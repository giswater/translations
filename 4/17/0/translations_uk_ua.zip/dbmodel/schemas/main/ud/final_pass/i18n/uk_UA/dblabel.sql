/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = SCHEMA_NAME, public, pg_catalog;
UPDATE sys_label AS t SET idval = v.idval FROM (
	VALUES
	(1001, 'ІНФО'),
    (1002, 'ПОПЕРЕДЖЕННЯ'),
    (1003, 'ПОМИЛКА'),
    (1004, 'КРИТИЧНІ ПОМИЛКИ'),
    (1005, 'ПІДКАЗКА'),
    (2000, ' '),
    (2007, '-------'),
    (2008, '--------'),
    (2009, '---------'),
    (2010, '----------'),
    (2011, '-----------'),
    (2014, '--------------'),
    (2022, '----------------------'),
    (2025, '-------------------------'),
    (2030, '------------------------------'),
    (2049, '-------------------------------------------------'),
    (3001, 'ІНФОРМАЦІЯ'),
    (3002, 'ПОПЕРЕДЖЕННЯ'),
    (3003, 'ПОМИЛКИ'),
    (3006, 'ДУГА РОЗДІЛ = TRUE'),
    (3008, 'ДУГА РОЗДІЛ = FALSE'),
    (3009, 'ПІДСУМОК'),
    (3010, 'ПЕРЕВІРИТИ СИСТЕМУ'),
    (3011, 'ПЕРЕВІРИТИ ДАНІ БД'),
    (3012, 'ДЕТАЛІ'),
    (4001, 'Main Data'),
    (4002, 'Additional Data'),
    (4003, 'Data'),
    (4004, 'Dscenario')
) AS v(id, idval)
WHERE t.id = v.id;