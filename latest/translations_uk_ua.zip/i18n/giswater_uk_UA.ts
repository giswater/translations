<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="uk_ua">
<!-- TOOLBARS AND ACTIONS -->
	<context>
		<name>giswater</name>
		<message>
			<source>18_text</source>
			<translation>комерційне підключення</translation>
		</message>
		<message>
			<source>19_text</source>
			<translation>Топо інструменти</translation>
		</message>
		<message>
			<source>24_text</source>
			<translation>Go2EPA експрес</translation>
		</message>
		<message>
			<source>301_text</source>
			<translation>Річний Планувальник</translation>
		</message>
		<message>
			<source>302_text</source>
			<translation>Місячний планувальник</translation>
		</message>
		<message>
			<source>303_text</source>
			<translation>Ціни генератор</translation>
		</message>
		<message>
			<source>304_text</source>
			<translation>Додати візит</translation>
		</message>
		<message>
			<source>305_text</source>
			<translation>Планувальник одиниць</translation>
		</message>
		<message>
			<source>309_text</source>
			<translation>Менеджер інцидентів</translation>
		</message>
		<message>
			<source>36_text</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>38_text</source>
			<translation>Нова вартість мережі</translation>
		</message>
		<message>
			<source>47_text</source>
			<translation>Psector селектор</translation>
		</message>
		<message>
			<source>74_text</source>
			<translation>Додати нову ділянку</translation>
		</message>
		<message>
			<source>75_text</source>
			<translation>Менеджер Лота</translation>
		</message>
		<message>
			<source>76_text</source>
			<translation>Фільтр Лоту</translation>
		</message>
		<message>
			<source>81_text</source>
			<translation>Новий psector</translation>
		</message>
		<message>
			<source>82_text</source>
			<translation>PСектор менеджер</translation>
		</message>
		<message>
			<source>98_text</source>
			<translation>Редактор Конфігурації</translation>
		</message>
		<message>
			<source>Actions</source>
			<translation>Дії</translation>
		</message>
		<message>
			<source>Add drain GPKG project</source>
			<translation>Додати Дренаж GPKG Проект</translation>
		</message>
		<message>
			<source>Additional demand check</source>
			<translation>Додаткова Перевірка Попиту</translation>
		</message>
		<message>
			<source>Advanced</source>
			<translation>Розширений</translation>
		</message>
		<message>
			<source>AmBreakage</source>
			<translation>Адміністративний Інструмент</translation>
		</message>
		<message>
			<source>AmPriority</source>
			<translation>Пріоритет вибір і Розрахунок</translation>
		</message>
		<message>
			<source>Analytics</source>
			<translation>Аналітика</translation>
		</message>
		<message>
			<source>ARC</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>Breakdown Assignation</source>
			<translation>Аварія Призначення</translation>
		</message>
		<message>
			<source>Calibration</source>
			<translation>Калібрування</translation>
		</message>
		<message>
			<source>Closest arcs</source>
			<translation>Найближчі дуги</translation>
		</message>
		<message>
			<source>CONNEC</source>
			<translation>Підключення</translation>
		</message>
		<message>
			<source>DRAG-DROP</source>
			<translation>Перетягування-Переміщення</translation>
		</message>
		<message>
			<source>Dscenario</source>
			<translation>Dсценарій</translation>
		</message>
		<message>
			<source>DWF scenario</source>
			<translation>DWF сценарій</translation>
		</message>
		<message>
			<source>Emitter calibration</source>
			<translation>Калібрування емітера</translation>
		</message>
		<message>
			<source>EPA multi calls</source>
			<translation>EPA множинні виклики</translation>
		</message>
		<message>
			<source>Export</source>
			<translation>Експорт</translation>
		</message>
		<message>
			<source>Fast print</source>
			<translation>Швидкий друк</translation>
		</message>
		<message>
			<source>Forced arcs</source>
			<translation>Примусові дуги</translation>
		</message>
		<message>
			<source>Forced arcs (selecting only arcs)</source>
			<translation>Примусові дуги (вибір лише дуг)</translation>
		</message>
		<message>
			<source>Get help</source>
			<translation>Отримати допомогу</translation>
		</message>
		<message>
			<source>Go2IBER</source>
			<translation>Go2IBER</translation>
		</message>
		<message>
			<source>GULLY</source>
			<translation>Ливневий Колодязь</translation>
		</message>
		<message>
			<source>GwAddCampaignButton</source>
			<translation>Додати Кампанію</translation>
		</message>
		<message>
			<source>GwAddChildLayerButton</source>
			<translation>Завантажити шар Giswater</translation>
		</message>
		<message>
			<source>GwAddLotButton</source>
			<translation>Додати Лот</translation>
		</message>
		<message>
			<source>GwAmBreakageButton</source>
			<translation>Адміністративний Інструмент</translation>
		</message>
		<message>
			<source>GwAmPriorityButton</source>
			<translation>Обчислення Пріоритету за Вибором</translation>
		</message>
		<message>
			<source>GwArcAddButton</source>
			<translation>Вставити дугу</translation>
		</message>
		<message>
			<source>GwArcDivideButton</source>
			<translation>Дуга поділ</translation>
		</message>
		<message>
			<source>GwArcFusionButton</source>
			<translation>Дуга злиття</translation>
		</message>
		<message>
			<source>GwAuxCircleAddButton</source>
			<translation>Створити коло</translation>
		</message>
		<message>
			<source>GwAuxPointAddButton</source>
			<translation>Створити точку</translation>
		</message>
		<message>
			<source>GwConfigButton</source>
			<translation>Конфігурація</translation>
		</message>
		<message>
			<source>GwConnectLinkButton</source>
			<translation>Підключитися до мережі</translation>
		</message>
		<message>
			<source>GwCSVButton</source>
			<translation>Імпорт CSV</translation>
		</message>
		<message>
			<source>GwDateSelectorButton</source>
			<translation>Вибір Дати</translation>
		</message>
		<message>
			<source>GwDimensioningButton</source>
			<translation>Розрахунок Розмірів</translation>
		</message>
		<message>
			<source>GwDocumentButton</source>
			<translation>Додати Документ</translation>
		</message>
		<message>
			<source>GwDocumentManagerButton</source>
			<translation>Менеджер Документів</translation>
		</message>
		<message>
			<source>GwDscenarioManagerButton</source>
			<translation>Dсценарій менеджер</translation>
		</message>
		<message>
			<source>GwElementButton</source>
			<translation>Додати елемент</translation>
		</message>
		<message>
			<source>GwElementManagerButton</source>
			<translation>Менеджер елементів</translation>
		</message>
		<message>
			<source>GwEpaTools</source>
			<translation>EPA інструменти</translation>
		</message>
		<message>
			<source>GwFeatureDeleteButton</source>
			<translation>Видалити елемент</translation>
		</message>
		<message>
			<source>GwFeatureEndButton</source>
			<translation>Завершити Елемент</translation>
		</message>
		<message>
			<source>GwFeatureReplaceButton</source>
			<translation>Замінити елемент</translation>
		</message>
		<message>
			<source>GwFeatureTypeChangeButton</source>
			<translation>Змінити Тип Об&apos;єкта</translation>
		</message>
		<message>
			<source>GwFlowExitButton</source>
			<translation>Потік вихід</translation>
		</message>
		<message>
			<source>GwFlowTraceButton</source>
			<translation>Відстеження потоку</translation>
		</message>
		<message>
			<source>GwGo2EpaButton</source>
			<translation>Go2EPA</translation>
		</message>
		<message>
			<source>GwGo2EpaManagerButton</source>
			<translation>EPA менеджер результатів</translation>
		</message>
		<message>
			<source>GwGo2EpaSelectorButton</source>
			<translation>EPA Селектор Результатів</translation>
		</message>
		<message>
			<source>GwInfoButton</source>
			<translation>Інфо Giswater</translation>
		</message>
		<message>
			<source>GwLayerStyleChangeButton</source>
			<translation>Giswater Стилі</translation>
		</message>
		<message>
			<source>GwLotResourceManagementButton</source>
			<translation>Управління Ресурсами Лоту</translation>
		</message>
		<message>
			<source>GwManageCampaignLotButton</source>
			<translation>Керувати Лотом Кампанії</translation>
		</message>
		<message>
			<source>GwMincutButton</source>
			<translation>Новий mincut</translation>
		</message>
		<message>
			<source>GwMincutManagerButton</source>
			<translation>Mincut Керування</translation>
		</message>
		<message>
			<source>GwNetscenarioManagerButton</source>
			<translation>Менеджер Сценарію Мережі</translation>
		</message>
		<message>
			<source>GwNonVisualManagerButton</source>
			<translation>Менеджер Невізуальних Об&apos;єктів</translation>
		</message>
		<message>
			<source>GwPointAddButton</source>
			<translation>Вставити точку</translation>
		</message>
		<message>
			<source>GwPriceManagerButton</source>
			<translation>Мережа витрати менеджер</translation>
		</message>
		<message>
			<source>GwPrintButton</source>
			<translation>Друк</translation>
		</message>
		<message>
			<source>GwProfileButton</source>
			<translation>Інструмент профілю</translation>
		</message>
		<message>
			<source>GwProjectCheckButton</source>
			<translation>Перевірити Проект</translation>
		</message>
		<message>
			<source>GwPsectorButton</source>
			<translation>Новий pсектор</translation>
		</message>
		<message>
			<source>GwPsectorManagerButton</source>
			<translation>Psector менеджер</translation>
		</message>
		<message>
			<source>GwResultManagerButton</source>
			<translation>Менеджер результатів</translation>
		</message>
		<message>
			<source>GwResultSelectorButton</source>
			<translation>Селектор Результатів</translation>
		</message>
		<message>
			<source>GwSearchButton</source>
			<translation>Пошук Плюс</translation>
		</message>
		<message>
			<source>GwSelectorButton</source>
			<translation>Селектори</translation>
		</message>
		<message>
			<source>GwSnapshotViewButton</source>
			<translation>Перегляд знімка</translation>
		</message>
		<message>
			<source>GwToolBoxButton</source>
			<translation>Набір Інструментів</translation>
		</message>
		<message>
			<source>GwUtilsManagerButton</source>
			<translation>Утиліти менеджер</translation>
		</message>
		<message>
			<source>GwVisitButton</source>
			<translation>Додати візит</translation>
		</message>
		<message>
			<source>GwVisitManagerButton</source>
			<translation>Менеджер Візитів</translation>
		</message>
		<message>
			<source>GwWorkspaceManagerButton</source>
			<translation>Менеджер Робочого Простору</translation>
		</message>
		<message>
			<source>Hydrology scenario</source>
			<translation>Гідрологія сценарій</translation>
		</message>
		<message>
			<source>Import</source>
			<translation>Імпорт</translation>
		</message>
		<message>
			<source>Import CSV</source>
			<translation>Імпорт CSV</translation>
		</message>
		<message>
			<source>Import INP file</source>
			<translation>Імпорт INP Файлу</translation>
		</message>
		<message>
			<source>Manage Campaign</source>
			<translation>Керувати Кампанією</translation>
		</message>
		<message>
			<source>Manage Campaign</source>
			<translation>Керувати Кампанією</translation>
		</message>
		<message>
			<source>Manage Lot</source>
			<translation>Керувати Лотом</translation>
		</message>
		<message>
			<source>Manage Lot</source>
			<translation>Керувати Лотом</translation>
		</message>
		<message>
			<source>Manage Workorder</source>
			<translation>Керувати Робочим Нарядом</translation>
		</message>
		<message>
			<source>Mapzones manager</source>
			<translation>Менеджер Зон Карти</translation>
		</message>
		<message>
			<source>Massive composer</source>
			<translation>Масовий композитор</translation>
		</message>
		<message>
			<source>menu_name</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>Multi psector print</source>
			<translation>Мульти psector друк</translation>
		</message>
		<message>
			<source>NODE</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>Open plugin folder</source>
			<translation>Відкрити Папку Плагіна</translation>
		</message>
		<message>
			<source>Open user folder</source>
			<translation>Відкрити Папку Користувача</translation>
		</message>
		<message>
			<source>Priority Calculation (Global)</source>
			<translation>Розрахунок Пріоритету (Глобальний)</translation>
		</message>
		<message>
			<source>Quantized demands</source>
			<translation>Квантизовані потреби</translation>
		</message>
		<message>
			<source>Reset dialogs</source>
			<translation>скинути діалоги</translation>
		</message>
		<message>
			<source>Reset plugin</source>
			<translation>Скинути Плагін</translation>
		</message>
		<message>
			<source>ResultManager</source>
			<translation>Менеджер Результатів</translation>
		</message>
		<message>
			<source>ResultSelector</source>
			<translation>Вибір Результатів</translation>
		</message>
		<message>
			<source>Review</source>
			<translation>Переглянути</translation>
		</message>
		<message>
			<source>SELECT</source>
			<translation>Вибрати</translation>
		</message>
		<message>
			<source>Show current selectors</source>
			<translation>Показати поточні селектори</translation>
		</message>
		<message>
			<source>Static calibration</source>
			<translation>Статичне калібрування</translation>
		</message>
		<message>
			<source>Style manager</source>
			<translation>Менеджер Стилю</translation>
		</message>
		<message>
			<source>Toggle Log DB</source>
			<translation>Переключити Журнал DB</translation>
		</message>
		<message>
			<source>toolbar_am_name</source>
			<translation>Giswater - Менеджер Активів</translation>
		</message>
		<message>
			<source>toolbar_basic_name</source>
			<translation>Giswater - Базовий</translation>
		</message>
		<message>
			<source>toolbar_cm_name</source>
			<translation>Giswater - Менеджер Кампаній</translation>
		</message>
		<message>
			<source>toolbar_custom_name</source>
			<translation>Giswater - Користувацький</translation>
		</message>
		<message>
			<source>toolbar_edit_name</source>
			<translation>Giswater - Редагувати</translation>
		</message>
		<message>
			<source>toolbar_epa_name</source>
			<translation>Giswater - Epa</translation>
		</message>
		<message>
			<source>toolbar_om_name</source>
			<translation>Giswater - O&amp;M</translation>
		</message>
		<message>
			<source>toolbar_plan_name</source>
			<translation>Giswater - Генплан</translation>
		</message>
		<message>
			<source>toolbar_utilities_name</source>
			<translation>Giswater - Утиліти</translation>
		</message>
		<message>
			<source>Valve operation check</source>
			<translation>Перевірка Роботи Клапана</translation>
		</message>
		<message>
			<source>Visit</source>
			<translation>Відвідати</translation>
		</message>
		<message>
			<source>Workcat manager</source>
			<translation>Менеджер Workcat</translation>
		</message>
	</context>
<!-- PYTHON MESSAGES -->
	<context>
		<name>giswater</name>
		<message>
			<source></source>
			<translation></translation>
		</message>
		<message>
			<source> </source>
			<translation> </translation>
		</message>
		<message>
			<source>, </source>
			<translation>,</translation>
		</message>
		<message>
			<source>{0}</source>
			<translation>{0}</translation>
		</message>
		<message>
			<source>{0} --&gt; {1}</source>
			<translation>{0} --&gt; {1}</translation>
		</message>
		<message>
			<source>{0}: {1}</source>
			<translation>{0}: {1}</translation>
		</message>
		<message>
			<source>{0} --&gt; {1} --&gt; {2}</source>
			<translation>{0} --&gt; {1} --&gt; {2}</translation>
		</message>
		<message>
			<source>{0} ({1}) - {2} - Updating {3}...</source>
			<translation>0} ({1}) - {2} - Оновлення {3}...</translation>
		</message>
		<message>
			<source>{0}: {1} Python function: tools_gw.set_widgets. WHERE columname=&apos;{2}&apos; AND widgetname=&apos;{3}&apos; AND widgettype=&apos;{4}&apos;</source>
			<translation>{0}: {1} Python-функція: tools_gw.set_widgets. WHERE columname=&apos;{2}&apos; AND widgetname=&apos;{3}&apos; AND widgettype=&apos;{4}&apos;</translation>
		</message>
		<message>
			<source>{0}: {1}. widgetname=&apos;{2}&apos; AND widgettype=&apos;{3}&apos;</source>
			<translation>{0}: {1}. widgetname=&apos;{2}&apos; AND widgettype=&apos;{3}&apos;</translation>
		</message>
		<message>
			<source>{0} callback raised: {1}</source>
			<translation>{0} callback raised: {1}</translation>
		</message>
		<message>
			<source>{0} campaign(s) deleted.</source>
			<translation>{0} campaign(s) deleted.</translation>
		</message>
		<message>
			<source>{0}: Config file is not set</source>
			<translation>{0}: Файл конфігурації не задано</translation>
		</message>
		<message>
			<source>{0}: Database translation canceled.</source>
			<translation>{0}: Database translation canceled.</translation>
		</message>
		<message>
			<source>{0}: Database translation failed.</source>
			<translation>{0}: Database translation failed.</translation>
		</message>
		<message>
			<source>{0}: Database translation successful to {1}.</source>
			<translation>{0}: Database translation successful to {1}.</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; does not exist. Please select a valid config file.</source>
			<translation>&quot;{0}&quot; does not exist. Please select a valid config file.</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; does not exist. Please select a valid folder.</source>
			<translation>&quot;{0}&quot; does not exist. Please select a valid folder.</translation>
		</message>
		<message>
			<source>{0} error {1}</source>
			<translation>{0} помилка {1}</translation>
		</message>
		<message>
			<source>{0} error: {1}</source>
			<translation>{0} помилка: {1}</translation>
		</message>
		<message>
			<source>{0}: Errors: {1}</source>
			<translation>{0}: Errors: {1}</translation>
		</message>
		<message>
			<source>{0} exception: {1}</source>
			<translation>{0} виняток: {1}</translation>
		</message>
		<message>
			<source>{0} Exception: {1}</source>
			<translation>{0} Exception: {1}</translation>
		</message>
		<message>
			<source>{0} exception [{1}]: {2}</source>
			<translation>{0} виняток [{1}]: {2}</translation>
		</message>
		<message>
			<source>{0} failed.</source>
			<translation>{0} failed.</translation>
		</message>
		<message>
			<source>{0}: Failed to update Multilang language preference: {1}</source>
			<translation>{0}: Failed to update Multilang language preference: {1}</translation>
		</message>
		<message>
			<source>{0} id:</source>
			<translation>{0} id:</translation>
		</message>
		<message>
			<source>{0} ID is missing.</source>
			<translation>{0} ID is missing.</translation>
		</message>
		<message>
			<source>{0} is not a table name or {1}</source>
			<translation>{0} не є назвою таблиці або {1}</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; is not a valid calibration_mode.</source>
			<translation>&quot;{0}&quot; is not a valid calibration_mode.</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; is not a valid target_parameter.</source>
			<translation>&quot;{0}&quot; is not a valid target_parameter.</translation>
		</message>
		<message>
			<source>{0} item(s) removed from the list: {1}</source>
			<translation>{0} item(s) removed from the list: {1}</translation>
		</message>
		<message>
			<source>{0} lot(s) deleted.</source>
			<translation>{0} lot(s) deleted.</translation>
		</message>
		<message>
			<source>{0}: Multilang language preference updated to {1}.</source>
			<translation>{0}: Multilang language preference updated to {1}.</translation>
		</message>
		<message>
			<source>{0} must contain {1} line{2}.</source>
			<translation>{0} must contain {1} line{2}.</translation>
		</message>
		<message>
			<source>{0} must contain just one line.</source>
			<translation>{0} must contain just one line.</translation>
		</message>
		<message>
			<source>{0} not found in {1} scenario.</source>
			<translation>{0} not found in {1} scenario.</translation>
		</message>
		<message>
			<source>{0} not found in [OPTIONS] section.</source>
			<translation>{0} not found in [OPTIONS] section.</translation>
		</message>
		<message>
			<source>{0}: project type &apos;{1}&apos; not supported</source>
			<translation>{0}: тип проєкту &apos;{1}&apos; не підтримується</translation>
		</message>
		<message>
			<source>{0}: Reference {1} = &apos;{2}&apos; it is not managed</source>
			<translation>{0}: Посилання {1} = &apos;{2}&apos; не керується</translation>
		</message>
		<message>
			<source>{0}: Refusing to write invalid user_params.config [{1}]: {2}</source>
			<translation>{0}: Refusing to write invalid user_params.config [{1}]: {2}</translation>
		</message>
		<message>
			<source>{0}: Refusing to write plugin user_params.config while GwDevMode is enabled</source>
			<translation>{0}: Refusing to write plugin user_params.config while GwDevMode is enabled</translation>
		</message>
		<message>
			<source>{0}.sql: {1}</source>
			<translation>{0}.sql: {1}</translation>
		</message>
		<message>
			<source>{0} successfully saved.</source>
			<translation>{0} успішно збережено.</translation>
		</message>
		<message>
			<source>{0} task is already active!</source>
			<translation>{0} завдання вже активне!</translation>
		</message>
		<message>
			<source>{0} to link</source>
			<translation>{0} to link</translation>
		</message>
		<message>
			<source>{0}: unsupported type {1}</source>
			<translation>{0}: unsupported type {1}</translation>
		</message>
		<message>
			<source>{0}: widget not found</source>
			<translation>{0}: віджет не знайдено</translation>
		</message>
		<message>
			<source>{0} workorder(s) deleted.</source>
			<translation>{0} workorder(s) deleted.</translation>
		</message>
		<message>
			<source>Accept</source>
			<translation>Accept</translation>
		</message>
		<message>
			<source>Action has no function!!</source>
			<translation>Дія не має функції!!</translation>
		</message>
		<message>
			<source>Activate water netowrk snapshot</source>
			<translation>Активувати знімок водної мережі</translation>
		</message>
		<message>
			<source>Adapt schema to cibs</source>
			<translation>Adapt schema to cibs</translation>
		</message>
		<message>
			<source>Add document</source>
			<translation>Додати документ</translation>
		</message>
		<message>
			<source>Add translator ({0})</source>
			<translation>Add translator ({0})</translation>
		</message>
		<message>
			<source>A diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.</source>
			<translation>Значення діаметра вважається недійсним, якщо воно дорівнює нулю, від&apos;ємне, NULL або більше за максимальний діаметр у таблиці конфігурації. Внаслідок цього цим трубам НЕ буде присвоєно значення пріоритету.</translation>
		</message>
		<message>
			<source>Advanced Menu</source>
			<translation>Розширене Меню</translation>
		</message>
		<message>
			<source>Alert</source>
			<translation>Попередження</translation>
		</message>
		<message>
			<source>All dialogs updated correctly</source>
			<translation>Усі діалоги успішно оновлено</translation>
		</message>
		<message>
			<source>ALL DONE! INP successfully imported.</source>
			<translation>ALL DONE! INP successfully imported.</translation>
		</message>
		<message>
			<source>All layers have been successfully refreshed.</source>
			<translation>Усі шари успішно оновлено.</translation>
		</message>
		<message>
			<source>All messages updated correctly</source>
			<translation>Усі повідомлення успішно оновлено</translation>
		</message>
		<message>
			<source>All the values in the column &apos;atlas_id&apos; from the table &apos;plan_psector&apos; have to be INTEGER. This is not the case for your table, please fix this before continuing.</source>
			<translation>Всі значення в стовпці &apos;atlas_id&apos; таблиці &apos;plan_psector&apos; мають бути INTEGER. У вашій таблиці це не так, будь ласка, виправте це перед продовженням.</translation>
		</message>
		<message>
			<source>A material is considered invalid if it is not listed in the material configuration table.</source>
			<translation>Матеріал вважається недійсним, якщо він не вказаний у таблиці конфігурації матеріалів.</translation>
		</message>
		<message>
			<source>An arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.</source>
			<translation>arccat_id вважається недійсним, якщо він не вказаний у таблиці конфігурації каталогу. Внаслідок цього цим трубам НЕ БУДЕ присвоєно значення пріоритету.</translation>
		</message>
		<message>
			<source>An error occurred saving the workorder.</source>
			<translation>An error occurred saving the workorder.</translation>
		</message>
		<message>
			<source>An error occurred while adding the style for layer &apos;{0}&apos;:\n{1}</source>
			<translation>An error occurred while adding the style for layer &apos;{0}&apos;:\n{1}</translation>
		</message>
		<message>
			<source>A new style has been added to &apos;{0}&apos; for the layer &apos;{1}&apos; using the &apos;GwBasic&apos; style information.\nYou can change it and use &apos;Update Style&apos; to create a personalized version.</source>
			<translation>A new style has been added to &apos;{0}&apos; for the layer &apos;{1}&apos; using the &apos;GwBasic&apos; style information.\nYou can change it and use &apos;Update Style&apos; to create a personalized version.</translation>
		</message>
		<message>
			<source>Any connec_id found with this customer_code</source>
			<translation>Будь-який connec_id, знайдений із цим customer_code</translation>
		</message>
		<message>
			<source>Any document selected</source>
			<translation>Жодного документа не вибрано</translation>
		</message>
		<message>
			<source>Any record found</source>
			<translation>Any record found</translation>
		</message>
		<message>
			<source>Any record selected</source>
			<translation>Жоден запис не вибрано</translation>
		</message>
		<message>
			<source>Applied styles for context</source>
			<translation>Застосовані Стилі Для Контексту</translation>
		</message>
		<message>
			<source>Apply Multilang translation ({0}) to schema ({1})?</source>
			<translation>Apply Multilang translation ({0}) to schema ({1})?</translation>
		</message>
		<message>
			<source>Apply translation ({0}) to schema ({1}) using local SQL files?</source>
			<translation>Apply translation ({0}) to schema ({1}) using local SQL files?</translation>
		</message>
		<message>
			<source>Arc already selected</source>
			<translation>Arc already selected</translation>
		</message>
		<message>
			<source>Arc fusion</source>
			<translation>Злиття дуг</translation>
		</message>
		<message>
			<source>Arc layer not found. Cannot start inundation from arc.</source>
			<translation>Arc layer not found. Cannot start inundation from arc.</translation>
		</message>
		<message>
			<source>Are you sure to execute vacuum on selected schema?</source>
			<translation>Ви впевнені, що хочете виконати vacuum у вибраній схемі?</translation>
		</message>
		<message>
			<source>Are you sure to save this feature?</source>
			<translation>Are you sure to save this feature?</translation>
		</message>
		<message>
			<source>Are you sure to update the project schema to last version?</source>
			<translation>Ви впевнені, що оновити схему проєкту до останньої версії?</translation>
		</message>
		<message>
			<source>Are you sure you want delete schema &apos;{0}&apos;?</source>
			<translation>Ви впевнені, що хочете видалити схему &apos;{0}&apos;?</translation>
		</message>
		<message>
			<source>Are you sure you want to assign team &apos;{0}&apos; to {1} selected user(s)?</source>
			<translation>Are you sure you want to assign team &apos;{0}&apos; to {1} selected user(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to cancel these mincuts?</source>
			<translation>Ви впевнені, що хочете скасувати ці mincuts?</translation>
		</message>
		<message>
			<source>Are you sure you want to change to team &apos;{0}&apos; for {1} selected user(s)?</source>
			<translation>Are you sure you want to change to team &apos;{0}&apos; for {1} selected user(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} campaign(s)?</source>
			<translation>Are you sure you want to delete {0} campaign(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} lot(s)?</source>
			<translation>Are you sure you want to delete {0} lot(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} workorder(s)?</source>
			<translation>Are you sure you want to delete {0} workorder(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the selected styles?</source>
			<translation>Ви впевнені, що хочете видалити вибрані стилі?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these mincuts?</source>
			<translation>Ви впевнені, що бажаєте видалити ці mincuts?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records:</source>
			<translation>Ви впевнені, що хочете видалити ці записи:</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records?</source>
			<translation>Ви впевнені, що хочете видалити ці записи?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records: ({0})?</source>
			<translation>Are you sure you want to delete these records: ({0})?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records: ({0})?\nThis will also delete the database user(s): {1}</source>
			<translation>Are you sure you want to delete these records: ({0})?\nThis will also delete the database user(s): {1}</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records?\nSome events have documents</source>
			<translation>Are you sure you want to delete these records?\nSome events have documents</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the style group &apos;{0}&apos;?\n\nThis will also delete all related entries in the sys_style table.Confirm Cascade Delete</source>
			<translation>Are you sure you want to delete the style group &apos;{0}&apos;?\n\nThis will also delete all related entries in the sys_style table.Confirm Cascade Delete</translation>
		</message>
		<message>
			<source>Are you sure you want to disconnect this elements?</source>
			<translation>Ви впевнені, що хочете від&apos;єднати ці елементи?</translation>
		</message>
		<message>
			<source>Are you sure you want to override the configuration of this workspace?</source>
			<translation>Ви впевнені, що хочете перезаписати конфігурацію цієї робочої області?</translation>
		</message>
		<message>
			<source>Are you sure you want to overwrite this file?</source>
			<translation>Ви впевнені, що хочете перезаписати цей файл?</translation>
		</message>
		<message>
			<source>Are you sure you want to remove team assignment from {0} selected user(s)?</source>
			<translation>Are you sure you want to remove team assignment from {0} selected user(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to replace selected feature with a new one?</source>
			<translation>Ви впевнені, що хочете замінити вибраний елемент на новий?</translation>
		</message>
		<message>
			<source>Are you sure you want to replace selected feature with a new one?\nIf you have different addfields in your feature, they will be deleted.</source>
			<translation>Are you sure you want to replace selected feature with a new one?\nIf you have different addfields in your feature, they will be deleted.</translation>
		</message>
		<message>
			<source>Are you sure you want to update the style of {0} ({1}) with the symbology of the layer in the project? \nYou are going to lose previous information!</source>
			<translation>Are you sure you want to update the style of {0} ({1}) with the symbology of the layer in the project? \nYou are going to lose previous information!</translation>
		</message>
		<message>
			<source>A rollback on schema will be done.</source>
			<translation>Виконано відкат схеми.</translation>
		</message>
		<message>
			<source>As a result, the material of these pipes will be treated as the configured unknown material, {0}.</source>
			<translation>Внаслідок цього матеріал цих труб буде трактуватися як налаштований невідомий матеріал, {0}.</translation>
		</message>
		<message>
			<source>A scenario cannot be named &apos;base&apos;.</source>
			<translation>A scenario cannot be named &apos;base&apos;.</translation>
		</message>
		<message>
			<source>Assign Team</source>
			<translation>Assign Team</translation>
		</message>
		<message>
			<source>A style already exists for the layer &apos;{0}&apos; in the selected style group.</source>
			<translation>Стиль для шару &apos;{0}&apos; уже існує в обраній групі стилів.</translation>
		</message>
		<message>
			<source>Atlas ID must be an integer.</source>
			<translation>Atlas ID must be an integer.</translation>
		</message>
		<message>
			<source>Automatic language provisioning failed: {0}</source>
			<translation>Automatic language provisioning failed: {0}</translation>
		</message>
		<message>
			<source>Automatic language provisioning failed to start: {0}</source>
			<translation>Automatic language provisioning failed to start: {0}</translation>
		</message>
		<message>
			<source>&lt;b&gt;Key: &lt;/b&gt;{0}&lt;br&gt;&lt;b&gt;Key container: &lt;/b&gt;body/data/ &lt;br&gt;&lt;b&gt;Python file: &lt;/b&gt;{1} &lt;br&gt;&lt;b&gt;Python function:&lt;/b&gt; {2} &lt;br&gt;</source>
			<translation>&lt;b&gt;Key: &lt;/b&gt;{0}&lt;br&gt;&lt;b&gt;Key container: &lt;/b&gt;body/data/ &lt;br&gt;&lt;b&gt;Python file: &lt;/b&gt;{1} &lt;br&gt;&lt;b&gt;Python function:&lt;/b&gt; {2} &lt;br&gt;</translation>
		</message>
		<message>
			<source>Breakdown Assignation</source>
			<translation>Breakdown Assignation</translation>
		</message>
		<message>
			<source>Calculating values</source>
			<translation>Calculating values</translation>
		</message>
		<message>
			<source>Campaign</source>
			<translation>Campaign</translation>
		</message>
		<message>
			<source>Campaign ID not found.</source>
			<translation>Ідентифікатор кампанії не знайдено.</translation>
		</message>
		<message>
			<source>Campaign saved successfully</source>
			<translation>Campaign saved successfully</translation>
		</message>
		<message>
			<source>Cancel</source>
			<translation>Cancel</translation>
		</message>
		<message>
			<source>Canceling task...</source>
			<translation>Canceling task...</translation>
		</message>
		<message>
			<source>Cancelled ({0}/{1})</source>
			<translation>Cancelled ({0}/{1})</translation>
		</message>
		<message>
			<source>Cancelling...</source>
			<translation>Cancelling...</translation>
		</message>
		<message>
			<source>Cancel mincut</source>
			<translation>Скасувати mincut</translation>
		</message>
		<message>
			<source>Cancel mincuts</source>
			<translation>Скасувати mincuts</translation>
		</message>
		<message>
			<source>Cannot calibrate {0} ({1}).</source>
			<translation>Cannot calibrate {0} ({1}).</translation>
		</message>
		<message>
			<source>Cannot create file, check if its open</source>
			<translation>Не вдається створити файл, перевірте, чи він відкритий</translation>
		</message>
		<message>
			<source>Cannot create file, check if selected composer is the correct composer</source>
			<translation>Неможливо створити файл, перевірте, чи вибраний композитор є правильним</translation>
		</message>
		<message>
			<source>Cannot create file, check if selected giswater_advancedtools is the correct giswater_advancedtools</source>
			<translation>Не вдається створити файл, перевірте, чи вибраний giswater_advancedtools є правильним giswater_advancedtools</translation>
		</message>
		<message>
			<source>Cannot delete the current scenario. Please set another scenario as current first.</source>
			<translation>Cannot delete the current scenario. Please set another scenario as current first.</translation>
		</message>
		<message>
			<source>Cannot duplicate archived psector {0}. Please unarchive it first.</source>
			<translation>Cannot duplicate archived psector {0}. Please unarchive it first.</translation>
		</message>
		<message>
			<source>Cannot merge archived psector {0}. Please unarchive it first.</source>
			<translation>Cannot merge archived psector {0}. Please unarchive it first.</translation>
		</message>
		<message>
			<source>Cannot set inactive a current scenario. Please update current first.</source>
			<translation>Неможливо зробити поточний сценарій неактивним. Будь ласка, спочатку оновіть поточний.</translation>
		</message>
		<message>
			<source>Cannot set the active state of archived psector {0}. Please unarchive it first.</source>
			<translation>Cannot set the active state of archived psector {0}. Please unarchive it first.</translation>
		</message>
		<message>
			<source>Cannot set the current {0} scenario of an inactive scenario. Please activate it first.</source>
			<translation>Неможливо встановити поточний сценарій {0} неактивного сценарію. Будь ласка, активуйте його спочатку.</translation>
		</message>
		<message>
			<source>Cannot set the current netscenario of an inactive scenario. Please activate it first.</source>
			<translation>Неможливо встановити поточний netscenario неактивного сценарію. Будь ласка, спочатку активуйте його.</translation>
		</message>
		<message>
			<source>Can&apos;t create curve with only one value if flow is 0. Add more values or change the flow value.</source>
			<translation>Неможливо створити криву лише з одного значення, якщо flow = 0. Додайте більше значень або змініть значення flow.</translation>
		</message>
		<message>
			<source>Category name cannot be empty.</source>
			<translation>Назва категорії не може бути порожньою.</translation>
		</message>
		<message>
			<source>Category updated successfully!</source>
			<translation>Категорію успішно оновлено!</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a dscenario will delete data from features related to the dscenario.\nAre you sure you want to delete these records?</source>
			<translation>CAUTION! Deleting a dscenario will delete data from features related to the dscenario.\nAre you sure you want to delete these records?</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a netscenario will delete data from features related to the netscenario.\nAre you sure you want to delete these records?</source>
			<translation>CAUTION! Deleting a netscenario will delete data from features related to the netscenario.\nAre you sure you want to delete these records?</translation>
		</message>
		<message>
			<source>Change epa_type</source>
			<translation>Змінити epa_type</translation>
		</message>
		<message>
			<source>Changes applied to &quot;{0}&quot; successfully.</source>
			<translation>Changes applied to &quot;{0}&quot; successfully.</translation>
		</message>
		<message>
			<source>Changes on this page are dangerous and can break Giswater plugin in various ways. \nYou will need to restart QGIS or reload Giswater plugin to apply changes. Do you want continue?</source>
			<translation>Changes on this page are dangerous and can break Giswater plugin in various ways. \nYou will need to restart QGIS or reload Giswater plugin to apply changes. Do you want continue?</translation>
		</message>
		<message>
			<source>Changes saved.</source>
			<translation>Changes saved.</translation>
		</message>
		<message>
			<source>Change Team</source>
			<translation>Change Team</translation>
		</message>
		<message>
			<source>Check all</source>
			<translation>Check all</translation>
		</message>
		<message>
			<source>Check fields from table or view</source>
			<translation>Перевірте поля таблиці або подання</translation>
		</message>
		<message>
			<source>Checking any item will not uncheck any other item.</source>
			<translation>Позначення будь-якого елементу не зніме позначення з інших елементів.</translation>
		</message>
		<message>
			<source>Checking any item will uncheck all other items.</source>
			<translation>Позначення будь-якого елементу зніме позначення з усіх інших елементів.</translation>
		</message>
		<message>
			<source>Checking any item will uncheck all other items unless Shift is pressed.</source>
			<translation>Позначення будь-якого елементу зніме позначення з усіх інших елементів, якщо не натиснуто Shift.</translation>
		</message>
		<message>
			<source>Check project failed: no response from database function &apos;{0}&apos;.</source>
			<translation>Check project failed: no response from database function &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Choose dscenario</source>
			<translation>Оберіть dscenario</translation>
		</message>
		<message>
			<source>cibs schema does not exist. Create it first.</source>
			<translation>cibs schema does not exist. Create it first.</translation>
		</message>
		<message>
			<source>Cibs schema does not exist. Create it first.</source>
			<translation>Cibs schema does not exist. Create it first.</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it. </source>
			<translation>Клацання по елементу встановить/зніме прапорець.</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.\nChecking any item will not uncheck any other item.\nThis behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Clicking an item will check/uncheck it.\nChecking any item will not uncheck any other item.\nThis behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.\nChecking any item will uncheck all other items.\nThis behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Clicking an item will check/uncheck it.\nChecking any item will uncheck all other items.\nThis behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.\nChecking any item will uncheck all other items unless Shift is pressed.\nThis behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Clicking an item will check/uncheck it.\nChecking any item will uncheck all other items unless Shift is pressed.\nThis behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.\nThis behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Clicking an item will check/uncheck it.\nThis behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Click on 2 places on the map, creating a line, then set the location of a point</source>
			<translation>Клацніть у 2 місцях на карті, створивши лінію, потім вкажіть розташування точки</translation>
		</message>
		<message>
			<source>Click on arcs to select them. Use Alt+click to unselect selected arcs.</source>
			<translation>Клацніть по арках, щоб їх вибрати. Використайте Alt+клік, щоб зняти виділення з вибраних арок.</translation>
		</message>
		<message>
			<source>Click on disconnected node, move the pointer to the desired location on pipe to break it</source>
			<translation>Клацніть на відключеному вузлі, перемістіть вказівник до бажаного місця на трубі, щоб розрізати її</translation>
		</message>
		<message>
			<source>Click on feature or any place on the map and set radius of a circle</source>
			<translation>Клацніть елемент або будь-яке місце на карті та задайте радіус кола</translation>
		</message>
		<message>
			<source>Click on feature to replace it with a new one. You can select other layer to snap a different feature type.</source>
			<translation>Click on feature to replace it with a new one. You can select other layer to snap a different feature type.</translation>
		</message>
		<message>
			<source>Click on node, that joins two pipes, in order to remove it and merge pipes</source>
			<translation>Клацніть на вузлі, що з&apos;єднує дві труби, щоб видалити його та об&apos;єднати труби</translation>
		</message>
		<message>
			<source>Click on the object to change its class</source>
			<translation>Клацніть на об&apos;єкті, щоб змінити його клас</translation>
		</message>
		<message>
			<source>Close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>Column name already exists.</source>
			<translation>Ім&apos;я стовпця вже існує.</translation>
		</message>
		<message>
			<source>Column name and Label fields are mandatory. Please set correct value.</source>
			<translation>Поля Назва стовпця та Label є обов&apos;язковими. Будь ласка, встановіть правильне значення.</translation>
		</message>
		<message>
			<source>Column not found in table: {0}</source>
			<translation>Column not found in table: {0}</translation>
		</message>
		<message>
			<source>Completed with no exception and no result</source>
			<translation>Завершено без винятків і без результату</translation>
		</message>
		<message>
			<source>Composer disabled: atlas coverage layer must be &apos;v_plan_psector&apos;.</source>
			<translation>Composer disabled: atlas coverage layer must be &apos;v_plan_psector&apos;.</translation>
		</message>
		<message>
			<source>Composer disabled: atlas must be enabled with coverage layer &apos;v_plan_psector&apos;.</source>
			<translation>Composer disabled: atlas must be enabled with coverage layer &apos;v_plan_psector&apos;.</translation>
		</message>
		<message>
			<source>Composer disabled: export failed, check layout configuration.</source>
			<translation>Composer disabled: export failed, check layout configuration.</translation>
		</message>
		<message>
			<source>Composer disabled: file is empty.</source>
			<translation>Composer disabled: file is empty.</translation>
		</message>
		<message>
			<source>Composer disabled: layout not found.</source>
			<translation>Composer disabled: layout not found.</translation>
		</message>
		<message>
			<source>Composer disabled: no layouts available.</source>
			<translation>Composer disabled: no layouts available.</translation>
		</message>
		<message>
			<source>Composer disabled: select a template.</source>
			<translation>Composer disabled: select a template.</translation>
		</message>
		<message>
			<source>Conduits couldn&apos;t be inserted!</source>
			<translation>Conduits couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Config</source>
			<translation>Config</translation>
		</message>
		<message>
			<source>Config database file not found</source>
			<translation>Файл конфігурації бази даних не знайдено</translation>
		</message>
		<message>
			<source>Config file not found: {0}</source>
			<translation>Config file not found: {0}</translation>
		</message>
		<message>
			<source>Config file not found at</source>
			<translation>Файл конфігурації не знайдено за адресою</translation>
		</message>
		<message>
			<source>Config file not found at: {0}</source>
			<translation>Config file not found at: {0}</translation>
		</message>
		<message>
			<source>Configuration file couldn&apos;t be imported:\n{0}</source>
			<translation>Configuration file couldn&apos;t be imported:\n{0}</translation>
		</message>
		<message>
			<source>Configuration file not found, please make sure it is located in the correct directory and try again: {0}</source>
			<translation>Configuration file not found, please make sure it is located in the correct directory and try again: {0}</translation>
		</message>
		<message>
			<source>Configuration loaded successfully</source>
			<translation>Конфігурацію успішно завантажено</translation>
		</message>
		<message>
			<source>Configuration saved to {0}</source>
			<translation>Конфігурацію збережено в {0}</translation>
		</message>
		<message>
			<source>Confirm</source>
			<translation>Confirm</translation>
		</message>
		<message>
			<source>Confirm Deletion</source>
			<translation>Підтвердити видалення</translation>
		</message>
		<message>
			<source>Connec management</source>
			<translation>Connec management</translation>
		</message>
		<message>
			<source>Connected to {0}</source>
			<translation>Підключено до {0}</translation>
		</message>
		<message>
			<source>Connecting...</source>
			<translation>Connecting...</translation>
		</message>
		<message>
			<source>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;</source>
			<translation>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;. Trying in &apos;{2}&apos;...</source>
			<translation>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;. Trying in &apos;{2}&apos;...</translation>
		</message>
		<message>
			<source>Connection failed. Please, check connection parameters</source>
			<translation>Connection failed. Please, check connection parameters</translation>
		</message>
		<message>
			<source>Connection Failed. Please, check connection parameters</source>
			<translation>З&apos;єднання не вдалося. Будь ласка, перевірте параметри підключення</translation>
		</message>
		<message>
			<source>Connection Failed. Please, check connection parameters ({0})</source>
			<translation>Connection Failed. Please, check connection parameters ({0})</translation>
		</message>
		<message>
			<source>Connect link</source>
			<translation>Connect link</translation>
		</message>
		<message>
			<source>Connect link task is already active!</source>
			<translation>Задача підключення зв&apos;язку вже активна!</translation>
		</message>
		<message>
			<source>Connect to network</source>
			<translation>Connect to network</translation>
		</message>
		<message>
			<source>Context</source>
			<translation>Контекст</translation>
		</message>
		<message>
			<source>Converting to flwreg...</source>
			<translation>Converting to flwreg...</translation>
		</message>
		<message>
			<source>Copy project - {0}</source>
			<translation>Copy project - {0}</translation>
		</message>
		<message>
			<source>Could not delete language files ({0}): {1}</source>
			<translation>Could not delete language files ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not delete manifest.json: {0}</source>
			<translation>Could not delete manifest.json: {0}</translation>
		</message>
		<message>
			<source>Could not delete multilang translations ({0}): {1}</source>
			<translation>Could not delete multilang translations ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not determine event point coordinates</source>
			<translation>Не вдалося визначити координати точки події</translation>
		</message>
		<message>
			<source>Could not download language files ({0}): {1}</source>
			<translation>Could not download language files ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not download some language files. The project will continue to load. {0}</source>
			<translation>Could not download some language files. The project will continue to load. {0}</translation>
		</message>
		<message>
			<source>Could not extract language files: Unknown error</source>
			<translation>Could not extract language files: Unknown error</translation>
		</message>
		<message>
			<source>Could not find an ID for the style group &apos;{0}&apos;.</source>
			<translation>Не вдалося знайти ID для групи стилів &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Could not find config_style ID for idval &apos;{0}&apos;.</source>
			<translation>Не вдалося знайти config_style ID для idval &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Could not find ID column &apos;{0}&apos;.</source>
			<translation>Could not find ID column &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Could not find the corresponding ID for the selected style {0}.</source>
			<translation>Не вдалося знайти відповідний ID для обраного стилю {0}.</translation>
		</message>
		<message>
			<source>Could not get feature ID from snapped point</source>
			<translation>Не вдалося отримати ідентифікатор елемента зі зафіксованої точки</translation>
		</message>
		<message>
			<source>Could not load EPA Results layers</source>
			<translation>Could not load EPA Results layers</translation>
		</message>
		<message>
			<source>Could not open database connection for multilang task.</source>
			<translation>Could not open database connection for multilang task.</translation>
		</message>
		<message>
			<source>Could not reach the translations server. Showing downloaded languages only.</source>
			<translation>Could not reach the translations server. Showing downloaded languages only.</translation>
		</message>
		<message>
			<source>could not remove: {0}</source>
			<translation>could not remove: {0}</translation>
		</message>
		<message>
			<source>Could not retrieve feature from layer</source>
			<translation>Не вдалося отримати елемент зі шару</translation>
		</message>
		<message>
			<source>Could not seed multilang translations ({0}): {1}</source>
			<translation>Could not seed multilang translations ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not update locale metadata</source>
			<translation>Could not update locale metadata</translation>
		</message>
		<message>
			<source>Could not write control {0} - skipping</source>
			<translation>Could not write control {0} - skipping</translation>
		</message>
		<message>
			<source>Couldn&apos;t add group.</source>
			<translation>Couldn&apos;t add group.</translation>
		</message>
		<message>
			<source>Couldn&apos;t draw profile. You may need to select another exploitation.</source>
			<translation>Не вдалося намалювати профіль. Можливо, потрібно вибрати іншу експлуатацію.</translation>
		</message>
		<message>
			<source>Couldn&apos;t find layer to zoom to</source>
			<translation>Couldn&apos;t find layer to zoom to</translation>
		</message>
		<message>
			<source>Couldn&apos;t find node &apos;{0}&apos; for source &apos;{1}&apos;.</source>
			<translation>Couldn&apos;t find node &apos;{0}&apos; for source &apos;{1}&apos;.</translation>
		</message>
		<message>
			<source>Couldn&apos;t import swmm_api package. Try to reload the Giswater plugin. If the issue persists restart QGIS.</source>
			<translation>Не вдалося імпортувати пакет swmm_api. Спробуйте перезавантажити плагін Giswater. Якщо проблема не зникає, перезапустіть QGIS.</translation>
		</message>
		<message>
			<source>Create {0} schema</source>
			<translation>Створити схему {0}</translation>
		</message>
		<message>
			<source>Create am schema</source>
			<translation>Create am schema</translation>
		</message>
		<message>
			<source>Create am schema with sample data</source>
			<translation>Create am schema with sample data</translation>
		</message>
		<message>
			<source>Create base schema</source>
			<translation>Створити базову схему</translation>
		</message>
		<message>
			<source>Create catalogs</source>
			<translation>Create catalogs</translation>
		</message>
		<message>
			<source>Create example</source>
			<translation>Створити приклад</translation>
		</message>
		<message>
			<source>Create field on &quot;{0}&quot;</source>
			<translation>Create field on &quot;{0}&quot;</translation>
		</message>
		<message>
			<source>Create multi field</source>
			<translation>Create multi field</translation>
		</message>
		<message>
			<source>Create multilang schema</source>
			<translation>Create multilang schema</translation>
		</message>
		<message>
			<source>Create Project - {0}</source>
			<translation>Create Project - {0}</translation>
		</message>
		<message>
			<source>Create schema of type &apos;{0}&apos;: &apos;{1}&apos;</source>
			<translation>Створити Схему Типу &apos;{0}&apos;: &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Creating demand dscenario...</source>
			<translation>Creating demand dscenario...</translation>
		</message>
		<message>
			<source>Creating GIS file... {0}</source>
			<translation>Створення GIS Файлу... {0}</translation>
		</message>
		<message>
			<source>Creating new flwreg catalogs</source>
			<translation>Creating new flwreg catalogs</translation>
		</message>
		<message>
			<source>Creating new node catalogs</source>
			<translation>Creating new node catalogs</translation>
		</message>
		<message>
			<source>Creating new node catalogs...</source>
			<translation>Creating new node catalogs...</translation>
		</message>
		<message>
			<source>Creating new pipe catalogs</source>
			<translation>Creating new pipe catalogs</translation>
		</message>
		<message>
			<source>Creating new pipe catalogs...</source>
			<translation>Creating new pipe catalogs...</translation>
		</message>
		<message>
			<source>Creating new varc catalogs</source>
			<translation>Creating new varc catalogs</translation>
		</message>
		<message>
			<source>Creating new varc catalogs...</source>
			<translation>Creating new varc catalogs...</translation>
		</message>
		<message>
			<source>Creating parser for file: {0}</source>
			<translation>Створення Парсера Для Файлу: {0}</translation>
		</message>
		<message>
			<source>Creating quantized model...</source>
			<translation>Creating quantized model...</translation>
		</message>
		<message>
			<source>Creating user config folder</source>
			<translation>Створення Папки Конфігурації Користувача</translation>
		</message>
		<message>
			<source>Creating user config folder: {0}</source>
			<translation>Створення Папки Конфігурації Користувача: {0}</translation>
		</message>
		<message>
			<source>Creating workcat</source>
			<translation>Creating workcat</translation>
		</message>
		<message>
			<source>Creating workcat...</source>
			<translation>Creating workcat...</translation>
		</message>
		<message>
			<source>Creation type</source>
			<translation>Creation type</translation>
		</message>
		<message>
			<source>Credentials will be stored in the GIS project file as plain text, and will apply to both existing and future layers. Do you want to proceed?</source>
			<translation>Облікові дані будуть збережені у файлі проекту ГІС у вигляді відкритого тексту та застосовуватимуться як до існуючих, так і до майбутніх шарів. Продовжити?</translation>
		</message>
		<message>
			<source>CRITICAL ERROR in update_expl_sector_combos: {0}</source>
			<translation>CRITICAL ERROR in update_expl_sector_combos: {0}</translation>
		</message>
		<message>
			<source>CSV not generated. Check fields from table or view</source>
			<translation>CSV не згенеровано. Перевірте поля у таблиці або поданні</translation>
		</message>
		<message>
			<source>Current feature has state &apos;{0}&apos;. Therefore it is not fusionable</source>
			<translation>Поточний елемент має стан &apos;{0}&apos;. Тому він не підлягає злиттю</translation>
		</message>
		<message>
			<source>Current feature has state &apos;{0}&apos;. Therefore it is not replaceable</source>
			<translation>Поточний елемент має стан &apos;{0}&apos;. Отже, він не підлягає заміні</translation>
		</message>
		<message>
			<source>Current feature is planified. You should activate plan mode to work with it.</source>
			<translation>Поточний елемент заплановано. Активуйте режим плану, щоб працювати з ним.</translation>
		</message>
		<message>
			<source>Current node is not located over an arc. Please, select option &apos;DRAG-DROP&apos;</source>
			<translation>Поточний вузол не знаходиться над дугою. Будь ласка, виберіть опцію &apos;DRAG-DROP&apos;</translation>
		</message>
		<message>
			<source>Current psector</source>
			<translation>Поточний psector</translation>
		</message>
		<message>
			<source>Current Result</source>
			<translation>Current Result</translation>
		</message>
		<message>
			<source>Database connection error: {0}</source>
			<translation>Помилка підключення до бази даних: {0}</translation>
		</message>
		<message>
			<source>Database connection error ({0}): {1}</source>
			<translation>Database connection error ({0}): {1}</translation>
		</message>
		<message>
			<source>Database connection error. Please check your connection parameters.</source>
			<translation>Database connection error. Please check your connection parameters.</translation>
		</message>
		<message>
			<source>Database connection error (psycopg2). Please open plugin log file to get more details</source>
			<translation>Database connection error (psycopg2). Please open plugin log file to get more details</translation>
		</message>
		<message>
			<source>Database connection error (QSqlDatabase). Please open plugin log file to get more details</source>
			<translation>Database connection error (QSqlDatabase). Please open plugin log file to get more details</translation>
		</message>
		<message>
			<source>Database connection is not available</source>
			<translation>Database connection is not available</translation>
		</message>
		<message>
			<source>Database connection is not available.</source>
			<translation>Database connection is not available.</translation>
		</message>
		<message>
			<source>Database connection reset, please try again</source>
			<translation>Database connection reset, please try again</translation>
		</message>
		<message>
			<source>Database connection was closed and reconnected</source>
			<translation>Database connection was closed and reconnected</translation>
		</message>
		<message>
			<source>Database error</source>
			<translation>Database error</translation>
		</message>
		<message>
			<source>Database Error</source>
			<translation>Помилка Бази Даних</translation>
		</message>
		<message>
			<source>Database execution failed</source>
			<translation>Виконання запиту до бази даних не вдалося</translation>
		</message>
		<message>
			<source>Database name contains special characters that are not supported</source>
			<translation>Назва бази даних містить спеціальні символи, які не підтримуються</translation>
		</message>
		<message>
			<source>Database returned null. Check postgres function &apos;{0}&apos;</source>
			<translation>База даних повернула null. Перевірте функцію postgres &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Database translation canceled.</source>
			<translation>Переклад бази даних скасовано.</translation>
		</message>
		<message>
			<source>Database translation failed.</source>
			<translation>Переклад бази даних не вдався.</translation>
		</message>
		<message>
			<source>Database translation successful to</source>
			<translation>Переклад бази даних успішно виконано в</translation>
		</message>
		<message>
			<source>Data insertion completed: {0} successful, {1} errors.</source>
			<translation>Вставлення даних завершено: {0} успішно, {1} помилок.</translation>
		</message>
		<message>
			<source>Data retrieved and displayed successfully.</source>
			<translation>Дані успішно отримано та відображено.</translation>
		</message>
		<message>
			<source>Date from:</source>
			<translation>Дата від:</translation>
		</message>
		<message>
			<source>Date of creation</source>
			<translation>Дата створення</translation>
		</message>
		<message>
			<source>Date of last update</source>
			<translation>Дата останнього оновлення</translation>
		</message>
		<message>
			<source>Date to:</source>
			<translation>Дата до:</translation>
		</message>
		<message>
			<source>DEBUG: {0}</source>
			<translation>DEBUG: {0}</translation>
		</message>
		<message>
			<source>DEBUG: catalog: {0}, arctype_id: {1}, material: {2}, pipe_dint: {3}</source>
			<translation>DEBUG: catalog: {0}, arctype_id: {1}, material: {2}, pipe_dint: {3}</translation>
		</message>
		<message>
			<source>DEBUG: OPTIONS:</source>
			<translation>DEBUG: OPTIONS:</translation>
		</message>
		<message>
			<source>Delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>Delete base</source>
			<translation>Delete base</translation>
		</message>
		<message>
			<source>Delete dscenario</source>
			<translation>Delete dscenario</translation>
		</message>
		<message>
			<source>Delete field on &quot;{0}&quot;</source>
			<translation>Delete field on &quot;{0}&quot;</translation>
		</message>
		<message>
			<source>Delete function</source>
			<translation>Delete function</translation>
		</message>
		<message>
			<source>Delete inflows</source>
			<translation>Delete inflows</translation>
		</message>
		<message>
			<source>Delete language files?</source>
			<translation>Delete language files?</translation>
		</message>
		<message>
			<source>Delete Lot(s)</source>
			<translation>Delete Lot(s)</translation>
		</message>
		<message>
			<source>Delete mincut</source>
			<translation>Видалити mincut</translation>
		</message>
		<message>
			<source>Delete multi field</source>
			<translation>Delete multi field</translation>
		</message>
		<message>
			<source>Delete multilang translations</source>
			<translation>Delete multilang translations</translation>
		</message>
		<message>
			<source>Delete multilang translations for ({0})?</source>
			<translation>Delete multilang translations for ({0})?</translation>
		</message>
		<message>
			<source>Delete records</source>
			<translation>Видалити записи</translation>
		</message>
		<message>
			<source>Delete schema failed: {0}</source>
			<translation>Delete schema failed: {0}</translation>
		</message>
		<message>
			<source>Delete Workorder(s)</source>
			<translation>Delete Workorder(s)</translation>
		</message>
		<message>
			<source>Demand</source>
			<translation>Demand</translation>
		</message>
		<message>
			<source>Description</source>
			<translation>Опис</translation>
		</message>
		<message>
			<source>Detail</source>
			<translation>Деталь</translation>
		</message>
		<message>
			<source>Disconnect elements</source>
			<translation>Відключити елементи</translation>
		</message>
		<message>
			<source>Dividers couldn&apos;t be inserted!</source>
			<translation>Dividers couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Document already exist</source>
			<translation>Документ вже існує</translation>
		</message>
		<message>
			<source>Document already exists</source>
			<translation>Документ Вже Існує</translation>
		</message>
		<message>
			<source>Document inserted successfully</source>
			<translation>Документ успішно додано</translation>
		</message>
		<message>
			<source>Document name not found</source>
			<translation>Ім&apos;я документа не знайдено</translation>
		</message>
		<message>
			<source>Document PDF created in</source>
			<translation>PDF-документ створено в</translation>
		</message>
		<message>
			<source>Documents deleted successfully</source>
			<translation>Документи успішно видалені</translation>
		</message>
		<message>
			<source>done!</source>
			<translation>done!</translation>
		</message>
		<message>
			<source>DOWNGRADE NODE</source>
			<translation>DOWNGRADE NODE</translation>
		</message>
		<message>
			<source>Downloading language files for ({0})...</source>
			<translation>Downloading language files for ({0})...</translation>
		</message>
		<message>
			<source>Download language files?</source>
			<translation>Download language files?</translation>
		</message>
		<message>
			<source>Do you want to copy its values to the current node?</source>
			<translation>Ви хочете скопіювати його значення в поточний вузол?</translation>
		</message>
		<message>
			<source>Do you want to delete local language files for ({0})?</source>
			<translation>Do you want to delete local language files for ({0})?</translation>
		</message>
		<message>
			<source>Do you want to download local language files for ({0})?</source>
			<translation>Do you want to download local language files for ({0})?</translation>
		</message>
		<message>
			<source>Do you want to insert {0} selected features? (First 50: {1} ...)</source>
			<translation>Ви хочете вставити {0} вибраних елементів? (Перші 50: {1} ...)</translation>
		</message>
		<message>
			<source>Do you want to insert the selected features? {0}</source>
			<translation>Ви хочете вставити вибрані елементи? {0}</translation>
		</message>
		<message>
			<source>Do you want to insert the selected features?\n{0}</source>
			<translation>Do you want to insert the selected features?\n{0}</translation>
		</message>
		<message>
			<source>Do you want to overwrite custom values?</source>
			<translation>Бажаєте перезаписати користувацькі значення?</translation>
		</message>
		<message>
			<source>Do you want to overwrite file?</source>
			<translation>Бажаєте перезаписати файл?</translation>
		</message>
		<message>
			<source>Do you want to proceed?</source>
			<translation>Бажаєте продовжити?</translation>
		</message>
		<message>
			<source>Do you want to save changes to dscenario &quot;{0}&quot;?\nThis operation cannot be undone.\n\n(Please note that any changes made to node elevations cannot be saved to dscenarios.)</source>
			<translation>Do you want to save changes to dscenario &quot;{0}&quot;?\nThis operation cannot be undone.\n\n(Please note that any changes made to node elevations cannot be saved to dscenarios.)</translation>
		</message>
		<message>
			<source>Do you want to seed multilang translations for ({0})?</source>
			<translation>Do you want to seed multilang translations for ({0})?</translation>
		</message>
		<message>
			<source>Do you want to set this psector as current?</source>
			<translation>Ви хочете встановити цей psector як поточний?</translation>
		</message>
		<message>
			<source>Do you want to update local language files for ({0})?</source>
			<translation>Do you want to update local language files for ({0})?</translation>
		</message>
		<message>
			<source>Do you want to update multilang translations for ({0})?</source>
			<translation>Do you want to update multilang translations for ({0})?</translation>
		</message>
		<message>
			<source>Do you want to update the symbology of the layers currently loaded in the project?</source>
			<translation>Do you want to update the symbology of the layers currently loaded in the project?</translation>
		</message>
		<message>
			<source>Draw Profile</source>
			<translation>Draw Profile</translation>
		</message>
		<message>
			<source>Dscenario manager</source>
			<translation>Dscenario менеджер</translation>
		</message>
		<message>
			<source>Duplicate</source>
			<translation>Duplicate</translation>
		</message>
		<message>
			<source>Duplicate user and campaign pairs are not allowed. Remove duplicates before saving.</source>
			<translation>Duplicate user and campaign pairs are not allowed. Remove duplicates before saving.</translation>
		</message>
		<message>
			<source>DWF &amp; INFLOWS</source>
			<translation>DWF &amp; INFLOWS</translation>
		</message>
		<message>
			<source>DWF scenario manager</source>
			<translation>DWF scenario менеджер</translation>
		</message>
		<message>
			<source>Edit base</source>
			<translation>Edit base</translation>
		</message>
		<message>
			<source>Edit dscenario</source>
			<translation>Edit dscenario</translation>
		</message>
		<message>
			<source>Edit inflows</source>
			<translation>Edit inflows</translation>
		</message>
		<message>
			<source>Empty coordinate list</source>
			<translation>Порожній список координат</translation>
		</message>
		<message>
			<source>Empty response</source>
			<translation>Empty response</translation>
		</message>
		<message>
			<source>Empty response from database function.</source>
			<translation>Empty response from database function.</translation>
		</message>
		<message>
			<source>English locale not found</source>
			<translation>English locale not found</translation>
		</message>
		<message>
			<source>Epa2data execution failed. See logs for more details...</source>
			<translation>Виконання Epa2data не вдалося. Див. журнали для детальнішої інформації...</translation>
		</message>
		<message>
			<source>EPA model finished.</source>
			<translation>EPA model finished.</translation>
		</message>
		<message>
			<source>EPA model finished. </source>
			<translation>Модель EPA завершена.</translation>
		</message>
		<message>
			<source>EPA Result Families exported successfully:\n{0}</source>
			<translation>EPA Result Families exported successfully:\n{0}</translation>
		</message>
		<message>
			<source>Epa type is not defined for element {0}</source>
			<translation>Epa type is not defined for element {0}</translation>
		</message>
		<message>
			<source>Error</source>
			<translation>Помилка</translation>
		</message>
		<message>
			<source>ERROR -&gt; {0}</source>
			<translation>ERROR -&gt; {0}</translation>
		</message>
		<message>
			<source>Error: &apos;{0}&apos; or &apos;{1}&apos; field is missing in the result.</source>
			<translation>Помилка: у результаті відсутнє поле &apos;{0}&apos; або &apos;{1}&apos;.</translation>
		</message>
		<message>
			<source>Error assigning team: {0}</source>
			<translation>Error assigning team: {0}</translation>
		</message>
		<message>
			<source>Error canceling mincut task: {0}</source>
			<translation>Error canceling mincut task: {0}</translation>
		</message>
		<message>
			<source>Error changing team: {0}</source>
			<translation>Error changing team: {0}</translation>
		</message>
		<message>
			<source>Error closing mincut cursor: {0}</source>
			<translation>Error closing mincut cursor: {0}</translation>
		</message>
		<message>
			<source>Error connecting to database (layer)</source>
			<translation>Error connecting to database (layer)</translation>
		</message>
		<message>
			<source>Error connecting to database (settings)</source>
			<translation>Error connecting to database (settings)</translation>
		</message>
		<message>
			<source>Error connecting to i18n dataabse</source>
			<translation>Помилка підключення до i18n бази даних</translation>
		</message>
		<message>
			<source>Error connecting to i18n database</source>
			<translation>Помилка Підключення До Бази Даних i18n</translation>
		</message>
		<message>
			<source>Error connecting to origin database</source>
			<translation>Помилка підключення до початкової бази даних</translation>
		</message>
		<message>
			<source>Error: Could not extract message from line: {0}</source>
			<translation>Помилка: Не вдалося витягти повідомлення з рядка: {0}</translation>
		</message>
		<message>
			<source>Error creating auxiliary connection for vacuum</source>
			<translation>Помилка створення допоміжного з&apos;єднання для операції VACUUM</translation>
		</message>
		<message>
			<source>Error creating dynamic dialog: {0}</source>
			<translation>Error creating dynamic dialog: {0}</translation>
		</message>
		<message>
			<source>Error creating mincut cursor: {0}</source>
			<translation>Error creating mincut cursor: {0}</translation>
		</message>
		<message>
			<source>Error creating or updating team</source>
			<translation>Error creating or updating team</translation>
		</message>
		<message>
			<source>Error creating Workcat.</source>
			<translation>Помилка створення Workcat.</translation>
		</message>
		<message>
			<source>Error. Database returned null. Check postgres function &apos;{0}&apos;</source>
			<translation>Помилка. База Даних Повернула null. Перевірте Функцію postgres &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Error deleting data</source>
			<translation>Error deleting data</translation>
		</message>
		<message>
			<source>Error deleting records</source>
			<translation>Помилка при видаленні записів</translation>
		</message>
		<message>
			<source>Error deleting row</source>
			<translation>Помилка видалення рядка</translation>
		</message>
		<message>
			<source>Error deleting row: {0} - Query: {1}</source>
			<translation>Помилка видалення рядка: {0} - Запит: {1}</translation>
		</message>
		<message>
			<source>Error deleting rows: {0}</source>
			<translation>Error deleting rows: {0}</translation>
		</message>
		<message>
			<source>ERROR: DIVIDER &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: DIVIDER &apos;{0}&apos; has no coordinates in [COORDINATES] section.</translation>
		</message>
		<message>
			<source>Error during point selection: {0}</source>
			<translation>Помилка під час вибору точки: {0}</translation>
		</message>
		<message>
			<source>Error executing {0} - {1}</source>
			<translation>Error executing {0} - {1}</translation>
		</message>
		<message>
			<source>Error executing EPA software</source>
			<translation>Error executing EPA software</translation>
		</message>
		<message>
			<source>Error executing EPA software: {0}</source>
			<translation>Error executing EPA software: {0}</translation>
		</message>
		<message>
			<source>Error executing gw_fct_create_dscenario_empty</source>
			<translation>Помилка Виконання gw_fct_create_dscenario_empty</translation>
		</message>
		<message>
			<source>Error executing gw_fct_import_swmm_flwreg - {0}</source>
			<translation>Error executing gw_fct_import_swmm_flwreg - {0}</translation>
		</message>
		<message>
			<source>Error executing setmincut with cursor: {0}</source>
			<translation>Error executing setmincut with cursor: {0}</translation>
		</message>
		<message>
			<source>Error executing vacuum: {0}</source>
			<translation>Помилка Виконання vacuum: {0}</translation>
		</message>
		<message>
			<source>Error fetching existing primary keys</source>
			<translation>Помилка отримання існуючих первинних ключів</translation>
		</message>
		<message>
			<source>Error fetching existing primary keys: {0}</source>
			<translation>Помилка отримання існуючих первинних ключів: {0</translation>
		</message>
		<message>
			<source>Error finding string</source>
			<translation>Помилка пошуку рядка</translation>
		</message>
		<message>
			<source>Error fusing arcs</source>
			<translation>Помилка злиття дуг</translation>
		</message>
		<message>
			<source>Error getting current psector</source>
			<translation>Помилка отримання поточного psector</translation>
		</message>
		<message>
			<source>Error getting database parameters</source>
			<translation>Помилка отримання параметрів бази даних</translation>
		</message>
		<message>
			<source>Error getting default connection (settings)</source>
			<translation>Error getting default connection (settings)</translation>
		</message>
		<message>
			<source>Error getting exploitation</source>
			<translation>Помилка отримання експлуатації</translation>
		</message>
		<message>
			<source>Error getting locale from schema: {0}</source>
			<translation>Error getting locale from schema: {0}</translation>
		</message>
		<message>
			<source>Error getting source symbol: {0}</source>
			<translation>Error getting source symbol: {0}</translation>
		</message>
		<message>
			<source>Error getting table values: {0}</source>
			<translation>Помилка отримання значень таблиці: {0}</translation>
		</message>
		<message>
			<source>Error getting UI language locale: {0}</source>
			<translation>Error getting UI language locale: {0}</translation>
		</message>
		<message>
			<source>Error importing IBERGIS project</source>
			<translation>Помилка імпорту проєкту IBERGIS</translation>
		</message>
		<message>
			<source>Error importing simulation results into database</source>
			<translation>Error importing simulation results into database</translation>
		</message>
		<message>
			<source>Error in _manage_selection_changed: {0}</source>
			<translation>Error in _manage_selection_changed: {0}</translation>
		</message>
		<message>
			<source>Error in remove function: {0}</source>
			<translation>Error in remove function: {0}</translation>
		</message>
		<message>
			<source>Error inserting row: {0}</source>
			<translation>Помилка вставки рядка: {0}</translation>
		</message>
		<message>
			<source>ERROR: JUNCTION &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: JUNCTION &apos;{0}&apos; has no coordinates in [COORDINATES] section.</translation>
		</message>
		<message>
			<source>Error logging</source>
			<translation>Error logging</translation>
		</message>
		<message>
			<source>Error near line</source>
			<translation>Помилка поблизу рядка</translation>
		</message>
		<message>
			<source>Error near line {0} -&gt; {1}</source>
			<translation>Помилка біля рядка {0} -&gt; {1}</translation>
		</message>
		<message>
			<source>Error on create auto mincut, you need to review data</source>
			<translation>Помилка при створенні auto mincut, потрібно переглянути дані</translation>
		</message>
		<message>
			<source>ERROR: OUTFALL &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: OUTFALL &apos;{0}&apos; has no coordinates in [COORDINATES] section.</translation>
		</message>
		<message>
			<source>Error parsing file: {0}</source>
			<translation>Помилка розбору файлу: {0}</translation>
		</message>
		<message>
			<source>Error processing muni_id {0}: {1}</source>
			<translation>Помилка обробки muni_id {0}: {1}</translation>
		</message>
		<message>
			<source>ERROR: RAINGAGE &apos;{0}&apos; has no coordinates in [SYMBOLS] section.</source>
			<translation>ERROR: RAINGAGE &apos;{0}&apos; has no coordinates in [SYMBOLS] section.</translation>
		</message>
		<message>
			<source>Error reading configuration file: {0}</source>
			<translation>Помилка читання файлу конфігурації: {0}</translation>
		</message>
		<message>
			<source>Error reading file</source>
			<translation>Помилка читання файлу</translation>
		</message>
		<message>
			<source>Error reading file {0}: {1}</source>
			<translation>Помилка читання файлу {0}: {1}</translation>
		</message>
		<message>
			<source>Error removing items: {0}</source>
			<translation>Error removing items: {0}</translation>
		</message>
		<message>
			<source>Error removing team assignment: {0}</source>
			<translation>Error removing team assignment: {0}</translation>
		</message>
		<message>
			<source>Error replacing feature</source>
			<translation>Помилка під час заміни елемента</translation>
		</message>
		<message>
			<source>Error replacing feature. Chose a valid catalog.</source>
			<translation>Помилка заміни елемента. Виберіть дійсний каталог.</translation>
		</message>
		<message>
			<source>Error saving lot</source>
			<translation>Error saving lot</translation>
		</message>
		<message>
			<source>Error saving the configuration</source>
			<translation>Помилка збереження конфігурації</translation>
		</message>
		<message>
			<source>Error setting node</source>
			<translation>Error setting node</translation>
		</message>
		<message>
			<source>ERROR: STORAGE &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: STORAGE &apos;{0}&apos; has no coordinates in [COORDINATES] section.</translation>
		</message>
		<message>
			<source>Error toggling state: {0}</source>
			<translation>Error toggling state: {0}</translation>
		</message>
		<message>
			<source>Error type</source>
			<translation>Тип помилки</translation>
		</message>
		<message>
			<source>Error updating element in table, you need to review data</source>
			<translation>Помилка оновлення елемента в таблиці, вам потрібно перевірити дані</translation>
		</message>
		<message>
			<source>Error updating expl_id: {0}</source>
			<translation>Помилка оновлення expl_id: {0}</translation>
		</message>
		<message>
			<source>Error updating messages</source>
			<translation>Помилка оновлення повідомлень</translation>
		</message>
		<message>
			<source>Error updating table</source>
			<translation>Помилка при оновленні таблиці</translation>
		</message>
		<message>
			<source>Error updating table: {0}\n</source>
			<translation>Error updating table: {0}\n</translation>
		</message>
		<message>
			<source>EXCEPTION</source>
			<translation>ВИНЯТОК</translation>
		</message>
		<message>
			<source>Exception: {0}</source>
			<translation>Виняток: {0}</translation>
		</message>
		<message>
			<source>Exception: {0}.</source>
			<translation>Виняток: {0}.</translation>
		</message>
		<message>
			<source>EXCEPTION -&gt; {0}</source>
			<translation>EXCEPTION -&gt; {0}</translation>
		</message>
		<message>
			<source>EXCEPTION: {0}, {1}</source>
			<translation>ВИНЯТОК: {0}, {1}</translation>
		</message>
		<message>
			<source>Exception error: {0}</source>
			<translation>Виняткова помилка: {0}</translation>
		</message>
		<message>
			<source>Exception in {0}</source>
			<translation>Виняток у {0}</translation>
		</message>
		<message>
			<source>Exception in {0} (executing {1} from {2}): {3}</source>
			<translation>Виняток у {0} (виконання {1} з {2}): {3}</translation>
		</message>
		<message>
			<source>Exception in info</source>
			<translation>Виняток у info</translation>
		</message>
		<message>
			<source>Exception in info (def _get_id)</source>
			<translation>Виняток в info (def _get_id)</translation>
		</message>
		<message>
			<source>Exception in resync_map_after_db_reconnect: {0}</source>
			<translation>Exception in resync_map_after_db_reconnect: {0}</translation>
		</message>
		<message>
			<source>Exception in unload when {0}</source>
			<translation>Виняток при розвантаженні, коли {0}</translation>
		</message>
		<message>
			<source>Exception in unload when deleting {0}</source>
			<translation>Виняток при розвантаженні під час видалення {0}</translation>
		</message>
		<message>
			<source>Exception in unload when disconnecting {0} signal</source>
			<translation>Виняток при розвантаженні при відключенні сигналу {0}</translation>
		</message>
		<message>
			<source>Exception in unload when reset values for {0}</source>
			<translation>Виняток при розвантаженні при скиданні значень для {0}</translation>
		</message>
		<message>
			<source>Exception in unload when unset signals</source>
			<translation>Виняток При Розвантаженні Коли Сигнали Не Встановлені</translation>
		</message>
		<message>
			<source>Exception message not shown to user</source>
			<translation>Exception message not shown to user</translation>
		</message>
		<message>
			<source>Exception when replacing inp strings</source>
			<translation>Виняток Під Час Заміни Рядків inp</translation>
		</message>
		<message>
			<source>Exception while moving/deleting old user config files</source>
			<translation>Виняток під час переміщення/видалення старих файлів конфігурації користувача</translation>
		</message>
		<message>
			<source>Exec. time: {0}</source>
			<translation>Exec. time: {0}</translation>
		</message>
		<message>
			<source>Execute EPA software</source>
			<translation>Запустити Програмне Забезпечення EPA</translation>
		</message>
		<message>
			<source>Execute EPA software......</source>
			<translation>Execute EPA software......</translation>
		</message>
		<message>
			<source>Execute EPA software......\n\n</source>
			<translation>Execute EPA software......\n\n</translation>
		</message>
		<message>
			<source>Execute failed.</source>
			<translation>Виконання Не Вдалося.</translation>
		</message>
		<message>
			<source>Executing calibration &quot;{0}&quot; ({1}/{2})...</source>
			<translation>Executing calibration &quot;{0}&quot; ({1}/{2})...</translation>
		</message>
		<message>
			<source>Executing vacuum</source>
			<translation>Виконання вакууму</translation>
		</message>
		<message>
			<source>EXECUTION FAILED! Check logs for more information</source>
			<translation>EXECUTION FAILED! Check logs for more information</translation>
		</message>
		<message>
			<source>Execution of {0} failed.</source>
			<translation>Виконання {0} не вдалося.</translation>
		</message>
		<message>
			<source>Export done succesfully</source>
			<translation>Експорт успішно завершено</translation>
		</message>
		<message>
			<source>Export INP file into PostgreSQL</source>
			<translation>Експорт файлу INP до PostgreSQL</translation>
		</message>
		<message>
			<source>Export INP finished. </source>
			<translation>Експорт INP завершено.</translation>
		</message>
		<message>
			<source>Expression Error</source>
			<translation>Помилка виразу</translation>
		</message>
		<message>
			<source>FAIL {0}</source>
			<translation>ПОМИЛКА {0}</translation>
		</message>
		<message>
			<source>Failed to add feature</source>
			<translation>Не вдалося додати елемент</translation>
		</message>
		<message>
			<source>Failed to configure layer &apos;{0}&apos;. Skipping...</source>
			<translation>Не вдалося налаштувати шар &apos;{0}&apos;. Пропускається...</translation>
		</message>
		<message>
			<source>Failed to create child campaign</source>
			<translation>Failed to create child campaign</translation>
		</message>
		<message>
			<source>Failed to create layout from template</source>
			<translation>Failed to create layout from template</translation>
		</message>
		<message>
			<source>Failed to delete multilang rows for removed project types.</source>
			<translation>Failed to delete multilang rows for removed project types.</translation>
		</message>
		<message>
			<source>Failed to delete records from {0}.</source>
			<translation>Не вдалося видалити записи з {0}.</translation>
		</message>
		<message>
			<source>Failed to delete style group</source>
			<translation>Не вдалося видалити групу стилів</translation>
		</message>
		<message>
			<source>Failed to delete styles</source>
			<translation>Не вдалося видалити стилі</translation>
		</message>
		<message>
			<source>Failed to drop database user &apos;{0}&apos;. It may need to be removed manually.</source>
			<translation>Не вдалося видалити користувача бази даних &apos;{0}&apos;. Його може знадобитися видалити вручну.</translation>
		</message>
		<message>
			<source>Failed to execute the mapzones analysis.</source>
			<translation>Не вдалося виконати аналіз mapzones.</translation>
		</message>
		<message>
			<source>Failed to fetch dialog configuration</source>
			<translation>Не вдалося отримати конфігурацію діалогу</translation>
		</message>
		<message>
			<source>Failed to get a valid response from gw_fct_config_mapzones.</source>
			<translation>Не вдалося отримати дійсну відповідь від gw_fct_config_mapzones.</translation>
		</message>
		<message>
			<source>Failed to load campaign form</source>
			<translation>Failed to load campaign form</translation>
		</message>
		<message>
			<source>Failed to load layers</source>
			<translation>Не вдалося завантажити шари</translation>
		</message>
		<message>
			<source>Failed to load layers.</source>
			<translation>Не вдалося завантажити шари.</translation>
		</message>
		<message>
			<source>Failed to load lot form</source>
			<translation>Failed to load lot form</translation>
		</message>
		<message>
			<source>Failed to load profile interpolation dialog.</source>
			<translation>Failed to load profile interpolation dialog.</translation>
		</message>
		<message>
			<source>Failed to load scada graph dialog.</source>
			<translation>Failed to load scada graph dialog.</translation>
		</message>
		<message>
			<source>Failed to load team creation dialog configuration. Please check database configuration.</source>
			<translation>Failed to load team creation dialog configuration. Please check database configuration.</translation>
		</message>
		<message>
			<source>Failed to load workorder form</source>
			<translation>Failed to load workorder form</translation>
		</message>
		<message>
			<source>Failed to parse JSON result from database.</source>
			<translation>Failed to parse JSON result from database.</translation>
		</message>
		<message>
			<source>Failed to retrieve GeoJSON data.</source>
			<translation>Не вдалося отримати дані GeoJSON.</translation>
		</message>
		<message>
			<source>Failed to retrieve sector features.</source>
			<translation>Не вдалося отримати елементи сектора.</translation>
		</message>
		<message>
			<source>Failed to retrieve the temporal layer</source>
			<translation>Не вдалося отримати тимчасовий шар</translation>
		</message>
		<message>
			<source>Failed to save campaign</source>
			<translation>Failed to save campaign</translation>
		</message>
		<message>
			<source>Failed to set {0} scenario</source>
			<translation>Не вдалося встановити сценарій {0}</translation>
		</message>
		<message>
			<source>Failed to set netscenario</source>
			<translation>Не вдалося встановити netscenario</translation>
		</message>
		<message>
			<source>Failed to set psector {0} as current</source>
			<translation>Failed to set psector {0} as current</translation>
		</message>
		<message>
			<source>Failed to set ValueRelation for field &apos;{0}&apos;: {1}</source>
			<translation>Не вдалося встановити ValueRelation для поля &apos;{0}&apos;: {1}</translation>
		</message>
		<message>
			<source>Failed to update category</source>
			<translation>Не вдалося оновити категорію</translation>
		</message>
		<message>
			<source>Failed to update styles</source>
			<translation>Не вдалося оновити стилі</translation>
		</message>
		<message>
			<source>Failed to write export file:\n{0}</source>
			<translation>Failed to write export file:\n{0}</translation>
		</message>
		<message>
			<source>Failing data: {0}</source>
			<translation>Невдалі дані: {0}</translation>
		</message>
		<message>
			<source>Feature added successfully!</source>
			<translation>Елемент успішно додано!</translation>
		</message>
		<message>
			<source>Feature already in the list</source>
			<translation>Елемент вже у списку</translation>
		</message>
		<message>
			<source>Feature class not found: {0}</source>
			<translation>Feature class not found: {0}</translation>
		</message>
		<message>
			<source>Feature has not been updated because no catalog has been selected</source>
			<translation>Елемент не було оновлено, оскільки не вибрано жодного каталогу</translation>
		</message>
		<message>
			<source>Feature ID and Idval cannot be empty.</source>
			<translation>ID елемента та Idval не можуть бути порожніми.</translation>
		</message>
		<message>
			<source>Feature_id is mandatory.</source>
			<translation>Feature_id є обов&apos;язковим.</translation>
		</message>
		<message>
			<source>Feature not upserted</source>
			<translation>Feature not upserted</translation>
		</message>
		<message>
			<source>Feature replaced successfully</source>
			<translation>Елемент успішно замінено</translation>
		</message>
		<message>
			<source>Feature upserted</source>
			<translation>Feature upserted</translation>
		</message>
		<message>
			<source>Field catalog_id required!</source>
			<translation>Поле catalog_id є обов&apos;язковим!</translation>
		</message>
		<message>
			<source>Field child_layer of id: </source>
			<translation>Поле child_layer з id:  }</translation>
		</message>
		<message>
			<source>Field child_layer of id: {0} is not defined in table cat_feature</source>
			<translation>Field child_layer of id: {0} is not defined in table cat_feature</translation>
		</message>
		<message>
			<source>Field configured in &apos;config_form_fields&apos;</source>
			<translation>Field configured in &apos;config_form_fields&apos;</translation>
		</message>
		<message>
			<source>Field update in &apos;config_form_fields&apos;</source>
			<translation>Field update in &apos;config_form_fields&apos;</translation>
		</message>
		<message>
			<source>File cannot be created. Check if it is already opened</source>
			<translation>Файл не може бути створений. Перевірте, чи він уже відкритий</translation>
		</message>
		<message>
			<source>File extension not valid</source>
			<translation>Розширення файлу недійсне</translation>
		</message>
		<message>
			<source>File INP not found</source>
			<translation>Файл INP не знайдено</translation>
		</message>
		<message>
			<source>File name</source>
			<translation>Ім&apos;я файлу</translation>
		</message>
		<message>
			<source>File name is required</source>
			<translation>Потрібна назва файлу</translation>
		</message>
		<message>
			<source>File not found</source>
			<translation>Файл не знайдено</translation>
		</message>
		<message>
			<source>File not found: {0}</source>
			<translation>Файл не знайдено: {0}</translation>
		</message>
		<message>
			<source>File path doesn&apos;t exist or you dont have permission or file is opened</source>
			<translation>Шлях до файлу не існує, або у вас немає дозволу, або файл відкритий</translation>
		</message>
		<message>
			<source>File path not found</source>
			<translation>Шлях до файлу не знайдено</translation>
		</message>
		<message>
			<source>File RPT not found</source>
			<translation>Файл RPT не знайдено</translation>
		</message>
		<message>
			<source>Files defined in environment variables &apos;{0}&apos; and &apos;{1}&apos; not found.</source>
			<translation>Files defined in environment variables &apos;{0}&apos; and &apos;{1}&apos; not found.</translation>
		</message>
		<message>
			<source>Fill table</source>
			<translation>Fill table</translation>
		</message>
		<message>
			<source>Filter</source>
			<translation>Filter</translation>
		</message>
		<message>
			<source>Filter by code</source>
			<translation>Фільтрувати за кодом</translation>
		</message>
		<message>
			<source>Filter by ext_code</source>
			<translation>Фільтрувати за ext_code</translation>
		</message>
		<message>
			<source>Finished!</source>
			<translation>Finished!</translation>
		</message>
		<message>
			<source>First node already selected with id: {0}. Select second one.</source>
			<translation>Перший вузол вже вибрано з id: {0}. Виберіть другий.</translation>
		</message>
		<message>
			<source>Flood analysis will start from arc ID</source>
			<translation>Flood analysis will start from arc ID</translation>
		</message>
		<message>
			<source>Flood analysis will start from node ID</source>
			<translation>Аналіз повені розпочнеться з вузла з ID</translation>
		</message>
		<message>
			<source>Flow regulators</source>
			<translation>Flow regulators</translation>
		</message>
		<message>
			<source>Folder not found</source>
			<translation>Папку не знайдено</translation>
		</message>
		<message>
			<source>Folder path</source>
			<translation>Шлях До Папки</translation>
		</message>
		<message>
			<source>Force commit</source>
			<translation>Примусове Підтвердження</translation>
		</message>
		<message>
			<source>For mode &apos;{0}&apos;, an result_id must be informed.</source>
			<translation>For mode &apos;{0}&apos;, an result_id must be informed.</translation>
		</message>
		<message>
			<source>For select on canvas is mandatory to load v_asset_arc_input layer</source>
			<translation>For select on canvas is mandatory to load v_asset_arc_input layer</translation>
		</message>
		<message>
			<source>From {0}, updating {1}...</source>
			<translation>З {0}, оновлюється {1}...</translation>
		</message>
		<message>
			<source>Function {0} error: {1} from last function is invalid</source>
			<translation>Помилка функції {0}: {1} з попередньої функції недійсний</translation>
		</message>
		<message>
			<source>Function {0} error: {1} returned null</source>
			<translation>Функція {0} помилка: {1} повернула null</translation>
		</message>
		<message>
			<source>Function {0} error: missing key {1}</source>
			<translation>Функція {0} помилка: відсутній ключ {1}</translation>
		</message>
		<message>
			<source>Function {0} failed</source>
			<translation>Функція {0} не вдалася</translation>
		</message>
		<message>
			<source>Function {0} finished successfully</source>
			<translation>Функція {0} успішно завершилася</translation>
		</message>
		<message>
			<source>Function {0} returned {1}</source>
			<translation>Функція {0} повернула {1}</translation>
		</message>
		<message>
			<source>Function error: {0}</source>
			<translation>Помилка функції: {0}</translation>
		</message>
		<message>
			<source>Function error: gw_fct_setmincut</source>
			<translation>Function error: gw_fct_setmincut</translation>
		</message>
		<message>
			<source>Function failed finished</source>
			<translation>Функція завершилася з помилкою</translation>
		</message>
		<message>
			<source>Function gw_fct_create_dscenario_empty returned no dscenario_id</source>
			<translation>Функція gw_fct_create_dscenario_empty не повернула dscenario_id</translation>
		</message>
		<message>
			<source>Function gw_fct_psector_duplicate executed with no result</source>
			<translation>Function gw_fct_psector_duplicate executed with no result</translation>
		</message>
		<message>
			<source>Function gw_fct_setfeaturedelete executed with no result </source>
			<translation>Функція gw_fct_setfeaturedelete виконана без результату</translation>
		</message>
		<message>
			<source>Function name</source>
			<translation>Назва Функції</translation>
		</message>
		<message>
			<source>Function not found</source>
			<translation>Функцію не знайдено</translation>
		</message>
		<message>
			<source>Function not found in database</source>
			<translation>Функцію не знайдено в базі даних</translation>
		</message>
		<message>
			<source>Function not found in database: {0}</source>
			<translation>Функцію не знайдено в базі даних: {0}</translation>
		</message>
		<message>
			<source>Generate INP algorithm</source>
			<translation>Generate INP algorithm</translation>
		</message>
		<message>
			<source>Generating markdown for {0}.</source>
			<translation>Генерація markdown для {0}.</translation>
		</message>
		<message>
			<source>Generating markdown from {0}...</source>
			<translation>Генерація markdown з {0}...</translation>
		</message>
		<message>
			<source>Generating result stats</source>
			<translation>Generating result stats</translation>
		</message>
		<message>
			<source>Generation of atlas uses ve_plan_psector as coverage layer ordered by atlas_id column. Please update the atlas&apos; coverage layer before continuing.</source>
			<translation>Генерація атласу використовує ve_plan_psector як шар покриття, впорядкований за стовпцем atlas_id. Оновіть шар покриття атласу перед продовженням.</translation>
		</message>
		<message>
			<source>Geometry has been added!</source>
			<translation>Геометрію додано!</translation>
		</message>
		<message>
			<source>Geometry set correctly.</source>
			<translation>Геометрія встановлена правильно.</translation>
		</message>
		<message>
			<source>Geometry type ({0}) not found in layer: {1}</source>
			<translation>Geometry type ({0}) not found in layer: {1}</translation>
		</message>
		<message>
			<source>Getting {0} from .{1} file</source>
			<translation>Getting {0} from .{1} file</translation>
		</message>
		<message>
			<source>Getting auxiliary data from DB</source>
			<translation>Getting auxiliary data from DB</translation>
		</message>
		<message>
			<source>Getting options</source>
			<translation>Getting options</translation>
		</message>
		<message>
			<source>Getting pipe data from DB</source>
			<translation>Getting pipe data from DB</translation>
		</message>
		<message>
			<source>Getting units...</source>
			<translation>Getting units...</translation>
		</message>
		<message>
			<source>GIS file generated successfully</source>
			<translation>Файл GIS згенеровано успішно</translation>
		</message>
		<message>
			<source>GIS file name not set</source>
			<translation>Ім&apos;я файлу GIS не встановлено</translation>
		</message>
		<message>
			<source>GIS folder not set</source>
			<translation>Папка GIS не встановлена</translation>
		</message>
		<message>
			<source>Giswater ({0})</source>
			<translation>Giswater ({0})</translation>
		</message>
		<message>
			<source>Giswater plugin cannot be loaded</source>
			<translation>Плагін Giswater не може бути завантажений</translation>
		</message>
		<message>
			<source>GitHub Issues</source>
			<translation>GitHub Issues</translation>
		</message>
		<message>
			<source>Go2Epa</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>Go2Epa task is already active!</source>
			<translation>Завдання Go2Epa вже активне!</translation>
		</message>
		<message>
			<source>GO2EPA - Work in progress</source>
			<translation>GO2EPA - Work in progress</translation>
		</message>
		<message>
			<source>Go2Iber task is already active!</source>
			<translation>Задача Go2Iber вже активна!</translation>
		</message>
		<message>
			<source>GO2IBER - Work in progress</source>
			<translation>GO2IBER - Work in progress</translation>
		</message>
		<message>
			<source>Group &apos;{0}&apos; not found in layer tree.</source>
			<translation>Group &apos;{0}&apos; not found in layer tree.</translation>
		</message>
		<message>
			<source>gw_fct_set_rpt_archived execution failed. See logs for more details...</source>
			<translation>виконання gw_fct_set_rpt_archived не вдалося. Див. журнали для деталей...</translation>
		</message>
		<message>
			<source>Hemisphere of the node has been updated. Value is</source>
			<translation>Півсфера вузла оновлено. Значення:</translation>
		</message>
		<message>
			<source>Here you can choose how the pumps and valves will be imported, either left as arcs (virual arcs) or converted to nodes.</source>
			<translation>Тут ви можете обрати, як імпортуються насоси та клапани: залишити їх як дуги (віртуальні дуги) або конвертувати в вузли.</translation>
		</message>
		<message>
			<source>Here you can choose how the pumps, weirs, orifices, and outlets will be imported, either left as arcs (virual arcs) or converted to flwreg.</source>
			<translation>Тут ви можете обрати, як імпортуються насоси, переливи, оріфіси та випуски: залишити як дуги (віртуальні дуги) або конвертувати в flwreg.</translation>
		</message>
		<message>
			<source>Highlighting large dataset ({0} features) - this may take a moment...</source>
			<translation>Highlighting large dataset ({0} features) - this may take a moment...</translation>
		</message>
		<message>
			<source>Hydraulic engine imported successfully</source>
			<translation>Hydraulic engine imported successfully</translation>
		</message>
		<message>
			<source>Hydraulic engine not imported. Using default EPA software.</source>
			<translation>Hydraulic engine not imported. Using default EPA software.</translation>
		</message>
		<message>
			<source>Hydrology scenario manager</source>
			<translation>Hydrology scenario менеджер</translation>
		</message>
		<message>
			<source>Hydrometer management</source>
			<translation>Hydrometer management</translation>
		</message>
		<message>
			<source>IBERGIS plugin not found</source>
			<translation>Плагін IBERGIS не знайдено</translation>
		</message>
		<message>
			<source>IBERGIS project imported successfully</source>
			<translation>Проєкт IBERGIS успішно імпортовано</translation>
		</message>
		<message>
			<source>Id already selected</source>
			<translation>Id вже вибрано</translation>
		</message>
		<message>
			<source>If not, you can ignore the tab.</source>
			<translation>Якщо ні, ви можете ігнорувати вкладку.</translation>
		</message>
		<message>
			<source>If you chose to import the flow regulators as flwreg objects, the sixth tab is where you can select the catalog for each flow regulator (pumps, weirs, orifices, outlets) on the network.</source>
			<translation>Якщо ви обрали імпорт регуляторів потоку як об&apos;єкти flwreg, на шостій вкладці ви можете вибрати каталог для кожного регулятора потоку (насоси, переливи, оріфіси, випуски) в мережі.</translation>
		</message>
		<message>
			<source>If you have any questions, please contact the Giswater team via</source>
			<translation>Якщо у вас є питання, будь ласка, зверніться до команди Giswater через</translation>
		</message>
		<message>
			<source>imported</source>
			<translation>imported</translation>
		</message>
		<message>
			<source>Importing conduits</source>
			<translation>Importing conduits</translation>
		</message>
		<message>
			<source>Importing controls</source>
			<translation>Importing controls</translation>
		</message>
		<message>
			<source>Importing controls and rules...</source>
			<translation>Importing controls and rules...</translation>
		</message>
		<message>
			<source>Importing curves</source>
			<translation>Importing curves</translation>
		</message>
		<message>
			<source>Importing curves...</source>
			<translation>Importing curves...</translation>
		</message>
		<message>
			<source>Importing dividers</source>
			<translation>Importing dividers</translation>
		</message>
		<message>
			<source>Importing DWF</source>
			<translation>Importing DWF</translation>
		</message>
		<message>
			<source>Importing files...</source>
			<translation>Importing files...</translation>
		</message>
		<message>
			<source>Importing inflows</source>
			<translation>Importing inflows</translation>
		</message>
		<message>
			<source>Importing junctions</source>
			<translation>Importing junctions</translation>
		</message>
		<message>
			<source>Importing junctions...</source>
			<translation>Importing junctions...</translation>
		</message>
		<message>
			<source>Importing LIDs</source>
			<translation>Importing LIDs</translation>
		</message>
		<message>
			<source>Importing options...</source>
			<translation>Importing options...</translation>
		</message>
		<message>
			<source>Importing orifices</source>
			<translation>Importing orifices</translation>
		</message>
		<message>
			<source>Importing outfalls</source>
			<translation>Importing outfalls</translation>
		</message>
		<message>
			<source>Importing outlets</source>
			<translation>Importing outlets</translation>
		</message>
		<message>
			<source>Importing patterns</source>
			<translation>Importing patterns</translation>
		</message>
		<message>
			<source>Importing patterns...</source>
			<translation>Importing patterns...</translation>
		</message>
		<message>
			<source>Importing pipes...</source>
			<translation>Importing pipes...</translation>
		</message>
		<message>
			<source>Importing pumps</source>
			<translation>Importing pumps</translation>
		</message>
		<message>
			<source>Importing pumps...</source>
			<translation>Importing pumps...</translation>
		</message>
		<message>
			<source>Importing raingages</source>
			<translation>Importing raingages</translation>
		</message>
		<message>
			<source>Importing reservoirs...</source>
			<translation>Importing reservoirs...</translation>
		</message>
		<message>
			<source>Importing sources...</source>
			<translation>Importing sources...</translation>
		</message>
		<message>
			<source>Importing storage units</source>
			<translation>Importing storage units</translation>
		</message>
		<message>
			<source>Importing subcatchments</source>
			<translation>Importing subcatchments</translation>
		</message>
		<message>
			<source>Importing tanks...</source>
			<translation>Importing tanks...</translation>
		</message>
		<message>
			<source>Importing timeseries</source>
			<translation>Importing timeseries</translation>
		</message>
		<message>
			<source>Importing title...</source>
			<translation>Importing title...</translation>
		</message>
		<message>
			<source>Importing valves...</source>
			<translation>Importing valves...</translation>
		</message>
		<message>
			<source>Importing weirs</source>
			<translation>Importing weirs</translation>
		</message>
		<message>
			<source>Import INP</source>
			<translation>Import INP</translation>
		</message>
		<message>
			<source>IMPORT INP</source>
			<translation>ІМПОРТ INP</translation>
		</message>
		<message>
			<source>Import INP is only available on Python 3.10 or higher. Please update your QGIS&apos;s Python version.</source>
			<translation>Імпорт INP доступний лише на Python 3.10 або новішому. Будь ласка, оновіть версію Python у QGIS.</translation>
		</message>
		<message>
			<source>Import INP is still in developement. It may not work as intended yet. Please report any unexpected behaviour to the Giswater team.</source>
			<translation>Імпорт INP все ще в розробці. Він може працювати не так, як очікується. Будь ласка, повідомте про будь-яку непередбачувану поведінку команді Giswater.</translation>
		</message>
		<message>
			<source>Import INP (TESTING MODE)</source>
			<translation>Import INP (TESTING MODE)</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis is only available on Python 3.10 or higher. Please update your QGIS&apos;s Python version.</source>
			<translation>Import OSM Streetaxis is only available on Python 3.10 or higher. Please update your QGIS&apos;s Python version.</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis its only for WS projects</source>
			<translation>Імпорт OSM Streetaxis призначений лише для проєктів WS</translation>
		</message>
		<message>
			<source>Import results requires Execute EPA software</source>
			<translation>Import results requires Execute EPA software</translation>
		</message>
		<message>
			<source>Import RPT file</source>
			<translation>Імпортувати RPT файл</translation>
		</message>
		<message>
			<source>Import rpt file........: {0}</source>
			<translation>Імпорт файлу rpt........: {0}</translation>
		</message>
		<message>
			<source>Import RPT file finished.</source>
			<translation>Імпорт файлу RPT завершено.</translation>
		</message>
		<message>
			<source>Import RPT file finished. </source>
			<translation>Import RPT file finished.</translation>
		</message>
		<message>
			<source>Import simulation results........: {0}</source>
			<translation>Import simulation results........: {0}</translation>
		</message>
		<message>
			<source>Import simulation results finished</source>
			<translation>Import simulation results finished</translation>
		</message>
		<message>
			<source>Import simulation results into database</source>
			<translation>Import simulation results into database</translation>
		</message>
		<message>
			<source>Incompatible version of PostgreSQL</source>
			<translation>Несумісна версія PostgreSQL</translation>
		</message>
		<message>
			<source>Incorrect languages, make sure to have the giswater project in english</source>
			<translation>Неправильні мови, переконайтеся, що проєкт giswater англійською</translation>
		</message>
		<message>
			<source>Incorrect option ({0}) for scenario {1}.</source>
			<translation>Incorrect option ({0}) for scenario {1}.</translation>
		</message>
		<message>
			<source>Incorrect user or password</source>
			<translation>Неправильний користувач або пароль</translation>
		</message>
		<message>
			<source>Incorrect valve status ({0}) for arc {1}.</source>
			<translation>Incorrect valve status ({0}) for arc {1}.</translation>
		</message>
		<message>
			<source>Incorrect valve status ({0}) for scenario {1}.</source>
			<translation>Incorrect valve status ({0}) for scenario {1}.</translation>
		</message>
		<message>
			<source>Info</source>
			<translation>Інфо</translation>
		</message>
		<message>
			<source>Info Message</source>
			<translation>Інформаційне повідомлення</translation>
		</message>
		<message>
			<source>Information about exception</source>
			<translation>Інформація про виняток</translation>
		</message>
		<message>
			<source>Initialize plugin</source>
			<translation>Ініціалізувати плагін</translation>
		</message>
		<message>
			<source>In order to create a qgis project you have to create a schema first.</source>
			<translation>щоб створити qgis-проєкт, спочатку потрібно створити схему.</translation>
		</message>
		<message>
			<source>INP file couldn&apos;t be imported:\n{0}</source>
			<translation>INP file couldn&apos;t be imported:\n{0}</translation>
		</message>
		<message>
			<source>INP file not found</source>
			<translation>Файл INP не знайдено</translation>
		</message>
		<message>
			<source>Inp Options</source>
			<translation>Inp Параметри</translation>
		</message>
		<message>
			<source>In schema</source>
			<translation>У схемі</translation>
		</message>
		<message>
			<source>Integrate am</source>
			<translation>Integrate am</translation>
		</message>
		<message>
			<source>Integrate utils requires a WS or UD anchor.</source>
			<translation>Integrate utils requires a WS or UD anchor.</translation>
		</message>
		<message>
			<source>Interpolate tool.\nTo modify columns (top_elev, ymax, elev among others) to be interpolated set variable edit_node_interpolate on table config_param_user</source>
			<translation>Interpolate tool.\nTo modify columns (top_elev, ymax, elev among others) to be interpolated set variable edit_node_interpolate on table config_param_user</translation>
		</message>
		<message>
			<source>Invalid {0} &apos;{1}&apos; provided. No configuration performed.</source>
			<translation>Неприпустимий {0} &apos;{1}&apos; надано. Налаштування не виконано.</translation>
		</message>
		<message>
			<source>Invalid arccat_ids: {0}.</source>
			<translation>Неприпустимі arccat_ids: {0}.</translation>
		</message>
		<message>
			<source>Invalid buffer value. Please enter an integer less than 1000.</source>
			<translation>Неприпустиме значення буфера. Будь ласка, введіть ціле число менше 1000.</translation>
		</message>
		<message>
			<source>Invalid buffer value. Please enter an valid integer.</source>
			<translation>Неприпустиме значення буфера. Будь ласка, введіть дійсне ціле число.</translation>
		</message>
		<message>
			<source>Invalid campaign ID</source>
			<translation>Invalid campaign ID</translation>
		</message>
		<message>
			<source>Invalid campaign mode: {0}</source>
			<translation>Invalid campaign mode: {0}</translation>
		</message>
		<message>
			<source>Invalid diameters: {1}.</source>
			<translation>Недійсні діаметри: {1}.</translation>
		</message>
		<message>
			<source>Invalid layer:\nprovider={0}\nuri={1}</source>
			<translation>Invalid layer:\nprovider={0}\nuri={1}</translation>
		</message>
		<message>
			<source>Invalid lot ID</source>
			<translation>Invalid lot ID</translation>
		</message>
		<message>
			<source>Invalid materials: {3}.</source>
			<translation>Недійсні матеріали: {3}.</translation>
		</message>
		<message>
			<source>Invalid tuple: {0}</source>
			<translation>Invalid tuple: {0}</translation>
		</message>
		<message>
			<source>Invalid value for field</source>
			<translation>Неприпустиме значення для поля</translation>
		</message>
		<message>
			<source>Invalid value for scenario_results in [OPTIONS] section.</source>
			<translation>Недійсне значення для scenario_results в секції [OPTIONS].</translation>
		</message>
		<message>
			<source>Invalid value for type of priority dialog. Please pass either &apos;GLOBAL&apos; or &apos;SELECTION&apos;. Value passed: {0}</source>
			<translation>Invalid value for type of priority dialog. Please pass either &apos;GLOBAL&apos; or &apos;SELECTION&apos;. Value passed: {0}</translation>
		</message>
		<message>
			<source>Invalid WKT string</source>
			<translation>Недійсний рядок WKT</translation>
		</message>
		<message>
			<source>Invalid workorder ID</source>
			<translation>Invalid workorder ID</translation>
		</message>
		<message>
			<source>Invert the current selection in the table</source>
			<translation>Invert the current selection in the table</translation>
		</message>
		<message>
			<source>is not defined in table cat_feature</source>
			<translation>не визначено в таблиці cat_feature</translation>
		</message>
		<message>
			<source>It will then show the log of the process in the last tab.</source>
			<translation>Потім буде показано журнал процесу в останній вкладці.</translation>
		</message>
		<message>
			<source>Junctions couldn&apos;t be inserted!</source>
			<translation>Junctions couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>KEEP OPERATIVE</source>
			<translation>KEEP OPERATIVE</translation>
		</message>
		<message>
			<source>Key</source>
			<translation>Ключ</translation>
		</message>
		<message>
			<source>Key ({0}) is not unique in the config catalog.</source>
			<translation>Key ({0}) is not unique in the config catalog.</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE columname=&apos;{0}&apos; AND widgetname=&apos;{1}&apos;</source>
			<translation>ключ &apos;comboIds&apos; або/та comboNames не знайдено WHERE columname=&apos;{0}&apos; AND widgetname=&apos;{1}&apos;</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE widgetname=&apos;{0}&apos; AND widgettype=&apos;{1}&apos;</source>
			<translation>ключ &apos;comboIds&apos; or/and comboNames not found WHERE widgetname=&apos;{0}&apos; AND widgettype=&apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Key container</source>
			<translation>Контейнер ключів</translation>
		</message>
		<message>
			<source>Key not found</source>
			<translation>Key not found</translation>
		</message>
		<message>
			<source>Key on returned json from ddbb is missed</source>
			<translation>Ключ у поверненому json від ddbb відсутній</translation>
		</message>
		<message>
			<source>Key on returned json from ddbb is missed.</source>
			<translation>Ключ у поверненому json з ddbb відсутній.</translation>
		</message>
		<message>
			<source>Language</source>
			<translation>Мова</translation>
		</message>
		<message>
			<source>Language: {0}</source>
			<translation>Language: {0}</translation>
		</message>
		<message>
			<source>Language ({0}) is in use and cannot be deleted. Used by: {1}</source>
			<translation>Language ({0}) is in use and cannot be deleted. Used by: {1}</translation>
		</message>
		<message>
			<source>Language files</source>
			<translation>Language files</translation>
		</message>
		<message>
			<source>Language files deleted and locale deactivated ({0}).</source>
			<translation>Language files deleted and locale deactivated ({0}).</translation>
		</message>
		<message>
			<source>Language files downloaded and locale activated ({0}).</source>
			<translation>Language files downloaded and locale activated ({0}).</translation>
		</message>
		<message>
			<source>Language files updated and locale activated ({0}).</source>
			<translation>Language files updated and locale activated ({0}).</translation>
		</message>
		<message>
			<source>Language provision pre-check failed: {0}</source>
			<translation>Language provision pre-check failed: {0}</translation>
		</message>
		<message>
			<source>Layer {0} does not found, therefore, not configured</source>
			<translation>Шар {0} не знайдено, отже не налаштований</translation>
		</message>
		<message>
			<source>Layer &apos;{0}&apos; is None and settings is None</source>
			<translation>Layer &apos;{0}&apos; is None and settings is None</translation>
		</message>
		<message>
			<source>Layer &apos;{0}&apos; not found in QGIS.</source>
			<translation>Шар &apos;{0}&apos; не знайдено в QGIS.</translation>
		</message>
		<message>
			<source>Layer failed to load!</source>
			<translation>Layer failed to load!</translation>
		</message>
		<message>
			<source>Layer is broken</source>
			<translation>Layer is broken</translation>
		</message>
		<message>
			<source>Layer not found</source>
			<translation>Шар не знайдено</translation>
		</message>
		<message>
			<source>Layer of CM project will be added to the project when create</source>
			<translation>Layer of CM project will be added to the project when create</translation>
		</message>
		<message>
			<source>Layout not found</source>
			<translation>Макет не знайдено</translation>
		</message>
		<message>
			<source>layoutorder not found.</source>
			<translation>layoutorder не знайдено.</translation>
		</message>
		<message>
			<source>LIDS</source>
			<translation>LIDS</translation>
		</message>
		<message>
			<source>Line number</source>
			<translation>Номер рядка</translation>
		</message>
		<message>
			<source>Locale not found</source>
			<translation>Locale not found</translation>
		</message>
		<message>
			<source>Log file</source>
			<translation>Log file</translation>
		</message>
		<message>
			<source>Lot ID not found.</source>
			<translation>Lot ID not found.</translation>
		</message>
		<message>
			<source>Manage languages</source>
			<translation>Manage languages</translation>
		</message>
		<message>
			<source>Managing nodarcs (pumps/valves as nodes)...</source>
			<translation>Managing nodarcs (pumps/valves as nodes)...</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please, set a value</source>
			<translation>Обов&apos;язкове поле відсутнє. Будь ласка, задайте значення</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please, set a value for field</source>
			<translation>Обов&apos;язкове поле відсутнє. Будь ласка, задайте значення для поля</translation>
		</message>
		<message>
			<source>Map item &apos;Mapa&apos; not found in template. Template may be empty or use different item IDs.</source>
			<translation>Map item &apos;Mapa&apos; not found in template. Template may be empty or use different item IDs.</translation>
		</message>
		<message>
			<source>Mapzone config - {0}</source>
			<translation>Mapzone config - {0}</translation>
		</message>
		<message>
			<source>Mapzone config - {0} (Netscenario {1})</source>
			<translation>Mapzone config - {0} (Netscenario {1})</translation>
		</message>
		<message>
			<source>Mapzone dynamic widgets not found: {0}</source>
			<translation>Mapzone dynamic widgets not found: {0}</translation>
		</message>
		<message>
			<source>Mapzone manager dynamic config not found.</source>
			<translation>Mapzone manager dynamic config not found.</translation>
		</message>
		<message>
			<source>Mapzone manager tabs not configured in DB.</source>
			<translation>Mapzone manager tabs not configured in DB.</translation>
		</message>
		<message>
			<source>Mapzones analysis completed successfully.</source>
			<translation>Аналіз Mapzones завершено успішно.</translation>
		</message>
		<message>
			<source>Markdown Generated from {0}.</source>
			<translation>Markdown згенеровано з {0}.</translation>
		</message>
		<message>
			<source>Marked values must be greater than 0</source>
			<translation>Позначені значення повинні бути більшими за 0</translation>
		</message>
		<message>
			<source>Merge</source>
			<translation>Merge</translation>
		</message>
		<message>
			<source>Merge requires at least 2 psectors to be selected</source>
			<translation>Merge вимагає, щоб було вибрано принаймні 2 psectors</translation>
		</message>
		<message>
			<source>Message</source>
			<translation>Повідомлення</translation>
		</message>
		<message>
			<source>Message error</source>
			<translation>Помилка Повідомлення</translation>
		</message>
		<message>
			<source>Mincut canceled!</source>
			<translation>Mincut canceled!</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict and overlaps with</source>
			<translation>Mincut виконано, але є конфлікт та перекриття з</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict and overlaps with other mincuts</source>
			<translation>Mincut виконано, але є конфлікт і перекривається з іншими mincuts</translation>
		</message>
		<message>
			<source>Mincut done successfully</source>
			<translation>Mincut виконано успішно</translation>
		</message>
		<message>
			<source>Mincut execute</source>
			<translation>Mincut execute</translation>
		</message>
		<message>
			<source>Mincut task is already active!</source>
			<translation>Завдання Mincut вже активне!</translation>
		</message>
		<message>
			<source>...min_message_level</source>
			<translation>...min_message_level</translation>
		</message>
		<message>
			<source>Missing Data</source>
			<translation>Missing Data</translation>
		</message>
		<message>
			<source>Missing required fields</source>
			<translation>Відсутні обов&apos;язкові поля</translation>
		</message>
		<message>
			<source>More than one event selected. Select just one</source>
			<translation>More than one event selected. Select just one</translation>
		</message>
		<message>
			<source>More then one document selected. Select just one document.</source>
			<translation>More then one document selected. Select just one document.</translation>
		</message>
		<message>
			<source>Move node: Error updating geometry</source>
			<translation>Перемістити вузол: Помилка оновлення геометрії</translation>
		</message>
		<message>
			<source>Multilang function failed</source>
			<translation>Multilang function failed</translation>
		</message>
		<message>
			<source>Multilang function failed.</source>
			<translation>Multilang function failed.</translation>
		</message>
		<message>
			<source>Multilang function failed. SQL: {0}</source>
			<translation>Multilang function failed. SQL: {0}</translation>
		</message>
		<message>
			<source>Multilang function response</source>
			<translation>Multilang function response</translation>
		</message>
		<message>
			<source>Multilang function returned an invalid JSON response.</source>
			<translation>Multilang function returned an invalid JSON response.</translation>
		</message>
		<message>
			<source>Multilang function returned unexpected status</source>
			<translation>Multilang function returned unexpected status</translation>
		</message>
		<message>
			<source>Multilang function SQL failed</source>
			<translation>Multilang function SQL failed</translation>
		</message>
		<message>
			<source>Multilang language currently used: {0}.</source>
			<translation>Multilang language currently used: {0}.</translation>
		</message>
		<message>
			<source>Multilang language delete completed for {0}.</source>
			<translation>Multilang language delete completed for {0}.</translation>
		</message>
		<message>
			<source>Multilang on_done callback raised: {0}</source>
			<translation>Multilang on_done callback raised: {0}</translation>
		</message>
		<message>
			<source>Multilang SchemaBuilder exception: {0}</source>
			<translation>Multilang SchemaBuilder exception: {0}</translation>
		</message>
		<message>
			<source>Multilang schema build failed: {0}</source>
			<translation>Multilang schema build failed: {0}</translation>
		</message>
		<message>
			<source>Multilang schema is not available on this connection.</source>
			<translation>Multilang schema is not available on this connection.</translation>
		</message>
		<message>
			<source>Multilang schema task failed during baseline seed.</source>
			<translation>Multilang schema task failed during baseline seed.</translation>
		</message>
		<message>
			<source>Multilang seed failed for project_type {0}: {1}</source>
			<translation>Multilang seed failed for project_type {0}: {1}</translation>
		</message>
		<message>
			<source>Multilang seed: no baseline SQL for project_type={0} (lang={1}); skipping.</source>
			<translation>Multilang seed: no baseline SQL for project_type={0} (lang={1}); skipping.</translation>
		</message>
		<message>
			<source>Multilang seed: no project types with bundled baselines detected; only cat_language ensured for {0}.</source>
			<translation>Multilang seed: no project types with bundled baselines detected; only cat_language ensured for {0}.</translation>
		</message>
		<message>
			<source>Multilang seed: no project types with bundled baselines detected; skipping import.</source>
			<translation>Multilang seed: no project types with bundled baselines detected; skipping import.</translation>
		</message>
		<message>
			<source>Multilang translations deleted and locale deactivated ({0}).</source>
			<translation>Multilang translations deleted and locale deactivated ({0}).</translation>
		</message>
		<message>
			<source>Multilang translations seeded and locale activated ({0}).</source>
			<translation>Multilang translations seeded and locale activated ({0}).</translation>
		</message>
		<message>
			<source>Multilang translations updated ({0}).</source>
			<translation>Multilang translations updated ({0}).</translation>
		</message>
		<message>
			<source>Multilang user parameter provisioning</source>
			<translation>Multilang user parameter provisioning</translation>
		</message>
		<message>
			<source>Multilang user parameter rollback failed.</source>
			<translation>Multilang user parameter rollback failed.</translation>
		</message>
		<message>
			<source>Multilang views provisioning</source>
			<translation>Multilang views provisioning</translation>
		</message>
		<message>
			<source>Multilang views rollback failed.</source>
			<translation>Multilang views rollback failed.</translation>
		</message>
		<message>
			<source>Multiple psectors selected. Please select only one.</source>
			<translation>Вибрано кілька psectors. Будь ласка, виберіть лише один.</translation>
		</message>
		<message>
			<source>Municipality</source>
			<translation>Municipality</translation>
		</message>
		<message>
			<source>Municipality with ID: {0} deleted from selection</source>
			<translation>Муніципалітет з ID: {0} видалено з вибору</translation>
		</message>
		<message>
			<source>Municipality with id[{0}] is already imported on om_streetaxis.\n\rDo you want to overwrite it?\n\r(This decision will not cancel the other selections, the process will keep running)</source>
			<translation>Municipality with id[{0}] is already imported on om_streetaxis.\n\rDo you want to overwrite it?\n\r(This decision will not cancel the other selections, the process will keep running)</translation>
		</message>
		<message>
			<source>\n</source>
			<translation>\n</translation>
		</message>
		<message>
			<source>New {0}</source>
			<translation>New {0}</translation>
		</message>
		<message>
			<source>New feature type is null. Please, select a valid value</source>
			<translation>Новий тип елемента дорівнює null. Будь ласка, виберіть дійсне значення</translation>
		</message>
		<message>
			<source>New feature type is null. Please, select a valid value.</source>
			<translation>Новий тип елементу порожній. Будь ласка, виберіть допустиме значення.</translation>
		</message>
		<message>
			<source>Next</source>
			<translation>Далі</translation>
		</message>
		<message>
			<source>n must be at least one</source>
			<translation>n must be at least one</translation>
		</message>
		<message>
			<source>\n\nALL DONE! INP successfully imported.</source>
			<translation>\n\nALL DONE! INP successfully imported.</translation>
		</message>
		<message>
			<source>No action found</source>
			<translation>Дія не знайдена</translation>
		</message>
		<message>
			<source>No active locales configured</source>
			<translation>No active locales configured</translation>
		</message>
		<message>
			<source>No arc ID found at the snapped location.</source>
			<translation>No arc ID found at the snapped location.</translation>
		</message>
		<message>
			<source>No campaign selected</source>
			<translation>No campaign selected</translation>
		</message>
		<message>
			<source>No changes to save.</source>
			<translation>No changes to save.</translation>
		</message>
		<message>
			<source>No composers found.</source>
			<translation>Не знайдено композиторів.</translation>
		</message>
		<message>
			<source>No current psector selected</source>
			<translation>Поточний psector не вибрано</translation>
		</message>
		<message>
			<source>Nodarcs</source>
			<translation>Nodarcs</translation>
		</message>
		<message>
			<source>No database connection available for hydraulic engine export</source>
			<translation>No database connection available for hydraulic engine export</translation>
		</message>
		<message>
			<source>Node {0} duplicated in config file.</source>
			<translation>Node {0} duplicated in config file.</translation>
		</message>
		<message>
			<source>node1 and node2 are required for profile interpolation.</source>
			<translation>node1 and node2 are required for profile interpolation.</translation>
		</message>
		<message>
			<source>Node 1 selected</source>
			<translation>Вузол 1 вибрано</translation>
		</message>
		<message>
			<source>Node 2 selected</source>
			<translation>Node 2 selected</translation>
		</message>
		<message>
			<source>Node already selected</source>
			<translation>Node already selected</translation>
		</message>
		<message>
			<source>Node id:</source>
			<translation>Вузол id:</translation>
		</message>
		<message>
			<source>Node ID for {0} not found!</source>
			<translation>Node ID for {0} not found!</translation>
		</message>
		<message>
			<source>Node layer not found in the project.</source>
			<translation>Node layer not found in the project.</translation>
		</message>
		<message>
			<source>Node not found: {0}</source>
			<translation>Node not found: {0}</translation>
		</message>
		<message>
			<source>Node selected</source>
			<translation>Node selected</translation>
		</message>
		<message>
			<source>Node set correctly</source>
			<translation>Node set correctly</translation>
		</message>
		<message>
			<source>No document selected.</source>
			<translation>Документ не вибрано.</translation>
		</message>
		<message>
			<source>No EPA results found. You must first simulate with Go2Epa.</source>
			<translation>No EPA results found. You must first simulate with Go2Epa.</translation>
		</message>
		<message>
			<source>No event provided for point selection</source>
			<translation>Подія для вибору точки не надана</translation>
		</message>
		<message>
			<source>No features found in the selection for {0}.</source>
			<translation>У виборі не знайдено елементів для {0}.</translation>
		</message>
		<message>
			<source>No features found in the selection for the enabled tabs ({0}).</source>
			<translation>У виборі не знайдено елементів для увімкнених вкладок ({0}).</translation>
		</message>
		<message>
			<source>NO FEATURE TYPE DEFINED</source>
			<translation>ТИП ЕЛЕМЕНТА НЕ ВИЗНАЧЕНО</translation>
		</message>
		<message>
			<source>No help file found</source>
			<translation>Файл довідки не знайдено</translation>
		</message>
		<message>
			<source>No link in common between network and scenario {0}.</source>
			<translation>No link in common between network and scenario {0}.</translation>
		</message>
		<message>
			<source>No listValues for</source>
			<translation>Немає listValues для</translation>
		</message>
		<message>
			<source>No local i18n baseline SQL found for ({0}). Download plugin language files first.</source>
			<translation>No local i18n baseline SQL found for ({0}). Download plugin language files first.</translation>
		</message>
		<message>
			<source>No local SQL files found for language ({0}). Download them first.</source>
			<translation>No local SQL files found for language ({0}). Download them first.</translation>
		</message>
		<message>
			<source>No municipalities selected</source>
			<translation>Не вибрано муніципалітетів</translation>
		</message>
		<message>
			<source>No new features to insert. All selected features already exist in the table.</source>
			<translation>Немає нових елементів для вставки. Усі вибрані елементи вже існують у таблиці.</translation>
		</message>
		<message>
			<source>No node ID found at the snapped location.</source>
			<translation>Не знайдено ID вузла у прив&apos;язці до місця.</translation>
		</message>
		<message>
			<source>Non-visual objects</source>
			<translation>Non-visual objects</translation>
		</message>
		<message>
			<source>No parameters found in section {0}</source>
			<translation>No parameters found in section {0}</translation>
		</message>
		<message>
			<source>No pictures for this event.</source>
			<translation>Зображень для цієї події немає.</translation>
		</message>
		<message>
			<source>No pipes found matching your budget. (Hint: increase the yearly budget or/and the horizon year)</source>
			<translation>No pipes found matching your budget. (Hint: increase the yearly budget or/and the horizon year)</translation>
		</message>
		<message>
			<source>No pipes found matching your selected filters.</source>
			<translation>No pipes found matching your selected filters.</translation>
		</message>
		<message>
			<source>No primary key value set</source>
			<translation>Значення первинного ключа не встановлено</translation>
		</message>
		<message>
			<source>No psector selected. Please select at least one.</source>
			<translation>Psector не вибрано. Будь ласка, виберіть принаймні один.</translation>
		</message>
		<message>
			<source>No psector values</source>
			<translation>Немає значень psector</translation>
		</message>
		<message>
			<source>No records selected</source>
			<translation>No records selected</translation>
		</message>
		<message>
			<source>No results</source>
			<translation>Немає результатів</translation>
		</message>
		<message>
			<source>No results found. Please check values set on selector of state and exploitation</source>
			<translation>Результатів не знайдено. Будь ласка, перевірте значення, встановлені в селекторі стану та експлуатації</translation>
		</message>
		<message>
			<source>No results returned from the database.</source>
			<translation>No results returned from the database.</translation>
		</message>
		<message>
			<source>No snapshots available. Please create a snapshot first or wait for tomorrow to travel since today.</source>
			<translation>Знімків недоступно. Створіть спочатку знімок або зачекайте до завтра для поїздки, оскільки сьогодні це неможливо.</translation>
		</message>
		<message>
			<source>No SQL context available.</source>
			<translation>No SQL context available.</translation>
		</message>
		<message>
			<source>Not &apos;{0}&apos;</source>
			<translation>Не &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>No teams available to switch to.</source>
			<translation>No teams available to switch to.</translation>
		</message>
		<message>
			<source>Not found: {0}</source>
			<translation>Не знайдено: {0}</translation>
		</message>
		<message>
			<source>No URI builder for provider: {0}</source>
			<translation>No URI builder for provider: {0}</translation>
		</message>
		<message>
			<source>No valid data received from the SQL function.</source>
			<translation>Дійсні дані від SQL-функції не отримано.</translation>
		</message>
		<message>
			<source>No valid line data received from the SQL function.</source>
			<translation>No valid line data received from the SQL function.</translation>
		</message>
		<message>
			<source>No valid psector IDs found</source>
			<translation>Не знайдено дійсних ID psector</translation>
		</message>
		<message>
			<source>No valid snapping result. Please select a valid arc.</source>
			<translation>No valid snapping result. Please select a valid arc.</translation>
		</message>
		<message>
			<source>No valid snapping result. Please select a valid point.</source>
			<translation>Немає дійсного результату прив&apos;язки. Будь ласка, виберіть дійсну точку.</translation>
		</message>
		<message>
			<source>No visit values</source>
			<translation>Немає значень візиту</translation>
		</message>
		<message>
			<source>No workcat values</source>
			<translation>Немає значень workcat</translation>
		</message>
		<message>
			<source>object_1 and object_2 are required.</source>
			<translation>object_1 and object_2 are required.</translation>
		</message>
		<message>
			<source>object_1 and object_2 must be different.</source>
			<translation>object_1 and object_2 must be different.</translation>
		</message>
		<message>
			<source>object_1 and object_2 must be numeric node ids.</source>
			<translation>object_1 and object_2 must be numeric node ids.</translation>
		</message>
		<message>
			<source>Object already associated with this feature</source>
			<translation>Об&apos;єкт уже пов&apos;язаний з цим елементом</translation>
		</message>
		<message>
			<source>Object id not found</source>
			<translation>Ідентифікатор об&apos;єкта не знайдено</translation>
		</message>
		<message>
			<source>Offline mincut failed (gw_fct_getmincutminsector)</source>
			<translation>Offline mincut failed (gw_fct_getmincutminsector)</translation>
		</message>
		<message>
			<source>Once you have configured all the necessary catalogs, you can click on the &apos;Accept&apos; button to start the import process.</source>
			<translation>Після налаштування всіх необхідних каталогів ви можете натиснути кнопку &apos;Прийняти&apos;, щоб розпочати процес імпорту.</translation>
		</message>
		<message>
			<source>Only FRELEM can be added to dscenario</source>
			<translation>До dscenario можна додавати лише FRELEM</translation>
		</message>
		<message>
			<source>Only one record can be selected</source>
			<translation>Можна вибрати лише один запис</translation>
		</message>
		<message>
			<source>Only rows with values are allowed to be deleted.</source>
			<translation>Можна видаляти лише рядки з значеннями.</translation>
		</message>
		<message>
			<source>Open</source>
			<translation>Open</translation>
		</message>
		<message>
			<source>Open Manage Schemas to create and integrate am</source>
			<translation>Open Manage Schemas to create and integrate am</translation>
		</message>
		<message>
			<source>Option &apos;{0}&apos; in scenario {1} must have 2 values.</source>
			<translation>Option &apos;{0}&apos; in scenario {1} must have 2 values.</translation>
		</message>
		<message>
			<source>or</source>
			<translation>або</translation>
		</message>
		<message>
			<source>Orifice</source>
			<translation>Orifice</translation>
		</message>
		<message>
			<source>Orifices couldn&apos;t be inserted!</source>
			<translation>Orifices couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Other catalogs:</source>
			<translation>Other catalogs:</translation>
		</message>
		<message>
			<source>Other feature ids:</source>
			<translation>Other feature ids:</translation>
		</message>
		<message>
			<source>Other materials:</source>
			<translation>Other materials:</translation>
		</message>
		<message>
			<source>Others</source>
			<translation>Others</translation>
		</message>
		<message>
			<source>our website</source>
			<translation>наш веб-сайт</translation>
		</message>
		<message>
			<source>Outfalls couldn&apos;t be inserted!</source>
			<translation>Outfalls couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Outlet</source>
			<translation>Outlet</translation>
		</message>
		<message>
			<source>Outlets couldn&apos;t be inserted!</source>
			<translation>Outlets couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Overwrite</source>
			<translation>Перезаписати</translation>
		</message>
		<message>
			<source>Overwrite file</source>
			<translation>Перезаписати файл</translation>
		</message>
		<message>
			<source>Overwrite values</source>
			<translation>Перезаписати значення</translation>
		</message>
		<message>
			<source>Page not found.</source>
			<translation>Page not found.</translation>
		</message>
		<message>
			<source>Parameter &apos;{0}&apos; is None</source>
			<translation>Параметр &apos;{0}&apos; є None</translation>
		</message>
		<message>
			<source>Parameter button_function is null for button</source>
			<translation>Параметр button_function має значення null для кнопки</translation>
		</message>
		<message>
			<source>Parameter functionName is null for button</source>
			<translation>Параметр functionName має значення null для кнопки</translation>
		</message>
		<message>
			<source>Parameter functionName is null for check</source>
			<translation>Параметр functionName дорівнює null для перевірки</translation>
		</message>
		<message>
			<source>Parameter not found: {parameter}</source>
			<translation>Параметр не знайдено: {parameter}</translation>
		</message>
		<message>
			<source>Parameter &apos;Query text:&apos; is mandatory for &apos;combo&apos; widgets. Please set value.</source>
			<translation>Параметр &apos;Query text:&apos; є обов&apos;язковим для віджетів &apos;combo&apos;. Будь ласка, задайте значення.</translation>
		</message>
		<message>
			<source>Parameter widgetfunction is null for widget hyperlink</source>
			<translation>Параметр widgetfunction має значення null для віджета hyperlink</translation>
		</message>
		<message>
			<source>Parameter widgetfunction not found for widget type hyperlink</source>
			<translation>Параметр widgetfunction не знайдено для типу віджета hyperlink</translation>
		</message>
		<message>
			<source>Parent ID does not exist.</source>
			<translation>Parent ID does not exist.</translation>
		</message>
		<message>
			<source>Parent ID must be an integer.</source>
			<translation>Parent ID must be an integer.</translation>
		</message>
		<message>
			<source>Parse INP task</source>
			<translation>Parse INP task</translation>
		</message>
		<message>
			<source>Parsing error fixed</source>
			<translation>Помилку розбору виправлено</translation>
		</message>
		<message>
			<source>PgRouting version</source>
			<translation>PgRouting версія</translation>
		</message>
		<message>
			<source>pgRouting version is not compatible with Giswater. Please check wiki</source>
			<translation>Версія pgRouting несумісна з Giswater. Будь ласка, перевірте wiki</translation>
		</message>
		<message>
			<source>PIPE</source>
			<translation>PIPE</translation>
		</message>
		<message>
			<source>Pipes couldn&apos;t be inserted!</source>
			<translation>Pipes couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Pipes with invalid arccat_ids: {0}.</source>
			<translation>Труби з недійсними arccat_ids: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid arccat_ids: {0}.\nInvalid arccat_ids: {1}.\n\nAn arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.\n\nDo you want to proceed?</source>
			<translation>Pipes with invalid arccat_ids: {0}.\nInvalid arccat_ids: {1}.\n\nAn arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.\n\nDo you want to proceed?</translation>
		</message>
		<message>
			<source>Pipes with invalid diameters: {0}.</source>
			<translation>Труби з недійсними діаметрами: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid diameters: {0}.\nInvalid diameters: {1}.\n\nA diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.\n\nDo you want to proceed?</source>
			<translation>Pipes with invalid diameters: {0}.\nInvalid diameters: {1}.\n\nA diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.\n\nDo you want to proceed?</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {0}.qtd</source>
			<translation>Труби з недійсними матеріалами: {0}.qtd</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {2}.</source>
			<translation>Труби з недійсними матеріалами: {2}.</translation>
		</message>
		<message>
			<source>Pipes with invalid pressures: {0}.\nThese pipes have no pressure information for their nodes. This will result in them receiving the maximum longevity value for their material, which may affect the final priority value.\n\nDo you want to proceed?</source>
			<translation>Pipes with invalid pressures: {0}.\nThese pipes have no pressure information for their nodes. This will result in them receiving the maximum longevity value for their material, which may affect the final priority value.\n\nDo you want to proceed?</translation>
		</message>
		<message>
			<source>Planified features cannot be replaced</source>
			<translation>Заплановані елементи не можуть бути замінені</translation>
		</message>
		<message>
			<source>Plan psector - {0} ({1})</source>
			<translation>Plan psector - {0} ({1})</translation>
		</message>
		<message>
			<source>Please choose a csv file</source>
			<translation>Будь ласка, виберіть файл csv</translation>
		</message>
		<message>
			<source>Please choose a different name.</source>
			<translation>Please choose a different name.</translation>
		</message>
		<message>
			<source>Please choose a valid path</source>
			<translation>Будь ласка, виберіть дійсний шлях</translation>
		</message>
		<message>
			<source>Please close all &apos;Psector manager&apos; dialogs and try again</source>
			<translation>Please close all &apos;Psector manager&apos; dialogs and try again</translation>
		</message>
		<message>
			<source>Please enter a demands dscenario name to proceed with this import.</source>
			<translation>Будь ласка, введіть назву сценарію попитів, щоб продовжити цей імпорт.</translation>
		</message>
		<message>
			<source>Please enter a new catalog name when the &quot;{0}&quot; option is selected.</source>
			<translation>Please enter a new catalog name when the &quot;{0}&quot; option is selected.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the built date range.</source>
			<translation>Будь ласка, введіть дійсне ціле число для діапазону дат побудови.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the cluster length.</source>
			<translation>Будь ласка, введіть дійсне ціле число для довжини кластера.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the maximum distance.</source>
			<translation>Будь ласка, введіть дійсне ціле число для максимальної відстані.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the number of years.</source>
			<translation>Будь ласка, введіть дійсне ціле число для кількості років.</translation>
		</message>
		<message>
			<source>Please enter a valid number.</source>
			<translation>Please enter a valid number.</translation>
		</message>
		<message>
			<source>Please enter a valid number for the budget.</source>
			<translation>Будь ласка, введіть дійсне число для бюджету.</translation>
		</message>
		<message>
			<source>Please enter a valid target year.</source>
			<translation>Введіть дійсний цільовий рік.</translation>
		</message>
		<message>
			<source>Please enter a Workcat_id to proceed with this import.</source>
			<translation>Будь ласка, введіть Workcat_id, щоб продовжити цей імпорт.</translation>
		</message>
		<message>
			<source>Please enter the diameter range in this format: [minimum factor]-[maximum factor]. For example, 0.75-1.5</source>
			<translation>Будь ласка, введіть діапазон діаметра у такому форматі: [мінімальний коефіцієнт]-[максимальний коефіцієнт]. Наприклад, 0.75-1.5</translation>
		</message>
		<message>
			<source>Please fill all mandatory fields (highlighted in red).</source>
			<translation>Please fill all mandatory fields (highlighted in red).</translation>
		</message>
		<message>
			<source>Please fill link catalog field in the dialog</source>
			<translation>Будь ласка, заповніть поле каталогу зв&apos;язків у діалоговому вікні</translation>
		</message>
		<message>
			<source>Please provide a result name.</source>
			<translation>Будь ласка, введіть назву результату.</translation>
		</message>
		<message>
			<source>Please select a catalog item for all elements in the tabs: Features, Nodes, Arcs, Materials.</source>
			<translation>Будь ласка, виберіть елемент каталогу для всіх елементів на вкладках: Елементи, Вузли, Дуги, Матеріали.</translation>
		</message>
		<message>
			<source>Please select a catalog item for all elements in the tabs: Nodes, Arcs, Materials, Features.</source>
			<translation>Будь ласка, виберіть елемент каталогу для всіх елементів на вкладках: Вузли, Дуги, Матеріали, Елементи.</translation>
		</message>
		<message>
			<source>Please select a category to update.</source>
			<translation>Будь ласка, виберіть категорію для оновлення.</translation>
		</message>
		<message>
			<source>Please select a default raingage to proceed with this import.</source>
			<translation>Будь ласка, виберіть датчик опадів за замовчуванням, щоб продовжити цей імпорт.</translation>
		</message>
		<message>
			<source>Please, select a diferent project name than current.</source>
			<translation>Будь ласка, виберіть іншу назву проекту, відмінну від поточної.</translation>
		</message>
		<message>
			<source>Please select a feature to add</source>
			<translation>Будь ласка, виберіть елемент для додавання</translation>
		</message>
		<message>
			<source>Please select a lot to open</source>
			<translation>Please select a lot to open</translation>
		</message>
		<message>
			<source>Please select a municipality to proceed with this import.</source>
			<translation>Будь ласка, виберіть муніципалітет, щоб продовжити цей імпорт.</translation>
		</message>
		<message>
			<source>Please select an element to zoom to.</source>
			<translation>Please select an element to zoom to.</translation>
		</message>
		<message>
			<source>Please select an exploitation to proceed with this import.</source>
			<translation>Будь ласка, виберіть експлуатацію, щоб продовжити цей імпорт.</translation>
		</message>
		<message>
			<source>Please, select a project to delete</source>
			<translation>Будь ласка, виберіть проект для видалення</translation>
		</message>
		<message>
			<source>Please, select a project to rename</source>
			<translation>Please, select a project to rename</translation>
		</message>
		<message>
			<source>Please select a result and an export path.</source>
			<translation>Please select a result and an export path.</translation>
		</message>
		<message>
			<source>Please select a result with not empty type</source>
			<translation>Please select a result with not empty type</translation>
		</message>
		<message>
			<source>Please select a row first</source>
			<translation>Please select a row first</translation>
		</message>
		<message>
			<source>Please select a sector to proceed with this import.</source>
			<translation>Будь ласка, виберіть сектор, щоб продовжити цей імпорт.</translation>
		</message>
		<message>
			<source>Please select a style group before adding a new style.</source>
			<translation>Будь ласка, виберіть групу стилю перед додаванням нового стилю.</translation>
		</message>
		<message>
			<source>Please select a style group to delete.</source>
			<translation>Будь ласка, виберіть групу стилів для видалення.</translation>
		</message>
		<message>
			<source>Please select a team to assign.</source>
			<translation>Please select a team to assign.</translation>
		</message>
		<message>
			<source>Please select at least one user to assign a team.</source>
			<translation>Please select at least one user to assign a team.</translation>
		</message>
		<message>
			<source>Please select at least one user to change team.</source>
			<translation>Please select at least one user to change team.</translation>
		</message>
		<message>
			<source>Please select at least one user to remove team assignment.</source>
			<translation>Please select at least one user to remove team assignment.</translation>
		</message>
		<message>
			<source>Please select a valid team to assign.</source>
			<translation>Please select a valid team to assign.</translation>
		</message>
		<message>
			<source>Please select a workorder to open</source>
			<translation>Please select a workorder to open</translation>
		</message>
		<message>
			<source>Please select both a user and a campaign before adding a row.</source>
			<translation>Please select both a user and a campaign before adding a row.</translation>
		</message>
		<message>
			<source>Please select one or more styles to delete.</source>
			<translation>Будь ласка, виберіть один або кілька стилів для видалення.</translation>
		</message>
		<message>
			<source>Please select one or more styles to update.</source>
			<translation>Будь ласка, виберіть один або кілька стилів для оновлення.</translation>
		</message>
		<message>
			<source>Please select only one result before changing its status.</source>
			<translation>Будь ласка, виберіть лише один результат перед зміненням його статусу.</translation>
		</message>
		<message>
			<source>Please select rows to remove from the table</source>
			<translation>Будь ласка, виберіть рядки для видалення з таблиці</translation>
		</message>
		<message>
			<source>Plugin version not found</source>
			<translation>Plugin version not found</translation>
		</message>
		<message>
			<source>PostGis version</source>
			<translation>PostGis версія</translation>
		</message>
		<message>
			<source>PostgreSQL PID: {0}</source>
			<translation>PostgreSQL PID: {0}</translation>
		</message>
		<message>
			<source>PostgreSQL version</source>
			<translation>PostgreSQL версія</translation>
		</message>
		<message>
			<source>PostgreSQL version is not compatible with Giswater. Please check wiki</source>
			<translation>Версія PostgreSQL несумісна з Giswater. Будь ласка, перевірте вікі</translation>
		</message>
		<message>
			<source>prefer</source>
			<translation>надавати перевагу</translation>
		</message>
		<message>
			<source>Preparing network...</source>
			<translation>Preparing network...</translation>
		</message>
		<message>
			<source>Price list csv file name is required</source>
			<translation>Назва csv-файлу прайс-листа є обов&apos;язковою</translation>
		</message>
		<message>
			<source>Price list detail csv file name is required</source>
			<translation>Потрібно вказати ім&apos;я файлу csv з деталями прайс-листа</translation>
		</message>
		<message>
			<source>Priority Calculation (Global)</source>
			<translation>Priority Calculation (Global)</translation>
		</message>
		<message>
			<source>Process completed</source>
			<translation>Процес завершено</translation>
		</message>
		<message>
			<source>Processes</source>
			<translation>Processes</translation>
		</message>
		<message>
			<source>Process finished.\n\nINP file created on:\n{0}\n\nReport file created on:\n{1}</source>
			<translation>Process finished.\n\nINP file created on:\n{0}\n\nReport file created on:\n{1}</translation>
		</message>
		<message>
			<source>Process finished.\n\nINP file created on:\n{0}\n\nStatistics file created on:\n{1}</source>
			<translation>Process finished.\n\nINP file created on:\n{0}\n\nStatistics file created on:\n{1}</translation>
		</message>
		<message>
			<source>Process finished successfully</source>
			<translation>Процес Успішно Завершено</translation>
		</message>
		<message>
			<source>Process finished successfully: Delete schema</source>
			<translation>Процес успішно завершено: Видалення схеми</translation>
		</message>
		<message>
			<source>Process finished with some errors</source>
			<translation>Процес Завершено З Деякими Помилками</translation>
		</message>
		<message>
			<source>Processing folder</source>
			<translation>Обробка папки</translation>
		</message>
		<message>
			<source>Processing muni_id {0}</source>
			<translation>Опрацювання muni_id {0}</translation>
		</message>
		<message>
			<source>Profile image path: {0}</source>
			<translation>Profile image path: {0}</translation>
		</message>
		<message>
			<source>Profile interpolation</source>
			<translation>Profile interpolation</translation>
		</message>
		<message>
			<source>Profile name is mandatory.</source>
			<translation>Ім&apos;я профілю обов&apos;язкове.</translation>
		</message>
		<message>
			<source>Project check task is already active!</source>
			<translation>Project check task is already active!</translation>
		</message>
		<message>
			<source>Project read finished</source>
			<translation>Зчитування Проекту Завершено</translation>
		</message>
		<message>
			<source>Project read finished with different versions on plugin metadata ({0}) and PostgreSQL sys_version table ({1}).</source>
			<translation>Зчитування Проекту Завершено З Різними Версіями В Метаданих Плагіну ({0}) Та Таблиці sys_version PostgreSQL ({1}).</translation>
		</message>
		<message>
			<source>Project read started</source>
			<translation>Зчитування Проекту Розпочато</translation>
		</message>
		<message>
			<source>Psector &apos;{0}&apos; has no workcat_id value set. Do you want to continue with the default value?</source>
			<translation>Psector &apos;{0}&apos; не має встановленого значення workcat_id. Бажаєте продовжити з використанням значення за замовчуванням?</translation>
		</message>
		<message>
			<source>Psector actual</source>
			<translation>Psector actual</translation>
		</message>
		<message>
			<source>Psector could not be updated because of the following errors: </source>
			<translation>Psector не вдалося оновити через такі помилки:</translation>
		</message>
		<message>
			<source>Psector could not be updated because of the following errors: {0}</source>
			<translation>Psector could not be updated because of the following errors: {0}</translation>
		</message>
		<message>
			<source>Psector features loaded successfully on the map.</source>
			<translation>Pсектор елементи успішно завантажені на карту.</translation>
		</message>
		<message>
			<source>Psector ID not found</source>
			<translation>Psector ID не знайдено</translation>
		</message>
		<message>
			<source>Psector is not archived</source>
			<translation>Psector не заархівований</translation>
		</message>
		<message>
			<source>Psector name not found</source>
			<translation>Pсектор ім&apos;я не знайдено</translation>
		</message>
		<message>
			<source>Psector values updated successfully</source>
			<translation>Значення Psector успішно оновлено</translation>
		</message>
		<message>
			<source>Pumps couldn&apos;t be inserted!</source>
			<translation>Pumps couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Python file</source>
			<translation>Файл Python</translation>
		</message>
		<message>
			<source>Python function</source>
			<translation>Функція Python</translation>
		</message>
		<message>
			<source>Python package &apos;{0}&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>Python package &apos;{0}&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</translation>
		</message>
		<message>
			<source>Python package &apos;matplotlib&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>Python package &apos;matplotlib&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</translation>
		</message>
		<message>
			<source>Python package &apos;swmm-api&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>Python package &apos;swmm-api&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</translation>
		</message>
		<message>
			<source>Python package &apos;wntr&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>Python package &apos;wntr&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</translation>
		</message>
		<message>
			<source>Python translation canceled</source>
			<translation>Переклад Python Скасовано</translation>
		</message>
		<message>
			<source>Python translation failed</source>
			<translation>Переклад Python не вдався</translation>
		</message>
		<message>
			<source>Python translation successful</source>
			<translation>Переклад Python успішний</translation>
		</message>
		<message>
			<source>QGIS project has more than one {0} layer coming from different schemas. If you are looking to manage two schemas, it is mandatory to define which is the master and which isn&apos;t. To do this, you need to configure the QGIS project setting this project&apos;s variables: {1} and {2}.</source>
			<translation>Проєкт QGIS має більше ніж один шар {0}, що походить із різних схем. Якщо ви хочете керувати двома схемами, обов&apos;язково потрібно визначити, яка є основною, а яка — ні. Для цього необхідно налаштувати проєкт QGIS, встановивши змінні цього проєкту: {1} та {2}.</translation>
		</message>
		<message>
			<source>QGIS project seems to be a Giswater project, but layer(s) {0} are missing</source>
			<translation>QGIS project seems to be a Giswater project, but layer(s) {0} are missing</translation>
		</message>
		<message>
			<source>QgsLayerTree not found for project.</source>
			<translation>QgsLayerTree not found for project.</translation>
		</message>
		<message>
			<source>QML file {0} not found</source>
			<translation>QML file {0} not found</translation>
		</message>
		<message>
			<source>QML is empty!</source>
			<translation>QML is empty!</translation>
		</message>
		<message>
			<source>Quantized Demands</source>
			<translation>Quantized Demands</translation>
		</message>
		<message>
			<source>Raingages couldn&apos;t be inserted!</source>
			<translation>Raingages couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Raports</source>
			<translation>Raports</translation>
		</message>
		<message>
			<source>Reading file</source>
			<translation>Читання файлу</translation>
		</message>
		<message>
			<source>Reading input files...</source>
			<translation>Reading input files...</translation>
		</message>
		<message>
			<source>Real location has been updated</source>
			<translation>Реальне розташування оновлено</translation>
		</message>
		<message>
			<source>Recommended catalogs:</source>
			<translation>Recommended catalogs:</translation>
		</message>
		<message>
			<source>Recommended feature ids:</source>
			<translation>Recommended feature ids:</translation>
		</message>
		<message>
			<source>Recommended materials:</source>
			<translation>Recommended materials:</translation>
		</message>
		<message>
			<source>Record deleted</source>
			<translation>Record deleted</translation>
		</message>
		<message>
			<source>Records deleted</source>
			<translation>Записи видалено</translation>
		</message>
		<message>
			<source>Recursive Go2Epa</source>
			<translation>Recursive Go2Epa</translation>
		</message>
		<message>
			<source>Reload failed</source>
			<translation>Перезавантаження Не Вдалося</translation>
		</message>
		<message>
			<source>Remaining: {0} ({1}/{2})</source>
			<translation>Remaining: {0} ({1}/{2})</translation>
		</message>
		<message>
			<source>Remove layer from project?</source>
			<translation>Видалити Шар З Проекту?</translation>
		</message>
		<message>
			<source>REMOVE NODE</source>
			<translation>REMOVE NODE</translation>
		</message>
		<message>
			<source>Remove Team Assignment</source>
			<translation>Remove Team Assignment</translation>
		</message>
		<message>
			<source>Rename project - {0}</source>
			<translation>Rename project - {0}</translation>
		</message>
		<message>
			<source>Replace feature</source>
			<translation>Замінити Об&apos;єкт</translation>
		</message>
		<message>
			<source>Replace feature done successfully</source>
			<translation>Replace feature done successfully</translation>
		</message>
		<message>
			<source>Replacing template text</source>
			<translation>Замінюється Текст Шаблону</translation>
		</message>
		<message>
			<source>REPORT</source>
			<translation>REPORT</translation>
		</message>
		<message>
			<source>Reports generated successfully</source>
			<translation>Звіти згенеровано успішно</translation>
		</message>
		<message>
			<source>Required fields are missing</source>
			<translation>Не Вистачає Обов&apos;язкових Полів</translation>
		</message>
		<message>
			<source>Reservoirs couldn&apos;t be inserted!</source>
			<translation>Reservoirs couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Reset position form done successfully.</source>
			<translation>Скидання позиції форми виконано успішно.</translation>
		</message>
		<message>
			<source>Response from {0} is not a ZIP archive</source>
			<translation>Response from {0} is not a ZIP archive</translation>
		</message>
		<message>
			<source>Result name</source>
			<translation>Ім&apos;я Результату</translation>
		</message>
		<message>
			<source>Result name already exists, do you want overwrite?</source>
			<translation>Ім&apos;я Результату Вже Існує, Ви Хочете Перезаписати?</translation>
		</message>
		<message>
			<source>Result name not found. It&apos;s not possible to import RPT file into database</source>
			<translation>Ім&apos;я результату не знайдено. Неможливо імпортувати RPT-файл у базу даних</translation>
		</message>
		<message>
			<source>Retrieving process ({0}/{1})...</source>
			<translation>Отримання Процесу ({0}/{1})...</translation>
		</message>
		<message>
			<source>Rotation must be a number.</source>
			<translation>Rotation must be a number.</translation>
		</message>
		<message>
			<source>Rpt fail</source>
			<translation>Помилка Rpt</translation>
		</message>
		<message>
			<source>RPT file path is required when importing results or executing EPA</source>
			<translation>RPT file path is required when importing results or executing EPA</translation>
		</message>
		<message>
			<source>Running simulation...</source>
			<translation>Running simulation...</translation>
		</message>
		<message>
			<source>Save feature</source>
			<translation>Save feature</translation>
		</message>
		<message>
			<source>Save these changes to campaign selector?</source>
			<translation>Save these changes to campaign selector?</translation>
		</message>
		<message>
			<source>Saving INP file...</source>
			<translation>Saving INP file...</translation>
		</message>
		<message>
			<source>Saving output files...</source>
			<translation>Saving output files...</translation>
		</message>
		<message>
			<source>Saving statistics file...</source>
			<translation>Saving statistics file...</translation>
		</message>
		<message>
			<source>Scada graph</source>
			<translation>Scada graph</translation>
		</message>
		<message>
			<source>Scada graph edge created</source>
			<translation>Scada graph edge created</translation>
		</message>
		<message>
			<source>Scada graph saved in DB but om_graph layer could not be loaded.</source>
			<translation>Scada graph saved in DB but om_graph layer could not be loaded.</translation>
		</message>
		<message>
			<source>Scale must be a number.</source>
			<translation>Scale must be a number.</translation>
		</message>
		<message>
			<source>Schema audit not found, please create it first</source>
			<translation>Схема Аудиту Не Знайдена, Будь Ласка, Створіть Її Спочатку</translation>
		</message>
		<message>
			<source>SchemaBuilder exception: {0}</source>
			<translation>SchemaBuilder exception: {0}</translation>
		</message>
		<message>
			<source>SchemaBuilder failed: {0}</source>
			<translation>SchemaBuilder failed: {0}</translation>
		</message>
		<message>
			<source>SchemaBuilder failed without first_failure</source>
			<translation>SchemaBuilder failed without first_failure</translation>
		</message>
		<message>
			<source>Schema cibs already exists.</source>
			<translation>Schema cibs already exists.</translation>
		</message>
		<message>
			<source>Schema multilang already exists.</source>
			<translation>Schema multilang already exists.</translation>
		</message>
		<message>
			<source>Schema name</source>
			<translation>Назва Схеми</translation>
		</message>
		<message>
			<source>Schema Utils already exist.</source>
			<translation>Schema Utils already exist.</translation>
		</message>
		<message>
			<source>Schema vacuum executed</source>
			<translation>Виконано vacuum схеми</translation>
		</message>
		<message>
			<source>Seeding {0} ({1}/{2})</source>
			<translation>Seeding {0} ({1}/{2})</translation>
		</message>
		<message>
			<source>Seeding multilang translations for ({0})...</source>
			<translation>Seeding multilang translations for ({0})...</translation>
		</message>
		<message>
			<source>Seed multilang translations?</source>
			<translation>Seed multilang translations?</translation>
		</message>
		<message>
			<source>Seed multilang translations for ({0})</source>
			<translation>Seed multilang translations for ({0})</translation>
		</message>
		<message>
			<source>Select a campaign to create a child campaign.</source>
			<translation>Select a campaign to create a child campaign.</translation>
		</message>
		<message>
			<source>Select a campaign to delete.</source>
			<translation>Виберіть кампанію для видалення.</translation>
		</message>
		<message>
			<source>Select a language</source>
			<translation>Select a language</translation>
		</message>
		<message>
			<source>Select a language to manage</source>
			<translation>Select a language to manage</translation>
		</message>
		<message>
			<source>Select a locale</source>
			<translation>Select a locale</translation>
		</message>
		<message>
			<source>Select a lot to delete</source>
			<translation>Select a lot to delete</translation>
		</message>
		<message>
			<source>Select an arc to start inundation analysis.</source>
			<translation>Select an arc to start inundation analysis.</translation>
		</message>
		<message>
			<source>Select a network anchor to copy cibs data.</source>
			<translation>Select a network anchor to copy cibs data.</translation>
		</message>
		<message>
			<source>Select a network anchor to integrate cibs.</source>
			<translation>Select a network anchor to integrate cibs.</translation>
		</message>
		<message>
			<source>Select a schema</source>
			<translation>Select a schema</translation>
		</message>
		<message>
			<source>Select a UD schema to integrate.</source>
			<translation>Select a UD schema to integrate.</translation>
		</message>
		<message>
			<source>Select a workorder to delete</source>
			<translation>Select a workorder to delete</translation>
		</message>
		<message>
			<source>Select a WS anchor in the network table.</source>
			<translation>Select a WS anchor in the network table.</translation>
		</message>
		<message>
			<source>Select a WS or UD anchor in the network table.</source>
			<translation>Select a WS or UD anchor in the network table.</translation>
		</message>
		<message>
			<source>Select a WS or UD schema for the cibs operation</source>
			<translation>Select a WS or UD schema for the cibs operation</translation>
		</message>
		<message>
			<source>Select a WS or UD schema in the table.</source>
			<translation>Select a WS or UD schema in the table.</translation>
		</message>
		<message>
			<source>Select a WS or UD schema to adapt to cibs</source>
			<translation>Select a WS or UD schema to adapt to cibs</translation>
		</message>
		<message>
			<source>Select a WS or UD schema to copy data to cibs</source>
			<translation>Select a WS or UD schema to copy data to cibs</translation>
		</message>
		<message>
			<source>Select a WS schema to integrate.</source>
			<translation>Select a WS schema to integrate.</translation>
		</message>
		<message>
			<source>Select a WS/UD anchor in the network table.</source>
			<translation>Select a WS/UD anchor in the network table.</translation>
		</message>
		<message>
			<source>Select connecs or gullies with qgis tool and use right click to connect them with network. CTRL + SHIFT over selection to remove it</source>
			<translation>виберіть connecs або gullies інструментом qgis і використайте правий клік, щоб з&apos;єднати їх з мережею. CTRL + SHIFT над виділенням, щоб видалити його</translation>
		</message>
		<message>
			<source>Selected {0}</source>
			<translation>Вибрано {0}</translation>
		</message>
		<message>
			<source>Selected date interval is not valid</source>
			<translation>Вибраний інтервал дат недійсний</translation>
		</message>
		<message>
			<source>Selected element already in the list</source>
			<translation>Вибраний елемент вже у списку</translation>
		</message>
		<message>
			<source>Selected hydrometer_id not found</source>
			<translation>Вибраний hydrometer_id не знайдено</translation>
		</message>
		<message>
			<source>Selected node</source>
			<translation>Вибраний вузол</translation>
		</message>
		<message>
			<source>Selected schema is already adapted to cibs.</source>
			<translation>Selected schema is already adapted to cibs.</translation>
		</message>
		<message>
			<source>Selected schema is already integrated with utils.</source>
			<translation>Selected schema is already integrated with utils.</translation>
		</message>
		<message>
			<source>Selected schema must be adapted to cibs before copying data</source>
			<translation>Selected schema must be adapted to cibs before copying data</translation>
		</message>
		<message>
			<source>Selected schema not found</source>
			<translation>Вибрана схема не знайдена</translation>
		</message>
		<message>
			<source>Selected snapped feature_id to copy values from</source>
			<translation>вибрано приєднану feature_id для копіювання значень із</translation>
		</message>
		<message>
			<source>Selected snapped feature_id to copy values from: {0}\nDo you want to copy its values to the current node?\n\n{1}</source>
			<translation>Selected snapped feature_id to copy values from: {0}\nDo you want to copy its values to the current node?\n\n{1}</translation>
		</message>
		<message>
			<source>Selected styles updated successfully!</source>
			<translation>Вибрані стилі успішно оновлені!</translation>
		</message>
		<message>
			<source>Selected styles were successfully deleted.</source>
			<translation>Вибрані стилі були успішно видалені.</translation>
		</message>
		<message>
			<source>Select Feature(s)</source>
			<translation>Select Feature(s)</translation>
		</message>
		<message>
			<source>Select features by expression</source>
			<translation>Select features by expression</translation>
		</message>
		<message>
			<source>Select Features by Freehand</source>
			<translation>Select Features by Freehand</translation>
		</message>
		<message>
			<source>Select Features by Polygon</source>
			<translation>Select Features by Polygon</translation>
		</message>
		<message>
			<source>Select Features by Radius</source>
			<translation>Select Features by Radius</translation>
		</message>
		<message>
			<source>Select folder</source>
			<translation>Select folder</translation>
		</message>
		<message>
			<source>Select INP file</source>
			<translation>Вибрати INP Файл</translation>
		</message>
		<message>
			<source>Select just one document</source>
			<translation>Виберіть Лише Один Документ</translation>
		</message>
		<message>
			<source>Select just one visit</source>
			<translation>Виберіть лише один візит</translation>
		</message>
		<message>
			<source>Select new team:</source>
			<translation>Select new team:</translation>
		</message>
		<message>
			<source>Select one</source>
			<translation>Виберіть один</translation>
		</message>
		<message>
			<source>selector</source>
			<translation>selector</translation>
		</message>
		<message>
			<source>Selector help</source>
			<translation>Довідка селектора</translation>
		</message>
		<message>
			<source>Select RPT file</source>
			<translation>Виберіть RPT файл</translation>
		</message>
		<message>
			<source>Select the arc to perform a visual execution</source>
			<translation>Select the arc to perform a visual execution</translation>
		</message>
		<message>
			<source>Select valid INP file</source>
			<translation>Вибрати Дійсний INP Файл</translation>
		</message>
		<message>
			<source>Select valid RPT file</source>
			<translation>Вибрати Дійсний RPT Файл</translation>
		</message>
		<message>
			<source>SERVER RESPONSE</source>
			<translation>ВІДПОВІДЬ СЕРВЕРА</translation>
		</message>
		<message>
			<source>Service database connection error (psycopg2). Please open plugin log file to get more details</source>
			<translation>Service database connection error (psycopg2). Please open plugin log file to get more details</translation>
		</message>
		<message>
			<source>Service database connection error (QSqlDatabase). Please open plugin log file to get more details</source>
			<translation>Service database connection error (QSqlDatabase). Please open plugin log file to get more details</translation>
		</message>
		<message>
			<source>Set rpt archived execution successful.</source>
			<translation>Встановлено: архівування RPT виконано успішно.</translation>
		</message>
		<message>
			<source>Shift+Click to uncheck all</source>
			<translation>Shift+Click to uncheck all</translation>
		</message>
		<message>
			<source>Show</source>
			<translation>Show</translation>
		</message>
		<message>
			<source>Show selection on top</source>
			<translation>Show selection on top</translation>
		</message>
		<message>
			<source>Skipping map highlighting for very large dataset ({0} features)</source>
			<translation>Skipping map highlighting for very large dataset ({0} features)</translation>
		</message>
		<message>
			<source>Skipping muni_id {0}: Invalid geometry</source>
			<translation>Пропуск muni_id {0}: Невірна геометрія</translation>
		</message>
		<message>
			<source>Snapped feature is not in a valid layer</source>
			<translation>Зафіксований елемент не в дійсному шарі</translation>
		</message>
		<message>
			<source>Some data is missing. Check gis_length for arc</source>
			<translation>Деякі дані відсутні. Перевірте gis_length для arc</translation>
		</message>
		<message>
			<source>Some mandatory fields are missing. Please fill the required fields (marked in red).</source>
			<translation>Some mandatory fields are missing. Please fill the required fields (marked in red).</translation>
		</message>
		<message>
			<source>Some mandatory values are missing. Please check the widgets marked in red.</source>
			<translation>Деякі обов&apos;язкові значення відсутні. Будь ласка, перевірте віджети, позначені червоним.</translation>
		</message>
		<message>
			<source>Sources</source>
			<translation>Sources</translation>
		</message>
		<message>
			<source>SQL</source>
			<translation>SQL</translation>
		</message>
		<message>
			<source>SQL: {0}</source>
			<translation>SQL: {0}</translation>
		</message>
		<message>
			<source>SQL Context</source>
			<translation>SQL Context</translation>
		</message>
		<message>
			<source>SQL execution failed.</source>
			<translation>SQL execution failed.</translation>
		</message>
		<message>
			<source>SQL File</source>
			<translation>SQL Файл</translation>
		</message>
		<message>
			<source>SQL folder not found</source>
			<translation>Папку SQL не знайдено</translation>
		</message>
		<message>
			<source>Started task &apos;{0}&apos;</source>
			<translation>Розпочато завдання &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Started task {0}</source>
			<translation>Розпочато завдання {0}</translation>
		</message>
		<message>
			<source>Starting execute_vacuum method</source>
			<translation>Початок виконання методу execute_vacuum</translation>
		</message>
		<message>
			<source>Starting process...</source>
			<translation>Розпочато процес...</translation>
		</message>
		<message>
			<source>Static Calibration</source>
			<translation>Static Calibration</translation>
		</message>
		<message>
			<source>Storage units couldn&apos;t be inserted!</source>
			<translation>Storage units couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Style group &apos;{0}&apos; and related entries have been deleted.</source>
			<translation>Група стилів &apos;{0}&apos; та пов&apos;язані записи були видалені.</translation>
		</message>
		<message>
			<source>Successful connection to {0} database</source>
			<translation>Успішне підключення до бази даних {0}</translation>
		</message>
		<message>
			<source>Successfully assigned team &apos;{0}&apos; to {1} user(s).</source>
			<translation>Successfully assigned team &apos;{0}&apos; to {1} user(s).</translation>
		</message>
		<message>
			<source>Successfully changed to team &apos;{0}&apos; for {1} user(s).</source>
			<translation>Successfully changed to team &apos;{0}&apos; for {1} user(s).</translation>
		</message>
		<message>
			<source>Successfully removed team assignment from {0} user(s).</source>
			<translation>Successfully removed team assignment from {0} user(s).</translation>
		</message>
		<message>
			<source>SUCCESS IN DUPLICATING PSECTOR</source>
			<translation>SUCCESS IN DUPLICATING PSECTOR</translation>
		</message>
		<message>
			<source>Table not found</source>
			<translation>Таблиця не знайдена</translation>
		</message>
		<message>
			<source>Table not found: &apos;{0}&apos;</source>
			<translation>Таблиця не знайдена: &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Table not found: {0}</source>
			<translation>Таблиця не знайдена: {0}</translation>
		</message>
		<message>
			<source>Tab not found.</source>
			<translation>Tab not found.</translation>
		</message>
		<message>
			<source>Tanks couldn&apos;t be inserted!</source>
			<translation>Tanks couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; completed</source>
			<translation>Завдання &apos;{0}&apos; виконано</translation>
		</message>
		<message>
			<source>Task {0} completed\n</source>
			<translation>Task {0} completed\n</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; Exception: {1}</source>
			<translation>Виняток у завданні &apos;{0}&apos;: {1}</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; execute function &apos;{1}&apos;</source>
			<translation>Task &apos;{0}&apos; execute function &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; execute procedure &apos;{1}&apos; with parameters: &apos;{2}&apos;, &apos;{3}&apos;, &apos;{4}&apos;</source>
			<translation>Завдання &apos;{0}&apos; виконує процедуру &apos;{1}&apos; з параметрами: &apos;{2}&apos;, &apos;{3}&apos;, &apos;{4}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; manage json response</source>
			<translation>Task &apos;{0}&apos; manage json response</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; manage json response with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Завдання &apos;{0}&apos; обробляє json-відповідь з параметрами: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; not successful but without exception</source>
			<translation>Завдання &apos;{0}&apos; не успішне, але без винятку</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; was cancelled</source>
			<translation>Завдання &apos;{0}&apos; було скасовано</translation>
		</message>
		<message>
			<source>Task aborted - {0}</source>
			<translation>Завдання скасовано - {0}</translation>
		</message>
		<message>
			<source>Task aborted: {0}.</source>
			<translation>Завдання скасовано: {0}.</translation>
		</message>
		<message>
			<source>Task canceled!</source>
			<translation>Task canceled!</translation>
		</message>
		<message>
			<source>Task canceled.</source>
			<translation>Task canceled.</translation>
		</message>
		<message>
			<source>Task canceled:</source>
			<translation>Task canceled:</translation>
		</message>
		<message>
			<source>Task canceled - {0}</source>
			<translation>Завдання скасовано - {0}</translation>
		</message>
		<message>
			<source>Task &apos;Check project&apos; execute function &apos;{0}&apos;</source>
			<translation>Завдання &apos;Перевірити проект&apos; виконує функцію &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>task_completed</source>
			<translation>task_completed</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute function &apos;{0}&apos; from &apos;{1}&apos; with parameters: &apos;{2}&apos;</source>
			<translation>Завдання &apos;Підключити зв&apos;язок&apos; виконує функцію &apos;{0}&apos; з &apos;{1}&apos; з параметрами: &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute function &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;</source>
			<translation>Завдання &apos;Підключити зв&apos;язок&apos; виконує функцію &apos;{0}&apos; з параметрами: &apos;{1}&apos;, &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute procedure &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Завдання &apos;Підключити зв&apos;язок&apos; виконує процедуру &apos;{0}&apos; з параметрами: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</translation>
		</message>
		<message>
			<source>Task failed: {0}. This is probably a DB error, check postgres function &apos;{1}&apos;.</source>
			<translation>Завдання не виконано: {0}. Ймовірно, це помилка БД, перевірте функцію postgres &apos;{1}&apos;.</translation>
		</message>
		<message>
			<source>Task finished!</source>
			<translation>Task finished!</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;{0}&apos;</source>
			<translation>Завдання &apos;Go2Epa&apos; виконує функцію &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;{0}&apos; from &apos;{1}&apos;</source>
			<translation>Завдання &apos;Go2Epa&apos; виконує функцію &apos;{0}&apos; з &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;def _exec_import_function&apos;</source>
			<translation>Завдання &apos;Go2Epa&apos; виконує функцію &apos;def _exec_import_function&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{0}&apos; step {1}</source>
			<translation>Завдання &apos;Go2Epa&apos; виконує процедуру &apos;{0}&apos;, крок {1}</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{1}&apos; step {2} with parameters: &apos;{1}&apos;, &apos;{3}&apos;, &apos;{4}&apos;, &apos;{5}&apos;, &apos;{6}&apos;</source>
			<translation>Завдання &apos;Go2Epa&apos; виконує процедуру &apos;{1}&apos; крок {2} з параметрами: &apos;{1}&apos;, &apos;{3}&apos;, &apos;{4}&apos;, &apos;{5}&apos;, &apos;{6}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Mincut execute&apos; execute procedure &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Завдання &apos;Mincut execute&apos; виконує процедуру &apos;{0}&apos; з параметрами: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Mincut execute&apos; manage json response with parameters: &apos;{0}&apos;, &apos;{1}&apos;, &apos;{2}&apos;</source>
			<translation>Завдання &apos;Mincut execute&apos; керує json-відповіддю з параметрами: &apos;{0}&apos;, &apos;{1}&apos;, &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Template not managed: {0}</source>
			<translation>Шаблон не обробляється: {0}</translation>
		</message>
		<message>
			<source>Temporal layer created successfully.</source>
			<translation>Тимчасовий шар успішно створено.</translation>
		</message>
		<message>
			<source>The &quot;{0}&quot; curve does not have a specified curve type and was not imported.</source>
			<translation>The &quot;{0}&quot; curve does not have a specified curve type and was not imported.</translation>
		</message>
		<message>
			<source>The &apos;{0}&apos; field is required.</source>
			<translation>Поле &apos;{0}&apos; є обов&apos;язковим.</translation>
		</message>
		<message>
			<source>The base language (en_US) cannot be deleted.</source>
			<translation>The base language (en_US) cannot be deleted.</translation>
		</message>
		<message>
			<source>The configuration file doesn&apos;t match the selected INP file. Some options may not be loaded or may be incorrect. Do you want to continue?</source>
			<translation>Файл конфігурації не відповідає обраному INP-файлу. Деякі параметри можуть не завантажитись або бути неправильними. Продовжити?</translation>
		</message>
		<message>
			<source>The connection to the database is broken.</source>
			<translation>The connection to the database is broken.</translation>
		</message>
		<message>
			<source>The connection to the database is broken: {0}</source>
			<translation>З&apos;єднання з базою даних перервано: {0}</translation>
		</message>
		<message>
			<source>The control &apos;{0}&apos; is already on database. Skipping...</source>
			<translation>The control &apos;{0}&apos; is already on database. Skipping...</translation>
		</message>
		<message>
			<source>The csv file has been successfully exported</source>
			<translation>CSV-файл успішно експортовано</translation>
		</message>
		<message>
			<source>The curve &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing curve.</source>
			<translation>The curve &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing curve.</translation>
		</message>
		<message>
			<source>The &apos;Description&apos; field is required.</source>
			<translation>Поле &apos;Опис&apos; є обов&apos;язковим.</translation>
		</message>
		<message>
			<source>The field layoutname is not configured for</source>
			<translation>Поле layoutname не налаштоване для</translation>
		</message>
		<message>
			<source>The field layoutorder is not configured for</source>
			<translation>Поле layoutorder не налаштоване для</translation>
		</message>
		<message>
			<source>The field widgettype is not configured for</source>
			<translation>Поле widgettype не налаштоване для</translation>
		</message>
		<message>
			<source>The fifth tab is the &apos;Arcs&apos; tab, where you can select the catalog for each type of arc on the network.</source>
			<translation>П&apos;ята вкладка — вкладка &apos;Arcs&apos;, де ви можете вибрати каталог для кожного типу дуг у мережі.</translation>
		</message>
		<message>
			<source>The file {0} already exists. Do you want to overwrite it?</source>
			<translation>Файл {0} вже існує. Перезаписати його?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.csv&quot; already exists. Do you want to overwrite it?</source>
			<translation>The file &quot;{0}.csv&quot; already exists. Do you want to overwrite it?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.in&quot; already exists. Do you want to overwrite it?</source>
			<translation>The file &quot;{0}.in&quot; already exists. Do you want to overwrite it?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.inp&quot; already exists. Do you want to overwrite it?</source>
			<translation>The file &quot;{0}.inp&quot; already exists. Do you want to overwrite it?</translation>
		</message>
		<message>
			<source>The files {0} already exist. Do you want to overwrite them?</source>
			<translation>Файли {0} вже існують. Перезаписати їх?</translation>
		</message>
		<message>
			<source>The files &quot;{0}.in&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</source>
			<translation>The files &quot;{0}.in&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</translation>
		</message>
		<message>
			<source>The files &quot;{0}.inp&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</source>
			<translation>The files &quot;{0}.inp&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</translation>
		</message>
		<message>
			<source>The file selected is not a GPKG file</source>
			<translation>Вибраний файл не є файлом GPKG</translation>
		</message>
		<message>
			<source>The file selected is not an INP file</source>
			<translation>Обраний Файл Не Є INP-Файлом</translation>
		</message>
		<message>
			<source>The first tab is the &apos;Basic&apos; tab, where you can select the exploitation, sector, municipality, and other basic information.</source>
			<translation>Перша вкладка — вкладка &apos;Basic&apos;, де можна вибрати експлуатацію, сектор, муніципалітет та іншу базову інформацію.</translation>
		</message>
		<message>
			<source>The flow data timestep must be a multiple of the desired timestep.</source>
			<translation>The flow data timestep must be a multiple of the desired timestep.</translation>
		</message>
		<message>
			<source>The following fields differ between the selected arcs. You are about to merge them using the selected values.\n\n{0}\n\nDo you want to continue?</source>
			<translation>The following fields differ between the selected arcs. You are about to merge them using the selected values.\n\n{0}\n\nDo you want to continue?</translation>
		</message>
		<message>
			<source>The fourth tab is the &apos;Nodes&apos; tab, where you can select the catalog for each type of node on the network.</source>
			<translation>Четверта вкладка — вкладка &apos;Nodes&apos;, де ви можете вибрати каталог для кожного типу вузлів у мережі.</translation>
		</message>
		<message>
			<source>The hour value must be between 0 and 23, inclusive. Value supplied: {0}</source>
			<translation>The hour value must be between 0 and 23, inclusive. Value supplied: {0}</translation>
		</message>
		<message>
			<source>The [JUNCTIONS] section of the configuration file is empty.</source>
			<translation>Розділ [JUNCTIONS] файлу конфігурації порожній.</translation>
		</message>
		<message>
			<source>The lid &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing lid.</source>
			<translation>The lid &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing lid.</translation>
		</message>
		<message>
			<source>The link &apos;{0}&apos; does not exist in the network.</source>
			<translation>The link &apos;{0}&apos; does not exist in the network.</translation>
		</message>
		<message>
			<source>The link &apos;{0}&apos; is not a pump.</source>
			<translation>The link &apos;{0}&apos; is not a pump.</translation>
		</message>
		<message>
			<source>The link &apos;{0}&apos; is not a valve.</source>
			<translation>The link &apos;{0}&apos; is not a valve.</translation>
		</message>
		<message>
			<source>The multilang language has been changed. To update the TOC and toolbar tooltips language, restart QGIS.</source>
			<translation>The multilang language has been changed. To update the TOC and toolbar tooltips language, restart QGIS.</translation>
		</message>
		<message>
			<source>The name is current in use</source>
			<translation>Ім&apos;я вже використовується</translation>
		</message>
		<message>
			<source>The node &apos;{0}&apos; does not exist in the network.</source>
			<translation>The node &apos;{0}&apos; does not exist in the network.</translation>
		</message>
		<message>
			<source>The node is obsolete, this tool doesn&apos;t work with obsolete nodes.</source>
			<translation>Вузол застарілий, цей інструмент не працює із застарілими вузлами.</translation>
		</message>
		<message>
			<source>The number of pages in your composition does not match the number of psectors. ({0} != {1})</source>
			<translation>The number of pages in your composition does not match the number of psectors. ({0} != {1})</translation>
		</message>
		<message>
			<source>The pattern &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing pattern.</source>
			<translation>The pattern &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing pattern.</translation>
		</message>
		<message>
			<source>The procedure will delete features on database unless it is a node that doesn&apos;t divide arcs.\nPlease ensure that features has no undelete value on true.\nOn the other hand you must know that traceability table will storage precedent information.</source>
			<translation>The procedure will delete features on database unless it is a node that doesn&apos;t divide arcs.\nPlease ensure that features has no undelete value on true.\nOn the other hand you must know that traceability table will storage precedent information.</translation>
		</message>
		<message>
			<source>The process has been executed. Files generated:</source>
			<translation>Процес виконано. Згенеровані файли:</translation>
		</message>
		<message>
			<source>The project name can&apos;t be a PostgreSQL reserved keyword</source>
			<translation>Ім&apos;я проекту не може бути зарезервованим ключовим словом PostgreSQL</translation>
		</message>
		<message>
			<source>The project name can&apos;t have any upper-case characters</source>
			<translation>Ім&apos;я проекту не може містити великі літери</translation>
		</message>
		<message>
			<source>The project name has invalid character</source>
			<translation>Ім&apos;я проекту містить недопустимий символ</translation>
		</message>
		<message>
			<source>The QGIS Projects templates was correctly created.</source>
			<translation>Шаблони проектів QGIS були успішно створені.</translation>
		</message>
		<message>
			<source>The QML file is invalid</source>
			<translation>Файл QML недійсний</translation>
		</message>
		<message>
			<source>The QML file is invalid.</source>
			<translation>Файл QML недійсний.</translation>
		</message>
		<message>
			<source>There are missing values in these nodes:</source>
			<translation>У цих вузлах відсутні значення:</translation>
		</message>
		<message>
			<source>There are multiple queries configured. These are the lists that will be used. Do you want to continue?</source>
			<translation>Налаштовано кілька запитів. Це списки, які будуть використані. Продовжити?</translation>
		</message>
		<message>
			<source>There are multple tabs in order to configure all the necessary catalogs.</source>
			<translation>Є декілька вкладок для налаштування всіх необхідних каталогів.</translation>
		</message>
		<message>
			<source>There are no results available to display.</source>
			<translation>Немає результатів для відображення.</translation>
		</message>
		<message>
			<source>There are no visible mincuts in the table. Try a different filter or make one</source>
			<translation>У таблиці немає видимих мінотрізків. Спробуйте інший фільтр або створіть його.</translation>
		</message>
		<message>
			<source>There are some error in the records with id</source>
			<translation>There are some error in the records with id</translation>
		</message>
		<message>
			<source>There are some topological inconsistences on psector &apos;{0}&apos;. Would you like to see the log?</source>
			<translation>There are some topological inconsistences on psector &apos;{0}&apos;. Would you like to see the log?</translation>
		</message>
		<message>
			<source>There have been errors translating:</source>
			<translation>Виникли помилки під час перекладу:</translation>
		</message>
		<message>
			<source>There is an error in the configuration of the pgservice file, please check it or consult your administrator</source>
			<translation>Помилка в конфігурації файлу pgservice, перевірте його або зверніться до адміністратора</translation>
		</message>
		<message>
			<source>There is an error in the configuration of the pgservice file, please check it or consult your administrator ({0})</source>
			<translation>There is an error in the configuration of the pgservice file, please check it or consult your administrator ({0})</translation>
		</message>
		<message>
			<source>There is another function dialog open.</source>
			<translation>There is another function dialog open.</translation>
		</message>
		<message>
			<source>There is another report open. Please close it first.</source>
			<translation>There is another report open. Please close it first.</translation>
		</message>
		<message>
			<source>There is a partially completed file for this folder/file name. Would you like to resume the process?</source>
			<translation>Для цієї папки/ім&apos;я файлу існує частково завершений файл. Бажаєте продовжити процес?</translation>
		</message>
		<message>
			<source>There is no data in table anl_arc for fid=491 and current user.</source>
			<translation>У таблиці anl_arc немає даних для fid=491 та поточного користувача.</translation>
		</message>
		<message>
			<source>There is no data in table anl_arc for fid=493 and current user.</source>
			<translation>У таблиці anl_arc немає даних для fid=493 і поточного користувача.</translation>
		</message>
		<message>
			<source>There is no project selected or it is not valid. Please check the first tab...</source>
			<translation>Проект не обрано або він недійсний. Будь ласка, перевірте першу вкладку...</translation>
		</message>
		<message>
			<source>There is no valid shape curve in the list</source>
			<translation>У списку немає дійсної кривої форми</translation>
		</message>
		<message>
			<source>The result cannot be deleted</source>
			<translation>Результат не можна видалити</translation>
		</message>
		<message>
			<source>There was an error deleting object.</source>
			<translation>Сталася помилка під час видалення об&apos;єкта.</translation>
		</message>
		<message>
			<source>There was an error deleting object values.</source>
			<translation>Сталася помилка під час видалення значень об&apos;єкта.</translation>
		</message>
		<message>
			<source>There was an error deleting old curve values.</source>
			<translation>Сталася помилка під час видалення старих значень кривої.</translation>
		</message>
		<message>
			<source>There was an error deleting old lid values.</source>
			<translation>Сталася помилка під час видалення старих значень LID.</translation>
		</message>
		<message>
			<source>There was an error deleting old pattern values.</source>
			<translation>Сталася помилка під час видалення старих значень шаблону.</translation>
		</message>
		<message>
			<source>There was an error deleting old timeseries values.</source>
			<translation>Під час видалення старих значень часових рядів сталася помилка.</translation>
		</message>
		<message>
			<source>There was an error inserting control.</source>
			<translation>Під час додавання контролю сталася помилка.</translation>
		</message>
		<message>
			<source>There was an error inserting curve.</source>
			<translation>Під час додавання кривої сталася помилка.</translation>
		</message>
		<message>
			<source>There was an error inserting curve value.</source>
			<translation>Під час додавання значення кривої сталася помилка.</translation>
		</message>
		<message>
			<source>There was an error inserting lid.</source>
			<translation>Під час додавання кришки сталася помилка.</translation>
		</message>
		<message>
			<source>There was an error inserting pattern.</source>
			<translation>Під час додавання шаблону сталася помилка.</translation>
		</message>
		<message>
			<source>There was an error inserting pattern value.</source>
			<translation>Під час додавання значення шаблону сталася помилка.</translation>
		</message>
		<message>
			<source>There was an error inserting timeseries.</source>
			<translation>Під час додавання часових рядів сталася помилка.</translation>
		</message>
		<message>
			<source>There were velocities &gt;50 in the rpt file. You have activated the option to force the import so they have been set to 50.</source>
			<translation>У rpt-файлі були швидкості &gt;50. Ви активували опцію примусового імпорту, тому вони були встановлені на 50.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlaped, it seems you need to improve your simulation. Please ckeck and fix it before continue. \n{0}</source>
			<translation>The rpt file is not valid to import. Because columns on rpt file are overlaped, it seems you need to improve your simulation. Please ckeck and fix it before continue. \n{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlapped, it seems you need to improve your simulation. Please check and fix it before continuing.\n{0}</source>
			<translation>The rpt file is not valid to import. Because columns on rpt file are overlapped, it seems you need to improve your simulation. Please check and fix it before continuing.\n{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. \n{0}</source>
			<translation>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. \n{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. \nNote: You can force the import by activating the variable &apos;{0}&apos; on the {1} file. \n{2}</source>
			<translation>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. \nNote: You can force the import by activating the variable &apos;{0}&apos; on the {1} file. \n{2}</translation>
		</message>
		<message>
			<source>The rule &apos;{0}&apos; is already on database. Skipping...</source>
			<translation>The rule &apos;{0}&apos; is already on database. Skipping...</translation>
		</message>
		<message>
			<source>The [SCENARIOS] section of the configuration file is empty.</source>
			<translation>Розділ [SCENARIOS] файлу конфігурації порожній.</translation>
		</message>
		<message>
			<source>The schema ({0}) does not exists</source>
			<translation>Схема ({0}) не існує</translation>
		</message>
		<message>
			<source>The schema &apos;{0}&apos; is being used in production! It can&apos;t be deleted.</source>
			<translation>Схема &apos;{0}&apos; використовується в продукції! Її не можна видалити.</translation>
		</message>
		<message>
			<source>The schema version has to be updated to make rename</source>
			<translation>Версію схеми потрібно оновити, щоб виконати перейменування</translation>
		</message>
		<message>
			<source>These are the lists that will be used. Do you want to continue?</source>
			<translation>Це списки, які будуть використані. Продовжити?</translation>
		</message>
		<message>
			<source>The second tab is the &apos;Features&apos; tab, where you can select the corresponding feature classes for each type of feature on the network.</source>
			<translation>Друга вкладка — вкладка «Елементи», де ви можете обрати відповідні класи елементів для кожного типу елемента мережі.</translation>
		</message>
		<message>
			<source>The selected node is planified in another psector.\nNode psector: {0}\nCurrent psector: {1}</source>
			<translation>The selected node is planified in another psector.\nNode psector: {0}\nCurrent psector: {1}</translation>
		</message>
		<message>
			<source>The selected node should have exactly two linked arcs.</source>
			<translation>Вибраний вузол повинен мати точно два пов&apos;язані дуги.</translation>
		</message>
		<message>
			<source>These links could not be located within the network: </source>
			<translation>Ці зв&apos;язки не вдалося знайти в мережі:</translation>
		</message>
		<message>
			<source>These pipes will NOT be assigned a priority value as the configured unknown material, {1}, is not listed in the configuration tab for materials.</source>
			<translation>Цим трубам НЕ буде призначено значення пріоритету, оскільки налаштований невідомий матеріал, {1}, не вказаний на вкладці конфігурації матеріалів.</translation>
		</message>
		<message>
			<source>The start date must be before the end date</source>
			<translation>Дата початку має бути раніше дати завершення</translation>
		</message>
		<message>
			<source>The start date real must be before the end date real</source>
			<translation>Реальна дата початку має бути раніше реальної дати завершення</translation>
		</message>
		<message>
			<source>The sum of weights must equal 1. Please adjust the values accordingly.</source>
			<translation>Сума ваг має дорівнювати 1. Будь ласка, відповідно відкоригуйте значення.</translation>
		</message>
		<message>
			<source>The table ({0}) does not exists</source>
			<translation>Таблиця ({0}) не існує</translation>
		</message>
		<message>
			<source>The table &apos;plan_psector&apos; contains NULL values in the column &apos;atlas_id&apos;. Please fix this before continuing.</source>
			<translation>У таблиці &apos;plan_psector&apos; є NULL-значення в стовпці &apos;atlas_id&apos;. Будь ласка, виправте це перед продовженням.</translation>
		</message>
		<message>
			<source>The target year must be between {0} and {1}.</source>
			<translation>Цільовий рік має бути між {0} та {1}.</translation>
		</message>
		<message>
			<source>The team name already exists</source>
			<translation>The team name already exists</translation>
		</message>
		<message>
			<source>The template &apos;{0}&apos; is missing some expected items: {1}. The layout will open, but these features won&apos;t be automatically configured. Make sure your template includes items with IDs: &apos;Mapa&apos; (for the map) and &apos;title&apos; (for the title).</source>
			<translation>The template &apos;{0}&apos; is missing some expected items: {1}. The layout will open, but these features won&apos;t be automatically configured. Make sure your template includes items with IDs: &apos;Mapa&apos; (for the map) and &apos;title&apos; (for the title).</translation>
		</message>
		<message>
			<source>The third tab is the &apos;Materials&apos; tab, where you can select the corresponding material for each roughness value.</source>
			<translation>Третя вкладка — вкладка «Матеріали», де ви можете обрати відповідний матеріал для кожного значення шорсткості.</translation>
		</message>
		<message>
			<source>The third tab is the &apos;Materials&apos; tab, where you can select the corresponding roughness value for each material.</source>
			<translation>Третя вкладка — вкладка &apos;Materials&apos;, де ви можете вибрати відповідне значення шорсткості для кожного матеріалу.</translation>
		</message>
		<message>
			<source>The timeseries &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing timeseries.</source>
			<translation>The timeseries &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing timeseries.</translation>
		</message>
		<message>
			<source>The timeseries &quot;{0}&quot; was not imported.</source>
			<translation>The timeseries &quot;{0}&quot; was not imported.</translation>
		</message>
		<message>
			<source>The user config files have been recreated. A backup of the broken ones have been created at</source>
			<translation>Файли конфігурації користувача були відтворені. Резервні копії пошкоджених файлів створені за адресою</translation>
		</message>
		<message>
			<source>The Workcat_id &quot;{0}&quot; is already in use. Please enter a different ID.</source>
			<translation>The Workcat_id &quot;{0}&quot; is already in use. Please enter a different ID.</translation>
		</message>
		<message>
			<source>This action cannot be undone. Do you want to proceed?</source>
			<translation>This action cannot be undone. Do you want to proceed?</translation>
		</message>
		<message>
			<source>This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector</source>
			<translation>Цю поведінку можна налаштувати в таблиці &apos;config_param_system&apos; (параметр = &apos;basic_selector</translation>
		</message>
		<message>
			<source>This dma doesn&apos;t exist</source>
			<translation>Такий dma не існує</translation>
		</message>
		<message>
			<source>This feature has no log changes, please update this feature before.</source>
			<translation>У цього елемента немає змін у журналі, будь ласка, оновіть цей елемент раніше.</translation>
		</message>
		<message>
			<source>This functionality is only allowed with the locality &apos;en_US&apos; and SRID 25831.\nDo you want change it and continue?</source>
			<translation>This functionality is only allowed with the locality &apos;en_US&apos; and SRID 25831.\nDo you want change it and continue?</translation>
		</message>
		<message>
			<source>This parameter is mandatory. Please, set a value</source>
			<translation>Цей параметр є обов&apos;язковим. Будь ласка, вкажіть значення</translation>
		</message>
		<message>
			<source>This presszone doesn&apos;t exist</source>
			<translation>Ця presszone не існує</translation>
		</message>
		<message>
			<source>This process will active snapshot. Are you sure to continue?</source>
			<translation>Цей процес активує знімок. Ви впевнені, що хочете продовжити?</translation>
		</message>
		<message>
			<source>This process will take a few seconds. Are you sure to continue?</source>
			<translation>Цей процес займе кілька секунд. Ви впевнені, що хочете продовжити?</translation>
		</message>
		<message>
			<source>This process will take time (few minutes). Are you sure to continue?</source>
			<translation>Цей процес займе певний час (кілька хвилин). Ви впевнені, що хочете продовжити?</translation>
		</message>
		<message>
			<source>This &apos;Project_name&apos; already exist. Do you want rename old schema to &apos;{0}&apos;</source>
			<translation>Цей &apos;Project_name&apos; вже існує. Ви хочете перейменувати стару схему на &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>This project name alredy exist.</source>
			<translation>Назва цього проєкту вже існує.</translation>
		</message>
		<message>
			<source>This result name already exists</source>
			<translation>Назва цього результату вже існує</translation>
		</message>
		<message>
			<source>This SRID value does not exist on Postgres Database. Please select a diferent one.</source>
			<translation>Це значення SRID не існує в базі даних Postgres. Будь ласка, виберіть інше.</translation>
		</message>
		<message>
			<source>This task may take some time to complete, do you want to proceed?</source>
			<translation>Ця задача може зайняти деякий час для виконання, чи бажаєте продовжити?</translation>
		</message>
		<message>
			<source>This will also delete the database user(s):</source>
			<translation>Це також видалить користувача(ів) бази даних:</translation>
		</message>
		<message>
			<source>!!!!! THIS WILL DELETE ALL DATA IN THE DATABASE !!!!!\nARE YOU SURE YOU WANT TO PROCEED?</source>
			<translation>!!!!! THIS WILL DELETE ALL DATA IN THE DATABASE !!!!!\nARE YOU SURE YOU WANT TO PROCEED?</translation>
		</message>
		<message>
			<source>This will modify your inp file, so a backup will be created.\nDo you want to proceed?</source>
			<translation>This will modify your inp file, so a backup will be created.\nDo you want to proceed?</translation>
		</message>
		<message>
			<source>This wizard will help with the process of importing a network from a {0} INP file into the Giswater database.</source>
			<translation>Цей майстер допоможе в процесі імпорту мережі з {0} INP файлу в базу даних Giswater.</translation>
		</message>
		<message>
			<source>This Workcat already exist</source>
			<translation>Цей Workcat вже існує</translation>
		</message>
		<message>
			<source>This Workcat is already exist</source>
			<translation>Цей Workcat вже існує</translation>
		</message>
		<message>
			<source>Timestep for input flows not informed.</source>
			<translation>Timestep for input flows not informed.</translation>
		</message>
		<message>
			<source>Title item &apos;title&apos; not found in template. Template may be empty or use different item IDs.</source>
			<translation>Title item &apos;title&apos; not found in template. Template may be empty or use different item IDs.</translation>
		</message>
		<message>
			<source>To add:</source>
			<translation>To add:</translation>
		</message>
		<message>
			<source>Toggle active</source>
			<translation>Toggle active</translation>
		</message>
		<message>
			<source>Toggle Active</source>
			<translation>Toggle Active</translation>
		</message>
		<message>
			<source>To make the result id {0} corporate, is necessary to make not corporate the following result ids: {1}. Do you want to proceed?</source>
			<translation>Щоб зробити результат id {0} корпоративним, необхідно зробити некорпоративними наступні id результатів: {1}. Бажаєте продовжити?</translation>
		</message>
		<message>
			<source>Toolbox task is already active!</source>
			<translation>Задача Toolbox вже активна!</translation>
		</message>
		<message>
			<source>Too many actions on CONTROL &apos;{0}&apos;</source>
			<translation>Too many actions on CONTROL &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>To remove:</source>
			<translation>To remove:</translation>
		</message>
		<message>
			<source>Total</source>
			<translation>Total</translation>
		</message>
		<message>
			<source>Total municipalities processed: {0}</source>
			<translation>Загальна кількість оброблених муніципалітетів: {0}</translation>
		</message>
		<message>
			<source>translation canceled</source>
			<translation>переклад скасовано</translation>
		</message>
		<message>
			<source>translation failed in table</source>
			<translation>не вдалося перекласти в таблиці</translation>
		</message>
		<message>
			<source>translation successful</source>
			<translation>переклад успішний</translation>
		</message>
		<message>
			<source>Tried to set {0} to &apos;{1}&apos; but it&apos;s not an integer. Defaulting to 4 threads.</source>
			<translation>Спробували встановити {0} у &apos;{1}&apos;, але це не ціле число. Використовується значення за замовчуванням: 4 потоки.</translation>
		</message>
		<message>
			<source>Triggers updated successfully</source>
			<translation>Триґери успішно оновлено</translation>
		</message>
		<message>
			<source>Try again</source>
			<translation>Спробуйте ще раз</translation>
		</message>
		<message>
			<source>Typeahead &apos;{0}&apos; doesn&apos;t have neither a queryText nor comboIds/comboNames.</source>
			<translation>Typeahead &apos;{0}&apos; не має ні queryText, ні comboIds/comboNames.</translation>
		</message>
		<message>
			<source>Type to search...</source>
			<translation>Type to search...</translation>
		</message>
		<message>
			<source>Unable to activate psector. </source>
			<translation>Unable to activate psector.</translation>
		</message>
		<message>
			<source>Unable to highlight the snapped arc.</source>
			<translation>Unable to highlight the snapped arc.</translation>
		</message>
		<message>
			<source>Unable to highlight the snapped node.</source>
			<translation>Не вдалося виділити зафіксований вузол.</translation>
		</message>
		<message>
			<source>Unexpected languages payload from ({0})</source>
			<translation>Unexpected languages payload from ({0})</translation>
		</message>
		<message>
			<source>Unexpected languages payload from {0}</source>
			<translation>Unexpected languages payload from {0}</translation>
		</message>
		<message>
			<source>Unhandled Error</source>
			<translation>Непередбачена помилка</translation>
		</message>
		<message>
			<source>Unit for values of input flows not informed.</source>
			<translation>Unit for values of input flows not informed.</translation>
		</message>
		<message>
			<source>Units not specified in the INP file.</source>
			<translation>Units not specified in the INP file.</translation>
		</message>
		<message>
			<source>Unknown control for EPANET INP files: {0}</source>
			<translation>Unknown control for EPANET INP files: {0}</translation>
		</message>
		<message>
			<source>Unknown error</source>
			<translation>Unknown error</translation>
		</message>
		<message>
			<source>Unrecognised form type</source>
			<translation>Невідомий тип форми</translation>
		</message>
		<message>
			<source>Unsafe path in ZIP archive: {0}</source>
			<translation>Unsafe path in ZIP archive: {0}</translation>
		</message>
		<message>
			<source>Unsuported geometry type</source>
			<translation>Непідтримуваний тип геометрії</translation>
		</message>
		<message>
			<source>Unsupported compare mode: {0}</source>
			<translation>Unsupported compare mode: {0}</translation>
		</message>
		<message>
			<source>Unsupported layer_type: {0}</source>
			<translation>Unsupported layer_type: {0}</translation>
		</message>
		<message>
			<source>Unsupported operation: {0}</source>
			<translation>Unsupported operation: {0}</translation>
		</message>
		<message>
			<source>Unsupported project type for hydraulic engine: {0}</source>
			<translation>Unsupported project type for hydraulic engine: {0}</translation>
		</message>
		<message>
			<source>Unsupported URI encoding: {0}</source>
			<translation>Unsupported URI encoding: {0}</translation>
		</message>
		<message>
			<source>Unsupported widget type: {0}</source>
			<translation>Unsupported widget type: {0}</translation>
		</message>
		<message>
			<source>Update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>Update {0} ({1})</source>
			<translation>Update {0} ({1})</translation>
		</message>
		<message>
			<source>Update AM Layers Symbology</source>
			<translation>Update AM Layers Symbology</translation>
		</message>
		<message>
			<source>Update am schema</source>
			<translation>Update am schema</translation>
		</message>
		<message>
			<source>Update audit schema</source>
			<translation>Update audit schema</translation>
		</message>
		<message>
			<source>Update cibs schema</source>
			<translation>Update cibs schema</translation>
		</message>
		<message>
			<source>Update cm schema</source>
			<translation>Update cm schema</translation>
		</message>
		<message>
			<source>Update configuration</source>
			<translation>Оновити конфігурацію</translation>
		</message>
		<message>
			<source>Update Confirmation</source>
			<translation>Підтвердження оновлення</translation>
		</message>
		<message>
			<source>Update field on &quot;{0}&quot;</source>
			<translation>Update field on &quot;{0}&quot;</translation>
		</message>
		<message>
			<source>Update language files?</source>
			<translation>Update language files?</translation>
		</message>
		<message>
			<source>Update multi field</source>
			<translation>Update multi field</translation>
		</message>
		<message>
			<source>Update multilang schema</source>
			<translation>Update multilang schema</translation>
		</message>
		<message>
			<source>Update Multilang translation?</source>
			<translation>Update Multilang translation?</translation>
		</message>
		<message>
			<source>Update multilang translations?</source>
			<translation>Update multilang translations?</translation>
		</message>
		<message>
			<source>Update multilang translations for ({0})</source>
			<translation>Update multilang translations for ({0})</translation>
		</message>
		<message>
			<source>Update network requires a WS or UD anchor.</source>
			<translation>Update network requires a WS or UD anchor.</translation>
		</message>
		<message>
			<source>Update records</source>
			<translation>Оновити записи</translation>
		</message>
		<message>
			<source>Update translation?</source>
			<translation>Update translation?</translation>
		</message>
		<message>
			<source>Updating {0}...</source>
			<translation>Оновлення {0}...</translation>
		</message>
		<message>
			<source>Updating language files for ({0})...</source>
			<translation>Updating language files for ({0})...</translation>
		</message>
		<message>
			<source>Updating multilang translations for ({0})...</source>
			<translation>Updating multilang translations for ({0})...</translation>
		</message>
		<message>
			<source>Updating municipality...</source>
			<translation>Updating municipality...</translation>
		</message>
		<message>
			<source>Updating tables</source>
			<translation>Updating tables</translation>
		</message>
		<message>
			<source>User</source>
			<translation>User</translation>
		</message>
		<message>
			<source>User not found</source>
			<translation>Користувача не знайдено</translation>
		</message>
		<message>
			<source>Utils schema does not exist. Create it first.</source>
			<translation>Utils schema does not exist. Create it first.</translation>
		</message>
		<message>
			<source>Vacuum executed: {0}.{1}</source>
			<translation>Вакуум виконано: {0}.{1}</translation>
		</message>
		<message>
			<source>Validate inputs</source>
			<translation>Validate inputs</translation>
		</message>
		<message>
			<source>Validating inputs...</source>
			<translation>Validating inputs...</translation>
		</message>
		<message>
			<source>Value_distribution must be SIMPLE or HOURLY.</source>
			<translation>Value_distribution must be SIMPLE or HOURLY.</translation>
		</message>
		<message>
			<source>Value in addparam must be in a json format</source>
			<translation>Значення в addparam має бути у форматі json</translation>
		</message>
		<message>
			<source>Values for input flows not informed.</source>
			<translation>Values for input flows not informed.</translation>
		</message>
		<message>
			<source>Values has been updated</source>
			<translation>Значення було оновлено</translation>
		</message>
		<message>
			<source>Values saved successfully.</source>
			<translation>Значення успішно збережено.</translation>
		</message>
		<message>
			<source>Valve Operation Check</source>
			<translation>Valve Operation Check</translation>
		</message>
		<message>
			<source>Valves couldn&apos;t be inserted!</source>
			<translation>Valves couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Valve type not recognized: {0}</source>
			<translation>Valve type not recognized: {0}</translation>
		</message>
		<message>
			<source>Variable log_sql from user config file has been disabled.</source>
			<translation>Змінна log_sql з файлу конфігурації користувача була відключена.</translation>
		</message>
		<message>
			<source>Variable log_sql from user config file has been enabled.</source>
			<translation>Змінна log_sql з файлу конфігурації користувача була увімкнена.</translation>
		</message>
		<message>
			<source>Version</source>
			<translation>Версія</translation>
		</message>
		<message>
			<source>Visual objects</source>
			<translation>Visual objects</translation>
		</message>
		<message>
			<source>Warning</source>
			<translation>Попередження</translation>
		</message>
		<message>
			<source>WARNING</source>
			<translation>ПОПЕРЕДЖЕННЯ</translation>
		</message>
		<message>
			<source>Warning: Are you sure to continue?. This button will update your plugin qgis templates file replacing all strings defined on the config/dev.config file. Be sure your config file is OK before continue</source>
			<translation>Попередження: Ви впевнені, що хочете продовжити? Ця кнопка оновить файл шаблонів плагіна qgis, замінюючи всі рядки, визначені у файлі config/dev.config. Переконайтеся, що ваш файл конфігурації в порядку перед продовженням</translation>
		</message>
		<message>
			<source>WARNING: This will remove the &apos;utils_workspace_current&apos; variable for your user!\nAre you sure you want to delete these records?</source>
			<translation>WARNING: This will remove the &apos;utils_workspace_current&apos; variable for your user!\nAre you sure you want to delete these records?</translation>
		</message>
		<message>
			<source>We are downloading the necessary language files. Please do not close QGIS.</source>
			<translation>We are downloading the necessary language files. Please do not close QGIS.</translation>
		</message>
		<message>
			<source>Weir</source>
			<translation>Weir</translation>
		</message>
		<message>
			<source>Weirs couldn&apos;t be inserted!</source>
			<translation>Weirs couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>widget {0} has associated function {1}, but {2} not exist</source>
			<translation>віджет {0} має пов&apos;язану функцію {1}, але {2} не існує</translation>
		</message>
		<message>
			<source>widget {0} has not columnname and can&apos;t be configured</source>
			<translation>віджет {0} не має імені стовпця і не може бути налаштований</translation>
		</message>
		<message>
			<source>widget {0} has not columnname and cant be configured</source>
			<translation>віджет {0} не має імені стовпця і не може бути налаштований</translation>
		</message>
		<message>
			<source>widget {0} have associated function {1}, but {2} not exist</source>
			<translation>віджет {0} має пов&apos;язану функцію {1}, але {2} не існує</translation>
		</message>
		<message>
			<source>widget {0} in tab {1} has not columnname and can&apos;t be configured</source>
			<translation>віджет {0} на вкладці {1} не має імені стовпця і не може бути налаштований</translation>
		</message>
		<message>
			<source>widget {0} in tab {1} has not columnname and cant be configured</source>
			<translation>віджет {0} на вкладці {1} не має імені стовпця і не може бути налаштований</translation>
		</message>
		<message>
			<source>Widget {0} is not configured or have a bad config</source>
			<translation>Віджет {0} не налаштовано або має неправильну конфігурацію</translation>
		</message>
		<message>
			<source>Widget &apos;{0}&apos; not found in the composer</source>
			<translation>Widget &apos;{0}&apos; not found in the composer</translation>
		</message>
		<message>
			<source>Widget &apos;{0}&apos; not found in the dialog.</source>
			<translation>Widget &apos;{0}&apos; not found in the dialog.</translation>
		</message>
		<message>
			<source>Widget: {0} not in form.</source>
			<translation>Віджет: {0} не в формі.</translation>
		</message>
		<message>
			<source>Widget expl_id not found</source>
			<translation>Віджет expl_id не знайдено</translation>
		</message>
		<message>
			<source>Widget is not a QTableView</source>
			<translation>Widget is not a QTableView</translation>
		</message>
		<message>
			<source>Widget model is none: {0}</source>
			<translation>Модель віджета відсутня: {0}</translation>
		</message>
		<message>
			<source>widgetname not found. </source>
			<translation>віджет не знайдено.</translation>
		</message>
		<message>
			<source>Widget not found</source>
			<translation>Віджет не знайдено</translation>
		</message>
		<message>
			<source>widgettype is wrongly configured. Needs to be in </source>
			<translation>Тип віджета налаштований неправильно. Має бути в</translation>
		</message>
		<message>
			<source>widgettype not found. </source>
			<translation>widgettype не знайдено.</translation>
		</message>
		<message>
			<source>Workcat created successfully.</source>
			<translation>Категорія робіт успішно створена.</translation>
		</message>
		<message>
			<source>Work_id field is empty</source>
			<translation>Поле Work_id порожнє</translation>
		</message>
		<message>
			<source>Write inp file........: {0}</source>
			<translation>Записати inp файл........: {0}</translation>
		</message>
		<message>
			<source>Wrong number of parameters for node {0} in config file.</source>
			<translation>Wrong number of parameters for node {0} in config file.</translation>
		</message>
		<message>
			<source>You are about to adapt schema &apos;{0}&apos; to cibs.\n\nAre you sure you want to continue?</source>
			<translation>You are about to adapt schema &apos;{0}&apos; to cibs.\n\nAre you sure you want to continue?</translation>
		</message>
		<message>
			<source>You are about to delete the result</source>
			<translation>Ви збираєтеся видалити результат</translation>
		</message>
		<message>
			<source>You are about to import the INP file in TESTING MODE. This will delete all the data in the database related to the network you are importing. Are you sure you want to proceed?</source>
			<translation>Ви збираєтесь імпортувати файл INP У РЕЖИМІ ТЕСТУВАННЯ. Це видалить усі дані в базі даних, пов&apos;язані з мережею, яку ви імпортуєте. Ви певні, що бажаєте продовжити?</translation>
		</message>
		<message>
			<source>You are about to integrate AM with the following WS schema: {0}\n\nAre you sure you want to continue?</source>
			<translation>You are about to integrate AM with the following WS schema: {0}\n\nAre you sure you want to continue?</translation>
		</message>
		<message>
			<source>You are about to perform this action aiming to the following schema: {0}\n\nAre you sure you want to continue?</source>
			<translation>You are about to perform this action aiming to the following schema: {0}\n\nAre you sure you want to continue?</translation>
		</message>
		<message>
			<source>You are going to change the epa_type. With this operation you will lose information about current epa_type values of this object. Would you like to continue?</source>
			<translation>Ви збираєтеся змінити epa_type. Внаслідок цієї операції ви втратите інформацію про поточні значення epa_type цього об&apos;єкта. Продовжити?</translation>
		</message>
		<message>
			<source>You are going to make this result corporate. From now on the result values will appear on feature form. Do you want to continue?</source>
			<translation>Ви збираєтеся зробити цей результат корпоративним. Відтепер значення результатів з&apos;являтимуться у формі елемента. Продовжити?</translation>
		</message>
		<message>
			<source>You are not enabled to modify this {0} widget</source>
			<translation>Вам не дозволено змінювати цей віджет {0}</translation>
		</message>
		<message>
			<source>You are trying to add/remove a record from the table, with changes to the current records. If you continue, the changes will be discarded without saving. Do you want to continue?</source>
			<translation>Ви намагаєтеся додати/видалити запис з таблиці, змінюючи поточні записи. Якщо продовжити, зміни будуть відкинуті без збереження. Продовжити?</translation>
		</message>
		<message>
			<source>You are trying to add/remove a record from the table, with changes to the current records.If you continue, the changes will be discarded without saving. Do you want to continue?</source>
			<translation>Ви намагаєтеся додати/видалити запис з таблиці, змінюючи поточні записи. Якщо продовжити, зміни будуть відкинуті без збереження. Продовжити?</translation>
		</message>
		<message>
			<source>You are trying to delete your current psector. Please, change your current psector before delete.</source>
			<translation>Ви намагаєтесь видалити поточний psector. Будь ласка, змініть поточний psector перед видаленням.</translation>
		</message>
		<message>
			<source>You cannot change the status of a result with status &apos;FINISHED&apos;.</source>
			<translation>Ви не можете змінити статус результату зі статусом &apos;FINISHED&apos;.</translation>
		</message>
		<message>
			<source>You cannot insert more than one feature at the same time, finish editing the previous feature</source>
			<translation>Ви Не Можете Вставляти Більше Одного Об&apos;єкта Одночасно, Завершіть Редагування Попереднього Об&apos;єкта</translation>
		</message>
		<message>
			<source>You can only delete results with the status &apos;CANCELED&apos;.</source>
			<translation>You can only delete results with the status &apos;CANCELED&apos;.</translation>
		</message>
		<message>
			<source>You can save the current configuration to a file and load it later, or load the last saved configuration.</source>
			<translation>Ви Можете Зберегти Поточну Конфігурацію У Файл І Завантажити Її Пізніше, Або Завантажити Останню Збережену Конфігурацію.</translation>
		</message>
		<message>
			<source>You can&apos;t delete these mincuts because they aren&apos;t planified \nor they were created by another user:</source>
			<translation>You can&apos;t delete these mincuts because they aren&apos;t planified \nor they were created by another user:</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time.</source>
			<translation>Ви закрили клапан, це змінить поточні зони карти і може зайняти трохи часу.</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time. Would you like to continue?</source>
			<translation>Ви закрили клапан, це змінить поточні зони карти і може зайняти трохи часу. Бажаєте продовжити?</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time.Would you like to continue?</source>
			<translation>Ви закрили клапан, це змінить поточні зони карти і може зайняти трохи часу. Бажаєте продовжити?</translation>
		</message>
		<message>
			<source>You do not have permission to execute this application</source>
			<translation>У вас немає дозволу на запуск цього додатку</translation>
		</message>
		<message>
			<source>You don&apos;t have any connection to PostGIS database configurated. Check your QGIS data source manager and create at least one</source>
			<translation>У вас немає налаштованого підключення до бази даних PostGIS. Перевірте менеджер джерел даних QGIS і створіть принаймні одне</translation>
		</message>
		<message>
			<source>You have selected multiple documents. In this case, name will be a sequential number for all selected documents and your name won&apos;t be used.</source>
			<translation>Ви вибрали декілька документів. У цьому випадку ім&apos;я буде послідовним номером для всіх вибраних документів і ваше ім&apos;я не буде використано.</translation>
		</message>
		<message>
			<source>You have to fill in &apos;date&apos;, &apos;time&apos; and &apos;value&apos; fields!</source>
			<translation>Ви повинні заповнити поля &apos;date&apos;, &apos;time&apos; та &apos;value&apos;!</translation>
		</message>
		<message>
			<source>You have to fill in &apos;time&apos; and &apos;value&apos; fields!</source>
			<translation>Ви повинні заповнити поля &apos;time&apos; та &apos;value&apos;!</translation>
		</message>
		<message>
			<source>You have to import a ibergis GPKG project first</source>
			<translation>Спочатку потрібно імпортувати проєкт IBERGIS у форматі GPKG</translation>
		</message>
		<message>
			<source>You have to set this parameter</source>
			<translation>Ви повинні встановити цей параметр</translation>
		</message>
		<message>
			<source>You have to set this parameter: INP file</source>
			<translation>Ви повинні встановити цей параметр: файл INP</translation>
		</message>
		<message>
			<source>You have unsaved changes in the campaign selector. Close without saving?</source>
			<translation>You have unsaved changes in the campaign selector. Close without saving?</translation>
		</message>
		<message>
			<source>You must choose at least one action</source>
			<translation>Ви повинні вибрати принаймні одну дію</translation>
		</message>
		<message>
			<source>You must select two different points</source>
			<translation>Ви повинні вибрати дві різні точки</translation>
		</message>
		<message>
			<source>You need at least one row of values.</source>
			<translation>Потрібен щонайменше один рядок зі значеннями.</translation>
		</message>
		<message>
			<source>You need to enter a customer code</source>
			<translation>Ви повинні ввести код клієнта</translation>
		</message>
		<message>
			<source>You need to enter a feature id</source>
			<translation>Ви повинні ввести id елемента</translation>
		</message>
		<message>
			<source>You need to enter a psector name</source>
			<translation>Вам потрібно ввести назву psector</translation>
		</message>
		<message>
			<source>You need to enter a visit ID</source>
			<translation>Необхідно ввести ID візиту</translation>
		</message>
		<message>
			<source>You need to enter a workcat id</source>
			<translation>Вам потрібно ввести ідентифікатор workcat</translation>
		</message>
		<message>
			<source>You need to enter hydrometer_id</source>
			<translation>Ви повинні ввести hydrometer_id</translation>
		</message>
		<message>
			<source>You need to have a mesh</source>
			<translation>Потрібно мати сітку</translation>
		</message>
		<message>
			<source>You need to insert a document name</source>
			<translation>Вам потрібно ввести назву документа</translation>
		</message>
		<message>
			<source>You need to insert data</source>
			<translation>Вам потрібно вставити дані</translation>
		</message>
		<message>
			<source>You need to insert psector_id</source>
			<translation>Вам потрібно вставити psector_id</translation>
		</message>
		<message>
			<source>You need to insert visit_id</source>
			<translation>Вам потрібно вставити visit_id</translation>
		</message>
		<message>
			<source>You need to reexecute the mincut</source>
			<translation>You need to reexecute the mincut</translation>
		</message>
		<message>
			<source>You need to select a template</source>
			<translation>Вам потрібно вибрати шаблон</translation>
		</message>
		<message>
			<source>You need to select at least one process</source>
			<translation>Вам потрібно вибрати щонайменше один процес</translation>
		</message>
		<message>
			<source>You need to select a valid parameter id</source>
			<translation>Вам потрібно вибрати дійсний ідентифікатор параметра</translation>
		</message>
		<message>
			<source>You need to select some sector</source>
			<translation>Вам потрібно вибрати якийсь сектор</translation>
		</message>
		<message>
			<source>Your composer&apos;s path is bad configured. Please, modify it and try again.</source>
			<translation>Шлях composer налаштовано неправильно. Будь ласка, змініть його та спробуйте знову.</translation>
		</message>
		<message>
			<source>Your exploitation selector has been updated</source>
			<translation>Ваш селектор експлуатації було оновлено</translation>
		</message>
		<message>
			<source>You should inform a file name!</source>
			<translation>Вам слід вказати ім&apos;я файлу!</translation>
		</message>
		<message>
			<source>You should select a config file!</source>
			<translation>Вам слід вибрати файл конфігурації!</translation>
		</message>
		<message>
			<source>You should select an config file!</source>
			<translation>Вам слід вибрати файл конфігурації!</translation>
		</message>
		<message>
			<source>You should select an input INP file!</source>
			<translation>Вам слід вибрати вхідний INP файл!</translation>
		</message>
		<message>
			<source>You should select an output folder!</source>
			<translation>Вам слід вибрати вихідну папку!</translation>
		</message>
		<message>
			<source>Zoom to selection</source>
			<translation>Zoom to selection</translation>
		</message>
	</context>
<!-- UI TRANSLATION -->
	<context>
		<name>add_campaign_inventory</name>
		<message>
			<source>add_campaign</source>
			<translation>Кампанія</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Підключення</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Кампанія</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Ливнеприймальник</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Посилання</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Зв&apos;язки елементів</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_review</name>
		<message>
			<source>add_campaign</source>
			<translation>Кампанія</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>З&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Кампанія</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Зливоприймальник</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Зв&apos;язок</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Зв&apos;язки елементів</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_review_old</name>
		<message>
			<source>action_selector</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_action_selector</source>
			<translation>action_selector</translation>
		</message>
		<message>
			<source>active</source>
			<translation>Активний:</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Кампанія</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_export_rel</source>
			<translation>Експорт у csv</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_export_rel</source>
			<translation>campaign_btn_export_rel</translation>
		</message>
		<message>
			<source>campaign_btn_path_rel</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_path_rel</source>
			<translation>campaign_btn_path_rel</translation>
		</message>
		<message>
			<source>CampaignTab</source>
			<translation>Кампанія</translation>
		</message>
		<message>
			<source>tooltip_CampaignTab</source>
			<translation>CampaignTab</translation>
		</message>
		<message>
			<source>grb_campaign</source>
			<translation>Кампанія:</translation>
		</message>
		<message>
			<source>tooltip_grb_campaign</source>
			<translation>grb_campaign</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Вправа:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Серія:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Реальний старт:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Fi real:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Організація:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Тривалість:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Статус:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Адреса:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Елемент тип:</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>label_feature_type</translation>
		</message>
		<message>
			<source>label_flexunion_code_5</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_label_flexunion_code_5</source>
			<translation>label_flexunion_code_5</translation>
		</message>
		<message>
			<source>label_node_type</source>
			<translation>Ідентифікатор:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type</source>
			<translation>label_node_type</translation>
		</message>
		<message>
			<source>label_node_type_2</source>
			<translation>Запланований кінець:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_2</source>
			<translation>label_node_type_2</translation>
		</message>
		<message>
			<source>label_node_type_3</source>
			<translation>Запланований початок:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_3</source>
			<translation>label_node_type_3</translation>
		</message>
		<message>
			<source>label_node_type_5</source>
			<translation>Ротація:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_5</source>
			<translation>label_node_type_5</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Елементи зв&apos;язки</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>RelationsTab</translation>
		</message>
		<message>
			<source>reviewclass_id</source>
			<translation>КласПерегляду:</translation>
		</message>
		<message>
			<source>tooltip_reviewclass_id</source>
			<translation>reviewclass_id</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_visit</name>
		<message>
			<source>add_campaign</source>
			<translation>Візит</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>З&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Кампанія</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Ливневий колодязь</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Посилання</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Зв&apos;язки елементів</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_visit_old</name>
		<message>
			<source>action_selector</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_action_selector</source>
			<translation>action_selector</translation>
		</message>
		<message>
			<source>active</source>
			<translation>Активний:</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Лот</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_export_rel</source>
			<translation>Експорт у csv</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_export_rel</source>
			<translation>campaign_btn_export_rel</translation>
		</message>
		<message>
			<source>campaign_btn_path_rel</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_path_rel</source>
			<translation>campaign_btn_path_rel</translation>
		</message>
		<message>
			<source>CampaignTab</source>
			<translation>Кампанія</translation>
		</message>
		<message>
			<source>tooltip_CampaignTab</source>
			<translation>CampaignTab</translation>
		</message>
		<message>
			<source>grb_campaign</source>
			<translation>Кампанія:</translation>
		</message>
		<message>
			<source>tooltip_grb_campaign</source>
			<translation>grb_campaign</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Вправа:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Серія:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Фактичний початок:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Фактичний кінець:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Організація:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Тривалість:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Статус:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Адреса:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Тип елемента</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>label_feature_type</translation>
		</message>
		<message>
			<source>label_flexunion_code_5</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_label_flexunion_code_5</source>
			<translation>label_flexunion_code_5</translation>
		</message>
		<message>
			<source>label_node_type</source>
			<translation>Ідентифікатор:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type</source>
			<translation>label_node_type</translation>
		</message>
		<message>
			<source>label_node_type_2</source>
			<translation>Запланований кінець:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_2</source>
			<translation>label_node_type_2</translation>
		</message>
		<message>
			<source>label_node_type_3</source>
			<translation>Запланований початок:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_3</source>
			<translation>label_node_type_3</translation>
		</message>
		<message>
			<source>label_node_type_5</source>
			<translation>Ротація:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_5</source>
			<translation>label_node_type_5</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Відносини елементів</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>RelationsTab</translation>
		</message>
		<message>
			<source>visitclass_id</source>
			<translation>Клас візиту:</translation>
		</message>
		<message>
			<source>tooltip_visitclass_id</source>
			<translation>visitclass_id</translation>
		</message>
	</context>
	<context>
		<name>add_lot</name>
		<message>
			<source>title</source>
			<translation>Лот</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_visit</source>
			<translation>Видалити візит</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_visit</source>
			<translation>Видалити візит</translation>
		</message>
		<message>
			<source>btn_export_visits</source>
			<translation>Експорт у csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_visits</source>
			<translation>Експорт у csv</translation>
		</message>
		<message>
			<source>btn_open_photo</source>
			<translation>Відкрити фото</translation>
		</message>
		<message>
			<source>tooltip_btn_open_photo</source>
			<translation>Відкрити фото</translation>
		</message>
		<message>
			<source>btn_open_visit</source>
			<translation>Відкрити візит</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit</source>
			<translation>Відкрити візит</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_validate_all</source>
			<translation>Перевірити все</translation>
		</message>
		<message>
			<source>tooltip_btn_validate_all</source>
			<translation>Перевірити все</translation>
		</message>
		<message>
			<source>dlg_add_lot</source>
			<translation>Лот</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_lot</source>
			<translation>dlg_add_lot</translation>
		</message>
		<message>
			<source>grb_lot</source>
			<translation>Лот:</translation>
		</message>
		<message>
			<source>tooltip_grb_lot</source>
			<translation>Лот:</translation>
		</message>
		<message>
			<source>label_data_event_from</source>
			<translation>Від:</translation>
		</message>
		<message>
			<source>tooltip_label_data_event_from</source>
			<translation>Від:</translation>
		</message>
		<message>
			<source>label_data_event_to</source>
			<translation>До:</translation>
		</message>
		<message>
			<source>tooltip_label_data_event_to</source>
			<translation>До:</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Фільтрувати за ідентифікатором елемента:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>Фільтрувати за ідентифікатором елемента:</translation>
		</message>
		<message>
			<source>LotTab</source>
			<translation>Лот</translation>
		</message>
		<message>
			<source>tooltip_LotTab</source>
			<translation>Лот</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Відносини елементів</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>Відношення елементів</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>З&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Ливнеприймальник</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Посилання</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>VisitsTab</source>
			<translation>Відвідування</translation>
		</message>
		<message>
			<source>tooltip_VisitsTab</source>
			<translation>Відвідування</translation>
		</message>
	</context>
	<context>
		<name>add_workorder</name>
		<message>
			<source>title</source>
			<translation>Робоче замовлення</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_add_workorder</source>
			<translation>Робоче замовлення</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_workorder</source>
			<translation>dlg_add_workorder</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Робоче замовлення</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
	</context>
	<context>
		<name>admin</name>
		<message>
			<source>title</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>btn_activate_audit</source>
			<translation>Активувати Середовище Аудиту</translation>
		</message>
		<message>
			<source>tooltip_btn_activate_audit</source>
			<translation>It will generate a copy of the network layers from your current schema into the audit schema</translation>
		</message>
		<message>
			<source>btn_adapt_cibs</source>
			<translation>Adapt schema to use cibs</translation>
		</message>
		<message>
			<source>tooltip_btn_adapt_cibs</source>
			<translation>btn_adapt_cibs</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_copy</source>
			<translation>Копіювати</translation>
		</message>
		<message>
			<source>tooltip_btn_copy</source>
			<translation>btn_copy</translation>
		</message>
		<message>
			<source>btn_create_asset</source>
			<translation>Створити DB asset схему</translation>
		</message>
		<message>
			<source>tooltip_btn_create_asset</source>
			<translation>btn_create_asset</translation>
		</message>
		<message>
			<source>btn_create_audit</source>
			<translation>Створити DB Схему Аудиту</translation>
		</message>
		<message>
			<source>tooltip_btn_create_audit</source>
			<translation>btn_create_audit</translation>
		</message>
		<message>
			<source>btn_create_cibs</source>
			<translation>Create cibs schema</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cibs</source>
			<translation>btn_create_cibs</translation>
		</message>
		<message>
			<source>btn_create_cm</source>
			<translation>Створити DB cm схему</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cm</source>
			<translation>btn_create_cm</translation>
		</message>
		<message>
			<source>btn_create_field</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create_field</source>
			<translation>btn_create_field</translation>
		</message>
		<message>
			<source>btn_create_qgis_template</source>
			<translation>Шаблони QGIS</translation>
		</message>
		<message>
			<source>tooltip_btn_create_qgis_template</source>
			<translation>btn_create_qgis_template</translation>
		</message>
		<message>
			<source>btn_create_utils</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create_utils</source>
			<translation>btn_create_utils</translation>
		</message>
		<message>
			<source>btn_custom_load_file</source>
			<translation>Завантажити SQL файли</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_load_file</source>
			<translation>btn_custom_load_file</translation>
		</message>
		<message>
			<source>btn_custom_select_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_select_file</source>
			<translation>btn_custom_select_file</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_delete_field</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_field</source>
			<translation>btn_delete_field</translation>
		</message>
		<message>
			<source>btn_gis_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_create</source>
			<translation>btn_gis_create</translation>
		</message>
		<message>
			<source>btn_gis_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_folder</source>
			<translation>btn_gis_folder</translation>
		</message>
		<message>
			<source>btn_i18n</source>
			<translation>менеджер i18n</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n</source>
			<translation>btn_i18n</translation>
		</message>
		<message>
			<source>btn_import_osm_streetaxis</source>
			<translation>Імпортувати OSM Streetaxis</translation>
		</message>
		<message>
			<source>tooltip_btn_import_osm_streetaxis</source>
			<translation>btn_import_osm_streetaxis</translation>
		</message>
		<message>
			<source>btn_info</source>
			<translation>Оновити Схему Проєкту</translation>
		</message>
		<message>
			<source>tooltip_btn_info</source>
			<translation>Оновити версію вибраної схеми бази даних</translation>
		</message>
		<message>
			<source>btn_manage_languages</source>
			<translation>Manage Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_languages</source>
			<translation>btn_manage_languages</translation>
		</message>
		<message>
			<source>btn_manage_schemas</source>
			<translation>Manage schemas</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_schemas</source>
			<translation>btn_manage_schemas</translation>
		</message>
		<message>
			<source>btn_markdown_generator</source>
			<translation>Markdown Генератор</translation>
		</message>
		<message>
			<source>tooltip_btn_markdown_generator</source>
			<translation>btn_markdown_generator</translation>
		</message>
		<message>
			<source>btn_reload_audit_triggers</source>
			<translation>Оновити аудит</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_audit_triggers</source>
			<translation>Allow to start/end auditing tables updating the triggers</translation>
		</message>
		<message>
			<source>btn_reload_fct_ftrg</source>
			<translation>Виконати</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_fct_ftrg</source>
			<translation>btn_reload_fct_ftrg</translation>
		</message>
		<message>
			<source>btn_schema_create</source>
			<translation>Створити Схему Проєкту DB</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_create</source>
			<translation>btn_schema_create</translation>
		</message>
		<message>
			<source>btn_schema_rename</source>
			<translation>Перейменувати</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_rename</source>
			<translation>btn_schema_rename</translation>
		</message>
		<message>
			<source>btn_translation</source>
			<translation>Файли Перекладу</translation>
		</message>
		<message>
			<source>tooltip_btn_translation</source>
			<translation>btn_translation</translation>
		</message>
		<message>
			<source>btn_update_asset</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_asset</source>
			<translation>btn_update_asset</translation>
		</message>
		<message>
			<source>btn_update_cm</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_cm</source>
			<translation>btn_update_cm</translation>
		</message>
		<message>
			<source>btn_update_field</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_btn_update_field</source>
			<translation>btn_update_field</translation>
		</message>
		<message>
			<source>btn_update_utils</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_btn_update_utils</source>
			<translation>btn_update_utils</translation>
		</message>
		<message>
			<source>btn_vacuum</source>
			<translation>Виконати</translation>
		</message>
		<message>
			<source>tooltip_btn_vacuum</source>
			<translation>btn_vacuum</translation>
		</message>
		<message>
			<source>chk_add_fields_multi</source>
			<translation>Мультистворення полів</translation>
		</message>
		<message>
			<source>tooltip_chk_add_fields_multi</source>
			<translation>chk_add_fields_multi</translation>
		</message>
		<message>
			<source>dlg_admin</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin</source>
			<translation>dlg_admin</translation>
		</message>
		<message>
			<source>grb_conection</source>
			<translation>Підключення</translation>
		</message>
		<message>
			<source>tooltip_grb_conection</source>
			<translation>grb_conection</translation>
		</message>
		<message>
			<source>grb_files_generator</source>
			<translation>Генератор Файлів Плагіна</translation>
		</message>
		<message>
			<source>tooltip_grb_files_generator</source>
			<translation>grb_files_generator</translation>
		</message>
		<message>
			<source>grb_i18n</source>
			<translation>i18n</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n</source>
			<translation>grb_i18n</translation>
		</message>
		<message>
			<source>grb_load_cf</source>
			<translation>Завантажити користувацький файл</translation>
		</message>
		<message>
			<source>tooltip_grb_load_cf</source>
			<translation>grb_load_cf</translation>
		</message>
		<message>
			<source>grb_manage_addfields</source>
			<translation>Керувати додаванням полів</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_addfields</source>
			<translation>grb_manage_addfields</translation>
		</message>
		<message>
			<source>grb_manage_schemas</source>
			<translation>Additional schema management</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_schemas</source>
			<translation>grb_manage_schemas</translation>
		</message>
		<message>
			<source>grb_project_scin</source>
			<translation>Інформація про схему проєкту</translation>
		</message>
		<message>
			<source>tooltip_grb_project_scin</source>
			<translation>grb_project_scin</translation>
		</message>
		<message>
			<source>grb_schema_manager</source>
			<translation>Керування Схемою</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_manager</source>
			<translation>grb_schema_manager</translation>
		</message>
		<message>
			<source>grb_schema_reload</source>
			<translation>Керування схемою</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_reload</source>
			<translation>grb_schema_reload</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Схема Утиліти</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Додаткове Керування Схемою</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_cibs</source>
			<translation>Schema cibs</translation>
		</message>
		<message>
			<source>tooltip_groupBox_cibs</source>
			<translation>groupBox_cibs</translation>
		</message>
		<message>
			<source>grp_i18n_update</source>
			<translation>Схема i18n оновлення</translation>
		</message>
		<message>
			<source>tooltip_grp_i18n_update</source>
			<translation>grp_i18n_update</translation>
		</message>
		<message>
			<source>grp_import_osm</source>
			<translation>Імпортувати OSM Streetaxis</translation>
		</message>
		<message>
			<source>tooltip_grp_import_osm</source>
			<translation>grp_import_osm</translation>
		</message>
		<message>
			<source>label</source>
			<translation>WS:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>UD:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_cibs_schema</source>
			<translation>Schema:</translation>
		</message>
		<message>
			<source>tooltip_label_cibs_schema</source>
			<translation>label_cibs_schema</translation>
		</message>
		<message>
			<source>lbl_add_fields_feature</source>
			<translation>Назва елемента:</translation>
		</message>
		<message>
			<source>tooltip_lbl_add_fields_feature</source>
			<translation>lbl_add_fields_feature</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Назва підключення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_export_user_pass</source>
			<translation>Export user password:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_user_pass</source>
			<translation>lbl_export_user_pass</translation>
		</message>
		<message>
			<source>lbl_gis_file</source>
			<translation>GIS file name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_file</source>
			<translation>lbl_gis_file</translation>
		</message>
		<message>
			<source>lbl_gis_folder</source>
			<translation>GIS folder:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_folder</source>
			<translation>lbl_gis_folder</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Назва:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_reload_fct_ftrg</source>
			<translation>Перезавантажити функції &amp;amp; тригери функцій</translation>
		</message>
		<message>
			<source>tooltip_lbl_reload_fct_ftrg</source>
			<translation>lbl_reload_fct_ftrg</translation>
		</message>
		<message>
			<source>lbl_vacuum</source>
			<translation>Виконати VACUUM для вибраної схеми</translation>
		</message>
		<message>
			<source>tooltip_lbl_vacuum</source>
			<translation>lbl_vacuum</translation>
		</message>
		<message>
			<source>tab_advanced</source>
			<translation>Додатково</translation>
		</message>
		<message>
			<source>tooltip_tab_advanced</source>
			<translation>tab_advanced</translation>
		</message>
		<message>
			<source>tab_dev</source>
			<translation>Розробка</translation>
		</message>
		<message>
			<source>tooltip_tab_dev</source>
			<translation>tab_dev</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Загальні</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>txt_roletype</source>
			<translation>inventory</translation>
		</message>
		<message>
			<source>tooltip_txt_roletype</source>
			<translation>txt_roletype</translation>
		</message>
	</context>
	<context>
		<name>admin_addfields</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Відкрити</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_admin_addfields</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_addfields</source>
			<translation>dlg_admin_addfields</translation>
		</message>
		<message>
			<source>grb_additional</source>
			<translation>Додаткова Конфігурація</translation>
		</message>
		<message>
			<source>tooltip_grb_additional</source>
			<translation>grb_additional</translation>
		</message>
		<message>
			<source>grb_mandatory</source>
			<translation>Обов&apos;язкова конфігурація додаткових полів</translation>
		</message>
		<message>
			<source>tooltip_grb_mandatory</source>
			<translation>grb_mandatory</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Активний:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_columnname</source>
			<translation>Назва Стовпця:</translation>
		</message>
		<message>
			<source>tooltip_lbl_columnname</source>
			<translation>lbl_columnname</translation>
		</message>
		<message>
			<source>lbl_datatype</source>
			<translation>Тип Даних:</translation>
		</message>
		<message>
			<source>tooltip_lbl_datatype</source>
			<translation>lbl_datatype</translation>
		</message>
		<message>
			<source>lbl_dv_orderby</source>
			<translation>Сортувати за id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_orderby</source>
			<translation>lbl_dv_orderby</translation>
		</message>
		<message>
			<source>lbl_dv_querynullvalue</source>
			<translation>Значення null запиту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_querynullvalue</source>
			<translation>lbl_dv_querynullvalue</translation>
		</message>
		<message>
			<source>lbl_dv_querytext</source>
			<translation>Текст запиту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_querytext</source>
			<translation>lbl_dv_querytext</translation>
		</message>
		<message>
			<source>lbl_field_name</source>
			<translation>Назва Поля:</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_name</source>
			<translation>lbl_field_name</translation>
		</message>
		<message>
			<source>lbl_formtype</source>
			<translation>Тип Форми:</translation>
		</message>
		<message>
			<source>tooltip_lbl_formtype</source>
			<translation>lbl_formtype</translation>
		</message>
		<message>
			<source>lbl_hidden</source>
			<translation>Прихований:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hidden</source>
			<translation>lbl_hidden</translation>
		</message>
		<message>
			<source>lbl_iseditable</source>
			<translation>Редагований:</translation>
		</message>
		<message>
			<source>tooltip_lbl_iseditable</source>
			<translation>lbl_iseditable</translation>
		</message>
		<message>
			<source>lbl_ismandatory</source>
			<translation>Обов&apos;язковий:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ismandatory</source>
			<translation>lbl_ismandatory</translation>
		</message>
		<message>
			<source>lbl_label</source>
			<translation>Мітка:</translation>
		</message>
		<message>
			<source>tooltip_lbl_label</source>
			<translation>lbl_label</translation>
		</message>
		<message>
			<source>lbl_layoutname</source>
			<translation>Назва макета:</translation>
		</message>
		<message>
			<source>tooltip_lbl_layoutname</source>
			<translation>lbl_layoutname</translation>
		</message>
		<message>
			<source>lbl_linkedobject</source>
			<translation>Зв&apos;язанийОб&apos;єкт:</translation>
		</message>
		<message>
			<source>tooltip_lbl_linkedobject</source>
			<translation>lbl_linkedobject</translation>
		</message>
		<message>
			<source>lbl_multifeaturetype</source>
			<translation>Функція мультистворення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multifeaturetype</source>
			<translation>lbl_multifeaturetype</translation>
		</message>
		<message>
			<source>lbl_placeholder</source>
			<translation>Заповнювач:</translation>
		</message>
		<message>
			<source>tooltip_lbl_placeholder</source>
			<translation>lbl_placeholder</translation>
		</message>
		<message>
			<source>lbl_stylesheet</source>
			<translation>ТаблицяСтилів:</translation>
		</message>
		<message>
			<source>tooltip_lbl_stylesheet</source>
			<translation>lbl_stylesheet</translation>
		</message>
		<message>
			<source>lbl_tooltip</source>
			<translation>Підказка:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tooltip</source>
			<translation>lbl_tooltip</translation>
		</message>
		<message>
			<source>lbl_widgetcontrols</source>
			<translation>КеруванняВіджетом</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgetcontrols</source>
			<translation>Приклади Ключів Конфігурації {&quot;widgetdim&quot;: 150,&quot;setMultiline&quot;:true,&quot;vdefault&quot;: &quot;01-01-2014&quot;, &quot;filterSign&quot;: &quot;&gt;}</translation>
		</message>
		<message>
			<source>lbl_widgettype</source>
			<translation>Тип Віджета:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgettype</source>
			<translation>lbl_widgettype</translation>
		</message>
		<message>
			<source>stylesheet</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;{&amp;amp;quot;label&amp;amp;quot;:&amp;amp;quot;color:green; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;widget&amp;amp;quot;:{&amp;amp;quot;enabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;disabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;}}&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_stylesheet</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;{&amp;amp;quot;label&amp;amp;quot;:&amp;amp;quot;color:green; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;widget&amp;amp;quot;:{&amp;amp;quot;enabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;disabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;}}&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tab_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_tab_create</source>
			<translation>tab_create</translation>
		</message>
		<message>
			<source>tab_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_tab_delete</source>
			<translation>tab_delete</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_update</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_tab_update</source>
			<translation>tab_update</translation>
		</message>
	</context>
	<context>
		<name>admin_cm_create</name>
		<message>
			<source>title</source>
			<translation>Створити проєкт</translation>
		</message>
		<message>
			<source>btn_base_schema</source>
			<translation>Створити cm схему</translation>
		</message>
		<message>
			<source>tooltip_btn_base_schema</source>
			<translation>btn_base_schema</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Скасувати завдання</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_example</source>
			<translation>Створити приклад</translation>
		</message>
		<message>
			<source>tooltip_btn_example</source>
			<translation>btn_example</translation>
		</message>
		<message>
			<source>btn_parent_schema</source>
			<translation>Посилання на батьківську схему</translation>
		</message>
		<message>
			<source>tooltip_btn_parent_schema</source>
			<translation>btn_parent_schema</translation>
		</message>
		<message>
			<source>btn_pschema_qgis_file</source>
			<translation>Створити файл pschema qgis</translation>
		</message>
		<message>
			<source>tooltip_btn_pschema_qgis_file</source>
			<translation>btn_pschema_qgis_file</translation>
		</message>
		<message>
			<source>dlg_admin_cm_create</source>
			<translation>Створити проєкт</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_cm_create</source>
			<translation>dlg_admin_cm_create</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>CM параметри схеми</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
	</context>
	<context>
		<name>admin_credentials</name>
		<message>
			<source>title</source>
			<translation>Облікові дані підключення</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>dlg_admin_credentials</source>
			<translation>Облікові дані підключення</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_credentials</source>
			<translation>dlg_admin_credentials</translation>
		</message>
		<message>
			<source>label</source>
			<translation>SSL Режим:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_connec</source>
			<translation>Підключення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connec</source>
			<translation>lbl_connec</translation>
		</message>
		<message>
			<source>lbl_connection_message</source>
			<translation>Не вдалося отримати параметри підключення для:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection_message</source>
			<translation>lbl_connection_message</translation>
		</message>
		<message>
			<source>lbl_password</source>
			<translation>Пароль:</translation>
		</message>
		<message>
			<source>tooltip_lbl_password</source>
			<translation>lbl_password</translation>
		</message>
		<message>
			<source>lbl_user_name</source>
			<translation>Ім&apos;я користувача:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user_name</source>
			<translation>lbl_user_name</translation>
		</message>
	</context>
	<context>
		<name>admin_dbproject</name>
		<message>
			<source>title</source>
			<translation>Створити проект</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Скасувати Завдання</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>btn_language</source>
			<translation>btn_language</translation>
		</message>
		<message>
			<source>tooltip_btn_language</source>
			<translation>Manage languages</translation>
		</message>
		<message>
			<source>dlg_admin_dbproject</source>
			<translation>Створити проект</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_dbproject</source>
			<translation>dlg_admin_dbproject</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>Проект схема Налаштування</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Фільтр SRID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>Ідентифікатор просторової прив&apos;язки. Дозволені лише значення, показані в таблиці нижче.</translation>
		</message>
		<message>
			<source>lbl_locale</source>
			<translation>Локаль:</translation>
		</message>
		<message>
			<source>tooltip_lbl_locale</source>
			<translation>Мова схеми</translation>
		</message>
		<message>
			<source>lbl_project_name</source>
			<translation>Назва проєкту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_name</source>
			<translation>Назва нової схеми. Назва має бути написана малими літерами, використовуючи лише літери англійського алфавіту та без пробілів чи дефісів</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Тип проєкту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_source</source>
			<translation>Джерело даних:</translation>
		</message>
		<message>
			<source>tooltip_lbl_source</source>
			<translation>lbl_source</translation>
		</message>
		<message>
			<source>rdb_empty</source>
			<translation>Порожні дані</translation>
		</message>
		<message>
			<source>tooltip_rdb_empty</source>
			<translation>rdb_empty</translation>
		</message>
		<message>
			<source>rdb_sample_full</source>
			<translation>Повний приклад</translation>
		</message>
		<message>
			<source>tooltip_rdb_sample_full</source>
			<translation>rdb_sample_full</translation>
		</message>
		<message>
			<source>rdb_sample_inv</source>
			<translation>Приклад інвентарю</translation>
		</message>
		<message>
			<source>tooltip_rdb_sample_inv</source>
			<translation>rdb_sample_inv</translation>
		</message>
	</context>
	<context>
		<name>admin_gisproject</name>
		<message>
			<source>title</source>
			<translation>Створити GIS проект</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>btn_gis_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_folder</source>
			<translation>btn_gis_folder</translation>
		</message>
		<message>
			<source>dlg_admin_gisproject</source>
			<translation>Створити GIS проект</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_gisproject</source>
			<translation>dlg_admin_gisproject</translation>
		</message>
		<message>
			<source>lbl_export_user_pass</source>
			<translation>Пароль користувача для експорту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_user_pass</source>
			<translation>lbl_export_user_pass</translation>
		</message>
		<message>
			<source>lbl_gis_file</source>
			<translation>Назва GIS файлу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_file</source>
			<translation>lbl_gis_file</translation>
		</message>
		<message>
			<source>lbl_gis_folder</source>
			<translation>Папка GIS:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_folder</source>
			<translation>lbl_gis_folder</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Тип Проєкту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>txt_roletype</source>
			<translation>інвентар</translation>
		</message>
		<message>
			<source>tooltip_txt_roletype</source>
			<translation>txt_roletype</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_hot_update</name>
		<message>
			<source>title</source>
			<translation>Manage languages</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Apply</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>btn_apply</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Close</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_manage_language_hot_update</source>
			<translation>Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_language_hot_update</source>
			<translation>btn_manage_language_hot_update</translation>
		</message>
		<message>
			<source>btn_manage_language_multilang</source>
			<translation>Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_language_multilang</source>
			<translation>btn_manage_language_multilang</translation>
		</message>
		<message>
			<source>btn_refresh</source>
			<translation>Refresh</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh</source>
			<translation>btn_refresh</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>chk_add_tab_data</source>
			<translation>Translate tab_data</translation>
		</message>
		<message>
			<source>tooltip_chk_add_tab_data</source>
			<translation>chk_add_tab_data</translation>
		</message>
		<message>
			<source>chk_use_selected_tables</source>
			<translation>Use selected tables only</translation>
		</message>
		<message>
			<source>tooltip_chk_use_selected_tables</source>
			<translation>chk_use_selected_tables</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_hot_update</source>
			<translation>Manage languages</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_hot_update</source>
			<translation>dlg_admin_i18n_hot_update</translation>
		</message>
		<message>
			<source>grb_connection</source>
			<translation>Connection</translation>
		</message>
		<message>
			<source>tooltip_grb_connection</source>
			<translation>grb_connection</translation>
		</message>
		<message>
			<source>grb_params</source>
			<translation>Parameters</translation>
		</message>
		<message>
			<source>tooltip_grb_params</source>
			<translation>grb_params</translation>
		</message>
		<message>
			<source>grb_schemas</source>
			<translation>Schemas</translation>
		</message>
		<message>
			<source>tooltip_grb_schemas</source>
			<translation>grb_schemas</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Language:</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Language</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Connection name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_schema_selection</source>
			<translation>Schema: select a row below</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_selection</source>
			<translation>lbl_schema_selection</translation>
		</message>
		<message>
			<source>lbl_tables</source>
			<translation>Tables filter:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tables</source>
			<translation>lbl_tables</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Hot Update</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_2</source>
			<translation>Multilang</translation>
		</message>
		<message>
			<source>tooltip_tab_2</source>
			<translation>tab_2</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_languages</name>
		<message>
			<source>title</source>
			<translation>Manage language</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Close</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_download</source>
			<translation>Download</translation>
		</message>
		<message>
			<source>tooltip_btn_download</source>
			<translation>btn_download</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>chk_download_latest</source>
			<translation>Download latest translation version</translation>
		</message>
		<message>
			<source>tooltip_chk_download_latest</source>
			<translation>Download translations from the latest published version instead of the version matched to this plugin. For advanced users only.</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_languages</source>
			<translation>Manage language</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_languages</source>
			<translation>dlg_admin_i18n_languages</translation>
		</message>
		<message>
			<source>grb_locales</source>
			<translation>Available Languages</translation>
		</message>
		<message>
			<source>tooltip_grb_locales</source>
			<translation>grb_locales</translation>
		</message>
		<message>
			<source>lbl_language</source>
			<translation>Select a language to manage</translation>
		</message>
		<message>
			<source>tooltip_lbl_language</source>
			<translation>lbl_language</translation>
		</message>
		<message>
			<source>txt_filter</source>
			<translation>Filter locales...</translation>
		</message>
		<message>
			<source>tooltip_txt_filter</source>
			<translation>txt_filter</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_manager</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_connection</source>
			<translation>Перевірити з&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_btn_connection</source>
			<translation>btn_connection</translation>
		</message>
		<message>
			<source>btn_search</source>
			<translation>Пошук</translation>
		</message>
		<message>
			<source>tooltip_btn_search</source>
			<translation>btn_search</translation>
		</message>
		<message>
			<source>chk_all</source>
			<translation>Перевірити Все</translation>
		</message>
		<message>
			<source>tooltip_chk_all</source>
			<translation>chk_all</translation>
		</message>
		<message>
			<source>chk_am_dialogs</source>
			<translation>Перевірити Таблиці am</translation>
		</message>
		<message>
			<source>tooltip_chk_am_dialogs</source>
			<translation>chk_am_dialogs</translation>
		</message>
		<message>
			<source>chk_cm_dialogs</source>
			<translation>Перевірити Таблиці cm</translation>
		</message>
		<message>
			<source>tooltip_chk_cm_dialogs</source>
			<translation>chk_cm_dialogs</translation>
		</message>
		<message>
			<source>chk_db_dialogs</source>
			<translation>Перевірити Діалоги Для Таблиць DB</translation>
		</message>
		<message>
			<source>tooltip_chk_db_dialogs</source>
			<translation>chk_db_dialogs</translation>
		</message>
		<message>
			<source>chk_for_su_tables</source>
			<translation>Перевірити Базові Таблиці DB (cat_feature...)</translation>
		</message>
		<message>
			<source>tooltip_chk_for_su_tables</source>
			<translation>chk_for_su_tables</translation>
		</message>
		<message>
			<source>chk_py_dialogs</source>
			<translation>Перевірити PY Діалоги</translation>
		</message>
		<message>
			<source>tooltip_chk_py_dialogs</source>
			<translation>chk_py_dialogs</translation>
		</message>
		<message>
			<source>chk_py_messages</source>
			<translation>Перевірити PY Повідомлення</translation>
		</message>
		<message>
			<source>tooltip_chk_py_messages</source>
			<translation>chk_py_messages</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_manager</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_manager</source>
			<translation>dlg_admin_i18n_manager</translation>
		</message>
		<message>
			<source>grb_i18n_conn</source>
			<translation>i18n Підключення</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n_conn</source>
			<translation>grb_i18n_conn</translation>
		</message>
		<message>
			<source>grp_search_options</source>
			<translation>Параметри Пошуку</translation>
		</message>
		<message>
			<source>tooltip_grp_search_options</source>
			<translation>grp_search_options</translation>
		</message>
		<message>
			<source>lbl_database</source>
			<translation>База даних:</translation>
		</message>
		<message>
			<source>tooltip_lbl_database</source>
			<translation>lbl_database</translation>
		</message>
		<message>
			<source>lbl_host</source>
			<translation>Хост:</translation>
		</message>
		<message>
			<source>tooltip_lbl_host</source>
			<translation>lbl_host</translation>
		</message>
		<message>
			<source>lbl_pass</source>
			<translation>Пароль:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pass</source>
			<translation>lbl_pass</translation>
		</message>
		<message>
			<source>lbl_port</source>
			<translation>Порт:</translation>
		</message>
		<message>
			<source>tooltip_lbl_port</source>
			<translation>lbl_port</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Користувач:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
	</context>
	<context>
		<name>admin_import_osm</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Виконати</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_admin_import_osm</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_import_osm</source>
			<translation>dlg_admin_import_osm</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Муніципалітети</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Журнали</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>admin_manage_schemas</name>
		<message>
			<source>title</source>
			<translation>Manage schemas</translation>
		</message>
		<message>
			<source>btn_activate_audit</source>
			<translation>Activate</translation>
		</message>
		<message>
			<source>tooltip_btn_activate_audit</source>
			<translation>Generate a copy of network layers from the anchor schema into audit</translation>
		</message>
		<message>
			<source>btn_cibs_copy</source>
			<translation>Copy data</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_copy</source>
			<translation>btn_cibs_copy</translation>
		</message>
		<message>
			<source>btn_cibs_create</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_create</source>
			<translation>btn_cibs_create</translation>
		</message>
		<message>
			<source>btn_cibs_integrate</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_integrate</source>
			<translation>Link cibs to the selected network schema</translation>
		</message>
		<message>
			<source>btn_cibs_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_update</source>
			<translation>btn_cibs_update</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Close</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_cm_integrate</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_integrate</source>
			<translation>Link CM to the selected network schema</translation>
		</message>
		<message>
			<source>btn_cm_qgis</source>
			<translation>btn_cm_qgis</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_qgis</source>
			<translation>Create pschema qgis file</translation>
		</message>
		<message>
			<source>btn_cm_sample</source>
			<translation>Sample</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_sample</source>
			<translation>Load CM example data for the selected network schema</translation>
		</message>
		<message>
			<source>btn_create_am</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_create_am</source>
			<translation>btn_create_am</translation>
		</message>
		<message>
			<source>btn_create_am_sample</source>
			<translation>+ Sample</translation>
		</message>
		<message>
			<source>tooltip_btn_create_am_sample</source>
			<translation>Create AM schema with sample leaks data</translation>
		</message>
		<message>
			<source>btn_create_audit</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_create_audit</source>
			<translation>btn_create_audit</translation>
		</message>
		<message>
			<source>btn_create_cm</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cm</source>
			<translation>btn_create_cm</translation>
		</message>
		<message>
			<source>btn_delete_am</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_am</source>
			<translation>btn_delete_am</translation>
		</message>
		<message>
			<source>btn_delete_audit</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_audit</source>
			<translation>btn_delete_audit</translation>
		</message>
		<message>
			<source>btn_delete_cm</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_cm</source>
			<translation>btn_delete_cm</translation>
		</message>
		<message>
			<source>btn_i18n_create</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_create</source>
			<translation>btn_i18n_create</translation>
		</message>
		<message>
			<source>btn_i18n_delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_delete</source>
			<translation>btn_i18n_delete</translation>
		</message>
		<message>
			<source>btn_i18n_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_update</source>
			<translation>btn_i18n_update</translation>
		</message>
		<message>
			<source>btn_integrate_am</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_integrate_am</source>
			<translation>Wire am into the selected WS network schema</translation>
		</message>
		<message>
			<source>btn_integrate_am_sample</source>
			<translation>Int. + Sample</translation>
		</message>
		<message>
			<source>tooltip_btn_integrate_am_sample</source>
			<translation>Integrate am and seed config from parent WS catalogs</translation>
		</message>
		<message>
			<source>btn_languages</source>
			<translation>Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_languages</source>
			<translation>btn_languages</translation>
		</message>
		<message>
			<source>btn_network_delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_network_delete</source>
			<translation>btn_network_delete</translation>
		</message>
		<message>
			<source>btn_network_rename</source>
			<translation>Rename</translation>
		</message>
		<message>
			<source>tooltip_btn_network_rename</source>
			<translation>btn_network_rename</translation>
		</message>
		<message>
			<source>btn_refresh</source>
			<translation>Refresh</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh</source>
			<translation>btn_refresh</translation>
		</message>
		<message>
			<source>btn_reload_audit_triggers</source>
			<translation>Triggers</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_audit_triggers</source>
			<translation>Refresh audit triggers on the anchor schema</translation>
		</message>
		<message>
			<source>btn_update_am</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_am</source>
			<translation>btn_update_am</translation>
		</message>
		<message>
			<source>btn_update_audit</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_audit</source>
			<translation>btn_update_audit</translation>
		</message>
		<message>
			<source>btn_update_cm</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_cm</source>
			<translation>btn_update_cm</translation>
		</message>
		<message>
			<source>btn_update_network</source>
			<translation>Update network</translation>
		</message>
		<message>
			<source>tooltip_btn_update_network</source>
			<translation>Update anchor WS/UD and linked satellites to the plugin version</translation>
		</message>
		<message>
			<source>btn_utils_create</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_create</source>
			<translation>btn_utils_create</translation>
		</message>
		<message>
			<source>btn_utils_integrate</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_integrate</source>
			<translation>Link utils to the selected network schema</translation>
		</message>
		<message>
			<source>btn_utils_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_update</source>
			<translation>btn_utils_update</translation>
		</message>
		<message>
			<source>dlg_admin_manage_schemas</source>
			<translation>Manage schemas</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_manage_schemas</source>
			<translation>dlg_admin_manage_schemas</translation>
		</message>
		<message>
			<source>grb_am</source>
			<translation>AM</translation>
		</message>
		<message>
			<source>tooltip_grb_am</source>
			<translation>grb_am</translation>
		</message>
		<message>
			<source>grb_audit</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>tooltip_grb_audit</source>
			<translation>grb_audit</translation>
		</message>
		<message>
			<source>grb_cibs</source>
			<translation>Cibs</translation>
		</message>
		<message>
			<source>tooltip_grb_cibs</source>
			<translation>grb_cibs</translation>
		</message>
		<message>
			<source>grb_cm</source>
			<translation>CM</translation>
		</message>
		<message>
			<source>tooltip_grb_cm</source>
			<translation>grb_cm</translation>
		</message>
		<message>
			<source>grb_connection</source>
			<translation>Connection</translation>
		</message>
		<message>
			<source>tooltip_grb_connection</source>
			<translation>grb_connection</translation>
		</message>
		<message>
			<source>grb_i18n</source>
			<translation>Multilang</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n</source>
			<translation>grb_i18n</translation>
		</message>
		<message>
			<source>grb_network</source>
			<translation>Network (WS / UD)</translation>
		</message>
		<message>
			<source>tooltip_grb_network</source>
			<translation>grb_network</translation>
		</message>
		<message>
			<source>grb_utils</source>
			<translation>Utils</translation>
		</message>
		<message>
			<source>tooltip_grb_utils</source>
			<translation>grb_utils</translation>
		</message>
		<message>
			<source>lbl_am_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_am_info</source>
			<translation>lbl_am_info</translation>
		</message>
		<message>
			<source>lbl_audit_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_audit_info</source>
			<translation>lbl_audit_info</translation>
		</message>
		<message>
			<source>lbl_cibs_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_cibs_info</source>
			<translation>lbl_cibs_info</translation>
		</message>
		<message>
			<source>lbl_cm_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_cm_info</source>
			<translation>lbl_cm_info</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Connection name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_i18n_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_i18n_info</source>
			<translation>lbl_i18n_info</translation>
		</message>
		<message>
			<source>lbl_network_selection</source>
			<translation>Anchor: select a row below</translation>
		</message>
		<message>
			<source>tooltip_lbl_network_selection</source>
			<translation>lbl_network_selection</translation>
		</message>
		<message>
			<source>lbl_utils_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_utils_info</source>
			<translation>lbl_utils_info</translation>
		</message>
	</context>
	<context>
		<name>admin_markdown</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_generate</source>
			<translation>Згенерувати</translation>
		</message>
		<message>
			<source>tooltip_btn_generate</source>
			<translation>btn_generate</translation>
		</message>
		<message>
			<source>dlg_admin_markdown</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_markdown</source>
			<translation>dlg_admin_markdown</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Тип проєкту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Ім&apos;я схеми:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lb_path</source>
			<translation>Шлях до файлу:</translation>
		</message>
		<message>
			<source>tooltip_lb_path</source>
			<translation>lb_path</translation>
		</message>
		<message>
			<source>pushButton_2</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_pushButton_2</source>
			<translation>pushButton_2</translation>
		</message>
	</context>
	<context>
		<name>admin_markdown_generator</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_generate</source>
			<translation>Генерувати</translation>
		</message>
		<message>
			<source>tooltip_btn_generate</source>
			<translation>btn_generate</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>cmb_projecttype</source>
			<translation>ud</translation>
		</message>
		<message>
			<source>tooltip_cmb_projecttype</source>
			<translation>cmb_projecttype</translation>
		</message>
		<message>
			<source>dlg_admin_markdown_generator</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_markdown_generator</source>
			<translation>dlg_admin_markdown_generator</translation>
		</message>
		<message>
			<source>grp_markdown_destination</source>
			<translation>Markdown Призначення</translation>
		</message>
		<message>
			<source>tooltip_grp_markdown_destination</source>
			<translation>grp_markdown_destination</translation>
		</message>
		<message>
			<source>grp_origin_schema</source>
			<translation>Схема Походження</translation>
		</message>
		<message>
			<source>tooltip_grp_origin_schema</source>
			<translation>grp_origin_schema</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Тип Проекту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Назва схеми:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lb_path</source>
			<translation>Шлях до файлу:</translation>
		</message>
		<message>
			<source>tooltip_lb_path</source>
			<translation>lb_path</translation>
		</message>
	</context>
	<context>
		<name>admin_projectinfo</name>
		<message>
			<source>title</source>
			<translation>Оновити SQL</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>dlg_admin_projectinfo</source>
			<translation>Оновити SQL</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_projectinfo</source>
			<translation>dlg_admin_projectinfo</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Інформація про нові оновлення</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>tab_main</source>
			<translation>Основний</translation>
		</message>
		<message>
			<source>tooltip_tab_main</source>
			<translation>tab_main</translation>
		</message>
	</context>
	<context>
		<name>admin_renameproj</name>
		<message>
			<source>title</source>
			<translation>Перейменувати</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>dlg_admin_renameproj</source>
			<translation>Перейменувати</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_renameproj</source>
			<translation>dlg_admin_renameproj</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Будь ласка, задайте нову назву проекту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>lbl_rename_copy</translation>
		</message>
	</context>
	<context>
		<name>admin_translation</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_connection</source>
			<translation>Перевірити з&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_btn_connection</source>
			<translation>btn_connection</translation>
		</message>
		<message>
			<source>btn_translate</source>
			<translation>Перекласти</translation>
		</message>
		<message>
			<source>tooltip_btn_translate</source>
			<translation>btn_translate</translation>
		</message>
		<message>
			<source>chk_am_files</source>
			<translation>Перекласти am Файли</translation>
		</message>
		<message>
			<source>tooltip_chk_am_files</source>
			<translation>chk_am_files</translation>
		</message>
		<message>
			<source>chk_audit_files</source>
			<translation>Перекласти Файли Аудиту</translation>
		</message>
		<message>
			<source>tooltip_chk_audit_files</source>
			<translation>chk_audit_files</translation>
		</message>
		<message>
			<source>chk_cm_files</source>
			<translation>Перекласти cm Файли</translation>
		</message>
		<message>
			<source>tooltip_chk_cm_files</source>
			<translation>chk_cm_files</translation>
		</message>
		<message>
			<source>chk_i18n_files</source>
			<translation>Перекласти i18n Переклади</translation>
		</message>
		<message>
			<source>tooltip_chk_i18n_files</source>
			<translation>chk_i18n_files</translation>
		</message>
		<message>
			<source>chk_py_msg</source>
			<translation>Перекласти ui та py повідомлення</translation>
		</message>
		<message>
			<source>tooltip_chk_py_msg</source>
			<translation>chk_py_msg</translation>
		</message>
		<message>
			<source>chk_relative_langs</source>
			<translation>Увімкнути резервний варіант для схожих локалей.</translation>
		</message>
		<message>
			<source>tooltip_chk_relative_langs</source>
			<translation>chk_relative_langs</translation>
		</message>
		<message>
			<source>dlg_admin_translation</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_translation</source>
			<translation>dlg_admin_translation</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Інформація про підключення</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Перекласти файли</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_3</source>
			<translation>Параметри</translation>
		</message>
		<message>
			<source>tooltip_groupBox_3</source>
			<translation>groupBox_3</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Якщо переклад відсутній у конкретному діалекті призначеної мови (наприклад, es_ES), система шукає інші регіональні варіанти (наприклад, es_CR, es_AR). Якщо знайдено відповідність, цей переклад застосовується.</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_database</source>
			<translation>База даних:</translation>
		</message>
		<message>
			<source>tooltip_lbl_database</source>
			<translation>lbl_database</translation>
		</message>
		<message>
			<source>lbl_host</source>
			<translation>Хост:</translation>
		</message>
		<message>
			<source>tooltip_lbl_host</source>
			<translation>lbl_host</translation>
		</message>
		<message>
			<source>lbl_language</source>
			<translation>Мова:</translation>
		</message>
		<message>
			<source>tooltip_lbl_language</source>
			<translation>lbl_language</translation>
		</message>
		<message>
			<source>lbl_pass</source>
			<translation>Пароль:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pass</source>
			<translation>lbl_pass</translation>
		</message>
		<message>
			<source>lbl_port</source>
			<translation>Порт:</translation>
		</message>
		<message>
			<source>tooltip_lbl_port</source>
			<translation>lbl_port</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Користувач:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
	</context>
	<context>
		<name>admin_update_translation</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_connection</source>
			<translation>Перевірити підключення</translation>
		</message>
		<message>
			<source>tooltip_btn_connection</source>
			<translation>btn_connection</translation>
		</message>
		<message>
			<source>btn_translate</source>
			<translation>Перекласти</translation>
		</message>
		<message>
			<source>tooltip_btn_translate</source>
			<translation>btn_translate</translation>
		</message>
		<message>
			<source>chk_add_tab_data</source>
			<translation>Перекласти вкладка_дані</translation>
		</message>
		<message>
			<source>tooltip_chk_add_tab_data</source>
			<translation>chk_add_tab_data</translation>
		</message>
		<message>
			<source>dlg_admin_update_translation</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_update_translation</source>
			<translation>dlg_admin_update_translation</translation>
		</message>
		<message>
			<source>grb_dest_conn</source>
			<translation>Підключення призначення</translation>
		</message>
		<message>
			<source>tooltip_grb_dest_conn</source>
			<translation>grb_dest_conn</translation>
		</message>
		<message>
			<source>grb_i18n_conn</source>
			<translation>i18n Підключення</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n_conn</source>
			<translation>grb_i18n_conn</translation>
		</message>
		<message>
			<source>grb_parameters</source>
			<translation>Параметри</translation>
		</message>
		<message>
			<source>tooltip_grb_parameters</source>
			<translation>grb_parameters</translation>
		</message>
		<message>
			<source>lbl_database</source>
			<translation>База даних:</translation>
		</message>
		<message>
			<source>tooltip_lbl_database</source>
			<translation>lbl_database</translation>
		</message>
		<message>
			<source>lbl_host</source>
			<translation>Хост:</translation>
		</message>
		<message>
			<source>tooltip_lbl_host</source>
			<translation>lbl_host</translation>
		</message>
		<message>
			<source>lbl_language</source>
			<translation>Мова:</translation>
		</message>
		<message>
			<source>tooltip_lbl_language</source>
			<translation>lbl_language</translation>
		</message>
		<message>
			<source>lbl_pass</source>
			<translation>Пароль:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pass</source>
			<translation>lbl_pass</translation>
		</message>
		<message>
			<source>lbl_port</source>
			<translation>Порт:</translation>
		</message>
		<message>
			<source>tooltip_lbl_port</source>
			<translation>lbl_port</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Тип проєкту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Назва схеми:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Користувач:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
	</context>
	<context>
		<name>admin_visitclass</name>
		<message>
			<source>title</source>
			<translation>Керувати класом відвідування</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_class_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_class_cancel</source>
			<translation>btn_class_cancel</translation>
		</message>
		<message>
			<source>btn_class_ok</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_class_ok</source>
			<translation>btn_class_ok</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_param_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_param_create</source>
			<translation>btn_param_create</translation>
		</message>
		<message>
			<source>btn_param_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_param_delete</source>
			<translation>btn_param_delete</translation>
		</message>
		<message>
			<source>btn_param_update</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_btn_param_update</source>
			<translation>btn_param_update</translation>
		</message>
		<message>
			<source>dlg_admin_visitclass</source>
			<translation>Керувати класом відвідування</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_visitclass</source>
			<translation>dlg_admin_visitclass</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Клас</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Параметр</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Активний:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_class_id</source>
			<translation>Ідентифікатор класу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_class_id</source>
			<translation>lbl_class_id</translation>
		</message>
		<message>
			<source>lbl_class_name</source>
			<translation>Назва класу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_class_name</source>
			<translation>lbl_class_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_feat_type</source>
			<translation>Тип елемента:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_type</source>
			<translation>lbl_feat_type</translation>
		</message>
		<message>
			<source>lbl_multi_event</source>
			<translation>Кілька подій:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multi_event</source>
			<translation>lbl_multi_event</translation>
		</message>
		<message>
			<source>lbl_multi_feat</source>
			<translation>Кілька елементів:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multi_feat</source>
			<translation>lbl_multi_feat</translation>
		</message>
		<message>
			<source>lbl_param_opt</source>
			<translation>Опції параметра:</translation>
		</message>
		<message>
			<source>tooltip_lbl_param_opt</source>
			<translation>lbl_param_opt</translation>
		</message>
		<message>
			<source>lbl_viewname</source>
			<translation>Назва подання:</translation>
		</message>
		<message>
			<source>tooltip_lbl_viewname</source>
			<translation>lbl_viewname</translation>
		</message>
		<message>
			<source>lbl_visit_type</source>
			<translation>Тип візиту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_type</source>
			<translation>lbl_visit_type</translation>
		</message>
	</context>
	<context>
		<name>admin_visitparam</name>
		<message>
			<source>title</source>
			<translation>Керувати параметром відвідування</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_admin_visitparam</source>
			<translation>Керувати параметром відвідування</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_visitparam</source>
			<translation>dlg_admin_visitparam</translation>
		</message>
		<message>
			<source>grb_params</source>
			<translation>Параметр</translation>
		</message>
		<message>
			<source>tooltip_grb_params</source>
			<translation>grb_params</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation>Код:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_data_type</source>
			<translation>Тип Даних:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_type</source>
			<translation>lbl_data_type</translation>
		</message>
		<message>
			<source>lbl_default_value</source>
			<translation>Значення За Замовчуванням:</translation>
		</message>
		<message>
			<source>tooltip_lbl_default_value</source>
			<translation>lbl_default_value</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_editable</source>
			<translation>Редагований:</translation>
		</message>
		<message>
			<source>tooltip_lbl_editable</source>
			<translation>lbl_editable</translation>
		</message>
		<message>
			<source>lbl_enabled</source>
			<translation>Увімкнено:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enabled</source>
			<translation>lbl_enabled</translation>
		</message>
		<message>
			<source>lbl_form_type</source>
			<translation>Тип форми:</translation>
		</message>
		<message>
			<source>tooltip_lbl_form_type</source>
			<translation>lbl_form_type</translation>
		</message>
		<message>
			<source>lbl_mandatory</source>
			<translation>Обов&apos;язковий:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mandatory</source>
			<translation>lbl_mandatory</translation>
		</message>
		<message>
			<source>lbl_parameter_name</source>
			<translation>Назва параметра:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_name</source>
			<translation>lbl_parameter_name</translation>
		</message>
		<message>
			<source>lbl_parameter_type</source>
			<translation>Тип Параметра:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_type</source>
			<translation>lbl_parameter_type</translation>
		</message>
		<message>
			<source>lbl_query_text</source>
			<translation>Текст запиту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_query_text</source>
			<translation>lbl_query_text</translation>
		</message>
		<message>
			<source>lbl_short_descript</source>
			<translation>Короткий опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_short_descript</source>
			<translation>lbl_short_descript</translation>
		</message>
		<message>
			<source>lbl_widgettype</source>
			<translation>Тип віджету:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgettype</source>
			<translation>lbl_widgettype</translation>
		</message>
	</context>
	<context>
		<name>arc_fusion</name>
		<message>
			<source>title</source>
			<translation>Злиття дуги</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>ОК</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_arc_fusion</source>
			<translation>Злиття дуги</translation>
		</message>
		<message>
			<source>tooltip_dlg_arc_fusion</source>
			<translation>dlg_arc_fusion</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>lbl_arc1asset</source>
			<translation>Дуга 1 актив:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc1asset</source>
			<translation>lbl_arc1asset</translation>
		</message>
		<message>
			<source>lbl_arc1cat</source>
			<translation>Арка 1 Каталог:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc1cat</source>
			<translation>lbl_arc1cat</translation>
		</message>
		<message>
			<source>lbl_arc2asset</source>
			<translation>Дуга 2 актив:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc2asset</source>
			<translation>lbl_arc2asset</translation>
		</message>
		<message>
			<source>lbl_arc2cat</source>
			<translation>Арка 2 Каталог:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc2cat</source>
			<translation>lbl_arc2cat</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Дата Завершення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_new_asset</source>
			<translation>Новий актив:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_asset</source>
			<translation>lbl_new_asset</translation>
		</message>
		<message>
			<source>lbl_new_cat</source>
			<translation>Новий Каталог:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_cat</source>
			<translation>lbl_new_cat</translation>
		</message>
		<message>
			<source>lbl_nodeaction</source>
			<translation>Дія Вузла:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodeaction</source>
			<translation>lbl_nodeaction</translation>
		</message>
		<message>
			<source>lbl_statetype</source>
			<translation>Тип Стану:</translation>
		</message>
		<message>
			<source>tooltip_lbl_statetype</source>
			<translation>lbl_statetype</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Категорія Робіт id Кінець:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Злиття дуги</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Журнал Інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>assignation</name>
		<message>
			<source>title</source>
			<translation>Призначення збоїв</translation>
		</message>
		<message>
			<source>chk_all_leaks</source>
			<translation>Використовувати всі витоки</translation>
		</message>
		<message>
			<source>tooltip_chk_all_leaks</source>
			<translation>Calculates leaks per kilometer per year using all available data, regardless of the &apos;years to calculate&apos; parameter.</translation>
		</message>
		<message>
			<source>dlg_assignation</source>
			<translation>Призначення збоїв</translation>
		</message>
		<message>
			<source>tooltip_dlg_assignation</source>
			<translation>dlg_assignation</translation>
		</message>
		<message>
			<source>lbl_buffer</source>
			<translation>Відстань буфера (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_buffer</source>
			<translation>Distance from a leak at which pipes are selected to be assigned that leak.</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Фільтрувати за датою побудови:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>Uses only pipes that match the builtdate range of the initial one.</translation>
		</message>
		<message>
			<source>lbl_builtdate_range</source>
			<translation>Діапазон року побудови (роки):</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate_range</source>
			<translation>Built date range, in years before and after the initial pipe.</translation>
		</message>
		<message>
			<source>lbl_cluster_length</source>
			<translation>Довжина кластера (м):</translation>
		</message>
		<message>
			<source>tooltip_lbl_cluster_length</source>
			<translation>Maximum sum of pipe lengths within a cluster, in meters.</translation>
		</message>
		<message>
			<source>lbl_diameter</source>
			<translation>Фільтрувати за діаметром:</translation>
		</message>
		<message>
			<source>tooltip_lbl_diameter</source>
			<translation>Uses only pipes that match the diameter range of the initial one.</translation>
		</message>
		<message>
			<source>lbl_diameter_range</source>
			<translation>Діапазон діаметра:</translation>
		</message>
		<message>
			<source>tooltip_lbl_diameter_range</source>
			<translation>Diameter range based on factors of the initial pipe.</translation>
		</message>
		<message>
			<source>lbl_leaks</source>
			<translation>Протікання</translation>
		</message>
		<message>
			<source>tooltip_lbl_leaks</source>
			<translation>lbl_leaks</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Фільтрувати за матеріалом:</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>Uses only pipes of the same material as the initial one.</translation>
		</message>
		<message>
			<source>lbl_max_distance</source>
			<translation>Максимальна відстань (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_max_distance</source>
			<translation>Maximum distance, in meters, between the initial pipe and other pipes included in the cluster.</translation>
		</message>
		<message>
			<source>lbl_pipes</source>
			<translation>Труби</translation>
		</message>
		<message>
			<source>tooltip_lbl_pipes</source>
			<translation>lbl_pipes</translation>
		</message>
		<message>
			<source>lbl_years</source>
			<translation>Роки для розрахунку:</translation>
		</message>
		<message>
			<source>tooltip_lbl_years</source>
			<translation>Number of years of leak data to consider, based on recency.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Налаштування</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Інформаційний Журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>audit</name>
		<message>
			<source>title</source>
			<translation>Аудит</translation>
		</message>
		<message>
			<source>dlg_audit</source>
			<translation>Аудит</translation>
		</message>
		<message>
			<source>tooltip_dlg_audit</source>
			<translation>dlg_audit</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Оновлені Значення</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
	</context>
	<context>
		<name>audit_manager</name>
		<message>
			<source>title</source>
			<translation>Аудит менеджер</translation>
		</message>
		<message>
			<source>dlg_audit_manager</source>
			<translation>Аудит менеджер</translation>
		</message>
		<message>
			<source>tooltip_dlg_audit_manager</source>
			<translation>Аудит менеджер</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Журнали</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Журнали</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Дата до</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Дата до</translation>
		</message>
	</context>
	<context>
		<name>auxcircle</name>
		<message>
			<source>title</source>
			<translation>CAD Малювати коло</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_delete_prev</source>
			<translation>Видалити попередні кола</translation>
		</message>
		<message>
			<source>tooltip_chk_delete_prev</source>
			<translation>chk_delete_prev</translation>
		</message>
		<message>
			<source>dlg_auxcircle</source>
			<translation>CAD Малювати коло</translation>
		</message>
		<message>
			<source>tooltip_dlg_auxcircle</source>
			<translation>dlg_auxcircle</translation>
		</message>
		<message>
			<source>lbl_ins_radius</source>
			<translation>Вставити радіус:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ins_radius</source>
			<translation>lbl_ins_radius</translation>
		</message>
		<message>
			<source>radius</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_radius</source>
			<translation>radius</translation>
		</message>
	</context>
	<context>
		<name>auxpoint</name>
		<message>
			<source>title</source>
			<translation>CAD Додати точку</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_delete_prev</source>
			<translation>Видалити попередні точки</translation>
		</message>
		<message>
			<source>tooltip_chk_delete_prev</source>
			<translation>chk_delete_prev</translation>
		</message>
		<message>
			<source>dist_x</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_dist_x</source>
			<translation>dist_x</translation>
		</message>
		<message>
			<source>dist_y</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_dist_y</source>
			<translation>dist_y</translation>
		</message>
		<message>
			<source>dlg_auxpoint</source>
			<translation>CAD Додати точку</translation>
		</message>
		<message>
			<source>tooltip_dlg_auxpoint</source>
			<translation>dlg_auxpoint</translation>
		</message>
		<message>
			<source>grb_from</source>
			<translation>Від:</translation>
		</message>
		<message>
			<source>tooltip_grb_from</source>
			<translation>grb_from</translation>
		</message>
		<message>
			<source>lbl_distx</source>
			<translation>Відстань (X):</translation>
		</message>
		<message>
			<source>tooltip_lbl_distx</source>
			<translation>lbl_distx</translation>
		</message>
		<message>
			<source>lbl_disty</source>
			<translation>Відстань (Y):</translation>
		</message>
		<message>
			<source>tooltip_lbl_disty</source>
			<translation>lbl_disty</translation>
		</message>
		<message>
			<source>rb_left</source>
			<translation>Початкова точка</translation>
		</message>
		<message>
			<source>tooltip_rb_left</source>
			<translation>rb_left</translation>
		</message>
		<message>
			<source>rb_right</source>
			<translation>Кінцева точка</translation>
		</message>
		<message>
			<source>tooltip_rb_right</source>
			<translation>rb_right</translation>
		</message>
	</context>
	<context>
		<name>campaign_management</name>
		<message>
			<source>title</source>
			<translation>Управління Кампанією</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_child</source>
			<translation>Create Child Campaign</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_child</source>
			<translation>campaign_btn_child</translation>
		</message>
		<message>
			<source>campaign_btn_delete</source>
			<translation>Видалити кампанію</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_delete</source>
			<translation>Видалити кампанію</translation>
		</message>
		<message>
			<source>campaign_btn_open</source>
			<translation>Відкрити кампанію</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_open</source>
			<translation>Відкрити кампанію</translation>
		</message>
		<message>
			<source>campaign_chk_show_nulls</source>
			<translation>Показати null значення</translation>
		</message>
		<message>
			<source>tooltip_campaign_chk_show_nulls</source>
			<translation>Показати порожні значення</translation>
		</message>
		<message>
			<source>dlg_campaign_management</source>
			<translation>Управління Кампанією</translation>
		</message>
		<message>
			<source>tooltip_dlg_campaign_management</source>
			<translation>Управління кампанією</translation>
		</message>
		<message>
			<source>lbl_column_filter_dates</source>
			<translation>Фільтр стовпця дат</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter_dates</source>
			<translation>Стовпець фільтра дат:</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Від:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>Від:</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>До:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>До:</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Стан</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Стан:</translation>
		</message>
	</context>
	<context>
		<name>check_project</name>
		<message>
			<source>title</source>
			<translation>Перевірити проект</translation>
		</message>
		<message>
			<source>brb_database_check</source>
			<translation>Перевірка Стану Бази Даних:</translation>
		</message>
		<message>
			<source>tooltip_brb_database_check</source>
			<translation>brb_database_check</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_check_project</source>
			<translation>Перевірити проект</translation>
		</message>
		<message>
			<source>tooltip_dlg_check_project</source>
			<translation>dlg_check_project</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Інфо:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_system_check</source>
			<translation>Перевірка Стану Системи:</translation>
		</message>
		<message>
			<source>tooltip_grb_system_check</source>
			<translation>grb_system_check</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Журнал бази даних</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Журнали</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>check_project_cm</name>
		<message>
			<source>title</source>
			<translation>Перевірити проект</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>chk_manage_config</source>
			<translation>Перевірити конфігурації управління</translation>
		</message>
		<message>
			<source>tooltip_chk_manage_config</source>
			<translation>chk_manage_config</translation>
		</message>
		<message>
			<source>dlg_check_project_cm</source>
			<translation>Перевірити проект</translation>
		</message>
		<message>
			<source>tooltip_dlg_check_project_cm</source>
			<translation>dlg_check_project_cm</translation>
		</message>
		<message>
			<source>grb_database_health_check</source>
			<translation>Перевірка стану бази даних</translation>
		</message>
		<message>
			<source>tooltip_grb_database_health_check</source>
			<translation>grb_database_health_check</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Інфо:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_system_health_check</source>
			<translation>Перевірка стану системи</translation>
		</message>
		<message>
			<source>tooltip_grb_system_health_check</source>
			<translation>grb_system_health_check</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Журнал бази даних</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Журнали</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>common</name>
		<message>
			<source>btn_help</source>
			<translation>Довідка</translation>
		</message>
		<message>
			<source>tooltip_btn_help</source>
			<translation>Довідка</translation>
		</message>
	</context>
	<context>
		<name>config</name>
		<message>
			<source>title</source>
			<translation>Налаштування</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_config</source>
			<translation>Налаштування</translation>
		</message>
		<message>
			<source>tooltip_dlg_config</source>
			<translation>dlg_config</translation>
		</message>
		<message>
			<source>grb_addfields</source>
			<translation>ДодатиПоля</translation>
		</message>
		<message>
			<source>tooltip_grb_addfields</source>
			<translation>grb_addfields</translation>
		</message>
		<message>
			<source>grb_admin_om</source>
			<translation>O&amp;&amp;M</translation>
		</message>
		<message>
			<source>tooltip_grb_admin_om</source>
			<translation>grb_admin_om</translation>
		</message>
		<message>
			<source>grb_admin_other</source>
			<translation>Інше</translation>
		</message>
		<message>
			<source>tooltip_grb_admin_other</source>
			<translation>grb_admin_other</translation>
		</message>
		<message>
			<source>grb_arc</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>tooltip_grb_arc</source>
			<translation>grb_arc</translation>
		</message>
		<message>
			<source>grb_basic</source>
			<translation>Базовий</translation>
		</message>
		<message>
			<source>tooltip_grb_basic</source>
			<translation>grb_basic</translation>
		</message>
		<message>
			<source>grb_category_type</source>
			<translation>Тип категорії</translation>
		</message>
		<message>
			<source>tooltip_grb_category_type</source>
			<translation>grb_category_type</translation>
		</message>
		<message>
			<source>grb_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_grb_connec</source>
			<translation>grb_connec</translation>
		</message>
		<message>
			<source>grb_epa</source>
			<translation>Epa</translation>
		</message>
		<message>
			<source>tooltip_grb_epa</source>
			<translation>grb_epa</translation>
		</message>
		<message>
			<source>grb_fluid_type</source>
			<translation>Тип рідини</translation>
		</message>
		<message>
			<source>tooltip_grb_fluid_type</source>
			<translation>grb_fluid_type</translation>
		</message>
		<message>
			<source>grb_function_type</source>
			<translation>Тип функції</translation>
		</message>
		<message>
			<source>tooltip_grb_function_type</source>
			<translation>grb_function_type</translation>
		</message>
		<message>
			<source>grb_gully</source>
			<translation>Водоприймний Колодязь</translation>
		</message>
		<message>
			<source>tooltip_grb_gully</source>
			<translation>grb_gully</translation>
		</message>
		<message>
			<source>grb_inventory</source>
			<translation>Інвентар</translation>
		</message>
		<message>
			<source>tooltip_grb_inventory</source>
			<translation>grb_inventory</translation>
		</message>
		<message>
			<source>grb_link</source>
			<translation>Посилання</translation>
		</message>
		<message>
			<source>tooltip_grb_link</source>
			<translation>grb_link</translation>
		</message>
		<message>
			<source>grb_location_type</source>
			<translation>Тип розташування</translation>
		</message>
		<message>
			<source>tooltip_grb_location_type</source>
			<translation>grb_location_type</translation>
		</message>
		<message>
			<source>grb_masterplan</source>
			<translation>MasterPlan</translation>
		</message>
		<message>
			<source>tooltip_grb_masterplan</source>
			<translation>grb_masterplan</translation>
		</message>
		<message>
			<source>grb_node</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_grb_node</source>
			<translation>grb_node</translation>
		</message>
		<message>
			<source>grb_om</source>
			<translation>O&amp;&amp;M</translation>
		</message>
		<message>
			<source>tooltip_grb_om</source>
			<translation>grb_om</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Інше</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_system</source>
			<translation>Система</translation>
		</message>
		<message>
			<source>tooltip_grb_system</source>
			<translation>grb_system</translation>
		</message>
		<message>
			<source>grb_topology</source>
			<translation>Топологія</translation>
		</message>
		<message>
			<source>tooltip_grb_topology</source>
			<translation>grb_topology</translation>
		</message>
		<message>
			<source>grb_utils</source>
			<translation>Утиліти</translation>
		</message>
		<message>
			<source>tooltip_grb_utils</source>
			<translation>grb_utils</translation>
		</message>
		<message>
			<source>tab_addfields</source>
			<translation>ДодатиПоля</translation>
		</message>
		<message>
			<source>tooltip_tab_addfields</source>
			<translation>tab_addfields</translation>
		</message>
		<message>
			<source>tab_admin</source>
			<translation>Адмін</translation>
		</message>
		<message>
			<source>tooltip_tab_admin</source>
			<translation>tab_admin</translation>
		</message>
		<message>
			<source>tab_basic</source>
			<translation>Базовий</translation>
		</message>
		<message>
			<source>tooltip_tab_basic</source>
			<translation>tab_basic</translation>
		</message>
		<message>
			<source>tab_featurecat</source>
			<translation>Категорія елемента</translation>
		</message>
		<message>
			<source>tooltip_tab_featurecat</source>
			<translation>tab_featurecat</translation>
		</message>
		<message>
			<source>tab_mantype</source>
			<translation>Тип колодязя</translation>
		</message>
		<message>
			<source>tooltip_tab_mantype</source>
			<translation>tab_mantype</translation>
		</message>
	</context>
	<context>
		<name>connect_link</name>
		<message>
			<source>title</source>
			<translation>Підключитися До Мережі</translation>
		</message>
		<message>
			<source>dlg_connect_link</source>
			<translation>Підключитися До Мережі</translation>
		</message>
		<message>
			<source>tooltip_dlg_connect_link</source>
			<translation>dlg_connect_link</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Конфігурація Посилань</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>З&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_3</source>
			<translation>Дуги</translation>
		</message>
		<message>
			<source>tooltip_groupBox_3</source>
			<translation>groupBox_3</translation>
		</message>
		<message>
			<source>tab_connect</source>
			<translation>Посилання</translation>
		</message>
		<message>
			<source>tooltip_tab_connect</source>
			<translation>tab_connect</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Журнал Інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>csv</name>
		<message>
			<source>title</source>
			<translation>Імпорт CSV</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>btn_file_csv</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_csv</source>
			<translation>btn_file_csv</translation>
		</message>
		<message>
			<source>dlg_csv</source>
			<translation>Імпорт CSV</translation>
		</message>
		<message>
			<source>tooltip_dlg_csv</source>
			<translation>dlg_csv</translation>
		</message>
		<message>
			<source>lbl_decimal</source>
			<translation>Десятковий роздільник:</translation>
		</message>
		<message>
			<source>tooltip_lbl_decimal</source>
			<translation>lbl_decimal</translation>
		</message>
		<message>
			<source>lbl_delimiter</source>
			<translation>Роздільник:</translation>
		</message>
		<message>
			<source>tooltip_lbl_delimiter</source>
			<translation>lbl_delimiter</translation>
		</message>
		<message>
			<source>lbl_file</source>
			<translation>Файл:</translation>
		</message>
		<message>
			<source>tooltip_lbl_file</source>
			<translation>lbl_file</translation>
		</message>
		<message>
			<source>lbl_ignore_header</source>
			<translation>Ігнорувати заголовки:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ignore_header</source>
			<translation>lbl_ignore_header</translation>
		</message>
		<message>
			<source>lbl_import_label</source>
			<translation>Мітка імпорту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_import_label</source>
			<translation>lbl_import_label</translation>
		</message>
		<message>
			<source>lbl_import_type</source>
			<translation>Тип імпорту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_import_type</source>
			<translation>lbl_import_type</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Інфо:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_set_of_charac</source>
			<translation>Набір символів:</translation>
		</message>
		<message>
			<source>tooltip_lbl_set_of_charac</source>
			<translation>lbl_set_of_charac</translation>
		</message>
		<message>
			<source>rb_comma</source>
			<translation>,</translation>
		</message>
		<message>
			<source>tooltip_rb_comma</source>
			<translation>rb_comma</translation>
		</message>
		<message>
			<source>rb_dec_comma</source>
			<translation>,</translation>
		</message>
		<message>
			<source>tooltip_rb_dec_comma</source>
			<translation>rb_dec_comma</translation>
		</message>
		<message>
			<source>rb_dec_period</source>
			<translation>.</translation>
		</message>
		<message>
			<source>tooltip_rb_dec_period</source>
			<translation>rb_dec_period</translation>
		</message>
		<message>
			<source>rb_semicolon</source>
			<translation>;</translation>
		</message>
		<message>
			<source>tooltip_rb_semicolon</source>
			<translation>rb_semicolon</translation>
		</message>
		<message>
			<source>rb_space</source>
			<translation>Пробіл</translation>
		</message>
		<message>
			<source>tooltip_rb_space</source>
			<translation>rb_space</translation>
		</message>
		<message>
			<source>tab_info</source>
			<translation>Журнал інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_info</source>
			<translation>tab_info</translation>
		</message>
		<message>
			<source>tab_preview</source>
			<translation>Перегляд</translation>
		</message>
		<message>
			<source>tooltip_tab_preview</source>
			<translation>tab_preview</translation>
		</message>
	</context>
	<context>
		<name>dimensioning</name>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>grb_depth</source>
			<translation>Вимірювання</translation>
		</message>
		<message>
			<source>tooltip_grb_depth</source>
			<translation>grb_depth</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Інше</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_symbology</source>
			<translation>Символіка кола</translation>
		</message>
		<message>
			<source>tooltip_grb_symbology</source>
			<translation>grb_symbology</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>панельІнструментів</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>doc</name>
		<message>
			<source>title</source>
			<translation>Документ</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Додати геометрію</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>Додати геометрію</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Застосувати</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>Застосувати</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_path_doc</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path_doc</source>
			<translation>btn_path_doc</translation>
		</message>
		<message>
			<source>btn_path_url</source>
			<translation>веб</translation>
		</message>
		<message>
			<source>tooltip_btn_path_url</source>
			<translation>Відкрити провідник, щоб дозволити вибір веб-шляху. Також можливо просто вставити шлях у текстове поле Посилання</translation>
		</message>
		<message>
			<source>date</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_date</source>
			<translation>date</translation>
		</message>
		<message>
			<source>dlg_doc</source>
			<translation>Документ</translation>
		</message>
		<message>
			<source>tooltip_dlg_doc</source>
			<translation>dlg_doc</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Дата:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_doc_name</source>
			<translation>Ім&apos;я документа:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_name</source>
			<translation>lbl_doc_name</translation>
		</message>
		<message>
			<source>lbl_doc_type</source>
			<translation>Тип документа:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_type</source>
			<translation>lbl_doc_type</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Посилання:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>Посилання</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Спостереження:</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Візит</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>З&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_doc</source>
			<translation>Документ</translation>
		</message>
		<message>
			<source>tooltip_tab_doc</source>
			<translation>tab_doc</translation>
		</message>
		<message>
			<source>tab_elem</source>
			<translation>Елемент</translation>
		</message>
		<message>
			<source>tooltip_tab_elem</source>
			<translation>tab_elem</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Колодязь</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Посилання</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_psector</source>
			<translation>Pсектор</translation>
		</message>
		<message>
			<source>tooltip_tab_psector</source>
			<translation>tab_psector</translation>
		</message>
		<message>
			<source>tab_rel</source>
			<translation>Відносини</translation>
		</message>
		<message>
			<source>tooltip_tab_rel</source>
			<translation>tab_rel</translation>
		</message>
		<message>
			<source>tab_workcat</source>
			<translation>Категорія Робіт</translation>
		</message>
		<message>
			<source>tooltip_tab_workcat</source>
			<translation>tab_workcat</translation>
		</message>
	</context>
	<context>
		<name>doc_manager</name>
		<message>
			<source>title</source>
			<translation>Управління документами</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_doc_manager</source>
			<translation>Управління документами</translation>
		</message>
		<message>
			<source>tooltip_dlg_doc_manager</source>
			<translation>dlg_doc_manager</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Фільтрувати за: Назва документа</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>dscenario</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_properties</source>
			<translation>Властивості</translation>
		</message>
		<message>
			<source>tooltip_btn_properties</source>
			<translation>btn_properties</translation>
		</message>
		<message>
			<source>dlg_dscenario</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_dscenario</source>
			<translation>dlg_dscenario</translation>
		</message>
	</context>
	<context>
		<name>dscenario_manager</name>
		<message>
			<source>title</source>
			<translation>Dscenario manager</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Дублювати</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Перемкнути активність</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Перемкнути активність</translation>
		</message>
		<message>
			<source>btn_toolbox</source>
			<translation>Дії</translation>
		</message>
		<message>
			<source>tooltip_btn_toolbox</source>
			<translation>btn_toolbox</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>btn_update_dscenario</source>
			<translation>Поточний Dscenario</translation>
		</message>
		<message>
			<source>tooltip_btn_update_dscenario</source>
			<translation>btn_update_dscenario</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Показати неактивні</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Показати неактивні</translation>
		</message>
		<message>
			<source>dlg_dscenario_manager</source>
			<translation>Dscenario manager</translation>
		</message>
		<message>
			<source>tooltip_dlg_dscenario_manager</source>
			<translation>dlg_dscenario_manager</translation>
		</message>
		<message>
			<source>lbl_dscenario_name</source>
			<translation>Фільтрувати за: Dscenario name</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario_name</source>
			<translation>lbl_dscenario_name</translation>
		</message>
	</context>
	<context>
		<name>element_manager</name>
		<message>
			<source>title</source>
			<translation>Управління елементами</translation>
		</message>
		<message>
			<source>dlg_element_manager</source>
			<translation>Управління елементами</translation>
		</message>
		<message>
			<source>tooltip_dlg_element_manager</source>
			<translation>dlg_element_manager</translation>
		</message>
	</context>
	<context>
		<name>epa_export</name>
		<message>
			<source>title</source>
			<translation>Export EPA Result Families</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Accept</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_browse</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_browse</source>
			<translation>btn_browse</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancel</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_format_json</source>
			<translation>Format Json</translation>
		</message>
		<message>
			<source>tooltip_chk_format_json</source>
			<translation>chk_format_json</translation>
		</message>
		<message>
			<source>dlg_epa_export</source>
			<translation>Export EPA Result Families</translation>
		</message>
		<message>
			<source>tooltip_dlg_epa_export</source>
			<translation>dlg_epa_export</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Export path:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Result ID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
	</context>
	<context>
		<name>epatools_add_demand_check</name>
		<message>
			<source>title</source>
			<translation>Додаткова перевірка попиту</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_add_demand_check</source>
			<translation>Додаткова перевірка попиту</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_add_demand_check</source>
			<translation>dlg_epatools_add_demand_check</translation>
		</message>
		<message>
			<source>lbl_config</source>
			<translation>Файл Конфігурації:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config</source>
			<translation>lbl_config</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Ім&apos;я файлу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Вхідний файл INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Використовувати вузли з:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Папка Виводу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>rdb_nodes_config</source>
			<translation>Файл конфігурації</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_config</source>
			<translation>Retrieve node data from the &amp;quot;nodes&amp;quot; property within the configuration file.</translation>
		</message>
		<message>
			<source>rdb_nodes_database</source>
			<translation>База Даних</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_database</source>
			<translation>Retrieve node data with fid=491 from the anl_node table.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Конфіг</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Журнал інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_emitter_calibration</name>
		<message>
			<source>title</source>
			<translation>Калібрування випромінювача</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_emitter_calibration</source>
			<translation>Калібрування випромінювача</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_emitter_calibration</source>
			<translation>dlg_epatools_emitter_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Файл Конфігурації:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Ім&apos;я Файлу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Вхідний INP файл:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_filename</source>
			<translation>Вихідні файли ім&apos;я:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_filename</source>
			<translation>lbl_output_filename</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Конфіг</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Журнал Інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>epatools_quantized_demands</name>
		<message>
			<source>title</source>
			<translation>Квантизовані потреби</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_quantized_demands</source>
			<translation>Квантизовані потреби</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_quantized_demands</source>
			<translation>dlg_epatools_quantized_demands</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Файл Конфігурації:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Ім&apos;я Файлу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Вхідний INP файл:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Тека Виводу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Налаштування</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Інформаційний Журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_recursive_go2epa</name>
		<message>
			<source>title</source>
			<translation>Epa Багато Викликів</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_recursive_go2epa</source>
			<translation>Epa Багато Викликів</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_recursive_go2epa</source>
			<translation>dlg_epatools_recursive_go2epa</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Файл конфігурації:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Ім&apos;я Файлу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Тека Виводу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Конфігурація</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Журнал інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_static_calibration</name>
		<message>
			<source>title</source>
			<translation>Статичне калібрування</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>ОК</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>btn_save_dscenario</source>
			<translation>Зберегти зміни в dсценарій</translation>
		</message>
		<message>
			<source>tooltip_btn_save_dscenario</source>
			<translation>btn_save_dscenario</translation>
		</message>
		<message>
			<source>dlg_epatools_static_calibration</source>
			<translation>Статичне калібрування</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_static_calibration</source>
			<translation>dlg_epatools_static_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Файл Конфігурації:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>The .ini file with the calibrations to make</translation>
		</message>
		<message>
			<source>lbl_dscenario</source>
			<translation>Dсценарій:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario</source>
			<translation>lbl_dscenario</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Назва Файлу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_inp_input_file</source>
			<translation>Вхідний INP Файл:</translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_input_file</source>
			<translation>The EPANET file to calibrate</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Тека Виводу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Конфіг</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Інформаційний Журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_valve_operation_check</name>
		<message>
			<source>title</source>
			<translation>Перевірка Роботи Клапана</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>ОК</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_valve_operation_check</source>
			<translation>Перевірка Роботи Клапана</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_valve_operation_check</source>
			<translation>dlg_epatools_valve_operation_check</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Файл Конфігурації:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Ім&apos;я Файлу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Вхідний INP файл:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Папка виводу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>lbl_scenarios</source>
			<translation>Використовувати сценарії з:</translation>
		</message>
		<message>
			<source>tooltip_lbl_scenarios</source>
			<translation>lbl_scenarios</translation>
		</message>
		<message>
			<source>rdb_scenarios_config</source>
			<translation>Файл Конфігурації</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_config</source>
			<translation>Retrieve scenarios data from the [SCENARIOS] section within the configuration file.</translation>
		</message>
		<message>
			<source>rdb_scenarios_database</source>
			<translation>База даних</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_database</source>
			<translation>Retrieve scenarios data with fid=493 from the anl_arc table.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Конфіг</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Інформаційний журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>feature_delete</name>
		<message>
			<source>title</source>
			<translation>Видалити елемент</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити вибраний елемент</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>btn_delete_another</source>
			<translation>Видалити інший елемент</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_another</source>
			<translation>btn_delete_another</translation>
		</message>
		<message>
			<source>btn_relations</source>
			<translation>Показати зв&apos;язки елемента</translation>
		</message>
		<message>
			<source>tooltip_btn_relations</source>
			<translation>btn_relations</translation>
		</message>
		<message>
			<source>dlg_feature_delete</source>
			<translation>Видалити елемент</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_delete</source>
			<translation>dlg_feature_delete</translation>
		</message>
		<message>
			<source>lbl_feature_id</source>
			<translation>Ідентифікатор елемента:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_id</source>
			<translation>lbl_feature_id</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Тип елемента:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>tab_del_feature</source>
			<translation>Видалити елемент</translation>
		</message>
		<message>
			<source>tooltip_tab_del_feature</source>
			<translation>tab_del_feature</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Журнал інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>feature_end</name>
		<message>
			<source>title</source>
			<translation>Кінець елемента</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>btn_new_workcat</source>
			<translation>btn_new_workcat</translation>
		</message>
		<message>
			<source>tooltip_btn_new_workcat</source>
			<translation>btn_new_workcat</translation>
		</message>
		<message>
			<source>builtdate</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_builtdate</source>
			<translation>builtdate</translation>
		</message>
		<message>
			<source>dlg_feature_end</source>
			<translation>Кінець елемента</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_end</source>
			<translation>dlg_feature_end</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Кінцева дата:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_state_type</source>
			<translation>Тип стану в кінці:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state_type</source>
			<translation>lbl_state_type</translation>
		</message>
		<message>
			<source>lbl_workcat_date</source>
			<translation>Дата Workcat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_date</source>
			<translation>lbl_workcat_date</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Workcat id кінця:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>З&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_elem</source>
			<translation>Елемент</translation>
		</message>
		<message>
			<source>tooltip_tab_elem</source>
			<translation>tab_elem</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Ливневий колодязь</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Журнал інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Посилання</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Зв&apos;язки</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Зв&apos;язки</translation>
		</message>
		<message>
			<source>tab_workcat</source>
			<translation>Workcat</translation>
		</message>
		<message>
			<source>tooltip_tab_workcat</source>
			<translation>tab_workcat</translation>
		</message>
	</context>
	<context>
		<name>feature_end_connec</name>
		<message>
			<source>title</source>
			<translation>workcat кінець списку</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>dlg_feature_end_connec</source>
			<translation>workcat кінець списку</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_end_connec</source>
			<translation>dlg_feature_end_connec</translation>
		</message>
		<message>
			<source>lbl_filter_by</source>
			<translation>Фільтрувати за arc_id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_by</source>
			<translation>lbl_filter_by</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>ці connecs або gullys будуть від&apos;єднані, коли будуть видалені вибрані arcs</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
	</context>
	<context>
		<name>feature_replace</name>
		<message>
			<source>title</source>
			<translation>Замінити елемент</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Гаразд</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>config</source>
			<translation>Конфігурація</translation>
		</message>
		<message>
			<source>tooltip_config</source>
			<translation>config</translation>
		</message>
		<message>
			<source>dlg_feature_replace</source>
			<translation>Замінити елемент</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_replace</source>
			<translation>dlg_feature_replace</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>grb_end_parameters</source>
			<translation>Кінцеві Параметри</translation>
		</message>
		<message>
			<source>tooltip_grb_end_parameters</source>
			<translation>grb_end_parameters</translation>
		</message>
		<message>
			<source>grb_feature_parameters</source>
			<translation>Параметри Елемента</translation>
		</message>
		<message>
			<source>tooltip_grb_feature_parameters</source>
			<translation>grb_feature_parameters</translation>
		</message>
		<message>
			<source>lbl_current_catalog_id</source>
			<translation>Поточний Каталог id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_current_catalog_id</source>
			<translation>lbl_current_catalog_id</translation>
		</message>
		<message>
			<source>lbl_description</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_description</source>
			<translation>lbl_description</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Замінити Дату:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Поточний Тип Елемента:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>lbl_keep_asset_id</source>
			<translation>Зберегти Ідентифікатор Активу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_asset_id</source>
			<translation>lbl_keep_asset_id</translation>
		</message>
		<message>
			<source>lbl_keep_customer_code</source>
			<translation>Keep customer code:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_customer_code</source>
			<translation>lbl_keep_customer_code</translation>
		</message>
		<message>
			<source>lbl_keep_elements</source>
			<translation>Зберегти Елементи:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_elements</source>
			<translation>lbl_keep_elements</translation>
		</message>
		<message>
			<source>lbl_keep_epa_values</source>
			<translation>Зберегти Значення EPA:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_epa_values</source>
			<translation>lbl_keep_epa_values</translation>
		</message>
		<message>
			<source>lbl_keep_sys_code</source>
			<translation>Keep sys code:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_sys_code</source>
			<translation>lbl_keep_sys_code</translation>
		</message>
		<message>
			<source>lbl_new_catalog_id</source>
			<translation>Новий Каталог id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_catalog_id</source>
			<translation>lbl_new_catalog_id</translation>
		</message>
		<message>
			<source>lbl_new_feature_type</source>
			<translation>Новий тип елемента:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_feature_type</source>
			<translation>lbl_new_feature_type</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>workcat id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Журнал інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>featuretype_change</name>
		<message>
			<source>title</source>
			<translation>Змінити тип елемента</translation>
		</message>
		<message>
			<source>dlg_featuretype_change</source>
			<translation>Змінити тип елемента</translation>
		</message>
		<message>
			<source>tooltip_dlg_featuretype_change</source>
			<translation>dlg_featuretype_change</translation>
		</message>
	</context>
	<context>
		<name>go2epa</name>
		<message>
			<source>title</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>btn_file_inp</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_inp</source>
			<translation>btn_file_inp</translation>
		</message>
		<message>
			<source>btn_file_rpt</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_rpt</source>
			<translation>btn_file_rpt</translation>
		</message>
		<message>
			<source>btn_hs_ds</source>
			<translation>Селектор</translation>
		</message>
		<message>
			<source>tooltip_btn_hs_ds</source>
			<translation>btn_hs_ds</translation>
		</message>
		<message>
			<source>btn_options</source>
			<translation>Параметри</translation>
		</message>
		<message>
			<source>tooltip_btn_options</source>
			<translation>btn_options</translation>
		</message>
		<message>
			<source>chk_exec</source>
			<translation>Виконати програмне забезпечення EPA</translation>
		</message>
		<message>
			<source>tooltip_chk_exec</source>
			<translation>chk_exec</translation>
		</message>
		<message>
			<source>chk_export</source>
			<translation>Експортувати INP</translation>
		</message>
		<message>
			<source>tooltip_chk_export</source>
			<translation>chk_export</translation>
		</message>
		<message>
			<source>chk_export_subcatch</source>
			<translation>Експорт UD  підбасейнів</translation>
		</message>
		<message>
			<source>tooltip_chk_export_subcatch</source>
			<translation>chk_export_subcatch</translation>
		</message>
		<message>
			<source>chk_import_result</source>
			<translation>Імпортувати результат</translation>
		</message>
		<message>
			<source>tooltip_chk_import_result</source>
			<translation>chk_import_result</translation>
		</message>
		<message>
			<source>dlg_go2epa</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa</source>
			<translation>dlg_go2epa</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Параметри попередньої обробки</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Менеджер файлів</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_inp_file</source>
			<translation>Файл INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_file</source>
			<translation>lbl_inp_file</translation>
		</message>
		<message>
			<source>lbl_result_name</source>
			<translation>Ім&apos;я результату:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name</source>
			<translation>lbl_result_name</translation>
		</message>
		<message>
			<source>lbl_rpt_file</source>
			<translation>RPT файл:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rpt_file</source>
			<translation>lbl_rpt_file</translation>
		</message>
		<message>
			<source>tab_file_manager</source>
			<translation>Менеджер файлів</translation>
		</message>
		<message>
			<source>tooltip_tab_file_manager</source>
			<translation>tab_file_manager</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Інфо журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>go2epa_manager</name>
		<message>
			<source>title</source>
			<translation>Epa керування результатами</translation>
		</message>
		<message>
			<source>btn_archive</source>
			<translation>Перемкнути архів</translation>
		</message>
		<message>
			<source>tooltip_btn_archive</source>
			<translation>Перемкнути архів</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>btn_edit</source>
			<translation>Редагувати</translation>
		</message>
		<message>
			<source>tooltip_btn_edit</source>
			<translation>Редагувати</translation>
		</message>
		<message>
			<source>btn_show_inp_data</source>
			<translation>Показати дані inp</translation>
		</message>
		<message>
			<source>tooltip_btn_show_inp_data</source>
			<translation>Показати inp дані</translation>
		</message>
		<message>
			<source>btn_toggle_corporate</source>
			<translation>Перемк��ути корпоративний</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_corporate</source>
			<translation>btn_toggle_corporate</translation>
		</message>
		<message>
			<source>dlg_go2epa_manager</source>
			<translation>Epa керування результатами</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_manager</source>
			<translation>dlg_go2epa_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Інфо:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Фільтрувати за: Результат id</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
	</context>
	<context>
		<name>go2epa_options</name>
		<message>
			<source>title</source>
			<translation>Go2Epa - параметри</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_go2epa_options</source>
			<translation>Go2Epa - параметри</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_options</source>
			<translation>dlg_go2epa_options</translation>
		</message>
		<message>
			<source>grb_energy</source>
			<translation>Енергія</translation>
		</message>
		<message>
			<source>tooltip_grb_energy</source>
			<translation>grb_energy</translation>
		</message>
		<message>
			<source>grb_general</source>
			<translation>Загальні</translation>
		</message>
		<message>
			<source>tooltip_grb_general</source>
			<translation>grb_general</translation>
		</message>
		<message>
			<source>grb_hydraulics</source>
			<translation>Гідравліка</translation>
		</message>
		<message>
			<source>tooltip_grb_hydraulics</source>
			<translation>grb_hydraulics</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Інше</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_reactions</source>
			<translation>Реакції</translation>
		</message>
		<message>
			<source>tooltip_grb_reactions</source>
			<translation>grb_reactions</translation>
		</message>
		<message>
			<source>grb_reports</source>
			<translation>Звіти</translation>
		</message>
		<message>
			<source>tooltip_grb_reports</source>
			<translation>grb_reports</translation>
		</message>
		<message>
			<source>grb_time_steps</source>
			<translation>Дата &amp;amp; кроки часу</translation>
		</message>
		<message>
			<source>tooltip_grb_time_steps</source>
			<translation>grb_time_steps</translation>
		</message>
		<message>
			<source>tab_inp</source>
			<translation>Inp</translation>
		</message>
		<message>
			<source>tooltip_tab_inp</source>
			<translation>tab_inp</translation>
		</message>
		<message>
			<source>tab_other</source>
			<translation>Інше</translation>
		</message>
		<message>
			<source>tooltip_tab_other</source>
			<translation>tab_other</translation>
		</message>
	</context>
	<context>
		<name>go2epa_selector</name>
		<message>
			<source>title</source>
			<translation>Селектор Порівняння Результатів</translation>
		</message>
		<message>
			<source>dlg_go2epa_selector</source>
			<translation>Селектор Порівняння Результатів</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_selector</source>
			<translation>dlg_go2epa_selector</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Результат</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
		<message>
			<source>tab_time</source>
			<translation>Дата й Час</translation>
		</message>
		<message>
			<source>tooltip_tab_time</source>
			<translation>tab_time</translation>
		</message>
	</context>
	<context>
		<name>go2iber</name>
		<message>
			<source>title</source>
			<translation>Go2Iber</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_iber_options</source>
			<translation>Iber Опції</translation>
		</message>
		<message>
			<source>tooltip_btn_iber_options</source>
			<translation>Iber Опції</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_swmm_options</source>
			<translation>SWMM Параметри</translation>
		</message>
		<message>
			<source>tooltip_btn_swmm_options</source>
			<translation>SWMM Параметри</translation>
		</message>
		<message>
			<source>dlg_go2iber</source>
			<translation>Go2Iber</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2iber</source>
			<translation>dlg_go2iber</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Параметри</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>lbl_mesh</source>
			<translation>Сітка:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mesh</source>
			<translation>lbl_mesh</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Шлях до папки:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
		<message>
			<source>lbl_result_name</source>
			<translation>Назва результату:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name</source>
			<translation>lbl_result_name</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Конфігурація</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>info_catalog</name>
		<message>
			<source>title</source>
			<translation>Каталог</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_info_catalog</source>
			<translation>Каталог</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_catalog</source>
			<translation>dlg_info_catalog</translation>
		</message>
	</context>
	<context>
		<name>info_crossect</name>
		<message>
			<source>title</source>
			<translation>Розділ</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>dlg_info_crossect</source>
			<translation>Розділ</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_crossect</source>
			<translation>dlg_info_crossect</translation>
		</message>
		<message>
			<source>lbl_cost_area</source>
			<translation>Площа Трубопроводу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_area</source>
			<translation>lbl_cost_area</translation>
		</message>
		<message>
			<source>lbl_cost_bulk</source>
			<translation>Об&apos;єм трубопроводу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_bulk</source>
			<translation>lbl_cost_bulk</translation>
		</message>
		<message>
			<source>lbl_cost_exc</source>
			<translation>m3/ml Надлишок:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_exc</source>
			<translation>lbl_cost_exc</translation>
		</message>
		<message>
			<source>lbl_cost_excav</source>
			<translation>m3/ml Розкопки:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_excav</source>
			<translation>lbl_cost_excav</translation>
		</message>
		<message>
			<source>lbl_cost_fill</source>
			<translation>m3/ml Заповнення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_fill</source>
			<translation>lbl_cost_fill</translation>
		</message>
		<message>
			<source>lbl_cost_trench</source>
			<translation>% Облицювання Траншеї:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_trench</source>
			<translation>lbl_cost_trench</translation>
		</message>
	</context>
	<context>
		<name>info_epa</name>
		<message>
			<source>title</source>
			<translation>ІнфоEPA</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_info_epa</source>
			<translation>ІнфоEPA</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_epa</source>
			<translation>dlg_info_epa</translation>
		</message>
		<message>
			<source>page_base</source>
			<translation>База</translation>
		</message>
		<message>
			<source>tooltip_page_base</source>
			<translation>page_base</translation>
		</message>
		<message>
			<source>page_dscenario</source>
			<translation>Dсценарій</translation>
		</message>
		<message>
			<source>tooltip_page_dscenario</source>
			<translation>page_dscenario</translation>
		</message>
		<message>
			<source>page_dwf</source>
			<translation>DWF</translation>
		</message>
		<message>
			<source>tooltip_page_dwf</source>
			<translation>page_dwf</translation>
		</message>
		<message>
			<source>page_inflows</source>
			<translation>ПРИТОКИ</translation>
		</message>
		<message>
			<source>tooltip_page_inflows</source>
			<translation>page_inflows</translation>
		</message>
	</context>
	<context>
		<name>info_feature</name>
		<message>
			<source>title</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Застосувати</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>Застосувати</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>btn_link</source>
			<translation>btn_link</translation>
		</message>
		<message>
			<source>tooltip_btn_link</source>
			<translation>btn_link</translation>
		</message>
		<message>
			<source>btn_new_element</source>
			<translation>btn_new_element</translation>
		</message>
		<message>
			<source>tooltip_btn_new_element</source>
			<translation>btn_new_element</translation>
		</message>
		<message>
			<source>btn_new_visit</source>
			<translation>btn_new_visit</translation>
		</message>
		<message>
			<source>tooltip_btn_new_visit</source>
			<translation>btn_new_visit</translation>
		</message>
		<message>
			<source>btn_open_element</source>
			<translation>btn_open_element</translation>
		</message>
		<message>
			<source>tooltip_btn_open_element</source>
			<translation>btn_open_element</translation>
		</message>
		<message>
			<source>btn_open_gallery</source>
			<translation>btn_open_gallery</translation>
		</message>
		<message>
			<source>tooltip_btn_open_gallery</source>
			<translation>btn_open_gallery</translation>
		</message>
		<message>
			<source>btn_open_visit</source>
			<translation>btn_open_visit</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit</source>
			<translation>btn_open_visit</translation>
		</message>
		<message>
			<source>btn_open_visit_doc</source>
			<translation>btn_open_visit_doc</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit_doc</source>
			<translation>btn_open_visit_doc</translation>
		</message>
		<message>
			<source>btn_open_visit_event</source>
			<translation>btn_open_visit_event</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit_event</source>
			<translation>btn_open_visit_event</translation>
		</message>
		<message>
			<source>dlg_info_feature</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_feature</source>
			<translation>dlg_info_feature</translation>
		</message>
		<message>
			<source>grb_frelem_dscenario</source>
			<translation>Dсценарій</translation>
		</message>
		<message>
			<source>tooltip_grb_frelem_dscenario</source>
			<translation>grb_frelem_dscenario</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>INP</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>RPT</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>page</source>
			<translation>Дані</translation>
		</message>
		<message>
			<source>tooltip_page</source>
			<translation>page</translation>
		</message>
		<message>
			<source>page_2</source>
			<translation>Dсценарій</translation>
		</message>
		<message>
			<source>tooltip_page_2</source>
			<translation>page_2</translation>
		</message>
		<message>
			<source>page_add</source>
			<translation>Додаткові Дані</translation>
		</message>
		<message>
			<source>tooltip_page_add</source>
			<translation>page_add</translation>
		</message>
		<message>
			<source>page_main</source>
			<translation>Основні Дані</translation>
		</message>
		<message>
			<source>tooltip_page_main</source>
			<translation>page_main</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>З&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_connections</source>
			<translation>З&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_tab_connections</source>
			<translation>tab_connections</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Дані</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_documents</source>
			<translation>Документ</translation>
		</message>
		<message>
			<source>tooltip_tab_documents</source>
			<translation>tab_documents</translation>
		</message>
		<message>
			<source>tab_elements</source>
			<translation>Елементи</translation>
		</message>
		<message>
			<source>tooltip_tab_elements</source>
			<translation>tab_elements</translation>
		</message>
		<message>
			<source>tab_epa</source>
			<translation>EPA</translation>
		</message>
		<message>
			<source>tooltip_tab_epa</source>
			<translation>tab_epa</translation>
		</message>
		<message>
			<source>tab_event</source>
			<translation>Подія</translation>
		</message>
		<message>
			<source>tooltip_tab_event</source>
			<translation>tab_event</translation>
		</message>
		<message>
			<source>tab_features</source>
			<translation>Елементи</translation>
		</message>
		<message>
			<source>tooltip_tab_features</source>
			<translation>tab_features</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Колодязь</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_hydrometer</source>
			<translation>Гідрометр</translation>
		</message>
		<message>
			<source>tooltip_tab_hydrometer</source>
			<translation>tab_hydrometer</translation>
		</message>
		<message>
			<source>tab_hydrometer_val</source>
			<translation>Значення Гідрометра</translation>
		</message>
		<message>
			<source>tooltip_tab_hydrometer_val</source>
			<translation>tab_hydrometer_val</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Зв&apos;язок</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_orifice</source>
			<translation>Отвір</translation>
		</message>
		<message>
			<source>tooltip_tab_orifice</source>
			<translation>tab_orifice</translation>
		</message>
		<message>
			<source>tab_outlet</source>
			<translation>Вихід</translation>
		</message>
		<message>
			<source>tooltip_tab_outlet</source>
			<translation>tab_outlet</translation>
		</message>
		<message>
			<source>tab_plan</source>
			<translation>План</translation>
		</message>
		<message>
			<source>tooltip_tab_plan</source>
			<translation>tab_plan</translation>
		</message>
		<message>
			<source>tab_pump</source>
			<translation>Насос</translation>
		</message>
		<message>
			<source>tooltip_tab_pump</source>
			<translation>tab_pump</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Зв&apos;язки</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Зв&apos;язки</translation>
		</message>
		<message>
			<source>tab_rpt</source>
			<translation>Звіт</translation>
		</message>
		<message>
			<source>tooltip_tab_rpt</source>
			<translation>tab_rpt</translation>
		</message>
		<message>
			<source>tab_shortpipe</source>
			<translation>Shortтруба</translation>
		</message>
		<message>
			<source>tooltip_tab_shortpipe</source>
			<translation>tab_shortpipe</translation>
		</message>
		<message>
			<source>tab_valve</source>
			<translation>Клапан</translation>
		</message>
		<message>
			<source>tooltip_tab_valve</source>
			<translation>tab_valve</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Відвід</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
		<message>
			<source>tab_weir</source>
			<translation>Перелив</translation>
		</message>
		<message>
			<source>tooltip_tab_weir</source>
			<translation>tab_weir</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>панельІнструментів</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>info_generic</name>
		<message>
			<source>title</source>
			<translation>Основна Інформація</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_info_generic</source>
			<translation>Основна Інформація</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_generic</source>
			<translation>dlg_info_generic</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>інструментПанель</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>info_workcat</name>
		<message>
			<source>title</source>
			<translation>Новий категоріяробіт</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>builtdate</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_builtdate</source>
			<translation>builtdate</translation>
		</message>
		<message>
			<source>dlg_info_workcat</source>
			<translation>Новий категоріяробіт</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_workcat</source>
			<translation>dlg_info_workcat</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Дата Побудови:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>lbl_builtdate</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Посилання:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>lbl_link</translation>
		</message>
		<message>
			<source>lbl_work_id</source>
			<translation>Ідентифікатор Роботи:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_id</source>
			<translation>lbl_work_id</translation>
		</message>
		<message>
			<source>lbl_workid_key_1</source>
			<translation>Ключ Ідентифікатора Роботи 1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workid_key_1</source>
			<translation>lbl_workid_key_1</translation>
		</message>
		<message>
			<source>lbl_workid_key_2</source>
			<translation>Ключ Ідентифікатора Роботи 2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workid_key_2</source>
			<translation>lbl_workid_key_2</translation>
		</message>
	</context>
	<context>
		<name>inp_config_import</name>
		<message>
			<source>title</source>
			<translation>Конфігурація INP імпорт</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_load</source>
			<translation>Завантажити...</translation>
		</message>
		<message>
			<source>tooltip_btn_load</source>
			<translation>btn_load</translation>
		</message>
		<message>
			<source>btn_reload</source>
			<translation>Перезавантажити параметри</translation>
		</message>
		<message>
			<source>tooltip_btn_reload</source>
			<translation>btn_reload</translation>
		</message>
		<message>
			<source>btn_save</source>
			<translation>Зберегти...</translation>
		</message>
		<message>
			<source>tooltip_btn_save</source>
			<translation>btn_save</translation>
		</message>
		<message>
			<source>chk_force_commit</source>
			<translation>Примусове підтвердження</translation>
		</message>
		<message>
			<source>tooltip_chk_force_commit</source>
			<translation>chk_force_commit</translation>
		</message>
		<message>
			<source>dlg_inp_config_import</source>
			<translation>Конфігурація INP імпорт</translation>
		</message>
		<message>
			<source>tooltip_dlg_inp_config_import</source>
			<translation>dlg_inp_config_import</translation>
		</message>
		<message>
			<source>grb_basic</source>
			<translation>Базовий</translation>
		</message>
		<message>
			<source>tooltip_grb_basic</source>
			<translation>grb_basic</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Інформація</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_mapzones</source>
			<translation>Зони карти</translation>
		</message>
		<message>
			<source>tooltip_grb_mapzones</source>
			<translation>grb_mapzones</translation>
		</message>
		<message>
			<source>label</source>
			<translation>PСектор:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Експлуатація:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Муніципалітет:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Сектор:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>lbl_arcs</source>
			<translation>Виберіть відповідний arccat_id для кожної комбінації дуг з наведених нижче варіантів. Якщо ви оберете &quot;Створити новий&quot;, введіть нове ім&apos;я в стовпець &quot;Нова назва каталогу&quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_arcs</source>
			<translation>lbl_arcs</translation>
		</message>
		<message>
			<source>lbl_dscenario</source>
			<translation>Потреби dscenario ім&apos;я:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario</source>
			<translation>lbl_dscenario</translation>
		</message>
		<message>
			<source>lbl_feature</source>
			<translation>Виберіть відповідний feature_id для кожного типу EPA із наведених нижче варіантів. Якщо потрібно, ви можете додати новий тип функції в каталог Giswater і натиснути кнопку «Перезавантажити Опції» нижче.</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature</source>
			<translation>lbl_feature</translation>
		</message>
		<message>
			<source>lbl_flwreg</source>
			<translation>Виберіть відповідний ідентифікатор каталогу для кожного регулятора потоку з наведених нижче варіантів. Якщо ви вибрали &amp;quot;Create new&amp;quot;, введіть нове ім&apos;я в колонці &amp;quot;New catalog name&amp;quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_flwreg</source>
			<translation>lbl_flwreg</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Виберіть відповідний матеріал для кожного значення шорсткості з наведених нижче варіантів. Якщо потрібно, ви можете додати новий матеріал у каталог Giswater і натиснути кнопку «Перезавантажити Опції» нижче.</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>lbl_material</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Виберіть відповідний nodecat_id для кожного типу EPA з наведених нижче варіантів. Якщо ви оберете &quot;Створити новий&quot;, введіть нове ім&apos;я в стовпець &quot;Нова назва каталогу&quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_raingage</source>
			<translation>За замовчуванням дощомір:</translation>
		</message>
		<message>
			<source>tooltip_lbl_raingage</source>
			<translation>lbl_raingage</translation>
		</message>
		<message>
			<source>lbl_workcat</source>
			<translation>Workcat_id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat</source>
			<translation>lbl_workcat</translation>
		</message>
		<message>
			<source>tab_arccat</source>
			<translation>Дуги</translation>
		</message>
		<message>
			<source>tooltip_tab_arccat</source>
			<translation>tab_arccat</translation>
		</message>
		<message>
			<source>tab_basic</source>
			<translation>Базовий</translation>
		</message>
		<message>
			<source>tooltip_tab_basic</source>
			<translation>tab_basic</translation>
		</message>
		<message>
			<source>tab_feature</source>
			<translation>Функції</translation>
		</message>
		<message>
			<source>tooltip_tab_feature</source>
			<translation>tab_feature</translation>
		</message>
		<message>
			<source>tab_flwreg</source>
			<translation>Регулятори витрати</translation>
		</message>
		<message>
			<source>tooltip_tab_flwreg</source>
			<translation>tab_flwreg</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Інформаційний Журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_material</source>
			<translation>Матеріал</translation>
		</message>
		<message>
			<source>tooltip_tab_material</source>
			<translation>tab_material</translation>
		</message>
		<message>
			<source>tab_nodecat</source>
			<translation>Вузли</translation>
		</message>
		<message>
			<source>tooltip_tab_nodecat</source>
			<translation>tab_nodecat</translation>
		</message>
		<message>
			<source>tbl_arcs</source>
			<translation>Нова назва каталогу</translation>
		</message>
		<message>
			<source>tooltip_tbl_arcs</source>
			<translation>tbl_arcs</translation>
		</message>
		<message>
			<source>tbl_feature</source>
			<translation>Функція</translation>
		</message>
		<message>
			<source>tooltip_tbl_feature</source>
			<translation>tbl_feature</translation>
		</message>
		<message>
			<source>tbl_flwreg</source>
			<translation>Нова Назва Каталогу</translation>
		</message>
		<message>
			<source>tooltip_tbl_flwreg</source>
			<translation>tbl_flwreg</translation>
		</message>
		<message>
			<source>tbl_material</source>
			<translation>Матеріал</translation>
		</message>
		<message>
			<source>tooltip_tbl_material</source>
			<translation>tbl_material</translation>
		</message>
		<message>
			<source>tbl_nodes</source>
			<translation>Нова Назва Каталогу</translation>
		</message>
		<message>
			<source>tooltip_tbl_nodes</source>
			<translation>tbl_nodes</translation>
		</message>
	</context>
	<context>
		<name>inp_parsing</name>
		<message>
			<source>title</source>
			<translation>Парсинг Файлу INP</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>dlg_inp_parsing</source>
			<translation>Парсинг Файлу INP</translation>
		</message>
		<message>
			<source>tooltip_dlg_inp_parsing</source>
			<translation>dlg_inp_parsing</translation>
		</message>
		<message>
			<source>tab_databaselog</source>
			<translation>Інформаційний Журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_databaselog</source>
			<translation>tab_databaselog</translation>
		</message>
	</context>
	<context>
		<name>interpolate</name>
		<message>
			<source>title</source>
			<translation>Інтерполювати</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_interpolate</source>
			<translation>Інтерполювати</translation>
		</message>
		<message>
			<source>tooltip_dlg_interpolate</source>
			<translation>dlg_interpolate</translation>
		</message>
		<message>
			<source>rb_extrapolate</source>
			<translation>Екстраполювати</translation>
		</message>
		<message>
			<source>tooltip_rb_extrapolate</source>
			<translation>rb_extrapolate</translation>
		</message>
		<message>
			<source>rb_interpolate</source>
			<translation>Інтерполювати</translation>
		</message>
		<message>
			<source>tooltip_rb_interpolate</source>
			<translation>rb_interpolate</translation>
		</message>
	</context>
	<context>
		<name>load_menu</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_load_menu</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_load_menu</source>
			<translation>dlg_load_menu</translation>
		</message>
	</context>
	<context>
		<name>lot_management</name>
		<message>
			<source>title</source>
			<translation>Управління Лотом</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити лот</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Видалити лот</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Відкрити Лот</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>Відкрити лот</translation>
		</message>
		<message>
			<source>chk_show_nulls</source>
			<translation>Показати null значення</translation>
		</message>
		<message>
			<source>tooltip_chk_show_nulls</source>
			<translation>Показати порожні значення</translation>
		</message>
		<message>
			<source>dlg_lot_management</source>
			<translation>Управління Лотом</translation>
		</message>
		<message>
			<source>tooltip_dlg_lot_management</source>
			<translation>dlg_lot_management</translation>
		</message>
		<message>
			<source>lbl_column_filter</source>
			<translation>Фільтр стовпця дат:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter</source>
			<translation>Фільтр стовпця даних:</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Від:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>Від:</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>До:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>Кому:</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Ім&apos;я:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Стан:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Стан:</translation>
		</message>
	</context>
	<context>
		<name>mapzone_config</name>
		<message>
			<source>title</source>
			<translation>Зона Карти Налаштування</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_forceClosed</source>
			<translation>ДОДАТИ</translation>
		</message>
		<message>
			<source>tooltip_btn_add_forceClosed</source>
			<translation>btn_add_forceClosed</translation>
		</message>
		<message>
			<source>btn_add_ignore</source>
			<translation>ДОДАТИ</translation>
		</message>
		<message>
			<source>tooltip_btn_add_ignore</source>
			<translation>btn_add_ignore</translation>
		</message>
		<message>
			<source>btn_add_nodeParent</source>
			<translation>ДОДАТИ</translation>
		</message>
		<message>
			<source>tooltip_btn_add_nodeParent</source>
			<translation>btn_add_nodeParent</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_clear_preview</source>
			<translation>Очистити Попередній Перегляд</translation>
		</message>
		<message>
			<source>tooltip_btn_clear_preview</source>
			<translation>btn_clear_preview</translation>
		</message>
		<message>
			<source>btn_remove_forceClosed</source>
			<translation>ВИДАЛИТИ</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_forceClosed</source>
			<translation>btn_remove_forceClosed</translation>
		</message>
		<message>
			<source>btn_remove_ignore</source>
			<translation>ВИДАЛИТИ</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_ignore</source>
			<translation>btn_remove_ignore</translation>
		</message>
		<message>
			<source>btn_remove_nodeParent</source>
			<translation>ВИДАЛИТИ</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_nodeParent</source>
			<translation>btn_remove_nodeParent</translation>
		</message>
		<message>
			<source>dlg_mapzone_config</source>
			<translation>Зона Карти Налаштування</translation>
		</message>
		<message>
			<source>tooltip_dlg_mapzone_config</source>
			<translation>dlg_mapzone_config</translation>
		</message>
		<message>
			<source>lbl_forceClosed</source>
			<translation>примусовоЗакрито:</translation>
		</message>
		<message>
			<source>tooltip_lbl_forceClosed</source>
			<translation>lbl_forceClosed</translation>
		</message>
		<message>
			<source>lbl_ignore</source>
			<translation>ігнорувати</translation>
		</message>
		<message>
			<source>tooltip_lbl_ignore</source>
			<translation>lbl_ignore</translation>
		</message>
		<message>
			<source>lbl_nodeParent</source>
			<translation>вузолБатько:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodeParent</source>
			<translation>lbl_nodeParent</translation>
		</message>
		<message>
			<source>lbl_preview</source>
			<translation>Попередній Перегляд:</translation>
		</message>
		<message>
			<source>tooltip_lbl_preview</source>
			<translation>lbl_preview</translation>
		</message>
		<message>
			<source>lbl_toArc</source>
			<translation>доДуги:</translation>
		</message>
		<message>
			<source>tooltip_lbl_toArc</source>
			<translation>lbl_toArc</translation>
		</message>
	</context>
	<context>
		<name>mapzone_manager</name>
		<message>
			<source>title</source>
			<translation>Менеджер зон карти</translation>
		</message>
		<message>
			<source>dlg_mapzone_manager</source>
			<translation>Менеджер зон карти</translation>
		</message>
		<message>
			<source>tooltip_dlg_mapzone_manager</source>
			<translation>dlg_mapzone_manager</translation>
		</message>
	</context>
	<context>
		<name>massive_composer</name>
		<message>
			<source>title</source>
			<translation>Друкувати Сторінки Компоновника Автоматично</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>dlg_massive_composer</source>
			<translation>Друкувати Сторінки Компоновника Автоматично</translation>
		</message>
		<message>
			<source>tooltip_dlg_massive_composer</source>
			<translation>dlg_massive_composer</translation>
		</message>
		<message>
			<source>grb_comp</source>
			<translation>Список Компоновників</translation>
		</message>
		<message>
			<source>tooltip_grb_comp</source>
			<translation>grb_comp</translation>
		</message>
		<message>
			<source>lbl_composers</source>
			<translation>Вибрати Компоновник:</translation>
		</message>
		<message>
			<source>tooltip_lbl_composers</source>
			<translation>lbl_composers</translation>
		</message>
		<message>
			<source>lbl_folder</source>
			<translation>Вибрати Папку:</translation>
		</message>
		<message>
			<source>tooltip_lbl_folder</source>
			<translation>lbl_folder</translation>
		</message>
		<message>
			<source>lbl_prefix</source>
			<translation>Префікс Файлу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prefix</source>
			<translation>lbl_prefix</translation>
		</message>
		<message>
			<source>lbl_single</source>
			<translation>Один Файл:</translation>
		</message>
		<message>
			<source>tooltip_lbl_single</source>
			<translation>lbl_single</translation>
		</message>
		<message>
			<source>lbl_sleep</source>
			<translation>Час Затримки:</translation>
		</message>
		<message>
			<source>tooltip_lbl_sleep</source>
			<translation>lbl_sleep</translation>
		</message>
	</context>
	<context>
		<name>mincut</name>
		<message>
			<source>title</source>
			<translation>Мінімальний розріз</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Скасувати завдання</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_end</source>
			<translation>Кінець</translation>
		</message>
		<message>
			<source>tooltip_btn_end</source>
			<translation>btn_end</translation>
		</message>
		<message>
			<source>btn_start</source>
			<translation>Почати</translation>
		</message>
		<message>
			<source>tooltip_btn_start</source>
			<translation>btn_start</translation>
		</message>
		<message>
			<source>cbx_date_end</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end</source>
			<translation>cbx_date_end</translation>
		</message>
		<message>
			<source>cbx_date_end_predict</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end_predict</source>
			<translation>cbx_date_end_predict</translation>
		</message>
		<message>
			<source>cbx_date_start</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start</source>
			<translation>cbx_date_start</translation>
		</message>
		<message>
			<source>cbx_date_start_predict</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start_predict</source>
			<translation>cbx_date_start_predict</translation>
		</message>
		<message>
			<source>cbx_recieved_day</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_cbx_recieved_day</source>
			<translation>cbx_recieved_day</translation>
		</message>
		<message>
			<source>chk_use_planified</source>
			<translation>Використовувати Заплановану Мережу</translation>
		</message>
		<message>
			<source>tooltip_chk_use_planified</source>
			<translation>chk_use_planified</translation>
		</message>
		<message>
			<source>dlg_mincut</source>
			<translation>Мінімальний розріз</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut</source>
			<translation>dlg_mincut</translation>
		</message>
		<message>
			<source>grb_adress</source>
			<translation>Adress</translation>
		</message>
		<message>
			<source>tooltip_grb_adress</source>
			<translation>grb_adress</translation>
		</message>
		<message>
			<source>grb_exec_realdates</source>
			<translation>Реальні дати</translation>
		</message>
		<message>
			<source>tooltip_grb_exec_realdates</source>
			<translation>grb_exec_realdates</translation>
		</message>
		<message>
			<source>grb_plan_details</source>
			<translation>Деталі</translation>
		</message>
		<message>
			<source>tooltip_grb_plan_details</source>
			<translation>grb_plan_details</translation>
		</message>
		<message>
			<source>grb_plan_forecasted_dates</source>
			<translation>Прогнозовані Дати</translation>
		</message>
		<message>
			<source>tooltip_grb_plan_forecasted_dates</source>
			<translation>grb_plan_forecasted_dates</translation>
		</message>
		<message>
			<source>lbl_assigned_to</source>
			<translation>Призначено до:</translation>
		</message>
		<message>
			<source>tooltip_lbl_assigned_to</source>
			<translation>lbl_assigned_to</translation>
		</message>
		<message>
			<source>lbl_cause</source>
			<translation>Причина:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cause</source>
			<translation>lbl_cause</translation>
		</message>
		<message>
			<source>lbl_chlorine</source>
			<translation>Хлор:</translation>
		</message>
		<message>
			<source>tooltip_lbl_chlorine</source>
			<translation>lbl_chlorine</translation>
		</message>
		<message>
			<source>lbl_depth</source>
			<translation>Глибина:</translation>
		</message>
		<message>
			<source>tooltip_lbl_depth</source>
			<translation>lbl_depth</translation>
		</message>
		<message>
			<source>lbl_descript_pd</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_pd</source>
			<translation>lbl_descript_pd</translation>
		</message>
		<message>
			<source>lbl_descript_rd</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_rd</source>
			<translation>lbl_descript_rd</translation>
		</message>
		<message>
			<source>lbl_dist_from_plot</source>
			<translation>Відстань від ділянки:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dist_from_plot</source>
			<translation>lbl_dist_from_plot</translation>
		</message>
		<message>
			<source>lbl_end</source>
			<translation>До:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end</source>
			<translation>lbl_end</translation>
		</message>
		<message>
			<source>lbl_equipment_code</source>
			<translation>Обладнання для вимірювання хлору:</translation>
		</message>
		<message>
			<source>tooltip_lbl_equipment_code</source>
			<translation>lbl_equipment_code</translation>
		</message>
		<message>
			<source>lbl_exec_appropriate</source>
			<translation>Відповідний:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_appropriate</source>
			<translation>Якщо true, фактичне розташування відповідає запланованій інформації mincut</translation>
		</message>
		<message>
			<source>lbl_exec_enddate</source>
			<translation>Кінцева дата:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_enddate</source>
			<translation>lbl_exec_enddate</translation>
		</message>
		<message>
			<source>lbl_exec_startdate</source>
			<translation>Дата Початку:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_startdate</source>
			<translation>ID Візиту</translation>
		</message>
		<message>
			<source>lbl_exec_user</source>
			<translation>Користувач виконання:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_user</source>
			<translation>lbl_exec_user</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Ідентифікатор:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_municiplity</source>
			<translation>Municipality</translation>
		</message>
		<message>
			<source>tooltip_lbl_municiplity</source>
			<translation>lbl_municiplity</translation>
		</message>
		<message>
			<source>lbl_postnumber</source>
			<translation>Number</translation>
		</message>
		<message>
			<source>tooltip_lbl_postnumber</source>
			<translation>lbl_postnumber</translation>
		</message>
		<message>
			<source>lbl_reagent_lot</source>
			<translation>Партія реагенту хлору:</translation>
		</message>
		<message>
			<source>tooltip_lbl_reagent_lot</source>
			<translation>lbl_reagent_lot</translation>
		</message>
		<message>
			<source>lbl_received_date</source>
			<translation>Дата отримання:</translation>
		</message>
		<message>
			<source>tooltip_lbl_received_date</source>
			<translation>lbl_received_date</translation>
		</message>
		<message>
			<source>lbl_start</source>
			<translation>Від:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start</source>
			<translation>lbl_start</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Стан:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
		<message>
			<source>lbl_street</source>
			<translation>Street</translation>
		</message>
		<message>
			<source>tooltip_lbl_street</source>
			<translation>lbl_street</translation>
		</message>
		<message>
			<source>lbl_turbidity</source>
			<translation>Мутність:</translation>
		</message>
		<message>
			<source>tooltip_lbl_turbidity</source>
			<translation>lbl_turbidity</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Тип:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
		<message>
			<source>lbl_work_order</source>
			<translation>Робоче замовлення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_order</source>
			<translation>lbl_work_order</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Виконати</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>План</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_hydro</source>
			<translation>Гідро</translation>
		</message>
		<message>
			<source>tooltip_tab_hydro</source>
			<translation>tab_hydro</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Журнал</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>панельІнструментів</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>mincut_composer</name>
		<message>
			<source>title</source>
			<translation>Mincut композитор</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Відкрити</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_mincut_composer</source>
			<translation>Mincut композитор</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_composer</source>
			<translation>dlg_mincut_composer</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Mincut компоновник</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_rotation</source>
			<translation>Обертання:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rotation</source>
			<translation>lbl_rotation</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Шаблон:</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Заголовок:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
	</context>
	<context>
		<name>mincut_connec</name>
		<message>
			<source>title</source>
			<translation>Mincut підключення</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>dlg_mincut_connec</source>
			<translation>Mincut підключення</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_connec</source>
			<translation>dlg_mincut_connec</translation>
		</message>
		<message>
			<source>lbl_search</source>
			<translation>Пошук за кодом клієнта:</translation>
		</message>
		<message>
			<source>tooltip_lbl_search</source>
			<translation>lbl_search</translation>
		</message>
	</context>
	<context>
		<name>mincut_end</name>
		<message>
			<source>title</source>
			<translation>Mincut кінець</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_set_real_location</source>
			<translation>Встановити реальне розташування</translation>
		</message>
		<message>
			<source>tooltip_btn_set_real_location</source>
			<translation>btn_set_real_location</translation>
		</message>
		<message>
			<source>cbx_date_end_fin</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end_fin</source>
			<translation>cbx_date_end_fin</translation>
		</message>
		<message>
			<source>cbx_date_start_fin</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start_fin</source>
			<translation>cbx_date_start_fin</translation>
		</message>
		<message>
			<source>cbx_hours_start_fin</source>
			<translation>H:mm:ss</translation>
		</message>
		<message>
			<source>tooltip_cbx_hours_start_fin</source>
			<translation>cbx_hours_start_fin</translation>
		</message>
		<message>
			<source>dlg_mincut_end</source>
			<translation>Mincut кінець</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_end</source>
			<translation>dlg_mincut_end</translation>
		</message>
		<message>
			<source>grb_adress</source>
			<translation>Adress</translation>
		</message>
		<message>
			<source>tooltip_grb_adress</source>
			<translation>grb_adress</translation>
		</message>
		<message>
			<source>grb_close_mincut</source>
			<translation>Закрити mincut</translation>
		</message>
		<message>
			<source>tooltip_grb_close_mincut</source>
			<translation>grb_close_mincut</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Дати</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>lbl_end_date</source>
			<translation>Кому:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_date</source>
			<translation>lbl_end_date</translation>
		</message>
		<message>
			<source>lbl_end_hour</source>
			<translation>Кінцева година:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_hour</source>
			<translation>lbl_end_hour</translation>
		</message>
		<message>
			<source>lbl_executed</source>
			<translation>Виконав:</translation>
		</message>
		<message>
			<source>tooltip_lbl_executed</source>
			<translation>lbl_executed</translation>
		</message>
		<message>
			<source>lbl_mincut</source>
			<translation>Mincut:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mincut</source>
			<translation>lbl_mincut</translation>
		</message>
		<message>
			<source>lbl_msg</source>
			<translation>Результатів не знайдено</translation>
		</message>
		<message>
			<source>tooltip_lbl_msg</source>
			<translation>lbl_msg</translation>
		</message>
		<message>
			<source>lbl_municiplity</source>
			<translation>Municipality</translation>
		</message>
		<message>
			<source>tooltip_lbl_municiplity</source>
			<translation>lbl_municiplity</translation>
		</message>
		<message>
			<source>lbl_postnumber</source>
			<translation>Number</translation>
		</message>
		<message>
			<source>tooltip_lbl_postnumber</source>
			<translation>lbl_postnumber</translation>
		</message>
		<message>
			<source>lbl_start_date</source>
			<translation>Від:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_date</source>
			<translation>lbl_start_date</translation>
		</message>
		<message>
			<source>lbl_start_hour</source>
			<translation>Час початку:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_hour</source>
			<translation>lbl_start_hour</translation>
		</message>
		<message>
			<source>lbl_street</source>
			<translation>Вулиця:</translation>
		</message>
		<message>
			<source>tooltip_lbl_street</source>
			<translation>lbl_street</translation>
		</message>
		<message>
			<source>lbl_work_order</source>
			<translation>Замовлення на роботу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_order</source>
			<translation>lbl_work_order</translation>
		</message>
	</context>
	<context>
		<name>mincut_hydrometer</name>
		<message>
			<source>title</source>
			<translation>Mincut водомір</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>dlg_mincut_hydrometer</source>
			<translation>Mincut водомір</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_hydrometer</source>
			<translation>dlg_mincut_hydrometer</translation>
		</message>
		<message>
			<source>lbl_ccc</source>
			<translation>Підключення код клієнта:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ccc</source>
			<translation>lbl_ccc</translation>
		</message>
		<message>
			<source>lbl_hcc</source>
			<translation>Водомір код клієнта:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hcc</source>
			<translation>lbl_hcc</translation>
		</message>
	</context>
	<context>
		<name>mincut_manager</name>
		<message>
			<source>title</source>
			<translation>Mincut Керування</translation>
		</message>
		<message>
			<source>btn_selector_mincut</source>
			<translation>btn_selector_mincut</translation>
		</message>
		<message>
			<source>tooltip_btn_selector_mincut</source>
			<translation>btn_selector_mincut</translation>
		</message>
		<message>
			<source>dlg_mincut_manager</source>
			<translation>Mincut Керування</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_manager</source>
			<translation>dlg_mincut_manager</translation>
		</message>
	</context>
	<context>
		<name>netscenario</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_config</source>
			<translation>Конфіг</translation>
		</message>
		<message>
			<source>tooltip_btn_config</source>
			<translation>btn_config</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Переключити Активність</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>btn_toggle_closed</source>
			<translation>Перемкнути Закрито</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_closed</source>
			<translation>btn_toggle_closed</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>dlg_netscenario</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_netscenario</source>
			<translation>dlg_netscenario</translation>
		</message>
		<message>
			<source>lbl_mapzone_id</source>
			<translation>Зона карти id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mapzone_id</source>
			<translation>lbl_mapzone_id</translation>
		</message>
	</context>
	<context>
		<name>netscenario_manager</name>
		<message>
			<source>title</source>
			<translation>Netscenario менеджер</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Дублювати</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>Дублювати</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Перемкнути активний</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Перемкнути активний</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>btn_update_netscenario</source>
			<translation>Поточний сценарій мережі</translation>
		</message>
		<message>
			<source>tooltip_btn_update_netscenario</source>
			<translation>Поточний сценарій мережі</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Показати неактивні</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Показати неактивні</translation>
		</message>
		<message>
			<source>dlg_netscenario_manager</source>
			<translation>Netscenario менеджер</translation>
		</message>
		<message>
			<source>tooltip_dlg_netscenario_manager</source>
			<translation>dlg_netscenario_manager</translation>
		</message>
		<message>
			<source>lbl_netscenario_name</source>
			<translation>Фільтрувати за: Netscenario name</translation>
		</message>
		<message>
			<source>tooltip_lbl_netscenario_name</source>
			<translation>Фільтрувати за: Netscenario name</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_controls</name>
		<message>
			<source>title</source>
			<translation>Редактор Простих Керувань</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>ОК</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Активний</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_controls</source>
			<translation>Редактор Простих Керувань</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_controls</source>
			<translation>dlg_nonvisual_controls</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observ</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_sector_id</source>
			<translation>Сектор ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_sector_id</source>
			<translation>lbl_sector_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_curve</name>
		<message>
			<source>title</source>
			<translation>Редактор кривих</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>ОК</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_curve</source>
			<translation>Редактор кривих</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_curve</source>
			<translation>dlg_nonvisual_curve</translation>
		</message>
		<message>
			<source>lbl_curve_id</source>
			<translation>Ідентифікатор кривої</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_id</source>
			<translation>lbl_curve_id</translation>
		</message>
		<message>
			<source>lbl_curve_type</source>
			<translation>Тип кривої</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_type</source>
			<translation>lbl_curve_type</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Опис</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>Ідентифікатор експлуатації</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>tbl_curve_value</source>
			<translation>ТАК</translation>
		</message>
		<message>
			<source>tooltip_tbl_curve_value</source>
			<translation>tbl_curve_value</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_lids</name>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_help</source>
			<translation>Довідка</translation>
		</message>
		<message>
			<source>tooltip_btn_help</source>
			<translation>btn_help</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>Dialog</source>
			<translation>LIDS</translation>
		</message>
		<message>
			<source>tooltip_Dialog</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>drain</source>
			<translation>Дренаж</translation>
		</message>
		<message>
			<source>tooltip_drain</source>
			<translation>drain</translation>
		</message>
		<message>
			<source>drainmat</source>
			<translation>Мат Для Дренажу</translation>
		</message>
		<message>
			<source>tooltip_drainmat</source>
			<translation>drainmat</translation>
		</message>
		<message>
			<source>label_source_img</source>
			<translation>Джерело: SWMM 5.1</translation>
		</message>
		<message>
			<source>tooltip_label_source_img</source>
			<translation>label_source_img</translation>
		</message>
		<message>
			<source>lbl_berm_height</source>
			<translation>Висота берми (in. or mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_berm_height</source>
			<translation>lbl_berm_height</translation>
		</message>
		<message>
			<source>lbl_clogging_factor_pavement</source>
			<translation>Фактор Забивання</translation>
		</message>
		<message>
			<source>tooltip_lbl_clogging_factor_pavement</source>
			<translation>lbl_clogging_factor_pavement</translation>
		</message>
		<message>
			<source>lbl_clogging_factor_storage</source>
			<translation>Коефіцієнт засмічення</translation>
		</message>
		<message>
			<source>tooltip_lbl_clogging_factor_storage</source>
			<translation>lbl_clogging_factor_storage</translation>
		</message>
		<message>
			<source>lbl_closed_level</source>
			<translation>Закритий Рівень (дюйми або мм)</translation>
		</message>
		<message>
			<source>tooltip_lbl_closed_level</source>
			<translation>lbl_closed_level</translation>
		</message>
		<message>
			<source>lbl_conducticity_slope</source>
			<translation>Нахил провідності</translation>
		</message>
		<message>
			<source>tooltip_lbl_conducticity_slope</source>
			<translation>lbl_conducticity_slope</translation>
		</message>
		<message>
			<source>lbl_conductivity</source>
			<translation>Провідність    (in/hr or mm/hr)</translation>
		</message>
		<message>
			<source>tooltip_lbl_conductivity</source>
			<translation>lbl_conductivity</translation>
		</message>
		<message>
			<source>lbl_control_curve</source>
			<translation>Крива керування</translation>
		</message>
		<message>
			<source>tooltip_lbl_control_curve</source>
			<translation>lbl_control_curve</translation>
		</message>
		<message>
			<source>lbl_control_name</source>
			<translation>Назва контролю:</translation>
		</message>
		<message>
			<source>tooltip_lbl_control_name</source>
			<translation>lbl_control_name</translation>
		</message>
		<message>
			<source>lbl_drain_delay</source>
			<translation>Затримка Дренажу (год)</translation>
		</message>
		<message>
			<source>tooltip_lbl_drain_delay</source>
			<translation>lbl_drain_delay</translation>
		</message>
		<message>
			<source>lbl_field_capacity</source>
			<translation>Полева Вологоємність (об&apos;ємна частка)</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_capacity</source>
			<translation>lbl_field_capacity</translation>
		</message>
		<message>
			<source>lbl_flow_capacity</source>
			<translation>Пропускна Здатність Потоку (дюйм/год або мм/год)</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_capacity</source>
			<translation>lbl_flow_capacity</translation>
		</message>
		<message>
			<source>lbl__flow_coefficient</source>
			<translation>Коефіцієнт Потоку*</translation>
		</message>
		<message>
			<source>tooltip_lbl__flow_coefficient</source>
			<translation>lbl__flow_coefficient</translation>
		</message>
		<message>
			<source>lbl_flow_description</source>
			<translation>*Потік вимірюється в in/hr або mm/hr; використовуйте 0, якщо немає дренажу.</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_description</source>
			<translation>lbl_flow_description</translation>
		</message>
		<message>
			<source>lbl_flow_exponent</source>
			<translation>Показник Потоку</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_exponent</source>
			<translation>lbl_flow_exponent</translation>
		</message>
		<message>
			<source>lbl_imprevious_surface</source>
			<translation>Доля Непроникної Поверхні</translation>
		</message>
		<message>
			<source>tooltip_lbl_imprevious_surface</source>
			<translation>lbl_imprevious_surface</translation>
		</message>
		<message>
			<source>lbl_lid_type</source>
			<translation>Тип LID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_lid_type</source>
			<translation>lbl_lid_type</translation>
		</message>
		<message>
			<source>lbl_offset</source>
			<translation>Зсув (in або mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_offset</source>
			<translation>lbl_offset</translation>
		</message>
		<message>
			<source>lbl_open_level</source>
			<translation>Рівень відкриття (in або mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_open_level</source>
			<translation>lbl_open_level</translation>
		</message>
		<message>
			<source>lbl__permeability</source>
			<translation>Проникність    (in/hr or mm/hr)</translation>
		</message>
		<message>
			<source>tooltip_lbl__permeability</source>
			<translation>lbl__permeability</translation>
		</message>
		<message>
			<source>lbl_porosity</source>
			<translation>Пористість (об&apos;ємна частка)</translation>
		</message>
		<message>
			<source>tooltip_lbl_porosity</source>
			<translation>lbl_porosity</translation>
		</message>
		<message>
			<source>lbl_regeneration_fraction</source>
			<translation>Фракція Регенерації</translation>
		</message>
		<message>
			<source>tooltip_lbl_regeneration_fraction</source>
			<translation>lbl_regeneration_fraction</translation>
		</message>
		<message>
			<source>lbl_regeneration_interval</source>
			<translation>Інтервал Регенерації (дні)</translation>
		</message>
		<message>
			<source>tooltip_lbl_regeneration_interval</source>
			<translation>lbl_regeneration_interval</translation>
		</message>
		<message>
			<source>lbl_roughness</source>
			<translation>Шорсткість (Mannings n)</translation>
		</message>
		<message>
			<source>tooltip_lbl_roughness</source>
			<translation>lbl_roughness</translation>
		</message>
		<message>
			<source>lbl_seepage_rate</source>
			<translation>Швидкість просочування (in/hr або mm/hr)</translation>
		</message>
		<message>
			<source>tooltip_lbl_seepage_rate</source>
			<translation>lbl_seepage_rate</translation>
		</message>
		<message>
			<source>lbl_suction_head</source>
			<translation>Всмоктувальний напір (in. or mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_suction_head</source>
			<translation>lbl_suction_head</translation>
		</message>
		<message>
			<source>lbl_surface_roughness</source>
			<translation>Шорсткість Поверхні (Mannings n)</translation>
		</message>
		<message>
			<source>tooltip_lbl_surface_roughness</source>
			<translation>lbl_surface_roughness</translation>
		</message>
		<message>
			<source>lbl_surface_slope</source>
			<translation>Нахил Поверхні (відсотки)</translation>
		</message>
		<message>
			<source>tooltip_lbl_surface_slope</source>
			<translation>lbl_surface_slope</translation>
		</message>
		<message>
			<source>lbl_swale_side_slope</source>
			<translation>Бічний Нахил Канави (run / rise)</translation>
		</message>
		<message>
			<source>tooltip_lbl_swale_side_slope</source>
			<translation>lbl_swale_side_slope</translation>
		</message>
		<message>
			<source>lbl_thickness</source>
			<translation>Товщина (in. or mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness</source>
			<translation>lbl_thickness</translation>
		</message>
		<message>
			<source>lbl_thickness_drainage</source>
			<translation>Товщина (дюйми або мм)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness_drainage</source>
			<translation>lbl_thickness_drainage</translation>
		</message>
		<message>
			<source>lbl_thickness_storage</source>
			<translation>Товщина (дюйм. або мм)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness_storage</source>
			<translation>lbl_thickness_storage</translation>
		</message>
		<message>
			<source>lbl_thinkness_pavement</source>
			<translation>Товщина (in. або mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thinkness_pavement</source>
			<translation>lbl_thinkness_pavement</translation>
		</message>
		<message>
			<source>lbl_vegetation_volume</source>
			<translation>Фракція Об&apos;єму Рослинності</translation>
		</message>
		<message>
			<source>tooltip_lbl_vegetation_volume</source>
			<translation>lbl_vegetation_volume</translation>
		</message>
		<message>
			<source>lbl_void_fraction</source>
			<translation>Доля Пустот</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_fraction</source>
			<translation>lbl_void_fraction</translation>
		</message>
		<message>
			<source>lbl_void_ratio_pavement</source>
			<translation>Коефіцієнт Порожнинності (Порожнини / Тверді)</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_ratio_pavement</source>
			<translation>lbl_void_ratio_pavement</translation>
		</message>
		<message>
			<source>lbl_void_ratio_storage</source>
			<translation>Коефіцієнт пустот (Порожнини / Тверді)</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_ratio_storage</source>
			<translation>lbl_void_ratio_storage</translation>
		</message>
		<message>
			<source>lbl_wilting_point</source>
			<translation>Точка в’янення (об&apos;ємна частка)</translation>
		</message>
		<message>
			<source>tooltip_lbl_wilting_point</source>
			<translation>lbl_wilting_point</translation>
		</message>
		<message>
			<source>pavement</source>
			<translation>Покриття</translation>
		</message>
		<message>
			<source>tooltip_pavement</source>
			<translation>pavement</translation>
		</message>
		<message>
			<source>rooftop</source>
			<translation>Даховий Водостік</translation>
		</message>
		<message>
			<source>tooltip_rooftop</source>
			<translation>rooftop</translation>
		</message>
		<message>
			<source>soil</source>
			<translation>Ґрунт</translation>
		</message>
		<message>
			<source>tooltip_soil</source>
			<translation>soil</translation>
		</message>
		<message>
			<source>storage</source>
			<translation>Зберігання</translation>
		</message>
		<message>
			<source>tooltip_storage</source>
			<translation>storage</translation>
		</message>
		<message>
			<source>surface</source>
			<translation>Поверхня</translation>
		</message>
		<message>
			<source>tooltip_surface</source>
			<translation>surface</translation>
		</message>
		<message>
			<source>txt_1_berm_height</source>
			<translation>0.0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_berm_height</source>
			<translation>txt_1_berm_height</translation>
		</message>
		<message>
			<source>txt_1_flow_coefficient</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_flow_coefficient</source>
			<translation>txt_1_flow_coefficient</translation>
		</message>
		<message>
			<source>txt_1_thickness</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness</source>
			<translation>txt_1_thickness</translation>
		</message>
		<message>
			<source>txt_1_thickness_drainage</source>
			<translation>3</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_drainage</source>
			<translation>txt_1_thickness_drainage</translation>
		</message>
		<message>
			<source>txt_1_thickness_pavement</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_pavement</source>
			<translation>txt_1_thickness_pavement</translation>
		</message>
		<message>
			<source>txt_1_thickness_storage</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_storage</source>
			<translation>txt_1_thickness_storage</translation>
		</message>
		<message>
			<source>txt_2_flow_exponent</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_flow_exponent</source>
			<translation>txt_2_flow_exponent</translation>
		</message>
		<message>
			<source>txt_2_porosity</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_porosity</source>
			<translation>txt_2_porosity</translation>
		</message>
		<message>
			<source>txt_2_vegetation_volume</source>
			<translation>0.0</translation>
		</message>
		<message>
			<source>tooltip_txt_2_vegetation_volume</source>
			<translation>txt_2_vegetation_volume</translation>
		</message>
		<message>
			<source>txt_2_void_fraction</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_fraction</source>
			<translation>txt_2_void_fraction</translation>
		</message>
		<message>
			<source>txt_2_void_ratio_pavement</source>
			<translation>0.15</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_ratio_pavement</source>
			<translation>txt_2_void_ratio_pavement</translation>
		</message>
		<message>
			<source>txt_2_void_ratio_storage</source>
			<translation>0.75</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_ratio_storage</source>
			<translation>txt_2_void_ratio_storage</translation>
		</message>
		<message>
			<source>txt_3_field_capacity</source>
			<translation>0.2</translation>
		</message>
		<message>
			<source>tooltip_txt_3_field_capacity</source>
			<translation>txt_3_field_capacity</translation>
		</message>
		<message>
			<source>txt_3_imprevious_surface</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_3_imprevious_surface</source>
			<translation>txt_3_imprevious_surface</translation>
		</message>
		<message>
			<source>txt_3_offset</source>
			<translation>6</translation>
		</message>
		<message>
			<source>tooltip_txt_3_offset</source>
			<translation>txt_3_offset</translation>
		</message>
		<message>
			<source>txt_3_roughness</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_3_roughness</source>
			<translation>txt_3_roughness</translation>
		</message>
		<message>
			<source>txt_3_seepage_rate</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_3_seepage_rate</source>
			<translation>txt_3_seepage_rate</translation>
		</message>
		<message>
			<source>txt_3_surface_roughness</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_3_surface_roughness</source>
			<translation>txt_3_surface_roughness</translation>
		</message>
		<message>
			<source>txt_4_clogging_factor_storage</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_4_clogging_factor_storage</source>
			<translation>txt_4_clogging_factor_storage</translation>
		</message>
		<message>
			<source>txt_4_drain_delay</source>
			<translation>6</translation>
		</message>
		<message>
			<source>tooltip_txt_4_drain_delay</source>
			<translation>txt_4_drain_delay</translation>
		</message>
		<message>
			<source>txt_4_permeability</source>
			<translation>100</translation>
		</message>
		<message>
			<source>tooltip_txt_4_permeability</source>
			<translation>txt_4_permeability</translation>
		</message>
		<message>
			<source>txt_4_surface_slope</source>
			<translation>1.0</translation>
		</message>
		<message>
			<source>tooltip_txt_4_surface_slope</source>
			<translation>txt_4_surface_slope</translation>
		</message>
		<message>
			<source>txt_4_wilting_point</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_4_wilting_point</source>
			<translation>txt_4_wilting_point</translation>
		</message>
		<message>
			<source>txt_5_clogging_factor_pavement</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_5_clogging_factor_pavement</source>
			<translation>txt_5_clogging_factor_pavement</translation>
		</message>
		<message>
			<source>txt_5_conductivity</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_5_conductivity</source>
			<translation>txt_5_conductivity</translation>
		</message>
		<message>
			<source>txt_5_open_level</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_5_open_level</source>
			<translation>txt_5_open_level</translation>
		</message>
		<message>
			<source>txt_5_swale_side_slope</source>
			<translation>5</translation>
		</message>
		<message>
			<source>tooltip_txt_5_swale_side_slope</source>
			<translation>txt_5_swale_side_slope</translation>
		</message>
		<message>
			<source>txt_6_closed_level</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_closed_level</source>
			<translation>txt_6_closed_level</translation>
		</message>
		<message>
			<source>txt_6_conducticity_slope</source>
			<translation>10.0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_conducticity_slope</source>
			<translation>txt_6_conducticity_slope</translation>
		</message>
		<message>
			<source>txt_6_regeneration_interval</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_regeneration_interval</source>
			<translation>txt_6_regeneration_interval</translation>
		</message>
		<message>
			<source>txt_7_regeneration_fraction</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_7_regeneration_fraction</source>
			<translation>txt_7_regeneration_fraction</translation>
		</message>
		<message>
			<source>txt_7_suction_head</source>
			<translation>3.5</translation>
		</message>
		<message>
			<source>tooltip_txt_7_suction_head</source>
			<translation>txt_7_suction_head</translation>
		</message>
		<message>
			<source>txt_flow_capacity</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_flow_capacity</source>
			<translation>txt_flow_capacity</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_manager</name>
		<message>
			<source>title</source>
			<translation>Менеджер невізуальних об&apos;єктів</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Дублювати</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>Дублювати</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Shape у PNG</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>btn_print</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Переключити активність</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Показати Неактивні</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Показати Неактивні</translation>
		</message>
		<message>
			<source>dlg_nonvisual_manager</source>
			<translation>Менеджер невізуальних об&apos;єктів</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_manager</source>
			<translation>dlg_nonvisual_manager</translation>
		</message>
		<message>
			<source>lbl_curve_type</source>
			<translation>Тип кривої:</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_type</source>
			<translation>Тип кривої</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Фільтрувати За:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Тип Шаблону:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>Тип Шаблону</translation>
		</message>
		<message>
			<source>lbl_timser_type</source>
			<translation>Тип Часових Рядів:</translation>
		</message>
		<message>
			<source>tooltip_lbl_timser_type</source>
			<translation>Тип Часових Рядів</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_pattern_ud</name>
		<message>
			<source>title</source>
			<translation>Редактор шаблонів</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_pattern_ud</source>
			<translation>Редактор шаблонів</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_pattern_ud</source>
			<translation>dlg_nonvisual_pattern_ud</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>Експлуатація ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Спостереження</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_pattern_id</source>
			<translation>ID Шаблону</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_id</source>
			<translation>lbl_pattern_id</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Тип Шаблону</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>lbl_pattern_type</translation>
		</message>
		<message>
			<source>tbl_daily</source>
			<translation>НД</translation>
		</message>
		<message>
			<source>tooltip_tbl_daily</source>
			<translation>tbl_daily</translation>
		</message>
		<message>
			<source>tbl_hourly</source>
			<translation>11PM</translation>
		</message>
		<message>
			<source>tooltip_tbl_hourly</source>
			<translation>tbl_hourly</translation>
		</message>
		<message>
			<source>tbl_monthly</source>
			<translation>ГРУ</translation>
		</message>
		<message>
			<source>tooltip_tbl_monthly</source>
			<translation>tbl_monthly</translation>
		</message>
		<message>
			<source>tbl_weekend</source>
			<translation>11PM</translation>
		</message>
		<message>
			<source>tooltip_tbl_weekend</source>
			<translation>tbl_weekend</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_pattern_ws</name>
		<message>
			<source>title</source>
			<translation>Редактор Шаблонів</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_pattern_ws</source>
			<translation>Редактор Шаблонів</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_pattern_ws</source>
			<translation>dlg_nonvisual_pattern_ws</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Спостереження</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_pattern_id</source>
			<translation>Шаблон ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_id</source>
			<translation>lbl_pattern_id</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Експлуатація ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>lbl_pattern_type</translation>
		</message>
		<message>
			<source>tbl_pattern_value</source>
			<translation>18</translation>
		</message>
		<message>
			<source>tooltip_tbl_pattern_value</source>
			<translation>tbl_pattern_value</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_print</name>
		<message>
			<source>title</source>
			<translation>Друк Невізуального Об&apos;єкта</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>chk_cross_arccat</source>
			<translation>Перетин з arccat</translation>
		</message>
		<message>
			<source>tooltip_chk_cross_arccat</source>
			<translation>chk_cross_arccat</translation>
		</message>
		<message>
			<source>dlg_nonvisual_print</source>
			<translation>Друк Невізуального Об&apos;єкта</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_print</source>
			<translation>dlg_nonvisual_print</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_roughness</name>
		<message>
			<source>title</source>
			<translation>Редактор Контролів На Основі Правил</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Активний</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_roughness</source>
			<translation>Редактор Контролів На Основі Правил</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_roughness</source>
			<translation>dlg_nonvisual_roughness</translation>
		</message>
		<message>
			<source>label</source>
			<translation>ID Періоду</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Початковий вік</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Кінцевий вік</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Шорсткість</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Опис</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>lbl_matcat_id</source>
			<translation>Matcat ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_matcat_id</source>
			<translation>lbl_matcat_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_rules</name>
		<message>
			<source>title</source>
			<translation>Редактор Керування На Основі Правил</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Активний</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_rules</source>
			<translation>Редактор Керування На Основі Правил</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_rules</source>
			<translation>dlg_nonvisual_rules</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observ</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_sector_id</source>
			<translation>Сектор ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_sector_id</source>
			<translation>lbl_sector_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_timeseries</name>
		<message>
			<source>title</source>
			<translation>Редактор Часових Рядів</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>ОК</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_timeseries</source>
			<translation>Редактор Часових Рядів</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_timeseries</source>
			<translation>dlg_nonvisual_timeseries</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Часи Тип</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Опис</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Експлуатація ID</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Активний</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_addparam</source>
			<translation>Додатипараметр (json)</translation>
		</message>
		<message>
			<source>tooltip_lbl_addparam</source>
			<translation>lbl_addparam</translation>
		</message>
		<message>
			<source>lbl_curve_id</source>
			<translation>Часовий Ряд ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_id</source>
			<translation>lbl_curve_id</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Часовий Ряд Тип</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_fname</source>
			<translation>Файл ім&apos;я</translation>
		</message>
		<message>
			<source>tooltip_lbl_fname</source>
			<translation>lbl_fname</translation>
		</message>
		<message>
			<source>tbl_timeseries_value</source>
			<translation>Значення</translation>
		</message>
		<message>
			<source>tooltip_tbl_timeseries_value</source>
			<translation>tbl_timeseries_value</translation>
		</message>
	</context>
	<context>
		<name>print</name>
		<message>
			<source>title</source>
			<translation>ШвидкийДрук</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_preview</source>
			<translation>Попередній перегляд</translation>
		</message>
		<message>
			<source>tooltip_btn_preview</source>
			<translation>btn_preview</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Друк</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>btn_print</translation>
		</message>
		<message>
			<source>dlg_print</source>
			<translation>ШвидкийДрук</translation>
		</message>
		<message>
			<source>tooltip_dlg_print</source>
			<translation>dlg_print</translation>
		</message>
		<message>
			<source>grb_map_options</source>
			<translation>Параметри Карти:</translation>
		</message>
		<message>
			<source>tooltip_grb_map_options</source>
			<translation>grb_map_options</translation>
		</message>
		<message>
			<source>grb_option_values</source>
			<translation>Необов&apos;язкові значення:</translation>
		</message>
		<message>
			<source>tooltip_grb_option_values</source>
			<translation>grb_option_values</translation>
		</message>
	</context>
	<context>
		<name>priority</name>
		<message>
			<source>title</source>
			<translation>Розрахунок Пріоритету</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Запустити</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_again</source>
			<translation>Далі</translation>
		</message>
		<message>
			<source>tooltip_btn_again</source>
			<translation>btn_again</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_save2file</source>
			<translation>Зберегти результати у файл Excel...</translation>
		</message>
		<message>
			<source>tooltip_btn_save2file</source>
			<translation>btn_save2file</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>Вибрати елементи на полотні</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Select features on canvas</translation>
		</message>
		<message>
			<source>dlg_priority</source>
			<translation>Розрахунок Пріоритету</translation>
		</message>
		<message>
			<source>tooltip_dlg_priority</source>
			<translation>dlg_priority</translation>
		</message>
		<message>
			<source>grb_engine_1</source>
			<translation>grb_двигун_1</translation>
		</message>
		<message>
			<source>tooltip_grb_engine_1</source>
			<translation>grb_engine_1</translation>
		</message>
		<message>
			<source>grb_engine_2</source>
			<translation>grb_двигун_2</translation>
		</message>
		<message>
			<source>tooltip_grb_engine_2</source>
			<translation>grb_engine_2</translation>
		</message>
		<message>
			<source>grb_global</source>
			<translation>Параметри розрахунку</translation>
		</message>
		<message>
			<source>tooltip_grb_global</source>
			<translation>grb_global</translation>
		</message>
		<message>
			<source>grb_selection</source>
			<translation>Вибір елементів</translation>
		</message>
		<message>
			<source>tooltip_grb_selection</source>
			<translation>grb_selection</translation>
		</message>
		<message>
			<source>lbl_budget</source>
			<translation>Річний бюджет:</translation>
		</message>
		<message>
			<source>tooltip_lbl_budget</source>
			<translation>lbl_budget</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_dnom</source>
			<translation>Діаметр:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dnom</source>
			<translation>lbl_dnom</translation>
		</message>
		<message>
			<source>lbl_expl_selection</source>
			<translation>Експлуатація:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_selection</source>
			<translation>lbl_expl_selection</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Матеріал:</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>lbl_material</translation>
		</message>
		<message>
			<source>lbl_presszone</source>
			<translation>Пресзона:</translation>
		</message>
		<message>
			<source>tooltip_lbl_presszone</source>
			<translation>lbl_presszone</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Назва результату:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Статус:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_year</source>
			<translation>Рік горизонту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_year</source>
			<translation>lbl_year</translation>
		</message>
		<message>
			<source>tab_calc</source>
			<translation>Розрахунок</translation>
		</message>
		<message>
			<source>tooltip_tab_calc</source>
			<translation>tab_calc</translation>
		</message>
		<message>
			<source>tab_catalog</source>
			<translation>Каталог</translation>
		</message>
		<message>
			<source>tooltip_tab_catalog</source>
			<translation>tab_catalog</translation>
		</message>
		<message>
			<source>tab_engine</source>
			<translation>Двигун</translation>
		</message>
		<message>
			<source>tooltip_tab_engine</source>
			<translation>tab_engine</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Журнал інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_material</source>
			<translation>Матеріал</translation>
		</message>
		<message>
			<source>tooltip_tab_material</source>
			<translation>tab_material</translation>
		</message>
	</context>
	<context>
		<name>priority_manager</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_corporate</source>
			<translation>Встановити Корпоративний</translation>
		</message>
		<message>
			<source>tooltip_btn_corporate</source>
			<translation>btn_corporate</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Дублювати</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_edit</source>
			<translation>Редагувати</translation>
		</message>
		<message>
			<source>tooltip_btn_edit</source>
			<translation>btn_edit</translation>
		</message>
		<message>
			<source>btn_status</source>
			<translation>Змінити статус</translation>
		</message>
		<message>
			<source>tooltip_btn_status</source>
			<translation>btn_status</translation>
		</message>
		<message>
			<source>dlg_priority_manager</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_priority_manager</source>
			<translation>dlg_priority_manager</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Експлуатація:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Фільтрувати за: Ім&apos;я результату</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Інформація:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Статус:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Тип:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
	</context>
	<context>
		<name>profile</name>
		<message>
			<source>title</source>
			<translation>Побудувати Профіль</translation>
		</message>
		<message>
			<source>btn_clear_profile</source>
			<translation>Очистити профіль</translation>
		</message>
		<message>
			<source>tooltip_btn_clear_profile</source>
			<translation>btn_clear_profile</translation>
		</message>
		<message>
			<source>btn_delete_additional_point</source>
			<translation>btn_delete_additional_point</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_additional_point</source>
			<translation>btn_delete_additional_point</translation>
		</message>
		<message>
			<source>btn_draw_profile</source>
			<translation>Намалювати Профіль</translation>
		</message>
		<message>
			<source>tooltip_btn_draw_profile</source>
			<translation>btn_draw_profile</translation>
		</message>
		<message>
			<source>btn_load_profile</source>
			<translation>Профіль завантаження</translation>
		</message>
		<message>
			<source>tooltip_btn_load_profile</source>
			<translation>btn_load_profile</translation>
		</message>
		<message>
			<source>btn_save_profile</source>
			<translation>Зберегти профіль</translation>
		</message>
		<message>
			<source>tooltip_btn_save_profile</source>
			<translation>btn_save_profile</translation>
		</message>
		<message>
			<source>date</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_date</source>
			<translation>date</translation>
		</message>
		<message>
			<source>dlg_profile</source>
			<translation>Побудувати Профіль</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile</source>
			<translation>dlg_profile</translation>
		</message>
		<message>
			<source>grb_composer</source>
			<translation>Параметри</translation>
		</message>
		<message>
			<source>tooltip_grb_composer</source>
			<translation>grb_composer</translation>
		</message>
		<message>
			<source>grb_profile</source>
			<translation>Профіль</translation>
		</message>
		<message>
			<source>tooltip_grb_profile</source>
			<translation>grb_profile</translation>
		</message>
		<message>
			<source>lbl_date</source>
			<translation>Дата:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date</source>
			<translation>Date to be displayed</translation>
		</message>
		<message>
			<source>lbl_min_distance</source>
			<translation>Vвузол Мін Відстань:</translation>
		</message>
		<message>
			<source>tooltip_lbl_min_distance</source>
			<translation>Minimum distance between vnodes to be displayed</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Заголовок:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>Profile title to be displayed</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>інструментПанель</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>txt_profile_id</source>
			<translation>Необов&apos;язковий ідентифікатор профілю</translation>
		</message>
		<message>
			<source>tooltip_txt_profile_id</source>
			<translation>Optional profile ID</translation>
		</message>
	</context>
	<context>
		<name>profile_interpolation</name>
		<message>
			<source>title</source>
			<translation>Profile interpolation</translation>
		</message>
		<message>
			<source>dlg_profile_interpolation</source>
			<translation>Profile interpolation</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile_interpolation</source>
			<translation>dlg_profile_interpolation</translation>
		</message>
	</context>
	<context>
		<name>profile_list</name>
		<message>
			<source>title</source>
			<translation>Завантажити Профілі</translation>
		</message>
		<message>
			<source>btn_delete_profile</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_profile</source>
			<translation>btn_delete_profile</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Відкрити</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_profile_list</source>
			<translation>Завантажити Профілі</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile_list</source>
			<translation>dlg_profile_list</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Список Профілів</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
	</context>
	<context>
		<name>project_check</name>
		<message>
			<source>title</source>
			<translation>Перевірити проєкт</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>dlg_project_check</source>
			<translation>Перевірити проєкт</translation>
		</message>
		<message>
			<source>tooltip_dlg_project_check</source>
			<translation>dlg_project_check</translation>
		</message>
		<message>
			<source>tab_databaselog</source>
			<translation>Журнал бази даних</translation>
		</message>
		<message>
			<source>tooltip_tab_databaselog</source>
			<translation>tab_databaselog</translation>
		</message>
	</context>
	<context>
		<name>psector</name>
		<message>
			<source>title</source>
			<translation>План pсектор</translation>
		</message>
		<message>
			<source>btn_remove</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_remove</source>
			<translation>btn_remove</translation>
		</message>
		<message>
			<source>btn_reports</source>
			<translation>Згенерувати звіт</translation>
		</message>
		<message>
			<source>tooltip_btn_reports</source>
			<translation>btn_reports</translation>
		</message>
		<message>
			<source>btn_select</source>
			<translation>Додати</translation>
		</message>
		<message>
			<source>tooltip_btn_select</source>
			<translation>btn_select</translation>
		</message>
		<message>
			<source>btn_set_geom</source>
			<translation>Встановити геометрію</translation>
		</message>
		<message>
			<source>tooltip_btn_set_geom</source>
			<translation>btn_set_geom</translation>
		</message>
		<message>
			<source>dlg_psector</source>
			<translation>План pсектор</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector</source>
			<translation>dlg_psector</translation>
		</message>
		<message>
			<source>gexpenses_label</source>
			<translation>Загальні витрати</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label</source>
			<translation>gexpenses_label</translation>
		</message>
		<message>
			<source>gexpenses_label_10</source>
			<translation>Загалом дуг:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_10</source>
			<translation>gexpenses_label_10</translation>
		</message>
		<message>
			<source>gexpenses_label_3</source>
			<translation>Всього вузлів:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_3</source>
			<translation>gexpenses_label_3</translation>
		</message>
		<message>
			<source>gexpenses_label_4</source>
			<translation>Загальна сума інших цін:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_4</source>
			<translation>gexpenses_label_4</translation>
		</message>
		<message>
			<source>gexpenses_label_5</source>
			<translation>Всього:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_5</source>
			<translation>gexpenses_label_5</translation>
		</message>
		<message>
			<source>gexpenses_label_6</source>
			<translation>Всього:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_6</source>
			<translation>gexpenses_label_6</translation>
		</message>
		<message>
			<source>gexpenses_label_7</source>
			<translation>Всього:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_7</source>
			<translation>gexpenses_label_7</translation>
		</message>
		<message>
			<source>gexpenses_label_8</source>
			<translation>Всього:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_8</source>
			<translation>gexpenses_label_8</translation>
		</message>
		<message>
			<source>lbl_num_value</source>
			<translation>Числове значення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_num_value</source>
			<translation>lbl_num_value</translation>
		</message>
		<message>
			<source>lbl_text3</source>
			<translation>Текст 3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text3</source>
			<translation>lbl_text3</translation>
		</message>
		<message>
			<source>lbl_text4</source>
			<translation>Текст 4:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text4</source>
			<translation>lbl_text4</translation>
		</message>
		<message>
			<source>lbl_text5</source>
			<translation>Текст 5:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text5</source>
			<translation>lbl_text5</translation>
		</message>
		<message>
			<source>lbl_text6</source>
			<translation>Текст 6:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text6</source>
			<translation>lbl_text6</translation>
		</message>
		<message>
			<source>lbl_total</source>
			<translation>Всього :</translation>
		</message>
		<message>
			<source>tooltip_lbl_total</source>
			<translation>lbl_total</translation>
		</message>
		<message>
			<source>lbl_total_count</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_lbl_total_count</source>
			<translation>lbl_total_count</translation>
		</message>
		<message>
			<source>other_label</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label</source>
			<translation>other_label</translation>
		</message>
		<message>
			<source>other_label_2</source>
			<translation>Інші витрати</translation>
		</message>
		<message>
			<source>tooltip_other_label_2</source>
			<translation>other_label_2</translation>
		</message>
		<message>
			<source>other_label_3</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_3</source>
			<translation>other_label_3</translation>
		</message>
		<message>
			<source>other_label_4</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_4</source>
			<translation>other_label_4</translation>
		</message>
		<message>
			<source>tab_additional_info</source>
			<translation>Додаткова інформація</translation>
		</message>
		<message>
			<source>tooltip_tab_additional_info</source>
			<translation>tab_additional_info</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_budget</source>
			<translation>Бюджет</translation>
		</message>
		<message>
			<source>tooltip_tab_budget</source>
			<translation>tab_budget</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>З&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Документ</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>tab_document</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Загальне</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Імборнал</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_other_prices</source>
			<translation>Інші ціни</translation>
		</message>
		<message>
			<source>tooltip_tab_other_prices</source>
			<translation>tab_other_prices</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Відношення</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
		<message>
			<source>vat_label</source>
			<translation>ПДВ:</translation>
		</message>
		<message>
			<source>tooltip_vat_label</source>
			<translation>vat_label</translation>
		</message>
	</context>
	<context>
		<name>psector_duplicate</name>
		<message>
			<source>title</source>
			<translation>Дублювати psector</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_psector_duplicate</source>
			<translation>Дублювати psector</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_duplicate</source>
			<translation>dlg_psector_duplicate</translation>
		</message>
		<message>
			<source>lbl_duplicate_psector</source>
			<translation>Дублювати psector:</translation>
		</message>
		<message>
			<source>tooltip_lbl_duplicate_psector</source>
			<translation>lbl_duplicate_psector</translation>
		</message>
		<message>
			<source>lbl_new_psector</source>
			<translation>Нова назва psector:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_psector</source>
			<translation>lbl_new_psector</translation>
		</message>
		<message>
			<source>tab_duplicate_psector</source>
			<translation>Дублювати psector</translation>
		</message>
		<message>
			<source>tooltip_tab_duplicate_psector</source>
			<translation>tab_duplicate_psector</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Журнал інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>psector_manager</name>
		<message>
			<source>title</source>
			<translation>Pсектор</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Дублювати</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_merge</source>
			<translation>Об&apos;єднати</translation>
		</message>
		<message>
			<source>tooltip_btn_merge</source>
			<translation>Щоб об&apos;єднати різні псектори в один, спочатку потрібно виділити їх, використовуючи Ctrl, а потім натиснути цю кнопку</translation>
		</message>
		<message>
			<source>btn_restore</source>
			<translation>Відновити</translation>
		</message>
		<message>
			<source>tooltip_btn_restore</source>
			<translation>btn_restore</translation>
		</message>
		<message>
			<source>btn_show</source>
			<translation>Показати</translation>
		</message>
		<message>
			<source>tooltip_btn_show</source>
			<translation>btn_show</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Перемкнути активність</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>btn_update_psector</source>
			<translation>Перемкнути поточний</translation>
		</message>
		<message>
			<source>tooltip_btn_update_psector</source>
			<translation>btn_update_psector</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Показати неактивні</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Показати неактивні</translation>
		</message>
		<message>
			<source>chk_archived</source>
			<translation>Показати архівні записи</translation>
		</message>
		<message>
			<source>tooltip_chk_archived</source>
			<translation>chk_archived</translation>
		</message>
		<message>
			<source>chk_filter_canvas</source>
			<translation>Фільтр з Canvas</translation>
		</message>
		<message>
			<source>tooltip_chk_filter_canvas</source>
			<translation>Показувати лише psectors видимі на полотні</translation>
		</message>
		<message>
			<source>dlg_psector_manager</source>
			<translation>Pсектор</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_manager</source>
			<translation>dlg_psector_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Інфо:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_psector_name</source>
			<translation>Фільтрувати за: Назва Psector</translation>
		</message>
		<message>
			<source>tooltip_lbl_psector_name</source>
			<translation>lbl_psector_name</translation>
		</message>
	</context>
	<context>
		<name>psector_rapport</name>
		<message>
			<source>title</source>
			<translation>Звіт Psector</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>chk_composer</source>
			<translation>Створити PDF-Файл</translation>
		</message>
		<message>
			<source>tooltip_chk_composer</source>
			<translation>chk_composer</translation>
		</message>
		<message>
			<source>dlg_psector_rapport</source>
			<translation>Звіт Psector</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_rapport</source>
			<translation>dlg_psector_rapport</translation>
		</message>
		<message>
			<source>grb_rapport</source>
			<translation>Звіт</translation>
		</message>
		<message>
			<source>tooltip_grb_rapport</source>
			<translation>grb_rapport</translation>
		</message>
		<message>
			<source>lbl_detail_csv</source>
			<translation>Файл детальних цін .csv:</translation>
		</message>
		<message>
			<source>tooltip_lbl_detail_csv</source>
			<translation>lbl_detail_csv</translation>
		</message>
		<message>
			<source>lbl_prices_list</source>
			<translation>Файл цін .csv:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prices_list</source>
			<translation>lbl_prices_list</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Шаблон</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
	</context>
	<context>
		<name>psector_repair</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_repair</source>
			<translation>Відремонтувати</translation>
		</message>
		<message>
			<source>tooltip_btn_repair</source>
			<translation>btn_repair</translation>
		</message>
		<message>
			<source>dlg_psector_repair</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_repair</source>
			<translation>dlg_psector_repair</translation>
		</message>
	</context>
	<context>
		<name>replace_in_file</name>
		<message>
			<source>title</source>
			<translation>Замінити Текст У Файлі</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_replace_in_file</source>
			<translation>Замінити Текст У Файлі</translation>
		</message>
		<message>
			<source>tooltip_dlg_replace_in_file</source>
			<translation>dlg_replace_in_file</translation>
		</message>
		<message>
			<source>lbl_subtitle</source>
			<translation>Є об&apos;єкти з назвою довшою за 16 символів</translation>
		</message>
		<message>
			<source>tooltip_lbl_subtitle</source>
			<translation>lbl_subtitle</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Замінити Ці Імена На Нові:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
	</context>
	<context>
		<name>resources_management</name>
		<message>
			<source>btn_assign_team</source>
			<translation>Призначити Команду</translation>
		</message>
		<message>
			<source>tooltip_btn_assign_team</source>
			<translation>btn_assign_team</translation>
		</message>
		<message>
			<source>btn_campaign_save</source>
			<translation>Save</translation>
		</message>
		<message>
			<source>tooltip_btn_campaign_save</source>
			<translation>btn_campaign_save</translation>
		</message>
		<message>
			<source>btn_change_team</source>
			<translation>Change team</translation>
		</message>
		<message>
			<source>tooltip_btn_change_team</source>
			<translation>btn_change_team</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>btn_remove_team</source>
			<translation>Видалити Команду</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_team</source>
			<translation>btn_remove_team</translation>
		</message>
		<message>
			<source>btn_team_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_team_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>btn_team_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_team_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>btn_team_toggle_active</source>
			<translation>Перемкнути активність</translation>
		</message>
		<message>
			<source>tooltip_btn_team_toggle_active</source>
			<translation>btn_team_toggle_active</translation>
		</message>
		<message>
			<source>btn_team_update</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_btn_team_update</source>
			<translation>Змінити</translation>
		</message>
		<message>
			<source>btn_user_toggle_active</source>
			<translation>Перемкнути активність</translation>
		</message>
		<message>
			<source>tooltip_btn_user_toggle_active</source>
			<translation>btn_user_toggle_active</translation>
		</message>
		<message>
			<source>cmb_team</source>
			<translation>Вибрати команду</translation>
		</message>
		<message>
			<source>tooltip_cmb_team</source>
			<translation>cmb_team</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Фільтрувати за назвою:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Фільтрувати за назвою команди:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Фільтрувати за командою:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>lbl_campaign</source>
			<translation>Campaign:</translation>
		</message>
		<message>
			<source>tooltip_lbl_campaign</source>
			<translation>lbl_campaign</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>User:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
		<message>
			<source>resource_management</source>
			<translation>Управління Ресурсами</translation>
		</message>
		<message>
			<source>tooltip_resource_management</source>
			<translation>resource_management</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Campaign revision</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_organizations</source>
			<translation>Організації</translation>
		</message>
		<message>
			<source>tooltip_tab_organizations</source>
			<translation>tab_organizations</translation>
		</message>
		<message>
			<source>tab_teams</source>
			<translation>Команди</translation>
		</message>
		<message>
			<source>tooltip_tab_teams</source>
			<translation>tab_teams</translation>
		</message>
		<message>
			<source>tab_users</source>
			<translation>Користувачі</translation>
		</message>
		<message>
			<source>tooltip_tab_users</source>
			<translation>tab_users</translation>
		</message>
	</context>
	<context>
		<name>result_selector</name>
		<message>
			<source>title</source>
			<translation>Селектор Результату</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_result_selector</source>
			<translation>Селектор Результату</translation>
		</message>
		<message>
			<source>tooltip_dlg_result_selector</source>
			<translation>dlg_result_selector</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_descript_compare</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_compare</source>
			<translation>lbl_descript_compare</translation>
		</message>
		<message>
			<source>lbl_result_compare</source>
			<translation>Результат Для Порівняння:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_compare</source>
			<translation>lbl_result_compare</translation>
		</message>
		<message>
			<source>lbl_result_main</source>
			<translation>Результат Для Показу:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_main</source>
			<translation>lbl_result_main</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Результат</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
	</context>
	<context>
		<name>scada_graph</name>
		<message>
			<source>title</source>
			<translation>Scada graph</translation>
		</message>
		<message>
			<source>dlg_scada_graph</source>
			<translation>Scada graph</translation>
		</message>
		<message>
			<source>tooltip_dlg_scada_graph</source>
			<translation>dlg_scada_graph</translation>
		</message>
	</context>
	<context>
		<name>search_workcat</name>
		<message>
			<source>title</source>
			<translation>Workcat Пошук</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_export_to_csv</source>
			<translation>Експорт У csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_to_csv</source>
			<translation>btn_export_to_csv</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_state0</source>
			<translation>Активувати</translation>
		</message>
		<message>
			<source>tooltip_btn_state0</source>
			<translation>btn_state0</translation>
		</message>
		<message>
			<source>btn_state1</source>
			<translation>Активувати</translation>
		</message>
		<message>
			<source>tooltip_btn_state1</source>
			<translation>btn_state1</translation>
		</message>
		<message>
			<source>dlg_search_workcat</source>
			<translation>Workcat Пошук</translation>
		</message>
		<message>
			<source>tooltip_dlg_search_workcat</source>
			<translation>dlg_search_workcat</translation>
		</message>
		<message>
			<source>lbl_destination_path</source>
			<translation>Шлях Призначення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_destination_path</source>
			<translation>lbl_destination_path</translation>
		</message>
		<message>
			<source>lbl_end</source>
			<translation>Фільтрувати за: код</translation>
		</message>
		<message>
			<source>tooltip_lbl_end</source>
			<translation>lbl_end</translation>
		</message>
		<message>
			<source>lbl_feat_end</source>
			<translation>Функції Видалені З Вибраним workcat</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_end</source>
			<translation>lbl_feat_end</translation>
		</message>
		<message>
			<source>lbl_feat_ini</source>
			<translation>Функції Встановлені З Вибраним workcat</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_ini</source>
			<translation>lbl_feat_ini</translation>
		</message>
		<message>
			<source>lbl_init</source>
			<translation>Фільтрувати За: код</translation>
		</message>
		<message>
			<source>tooltip_lbl_init</source>
			<translation>lbl_init</translation>
		</message>
		<message>
			<source>lbl_total1</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;&amp;lt;span style=&amp;quot; font-weight:600;&amp;quot;&amp;gt;Загальна Кількість:&amp;lt;/span&amp;gt;&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_lbl_total1</source>
			<translation>lbl_total1</translation>
		</message>
		<message>
			<source>lbl_total2</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;&amp;lt;span style=&amp;quot; font-weight:600;&amp;quot;&amp;gt;Загальна кількість:&amp;lt;/span&amp;gt;&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_lbl_total2</source>
			<translation>lbl_total2</translation>
		</message>
		<message>
			<source>tab_doc</source>
			<translation>Документи</translation>
		</message>
		<message>
			<source>tooltip_tab_doc</source>
			<translation>tab_doc</translation>
		</message>
		<message>
			<source>tab_ended</source>
			<translation>Видалено</translation>
		</message>
		<message>
			<source>tooltip_tab_ended</source>
			<translation>tab_ended</translation>
		</message>
		<message>
			<source>tab_init</source>
			<translation>Встановлено</translation>
		</message>
		<message>
			<source>tooltip_tab_init</source>
			<translation>tab_init</translation>
		</message>
	</context>
	<context>
		<name>selector</name>
		<message>
			<source>title</source>
			<translation>Селектор</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_selector</source>
			<translation>Селектор</translation>
		</message>
		<message>
			<source>tooltip_dlg_selector</source>
			<translation>dlg_selector</translation>
		</message>
	</context>
	<context>
		<name>selector_date</name>
		<message>
			<source>title</source>
			<translation>Вибір дати</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>ГАРАЗД</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>date_from</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_date_from</source>
			<translation>date_from</translation>
		</message>
		<message>
			<source>date_to</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_date_to</source>
			<translation>date_to</translation>
		</message>
		<message>
			<source>dlg_selector_date</source>
			<translation>Вибір дати</translation>
		</message>
		<message>
			<source>tooltip_dlg_selector_date</source>
			<translation>dlg_selector_date</translation>
		</message>
		<message>
			<source>lbl_date_from</source>
			<translation>Дата від:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_from</source>
			<translation>lbl_date_from</translation>
		</message>
		<message>
			<source>lbl_date_to</source>
			<translation>Дата до:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_to</source>
			<translation>lbl_date_to</translation>
		</message>
	</context>
	<context>
		<name>snapshot_view</name>
		<message>
			<source>Audit</source>
			<translation>Аудит</translation>
		</message>
		<message>
			<source>tooltip_Audit</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Елементи Для Відновлення</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Елементи для відновлення</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Тимчасовий Та Просторовий Вибір</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Тимчасовий Та Просторовий Вибір</translation>
		</message>
	</context>
	<context>
		<name>status_selector</name>
		<message>
			<source>title</source>
			<translation>Селектор Статусу</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_status_selector</source>
			<translation>Селектор Статусу</translation>
		</message>
		<message>
			<source>tooltip_dlg_status_selector</source>
			<translation>dlg_status_selector</translation>
		</message>
		<message>
			<source>lbl_new_status</source>
			<translation>Новий Статус:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_status</source>
			<translation>lbl_new_status</translation>
		</message>
		<message>
			<source>lbl_result</source>
			<translation>результат_id: результат_name</translation>
		</message>
		<message>
			<source>tooltip_lbl_result</source>
			<translation>lbl_result</translation>
		</message>
		<message>
			<source>lbl_result_main</source>
			<translation>Ви змінюєте статус наступного результату:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_main</source>
			<translation>lbl_result_main</translation>
		</message>
	</context>
	<context>
		<name>style</name>
		<message>
			<source>title</source>
			<translation>Додати категорію</translation>
		</message>
		<message>
			<source>btn_add</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_add</source>
			<translation>btn_add</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_style</source>
			<translation>Додати категорію</translation>
		</message>
		<message>
			<source>tooltip_dlg_style</source>
			<translation>dlg_style</translation>
		</message>
		<message>
			<source>lbl_cat_id</source>
			<translation>ID категорії:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_id</source>
			<translation>lbl_cat_id</translation>
		</message>
		<message>
			<source>lbl_cat_name</source>
			<translation>Назва категорії:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_name</source>
			<translation>lbl_cat_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_role</source>
			<translation>Роль:</translation>
		</message>
		<message>
			<source>tooltip_lbl_role</source>
			<translation>lbl_role</translation>
		</message>
		<message>
			<source>tab_del_feature</source>
			<translation>Дані</translation>
		</message>
		<message>
			<source>tooltip_tab_del_feature</source>
			<translation>tab_del_feature</translation>
		</message>
	</context>
	<context>
		<name>style_manager</name>
		<message>
			<source>title</source>
			<translation>Стиль управління</translation>
		</message>
		<message>
			<source>btn_add_style</source>
			<translation>Додати стиль</translation>
		</message>
		<message>
			<source>tooltip_btn_add_style</source>
			<translation>Додати стиль</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>btn_delete_style</source>
			<translation>Видалити стиль</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_style</source>
			<translation>btn_delete_style</translation>
		</message>
		<message>
			<source>btn_refresh_all</source>
			<translation>Оновити все</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh_all</source>
			<translation>Оновити все</translation>
		</message>
		<message>
			<source>btn_update_group</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_btn_update_group</source>
			<translation>Оновити вибрану категорію</translation>
		</message>
		<message>
			<source>btn_update_style</source>
			<translation>Оновити стиль</translation>
		</message>
		<message>
			<source>tooltip_btn_update_style</source>
			<translation>Оновити стиль</translation>
		</message>
		<message>
			<source>dlg_style_manager</source>
			<translation>Стиль управління</translation>
		</message>
		<message>
			<source>tooltip_dlg_style_manager</source>
			<translation>dlg_style_manager</translation>
		</message>
		<message>
			<source>lbl_filter_category</source>
			<translation>Фільтрувати за: Категорія</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_category</source>
			<translation>lbl_filter_category</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Фільтрувати за: layername</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>style_update_category</name>
		<message>
			<source>title</source>
			<translation>Перейменувати категорію</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_style_update_category</source>
			<translation>Перейменувати категорію</translation>
		</message>
		<message>
			<source>tooltip_dlg_style_update_category</source>
			<translation>dlg_style_update_category</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Будь ласка, виберіть нове ім&apos;я категорії:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>lbl_rename_copy</translation>
		</message>
	</context>
	<context>
		<name>team_create</name>
		<message>
			<source>title</source>
			<translation>Створити команду</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>dlg_team_create</source>
			<translation>Створити команду</translation>
		</message>
		<message>
			<source>tooltip_dlg_team_create</source>
			<translation>dlg_team_create</translation>
		</message>
		<message>
			<source>grb_team</source>
			<translation>Команда:</translation>
		</message>
		<message>
			<source>tooltip_grb_team</source>
			<translation>grb_team</translation>
		</message>
		<message>
			<source>TeamTab</source>
			<translation>Команда</translation>
		</message>
		<message>
			<source>tooltip_TeamTab</source>
			<translation>TeamTab</translation>
		</message>
	</context>
	<context>
		<name>team_management</name>
		<message>
			<source>title</source>
			<translation>Управління Командою</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_user_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_user_select</source>
			<translation>btn_user_select</translation>
		</message>
		<message>
			<source>btn_user_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_user_unselect</source>
			<translation>btn_user_unselect</translation>
		</message>
		<message>
			<source>btn_vehicle_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_vehicle_select</source>
			<translation>btn_vehicle_select</translation>
		</message>
		<message>
			<source>btn_vehicle_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_vehicle_unselect</source>
			<translation>btn_vehicle_unselect</translation>
		</message>
		<message>
			<source>btn_visitclass_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_visitclass_select</source>
			<translation>btn_visitclass_select</translation>
		</message>
		<message>
			<source>btn_visitclass_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_visitclass_unselect</source>
			<translation>btn_visitclass_unselect</translation>
		</message>
		<message>
			<source>dlg_team_management</source>
			<translation>Управління Командою</translation>
		</message>
		<message>
			<source>tooltip_dlg_team_management</source>
			<translation>dlg_team_management</translation>
		</message>
		<message>
			<source>tab_user</source>
			<translation>Користувачі</translation>
		</message>
		<message>
			<source>tooltip_tab_user</source>
			<translation>Користувачі</translation>
		</message>
		<message>
			<source>tab_vehicles</source>
			<translation>Транспортні Засоби</translation>
		</message>
		<message>
			<source>tooltip_tab_vehicles</source>
			<translation>Транспортні Засоби</translation>
		</message>
		<message>
			<source>tab_visit_class</source>
			<translation>Клас відвідування</translation>
		</message>
		<message>
			<source>tooltip_tab_visit_class</source>
			<translation>Клас Візиту</translation>
		</message>
	</context>
	<context>
		<name>toolbox</name>
		<message>
			<source>title</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>dlg_toolbox</source>
			<translation>Діалог</translation>
		</message>
		<message>
			<source>tooltip_dlg_toolbox</source>
			<translation>dlg_toolbox</translation>
		</message>
	</context>
	<context>
		<name>toolbox_reports</name>
		<message>
			<source>title</source>
			<translation>Звіти</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_export</source>
			<translation>Експортувати</translation>
		</message>
		<message>
			<source>tooltip_btn_export</source>
			<translation>btn_export</translation>
		</message>
		<message>
			<source>btn_export_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_export_path</source>
			<translation>btn_export_path</translation>
		</message>
		<message>
			<source>dlg_toolbox_reports</source>
			<translation>Звіти</translation>
		</message>
		<message>
			<source>tooltip_dlg_toolbox_reports</source>
			<translation>dlg_toolbox_reports</translation>
		</message>
		<message>
			<source>grb_filters</source>
			<translation>Фільтри</translation>
		</message>
		<message>
			<source>tooltip_grb_filters</source>
			<translation>grb_filters</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Інформація</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Запит:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>lbl_export_path</source>
			<translation>Шлях:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_path</source>
			<translation>lbl_export_path</translation>
		</message>
	</context>
	<context>
		<name>toolbox_tool</name>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_run</source>
			<translation>Запустити</translation>
		</message>
		<message>
			<source>tooltip_btn_run</source>
			<translation>btn_run</translation>
		</message>
		<message>
			<source>grb_input_layer</source>
			<translation>Вхідний Шар:</translation>
		</message>
		<message>
			<source>tooltip_grb_input_layer</source>
			<translation>grb_input_layer</translation>
		</message>
		<message>
			<source>grb_parameters</source>
			<translation>Параметри Опцій:</translation>
		</message>
		<message>
			<source>tooltip_grb_parameters</source>
			<translation>grb_parameters</translation>
		</message>
		<message>
			<source>grb_selection_type</source>
			<translation>Тип вибору:</translation>
		</message>
		<message>
			<source>tooltip_grb_selection_type</source>
			<translation>grb_selection_type</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Інформація:</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>progressBar</source>
			<translation>%p%</translation>
		</message>
		<message>
			<source>tooltip_progressBar</source>
			<translation>progressBar</translation>
		</message>
		<message>
			<source>rbt_layer</source>
			<translation>Усі елементи</translation>
		</message>
		<message>
			<source>tooltip_rbt_layer</source>
			<translation>rbt_layer</translation>
		</message>
		<message>
			<source>rbt_previous</source>
			<translation>Вибрані лише об&apos;єкти</translation>
		</message>
		<message>
			<source>tooltip_rbt_previous</source>
			<translation>rbt_previous</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Конфігурація</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Журнал Інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>visit</name>
		<message>
			<source>title</source>
			<translation>Відвідати</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Додати геом</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>btn_add_geom</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_event_delete</source>
			<translation>ВИДАЛИТИ ПОДІЮ</translation>
		</message>
		<message>
			<source>tooltip_btn_event_delete</source>
			<translation>btn_event_delete</translation>
		</message>
		<message>
			<source>btn_event_insert</source>
			<translation>ВСТАВИТИ ПОДІЮ</translation>
		</message>
		<message>
			<source>tooltip_btn_event_insert</source>
			<translation>btn_event_insert</translation>
		</message>
		<message>
			<source>btn_event_update</source>
			<translation>ОНОВИТИ ПОДІЮ</translation>
		</message>
		<message>
			<source>tooltip_btn_event_update</source>
			<translation>btn_event_update</translation>
		</message>
		<message>
			<source>btn_feature_delete</source>
			<translation>btn_feature_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_delete</source>
			<translation>btn_feature_delete</translation>
		</message>
		<message>
			<source>btn_feature_insert</source>
			<translation>btn_feature_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_insert</source>
			<translation>btn_feature_insert</translation>
		</message>
		<message>
			<source>btn_feature_snapping</source>
			<translation>btn_feature_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_snapping</source>
			<translation>btn_feature_snapping</translation>
		</message>
		<message>
			<source>dlg_visit</source>
			<translation>Відвідати</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit</source>
			<translation>dlg_visit</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Елемент тип:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation>Код:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_end_date</source>
			<translation>Кінець дата:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_date</source>
			<translation>lbl_end_date</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Експлуатація:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>З панелі інструментів лише СТАНДАРТНІ ПОДІЇ увімкнені.</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_start_date</source>
			<translation>Початок дата:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_date</source>
			<translation>lbl_start_date</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Статус:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_user_name</source>
			<translation>Користувач ім&apos;я:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user_name</source>
			<translation>lbl_user_name</translation>
		</message>
		<message>
			<source>lbl_visitcat_id</source>
			<translation>Visitcat id:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_visitcat_id</source>
			<translation>lbl_visitcat_id</translation>
		</message>
		<message>
			<source>startdate</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_startdate</source>
			<translation>startdate</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Дуга</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>З&apos;єднання</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Документ</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>tab_document</translation>
		</message>
		<message>
			<source>tab_event</source>
			<translation>Подія</translation>
		</message>
		<message>
			<source>tooltip_tab_event</source>
			<translation>tab_event</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Зливоприймальник</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Посилання</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Вузол</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Відносини</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Відвідати</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
	</context>
	<context>
		<name>visit_document</name>
		<message>
			<source>title</source>
			<translation>Завантажити Документи</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Відкрити</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_visit_document</source>
			<translation>Завантажити Документи</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_document</source>
			<translation>dlg_visit_document</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Список Документів</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Відвідати id</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_event</name>
		<message>
			<source>title</source>
			<translation>Стандартна подія</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_file</source>
			<translation>Додати файл</translation>
		</message>
		<message>
			<source>tooltip_btn_add_file</source>
			<translation>btn_add_file</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_file</source>
			<translation>Видалити файл</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_file</source>
			<translation>btn_delete_file</translation>
		</message>
		<message>
			<source>dlg_visit_event</source>
			<translation>Стандартна подія</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event</source>
			<translation>dlg_visit_event</translation>
		</message>
		<message>
			<source>label</source>
			<translation>код_події:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Файли:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>ID параметра:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Позиція id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Позиція значення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Текст:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_value</source>
			<translation>Значення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value</source>
			<translation>lbl_value</translation>
		</message>
	</context>
	<context>
		<name>visit_event_full</name>
		<message>
			<source>title</source>
			<translation>Подія</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_visit_event_full</source>
			<translation>Подія</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event_full</source>
			<translation>dlg_visit_event_full</translation>
		</message>
		<message>
			<source>lbl_compass</source>
			<translation>Компас:</translation>
		</message>
		<message>
			<source>tooltip_lbl_compass</source>
			<translation>lbl_compass</translation>
		</message>
		<message>
			<source>lbl_event_code</source>
			<translation>Код події:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_code</source>
			<translation>lbl_event_code</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Файли:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_geom1</source>
			<translation>Геом1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom1</source>
			<translation>lbl_geom1</translation>
		</message>
		<message>
			<source>lbl_geom2</source>
			<translation>Геом2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom2</source>
			<translation>lbl_geom2</translation>
		</message>
		<message>
			<source>lbl_geom3</source>
			<translation>Геом3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom3</source>
			<translation>lbl_geom3</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Ідентифікатор:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_index_val</source>
			<translation>Індекс значення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_index_val</source>
			<translation>lbl_index_val</translation>
		</message>
		<message>
			<source>lbl_is_last</source>
			<translation>Є останнім:</translation>
		</message>
		<message>
			<source>tooltip_lbl_is_last</source>
			<translation>lbl_is_last</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Ідентифікатор параметра:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Ідентифікатор позиції:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Значення Позиції:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Текст:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_tstamp</source>
			<translation>Tstamp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tstamp</source>
			<translation>lbl_tstamp</translation>
		</message>
		<message>
			<source>lbl_value</source>
			<translation>Значення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value</source>
			<translation>lbl_value</translation>
		</message>
		<message>
			<source>lbl_value1</source>
			<translation>Значення1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value1</source>
			<translation>lbl_value1</translation>
		</message>
		<message>
			<source>lbl_value2</source>
			<translation>Значення2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value2</source>
			<translation>lbl_value2</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Ідентифікатор візиту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
		<message>
			<source>lbl_xcoord</source>
			<translation>Xcoord:</translation>
		</message>
		<message>
			<source>tooltip_lbl_xcoord</source>
			<translation>lbl_xcoord</translation>
		</message>
		<message>
			<source>lbl_ycoord</source>
			<translation>Ycoord:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ycoord</source>
			<translation>lbl_ycoord</translation>
		</message>
		<message>
			<source>tab_files</source>
			<translation>Файли</translation>
		</message>
		<message>
			<source>tooltip_tab_files</source>
			<translation>tab_files</translation>
		</message>
		<message>
			<source>tab_info</source>
			<translation>Інфо</translation>
		</message>
		<message>
			<source>tooltip_tab_info</source>
			<translation>tab_info</translation>
		</message>
	</context>
	<context>
		<name>visit_event_rehab</name>
		<message>
			<source>title</source>
			<translation>Подія реабілітації дуги</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_file</source>
			<translation>Додати файл</translation>
		</message>
		<message>
			<source>tooltip_btn_add_file</source>
			<translation>btn_add_file</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_file</source>
			<translation>Видалити файл</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_file</source>
			<translation>btn_delete_file</translation>
		</message>
		<message>
			<source>dlg_visit_event_rehab</source>
			<translation>Подія реабілітації дуги</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event_rehab</source>
			<translation>dlg_visit_event_rehab</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Файли:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_geom1</source>
			<translation>Геом1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom1</source>
			<translation>lbl_geom1</translation>
		</message>
		<message>
			<source>lbl_geom2</source>
			<translation>Геом2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom2</source>
			<translation>lbl_geom2</translation>
		</message>
		<message>
			<source>lbl_geom3</source>
			<translation>Геом3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom3</source>
			<translation>lbl_geom3</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Ідентифікатор параметра:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Позиція id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Позиція значення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Текст:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_value1</source>
			<translation>Значення1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value1</source>
			<translation>lbl_value1</translation>
		</message>
		<message>
			<source>lbl_value2</source>
			<translation>Значення2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value2</source>
			<translation>lbl_value2</translation>
		</message>
	</context>
	<context>
		<name>visit_gallery</name>
		<message>
			<source>title</source>
			<translation>Галерея</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_next</source>
			<translation>btn_next</translation>
		</message>
		<message>
			<source>tooltip_btn_next</source>
			<translation>btn_next</translation>
		</message>
		<message>
			<source>btn_previous</source>
			<translation>btn_previous</translation>
		</message>
		<message>
			<source>tooltip_btn_previous</source>
			<translation>btn_previous</translation>
		</message>
		<message>
			<source>dlg_visit_gallery</source>
			<translation>Галерея</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_gallery</source>
			<translation>dlg_visit_gallery</translation>
		</message>
		<message>
			<source>lbl_event_id</source>
			<translation>Ідентифікатор події:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_id</source>
			<translation>lbl_event_id</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Візит ідентифікатор:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_gallery_zoom</name>
		<message>
			<source>title</source>
			<translation>Збільшення галереї</translation>
		</message>
		<message>
			<source>btn_slideNext</source>
			<translation>btn_slideNext</translation>
		</message>
		<message>
			<source>tooltip_btn_slideNext</source>
			<translation>btn_slideNext</translation>
		</message>
		<message>
			<source>btn_slidePrevious</source>
			<translation>btn_slidePrevious</translation>
		</message>
		<message>
			<source>tooltip_btn_slidePrevious</source>
			<translation>btn_slidePrevious</translation>
		</message>
		<message>
			<source>dlg_visit_gallery_zoom</source>
			<translation>Збільшення галереї</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_gallery_zoom</source>
			<translation>dlg_visit_gallery_zoom</translation>
		</message>
		<message>
			<source>lbl_event_id</source>
			<translation>Ідентифікатор події:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_id</source>
			<translation>lbl_event_id</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Ідентифікатор візиту:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_manager</name>
		<message>
			<source>title</source>
			<translation>Керування візитами</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити візит</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Відкрити візит</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>date_event_from</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_date_event_from</source>
			<translation>date_event_from</translation>
		</message>
		<message>
			<source>date_event_to</source>
			<translation>dd/MM/yyyy</translation>
		</message>
		<message>
			<source>tooltip_date_event_to</source>
			<translation>date_event_to</translation>
		</message>
		<message>
			<source>dlg_visit_manager</source>
			<translation>Керування візитами</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_manager</source>
			<translation>dlg_visit_manager</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Від:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>lbl_data_event_from</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>До:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>lbl_data_event_to</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Фільтрувати за кодом:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
	</context>
	<context>
		<name>workcat_manager</name>
		<message>
			<source>title</source>
			<translation>Workcat управління</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_workcat_manager</source>
			<translation>Workcat управління</translation>
		</message>
		<message>
			<source>tooltip_dlg_workcat_manager</source>
			<translation>dlg_workcat_manager</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Фільтрувати за: Workcat назва</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>workorder_management</name>
		<message>
			<source>title</source>
			<translation>Управління Робочими Замовленнями</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Створити Робоче Замовлення</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_create_wclass</source>
			<translation>Створити Клас</translation>
		</message>
		<message>
			<source>tooltip_btn_create_wclass</source>
			<translation>btn_create_wclass</translation>
		</message>
		<message>
			<source>btn_create_wtype</source>
			<translation>Створити Тип</translation>
		</message>
		<message>
			<source>tooltip_btn_create_wtype</source>
			<translation>btn_create_wtype</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити Робоче Замовлення</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_workorder_management</source>
			<translation>Управління Робочими Замовленнями</translation>
		</message>
		<message>
			<source>tooltip_dlg_workorder_management</source>
			<translation>dlg_workorder_management</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Фільтрувати за назвою:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_column_filter_dates</source>
			<translation>Тип Робочого Замовлення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter_dates</source>
			<translation>lbl_column_filter_dates</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Клас Робочого Замовлення:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
	</context>
	<context>
		<name>workspace_create</name>
		<message>
			<source>title</source>
			<translation>Створити нове робоче середовище</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Прийняти</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Скасувати</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_workspace_create</source>
			<translation>Створити нове робоче середовище</translation>
		</message>
		<message>
			<source>tooltip_dlg_workspace_create</source>
			<translation>dlg_workspace_create</translation>
		</message>
		<message>
			<source>lbl_new_workspace</source>
			<translation>Назва робочого простору:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace</source>
			<translation>Назва Робочого Простору</translation>
		</message>
		<message>
			<source>lbl_new_workspace_chk</source>
			<translation>Приватний робочий простір:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace_chk</source>
			<translation>lbl_new_workspace_chk</translation>
		</message>
		<message>
			<source>lbl_new_workspace_descript</source>
			<translation>Опис:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace_descript</source>
			<translation>Опис робочого простору</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Журнал інформації</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
		<message>
			<source>tab_new_workspace</source>
			<translation>Створити новий робочий простір</translation>
		</message>
		<message>
			<source>tooltip_tab_new_workspace</source>
			<translation>tab_new_workspace</translation>
		</message>
	</context>
	<context>
		<name>workspace_manager</name>
		<message>
			<source>title</source>
			<translation>Менеджер робочих просторів</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Закрити</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Створити</translation>
		</message>
		<message>
			<source>btn_current</source>
			<translation>Встановити Поточний</translation>
		</message>
		<message>
			<source>tooltip_btn_current</source>
			<translation>Встановити Поточну Робочу Область</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Видалити</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Видалити Вибраний Робочий Простір</translation>
		</message>
		<message>
			<source>btn_toggle_privacy</source>
			<translation>Перемкнути приватність</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_privacy</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Оновити</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Перемкнути приватність</translation>
		</message>
		<message>
			<source>dlg_workspace_manager</source>
			<translation>Менеджер робочих просторів</translation>
		</message>
		<message>
			<source>tooltip_dlg_workspace_manager</source>
			<translation>dlg_workspace_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Інформація:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_workspace_name</source>
			<translation>Фільтрувати за: Назва Робочого Простору</translation>
		</message>
		<message>
			<source>tooltip_lbl_workspace_name</source>
			<translation>lbl_workspace_name</translation>
		</message>
	</context>
</TS>
