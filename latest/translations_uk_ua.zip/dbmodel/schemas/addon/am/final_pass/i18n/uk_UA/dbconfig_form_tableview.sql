/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = am, public;
UPDATE config_form_tableview AS t SET alias = v.alias FROM (
	VALUES
	('cat_result', 'budget', 'Бюджет'),
    ('cat_result', 'cur_user', 'Поточний Користувач'),
    ('cat_result', 'descript', 'Опис'),
    ('cat_result', 'dnom', 'DNOM'),
    ('cat_result', 'expl_id', 'Експлуатація Id'),
    ('cat_result', 'features', 'Елементи'),
    ('cat_result', 'iscorporate', 'Корпоративний'),
    ('cat_result', 'material_id', 'Матеріал Id'),
    ('cat_result', 'presszone_id', 'Зона тиску Id'),
    ('cat_result', 'report', 'Звіт'),
    ('cat_result', 'result_id', 'Результат Id'),
    ('cat_result', 'result_name', 'Назва Результату'),
    ('cat_result', 'result_type', 'Тип'),
    ('cat_result', 'status', 'Статус'),
    ('cat_result', 'target_year', 'Рік Горизонту'),
    ('cat_result', 'tstamp', 'Мітка Часу')
) AS v(objectname, columnname, alias)
WHERE t.objectname = v.objectname AND t.columnname = v.columnname;