/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = cm, public, public;
UPDATE config_param_system AS t SET label = v.label, descript = v.descript FROM (
	VALUES
	('admin_campaign_type', NULL, 'Змінна для вказівки, який тип кампанії ми хочемо бачити при створенні'),
    ('basic_selector_tab_campaign', 'Змінні селектора', 'Змінна для налаштування всіх опцій, пов''язаних із пошуком для конкретної вкладки'),
    ('basic_selector_tab_lot', 'Змінні селектора', 'Змінна для налаштування всіх опцій, пов''язаних із пошуком для конкретної вкладки')
) AS v(parameter, label, descript)
WHERE t.parameter = v.parameter;