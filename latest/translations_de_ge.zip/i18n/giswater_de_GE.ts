<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_ge">
<!-- TOOLBARS AND ACTIONS -->
	<context>
		<name>giswater</name>
		<message>
			<source>18_text</source>
			<translation>Kommerzielle Verbindung</translation>
		</message>
		<message>
			<source>19_text</source>
			<translation>Topo-Werkzeuge</translation>
		</message>
		<message>
			<source>24_text</source>
			<translation>Go2EPA-Express</translation>
		</message>
		<message>
			<source>301_text</source>
			<translation>Jahresplaner</translation>
		</message>
		<message>
			<source>302_text</source>
			<translation>Monatlicher Planer</translation>
		</message>
		<message>
			<source>303_text</source>
			<translation>Preise Generator</translation>
		</message>
		<message>
			<source>304_text</source>
			<translation>Besuch hinzufügen</translation>
		</message>
		<message>
			<source>305_text</source>
			<translation>Einheit Planer</translation>
		</message>
		<message>
			<source>309_text</source>
			<translation>Vorfallsmanager</translation>
		</message>
		<message>
			<source>36_text</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>38_text</source>
			<translation>Neue Netzkosten</translation>
		</message>
		<message>
			<source>47_text</source>
			<translation>Selektor für den Sektor</translation>
		</message>
		<message>
			<source>74_text</source>
			<translation>Neues Los hinzufügen</translation>
		</message>
		<message>
			<source>75_text</source>
			<translation>Grundstücksverwalter</translation>
		</message>
		<message>
			<source>76_text</source>
			<translation>Losfilter</translation>
		</message>
		<message>
			<source>81_text</source>
			<translation>Neuer pSektor</translation>
		</message>
		<message>
			<source>82_text</source>
			<translation>Psector Manager</translation>
		</message>
		<message>
			<source>98_text</source>
			<translation>Konfig-Editor</translation>
		</message>
		<message>
			<source>Actions</source>
			<translation>Aktionen</translation>
		</message>
		<message>
			<source>Add drain GPKG project</source>
			<translation>Abfluss GPKG-Projekt hinzufügen</translation>
		</message>
		<message>
			<source>Additional demand check</source>
			<translation>Zusätzliche Bedarfsprüfung</translation>
		</message>
		<message>
			<source>Advanced</source>
			<translation>Fortgeschrittene</translation>
		</message>
		<message>
			<source>AmBreakage</source>
			<translation>Verwaltungsinstrument</translation>
		</message>
		<message>
			<source>AmPriority</source>
			<translation>Auswahl und Berechnung der Prioritäten</translation>
		</message>
		<message>
			<source>Analytics</source>
			<translation>Analytik</translation>
		</message>
		<message>
			<source>ARC</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>Breakdown Assignation</source>
			<translation>Pannenhilfe-Zuordnung</translation>
		</message>
		<message>
			<source>Calibration</source>
			<translation>Kalibrierung</translation>
		</message>
		<message>
			<source>Closest arcs</source>
			<translation>Engste Bögen</translation>
		</message>
		<message>
			<source>CONNEC</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>DRAG-DROP</source>
			<translation>Ziehen und Ablegen</translation>
		</message>
		<message>
			<source>Dscenario</source>
			<translation>Dszenario</translation>
		</message>
		<message>
			<source>DWF scenario</source>
			<translation>DWF-Szenario</translation>
		</message>
		<message>
			<source>Emitter calibration</source>
			<translation>Emitter calibration</translation>
		</message>
		<message>
			<source>EPA multi calls</source>
			<translation>EPA-Mehrfachanrufe</translation>
		</message>
		<message>
			<source>Export</source>
			<translation>Exportieren</translation>
		</message>
		<message>
			<source>Fast print</source>
			<translation>Schnelles Drucken</translation>
		</message>
		<message>
			<source>Forced arcs</source>
			<translation>Erzwungene Bögen</translation>
		</message>
		<message>
			<source>Forced arcs (selecting only arcs)</source>
			<translation>Erzwungene Bögen (nur Bögen auswählen)</translation>
		</message>
		<message>
			<source>Get help</source>
			<translation>Hilfe holen</translation>
		</message>
		<message>
			<source>Go2IBER</source>
			<translation>Go2IBER</translation>
		</message>
		<message>
			<source>GULLY</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>GwAddCampaignButton</source>
			<translation>Kampagne hinzufügen</translation>
		</message>
		<message>
			<source>GwAddChildLayerButton</source>
			<translation>Giswater-Schicht laden</translation>
		</message>
		<message>
			<source>GwAddLotButton</source>
			<translation>Los hinzufügen</translation>
		</message>
		<message>
			<source>GwAmBreakageButton</source>
			<translation>Verwaltungsinstrument</translation>
		</message>
		<message>
			<source>GwAmPriorityButton</source>
			<translation>Auswahl und Berechnung der Prioritäten</translation>
		</message>
		<message>
			<source>GwArcAddButton</source>
			<translation>Bogeneinsatz</translation>
		</message>
		<message>
			<source>GwArcDivideButton</source>
			<translation>Bogenschere</translation>
		</message>
		<message>
			<source>GwArcFusionButton</source>
			<translation>Lichtbogenfusion</translation>
		</message>
		<message>
			<source>GwAuxCircleAddButton</source>
			<translation>Kreis erstellen</translation>
		</message>
		<message>
			<source>GwAuxPointAddButton</source>
			<translation>Punkt erstellen</translation>
		</message>
		<message>
			<source>GwConfigButton</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>GwConnectLinkButton</source>
			<translation>Mit dem Netzwerk verbinden</translation>
		</message>
		<message>
			<source>GwCSVButton</source>
			<translation>CSV importieren</translation>
		</message>
		<message>
			<source>GwDateSelectorButton</source>
			<translation>Datumselektor</translation>
		</message>
		<message>
			<source>GwDimensioningButton</source>
			<translation>Bemessung</translation>
		</message>
		<message>
			<source>GwDocumentButton</source>
			<translation>Dokument hinzufügen</translation>
		</message>
		<message>
			<source>GwDocumentManagerButton</source>
			<translation>Document manager</translation>
		</message>
		<message>
			<source>GwDscenarioManagerButton</source>
			<translation>Dszenario-Manager</translation>
		</message>
		<message>
			<source>GwElementButton</source>
			<translation>Element hinzufügen</translation>
		</message>
		<message>
			<source>GwElementManagerButton</source>
			<translation>Element-Manager</translation>
		</message>
		<message>
			<source>GwEpaTools</source>
			<translation>EPA-Werkzeuge</translation>
		</message>
		<message>
			<source>GwFeatureDeleteButton</source>
			<translation>Funktion löschen</translation>
		</message>
		<message>
			<source>GwFeatureEndButton</source>
			<translation>Merkmal beenden</translation>
		</message>
		<message>
			<source>GwFeatureReplaceButton</source>
			<translation>Funktion &quot;Ersetzen</translation>
		</message>
		<message>
			<source>GwFeatureTypeChangeButton</source>
			<translation>Featureklasse ändern</translation>
		</message>
		<message>
			<source>GwFlowExitButton</source>
			<translation>Flow-Ausgang</translation>
		</message>
		<message>
			<source>GwFlowTraceButton</source>
			<translation>Fluss-Spur</translation>
		</message>
		<message>
			<source>GwGo2EpaButton</source>
			<translation>Go2EPA</translation>
		</message>
		<message>
			<source>GwGo2EpaManagerButton</source>
			<translation>EPA-Ergebnismanager</translation>
		</message>
		<message>
			<source>GwGo2EpaSelectorButton</source>
			<translation>EPA result selector</translation>
		</message>
		<message>
			<source>GwInfoButton</source>
			<translation>Info Giswater</translation>
		</message>
		<message>
			<source>GwLayerStyleChangeButton</source>
			<translation>Giswater-Stile</translation>
		</message>
		<message>
			<source>GwLotResourceManagementButton</source>
			<translation>Verwaltung der Grundstücksressourcen</translation>
		</message>
		<message>
			<source>GwManageCampaignLotButton</source>
			<translation>Kampagnenlos verwalten</translation>
		</message>
		<message>
			<source>GwMincutButton</source>
			<translation>Neuer Minschnitt</translation>
		</message>
		<message>
			<source>GwMincutManagerButton</source>
			<translation>Mincut-Verwaltung</translation>
		</message>
		<message>
			<source>GwNetscenarioManagerButton</source>
			<translation>Netscenario-Manager</translation>
		</message>
		<message>
			<source>GwNonVisualManagerButton</source>
			<translation>Manager für nicht-visuelle Objekte</translation>
		</message>
		<message>
			<source>GwPointAddButton</source>
			<translation>Einlegepunkt</translation>
		</message>
		<message>
			<source>GwPriceManagerButton</source>
			<translation>Netzkostenmanager</translation>
		</message>
		<message>
			<source>GwPrintButton</source>
			<translation>Drucken</translation>
		</message>
		<message>
			<source>GwProfileButton</source>
			<translation>Profile tool</translation>
		</message>
		<message>
			<source>GwProjectCheckButton</source>
			<translation>Projekt prüfen</translation>
		</message>
		<message>
			<source>GwPsectorButton</source>
			<translation>Neuer pSektor</translation>
		</message>
		<message>
			<source>GwPsectorManagerButton</source>
			<translation>Psector Manager</translation>
		</message>
		<message>
			<source>GwResultManagerButton</source>
			<translation>Result manager</translation>
		</message>
		<message>
			<source>GwResultSelectorButton</source>
			<translation>Ergebnis-Selektor</translation>
		</message>
		<message>
			<source>GwSearchButton</source>
			<translation>Suche plus</translation>
		</message>
		<message>
			<source>GwSelectorButton</source>
			<translation>Selektoren</translation>
		</message>
		<message>
			<source>GwSnapshotViewButton</source>
			<translation>Schnappschuss-Ansicht</translation>
		</message>
		<message>
			<source>GwToolBoxButton</source>
			<translation>Werkzeugkasten</translation>
		</message>
		<message>
			<source>GwUtilsManagerButton</source>
			<translation>Utils manager</translation>
		</message>
		<message>
			<source>GwVisitButton</source>
			<translation>Besuch hinzufügen</translation>
		</message>
		<message>
			<source>GwVisitManagerButton</source>
			<translation>Manager besuchen</translation>
		</message>
		<message>
			<source>GwWorkspaceManagerButton</source>
			<translation>Arbeitsbereich-Manager</translation>
		</message>
		<message>
			<source>Hydrology scenario</source>
			<translation>Hydrologie-Szenario</translation>
		</message>
		<message>
			<source>Import</source>
			<translation>Importieren</translation>
		</message>
		<message>
			<source>Import CSV</source>
			<translation>CSV importieren</translation>
		</message>
		<message>
			<source>Import INP file</source>
			<translation>INP-Datei importieren</translation>
		</message>
		<message>
			<source>Manage Campaign</source>
			<translation>Kampagne verwalten</translation>
		</message>
		<message>
			<source>Manage Campaign</source>
			<translation>Kampagne verwalten</translation>
		</message>
		<message>
			<source>Manage Lot</source>
			<translation>Manage Lot</translation>
		</message>
		<message>
			<source>Manage Lot</source>
			<translation>Manage Lot</translation>
		</message>
		<message>
			<source>Manage Workorder</source>
			<translation>Manage Workorder</translation>
		</message>
		<message>
			<source>Mapzones manager</source>
			<translation>Mapzones manager</translation>
		</message>
		<message>
			<source>Massive composer</source>
			<translation>Massiver Komponist</translation>
		</message>
		<message>
			<source>menu_name</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>Multi psector print</source>
			<translation>Multisektoraler Druck</translation>
		</message>
		<message>
			<source>NODE</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>Open plugin folder</source>
			<translation>Plugin-Ordner öffnen</translation>
		</message>
		<message>
			<source>Open user folder</source>
			<translation>Benutzerordner öffnen</translation>
		</message>
		<message>
			<source>Priority Calculation (Global)</source>
			<translation>Prioritätsberechnung (Global)</translation>
		</message>
		<message>
			<source>Quantized demands</source>
			<translation>Quantisierte Anforderungen</translation>
		</message>
		<message>
			<source>Reset dialogs</source>
			<translation>Dialoge zurücksetzen</translation>
		</message>
		<message>
			<source>Reset plugin</source>
			<translation>Plugin zurücksetzen</translation>
		</message>
		<message>
			<source>ResultManager</source>
			<translation>Ergebnis-Manager</translation>
		</message>
		<message>
			<source>ResultSelector</source>
			<translation>Ergebnis-Selektor</translation>
		</message>
		<message>
			<source>Review</source>
			<translation>Überprüfung</translation>
		</message>
		<message>
			<source>SELECT</source>
			<translation>Wählen Sie</translation>
		</message>
		<message>
			<source>Show current selectors</source>
			<translation>Aktuelle Selektoren anzeigen</translation>
		</message>
		<message>
			<source>Static calibration</source>
			<translation>Statische Kalibrierung</translation>
		</message>
		<message>
			<source>Style manager</source>
			<translation>Stil-Manager</translation>
		</message>
		<message>
			<source>Toggle Log DB</source>
			<translation>Toggle Log DB</translation>
		</message>
		<message>
			<source>toolbar_am_name</source>
			<translation>Giswater - Vermögensverwalter</translation>
		</message>
		<message>
			<source>toolbar_basic_name</source>
			<translation>Giswater - Basic</translation>
		</message>
		<message>
			<source>toolbar_cm_name</source>
			<translation>Giswater - Kampagnenleiter</translation>
		</message>
		<message>
			<source>toolbar_custom_name</source>
			<translation>Giswater - Benutzerdefiniert</translation>
		</message>
		<message>
			<source>toolbar_edit_name</source>
			<translation>Giswater - Bearbeiten</translation>
		</message>
		<message>
			<source>toolbar_epa_name</source>
			<translation>Giswater - Epa</translation>
		</message>
		<message>
			<source>toolbar_om_name</source>
			<translation>Giswater - O&amp;M</translation>
		</message>
		<message>
			<source>toolbar_plan_name</source>
			<translation>Giswater - Gesamtplan</translation>
		</message>
		<message>
			<source>toolbar_utilities_name</source>
			<translation>Giswater - Versorgungsunternehmen</translation>
		</message>
		<message>
			<source>Valve operation check</source>
			<translation>Überprüfung des Ventilbetriebs</translation>
		</message>
		<message>
			<source>Visit</source>
			<translation>Besuchen Sie</translation>
		</message>
		<message>
			<source>Workcat manager</source>
			<translation>Workcat-Manager</translation>
		</message>
	</context>
<!-- PYTHON MESSAGES -->
	<context>
		<name>giswater</name>
		<message>
			<source></source>
			<translation></translation>
		</message>
		<message>
			<source> </source>
			<translation> </translation>
		</message>
		<message>
			<source>, </source>
			<translation>,</translation>
		</message>
		<message>
			<source>{0}</source>
			<translation>{0}</translation>
		</message>
		<message>
			<source>{0}%</source>
			<translation>{0}%</translation>
		</message>
		<message>
			<source>{0} --&gt; {1}</source>
			<translation>{0} --&gt; {1}</translation>
		</message>
		<message>
			<source>{0}: {1}</source>
			<translation>{0}: {1}</translation>
		</message>
		<message>
			<source>{0} --&gt; {1} --&gt; {2}</source>
			<translation>{0} --&gt; {1} --&gt; {2}</translation>
		</message>
		<message>
			<source>{0}: {1} Python function: tools_gw.set_widgets. WHERE columname=&apos;{2}&apos; AND widgetname=&apos;{3}&apos; AND widgettype=&apos;{4}&apos;</source>
			<translation>{0}: {1} Python-Funktion: tools_gw.set_widgets. WHERE spaltenname=&apos;{2}&apos; AND widgetname=&apos;{3}&apos; AND widgettype=&apos;{4}&apos;</translation>
		</message>
		<message>
			<source>{0}: {1}. widgetname=&apos;{2}&apos; AND widgettype=&apos;{3}&apos;</source>
			<translation>{0}: {1}. widgetname=&apos;{2}&apos; AND widgettype=&apos;{3}&apos;</translation>
		</message>
		<message>
			<source>{0} callback raised: {1}</source>
			<translation>{0} callback raised: {1}</translation>
		</message>
		<message>
			<source>{0} campaign(s) deleted.</source>
			<translation>{0} campaign(s) deleted.</translation>
		</message>
		<message>
			<source>{0}: Config file is not set</source>
			<translation>{0}: Config-Datei ist nicht gesetzt</translation>
		</message>
		<message>
			<source>{0}: Database translation canceled.</source>
			<translation>{0}: Database translation canceled.</translation>
		</message>
		<message>
			<source>{0}: Database translation failed.</source>
			<translation>{0}: Database translation failed.</translation>
		</message>
		<message>
			<source>{0}: Database translation successful to {1}.</source>
			<translation>{0}: Database translation successful to {1}.</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; does not exist. Please select a valid config file.</source>
			<translation>&quot;{0}&quot; does not exist. Please select a valid config file.</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; does not exist. Please select a valid folder.</source>
			<translation>&quot;{0}&quot; does not exist. Please select a valid folder.</translation>
		</message>
		<message>
			<source>{0} error {1}</source>
			<translation>{0} Fehler {1}</translation>
		</message>
		<message>
			<source>{0} error: {1}</source>
			<translation>{0} Fehler: {1}</translation>
		</message>
		<message>
			<source>{0}: Errors: {1}</source>
			<translation>{0}: Errors: {1}</translation>
		</message>
		<message>
			<source>{0} exception: {1}</source>
			<translation>{0} Ausnahme: {1}</translation>
		</message>
		<message>
			<source>{0} Exception: {1}</source>
			<translation>{0} Exception: {1}</translation>
		</message>
		<message>
			<source>{0} exception [{1}]: {2}</source>
			<translation>{0} Ausnahme [{1}]: {2}</translation>
		</message>
		<message>
			<source>{0} failed.</source>
			<translation>{0} failed.</translation>
		</message>
		<message>
			<source>{0}: Failed to update Multilang language preference: {1}</source>
			<translation>{0}: Failed to update Multilang language preference: {1}</translation>
		</message>
		<message>
			<source>{0} id:</source>
			<translation>{0} id:</translation>
		</message>
		<message>
			<source>{0} ID is missing.</source>
			<translation>{0} ID is missing.</translation>
		</message>
		<message>
			<source>{0} is not a table name or {1}</source>
			<translation>{0} ist kein Tabellenname oder {1}</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; is not a valid calibration_mode.</source>
			<translation>&quot;{0}&quot; is not a valid calibration_mode.</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; is not a valid target_parameter.</source>
			<translation>&quot;{0}&quot; is not a valid target_parameter.</translation>
		</message>
		<message>
			<source>{0} item(s) removed from the list: {1}</source>
			<translation>{0} item(s) removed from the list: {1}</translation>
		</message>
		<message>
			<source>{0} lot(s) deleted.</source>
			<translation>{0} lot(s) deleted.</translation>
		</message>
		<message>
			<source>{0}: Multilang language preference updated to {1}.</source>
			<translation>{0}: Multilang language preference updated to {1}.</translation>
		</message>
		<message>
			<source>{0} must contain {1} line{2}.</source>
			<translation>{0} must contain {1} line{2}.</translation>
		</message>
		<message>
			<source>{0} must contain just one line.</source>
			<translation>{0} must contain just one line.</translation>
		</message>
		<message>
			<source>{0} not found in {1} scenario.</source>
			<translation>{0} not found in {1} scenario.</translation>
		</message>
		<message>
			<source>{0} not found in [OPTIONS] section.</source>
			<translation>{0} not found in [OPTIONS] section.</translation>
		</message>
		<message>
			<source>{0}: project type &apos;{1}&apos; not supported</source>
			<translation>{0}: Projekttyp &apos;{1}&apos; wird nicht unterstützt</translation>
		</message>
		<message>
			<source>{0}: Reference {1} = &apos;{2}&apos; it is not managed</source>
			<translation>{0}: Referenz {1} = &apos;{2}&apos; es wird nicht verwaltet</translation>
		</message>
		<message>
			<source>{0}: Refusing to write invalid user_params.config [{1}]: {2}</source>
			<translation>{0}: Refusing to write invalid user_params.config [{1}]: {2}</translation>
		</message>
		<message>
			<source>{0}: Refusing to write plugin user_params.config while GwDevMode is enabled</source>
			<translation>{0}: Refusing to write plugin user_params.config while GwDevMode is enabled</translation>
		</message>
		<message>
			<source>{0}.sql: {1}</source>
			<translation>{0}.sql: {1}</translation>
		</message>
		<message>
			<source>{0} successfully saved.</source>
			<translation>{0} erfolgreich gespeichert.</translation>
		</message>
		<message>
			<source>{0} task is already active!</source>
			<translation>{0} Aufgabe ist bereits aktiv!</translation>
		</message>
		<message>
			<source>{0}: unsupported type {1}</source>
			<translation>{0}: unsupported type {1}</translation>
		</message>
		<message>
			<source>{0}: widget not found</source>
			<translation>{0}: Widget nicht gefunden</translation>
		</message>
		<message>
			<source>{0} workorder(s) deleted.</source>
			<translation>{0} workorder(s) deleted.</translation>
		</message>
		<message>
			<source>About</source>
			<translation>About</translation>
		</message>
		<message>
			<source>About Giswater</source>
			<translation>About Giswater</translation>
		</message>
		<message>
			<source>Accept</source>
			<translation>Accept</translation>
		</message>
		<message>
			<source>Acknowledgments</source>
			<translation>Acknowledgments</translation>
		</message>
		<message>
			<source>Action has no function!!</source>
			<translation>Aktion hat keine Funktion!!</translation>
		</message>
		<message>
			<source>Activate water netowrk snapshot</source>
			<translation>Schnappschuss des Wassernetzes aktivieren</translation>
		</message>
		<message>
			<source>Active</source>
			<translation>Active</translation>
		</message>
		<message>
			<source>Adapt schema to cibs</source>
			<translation>Adapt schema to cibs</translation>
		</message>
		<message>
			<source>Add document</source>
			<translation>Dokument hinzufügen</translation>
		</message>
		<message>
			<source>Addparam must be valid JSON.</source>
			<translation>Addparam must be valid JSON.</translation>
		</message>
		<message>
			<source>Add translator ({0})</source>
			<translation>Add translator ({0})</translation>
		</message>
		<message>
			<source>A diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.</source>
			<translation>Ein Durchmesserwert wird als ungültig angesehen, wenn er Null, negativ, NULL oder größer als der maximale Durchmesser in der Konfigurationstabelle ist. Infolgedessen wird diesen Rohren KEIN Prioritätswert zugewiesen.</translation>
		</message>
		<message>
			<source>Advanced Menu</source>
			<translation>Erweitertes Menü</translation>
		</message>
		<message>
			<source>Alert</source>
			<translation>Alarmierung</translation>
		</message>
		<message>
			<source>ALL</source>
			<translation>ALL</translation>
		</message>
		<message>
			<source>

ALL DONE! INP successfully imported.</source>
			<translation>ALL DONE! INP successfully imported.</translation>
		</message>
		<message>
			<source>ALL DONE! INP successfully imported.</source>
			<translation>ALL DONE! INP successfully imported.</translation>
		</message>
		<message>
			<source>All layers have been successfully refreshed.</source>
			<translation>Alle Ebenen wurden erfolgreich aufgefrischt.</translation>
		</message>
		<message>
			<source>All the values in the column &apos;atlas_id&apos; from the table &apos;plan_psector&apos; have to be INTEGER. This is not the case for your table, please fix this before continuing.</source>
			<translation>Alle Werte in der Spalte &apos;atlas_id&apos; der Tabelle &apos;plan_psector&apos; müssen INTEGER sein. Dies ist bei Ihrer Tabelle nicht der Fall. Bitte beheben Sie dies, bevor Sie fortfahren.</translation>
		</message>
		<message>
			<source>A material is considered invalid if it is not listed in the material configuration table.</source>
			<translation>Ein Material gilt als ungültig, wenn es nicht in der Materialkonfigurationstabelle aufgeführt ist.</translation>
		</message>
		<message>
			<source>An arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.</source>
			<translation>Eine arccat_id gilt als ungültig, wenn sie nicht in der Katalogkonfigurationstabelle aufgeführt ist. Infolgedessen wird diesen Leitungen KEIN Prioritätswert zugewiesen.</translation>
		</message>
		<message>
			<source>An error occurred saving the workorder.</source>
			<translation>An error occurred saving the workorder.</translation>
		</message>
		<message>
			<source>An error occurred while adding the style for layer &apos;{0}&apos;:
{1}</source>
			<translation>An error occurred while adding the style for layer &apos;{0}&apos;:
{1}</translation>
		</message>
		<message>
			<source>A new style has been added to &apos;{0}&apos; for the layer &apos;{1}&apos; using the &apos;GwBasic&apos; style information.
You can change it and use &apos;Update Style&apos; to create a personalized version.</source>
			<translation>A new style has been added to &apos;{0}&apos; for the layer &apos;{1}&apos; using the &apos;GwBasic&apos; style information.
You can change it and use &apos;Update Style&apos; to create a personalized version.</translation>
		</message>
		<message>
			<source>Any connec_id found with this customer_code</source>
			<translation>Jede gefundene connec_id mit diesem customer_code</translation>
		</message>
		<message>
			<source>Any document selected</source>
			<translation>Jedes ausgewählte Dokument</translation>
		</message>
		<message>
			<source>Any record found</source>
			<translation>Any record found</translation>
		</message>
		<message>
			<source>Any record selected</source>
			<translation>Jeder ausgewählte Datensatz</translation>
		</message>
		<message>
			<source>Applied styles for context</source>
			<translation>Angewandte Stile für den Kontext</translation>
		</message>
		<message>
			<source>Apply Multilang translation ({0}) to schema ({1})?</source>
			<translation>Apply Multilang translation ({0}) to schema ({1})?</translation>
		</message>
		<message>
			<source>Apply to Multilang</source>
			<translation>Apply to Multilang</translation>
		</message>
		<message>
			<source>Apply translation ({0}) to schema ({1}) using local SQL files?</source>
			<translation>Apply translation ({0}) to schema ({1}) using local SQL files?</translation>
		</message>
		<message>
			<source>Arc already selected</source>
			<translation>Arc already selected</translation>
		</message>
		<message>
			<source>Arc catalog</source>
			<translation>Arc catalog</translation>
		</message>
		<message>
			<source>Arc fusion</source>
			<translation>Lichtbogenfusion</translation>
		</message>
		<message>
			<source>Arc layer not found. Cannot start inundation from arc.</source>
			<translation>Arc layer not found. Cannot start inundation from arc.</translation>
		</message>
		<message>
			<source>Arcs</source>
			<translation>Arcs</translation>
		</message>
		<message>
			<source>Are you sure to execute vacuum on selected schema?</source>
			<translation>Sind Sie sicher, dass Sie das Vakuum auf dem ausgewählten Schema ausführen wollen?</translation>
		</message>
		<message>
			<source>Are you sure to save this feature?</source>
			<translation>Are you sure to save this feature?</translation>
		</message>
		<message>
			<source>Are you sure to update the project schema to last version?</source>
			<translation>Sind Sie sicher, dass Sie das Projektschema auf die letzte Version aktualisiert haben?</translation>
		</message>
		<message>
			<source>Are you sure you want delete schema &apos;{0}&apos;?</source>
			<translation>Sind Sie sicher, dass Sie Schema &apos;{0}&apos; löschen wollen?</translation>
		</message>
		<message>
			<source>Are you sure you want to assign team &apos;{0}&apos; to {1} selected user(s)?</source>
			<translation>Are you sure you want to assign team &apos;{0}&apos; to {1} selected user(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to cancel these mincuts?</source>
			<translation>Sind Sie sicher, dass Sie diese Minicuts streichen wollen?</translation>
		</message>
		<message>
			<source>Are you sure you want to change to team &apos;{0}&apos; for {1} selected user(s)?</source>
			<translation>Are you sure you want to change to team &apos;{0}&apos; for {1} selected user(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} campaign(s)?</source>
			<translation>Are you sure you want to delete {0} campaign(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} lot(s)?</source>
			<translation>Are you sure you want to delete {0} lot(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} workorder(s)?</source>
			<translation>Are you sure you want to delete {0} workorder(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the selected styles?</source>
			<translation>Sind Sie sicher, dass Sie die ausgewählten Stile löschen wollen?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these mincuts?</source>
			<translation>Sind Sie sicher, dass Sie diese Minicuts löschen wollen?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records:</source>
			<translation>Sind Sie sicher, dass Sie diese Datensätze löschen wollen:</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records?</source>
			<translation>Sind Sie sicher, dass Sie diese Datensätze löschen wollen?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records: ({0})?</source>
			<translation>Are you sure you want to delete these records: ({0})?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records: ({0})?
This will also delete the database user(s): {1}</source>
			<translation>Are you sure you want to delete these records: ({0})?
This will also delete the database user(s): {1}</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records?
Some events have documents</source>
			<translation>Are you sure you want to delete these records?
Some events have documents</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the style group &apos;{0}&apos;?

This will also delete all related entries in the sys_style table.Confirm Cascade Delete</source>
			<translation>Are you sure you want to delete the style group &apos;{0}&apos;?

This will also delete all related entries in the sys_style table.Confirm Cascade Delete</translation>
		</message>
		<message>
			<source>Are you sure you want to disconnect this elements?</source>
			<translation>Sind Sie sicher, dass Sie die Verbindung zu diesen Elementen trennen wollen?</translation>
		</message>
		<message>
			<source>Are you sure you want to override the configuration of this workspace?</source>
			<translation>Sind Sie sicher, dass Sie die Konfiguration dieses Arbeitsbereichs außer Kraft setzen wollen?</translation>
		</message>
		<message>
			<source>Are you sure you want to overwrite this file?</source>
			<translation>Sind Sie sicher, dass Sie diese Datei überschreiben wollen?</translation>
		</message>
		<message>
			<source>Are you sure you want to remove team assignment from {0} selected user(s)?</source>
			<translation>Are you sure you want to remove team assignment from {0} selected user(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to replace selected feature with a new one?</source>
			<translation>Sind Sie sicher, dass Sie das ausgewählte Merkmal durch ein neues ersetzen wollen?</translation>
		</message>
		<message>
			<source>Are you sure you want to replace selected feature with a new one?
If you have different addfields in your feature, they will be deleted.</source>
			<translation>Are you sure you want to replace selected feature with a new one?
If you have different addfields in your feature, they will be deleted.</translation>
		</message>
		<message>
			<source>Are you sure you want to update the style of {0} ({1}) with the symbology of the layer in the project? 
You are going to lose previous information!</source>
			<translation>Are you sure you want to update the style of {0} ({1}) with the symbology of the layer in the project? 
You are going to lose previous information!</translation>
		</message>
		<message>
			<source>A rollback on schema will be done.</source>
			<translation>Es wird ein Rollback auf das Schema durchgeführt.</translation>
		</message>
		<message>
			<source>As a result, the material of these pipes will be treated as the configured unknown material, {0}.</source>
			<translation>As a result, the material of these pipes will be treated as the configured unknown material, {0}.</translation>
		</message>
		<message>
			<source>A scenario cannot be named &apos;base&apos;.</source>
			<translation>A scenario cannot be named &apos;base&apos;.</translation>
		</message>
		<message>
			<source>Assign Team</source>
			<translation>Assign Team</translation>
		</message>
		<message>
			<source>A style already exists for the layer &apos;{0}&apos; in the selected style group.</source>
			<translation>Für die Ebene &apos;{0}&apos; existiert bereits ein Stil in der ausgewählten Stilgruppe.</translation>
		</message>
		<message>
			<source>Atlas ID must be an integer.</source>
			<translation>Atlas ID must be an integer.</translation>
		</message>
		<message>
			<source>Automatic language provisioning failed: {0}</source>
			<translation>Automatic language provisioning failed: {0}</translation>
		</message>
		<message>
			<source>Automatic language provisioning failed to start: {0}</source>
			<translation>Automatic language provisioning failed to start: {0}</translation>
		</message>
		<message>
			<source>Automatic language provisioning timed out after {0} seconds</source>
			<translation>Automatic language provisioning timed out after {0} seconds</translation>
		</message>
		<message>
			<source>&lt;b&gt;Key: &lt;/b&gt;{0}&lt;br&gt;&lt;b&gt;Key container: &lt;/b&gt;body/data/ &lt;br&gt;&lt;b&gt;Python file: &lt;/b&gt;{1} &lt;br&gt;&lt;b&gt;Python function:&lt;/b&gt; {2} &lt;br&gt;</source>
			<translation>&lt;b&gt;Key: &lt;/b&gt;{0}&lt;br&gt;&lt;b&gt;Key container: &lt;/b&gt;body/data/ &lt;br&gt;&lt;b&gt;Python file: &lt;/b&gt;{1} &lt;br&gt;&lt;b&gt;Python function:&lt;/b&gt; {2} &lt;br&gt;</translation>
		</message>
		<message>
			<source>Breakdown Assignation</source>
			<translation>Breakdown Assignation</translation>
		</message>
		<message>
			<source>Calculating values</source>
			<translation>Calculating values</translation>
		</message>
		<message>
			<source>Campaign</source>
			<translation>Campaign</translation>
		</message>
		<message>
			<source>Campaign ID not found.</source>
			<translation>Kampagnen-ID nicht gefunden.</translation>
		</message>
		<message>
			<source>Campaign saved successfully</source>
			<translation>Campaign saved successfully</translation>
		</message>
		<message>
			<source>Cancel</source>
			<translation>Cancel</translation>
		</message>
		<message>
			<source>Canceling task...</source>
			<translation>Canceling task...</translation>
		</message>
		<message>
			<source>Cancelled ({0}/{1})</source>
			<translation>Cancelled ({0}/{1})</translation>
		</message>
		<message>
			<source>Cancelling...</source>
			<translation>Cancelling...</translation>
		</message>
		<message>
			<source>Cancel mincut</source>
			<translation>Cancel mincut</translation>
		</message>
		<message>
			<source>Cancel mincuts</source>
			<translation>Minicuts abbrechen</translation>
		</message>
		<message>
			<source>Cannot calibrate {0} ({1}).</source>
			<translation>Cannot calibrate {0} ({1}).</translation>
		</message>
		<message>
			<source>Cannot create file, check if its open</source>
			<translation>Datei kann nicht erstellt werden, prüfen Sie, ob sie geöffnet ist</translation>
		</message>
		<message>
			<source>Cannot create file, check if selected composer is the correct composer</source>
			<translation>Datei kann nicht erstellt werden, prüfen Sie, ob der gewählte Komponist der richtige Komponist ist</translation>
		</message>
		<message>
			<source>Cannot create file, check if selected giswater_advancedtools is the correct giswater_advancedtools</source>
			<translation>Datei kann nicht erstellt werden, prüfen Sie, ob das ausgewählte giswater_advancedtools das richtige giswater_advancedtools ist</translation>
		</message>
		<message>
			<source>Cannot delete the current scenario. Please set another scenario as current first.</source>
			<translation>Cannot delete the current scenario. Please set another scenario as current first.</translation>
		</message>
		<message>
			<source>Cannot duplicate archived psector {0}. Please unarchive it first.</source>
			<translation>Cannot duplicate archived psector {0}. Please unarchive it first.</translation>
		</message>
		<message>
			<source>Cannot force connection to a node while arcs are selected.</source>
			<translation>Cannot force connection to a node while arcs are selected.</translation>
		</message>
		<message>
			<source>Cannot merge archived psector {0}. Please unarchive it first.</source>
			<translation>Cannot merge archived psector {0}. Please unarchive it first.</translation>
		</message>
		<message>
			<source>Cannot set inactive a current scenario. Please update current first.</source>
			<translation>Cannot set inactive a current scenario. Please update current first.</translation>
		</message>
		<message>
			<source>Cannot set the active state of archived psector {0}. Please unarchive it first.</source>
			<translation>Cannot set the active state of archived psector {0}. Please unarchive it first.</translation>
		</message>
		<message>
			<source>Cannot set the current {0} scenario of an inactive scenario. Please activate it first.</source>
			<translation>Das aktuelle {0} Szenario eines inaktiven Szenarios kann nicht eingestellt werden. Bitte aktivieren Sie es zuerst.</translation>
		</message>
		<message>
			<source>Cannot set the current netscenario of an inactive scenario. Please activate it first.</source>
			<translation>Das aktuelle Netzszenario eines inaktiven Szenarios kann nicht eingestellt werden. Bitte aktivieren Sie es zuerst.</translation>
		</message>
		<message>
			<source>Can&apos;t create curve with only one value if flow is 0. Add more values or change the flow value.</source>
			<translation>Es kann keine Kurve mit nur einem Wert erstellt werden, wenn der Fluss 0 ist. Fügen Sie weitere Werte hinzu oder ändern Sie den Flusswert.</translation>
		</message>
		<message>
			<source>Category name cannot be empty.</source>
			<translation>Der Kategoriename darf nicht leer sein.</translation>
		</message>
		<message>
			<source>Category updated successfully!</source>
			<translation>Kategorie erfolgreich aktualisiert!</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a dscenario will delete data from features related to the dscenario.
Are you sure you want to delete these records?</source>
			<translation>CAUTION! Deleting a dscenario will delete data from features related to the dscenario.
Are you sure you want to delete these records?</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a netscenario will delete data from features related to the netscenario.
Are you sure you want to delete these records?</source>
			<translation>CAUTION! Deleting a netscenario will delete data from features related to the netscenario.
Are you sure you want to delete these records?</translation>
		</message>
		<message>
			<source>Change epa_type</source>
			<translation>epa_type ändern</translation>
		</message>
		<message>
			<source>Change feature type</source>
			<translation>Change feature type</translation>
		</message>
		<message>
			<source>Changes applied to &quot;{0}&quot; successfully.</source>
			<translation>Changes applied to &quot;{0}&quot; successfully.</translation>
		</message>
		<message>
			<source>Changes on this page are dangerous and can break Giswater plugin in various ways. 
You will need to restart QGIS or reload Giswater plugin to apply changes. Do you want continue?</source>
			<translation>Changes on this page are dangerous and can break Giswater plugin in various ways. 
You will need to restart QGIS or reload Giswater plugin to apply changes. Do you want continue?</translation>
		</message>
		<message>
			<source>Changes saved.</source>
			<translation>Changes saved.</translation>
		</message>
		<message>
			<source>Change Team</source>
			<translation>Change Team</translation>
		</message>
		<message>
			<source>Check all</source>
			<translation>Check all</translation>
		</message>
		<message>
			<source>Check fields from table or view</source>
			<translation>Felder aus einer Tabelle oder Ansicht prüfen</translation>
		</message>
		<message>
			<source>Checking any item will not uncheck any other item.</source>
			<translation>Wenn Sie einen Punkt markieren, wird die Markierung eines anderen Punktes nicht aufgehoben.</translation>
		</message>
		<message>
			<source>Checking any item will uncheck all other items.</source>
			<translation>Wenn Sie einen Punkt ankreuzen, werden alle anderen Punkte abgehakt.</translation>
		</message>
		<message>
			<source>Checking any item will uncheck all other items unless Shift is pressed.</source>
			<translation>Wenn Sie ein Element markieren, werden alle anderen Elemente deaktiviert, es sei denn, Sie drücken die Umschalttaste.</translation>
		</message>
		<message>
			<source>Check project failed: no response from database function &apos;{0}&apos;.</source>
			<translation>Check project failed: no response from database function &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Choose dscenario</source>
			<translation>Szenario wählen</translation>
		</message>
		<message>
			<source>cibs schema does not exist. Create it first.</source>
			<translation>cibs schema does not exist. Create it first.</translation>
		</message>
		<message>
			<source>Cibs schema does not exist. Create it first.</source>
			<translation>Cibs schema does not exist. Create it first.</translation>
		</message>
		<message>
			<source>cibs schema is not supported for parent_type=&apos;{0}&apos; in this dbmodel. Missing schemas/addon/cibs/integration/{1}/integration.sql.</source>
			<translation>cibs schema is not supported for parent_type=&apos;{0}&apos; in this dbmodel. Missing schemas/addon/cibs/integration/{1}/integration.sql.</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it. </source>
			<translation>Durch Anklicken eines Eintrags wird dieser abgehakt bzw. nicht abgehakt.</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.
Checking any item will not uncheck any other item.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Clicking an item will check/uncheck it.
Checking any item will not uncheck any other item.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.
Checking any item will uncheck all other items.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Clicking an item will check/uncheck it.
Checking any item will uncheck all other items.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.
Checking any item will uncheck all other items unless Shift is pressed.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Clicking an item will check/uncheck it.
Checking any item will uncheck all other items unless Shift is pressed.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Clicking an item will check/uncheck it.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Click on 2 places on the map, creating a line, then set the location of a point</source>
			<translation>Klicken Sie auf 2 Stellen auf der Karte, so dass eine Linie entsteht, und legen Sie dann die Position eines Punktes fest</translation>
		</message>
		<message>
			<source>Click on a node to force the connection.</source>
			<translation>Click on a node to force the connection.</translation>
		</message>
		<message>
			<source>Click on arcs to select them. Use Alt+click to unselect selected arcs.</source>
			<translation>Klicken Sie auf Bögen, um sie auszuwählen. Verwenden Sie Alt+Klick, um ausgewählte Bögen wieder abzuwählen.</translation>
		</message>
		<message>
			<source>Click on disconnected node, move the pointer to the desired location on pipe to break it</source>
			<translation>Klicken Sie auf den unterbrochenen Knoten und bewegen Sie den Zeiger an die gewünschte Stelle der Leitung, um sie zu unterbrechen.</translation>
		</message>
		<message>
			<source>Click on feature or any place on the map and set radius of a circle</source>
			<translation>Klicken Sie auf ein Merkmal oder einen beliebigen Ort auf der Karte und legen Sie den Radius eines Kreises fest.</translation>
		</message>
		<message>
			<source>Click on feature to replace it with a new one. You can select other layer to snap a different feature type.</source>
			<translation>Click on feature to replace it with a new one. You can select other layer to snap a different feature type.</translation>
		</message>
		<message>
			<source>Click on node, that joins two pipes, in order to remove it and merge pipes</source>
			<translation>Klicken Sie auf den Knoten, der zwei Rohre miteinander verbindet, um ihn zu entfernen und die Rohre zusammenzuführen</translation>
		</message>
		<message>
			<source>Click on the object to change its class</source>
			<translation>Klicken Sie auf das Objekt, um seine Klasse zu ändern</translation>
		</message>
		<message>
			<source>Close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>cm schema is not supported for parent_type=&apos;{0}&apos; in this dbmodel. Missing schemas/addon/cm/integration/{1}/integration.sql.</source>
			<translation>cm schema is not supported for parent_type=&apos;{0}&apos; in this dbmodel. Missing schemas/addon/cm/integration/{1}/integration.sql.</translation>
		</message>
		<message>
			<source>Column name already exists.</source>
			<translation>Der Spaltenname existiert bereits.</translation>
		</message>
		<message>
			<source>Column name and Label fields are mandatory. Please set correct value.</source>
			<translation>Die Felder Spaltenname und Bezeichnung sind obligatorisch. Bitte geben Sie den richtigen Wert ein.</translation>
		</message>
		<message>
			<source>Column not found in table: {0}</source>
			<translation>Column not found in table: {0}</translation>
		</message>
		<message>
			<source>Completed with no exception and no result</source>
			<translation>Abgeschlossen ohne Ausnahme und ohne Ergebnis</translation>
		</message>
		<message>
			<source>Compliance Grade</source>
			<translation>Compliance Grade</translation>
		</message>
		<message>
			<source>Composer disabled: atlas coverage layer must be &apos;v_plan_psector&apos;.</source>
			<translation>Composer disabled: atlas coverage layer must be &apos;v_plan_psector&apos;.</translation>
		</message>
		<message>
			<source>Composer disabled: atlas must be enabled with coverage layer &apos;v_plan_psector&apos;.</source>
			<translation>Composer disabled: atlas must be enabled with coverage layer &apos;v_plan_psector&apos;.</translation>
		</message>
		<message>
			<source>Composer disabled: export failed, check layout configuration.</source>
			<translation>Composer disabled: export failed, check layout configuration.</translation>
		</message>
		<message>
			<source>Composer disabled: file is empty.</source>
			<translation>Composer disabled: file is empty.</translation>
		</message>
		<message>
			<source>Composer disabled: layout not found.</source>
			<translation>Composer disabled: layout not found.</translation>
		</message>
		<message>
			<source>Composer disabled: no layouts available.</source>
			<translation>Composer disabled: no layouts available.</translation>
		</message>
		<message>
			<source>Composer disabled: select a template.</source>
			<translation>Composer disabled: select a template.</translation>
		</message>
		<message>
			<source>Conduits couldn&apos;t be inserted!</source>
			<translation>Conduits couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Config</source>
			<translation>Config</translation>
		</message>
		<message>
			<source>Config database file not found</source>
			<translation>Config-Datenbankdatei nicht gefunden</translation>
		</message>
		<message>
			<source>Config file not found: {0}</source>
			<translation>Config file not found: {0}</translation>
		</message>
		<message>
			<source>Config file not found at</source>
			<translation>Config-Datei nicht gefunden unter</translation>
		</message>
		<message>
			<source>Config file not found at: {0}</source>
			<translation>Config file not found at: {0}</translation>
		</message>
		<message>
			<source>Configuration file couldn&apos;t be imported:
{0}</source>
			<translation>Configuration file couldn&apos;t be imported:
{0}</translation>
		</message>
		<message>
			<source>Configuration file not found, please make sure it is located in the correct directory and try again: {0}</source>
			<translation>Configuration file not found, please make sure it is located in the correct directory and try again: {0}</translation>
		</message>
		<message>
			<source>Configuration loaded successfully</source>
			<translation>Konfiguration erfolgreich geladen</translation>
		</message>
		<message>
			<source>Configuration saved to {0}</source>
			<translation>Konfiguration gespeichert auf {0}</translation>
		</message>
		<message>
			<source>Confirm</source>
			<translation>Confirm</translation>
		</message>
		<message>
			<source>Confirm Deletion</source>
			<translation>Bestätigen Sie die Löschung</translation>
		</message>
		<message>
			<source>Connec management</source>
			<translation>Connec management</translation>
		</message>
		<message>
			<source>Connecting...</source>
			<translation>Connecting...</translation>
		</message>
		<message>
			<source>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;</source>
			<translation>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;. Trying in &apos;{2}&apos;...</source>
			<translation>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;. Trying in &apos;{2}&apos;...</translation>
		</message>
		<message>
			<source>Connection failed. Please, check connection parameters</source>
			<translation>Connection failed. Please, check connection parameters</translation>
		</message>
		<message>
			<source>Connection Failed. Please, check connection parameters</source>
			<translation>Verbindung fehlgeschlagen. Bitte überprüfen Sie die Verbindungsparameter</translation>
		</message>
		<message>
			<source>Connection Failed. Please, check connection parameters ({0})</source>
			<translation>Connection Failed. Please, check connection parameters ({0})</translation>
		</message>
		<message>
			<source>Connect link</source>
			<translation>Connect link</translation>
		</message>
		<message>
			<source>Connect link task is already active!</source>
			<translation>Die Aufgabe Link verbinden ist bereits aktiv!</translation>
		</message>
		<message>
			<source>Connec to network</source>
			<translation>Connec to network</translation>
		</message>
		<message>
			<source>Connect to network</source>
			<translation>Connect to network</translation>
		</message>
		<message>
			<source>Context</source>
			<translation>Kontext</translation>
		</message>
		<message>
			<source>Contributors</source>
			<translation>Contributors</translation>
		</message>
		<message>
			<source>Converting to flwreg...</source>
			<translation>Converting to flwreg...</translation>
		</message>
		<message>
			<source>Copied to clipboard</source>
			<translation>Copied to clipboard</translation>
		</message>
		<message>
			<source>Copy project - {0}</source>
			<translation>Copy project - {0}</translation>
		</message>
		<message>
			<source>Cost (€)</source>
			<translation>Cost (€)</translation>
		</message>
		<message>
			<source>Could not delete language files ({0}): {1}</source>
			<translation>Could not delete language files ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not delete manifest.json: {0}</source>
			<translation>Could not delete manifest.json: {0}</translation>
		</message>
		<message>
			<source>Could not delete multilang translations ({0}): {1}</source>
			<translation>Could not delete multilang translations ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not determine event point coordinates</source>
			<translation>Could not determine event point coordinates</translation>
		</message>
		<message>
			<source>Could not download language files ({0}): {1}</source>
			<translation>Could not download language files ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not download language files in time. The project will continue to load.</source>
			<translation>Could not download language files in time. The project will continue to load.</translation>
		</message>
		<message>
			<source>Could not download language files. The project will continue to load. {0}</source>
			<translation>Could not download language files. The project will continue to load. {0}</translation>
		</message>
		<message>
			<source>Could not extract language files: Unknown error</source>
			<translation>Could not extract language files: Unknown error</translation>
		</message>
		<message>
			<source>Could not find an ID for the style group &apos;{0}&apos;.</source>
			<translation>Es konnte keine ID für die Stilgruppe &apos;{0}&apos; gefunden werden.</translation>
		</message>
		<message>
			<source>Could not find config_style ID for idval &apos;{0}&apos;.</source>
			<translation>Konnte keine config_style ID für idval &apos;{0}&apos; finden.</translation>
		</message>
		<message>
			<source>Could not find ID column &apos;{0}&apos;.</source>
			<translation>Could not find ID column &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Could not find the corresponding ID for the selected style {0}.</source>
			<translation>Die entsprechende ID für den ausgewählten Stil {0} konnte nicht gefunden werden.</translation>
		</message>
		<message>
			<source>Could not get feature ID from snapped point</source>
			<translation>Could not get feature ID from snapped point</translation>
		</message>
		<message>
			<source>Could not load EPA Results layers</source>
			<translation>Could not load EPA Results layers</translation>
		</message>
		<message>
			<source>Could not open database connection for multilang task.</source>
			<translation>Could not open database connection for multilang task.</translation>
		</message>
		<message>
			<source>Could not open URL: {0}</source>
			<translation>Could not open URL: {0}</translation>
		</message>
		<message>
			<source>Could not reach the translations server. Showing downloaded languages only.</source>
			<translation>Could not reach the translations server. Showing downloaded languages only.</translation>
		</message>
		<message>
			<source>could not remove: {0}</source>
			<translation>could not remove: {0}</translation>
		</message>
		<message>
			<source>Could not retrieve feature from layer</source>
			<translation>Could not retrieve feature from layer</translation>
		</message>
		<message>
			<source>Could not seed multilang translations ({0}): {1}</source>
			<translation>Could not seed multilang translations ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not update locale metadata</source>
			<translation>Could not update locale metadata</translation>
		</message>
		<message>
			<source>Could not write control {0} - skipping</source>
			<translation>Could not write control {0} - skipping</translation>
		</message>
		<message>
			<source>Couldn&apos;t add group.</source>
			<translation>Couldn&apos;t add group.</translation>
		</message>
		<message>
			<source>Couldn&apos;t draw profile. You may need to select another exploitation.</source>
			<translation>Das Profil konnte nicht gezeichnet werden. Möglicherweise müssen Sie eine andere Ausnutzung wählen.</translation>
		</message>
		<message>
			<source>Couldn&apos;t find layer to zoom to</source>
			<translation>Couldn&apos;t find layer to zoom to</translation>
		</message>
		<message>
			<source>Couldn&apos;t find node &apos;{0}&apos; for source &apos;{1}&apos;.</source>
			<translation>Couldn&apos;t find node &apos;{0}&apos; for source &apos;{1}&apos;.</translation>
		</message>
		<message>
			<source>Couldn&apos;t import swmm_api package. Try to reload the Giswater plugin. If the issue persists restart QGIS.</source>
			<translation>Das Paket swmm_api konnte nicht importiert werden. Versuchen Sie, das Giswater-Plugin neu zu laden. Wenn das Problem weiterhin besteht, starten Sie QGIS neu.</translation>
		</message>
		<message>
			<source>Create {0} schema</source>
			<translation>Schema {0} erstellen</translation>
		</message>
		<message>
			<source>Create am schema</source>
			<translation>Create am schema</translation>
		</message>
		<message>
			<source>Create am schema with sample data</source>
			<translation>Create am schema with sample data</translation>
		</message>
		<message>
			<source>Create base schema</source>
			<translation>Basisschema erstellen</translation>
		</message>
		<message>
			<source>Create catalogs</source>
			<translation>Create catalogs</translation>
		</message>
		<message>
			<source>Created</source>
			<translation>Created</translation>
		</message>
		<message>
			<source>Created locales database from seed</source>
			<translation>Created locales database from seed</translation>
		</message>
		<message>
			<source>Create example</source>
			<translation>Beispiel erstellen</translation>
		</message>
		<message>
			<source>Create field on &quot;{0}&quot;</source>
			<translation>Create field on &quot;{0}&quot;</translation>
		</message>
		<message>
			<source>Create multi field</source>
			<translation>Create multi field</translation>
		</message>
		<message>
			<source>Create multilang schema</source>
			<translation>Create multilang schema</translation>
		</message>
		<message>
			<source>Create Project - {0}</source>
			<translation>Create Project - {0}</translation>
		</message>
		<message>
			<source>Create schema of type &apos;{0}&apos;: &apos;{1}&apos;</source>
			<translation>Schema des Typs &apos;{0}&apos; erstellen: &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Creating demand dscenario...</source>
			<translation>Creating demand dscenario...</translation>
		</message>
		<message>
			<source>Creating GIS file... {0}</source>
			<translation>GIS-Datei erstellen... {0}</translation>
		</message>
		<message>
			<source>Creating new flwreg catalogs</source>
			<translation>Creating new flwreg catalogs</translation>
		</message>
		<message>
			<source>Creating new node catalogs</source>
			<translation>Creating new node catalogs</translation>
		</message>
		<message>
			<source>Creating new node catalogs...</source>
			<translation>Creating new node catalogs...</translation>
		</message>
		<message>
			<source>Creating new pipe catalogs</source>
			<translation>Creating new pipe catalogs</translation>
		</message>
		<message>
			<source>Creating new pipe catalogs...</source>
			<translation>Creating new pipe catalogs...</translation>
		</message>
		<message>
			<source>Creating new varc catalogs</source>
			<translation>Creating new varc catalogs</translation>
		</message>
		<message>
			<source>Creating new varc catalogs...</source>
			<translation>Creating new varc catalogs...</translation>
		</message>
		<message>
			<source>Creating parser for file: {0}</source>
			<translation>Parser für Datei erstellen: {0}</translation>
		</message>
		<message>
			<source>Creating quantized model...</source>
			<translation>Creating quantized model...</translation>
		</message>
		<message>
			<source>Creating user config folder</source>
			<translation>Benutzer-Konfigurationsordner erstellen</translation>
		</message>
		<message>
			<source>Creating user config folder: {0}</source>
			<translation>Benutzer-Konfigurationsordner erstellen: {0}</translation>
		</message>
		<message>
			<source>Creating workcat</source>
			<translation>Creating workcat</translation>
		</message>
		<message>
			<source>Creating workcat...</source>
			<translation>Creating workcat...</translation>
		</message>
		<message>
			<source>Creation type</source>
			<translation>Creation type</translation>
		</message>
		<message>
			<source>Credentials will be stored in the GIS project file as plain text, and will apply to both existing and future layers. Do you want to proceed?</source>
			<translation>Die Berechtigungsnachweise werden in der GIS-Projektdatei als reiner Text gespeichert und gelten sowohl für bestehende als auch für zukünftige Ebenen. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>CRITICAL ERROR in update_expl_sector_combos: {0}</source>
			<translation>CRITICAL ERROR in update_expl_sector_combos: {0}</translation>
		</message>
		<message>
			<source>CSV not generated. Check fields from table or view</source>
			<translation>CSV nicht erzeugt. Felder aus Tabelle oder Ansicht prüfen</translation>
		</message>
		<message>
			<source>Current feature has state &apos;{0}&apos;. Therefore it is not fusionable</source>
			<translation>Das aktuelle Merkmal hat den Status &apos;{0}&apos;. Daher ist es nicht fusionsfähig</translation>
		</message>
		<message>
			<source>Current feature has state &apos;{0}&apos;. Therefore it is not replaceable</source>
			<translation>Das aktuelle Merkmal hat den Status &apos;{0}&apos;. Daher ist es nicht ersetzbar</translation>
		</message>
		<message>
			<source>Current feature is planified. You should activate plan mode to work with it.</source>
			<translation>Die aktuelle Funktion ist planifiziert. Sie sollten den Planungsmodus aktivieren, um damit zu arbeiten.</translation>
		</message>
		<message>
			<source>Current network cost (€):</source>
			<translation>Current network cost (€):</translation>
		</message>
		<message>
			<source>Current node is not located over an arc. Please, select option &apos;DRAG-DROP&apos;</source>
			<translation>Der aktuelle Knoten befindet sich nicht über einem Bogen. Bitte wählen Sie die Option &apos;DRAG-DROP&apos;.</translation>
		</message>
		<message>
			<source>Current psector</source>
			<translation>Aktueller pSektor</translation>
		</message>
		<message>
			<source>Current Result</source>
			<translation>Current Result</translation>
		</message>
		<message>
			<source>Database connection error: {0}</source>
			<translation>Fehler bei der Datenbankverbindung: {0}</translation>
		</message>
		<message>
			<source>Database connection error ({0}): {1}</source>
			<translation>Database connection error ({0}): {1}</translation>
		</message>
		<message>
			<source>Database connection error. Please check your connection parameters.</source>
			<translation>Database connection error. Please check your connection parameters.</translation>
		</message>
		<message>
			<source>Database connection error (psycopg2). Please open plugin log file to get more details</source>
			<translation>Database connection error (psycopg2). Please open plugin log file to get more details</translation>
		</message>
		<message>
			<source>Database connection error (QSqlDatabase). Please open plugin log file to get more details</source>
			<translation>Database connection error (QSqlDatabase). Please open plugin log file to get more details</translation>
		</message>
		<message>
			<source>Database connection is not available</source>
			<translation>Database connection is not available</translation>
		</message>
		<message>
			<source>Database connection is not available.</source>
			<translation>Database connection is not available.</translation>
		</message>
		<message>
			<source>Database connection reset, please try again</source>
			<translation>Database connection reset, please try again</translation>
		</message>
		<message>
			<source>Database connection was closed and reconnected</source>
			<translation>Database connection was closed and reconnected</translation>
		</message>
		<message>
			<source>Database error</source>
			<translation>Database error</translation>
		</message>
		<message>
			<source>Database Error</source>
			<translation>Datenbank-Fehler</translation>
		</message>
		<message>
			<source>Database error importing simulation results: {0}</source>
			<translation>Database error importing simulation results: {0}</translation>
		</message>
		<message>
			<source>Database execution failed</source>
			<translation>Datenbankausführung fehlgeschlagen</translation>
		</message>
		<message>
			<source>Database name contains special characters that are not supported</source>
			<translation>Datenbankname enthält Sonderzeichen, die nicht unterstützt werden</translation>
		</message>
		<message>
			<source>Database returned null. Check postgres function &apos;{0}&apos;</source>
			<translation>Die Datenbank hat null zurückgegeben. Postgres-Funktion &apos;{0}&apos; prüfen</translation>
		</message>
		<message>
			<source>Database translation canceled.</source>
			<translation>Die Datenbankübersetzung wurde abgebrochen.</translation>
		</message>
		<message>
			<source>Database translation failed.</source>
			<translation>Datenbankübersetzung fehlgeschlagen.</translation>
		</message>
		<message>
			<source>Database translation successful to</source>
			<translation>Datenbankübersetzung erfolgreich nach</translation>
		</message>
		<message>
			<source>Data insertion completed: {0} successful, {1} errors.</source>
			<translation>Dateneinfügung abgeschlossen: {0} erfolgreich, {1} Fehler.</translation>
		</message>
		<message>
			<source>Data retrieved and displayed successfully.</source>
			<translation>Die Daten wurden erfolgreich abgerufen und angezeigt.</translation>
		</message>
		<message>
			<source>Date from:</source>
			<translation>Datum vom:</translation>
		</message>
		<message>
			<source>Date of creation</source>
			<translation>Datum der Erstellung</translation>
		</message>
		<message>
			<source>Date of last update</source>
			<translation>Datum der letzten Aktualisierung</translation>
		</message>
		<message>
			<source>Date to:</source>
			<translation>Datum bis:</translation>
		</message>
		<message>
			<source>DEBUG: {0}</source>
			<translation>DEBUG: {0}</translation>
		</message>
		<message>
			<source>DEBUG: catalog: {0}, arctype_id: {1}, material: {2}, pipe_dint: {3}</source>
			<translation>DEBUG: catalog: {0}, arctype_id: {1}, material: {2}, pipe_dint: {3}</translation>
		</message>
		<message>
			<source>DEBUG: OPTIONS:</source>
			<translation>DEBUG: OPTIONS:</translation>
		</message>
		<message>
			<source>Default Built Date</source>
			<translation>Default Built Date</translation>
		</message>
		<message>
			<source>Delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>Delete base</source>
			<translation>Delete base</translation>
		</message>
		<message>
			<source>Delete dscenario</source>
			<translation>Delete dscenario</translation>
		</message>
		<message>
			<source>Delete field on &quot;{0}&quot;</source>
			<translation>Delete field on &quot;{0}&quot;</translation>
		</message>
		<message>
			<source>Delete function</source>
			<translation>Delete function</translation>
		</message>
		<message>
			<source>Delete inflows</source>
			<translation>Delete inflows</translation>
		</message>
		<message>
			<source>Delete language files?</source>
			<translation>Delete language files?</translation>
		</message>
		<message>
			<source>Delete Lot(s)</source>
			<translation>Delete Lot(s)</translation>
		</message>
		<message>
			<source>Delete mincut</source>
			<translation>Minschnitt löschen</translation>
		</message>
		<message>
			<source>Delete multi field</source>
			<translation>Delete multi field</translation>
		</message>
		<message>
			<source>Delete multilang translations</source>
			<translation>Delete multilang translations</translation>
		</message>
		<message>
			<source>Delete multilang translations for ({0})</source>
			<translation>Delete multilang translations for ({0})</translation>
		</message>
		<message>
			<source>Delete multilang translations for ({0})?</source>
			<translation>Delete multilang translations for ({0})?</translation>
		</message>
		<message>
			<source>Delete records</source>
			<translation>Datensätze löschen</translation>
		</message>
		<message>
			<source>Delete schema failed: {0}</source>
			<translation>Delete schema failed: {0}</translation>
		</message>
		<message>
			<source>Delete Workorder(s)</source>
			<translation>Delete Workorder(s)</translation>
		</message>
		<message>
			<source>Deleting multilang translations for ({0})...</source>
			<translation>Deleting multilang translations for ({0})...</translation>
		</message>
		<message>
			<source>Demand</source>
			<translation>Demand</translation>
		</message>
		<message>
			<source>Description</source>
			<translation>Beschreibung</translation>
		</message>
		<message>
			<source>Detail</source>
			<translation>Einzelheiten</translation>
		</message>
		<message>
			<source>Diameter</source>
			<translation>Diameter</translation>
		</message>
		<message>
			<source>Disconnect elements</source>
			<translation>Trennen von Elementen</translation>
		</message>
		<message>
			<source>Dividers couldn&apos;t be inserted!</source>
			<translation>Dividers couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Document already exist</source>
			<translation>Dokument bereits vorhanden</translation>
		</message>
		<message>
			<source>Document already exists</source>
			<translation>Dokument existiert bereits</translation>
		</message>
		<message>
			<source>Document inserted successfully</source>
			<translation>Dokument erfolgreich eingefügt</translation>
		</message>
		<message>
			<source>Document name not found</source>
			<translation>Dokumentname nicht gefunden</translation>
		</message>
		<message>
			<source>Document PDF created in</source>
			<translation>Dokument PDF erstellt in</translation>
		</message>
		<message>
			<source>Documents deleted successfully</source>
			<translation>Dokumente erfolgreich gelöscht</translation>
		</message>
		<message>
			<source>done!</source>
			<translation>done!</translation>
		</message>
		<message>
			<source>DOWNGRADE NODE</source>
			<translation>DOWNGRADE NODE</translation>
		</message>
		<message>
			<source>Download cancelled or timed out</source>
			<translation>Download cancelled or timed out</translation>
		</message>
		<message>
			<source>Downloading language files for ({0})...</source>
			<translation>Downloading language files for ({0})...</translation>
		</message>
		<message>
			<source>Downloading OSM streetaxis. This can take a while...</source>
			<translation>Downloading OSM streetaxis. This can take a while...</translation>
		</message>
		<message>
			<source>Download language files?</source>
			<translation>Download language files?</translation>
		</message>
		<message>
			<source>Do you want to copy its values to the current node?</source>
			<translation>Möchten Sie seine Werte in den aktuellen Knoten kopieren?</translation>
		</message>
		<message>
			<source>Do you want to delete local language files for ({0})?</source>
			<translation>Do you want to delete local language files for ({0})?</translation>
		</message>
		<message>
			<source>Do you want to download local language files for ({0})?</source>
			<translation>Do you want to download local language files for ({0})?</translation>
		</message>
		<message>
			<source>Do you want to insert {0} selected features? (First 50: {1} ...)</source>
			<translation>Do you want to insert {0} selected features? (First 50: {1} ...)</translation>
		</message>
		<message>
			<source>Do you want to insert the selected features?
{0}</source>
			<translation>Do you want to insert the selected features?
{0}</translation>
		</message>
		<message>
			<source>Do you want to insert the selected features? {0}</source>
			<translation>Möchten Sie die ausgewählten Merkmale einfügen? {0}</translation>
		</message>
		<message>
			<source>Do you want to overwrite custom values?</source>
			<translation>Möchten Sie benutzerdefinierte Werte überschreiben?</translation>
		</message>
		<message>
			<source>Do you want to overwrite file?</source>
			<translation>Möchten Sie die Datei überschreiben?</translation>
		</message>
		<message>
			<source>Do you want to proceed?</source>
			<translation>Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>Do you want to save changes to dscenario &quot;{0}&quot;?
This operation cannot be undone.

(Please note that any changes made to node elevations cannot be saved to dscenarios.)</source>
			<translation>Do you want to save changes to dscenario &quot;{0}&quot;?
This operation cannot be undone.

(Please note that any changes made to node elevations cannot be saved to dscenarios.)</translation>
		</message>
		<message>
			<source>Do you want to seed multilang translations for ({0})?</source>
			<translation>Do you want to seed multilang translations for ({0})?</translation>
		</message>
		<message>
			<source>Do you want to set this psector as current?</source>
			<translation>Möchten Sie diesen Sektor als aktuell festlegen?</translation>
		</message>
		<message>
			<source>Do you want to update local language files for ({0})?</source>
			<translation>Do you want to update local language files for ({0})?</translation>
		</message>
		<message>
			<source>Do you want to update multilang translations for ({0})?</source>
			<translation>Do you want to update multilang translations for ({0})?</translation>
		</message>
		<message>
			<source>Do you want to update the symbology of the layers currently loaded in the project?</source>
			<translation>Do you want to update the symbology of the layers currently loaded in the project?</translation>
		</message>
		<message>
			<source>Draw Profile</source>
			<translation>Draw Profile</translation>
		</message>
		<message>
			<source>Dscenario manager</source>
			<translation>Dszenario-Manager</translation>
		</message>
		<message>
			<source>Duplicate</source>
			<translation>Duplicate</translation>
		</message>
		<message>
			<source>Duplicate user and campaign pairs are not allowed. Remove duplicates before saving.</source>
			<translation>Duplicate user and campaign pairs are not allowed. Remove duplicates before saving.</translation>
		</message>
		<message>
			<source>DWF &amp; INFLOWS</source>
			<translation>DWF &amp; INFLOWS</translation>
		</message>
		<message>
			<source>DWF scenario manager</source>
			<translation>DWF-Szenario-Manager</translation>
		</message>
		<message>
			<source>Edit base</source>
			<translation>Edit base</translation>
		</message>
		<message>
			<source>Edit dscenario</source>
			<translation>Edit dscenario</translation>
		</message>
		<message>
			<source>Edit inflows</source>
			<translation>Edit inflows</translation>
		</message>
		<message>
			<source>Empty coordinate list</source>
			<translation>Leere Koordinatenliste</translation>
		</message>
		<message>
			<source>Empty response</source>
			<translation>Empty response</translation>
		</message>
		<message>
			<source>Empty response from database function.</source>
			<translation>Empty response from database function.</translation>
		</message>
		<message>
			<source>English locale not found</source>
			<translation>English locale not found</translation>
		</message>
		<message>
			<source>Epa2data execution failed. See logs for more details...</source>
			<translation>Die Ausführung von Epa2data ist fehlgeschlagen. Siehe Protokolle für weitere Details...</translation>
		</message>
		<message>
			<source>EPA model finished.</source>
			<translation>EPA model finished.</translation>
		</message>
		<message>
			<source>EPA model finished. </source>
			<translation>EPA-Modell abgeschlossen.</translation>
		</message>
		<message>
			<source>EPA Result Families exported successfully:
{0}</source>
			<translation>EPA Result Families exported successfully:
{0}</translation>
		</message>
		<message>
			<source>EPA type</source>
			<translation>EPA type</translation>
		</message>
		<message>
			<source>Epa type is not defined for element {0}</source>
			<translation>Epa type is not defined for element {0}</translation>
		</message>
		<message>
			<source>Error</source>
			<translation>Fehler</translation>
		</message>
		<message>
			<source>ERROR -&gt; {0}</source>
			<translation>ERROR -&gt; {0}</translation>
		</message>
		<message>
			<source>Error: &apos;{0}&apos; or &apos;{1}&apos; field is missing in the result.</source>
			<translation>Fehler: Das Feld &apos;{0}&apos; oder &apos;{1}&apos; fehlt im Ergebnis.</translation>
		</message>
		<message>
			<source>Error assigning team: {0}</source>
			<translation>Error assigning team: {0}</translation>
		</message>
		<message>
			<source>Error canceling mincut task: {0}</source>
			<translation>Error canceling mincut task: {0}</translation>
		</message>
		<message>
			<source>Error changing team: {0}</source>
			<translation>Error changing team: {0}</translation>
		</message>
		<message>
			<source>Error closing mincut cursor: {0}</source>
			<translation>Error closing mincut cursor: {0}</translation>
		</message>
		<message>
			<source>Error connecting to database (layer)</source>
			<translation>Error connecting to database (layer)</translation>
		</message>
		<message>
			<source>Error connecting to database (settings)</source>
			<translation>Error connecting to database (settings)</translation>
		</message>
		<message>
			<source>Error creating auxiliary connection for vacuum</source>
			<translation>Fehler beim Herstellen des Hilfsanschlusses für das Vakuum</translation>
		</message>
		<message>
			<source>Error creating dynamic dialog: {0}</source>
			<translation>Error creating dynamic dialog: {0}</translation>
		</message>
		<message>
			<source>Error creating mincut cursor: {0}</source>
			<translation>Error creating mincut cursor: {0}</translation>
		</message>
		<message>
			<source>Error creating or updating team</source>
			<translation>Error creating or updating team</translation>
		</message>
		<message>
			<source>Error creating Workcat.</source>
			<translation>Fehler beim Erstellen von Workcat.</translation>
		</message>
		<message>
			<source>Error. Database returned null. Check postgres function &apos;{0}&apos;</source>
			<translation>Fehler. Datenbank gab null zurück. Postgres-Funktion &apos;{0}&apos; prüfen</translation>
		</message>
		<message>
			<source>Error deleting data</source>
			<translation>Error deleting data</translation>
		</message>
		<message>
			<source>Error deleting records</source>
			<translation>Fehler beim Löschen von Datensätzen</translation>
		</message>
		<message>
			<source>ERROR: DIVIDER &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: DIVIDER &apos;{0}&apos; has no coordinates in [COORDINATES] section.</translation>
		</message>
		<message>
			<source>Error during point selection: {0}</source>
			<translation>Error during point selection: {0}</translation>
		</message>
		<message>
			<source>Error executing {0} - {1}</source>
			<translation>Error executing {0} - {1}</translation>
		</message>
		<message>
			<source>Error executing EPA software: {0}</source>
			<translation>Error executing EPA software: {0}</translation>
		</message>
		<message>
			<source>Error executing gw_fct_create_dscenario_empty</source>
			<translation>Fehler bei der Ausführung von gw_fct_create_dscenario_empty</translation>
		</message>
		<message>
			<source>Error executing gw_fct_import_swmm_flwreg - {0}</source>
			<translation>Error executing gw_fct_import_swmm_flwreg - {0}</translation>
		</message>
		<message>
			<source>Error executing setmincut with cursor: {0}</source>
			<translation>Error executing setmincut with cursor: {0}</translation>
		</message>
		<message>
			<source>Error executing vacuum: {0}</source>
			<translation>Fehler beim Ausführen des Vakuums: {0}</translation>
		</message>
		<message>
			<source>Error fusing arcs</source>
			<translation>Error fusing arcs</translation>
		</message>
		<message>
			<source>Error getting current psector</source>
			<translation>Fehler beim Abrufen des aktuellen Psektors</translation>
		</message>
		<message>
			<source>Error getting database parameters</source>
			<translation>Fehler beim Abrufen von Datenbankparametern</translation>
		</message>
		<message>
			<source>Error getting default connection (settings)</source>
			<translation>Error getting default connection (settings)</translation>
		</message>
		<message>
			<source>Error getting exploitation</source>
			<translation>Fehler bei der Ausbeutung</translation>
		</message>
		<message>
			<source>Error getting locale from schema: {0}</source>
			<translation>Error getting locale from schema: {0}</translation>
		</message>
		<message>
			<source>Error getting source symbol: {0}</source>
			<translation>Error getting source symbol: {0}</translation>
		</message>
		<message>
			<source>Error getting UI language locale: {0}</source>
			<translation>Error getting UI language locale: {0}</translation>
		</message>
		<message>
			<source>Error importing IBERGIS project</source>
			<translation>Fehler beim Importieren des IBERGIS-Projekts</translation>
		</message>
		<message>
			<source>Error importing simulation results: {0}</source>
			<translation>Error importing simulation results: {0}</translation>
		</message>
		<message>
			<source>Error importing simulation results into database</source>
			<translation>Error importing simulation results into database</translation>
		</message>
		<message>
			<source>Error importing simulation results into database: {0}</source>
			<translation>Error importing simulation results into database: {0}</translation>
		</message>
		<message>
			<source>Error in _manage_selection_changed: {0}</source>
			<translation>Error in _manage_selection_changed: {0}</translation>
		</message>
		<message>
			<source>Error in remove function: {0}</source>
			<translation>Error in remove function: {0}</translation>
		</message>
		<message>
			<source>ERROR: JUNCTION &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: JUNCTION &apos;{0}&apos; has no coordinates in [COORDINATES] section.</translation>
		</message>
		<message>
			<source>Error logging</source>
			<translation>Error logging</translation>
		</message>
		<message>
			<source>Error near line</source>
			<translation>Fehler bei Zeile</translation>
		</message>
		<message>
			<source>Error near line {0} -&gt; {1}</source>
			<translation>Fehler bei Zeile {0} -&gt; {1}</translation>
		</message>
		<message>
			<source>Error on create auto mincut, you need to review data</source>
			<translation>Fehler bei der Erstellung des automatischen Mindestschnitts, Sie müssen die Daten überprüfen</translation>
		</message>
		<message>
			<source>ERROR: OUTFALL &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: OUTFALL &apos;{0}&apos; has no coordinates in [COORDINATES] section.</translation>
		</message>
		<message>
			<source>Error parsing file: {0}</source>
			<translation>Fehler beim Parsen der Datei: {0}</translation>
		</message>
		<message>
			<source>Error processing OSM import: {0}</source>
			<translation>Error processing OSM import: {0}</translation>
		</message>
		<message>
			<source>ERROR: RAINGAGE &apos;{0}&apos; has no coordinates in [SYMBOLS] section.</source>
			<translation>ERROR: RAINGAGE &apos;{0}&apos; has no coordinates in [SYMBOLS] section.</translation>
		</message>
		<message>
			<source>Error reading configuration file: {0}</source>
			<translation>Fehler beim Lesen der Konfigurationsdatei: {0}</translation>
		</message>
		<message>
			<source>Error removing items: {0}</source>
			<translation>Error removing items: {0}</translation>
		</message>
		<message>
			<source>Error removing team assignment: {0}</source>
			<translation>Error removing team assignment: {0}</translation>
		</message>
		<message>
			<source>Error replacing feature</source>
			<translation>Funktion zum Ersetzen von Fehlern</translation>
		</message>
		<message>
			<source>Error replacing feature. Chose a valid catalog.</source>
			<translation>Funktion zum Ersetzen von Fehlern. Wählen Sie einen gültigen Katalog aus.</translation>
		</message>
		<message>
			<source>Error saving lot</source>
			<translation>Error saving lot</translation>
		</message>
		<message>
			<source>Error saving the configuration</source>
			<translation>Fehler beim Speichern der Konfiguration</translation>
		</message>
		<message>
			<source>Error setting node</source>
			<translation>Error setting node</translation>
		</message>
		<message>
			<source>ERROR: STORAGE &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: STORAGE &apos;{0}&apos; has no coordinates in [COORDINATES] section.</translation>
		</message>
		<message>
			<source>Error toggling state: {0}</source>
			<translation>Error toggling state: {0}</translation>
		</message>
		<message>
			<source>Error type</source>
			<translation>Fehlerart</translation>
		</message>
		<message>
			<source>Error updating element in table, you need to review data</source>
			<translation>Fehler beim Aktualisieren des Elements in der Tabelle, Sie müssen die Daten überprüfen</translation>
		</message>
		<message>
			<source>Error updating table</source>
			<translation>Fehler beim Aktualisieren der Tabelle</translation>
		</message>
		<message>
			<source>EXCEPTION</source>
			<translation>AUSNAHME</translation>
		</message>
		<message>
			<source>Exception: {0}</source>
			<translation>Exception: {0}</translation>
		</message>
		<message>
			<source>Exception: {0}.</source>
			<translation>Ausnahme: {0}.</translation>
		</message>
		<message>
			<source>EXCEPTION -&gt; {0}</source>
			<translation>EXCEPTION -&gt; {0}</translation>
		</message>
		<message>
			<source>EXCEPTION: {0}, {1}</source>
			<translation>AUSNAHME: {0}, {1}</translation>
		</message>
		<message>
			<source>Exception error: {0}</source>
			<translation>Ausnahmefehler: {0}</translation>
		</message>
		<message>
			<source>Exception in {0}</source>
			<translation>Ausnahme in {0}</translation>
		</message>
		<message>
			<source>Exception in {0} (executing {1} from {2}): {3}</source>
			<translation>Ausnahme in {0} (Ausführung von {1} aus {2}): {3}</translation>
		</message>
		<message>
			<source>Exception in info</source>
			<translation>Ausnahme in Info</translation>
		</message>
		<message>
			<source>Exception in info (def _get_id)</source>
			<translation>Ausnahme in info (def _get_id)</translation>
		</message>
		<message>
			<source>Exception in resync_map_after_db_reconnect: {0}</source>
			<translation>Exception in resync_map_after_db_reconnect: {0}</translation>
		</message>
		<message>
			<source>Exception in unload when {0}</source>
			<translation>Ausnahme beim Entladen, wenn {0}</translation>
		</message>
		<message>
			<source>Exception in unload when deleting {0}</source>
			<translation>Ausnahme beim Entladen beim Löschen von {0}</translation>
		</message>
		<message>
			<source>Exception in unload when disconnecting {0} signal</source>
			<translation>Ausnahme beim Entladen beim Trennen des {0}-Signals</translation>
		</message>
		<message>
			<source>Exception in unload when reset values for {0}</source>
			<translation>Ausnahme beim Entladen, wenn Werte für {0} zurückgesetzt werden</translation>
		</message>
		<message>
			<source>Exception in unload when unset signals</source>
			<translation>Ausnahme beim Entladen, wenn Signale nicht gesetzt werden</translation>
		</message>
		<message>
			<source>Exception message not shown to user</source>
			<translation>Exception message not shown to user</translation>
		</message>
		<message>
			<source>Exception when replacing inp strings</source>
			<translation>Ausnahme beim Ersetzen von inp-Strings</translation>
		</message>
		<message>
			<source>Exception while moving/deleting old user config files</source>
			<translation>Ausnahme beim Verschieben/Löschen von alten Benutzer-Konfigurationsdateien</translation>
		</message>
		<message>
			<source>Exec. time: {0}</source>
			<translation>Exec. time: {0}</translation>
		</message>
		<message>
			<source>Execute EPA software</source>
			<translation>Ausführen der EPA-Software</translation>
		</message>
		<message>
			<source>Execute EPA software......</source>
			<translation>Execute EPA software......</translation>
		</message>
		<message>
			<source>Execute EPA software......

</source>
			<translation>Execute EPA software......</translation>
		</message>
		<message>
			<source>Execute failed.</source>
			<translation>Ausführen fehlgeschlagen.</translation>
		</message>
		<message>
			<source>Executing calibration &quot;{0}&quot; ({1}/{2})...</source>
			<translation>Executing calibration &quot;{0}&quot; ({1}/{2})...</translation>
		</message>
		<message>
			<source>Executing vacuum</source>
			<translation>Ausführendes Vakuum</translation>
		</message>
		<message>
			<source>EXECUTION FAILED! Check logs for more information</source>
			<translation>EXECUTION FAILED! Check logs for more information</translation>
		</message>
		<message>
			<source>Execution of {0} failed.</source>
			<translation>Die Ausführung von {0} ist fehlgeschlagen.</translation>
		</message>
		<message>
			<source>Export done succesfully</source>
			<translation>Erfolgreich exportiert</translation>
		</message>
		<message>
			<source>Export INP file into PostgreSQL</source>
			<translation>INP-Datei in PostgreSQL exportieren</translation>
		</message>
		<message>
			<source>Export INP finished. </source>
			<translation>INP exportieren beendet.</translation>
		</message>
		<message>
			<source>Expression Error</source>
			<translation>Ausdrucksfehler</translation>
		</message>
		<message>
			<source>Extension</source>
			<translation>Extension</translation>
		</message>
		<message>
			<source>FAIL {0}</source>
			<translation>FAIL {0}</translation>
		</message>
		<message>
			<source>Failed to add feature</source>
			<translation>Funktion kann nicht hinzugefügt werden</translation>
		</message>
		<message>
			<source>Failed to configure layer &apos;{0}&apos;. Skipping...</source>
			<translation>Konfiguration der Ebene &apos;{0}&apos; fehlgeschlagen. Überspringen...</translation>
		</message>
		<message>
			<source>Failed to create child campaign</source>
			<translation>Failed to create child campaign</translation>
		</message>
		<message>
			<source>Failed to create layout from template</source>
			<translation>Failed to create layout from template</translation>
		</message>
		<message>
			<source>Failed to delete multilang rows for removed project types.</source>
			<translation>Failed to delete multilang rows for removed project types.</translation>
		</message>
		<message>
			<source>Failed to delete records from {0}.</source>
			<translation>Datensätze aus {0} konnten nicht gelöscht werden.</translation>
		</message>
		<message>
			<source>Failed to delete style group</source>
			<translation>Stilgruppe konnte nicht gelöscht werden</translation>
		</message>
		<message>
			<source>Failed to delete styles</source>
			<translation>Stile können nicht gelöscht werden</translation>
		</message>
		<message>
			<source>Failed to drop database user &apos;{0}&apos;. It may need to be removed manually.</source>
			<translation>Der Datenbankbenutzer &apos;{0}&apos; konnte nicht gelöscht werden. Er muss möglicherweise manuell entfernt werden.</translation>
		</message>
		<message>
			<source>Failed to execute the mapzones analysis.</source>
			<translation>Die Mapzones-Analyse konnte nicht ausgeführt werden.</translation>
		</message>
		<message>
			<source>Failed to fetch dialog configuration</source>
			<translation>Dialogkonfiguration konnte nicht abgerufen werden</translation>
		</message>
		<message>
			<source>Failed to get a valid response from gw_fct_config_mapzones.</source>
			<translation>Es konnte keine gültige Antwort von gw_fct_config_mapzones erhalten werden.</translation>
		</message>
		<message>
			<source>Failed to load campaign form</source>
			<translation>Failed to load campaign form</translation>
		</message>
		<message>
			<source>Failed to load layers</source>
			<translation>Ebenen konnten nicht geladen werden</translation>
		</message>
		<message>
			<source>Failed to load layers.</source>
			<translation>Ebenen konnten nicht geladen werden.</translation>
		</message>
		<message>
			<source>Failed to load lot form</source>
			<translation>Failed to load lot form</translation>
		</message>
		<message>
			<source>Failed to load profile interpolation dialog.</source>
			<translation>Failed to load profile interpolation dialog.</translation>
		</message>
		<message>
			<source>Failed to load scada graph dialog.</source>
			<translation>Failed to load scada graph dialog.</translation>
		</message>
		<message>
			<source>Failed to load team creation dialog configuration. Please check database configuration.</source>
			<translation>Failed to load team creation dialog configuration. Please check database configuration.</translation>
		</message>
		<message>
			<source>Failed to load workorder form</source>
			<translation>Failed to load workorder form</translation>
		</message>
		<message>
			<source>Failed to parse JSON result from database.</source>
			<translation>Failed to parse JSON result from database.</translation>
		</message>
		<message>
			<source>Failed to retrieve GeoJSON data.</source>
			<translation>Abruf von GeoJSON-Daten fehlgeschlagen.</translation>
		</message>
		<message>
			<source>Failed to retrieve sector features.</source>
			<translation>Sektormerkmale konnten nicht abgerufen werden.</translation>
		</message>
		<message>
			<source>Failed to retrieve the temporal layer</source>
			<translation>Abruf der temporalen Ebene fehlgeschlagen</translation>
		</message>
		<message>
			<source>Failed to save campaign</source>
			<translation>Failed to save campaign</translation>
		</message>
		<message>
			<source>Failed to set {0} scenario</source>
			<translation>Szenario {0} konnte nicht eingestellt werden</translation>
		</message>
		<message>
			<source>Failed to set netscenario</source>
			<translation>Netszenario konnte nicht eingestellt werden</translation>
		</message>
		<message>
			<source>Failed to set psector {0} as current</source>
			<translation>Failed to set psector {0} as current</translation>
		</message>
		<message>
			<source>Failed to set ValueRelation for field &apos;{0}&apos;: {1}</source>
			<translation>Failed to set ValueRelation for field &apos;{0}&apos;: {1}</translation>
		</message>
		<message>
			<source>Failed to update category</source>
			<translation>Kategorie kann nicht aktualisiert werden</translation>
		</message>
		<message>
			<source>Failed to update mapzone config.</source>
			<translation>Failed to update mapzone config.</translation>
		</message>
		<message>
			<source>Failed to update styles</source>
			<translation>Aktualisierung der Stile fehlgeschlagen</translation>
		</message>
		<message>
			<source>Failed to write export file:
{0}</source>
			<translation>Failed to write export file:
{0}</translation>
		</message>
		<message>
			<source>Feature added successfully!</source>
			<translation>Funktion erfolgreich hinzugefügt!</translation>
		</message>
		<message>
			<source>Feature already in the list</source>
			<translation>Bereits in der Liste enthaltenes Merkmal</translation>
		</message>
		<message>
			<source>Feature class not found: {0}</source>
			<translation>Feature class not found: {0}</translation>
		</message>
		<message>
			<source>Feature has not been updated because no catalog has been selected</source>
			<translation>Das Merkmal wurde nicht aktualisiert, da kein Katalog ausgewählt wurde.</translation>
		</message>
		<message>
			<source>Feature ID and Idval cannot be empty.</source>
			<translation>Feature ID und Idval dürfen nicht leer sein.</translation>
		</message>
		<message>
			<source>Feature_id is mandatory.</source>
			<translation>Feature_id ist obligatorisch.</translation>
		</message>
		<message>
			<source>Feature not upserted</source>
			<translation>Feature not upserted</translation>
		</message>
		<message>
			<source>Feature replaced successfully</source>
			<translation>Merkmal erfolgreich ersetzt</translation>
		</message>
		<message>
			<source>Feature upserted</source>
			<translation>Feature upserted</translation>
		</message>
		<message>
			<source>Field catalog_id required!</source>
			<translation>Feld catalog_id erforderlich!</translation>
		</message>
		<message>
			<source>Field child_layer of id: </source>
			<translation>Feld child_layer von id:</translation>
		</message>
		<message>
			<source>Field child_layer of id: {0} is not defined in table cat_feature</source>
			<translation>Field child_layer of id: {0} is not defined in table cat_feature</translation>
		</message>
		<message>
			<source>Field configured in &apos;config_form_fields&apos;</source>
			<translation>Field configured in &apos;config_form_fields&apos;</translation>
		</message>
		<message>
			<source>Field update in &apos;config_form_fields&apos;</source>
			<translation>Field update in &apos;config_form_fields&apos;</translation>
		</message>
		<message>
			<source>File cannot be created. Check if it is already opened</source>
			<translation>Datei kann nicht erstellt werden. Prüfen Sie, ob sie bereits geöffnet ist</translation>
		</message>
		<message>
			<source>File extension not valid</source>
			<translation>Dateierweiterung nicht gültig</translation>
		</message>
		<message>
			<source>File INP not found</source>
			<translation>Datei INP nicht gefunden</translation>
		</message>
		<message>
			<source>File name</source>
			<translation>Name der Datei</translation>
		</message>
		<message>
			<source>File name is required</source>
			<translation>Dateiname ist erforderlich</translation>
		</message>
		<message>
			<source>File not found</source>
			<translation>Datei nicht gefunden</translation>
		</message>
		<message>
			<source>File not found: {0}</source>
			<translation>Datei nicht gefunden: {0}</translation>
		</message>
		<message>
			<source>File path doesn&apos;t exist or you dont have permission or file is opened</source>
			<translation>Der Dateipfad existiert nicht oder Sie haben keine Berechtigung oder die Datei ist geöffnet</translation>
		</message>
		<message>
			<source>File path not found</source>
			<translation>Dateipfad nicht gefunden</translation>
		</message>
		<message>
			<source>File RPT not found</source>
			<translation>Datei RPT nicht gefunden</translation>
		</message>
		<message>
			<source>Files defined in environment variables &apos;{0}&apos; and &apos;{1}&apos; not found.</source>
			<translation>Files defined in environment variables &apos;{0}&apos; and &apos;{1}&apos; not found.</translation>
		</message>
		<message>
			<source>File Transfer</source>
			<translation>File Transfer</translation>
		</message>
		<message>
			<source>File type</source>
			<translation>File type</translation>
		</message>
		<message>
			<source>Fill table</source>
			<translation>Fill table</translation>
		</message>
		<message>
			<source>Filter</source>
			<translation>Filter</translation>
		</message>
		<message>
			<source>Filter by code</source>
			<translation>Nach Code filtern</translation>
		</message>
		<message>
			<source>Filter by ext_code</source>
			<translation>Filter nach ext_code</translation>
		</message>
		<message>
			<source>Finished %</source>
			<translation>Finished %</translation>
		</message>
		<message>
			<source>Finished!</source>
			<translation>Finished!</translation>
		</message>
		<message>
			<source>First node already selected with id: {0}. Select second one.</source>
			<translation>Erster Knoten bereits ausgewählt mit id: {0}. Zweiten Knoten auswählen.</translation>
		</message>
		<message>
			<source>Flood analysis will start from arc ID</source>
			<translation>Flood analysis will start from arc ID</translation>
		</message>
		<message>
			<source>Flood analysis will start from node ID</source>
			<translation>Die Hochwasseranalyse beginnt mit der Knoten-ID</translation>
		</message>
		<message>
			<source>Flow regulators</source>
			<translation>Flow regulators</translation>
		</message>
		<message>
			<source>Folder not found</source>
			<translation>Ordner nicht gefunden</translation>
		</message>
		<message>
			<source>Folder path</source>
			<translation>Pfad des Ordners</translation>
		</message>
		<message>
			<source>Force commit</source>
			<translation>Commit erzwingen</translation>
		</message>
		<message>
			<source>For mode &apos;{0}&apos;, an result_id must be informed.</source>
			<translation>For mode &apos;{0}&apos;, an result_id must be informed.</translation>
		</message>
		<message>
			<source>For select on canvas is mandatory to load v_asset_arc_input layer</source>
			<translation>For select on canvas is mandatory to load v_asset_arc_input layer</translation>
		</message>
		<message>
			<source>Function {0} error: {1} from last function is invalid</source>
			<translation>Funktion {0} Fehler: {1} der letzten Funktion ist ungültig</translation>
		</message>
		<message>
			<source>Function {0} error: {1} returned null</source>
			<translation>Funktion {0} Fehler: {1} gab null zurück</translation>
		</message>
		<message>
			<source>Function {0} error: missing key {1}</source>
			<translation>Funktion {0} Fehler: fehlender Schlüssel {1}</translation>
		</message>
		<message>
			<source>Function {0} failed</source>
			<translation>Funktion {0} fehlgeschlagen</translation>
		</message>
		<message>
			<source>Function {0} finished successfully</source>
			<translation>Funktion {0} erfolgreich beendet</translation>
		</message>
		<message>
			<source>Function {0} returned {1}</source>
			<translation>Funktion {0} gab {1} zurück</translation>
		</message>
		<message>
			<source>Function error: {0}</source>
			<translation>Funktionsfehler: {0}</translation>
		</message>
		<message>
			<source>Function error: gw_fct_setmincut</source>
			<translation>Function error: gw_fct_setmincut</translation>
		</message>
		<message>
			<source>Function failed finished</source>
			<translation>Funktion fehlgeschlagen beendet</translation>
		</message>
		<message>
			<source>Function gw_fct_create_dscenario_empty returned no dscenario_id</source>
			<translation>Die Funktion gw_fct_create_dscenario_empty gab keine dscenario_id zurück</translation>
		</message>
		<message>
			<source>Function gw_fct_psector_duplicate executed with no result</source>
			<translation>Function gw_fct_psector_duplicate executed with no result</translation>
		</message>
		<message>
			<source>Function gw_fct_setfeaturedelete executed with no result </source>
			<translation>Funktion gw_fct_setfeaturedelete ohne Ergebnis ausgeführt</translation>
		</message>
		<message>
			<source>Function name</source>
			<translation>Name der Funktion</translation>
		</message>
		<message>
			<source>Function not found</source>
			<translation>Funktion nicht gefunden</translation>
		</message>
		<message>
			<source>Function not found in database</source>
			<translation>Funktion nicht in der Datenbank gefunden</translation>
		</message>
		<message>
			<source>Function not found in database: {0}</source>
			<translation>Funktion nicht in der Datenbank gefunden: {0}</translation>
		</message>
		<message>
			<source>Generate INP algorithm</source>
			<translation>Generate INP algorithm</translation>
		</message>
		<message>
			<source>Generating markdown for {0}.</source>
			<translation>Generierung von Markdown für {0}.</translation>
		</message>
		<message>
			<source>Generating markdown from {0}...</source>
			<translation>Erzeugen von Markdown aus {0}...</translation>
		</message>
		<message>
			<source>Generating result stats</source>
			<translation>Generating result stats</translation>
		</message>
		<message>
			<source>Generation of atlas uses ve_plan_psector as coverage layer ordered by atlas_id column. Please update the atlas&apos; coverage layer before continuing.</source>
			<translation>Bei der Erstellung des Atlasses wird ve_plan_psector als Abdeckungsebene verwendet, die nach der Spalte atlas_id geordnet ist. Bitte aktualisieren Sie die Abdeckungsebene des Atlasses, bevor Sie fortfahren.</translation>
		</message>
		<message>
			<source>Geometry has been added!</source>
			<translation>Die Geometrie wurde hinzugefügt!</translation>
		</message>
		<message>
			<source>Geometry set correctly.</source>
			<translation>Die Geometrie ist korrekt eingestellt.</translation>
		</message>
		<message>
			<source>Geometry type ({0}) not found in layer: {1}</source>
			<translation>Geometry type ({0}) not found in layer: {1}</translation>
		</message>
		<message>
			<source>Getting {0} from .{1} file</source>
			<translation>Getting {0} from .{1} file</translation>
		</message>
		<message>
			<source>Getting auxiliary data from DB</source>
			<translation>Getting auxiliary data from DB</translation>
		</message>
		<message>
			<source>Getting options</source>
			<translation>Getting options</translation>
		</message>
		<message>
			<source>Getting pipe data from DB</source>
			<translation>Getting pipe data from DB</translation>
		</message>
		<message>
			<source>Getting units...</source>
			<translation>Getting units...</translation>
		</message>
		<message>
			<source>GIS file generated successfully</source>
			<translation>GIS-Datei erfolgreich erstellt</translation>
		</message>
		<message>
			<source>GIS file name not set</source>
			<translation>GIS-Dateiname nicht gesetzt</translation>
		</message>
		<message>
			<source>GIS folder not set</source>
			<translation>GIS-Ordner nicht eingestellt</translation>
		</message>
		<message>
			<source>Giswater ({0})</source>
			<translation>Giswater ({0})</translation>
		</message>
		<message>
			<source>Giswater code revision</source>
			<translation>Giswater code revision</translation>
		</message>
		<message>
			<source>Giswater (libs) code revision</source>
			<translation>Giswater (libs) code revision</translation>
		</message>
		<message>
			<source>Giswater plugin cannot be loaded</source>
			<translation>Giswater-Plugin kann nicht geladen werden</translation>
		</message>
		<message>
			<source>Giswater version</source>
			<translation>Giswater version</translation>
		</message>
		<message>
			<source>GitHub Issues</source>
			<translation>GitHub-Themen</translation>
		</message>
		<message>
			<source>Go2Epa</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>Go2Epa task is already active!</source>
			<translation>Die Go2Epa-Aufgabe ist bereits aktiv!</translation>
		</message>
		<message>
			<source>GO2EPA - Work in progress</source>
			<translation>GO2EPA - Work in progress</translation>
		</message>
		<message>
			<source>Go2Iber task is already active!</source>
			<translation>Die Go2Iber Aufgabe ist bereits aktiv!</translation>
		</message>
		<message>
			<source>GO2IBER - Work in progress</source>
			<translation>GO2IBER - Work in progress</translation>
		</message>
		<message>
			<source>Group &apos;{0}&apos; not found in layer tree.</source>
			<translation>Group &apos;{0}&apos; not found in layer tree.</translation>
		</message>
		<message>
			<source>Gullies</source>
			<translation>Gullies</translation>
		</message>
		<message>
			<source>Gully to network</source>
			<translation>Gully to network</translation>
		</message>
		<message>
			<source>gw_fct_set_rpt_archived execution failed. See logs for more details...</source>
			<translation>gw_fct_set_rpt_archived Ausführung fehlgeschlagen. Siehe Protokolle für weitere Details...</translation>
		</message>
		<message>
			<source>Hemisphere of the node has been updated. Value is</source>
			<translation>Die Hemisphäre des Knotens wurde aktualisiert. Wert ist</translation>
		</message>
		<message>
			<source>Here you can choose how the pumps and valves will be imported, either left as arcs (virual arcs) or converted to nodes.</source>
			<translation>Hier können Sie wählen, wie die Pumpen und Ventile importiert werden sollen, entweder als Bögen (viruale Bögen) oder umgewandelt in Knoten.</translation>
		</message>
		<message>
			<source>Here you can choose how the pumps, weirs, orifices, and outlets will be imported, either left as arcs (virual arcs) or converted to flwreg.</source>
			<translation>Hier können Sie wählen, wie die Pumpen, Wehre, Mündungen und Auslässe importiert werden sollen, entweder als Bögen (virual arcs) oder konvertiert in flwreg.</translation>
		</message>
		<message>
			<source>Highlighting large dataset ({0} features) - this may take a moment...</source>
			<translation>Highlighting large dataset ({0} features) - this may take a moment...</translation>
		</message>
		<message>
			<source>Hot update completed for {0} schema(s) using language ({1}).</source>
			<translation>Hot update completed for {0} schema(s) using language ({1}).</translation>
		</message>
		<message>
			<source>Hot update finished with errors. Updated: {0}. Failed: {1}.</source>
			<translation>Hot update finished with errors. Updated: {0}. Failed: {1}.</translation>
		</message>
		<message>
			<source>Hot update schemas?</source>
			<translation>Hot update schemas?</translation>
		</message>
		<message>
			<source>Hot updating {0}...</source>
			<translation>Hot updating {0}...</translation>
		</message>
		<message>
			<source>Hydraulic engine imported successfully</source>
			<translation>Hydraulic engine imported successfully</translation>
		</message>
		<message>
			<source>Hydrology scenario manager</source>
			<translation>Manager für hydrologische Szenarien</translation>
		</message>
		<message>
			<source>Hydrometer management</source>
			<translation>Hydrometer management</translation>
		</message>
		<message>
			<source>IBERGIS plugin not found</source>
			<translation>IBERGIS-Plugin nicht gefunden</translation>
		</message>
		<message>
			<source>IBERGIS project imported successfully</source>
			<translation>IBERGIS-Projekt erfolgreich importiert</translation>
		</message>
		<message>
			<source>Id already selected</source>
			<translation>Id bereits ausgewählt</translation>
		</message>
		<message>
			<source>If not, you can ignore the tab.</source>
			<translation>Wenn nicht, können Sie die Registerkarte ignorieren.</translation>
		</message>
		<message>
			<source>If you chose to import the flow regulators as flwreg objects, the sixth tab is where you can select the catalog for each flow regulator (pumps, weirs, orifices, outlets) on the network.</source>
			<translation>Wenn Sie sich entschieden haben, die Durchflussregler als flwreg-Objekte zu importieren, können Sie auf der sechsten Registerkarte den Katalog für jeden Durchflussregler (Pumpen, Wehre, Blenden, Auslässe) im Netzwerk auswählen.</translation>
		</message>
		<message>
			<source>If you have any questions, please contact the Giswater team via</source>
			<translation>Wenn Sie Fragen haben, wenden Sie sich bitte an das Giswater-Team unter</translation>
		</message>
		<message>
			<source>imported</source>
			<translation>imported</translation>
		</message>
		<message>
			<source>Importing conduits</source>
			<translation>Importing conduits</translation>
		</message>
		<message>
			<source>Importing controls</source>
			<translation>Importing controls</translation>
		</message>
		<message>
			<source>Importing controls and rules...</source>
			<translation>Importing controls and rules...</translation>
		</message>
		<message>
			<source>Importing curves</source>
			<translation>Importing curves</translation>
		</message>
		<message>
			<source>Importing curves...</source>
			<translation>Importing curves...</translation>
		</message>
		<message>
			<source>Importing dividers</source>
			<translation>Importing dividers</translation>
		</message>
		<message>
			<source>Importing DWF</source>
			<translation>Importing DWF</translation>
		</message>
		<message>
			<source>Importing files...</source>
			<translation>Importing files...</translation>
		</message>
		<message>
			<source>Importing inflows</source>
			<translation>Importing inflows</translation>
		</message>
		<message>
			<source>Importing junctions</source>
			<translation>Importing junctions</translation>
		</message>
		<message>
			<source>Importing junctions...</source>
			<translation>Importing junctions...</translation>
		</message>
		<message>
			<source>Importing LIDs</source>
			<translation>Importing LIDs</translation>
		</message>
		<message>
			<source>Importing options...</source>
			<translation>Importing options...</translation>
		</message>
		<message>
			<source>Importing orifices</source>
			<translation>Importing orifices</translation>
		</message>
		<message>
			<source>Importing outfalls</source>
			<translation>Importing outfalls</translation>
		</message>
		<message>
			<source>Importing outlets</source>
			<translation>Importing outlets</translation>
		</message>
		<message>
			<source>Importing patterns</source>
			<translation>Importing patterns</translation>
		</message>
		<message>
			<source>Importing patterns...</source>
			<translation>Importing patterns...</translation>
		</message>
		<message>
			<source>Importing pipes...</source>
			<translation>Importing pipes...</translation>
		</message>
		<message>
			<source>Importing pumps</source>
			<translation>Importing pumps</translation>
		</message>
		<message>
			<source>Importing pumps...</source>
			<translation>Importing pumps...</translation>
		</message>
		<message>
			<source>Importing raingages</source>
			<translation>Importing raingages</translation>
		</message>
		<message>
			<source>Importing reservoirs...</source>
			<translation>Importing reservoirs...</translation>
		</message>
		<message>
			<source>Importing sources...</source>
			<translation>Importing sources...</translation>
		</message>
		<message>
			<source>Importing storage units</source>
			<translation>Importing storage units</translation>
		</message>
		<message>
			<source>Importing subcatchments</source>
			<translation>Importing subcatchments</translation>
		</message>
		<message>
			<source>Importing tanks...</source>
			<translation>Importing tanks...</translation>
		</message>
		<message>
			<source>Importing timeseries</source>
			<translation>Importing timeseries</translation>
		</message>
		<message>
			<source>Importing title...</source>
			<translation>Importing title...</translation>
		</message>
		<message>
			<source>Importing valves...</source>
			<translation>Importing valves...</translation>
		</message>
		<message>
			<source>Importing weirs</source>
			<translation>Importing weirs</translation>
		</message>
		<message>
			<source>Import INP</source>
			<translation>Import INP</translation>
		</message>
		<message>
			<source>IMPORT INP</source>
			<translation>IMPORT INP</translation>
		</message>
		<message>
			<source>Import INP is only available on Python 3.10 or higher. Please update your QGIS&apos;s Python version.</source>
			<translation>Import INP ist nur unter Python 3.10 oder höher verfügbar. Bitte aktualisieren Sie die Python-Version Ihres QGIS.</translation>
		</message>
		<message>
			<source>Import INP is still in developement. It may not work as intended yet. Please report any unexpected behaviour to the Giswater team.</source>
			<translation>Import INP befindet sich noch in der Entwicklung. Es kann sein, dass es noch nicht wie vorgesehen funktioniert. Bitte melden Sie jedes unerwartete Verhalten an das Giswater-Team.</translation>
		</message>
		<message>
			<source>Import INP (TESTING MODE)</source>
			<translation>Import INP (TESTING MODE)</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis</source>
			<translation>Import OSM Streetaxis</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis - {0}</source>
			<translation>Import OSM Streetaxis - {0}</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis is only available on Python 3.10 or higher. Please update your QGIS&apos;s Python version.</source>
			<translation>Import OSM Streetaxis is only available on Python 3.10 or higher. Please update your QGIS&apos;s Python version.</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis its only for WS projects</source>
			<translation>OSM Streetaxis importieren - nur für WS-Projekte</translation>
		</message>
		<message>
			<source>Import results requires Execute EPA software</source>
			<translation>Import results requires Execute EPA software</translation>
		</message>
		<message>
			<source>Import RPT file</source>
			<translation>RPT-Datei importieren</translation>
		</message>
		<message>
			<source>Import rpt file........: {0}</source>
			<translation>Import rpt file........: {0}</translation>
		</message>
		<message>
			<source>Import RPT file finished.</source>
			<translation>Import der RPT-Datei abgeschlossen.</translation>
		</message>
		<message>
			<source>Import RPT file finished. </source>
			<translation>Import RPT file finished.</translation>
		</message>
		<message>
			<source>Import simulation results........: {0}</source>
			<translation>Import simulation results........: {0}</translation>
		</message>
		<message>
			<source>Import simulation results finished</source>
			<translation>Import simulation results finished</translation>
		</message>
		<message>
			<source>Import simulation results into database</source>
			<translation>Import simulation results into database</translation>
		</message>
		<message>
			<source>Incompatible version of PostgreSQL</source>
			<translation>Inkompatible Version von PostgreSQL</translation>
		</message>
		<message>
			<source>Incorrect option ({0}) for scenario {1}.</source>
			<translation>Incorrect option ({0}) for scenario {1}.</translation>
		</message>
		<message>
			<source>Incorrect valve status ({0}) for arc {1}.</source>
			<translation>Incorrect valve status ({0}) for arc {1}.</translation>
		</message>
		<message>
			<source>Incorrect valve status ({0}) for scenario {1}.</source>
			<translation>Incorrect valve status ({0}) for scenario {1}.</translation>
		</message>
		<message>
			<source>Info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>Info Message</source>
			<translation>Info-Meldung</translation>
		</message>
		<message>
			<source>Information about exception</source>
			<translation>Informationen über Ausnahmen</translation>
		</message>
		<message>
			<source>Initialize plugin</source>
			<translation>Plugin initialisieren</translation>
		</message>
		<message>
			<source>In order to create a qgis project you have to create a schema first.</source>
			<translation>Um ein qgis-Projekt zu erstellen, müssen Sie zunächst ein Schema erstellen.</translation>
		</message>
		<message>
			<source>INP file couldn&apos;t be imported:
{0}</source>
			<translation>INP file couldn&apos;t be imported:
{0}</translation>
		</message>
		<message>
			<source>INP file not found</source>
			<translation>INP-Datei nicht gefunden</translation>
		</message>
		<message>
			<source>Inp Options</source>
			<translation>Inp Optionen</translation>
		</message>
		<message>
			<source>In schema</source>
			<translation>In schema</translation>
		</message>
		<message>
			<source>Integrate am</source>
			<translation>Integrate am</translation>
		</message>
		<message>
			<source>Integrate utils requires a WS or UD anchor.</source>
			<translation>Integrate utils requires a WS or UD anchor.</translation>
		</message>
		<message>
			<source>Interpolate tool.
To modify columns (top_elev, ymax, elev among others) to be interpolated set variable edit_node_interpolate on table config_param_user</source>
			<translation>Interpolate tool.
To modify columns (top_elev, ymax, elev among others) to be interpolated set variable edit_node_interpolate on table config_param_user</translation>
		</message>
		<message>
			<source>Invalid {0} &apos;{1}&apos; provided. No configuration performed.</source>
			<translation>Ungültige {0} &apos;{1}&apos; angegeben. Keine Konfiguration durchgeführt.</translation>
		</message>
		<message>
			<source>Invalid arccat_ids: {0}.</source>
			<translation>Ungültige arccat_ids: {0}.</translation>
		</message>
		<message>
			<source>Invalid buffer value. Please enter an integer less than 1000.</source>
			<translation>Ungültiger Pufferwert. Bitte geben Sie eine ganze Zahl kleiner als 1000 ein.</translation>
		</message>
		<message>
			<source>Invalid buffer value. Please enter an valid integer.</source>
			<translation>Ungültiger Pufferwert. Bitte geben Sie eine gültige Ganzzahl ein.</translation>
		</message>
		<message>
			<source>Invalid campaign ID</source>
			<translation>Invalid campaign ID</translation>
		</message>
		<message>
			<source>Invalid campaign mode: {0}</source>
			<translation>Invalid campaign mode: {0}</translation>
		</message>
		<message>
			<source>Invalid diameters: {1}.</source>
			<translation>Ungültige Durchmesser: {1}.</translation>
		</message>
		<message>
			<source>Invalid layer:
provider={0}
uri={1}</source>
			<translation>Invalid layer:
provider={0}
uri={1}</translation>
		</message>
		<message>
			<source>Invalid lot ID</source>
			<translation>Invalid lot ID</translation>
		</message>
		<message>
			<source>Invalid materials: {3}.</source>
			<translation>Ungültige Materialien: {3}.</translation>
		</message>
		<message>
			<source>Invalid tuple: {0}</source>
			<translation>Invalid tuple: {0}</translation>
		</message>
		<message>
			<source>Invalid value for field</source>
			<translation>Ungültiger Wert für das Feld</translation>
		</message>
		<message>
			<source>Invalid value for scenario_results in [OPTIONS] section.</source>
			<translation>Ungültiger Wert für scenario_results im Abschnitt [OPTIONS].</translation>
		</message>
		<message>
			<source>Invalid value for type of priority dialog. Please pass either &apos;GLOBAL&apos; or &apos;SELECTION&apos;. Value passed: {0}</source>
			<translation>Invalid value for type of priority dialog. Please pass either &apos;GLOBAL&apos; or &apos;SELECTION&apos;. Value passed: {0}</translation>
		</message>
		<message>
			<source>Invalid WKT string</source>
			<translation>Ungültige WKT-Zeichenkette</translation>
		</message>
		<message>
			<source>Invalid workorder ID</source>
			<translation>Invalid workorder ID</translation>
		</message>
		<message>
			<source>Invert the current selection in the table</source>
			<translation>Invert the current selection in the table</translation>
		</message>
		<message>
			<source>Investment (€/year):</source>
			<translation>Investment (€/year):</translation>
		</message>
		<message>
			<source>is not defined in table cat_feature</source>
			<translation>ist in der Tabelle cat_feature nicht definiert</translation>
		</message>
		<message>
			<source>It will then show the log of the process in the last tab.</source>
			<translation>Auf der letzten Registerkarte wird dann das Protokoll des Vorgangs angezeigt.</translation>
		</message>
		<message>
			<source>IVI</source>
			<translation>IVI</translation>
		</message>
		<message>
			<source>IVI (Horizon year):</source>
			<translation>IVI (Horizon year):</translation>
		</message>
		<message>
			<source>Junctions couldn&apos;t be inserted!</source>
			<translation>Junctions couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>KEEP OPERATIVE</source>
			<translation>KEEP OPERATIVE</translation>
		</message>
		<message>
			<source>Key</source>
			<translation>Schlüssel</translation>
		</message>
		<message>
			<source>Key ({0}) is not unique in the config catalog.</source>
			<translation>Key ({0}) is not unique in the config catalog.</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE columname=&apos;{0}&apos; AND widgetname=&apos;{1}&apos;</source>
			<translation>Schlüssel &apos;comboIds&apos; oder/und comboNames nicht gefunden WHERE columnname=&apos;{0}&apos; AND widgetname=&apos;{1}&apos;</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE widgetname=&apos;{0}&apos; AND widgettype=&apos;{1}&apos;</source>
			<translation>Schlüssel &apos;comboIds&apos; oder/und comboNames nicht gefunden WHERE widgetname=&apos;{0}&apos; AND widgettype=&apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Key container</source>
			<translation>Schlüssel-Container</translation>
		</message>
		<message>
			<source>Key not found</source>
			<translation>Key not found</translation>
		</message>
		<message>
			<source>Key on returned json from ddbb is missed</source>
			<translation>Schlüssel auf zurückgegebenem json von ddbb fehlt</translation>
		</message>
		<message>
			<source>Key on returned json from ddbb is missed.</source>
			<translation>Schlüssel auf zurückgegebenem json von ddbb fehlt.</translation>
		</message>
		<message>
			<source>Kind</source>
			<translation>Kind</translation>
		</message>
		<message>
			<source>Language</source>
			<translation>Sprache</translation>
		</message>
		<message>
			<source>Language: {0}</source>
			<translation>Language: {0}</translation>
		</message>
		<message>
			<source>Language ({0}) is in use and cannot be deleted. Used by: {1}</source>
			<translation>Language ({0}) is in use and cannot be deleted. Used by: {1}</translation>
		</message>
		<message>
			<source>Language ({0}) is used by {1} schema(s): {2}. Do you want to hot update them now?</source>
			<translation>Language ({0}) is used by {1} schema(s): {2}. Do you want to hot update them now?</translation>
		</message>
		<message>
			<source>Language files</source>
			<translation>Language files</translation>
		</message>
		<message>
			<source>Language files and multilang translations updated ({0}).</source>
			<translation>Language files and multilang translations updated ({0}).</translation>
		</message>
		<message>
			<source>Language files deleted and locale deactivated ({0}).</source>
			<translation>Language files deleted and locale deactivated ({0}).</translation>
		</message>
		<message>
			<source>Language files downloaded and locale activated ({0}).</source>
			<translation>Language files downloaded and locale activated ({0}).</translation>
		</message>
		<message>
			<source>Language files updated ({0}), but multilang translations failed: {1}</source>
			<translation>Language files updated ({0}), but multilang translations failed: {1}</translation>
		</message>
		<message>
			<source>Language files updated and locale activated ({0}).</source>
			<translation>Language files updated and locale activated ({0}).</translation>
		</message>
		<message>
			<source>Language provision cancel failed: {0}</source>
			<translation>Language provision cancel failed: {0}</translation>
		</message>
		<message>
			<source>Language provision pre-check failed: {0}</source>
			<translation>Language provision pre-check failed: {0}</translation>
		</message>
		<message>
			<source>Last update</source>
			<translation>Last update</translation>
		</message>
		<message>
			<source>Layer {0} does not found, therefore, not configured</source>
			<translation>Schicht {0} nicht gefunden, daher nicht konfiguriert</translation>
		</message>
		<message>
			<source>Layer &apos;{0}&apos; is None and settings is None</source>
			<translation>Layer &apos;{0}&apos; is None and settings is None</translation>
		</message>
		<message>
			<source>Layer &apos;{0}&apos; not found in QGIS.</source>
			<translation>Ebene &apos;{0}&apos; nicht in QGIS gefunden.</translation>
		</message>
		<message>
			<source>Layer failed to load!</source>
			<translation>Layer failed to load!</translation>
		</message>
		<message>
			<source>Layer is broken</source>
			<translation>Layer is broken</translation>
		</message>
		<message>
			<source>Layer not found</source>
			<translation>Ebene nicht gefunden</translation>
		</message>
		<message>
			<source>Layer of CM project will be added to the project when create</source>
			<translation>Layer of CM project will be added to the project when create</translation>
		</message>
		<message>
			<source>Layout not found</source>
			<translation>Layout nicht gefunden</translation>
		</message>
		<message>
			<source>layoutorder not found.</source>
			<translation>Layout-Auftrag nicht gefunden.</translation>
		</message>
		<message>
			<source>Libraries</source>
			<translation>Libraries</translation>
		</message>
		<message>
			<source>License</source>
			<translation>License</translation>
		</message>
		<message>
			<source>LIDS</source>
			<translation>LIDS</translation>
		</message>
		<message>
			<source>Line number</source>
			<translation>Zeilennummer</translation>
		</message>
		<message>
			<source>Linked</source>
			<translation>Linked</translation>
		</message>
		<message>
			<source>Link widget not found. Check config_form_fields.</source>
			<translation>Link widget not found. Check config_form_fields.</translation>
		</message>
		<message>
			<source>Locale</source>
			<translation>Locale</translation>
		</message>
		<message>
			<source>Locale not found</source>
			<translation>Locale not found</translation>
		</message>
		<message>
			<source>Locales seed file not found</source>
			<translation>Locales seed file not found</translation>
		</message>
		<message>
			<source>Log file</source>
			<translation>Log file</translation>
		</message>
		<message>
			<source>Lot ID not found.</source>
			<translation>Lot ID not found.</translation>
		</message>
		<message>
			<source>Manage languages</source>
			<translation>Manage languages</translation>
		</message>
		<message>
			<source>Managing nodarcs (pumps/valves as nodes)...</source>
			<translation>Managing nodarcs (pumps/valves as nodes)...</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please, set a value</source>
			<translation>Obligatorisches Feld fehlt. Bitte setzen Sie einen Wert</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please, set a value for field</source>
			<translation>Obligatorisches Feld fehlt. Bitte setzen Sie einen Wert für das Feld</translation>
		</message>
		<message>
			<source>Map item &apos;Mapa&apos; not found in template. Template may be empty or use different item IDs.</source>
			<translation>Map item &apos;Mapa&apos; not found in template. Template may be empty or use different item IDs.</translation>
		</message>
		<message>
			<source>Mapzone config - {0}</source>
			<translation>Mapzone config - {0}</translation>
		</message>
		<message>
			<source>Mapzone config - {0} (Netscenario {1})</source>
			<translation>Mapzone config - {0} (Netscenario {1})</translation>
		</message>
		<message>
			<source>Mapzone dynamic widgets not found: {0}</source>
			<translation>Mapzone dynamic widgets not found: {0}</translation>
		</message>
		<message>
			<source>Mapzone manager dynamic config not found.</source>
			<translation>Mapzone manager dynamic config not found.</translation>
		</message>
		<message>
			<source>Mapzone manager tabs not configured in DB.</source>
			<translation>Mapzone manager tabs not configured in DB.</translation>
		</message>
		<message>
			<source>Mapzones analysis completed successfully.</source>
			<translation>Mapzones-Analyse erfolgreich abgeschlossen.</translation>
		</message>
		<message>
			<source>Markdown Generated from {0}.</source>
			<translation>Markdown Generated from {0}.</translation>
		</message>
		<message>
			<source>Marked values must be greater than 0</source>
			<translation>Markierte Werte müssen größer als 0 sein</translation>
		</message>
		<message>
			<source>Material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>Max. Longevity</source>
			<translation>Max. Longevity</translation>
		</message>
		<message>
			<source>Med. Longevity</source>
			<translation>Med. Longevity</translation>
		</message>
		<message>
			<source>Merge</source>
			<translation>Merge</translation>
		</message>
		<message>
			<source>Merge requires at least 2 psectors to be selected</source>
			<translation>Merge requires at least 2 psectors to be selected</translation>
		</message>
		<message>
			<source>Message</source>
			<translation>Nachricht</translation>
		</message>
		<message>
			<source>Message error</source>
			<translation>Message error</translation>
		</message>
		<message>
			<source>Mincut canceled!</source>
			<translation>Mincut canceled!</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict and overlaps with</source>
			<translation>Mincut erledigt, hat aber Konflikte und Überschneidungen mit</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict and overlaps with other mincuts</source>
			<translation>Mincut done, but has conflict and overlaps with other mincuts</translation>
		</message>
		<message>
			<source>Mincut done successfully</source>
			<translation>Mincut erfolgreich durchgeführt</translation>
		</message>
		<message>
			<source>Mincut execute</source>
			<translation>Mincut execute</translation>
		</message>
		<message>
			<source>Mincut task is already active!</source>
			<translation>Die Mincut-Aufgabe ist bereits aktiv!</translation>
		</message>
		<message>
			<source>Min. Longevity</source>
			<translation>Min. Longevity</translation>
		</message>
		<message>
			<source>...min_message_level</source>
			<translation>...min_message_level</translation>
		</message>
		<message>
			<source>Missing Data</source>
			<translation>Missing Data</translation>
		</message>
		<message>
			<source>Missing required fields</source>
			<translation>Fehlende Pflichtfelder</translation>
		</message>
		<message>
			<source>More than one event selected. Select just one</source>
			<translation>More than one event selected. Select just one</translation>
		</message>
		<message>
			<source>More then one document selected. Select just one document.</source>
			<translation>More then one document selected. Select just one document.</translation>
		</message>
		<message>
			<source>Move node: Error updating geometry</source>
			<translation>Knoten verschieben: Fehler beim Aktualisieren der Geometrie</translation>
		</message>
		<message>
			<source>Multilang function failed</source>
			<translation>Multilang function failed</translation>
		</message>
		<message>
			<source>Multilang function failed.</source>
			<translation>Multilang function failed.</translation>
		</message>
		<message>
			<source>Multilang function failed. SQL: {0}</source>
			<translation>Multilang function failed. SQL: {0}</translation>
		</message>
		<message>
			<source>Multilang function response</source>
			<translation>Multilang function response</translation>
		</message>
		<message>
			<source>Multilang function returned an invalid JSON response.</source>
			<translation>Multilang function returned an invalid JSON response.</translation>
		</message>
		<message>
			<source>Multilang function returned unexpected status</source>
			<translation>Multilang function returned unexpected status</translation>
		</message>
		<message>
			<source>Multilang function SQL failed</source>
			<translation>Multilang function SQL failed</translation>
		</message>
		<message>
			<source>Multilang language currently used: {0}.</source>
			<translation>Multilang language currently used: {0}.</translation>
		</message>
		<message>
			<source>Multilang language delete completed for {0}.</source>
			<translation>Multilang language delete completed for {0}.</translation>
		</message>
		<message>
			<source>Multilang on_done callback raised: {0}</source>
			<translation>Multilang on_done callback raised: {0}</translation>
		</message>
		<message>
			<source>Multilang SchemaBuilder exception: {0}</source>
			<translation>Multilang SchemaBuilder exception: {0}</translation>
		</message>
		<message>
			<source>Multilang schema build failed: {0}</source>
			<translation>Multilang schema build failed: {0}</translation>
		</message>
		<message>
			<source>Multilang schema is not available on this connection.</source>
			<translation>Multilang schema is not available on this connection.</translation>
		</message>
		<message>
			<source>Multilang schema task failed during baseline seed.</source>
			<translation>Multilang schema task failed during baseline seed.</translation>
		</message>
		<message>
			<source>Multilang seed failed for project_type {0}: {1}</source>
			<translation>Multilang seed failed for project_type {0}: {1}</translation>
		</message>
		<message>
			<source>Multilang seed: no baseline SQL for project_type={0} (lang={1}); skipping.</source>
			<translation>Multilang seed: no baseline SQL for project_type={0} (lang={1}); skipping.</translation>
		</message>
		<message>
			<source>Multilang seed: no project types with bundled baselines detected; only cat_language ensured for {0}.</source>
			<translation>Multilang seed: no project types with bundled baselines detected; only cat_language ensured for {0}.</translation>
		</message>
		<message>
			<source>Multilang seed: no project types with bundled baselines detected; skipping import.</source>
			<translation>Multilang seed: no project types with bundled baselines detected; skipping import.</translation>
		</message>
		<message>
			<source>Multilang translations deleted and locale deactivated ({0}).</source>
			<translation>Multilang translations deleted and locale deactivated ({0}).</translation>
		</message>
		<message>
			<source>Multilang translations seeded and locale activated ({0}).</source>
			<translation>Multilang translations seeded and locale activated ({0}).</translation>
		</message>
		<message>
			<source>Multilang translations updated ({0}).</source>
			<translation>Multilang translations updated ({0}).</translation>
		</message>
		<message>
			<source>Multilang user parameter provisioning</source>
			<translation>Multilang user parameter provisioning</translation>
		</message>
		<message>
			<source>Multilang user parameter rollback failed.</source>
			<translation>Multilang user parameter rollback failed.</translation>
		</message>
		<message>
			<source>Multilang views provisioning</source>
			<translation>Multilang views provisioning</translation>
		</message>
		<message>
			<source>Multilang views rollback failed.</source>
			<translation>Multilang views rollback failed.</translation>
		</message>
		<message>
			<source>Multiple psectors selected. Please select only one.</source>
			<translation>Mehrere Sektoren ausgewählt. Bitte wählen Sie nur einen aus.</translation>
		</message>
		<message>
			<source>Municipality</source>
			<translation>Municipality</translation>
		</message>
		<message>
			<source>Municipality with ID: {0} deleted from selection</source>
			<translation>Kommune mit ID: {0} aus der Auswahl gelöscht</translation>
		</message>
		<message>
			<source>Municipality with id[{0}] is already imported on om_streetaxis.
Do you want to overwrite it?
(This decision will not cancel the other selections, the process will keep running)</source>
			<translation>Municipality with id[{0}] is already imported on om_streetaxis.
Do you want to overwrite it?
(This decision will not cancel the other selections, the process will keep running)</translation>
		</message>
		<message>
			<source>N/A</source>
			<translation>N/A</translation>
		</message>
		<message>
			<source>Name</source>
			<translation>Name</translation>
		</message>
		<message>
			<source>Network Utilities</source>
			<translation>Network Utilities</translation>
		</message>
		<message>
			<source>New {0}</source>
			<translation>New {0}</translation>
		</message>
		<message>
			<source>New catalog name</source>
			<translation>New catalog name</translation>
		</message>
		<message>
			<source>New feature type is null. Please, select a valid value</source>
			<translation>Neuer Merkmalstyp ist null. Bitte wählen Sie einen gültigen Wert</translation>
		</message>
		<message>
			<source>New feature type is null. Please, select a valid value.</source>
			<translation>Neuer Merkmalstyp ist null. Bitte wählen Sie einen gültigen Wert.</translation>
		</message>
		<message>
			<source>Next</source>
			<translation>Weiter</translation>
		</message>
		<message>
			<source>n must be at least one</source>
			<translation>n must be at least one</translation>
		</message>
		<message>
			<source>No action found</source>
			<translation>Keine Aktion gefunden</translation>
		</message>
		<message>
			<source>No active locales configured</source>
			<translation>No active locales configured</translation>
		</message>
		<message>
			<source>No arc ID found at the snapped location.</source>
			<translation>No arc ID found at the snapped location.</translation>
		</message>
		<message>
			<source>No campaign selected</source>
			<translation>No campaign selected</translation>
		</message>
		<message>
			<source>No changes to save.</source>
			<translation>No changes to save.</translation>
		</message>
		<message>
			<source>No composers found.</source>
			<translation>Keine Komponisten gefunden.</translation>
		</message>
		<message>
			<source>No current psector selected</source>
			<translation>Kein aktueller Sektor ausgewählt</translation>
		</message>
		<message>
			<source>Nodarcs</source>
			<translation>Nodarcs</translation>
		</message>
		<message>
			<source>No database connection available for hydraulic engine export</source>
			<translation>No database connection available for hydraulic engine export</translation>
		</message>
		<message>
			<source>Node {0} duplicated in config file.</source>
			<translation>Node {0} duplicated in config file.</translation>
		</message>
		<message>
			<source>node1 and node2 are required for profile interpolation.</source>
			<translation>node1 and node2 are required for profile interpolation.</translation>
		</message>
		<message>
			<source>Node 1 selected</source>
			<translation>Knoten 1 ausgewählt</translation>
		</message>
		<message>
			<source>Node 2 selected</source>
			<translation>Node 2 selected</translation>
		</message>
		<message>
			<source>Node already selected</source>
			<translation>Node already selected</translation>
		</message>
		<message>
			<source>Node id:</source>
			<translation>Knotenpunkt-ID:</translation>
		</message>
		<message>
			<source>Node ID for {0} not found!</source>
			<translation>Node ID for {0} not found!</translation>
		</message>
		<message>
			<source>Node layer not found in the project.</source>
			<translation>Node layer not found in the project.</translation>
		</message>
		<message>
			<source>Node not found: {0}</source>
			<translation>Node not found: {0}</translation>
		</message>
		<message>
			<source>Node selected</source>
			<translation>Node selected</translation>
		</message>
		<message>
			<source>Node set correctly</source>
			<translation>Node set correctly</translation>
		</message>
		<message>
			<source>No document selected.</source>
			<translation>Kein Dokument ausgewählt.</translation>
		</message>
		<message>
			<source>No EPA results found. You must first simulate with Go2Epa.</source>
			<translation>No EPA results found. You must first simulate with Go2Epa.</translation>
		</message>
		<message>
			<source>No event provided for point selection</source>
			<translation>No event provided for point selection</translation>
		</message>
		<message>
			<source>No features found in the selection for {0}.</source>
			<translation>No features found in the selection for {0}.</translation>
		</message>
		<message>
			<source>No features found in the selection for the enabled tabs ({0}).</source>
			<translation>No features found in the selection for the enabled tabs ({0}).</translation>
		</message>
		<message>
			<source>NO FEATURE TYPE DEFINED</source>
			<translation>KEIN MERKMALSTYP DEFINIERT</translation>
		</message>
		<message>
			<source>No help file found</source>
			<translation>Keine Hilfedatei gefunden</translation>
		</message>
		<message>
			<source>No link in common between network and scenario {0}.</source>
			<translation>No link in common between network and scenario {0}.</translation>
		</message>
		<message>
			<source>No listValues for</source>
			<translation>Keine listValues für</translation>
		</message>
		<message>
			<source>No local i18n baseline SQL found for ({0}). Download plugin language files first.</source>
			<translation>No local i18n baseline SQL found for ({0}). Download plugin language files first.</translation>
		</message>
		<message>
			<source>No local SQL files found for language ({0}). Download them first.</source>
			<translation>No local SQL files found for language ({0}). Download them first.</translation>
		</message>
		<message>
			<source>No municipalities selected</source>
			<translation>Keine Gemeinden ausgewählt</translation>
		</message>
		<message>
			<source>No new features to insert. All selected features already exist in the table.</source>
			<translation>No new features to insert. All selected features already exist in the table.</translation>
		</message>
		<message>
			<source>No node ID found at the snapped location.</source>
			<translation>Keine Node-ID an der gesnappten Stelle gefunden.</translation>
		</message>
		<message>
			<source>Non-visual objects</source>
			<translation>Non-visual objects</translation>
		</message>
		<message>
			<source>No parameters found in section {0}</source>
			<translation>No parameters found in section {0}</translation>
		</message>
		<message>
			<source>No pictures for this event.</source>
			<translation>Keine Bilder für diese Veranstaltung.</translation>
		</message>
		<message>
			<source>No pipes found matching your budget. (Hint: increase the yearly budget or/and the horizon year)</source>
			<translation>No pipes found matching your budget. (Hint: increase the yearly budget or/and the horizon year)</translation>
		</message>
		<message>
			<source>No pipes found matching your selected filters.</source>
			<translation>No pipes found matching your selected filters.</translation>
		</message>
		<message>
			<source>No primary key value set</source>
			<translation>Kein Primärschlüsselwert festgelegt</translation>
		</message>
		<message>
			<source>No psector selected. Please select at least one.</source>
			<translation>Kein Sektor ausgewählt. Bitte wählen Sie mindestens einen aus.</translation>
		</message>
		<message>
			<source>No psector values</source>
			<translation>Keine sektoralen Werte</translation>
		</message>
		<message>
			<source>No records selected</source>
			<translation>No records selected</translation>
		</message>
		<message>
			<source>No results</source>
			<translation>Keine Ergebnisse</translation>
		</message>
		<message>
			<source>No results found. Please check values set on selector of state and exploitation</source>
			<translation>Keine Ergebnisse gefunden. Bitte überprüfen Sie die Werte im Selektor für Staat und Ausbeutung</translation>
		</message>
		<message>
			<source>No results returned from the database.</source>
			<translation>No results returned from the database.</translation>
		</message>
		<message>
			<source>No snapshots available. Please create a snapshot first or wait for tomorrow to travel since today.</source>
			<translation>Keine Schnappschüsse verfügbar. Bitte erstellen Sie zuerst einen Snapshot oder warten Sie auf morgen, um seit heute zu reisen.</translation>
		</message>
		<message>
			<source>No SQL context available.</source>
			<translation>No SQL context available.</translation>
		</message>
		<message>
			<source>No teams available to switch to.</source>
			<translation>No teams available to switch to.</translation>
		</message>
		<message>
			<source>Not found: {0}</source>
			<translation>Nicht gefunden: {0}</translation>
		</message>
		<message>
			<source>Not installed</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>No URI builder for provider: {0}</source>
			<translation>No URI builder for provider: {0}</translation>
		</message>
		<message>
			<source>No valid data received from the SQL function.</source>
			<translation>Keine gültigen Daten von der SQL-Funktion empfangen.</translation>
		</message>
		<message>
			<source>No valid psector IDs found</source>
			<translation>Keine gültigen Sektor-IDs gefunden</translation>
		</message>
		<message>
			<source>No valid snapping result. Please select a valid arc.</source>
			<translation>No valid snapping result. Please select a valid arc.</translation>
		</message>
		<message>
			<source>No valid snapping result. Please select a valid point.</source>
			<translation>Kein gültiges Fangergebnis. Bitte wählen Sie einen gültigen Punkt.</translation>
		</message>
		<message>
			<source>No visit values</source>
			<translation>Keine Besuchswerte</translation>
		</message>
		<message>
			<source>No workcat values</source>
			<translation>Keine workcat-Werte</translation>
		</message>
		<message>
			<source>object_1 and object_2 are required.</source>
			<translation>object_1 and object_2 are required.</translation>
		</message>
		<message>
			<source>object_1 and object_2 must be different.</source>
			<translation>object_1 and object_2 must be different.</translation>
		</message>
		<message>
			<source>object_1 and object_2 must be numeric node ids.</source>
			<translation>object_1 and object_2 must be numeric node ids.</translation>
		</message>
		<message>
			<source>Object already associated with this feature</source>
			<translation>Objekt, das bereits mit diesem Merkmal verknüpft ist</translation>
		</message>
		<message>
			<source>Object id not found</source>
			<translation>Objekt-ID nicht gefunden</translation>
		</message>
		<message>
			<source>Offline mincut failed (gw_fct_getmincutminsector)</source>
			<translation>Offline mincut failed (gw_fct_getmincutminsector)</translation>
		</message>
		<message>
			<source>Once you have configured all the necessary catalogs, you can click on the &apos;Accept&apos; button to start the import process.</source>
			<translation>Sobald Sie alle erforderlichen Kataloge konfiguriert haben, können Sie auf die Schaltfläche &quot;Übernehmen&quot; klicken, um den Importvorgang zu starten.</translation>
		</message>
		<message>
			<source>Only FRELEM can be added to dscenario</source>
			<translation>Nur FRELEM kann zu dscenario hinzugefügt werden</translation>
		</message>
		<message>
			<source>Only one record can be selected</source>
			<translation>Es kann nur ein Datensatz ausgewählt werden</translation>
		</message>
		<message>
			<source>Only PARTIAL or COMPLETED results can be validated</source>
			<translation>Only PARTIAL or COMPLETED results can be validated</translation>
		</message>
		<message>
			<source>Only rows with values are allowed to be deleted.</source>
			<translation>Es dürfen nur Zeilen mit Werten gelöscht werden.</translation>
		</message>
		<message>
			<source>Open</source>
			<translation>Open</translation>
		</message>
		<message>
			<source>Open Manage Schemas to create and integrate am</source>
			<translation>Open Manage Schemas to create and integrate am</translation>
		</message>
		<message>
			<source>Option &apos;{0}&apos; in scenario {1} must have 2 values.</source>
			<translation>Option &apos;{0}&apos; in scenario {1} must have 2 values.</translation>
		</message>
		<message>
			<source>or</source>
			<translation>oder</translation>
		</message>
		<message>
			<source>Orifice</source>
			<translation>Orifice</translation>
		</message>
		<message>
			<source>Orifices couldn&apos;t be inserted!</source>
			<translation>Orifices couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>OSM import is already running</source>
			<translation>OSM import is already running</translation>
		</message>
		<message>
			<source>OSM import was cancelled</source>
			<translation>OSM import was cancelled</translation>
		</message>
		<message>
			<source>OS version</source>
			<translation>OS version</translation>
		</message>
		<message>
			<source>Other catalogs:</source>
			<translation>Other catalogs:</translation>
		</message>
		<message>
			<source>Other feature ids:</source>
			<translation>Other feature ids:</translation>
		</message>
		<message>
			<source>Other materials:</source>
			<translation>Other materials:</translation>
		</message>
		<message>
			<source>Others</source>
			<translation>Others</translation>
		</message>
		<message>
			<source>our website</source>
			<translation>unsere Webseite</translation>
		</message>
		<message>
			<source>Outfalls couldn&apos;t be inserted!</source>
			<translation>Outfalls couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Outlet</source>
			<translation>Outlet</translation>
		</message>
		<message>
			<source>Outlets couldn&apos;t be inserted!</source>
			<translation>Outlets couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Overwrite</source>
			<translation>Überschreiben Sie</translation>
		</message>
		<message>
			<source>Overwrite file</source>
			<translation>Datei überschreiben</translation>
		</message>
		<message>
			<source>Overwrite values</source>
			<translation>Werte überschreiben</translation>
		</message>
		<message>
			<source>Page not found.</source>
			<translation>Page not found.</translation>
		</message>
		<message>
			<source>Parameter &apos;{0}&apos; is None</source>
			<translation>Der Parameter &apos;{0}&apos; ist keiner</translation>
		</message>
		<message>
			<source>Parameter button_function is null for button</source>
			<translation>Der Parameter button_function ist für die Schaltfläche null</translation>
		</message>
		<message>
			<source>Parameter functionName is null for button</source>
			<translation>Der Parameter functionName ist für die Schaltfläche null</translation>
		</message>
		<message>
			<source>Parameter functionName is null for check</source>
			<translation>Parameter functionName ist null für die Prüfung</translation>
		</message>
		<message>
			<source>Parameter not found: {parameter}</source>
			<translation>Parameter nicht gefunden: {parameter}</translation>
		</message>
		<message>
			<source>Parameter &apos;Query text:&apos; is mandatory for &apos;combo&apos; widgets. Please set value.</source>
			<translation>Der Parameter &apos;Abfragetext:&apos; ist für &apos;Combo&apos;-Widgets obligatorisch. Bitte setzen Sie den Wert.</translation>
		</message>
		<message>
			<source>Parameter widgetfunction is null for widget hyperlink</source>
			<translation>Parameter widgetfunction ist null für das Widget Hyperlink</translation>
		</message>
		<message>
			<source>Parameter widgetfunction not found for widget type hyperlink</source>
			<translation>Parameter widgetfunction für Widget-Typ Hyperlink nicht gefunden</translation>
		</message>
		<message>
			<source>Parent ID does not exist.</source>
			<translation>Parent ID does not exist.</translation>
		</message>
		<message>
			<source>Parent ID must be an integer.</source>
			<translation>Parent ID must be an integer.</translation>
		</message>
		<message>
			<source>Parse INP task</source>
			<translation>Parse INP task</translation>
		</message>
		<message>
			<source>Parsing error fixed</source>
			<translation>Parsing-Fehler behoben</translation>
		</message>
		<message>
			<source>pgRouting version</source>
			<translation>pgRouting version</translation>
		</message>
		<message>
			<source>PgRouting version</source>
			<translation>PgRouting Version</translation>
		</message>
		<message>
			<source>pgRouting version is not compatible with Giswater. Please check wiki</source>
			<translation>pgRouting Version ist nicht kompatibel mit Giswater. Bitte schauen Sie im Wiki nach</translation>
		</message>
		<message>
			<source>PIPE</source>
			<translation>PIPE</translation>
		</message>
		<message>
			<source>Pipes couldn&apos;t be inserted!</source>
			<translation>Pipes couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Pipes with invalid arccat_ids: {0}.</source>
			<translation>Pipes mit ungültigen arccat_ids: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid arccat_ids: {0}.
Invalid arccat_ids: {1}.

An arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.

Do you want to proceed?</source>
			<translation>Pipes with invalid arccat_ids: {0}.
Invalid arccat_ids: {1}.

An arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.

Do you want to proceed?</translation>
		</message>
		<message>
			<source>Pipes with invalid diameters: {0}.</source>
			<translation>Rohre mit ungültigen Durchmessern: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid diameters: {0}.
Invalid diameters: {1}.

A diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.

Do you want to proceed?</source>
			<translation>Pipes with invalid diameters: {0}.
Invalid diameters: {1}.

A diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.

Do you want to proceed?</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {0}.qtd</source>
			<translation>Rohre mit ungültigen Materialien: {0}.qtd</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {2}.</source>
			<translation>Rohre mit ungültigen Materialien: {2}.</translation>
		</message>
		<message>
			<source>Pipes with invalid pressures: {0}.
These pipes have no pressure information for their nodes. This will result in them receiving the maximum longevity value for their material, which may affect the final priority value.

Do you want to proceed?</source>
			<translation>Pipes with invalid pressures: {0}.
These pipes have no pressure information for their nodes. This will result in them receiving the maximum longevity value for their material, which may affect the final priority value.

Do you want to proceed?</translation>
		</message>
		<message>
			<source>Planified features cannot be replaced</source>
			<translation>Geplante Merkmale können nicht ersetzt werden</translation>
		</message>
		<message>
			<source>Plan psector - {0} ({1})</source>
			<translation>Plan psector - {0} ({1})</translation>
		</message>
		<message>
			<source>Please choose a csv file</source>
			<translation>Bitte wählen Sie eine csv-Datei</translation>
		</message>
		<message>
			<source>Please choose a different name.</source>
			<translation>Please choose a different name.</translation>
		</message>
		<message>
			<source>Please choose a valid path</source>
			<translation>Bitte wählen Sie einen gültigen Pfad</translation>
		</message>
		<message>
			<source>Please close all &apos;Psector manager&apos; dialogs and try again</source>
			<translation>Please close all &apos;Psector manager&apos; dialogs and try again</translation>
		</message>
		<message>
			<source>Please enter a demands dscenario name to proceed with this import.</source>
			<translation>Bitte geben Sie einen Namen für das Nachfrageszenario ein, um mit dem Import fortzufahren.</translation>
		</message>
		<message>
			<source>Please enter a new catalog name when the &quot;{0}&quot; option is selected.</source>
			<translation>Please enter a new catalog name when the &quot;{0}&quot; option is selected.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the built date range.</source>
			<translation>Bitte geben Sie eine gültige ganze Zahl für den Erstellungszeitraum ein.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the cluster length.</source>
			<translation>Bitte geben Sie eine gültige ganze Zahl für die Länge des Clusters ein.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the maximum distance.</source>
			<translation>Bitte geben Sie eine gültige Ganzzahl für die maximale Entfernung ein.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the number of years.</source>
			<translation>Bitte geben Sie eine gültige ganze Zahl für die Anzahl der Jahre ein.</translation>
		</message>
		<message>
			<source>Please enter a valid number.</source>
			<translation>Please enter a valid number.</translation>
		</message>
		<message>
			<source>Please enter a valid number for the budget.</source>
			<translation>Bitte geben Sie eine gültige Nummer für das Budget ein.</translation>
		</message>
		<message>
			<source>Please enter a valid target year.</source>
			<translation>Bitte geben Sie ein gültiges Zieljahr ein.</translation>
		</message>
		<message>
			<source>Please enter a Workcat_id to proceed with this import.</source>
			<translation>Bitte geben Sie eine Workcat_id ein, um mit diesem Import fortzufahren.</translation>
		</message>
		<message>
			<source>Please enter the diameter range in this format: [minimum factor]-[maximum factor]. For example, 0.75-1.5</source>
			<translation>Bitte geben Sie den Durchmesserbereich in diesem Format ein: [Mindestfaktor]-[Höchstfaktor]. Zum Beispiel: 0,75-1,5</translation>
		</message>
		<message>
			<source>Please fill all mandatory fields (highlighted in red).</source>
			<translation>Please fill all mandatory fields (highlighted in red).</translation>
		</message>
		<message>
			<source>Please fill link catalog field in the dialog</source>
			<translation>Bitte füllen Sie das Feld Linkkatalog im Dialog aus</translation>
		</message>
		<message>
			<source>Please provide a result name.</source>
			<translation>Bitte geben Sie einen Ergebnisnamen an.</translation>
		</message>
		<message>
			<source>Please select a catalog item for all elements in the tabs: Features, Nodes, Arcs, Materials.</source>
			<translation>Bitte wählen Sie eine Katalogposition für alle Elemente in den Registerkarten: Merkmale, Knoten, Bögen, Materialien.</translation>
		</message>
		<message>
			<source>Please select a catalog item for all elements in the tabs: Nodes, Arcs, Materials, Features.</source>
			<translation>Bitte wählen Sie eine Katalogposition für alle Elemente in den Registerkarten: Knoten, Bögen, Materialien, Merkmale.</translation>
		</message>
		<message>
			<source>Please select a category to update.</source>
			<translation>Bitte wählen Sie eine Kategorie zur Aktualisierung.</translation>
		</message>
		<message>
			<source>Please select a default raingage to proceed with this import.</source>
			<translation>Bitte wählen Sie eine Standardmenge aus, um mit dem Import fortzufahren.</translation>
		</message>
		<message>
			<source>Please, select a diferent project name than current.</source>
			<translation>Bitte wählen Sie einen anderen Projektnamen als den aktuellen.</translation>
		</message>
		<message>
			<source>Please select a feature to add</source>
			<translation>Bitte wählen Sie eine Funktion zum Hinzufügen</translation>
		</message>
		<message>
			<source>Please select a lot to open</source>
			<translation>Please select a lot to open</translation>
		</message>
		<message>
			<source>Please select a municipality to proceed with this import.</source>
			<translation>Bitte wählen Sie eine Gemeinde aus, um mit dem Import fortzufahren.</translation>
		</message>
		<message>
			<source>Please select an element to zoom to.</source>
			<translation>Please select an element to zoom to.</translation>
		</message>
		<message>
			<source>Please select an exploitation to proceed with this import.</source>
			<translation>Bitte wählen Sie einen Betrieb aus, um mit dem Import fortzufahren.</translation>
		</message>
		<message>
			<source>Please, select a project to delete</source>
			<translation>Bitte wählen Sie ein zu löschendes Projekt aus</translation>
		</message>
		<message>
			<source>Please, select a project to rename</source>
			<translation>Please, select a project to rename</translation>
		</message>
		<message>
			<source>Please select a result and an export path.</source>
			<translation>Please select a result and an export path.</translation>
		</message>
		<message>
			<source>Please select a result with not empty type</source>
			<translation>Please select a result with not empty type</translation>
		</message>
		<message>
			<source>Please select a row first</source>
			<translation>Please select a row first</translation>
		</message>
		<message>
			<source>Please select a sector to proceed with this import.</source>
			<translation>Bitte wählen Sie einen Sektor aus, um mit dem Import fortzufahren.</translation>
		</message>
		<message>
			<source>Please select a style group before adding a new style.</source>
			<translation>Bitte wählen Sie eine Stilgruppe aus, bevor Sie einen neuen Stil hinzufügen.</translation>
		</message>
		<message>
			<source>Please select a style group to delete.</source>
			<translation>Bitte wählen Sie eine Stilgruppe zum Löschen aus.</translation>
		</message>
		<message>
			<source>Please select a team to assign.</source>
			<translation>Please select a team to assign.</translation>
		</message>
		<message>
			<source>Please select at least one user to assign a team.</source>
			<translation>Please select at least one user to assign a team.</translation>
		</message>
		<message>
			<source>Please select at least one user to change team.</source>
			<translation>Please select at least one user to change team.</translation>
		</message>
		<message>
			<source>Please select at least one user to remove team assignment.</source>
			<translation>Please select at least one user to remove team assignment.</translation>
		</message>
		<message>
			<source>Please select a valid team to assign.</source>
			<translation>Please select a valid team to assign.</translation>
		</message>
		<message>
			<source>Please select a workorder to open</source>
			<translation>Please select a workorder to open</translation>
		</message>
		<message>
			<source>Please select both a user and a campaign before adding a row.</source>
			<translation>Please select both a user and a campaign before adding a row.</translation>
		</message>
		<message>
			<source>Please select one or more styles to delete.</source>
			<translation>Bitte wählen Sie einen oder mehrere Stile zum Löschen aus.</translation>
		</message>
		<message>
			<source>Please select one or more styles to update.</source>
			<translation>Bitte wählen Sie einen oder mehrere Stile zur Aktualisierung aus.</translation>
		</message>
		<message>
			<source>Please select only one result before changing its status.</source>
			<translation>Bitte wählen Sie nur ein Ergebnis aus, bevor Sie dessen Status ändern.</translation>
		</message>
		<message>
			<source>Please select rows to remove from the table</source>
			<translation>Bitte wählen Sie die Zeilen aus, die Sie aus der Tabelle entfernen möchten</translation>
		</message>
		<message>
			<source>Plugin version not found</source>
			<translation>Plugin version not found</translation>
		</message>
		<message>
			<source>PostGis version</source>
			<translation>PostGis version</translation>
		</message>
		<message>
			<source>PostGIS version</source>
			<translation>PostGIS version</translation>
		</message>
		<message>
			<source>PostgreSQL PID: {0}</source>
			<translation>PostgreSQL PID: {0}</translation>
		</message>
		<message>
			<source>PostgreSQL version</source>
			<translation>PostgreSQL-Version</translation>
		</message>
		<message>
			<source>PostgreSQL version is not compatible with Giswater. Please check wiki</source>
			<translation>Die PostgreSQL-Version ist nicht mit Giswater kompatibel. Bitte prüfen Sie Wiki</translation>
		</message>
		<message>
			<source>prefer</source>
			<translation>lieber</translation>
		</message>
		<message>
			<source>Preparing network...</source>
			<translation>Preparing network...</translation>
		</message>
		<message>
			<source>Price list csv file name is required</source>
			<translation>Name der csv-Datei für die Preisliste ist erforderlich</translation>
		</message>
		<message>
			<source>Price list detail csv file name is required</source>
			<translation>Price list detail csv file name is required</translation>
		</message>
		<message>
			<source>Priority Calculation (Global)</source>
			<translation>Priority Calculation (Global)</translation>
		</message>
		<message>
			<source>Prob. of Failure</source>
			<translation>Prob. of Failure</translation>
		</message>
		<message>
			<source>Processes</source>
			<translation>Processes</translation>
		</message>
		<message>
			<source>Process finished.

INP file created on:
{0}

Report file created on:
{1}</source>
			<translation>Process finished.

INP file created on:
{0}

Report file created on:
{1}</translation>
		</message>
		<message>
			<source>Process finished.

INP file created on:
{0}

Statistics file created on:
{1}</source>
			<translation>Process finished.

INP file created on:
{0}

Statistics file created on:
{1}</translation>
		</message>
		<message>
			<source>Process finished successfully</source>
			<translation>Prozess erfolgreich beendet</translation>
		</message>
		<message>
			<source>Process finished successfully: Delete schema</source>
			<translation>Prozess erfolgreich beendet: Schema löschen</translation>
		</message>
		<message>
			<source>Process finished with some errors</source>
			<translation>Prozess mit einigen Fehlern beendet</translation>
		</message>
		<message>
			<source>Processing folder</source>
			<translation>Ordner bearbeiten</translation>
		</message>
		<message>
			<source>Profile</source>
			<translation>Profile</translation>
		</message>
		<message>
			<source>Profile image path: {0}</source>
			<translation>Profile image path: {0}</translation>
		</message>
		<message>
			<source>Profile interpolation</source>
			<translation>Profile interpolation</translation>
		</message>
		<message>
			<source>Profile name is mandatory.</source>
			<translation>Der Profilname ist obligatorisch.</translation>
		</message>
		<message>
			<source>Project check task is already active!</source>
			<translation>Project check task is already active!</translation>
		</message>
		<message>
			<source>Project read finished</source>
			<translation>Projekt fertig gelesen</translation>
		</message>
		<message>
			<source>Project read finished with different versions on plugin metadata ({0}) and PostgreSQL sys_version table ({1}).</source>
			<translation>Das Projekt wurde mit unterschiedlichen Versionen in den Plugin-Metadaten ({0}) und der PostgreSQL-Tabelle sys_version ({1}) abgeschlossen.</translation>
		</message>
		<message>
			<source>Project read started</source>
			<translation>Projekt lesen gestartet</translation>
		</message>
		<message>
			<source>Psector &apos;{0}&apos; has no workcat_id value set. Do you want to continue with the default value?</source>
			<translation>Für den Sektor &apos;{0}&apos; ist kein workcat_id-Wert festgelegt. Möchten Sie mit dem Standardwert fortfahren?</translation>
		</message>
		<message>
			<source>Psector actual</source>
			<translation>Psector actual</translation>
		</message>
		<message>
			<source>Psector could not be updated because of the following errors: </source>
			<translation>Psector could not be updated because of the following errors: </translation>
		</message>
		<message>
			<source>Psector could not be updated because of the following errors: {0}</source>
			<translation>Psector could not be updated because of the following errors: {0}</translation>
		</message>
		<message>
			<source>Psector features loaded successfully on the map.</source>
			<translation>Psector Features wurden erfolgreich auf die Karte geladen.</translation>
		</message>
		<message>
			<source>Psector ID not found</source>
			<translation>Psector ID not found</translation>
		</message>
		<message>
			<source>Psector is not archived</source>
			<translation>Psector wird nicht archiviert</translation>
		</message>
		<message>
			<source>Psector name not found</source>
			<translation>Sektorname nicht gefunden</translation>
		</message>
		<message>
			<source>Psector values updated successfully</source>
			<translation>Psektorwerte erfolgreich aktualisiert</translation>
		</message>
		<message>
			<source>Pumps couldn&apos;t be inserted!</source>
			<translation>Pumps couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Python file</source>
			<translation>Python-Datei</translation>
		</message>
		<message>
			<source>Python function</source>
			<translation>Python-Funktion</translation>
		</message>
		<message>
			<source>Python package &apos;{0}&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>Python package &apos;{0}&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</translation>
		</message>
		<message>
			<source>Python package &apos;matplotlib&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>Python package &apos;matplotlib&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</translation>
		</message>
		<message>
			<source>Python package required for OSM import is not installed: {0}. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>Python package required for OSM import is not installed: {0}. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</translation>
		</message>
		<message>
			<source>Python packages</source>
			<translation>Python packages</translation>
		</message>
		<message>
			<source>Python package &apos;swmm-api&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>Python package &apos;swmm-api&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</translation>
		</message>
		<message>
			<source>Python package &apos;wntr&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>Python package &apos;wntr&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</translation>
		</message>
		<message>
			<source>Python translation canceled</source>
			<translation>Python-Übersetzung abgebrochen</translation>
		</message>
		<message>
			<source>Python translation failed</source>
			<translation>Python-Übersetzung fehlgeschlagen</translation>
		</message>
		<message>
			<source>Python translation successful</source>
			<translation>Python-Übersetzung erfolgreich</translation>
		</message>
		<message>
			<source>Python version</source>
			<translation>Python version</translation>
		</message>
		<message>
			<source>QGIS project has more than one {0} layer coming from different schemas. If you are looking to manage two schemas, it is mandatory to define which is the master and which isn&apos;t. To do this, you need to configure the QGIS project setting this project&apos;s variables: {1} and {2}.</source>
			<translation>Ein QGIS-Projekt hat mehr als einen {0}-Layer, der aus verschiedenen Schemata stammt. Wenn Sie zwei Schemata verwalten möchten, müssen Sie festlegen, welches das Master-Schema ist und welches nicht. Um dies zu tun, müssen Sie das QGIS-Projekt konfigurieren, indem Sie die Variablen dieses Projekts einstellen: {1} und {2}.</translation>
		</message>
		<message>
			<source>QGIS project seems to be a Giswater project, but layer(s) {0} are missing</source>
			<translation>QGIS project seems to be a Giswater project, but layer(s) {0} are missing</translation>
		</message>
		<message>
			<source>QGIS version</source>
			<translation>QGIS version</translation>
		</message>
		<message>
			<source>QgsLayerTree not found for project.</source>
			<translation>QgsLayerTree not found for project.</translation>
		</message>
		<message>
			<source>QML file {0} not found</source>
			<translation>QML file {0} not found</translation>
		</message>
		<message>
			<source>QML is empty!</source>
			<translation>QML is empty!</translation>
		</message>
		<message>
			<source>Quantized Demands</source>
			<translation>Quantized Demands</translation>
		</message>
		<message>
			<source>Raingages couldn&apos;t be inserted!</source>
			<translation>Raingages couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Reading file</source>
			<translation>Datei lesen</translation>
		</message>
		<message>
			<source>Reading input files...</source>
			<translation>Reading input files...</translation>
		</message>
		<message>
			<source>Real location has been updated</source>
			<translation>Der tatsächliche Standort wurde aktualisiert</translation>
		</message>
		<message>
			<source>Recommended catalogs:</source>
			<translation>Recommended catalogs:</translation>
		</message>
		<message>
			<source>Recommended feature ids:</source>
			<translation>Recommended feature ids:</translation>
		</message>
		<message>
			<source>Recommended materials:</source>
			<translation>Recommended materials:</translation>
		</message>
		<message>
			<source>Record deleted</source>
			<translation>Record deleted</translation>
		</message>
		<message>
			<source>Records deleted</source>
			<translation>Datensätze gelöscht</translation>
		</message>
		<message>
			<source>Recursive Go2Epa</source>
			<translation>Recursive Go2Epa</translation>
		</message>
		<message>
			<source>Reload failed</source>
			<translation>Reload fehlgeschlagen</translation>
		</message>
		<message>
			<source>Remaining: {0} ({1}/{2})</source>
			<translation>Remaining: {0} ({1}/{2})</translation>
		</message>
		<message>
			<source>Remove layer from project?</source>
			<translation>Ebene aus dem Projekt entfernen?</translation>
		</message>
		<message>
			<source>REMOVE NODE</source>
			<translation>REMOVE NODE</translation>
		</message>
		<message>
			<source>Remove Team Assignment</source>
			<translation>Remove Team Assignment</translation>
		</message>
		<message>
			<source>Rename project - {0}</source>
			<translation>Rename project - {0}</translation>
		</message>
		<message>
			<source>Repair cost</source>
			<translation>Repair cost</translation>
		</message>
		<message>
			<source>Replace feature</source>
			<translation>Funktion &quot;Ersetzen</translation>
		</message>
		<message>
			<source>Replace feature done successfully</source>
			<translation>Replace feature done successfully</translation>
		</message>
		<message>
			<source>Replacement cost</source>
			<translation>Replacement cost</translation>
		</message>
		<message>
			<source>Replacement rate (%/year):</source>
			<translation>Replacement rate (%/year):</translation>
		</message>
		<message>
			<source>REPLACEMENTS PER YEAR</source>
			<translation>REPLACEMENTS PER YEAR</translation>
		</message>
		<message>
			<source>Replacing template text</source>
			<translation>Ersetzen von Vorlagentext</translation>
		</message>
		<message>
			<source>REPORT</source>
			<translation>REPORT</translation>
		</message>
		<message>
			<source>Reports</source>
			<translation>Reports</translation>
		</message>
		<message>
			<source>Reports generated successfully</source>
			<translation>Reports generated successfully</translation>
		</message>
		<message>
			<source>Required fields are missing</source>
			<translation>Erforderliche Felder fehlen</translation>
		</message>
		<message>
			<source>Reservoirs couldn&apos;t be inserted!</source>
			<translation>Reservoirs couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Reset position form done successfully.</source>
			<translation>Zurücksetzen des Positionsformulars erfolgreich durchgeführt.</translation>
		</message>
		<message>
			<source>resolve_combo_valuemap: failed to load values for &apos;{0}&apos;: {1}</source>
			<translation>resolve_combo_valuemap: failed to load values for &apos;{0}&apos;: {1}</translation>
		</message>
		<message>
			<source>Response from {0} is not a ZIP archive</source>
			<translation>Response from {0} is not a ZIP archive</translation>
		</message>
		<message>
			<source>Result name</source>
			<translation>Ergebnis Name</translation>
		</message>
		<message>
			<source>Result name already exists, do you want overwrite?</source>
			<translation>Der Ergebnisname ist bereits vorhanden, möchten Sie ihn überschreiben?</translation>
		</message>
		<message>
			<source>Result name not found. It&apos;s not possible to import RPT file into database</source>
			<translation>Ergebnisname nicht gefunden. Es ist nicht möglich, die RPT-Datei in die Datenbank zu importieren.</translation>
		</message>
		<message>
			<source>Retrieving process ({0}/{1})...</source>
			<translation>Prozess abrufen ({0}/{1})...</translation>
		</message>
		<message>
			<source>Rotation must be a number.</source>
			<translation>Rotation must be a number.</translation>
		</message>
		<message>
			<source>Rpt fail</source>
			<translation>Rpt fehlgeschlagen</translation>
		</message>
		<message>
			<source>RPT file path is required when importing results or executing EPA</source>
			<translation>RPT file path is required when importing results or executing EPA</translation>
		</message>
		<message>
			<source>Running simulation...</source>
			<translation>Running simulation...</translation>
		</message>
		<message>
			<source>Sample projects are only allowed with locales en_US, es_ES, ca_ES or es_CR, and SRID 25831.
Do you want to apply the required values and continue?</source>
			<translation>Sample projects are only allowed with locales en_US, es_ES, ca_ES or es_CR, and SRID 25831.
Do you want to apply the required values and continue?</translation>
		</message>
		<message>
			<source>Save feature</source>
			<translation>Save feature</translation>
		</message>
		<message>
			<source>Save these changes to campaign selector?</source>
			<translation>Save these changes to campaign selector?</translation>
		</message>
		<message>
			<source>Saving INP file...</source>
			<translation>Saving INP file...</translation>
		</message>
		<message>
			<source>Saving output files...</source>
			<translation>Saving output files...</translation>
		</message>
		<message>
			<source>Saving statistics file...</source>
			<translation>Saving statistics file...</translation>
		</message>
		<message>
			<source>Scada graph</source>
			<translation>Scada graph</translation>
		</message>
		<message>
			<source>Scada graph edge already exists.</source>
			<translation>Scada graph edge already exists.</translation>
		</message>
		<message>
			<source>Scada graph edge created</source>
			<translation>Scada graph edge created</translation>
		</message>
		<message>
			<source>Scada graph saved in DB but v_om_scada_graph layer could not be loaded.</source>
			<translation>Scada graph saved in DB but v_om_scada_graph layer could not be loaded.</translation>
		</message>
		<message>
			<source>Scale must be a number.</source>
			<translation>Scale must be a number.</translation>
		</message>
		<message>
			<source>Schema</source>
			<translation>Schema</translation>
		</message>
		<message>
			<source>Schema: {0}</source>
			<translation>Schema: {0}</translation>
		</message>
		<message>
			<source>Schema audit not found, please create it first</source>
			<translation>Schema-Audit nicht gefunden, bitte erstellen Sie es zuerst</translation>
		</message>
		<message>
			<source>SchemaBuilder exception: {0}</source>
			<translation>SchemaBuilder exception: {0}</translation>
		</message>
		<message>
			<source>SchemaBuilder failed: {0}</source>
			<translation>SchemaBuilder failed: {0}</translation>
		</message>
		<message>
			<source>SchemaBuilder failed without first_failure</source>
			<translation>SchemaBuilder failed without first_failure</translation>
		</message>
		<message>
			<source>Schema cibs already exists.</source>
			<translation>Schema cibs already exists.</translation>
		</message>
		<message>
			<source>Schema multilang already exists.</source>
			<translation>Schema multilang already exists.</translation>
		</message>
		<message>
			<source>Schema name</source>
			<translation>Name des Schemas</translation>
		</message>
		<message>
			<source>Schema: select a row below</source>
			<translation>Schema: select a row below</translation>
		</message>
		<message>
			<source>Schema Utils already exist.</source>
			<translation>Schema Utils already exist.</translation>
		</message>
		<message>
			<source>Schema vacuum executed</source>
			<translation>Schema Vakuum ausgeführt</translation>
		</message>
		<message>
			<source>Schema version</source>
			<translation>Schema version</translation>
		</message>
		<message>
			<source>Seeding {0} ({1}/{2})</source>
			<translation>Seeding {0} ({1}/{2})</translation>
		</message>
		<message>
			<source>Seeding multilang translations for ({0})...</source>
			<translation>Seeding multilang translations for ({0})...</translation>
		</message>
		<message>
			<source>Seed multilang translations?</source>
			<translation>Seed multilang translations?</translation>
		</message>
		<message>
			<source>Seed multilang translations for ({0})</source>
			<translation>Seed multilang translations for ({0})</translation>
		</message>
		<message>
			<source>Select a campaign to create a child campaign.</source>
			<translation>Select a campaign to create a child campaign.</translation>
		</message>
		<message>
			<source>Select a campaign to delete.</source>
			<translation>Wählen Sie eine zu löschende Kampagne aus.</translation>
		</message>
		<message>
			<source>Select a language</source>
			<translation>Select a language</translation>
		</message>
		<message>
			<source>Select a language to manage</source>
			<translation>Select a language to manage</translation>
		</message>
		<message>
			<source>Select a locale</source>
			<translation>Select a locale</translation>
		</message>
		<message>
			<source>Select a lot to delete</source>
			<translation>Select a lot to delete</translation>
		</message>
		<message>
			<source>Select an arc to start inundation analysis.</source>
			<translation>Select an arc to start inundation analysis.</translation>
		</message>
		<message>
			<source>Select a network anchor to copy cibs data.</source>
			<translation>Select a network anchor to copy cibs data.</translation>
		</message>
		<message>
			<source>Select a network anchor to integrate cibs.</source>
			<translation>Select a network anchor to integrate cibs.</translation>
		</message>
		<message>
			<source>Select a schema</source>
			<translation>Select a schema</translation>
		</message>
		<message>
			<source>Select a schema to see the Multilang language currently used.</source>
			<translation>Select a schema to see the Multilang language currently used.</translation>
		</message>
		<message>
			<source>Select a UD schema to integrate.</source>
			<translation>Select a UD schema to integrate.</translation>
		</message>
		<message>
			<source>Select a workorder to delete</source>
			<translation>Select a workorder to delete</translation>
		</message>
		<message>
			<source>Select a WS anchor in the network table.</source>
			<translation>Select a WS anchor in the network table.</translation>
		</message>
		<message>
			<source>Select a WS or UD anchor in the network table.</source>
			<translation>Select a WS or UD anchor in the network table.</translation>
		</message>
		<message>
			<source>Select a WS or UD schema for the cibs operation</source>
			<translation>Select a WS or UD schema for the cibs operation</translation>
		</message>
		<message>
			<source>Select a WS or UD schema in the table.</source>
			<translation>Select a WS or UD schema in the table.</translation>
		</message>
		<message>
			<source>Select a WS or UD schema to adapt to cibs</source>
			<translation>Select a WS or UD schema to adapt to cibs</translation>
		</message>
		<message>
			<source>Select a WS or UD schema to copy data to cibs</source>
			<translation>Select a WS or UD schema to copy data to cibs</translation>
		</message>
		<message>
			<source>Select a WS schema to integrate.</source>
			<translation>Select a WS schema to integrate.</translation>
		</message>
		<message>
			<source>Select a WS/UD anchor in the network table.</source>
			<translation>Select a WS/UD anchor in the network table.</translation>
		</message>
		<message>
			<source>Select connecs or gullies with qgis tool and use right click to connect them with network. CTRL + SHIFT over selection to remove it</source>
			<translation>Wählen Sie Verbindungen oder Gullys mit dem qgis-Tool aus und klicken Sie mit der rechten Maustaste, um sie mit dem Netzwerk zu verbinden. CTRL + SHIFT über der Auswahl, um sie zu entfernen</translation>
		</message>
		<message>
			<source>Selected {0}</source>
			<translation>Ausgewählt {0}</translation>
		</message>
		<message>
			<source>Selected date interval is not valid</source>
			<translation>Ausgewähltes Datumsintervall ist nicht gültig</translation>
		</message>
		<message>
			<source>Selected element already in the list</source>
			<translation>Ausgewähltes Element bereits in der Liste</translation>
		</message>
		<message>
			<source>Selected hydrometer_id not found</source>
			<translation>Ausgewählte Aräometer_id nicht gefunden</translation>
		</message>
		<message>
			<source>Selected node</source>
			<translation>Ausgewählter Knoten</translation>
		</message>
		<message>
			<source>Selected schema is already adapted to cibs.</source>
			<translation>Selected schema is already adapted to cibs.</translation>
		</message>
		<message>
			<source>Selected schema is already integrated with utils.</source>
			<translation>Selected schema is already integrated with utils.</translation>
		</message>
		<message>
			<source>Selected schema must be adapted to cibs before copying data</source>
			<translation>Selected schema must be adapted to cibs before copying data</translation>
		</message>
		<message>
			<source>Selected schema not found</source>
			<translation>Ausgewähltes Schema nicht gefunden</translation>
		</message>
		<message>
			<source>Selected snapped feature_id to copy values from</source>
			<translation>Ausgewähltes gerastertes Merkmal_id zum Kopieren von Werten aus</translation>
		</message>
		<message>
			<source>Selected snapped feature_id to copy values from: {0}
Do you want to copy its values to the current node?

{1}</source>
			<translation>Selected snapped feature_id to copy values from: {0}
Do you want to copy its values to the current node?

{1}</translation>
		</message>
		<message>
			<source>Selected styles updated successfully!</source>
			<translation>Ausgewählte Stile erfolgreich aktualisiert!</translation>
		</message>
		<message>
			<source>Selected styles were successfully deleted.</source>
			<translation>Ausgewählte Stile wurden erfolgreich gelöscht.</translation>
		</message>
		<message>
			<source>Select Feature(s)</source>
			<translation>Select Feature(s)</translation>
		</message>
		<message>
			<source>Select features by expression</source>
			<translation>Select features by expression</translation>
		</message>
		<message>
			<source>Select Features by Freehand</source>
			<translation>Select Features by Freehand</translation>
		</message>
		<message>
			<source>Select Features by Polygon</source>
			<translation>Select Features by Polygon</translation>
		</message>
		<message>
			<source>Select Features by Radius</source>
			<translation>Select Features by Radius</translation>
		</message>
		<message>
			<source>Select folder</source>
			<translation>Select folder</translation>
		</message>
		<message>
			<source>Select INP file</source>
			<translation>INP-Datei auswählen</translation>
		</message>
		<message>
			<source>Select just one document</source>
			<translation>Nur ein Dokument auswählen</translation>
		</message>
		<message>
			<source>Select just one visit</source>
			<translation>Wählen Sie nur einen Besuch</translation>
		</message>
		<message>
			<source>Select new team:</source>
			<translation>Select new team:</translation>
		</message>
		<message>
			<source>Select one</source>
			<translation>Wählen Sie eine</translation>
		</message>
		<message>
			<source>selector</source>
			<translation>selector</translation>
		</message>
		<message>
			<source>Selector help</source>
			<translation>Selektor-Hilfe</translation>
		</message>
		<message>
			<source>Select RPT file</source>
			<translation>RPT-Datei auswählen</translation>
		</message>
		<message>
			<source>Select the arc to perform a visual execution</source>
			<translation>Select the arc to perform a visual execution</translation>
		</message>
		<message>
			<source>Select valid INP file</source>
			<translation>Gültige INP-Datei auswählen</translation>
		</message>
		<message>
			<source>Select valid RPT file</source>
			<translation>Gültige RPT-Datei auswählen</translation>
		</message>
		<message>
			<source>SERVER RESPONSE</source>
			<translation>SERVER-REAKTION</translation>
		</message>
		<message>
			<source>Service database connection error (psycopg2). Please open plugin log file to get more details</source>
			<translation>Service database connection error (psycopg2). Please open plugin log file to get more details</translation>
		</message>
		<message>
			<source>Service database connection error (QSqlDatabase). Please open plugin log file to get more details</source>
			<translation>Service database connection error (QSqlDatabase). Please open plugin log file to get more details</translation>
		</message>
		<message>
			<source>Set rpt archived execution successful.</source>
			<translation>Set rpt archiviert Ausführung erfolgreich.</translation>
		</message>
		<message>
			<source>SHAPE</source>
			<translation>SHAPE</translation>
		</message>
		<message>
			<source>Shift+Click to uncheck all</source>
			<translation>Shift+Click to uncheck all</translation>
		</message>
		<message>
			<source>Show</source>
			<translation>Show</translation>
		</message>
		<message>
			<source>Show selection on top</source>
			<translation>Show selection on top</translation>
		</message>
		<message>
			<source>Skipping map highlighting for very large dataset ({0} features)</source>
			<translation>Skipping map highlighting for very large dataset ({0} features)</translation>
		</message>
		<message>
			<source>Snapped feature is not in a valid layer</source>
			<translation>Snapped feature is not in a valid layer</translation>
		</message>
		<message>
			<source>Some data is missing. Check gis_length for arc</source>
			<translation>Es fehlen einige Daten. Prüfen Sie gis_length für arc</translation>
		</message>
		<message>
			<source>Some mandatory fields are missing. Please fill the required fields (marked in red).</source>
			<translation>Some mandatory fields are missing. Please fill the required fields (marked in red).</translation>
		</message>
		<message>
			<source>Some mandatory values are missing. Please check the widgets marked in red.</source>
			<translation>Es fehlen einige obligatorische Werte. Bitte überprüfen Sie die rot markierten Widgets.</translation>
		</message>
		<message>
			<source>Sources</source>
			<translation>Sources</translation>
		</message>
		<message>
			<source>SQL</source>
			<translation>SQL</translation>
		</message>
		<message>
			<source>SQL: {0}</source>
			<translation>SQL: {0}</translation>
		</message>
		<message>
			<source>SQL Context</source>
			<translation>SQL Context</translation>
		</message>
		<message>
			<source>SQL execution failed.</source>
			<translation>SQL execution failed.</translation>
		</message>
		<message>
			<source>SQL File</source>
			<translation>SQL-Dateien</translation>
		</message>
		<message>
			<source>SQL folder not found</source>
			<translation>SQL-Ordner nicht gefunden</translation>
		</message>
		<message>
			<source>SRID</source>
			<translation>SRID</translation>
		</message>
		<message>
			<source>Started task &apos;{0}&apos;</source>
			<translation>Gestartete Aufgabe &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Started task {0}</source>
			<translation>Gestartete Aufgabe {0}</translation>
		</message>
		<message>
			<source>Starting execute_vacuum method</source>
			<translation>Starten der Methode execute_vacuum</translation>
		</message>
		<message>
			<source>Starting process...</source>
			<translation>Prozess starten...</translation>
		</message>
		<message>
			<source>Static Calibration</source>
			<translation>Static Calibration</translation>
		</message>
		<message>
			<source>Storage units couldn&apos;t be inserted!</source>
			<translation>Storage units couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Style group &apos;{0}&apos; and related entries have been deleted.</source>
			<translation>Die Stilgruppe &apos;{0}&apos; und die zugehörigen Einträge wurden gelöscht.</translation>
		</message>
		<message>
			<source>Successfully assigned team &apos;{0}&apos; to {1} user(s).</source>
			<translation>Successfully assigned team &apos;{0}&apos; to {1} user(s).</translation>
		</message>
		<message>
			<source>Successfully changed to team &apos;{0}&apos; for {1} user(s).</source>
			<translation>Successfully changed to team &apos;{0}&apos; for {1} user(s).</translation>
		</message>
		<message>
			<source>Successfully removed team assignment from {0} user(s).</source>
			<translation>Successfully removed team assignment from {0} user(s).</translation>
		</message>
		<message>
			<source>SUCCESS IN DUPLICATING PSECTOR</source>
			<translation>SUCCESS IN DUPLICATING PSECTOR</translation>
		</message>
		<message>
			<source>SUMMARY</source>
			<translation>SUMMARY</translation>
		</message>
		<message>
			<source>Table not found</source>
			<translation>Tabelle nicht gefunden</translation>
		</message>
		<message>
			<source>Table not found: &apos;{0}&apos;</source>
			<translation>Tabelle nicht gefunden: &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Table not found: {0}</source>
			<translation>Tabelle nicht gefunden: {0}</translation>
		</message>
		<message>
			<source>Tab not found.</source>
			<translation>Tab not found.</translation>
		</message>
		<message>
			<source>Tanks couldn&apos;t be inserted!</source>
			<translation>Tanks couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; completed</source>
			<translation>Aufgabe &apos;{0}&apos; abgeschlossen</translation>
		</message>
		<message>
			<source>Task {0} completed
</source>
			<translation>Task {0} completed</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; Exception: {1}</source>
			<translation>Aufgabe &apos;{0}&apos; Exception: {1}</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; execute function &apos;{1}&apos;</source>
			<translation>Task &apos;{0}&apos; execute function &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; execute procedure &apos;{1}&apos; with parameters: &apos;{2}&apos;, &apos;{3}&apos;, &apos;{4}&apos;</source>
			<translation>Aufgabe &apos;{0}&apos; führt Prozedur &apos;{1}&apos; aus mit Parametern: &apos;{2}&apos;, &apos;{3}&apos;, &apos;{4}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; manage json response</source>
			<translation>Task &apos;{0}&apos; manage json response</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; manage json response with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Aufgabe &apos;{0}&apos; verwaltet json-Antwort mit Parametern: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; not successful but without exception</source>
			<translation>Aufgabe &apos;{0}&apos; nicht erfolgreich, aber ohne Ausnahme</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; was cancelled</source>
			<translation>Aufgabe &apos;{0}&apos; wurde abgebrochen</translation>
		</message>
		<message>
			<source>Task aborted - {0}</source>
			<translation>Aufgabe abgebrochen - {0}</translation>
		</message>
		<message>
			<source>Task aborted: {0}.</source>
			<translation>Aufgabe abgebrochen: {0}.</translation>
		</message>
		<message>
			<source>Task canceled!</source>
			<translation>Task canceled!</translation>
		</message>
		<message>
			<source>Task canceled.</source>
			<translation>Task canceled.</translation>
		</message>
		<message>
			<source>Task canceled:</source>
			<translation>Task canceled:</translation>
		</message>
		<message>
			<source>Task canceled - {0}</source>
			<translation>Aufgabe abgebrochen - {0}</translation>
		</message>
		<message>
			<source>Task &apos;Check project&apos; execute function &apos;{0}&apos;</source>
			<translation>Aufgabe &apos;Projekt prüfen&apos; Funktion &apos;{0}&apos; ausführen</translation>
		</message>
		<message>
			<source>task_completed</source>
			<translation>aufgabe_erledigt</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute function &apos;{0}&apos; from &apos;{1}&apos; with parameters: &apos;{2}&apos;</source>
			<translation>Aufgabe &apos;Link verbinden&apos; führt Funktion &apos;{0}&apos; aus &apos;{1}&apos; mit Parametern: &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute function &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;</source>
			<translation>Aufgabe &apos;Link verbinden&apos; führt Funktion &apos;{0}&apos; aus mit Parametern: &apos;{1}&apos;, &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute procedure &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Aufgabe &apos;Link verbinden&apos; führt Prozedur &apos;{0}&apos; mit den Parametern: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos; aus</translation>
		</message>
		<message>
			<source>Task failed: {0}. This is probably a DB error, check postgres function &apos;{1}&apos;.</source>
			<translation>Aufgabe fehlgeschlagen: {0}. Dies ist wahrscheinlich ein DB-Fehler, prüfen Sie die Postgres-Funktion &apos;{1}&apos;.</translation>
		</message>
		<message>
			<source>Task finished!</source>
			<translation>Task finished!</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;{0}&apos;</source>
			<translation>Aufgabe &apos;Go2Epa&apos; führt Funktion &apos;{0}&apos; aus</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;{0}&apos; from &apos;{1}&apos;</source>
			<translation>Aufgabe &apos;Go2Epa&apos; führt Funktion &apos;{0}&apos; aus &apos;{1}&apos; aus</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;def _exec_import_function&apos;</source>
			<translation>Aufgabe &apos;Go2Epa&apos; Funktion &apos;def _exec_import_function&apos; ausführen</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{0}&apos; step {1}</source>
			<translation>Aufgabe &apos;Go2Epa&apos; Ausführen der Prozedur &apos;{0}&apos; Schritt {1}</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{1}&apos; step {2} with parameters: &apos;{1}&apos;, &apos;{3}&apos;, &apos;{4}&apos;, &apos;{5}&apos;, &apos;{6}&apos;</source>
			<translation>Aufgabe &apos;Go2Epa&apos; führt Prozedur &apos;{1}&apos; Schritt {2} aus mit Parametern: &apos;{1}&apos;, &apos;{3}&apos;, &apos;{4}&apos;, &apos;{5}&apos;, &apos;{6}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Mincut execute&apos; execute procedure &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Aufgabe &apos;Mincut execute&apos; führt Prozedur &apos;{0}&apos; mit den Parametern: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos; aus</translation>
		</message>
		<message>
			<source>Task &apos;Mincut execute&apos; manage json response with parameters: &apos;{0}&apos;, &apos;{1}&apos;, &apos;{2}&apos;</source>
			<translation>Aufgabe &apos;Mincut execute&apos; verwaltet json-Antwort mit Parametern: &apos;{0}&apos;, &apos;{1}&apos;, &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Template not managed: {0}</source>
			<translation>Vorlage wird nicht verwaltet: {0}</translation>
		</message>
		<message>
			<source>Temporal layer created successfully.</source>
			<translation>Zeitliche Ebene erfolgreich erstellt.</translation>
		</message>
		<message>
			<source>The &quot;{0}&quot; curve does not have a specified curve type and was not imported.</source>
			<translation>The &quot;{0}&quot; curve does not have a specified curve type and was not imported.</translation>
		</message>
		<message>
			<source>The &apos;{0}&apos; field is required.</source>
			<translation>Das Feld &apos;{0}&apos; ist erforderlich.</translation>
		</message>
		<message>
			<source>The base language (en_US) cannot be deleted.</source>
			<translation>The base language (en_US) cannot be deleted.</translation>
		</message>
		<message>
			<source>The configuration file doesn&apos;t match the selected INP file. Some options may not be loaded or may be incorrect. Do you want to continue?</source>
			<translation>Die Konfigurationsdatei stimmt nicht mit der ausgewählten INP-Datei überein. Einige Optionen sind möglicherweise nicht geladen oder falsch. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>The connection to the database is broken.</source>
			<translation>The connection to the database is broken.</translation>
		</message>
		<message>
			<source>The connection to the database is broken: {0}</source>
			<translation>Die Verbindung zur Datenbank ist unterbrochen: {0}</translation>
		</message>
		<message>
			<source>The control &apos;{0}&apos; is already on database. Skipping...</source>
			<translation>The control &apos;{0}&apos; is already on database. Skipping...</translation>
		</message>
		<message>
			<source>The csv file has been successfully exported</source>
			<translation>Die csv-Datei wurde erfolgreich exportiert</translation>
		</message>
		<message>
			<source>The curve &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing curve.</source>
			<translation>The curve &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing curve.</translation>
		</message>
		<message>
			<source>The &apos;Description&apos; field is required.</source>
			<translation>Das Feld &quot;Beschreibung&quot; ist erforderlich.</translation>
		</message>
		<message>
			<source>The field layoutname is not configured for</source>
			<translation>Das Feld layoutname ist nicht konfiguriert für</translation>
		</message>
		<message>
			<source>The field layoutorder is not configured for</source>
			<translation>Das Feld layoutorder ist nicht konfiguriert für</translation>
		</message>
		<message>
			<source>The field widgettype is not configured for</source>
			<translation>Das Feld widgettype ist nicht konfiguriert für</translation>
		</message>
		<message>
			<source>The fifth tab is the &apos;Arcs&apos; tab, where you can select the catalog for each type of arc on the network.</source>
			<translation>Die fünfte Registerkarte ist die Registerkarte &quot;Bögen&quot;, auf der Sie den Katalog für jede Art von Bogen im Netz auswählen können.</translation>
		</message>
		<message>
			<source>The file {0} already exists. Do you want to overwrite it?</source>
			<translation>Die Datei {0} existiert bereits. Möchten Sie sie überschreiben?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.csv&quot; already exists. Do you want to overwrite it?</source>
			<translation>The file &quot;{0}.csv&quot; already exists. Do you want to overwrite it?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.in&quot; already exists. Do you want to overwrite it?</source>
			<translation>The file &quot;{0}.in&quot; already exists. Do you want to overwrite it?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.inp&quot; already exists. Do you want to overwrite it?</source>
			<translation>The file &quot;{0}.inp&quot; already exists. Do you want to overwrite it?</translation>
		</message>
		<message>
			<source>The files {0} already exist. Do you want to overwrite them?</source>
			<translation>Die Dateien {0} existieren bereits. Möchten Sie sie überschreiben?</translation>
		</message>
		<message>
			<source>The files &quot;{0}.in&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</source>
			<translation>The files &quot;{0}.in&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</translation>
		</message>
		<message>
			<source>The files &quot;{0}.inp&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</source>
			<translation>The files &quot;{0}.inp&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</translation>
		</message>
		<message>
			<source>The file selected is not a GPKG file</source>
			<translation>Die ausgewählte Datei ist keine GPKG-Datei</translation>
		</message>
		<message>
			<source>The file selected is not an INP file</source>
			<translation>Die ausgewählte Datei ist keine INP-Datei</translation>
		</message>
		<message>
			<source>The first tab is the &apos;Basic&apos; tab, where you can select the exploitation, sector, municipality, and other basic information.</source>
			<translation>Die erste Registerkarte ist die &quot;Basis&quot;-Registerkarte, auf der Sie den Betrieb, den Sektor, die Gemeinde und andere grundlegende Informationen auswählen können.</translation>
		</message>
		<message>
			<source>The flow data timestep must be a multiple of the desired timestep.</source>
			<translation>The flow data timestep must be a multiple of the desired timestep.</translation>
		</message>
		<message>
			<source>The following fields differ between the selected arcs. You are about to merge them using the selected values.

{0}

Do you want to continue?</source>
			<translation>The following fields differ between the selected arcs. You are about to merge them using the selected values.

{0}

Do you want to continue?</translation>
		</message>
		<message>
			<source>The fourth tab is the &apos;Nodes&apos; tab, where you can select the catalog for each type of node on the network.</source>
			<translation>Die vierte Registerkarte ist die Registerkarte &quot;Knoten&quot;, auf der Sie den Katalog für jede Art von Knoten im Netzwerk auswählen können.</translation>
		</message>
		<message>
			<source>The hour value must be between 0 and 23, inclusive. Value supplied: {0}</source>
			<translation>The hour value must be between 0 and 23, inclusive. Value supplied: {0}</translation>
		</message>
		<message>
			<source>The [JUNCTIONS] section of the configuration file is empty.</source>
			<translation>Der Abschnitt [JUNCTIONS] in der Konfigurationsdatei ist leer.</translation>
		</message>
		<message>
			<source>The lid &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing lid.</source>
			<translation>The lid &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing lid.</translation>
		</message>
		<message>
			<source>The link &apos;{0}&apos; does not exist in the network.</source>
			<translation>The link &apos;{0}&apos; does not exist in the network.</translation>
		</message>
		<message>
			<source>The link &apos;{0}&apos; is not a pump.</source>
			<translation>The link &apos;{0}&apos; is not a pump.</translation>
		</message>
		<message>
			<source>The link &apos;{0}&apos; is not a valve.</source>
			<translation>The link &apos;{0}&apos; is not a valve.</translation>
		</message>
		<message>
			<source>The multilang language has been changed. To update the TOC and toolbar tooltips language, restart QGIS.</source>
			<translation>The multilang language has been changed. To update the TOC and toolbar tooltips language, restart QGIS.</translation>
		</message>
		<message>
			<source>The name is current in use</source>
			<translation>Der Name ist derzeit in Gebrauch</translation>
		</message>
		<message>
			<source>The node &apos;{0}&apos; does not exist in the network.</source>
			<translation>The node &apos;{0}&apos; does not exist in the network.</translation>
		</message>
		<message>
			<source>The node is obsolete, this tool doesn&apos;t work with obsolete nodes.</source>
			<translation>Der Knoten ist veraltet, dieses Tool funktioniert nicht mit veralteten Knoten.</translation>
		</message>
		<message>
			<source>The notes of this release are published on GitHub.</source>
			<translation>The notes of this release are published on GitHub.</translation>
		</message>
		<message>
			<source>The number of pages in your composition does not match the number of psectors. ({0} != {1})</source>
			<translation>The number of pages in your composition does not match the number of psectors. ({0} != {1})</translation>
		</message>
		<message>
			<source>The pattern &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing pattern.</source>
			<translation>The pattern &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing pattern.</translation>
		</message>
		<message>
			<source>The procedure will delete features on database unless it is a node that doesn&apos;t divide arcs.
Please ensure that features has no undelete value on true.
On the other hand you must know that traceability table will storage precedent information.</source>
			<translation>The procedure will delete features on database unless it is a node that doesn&apos;t divide arcs.
Please ensure that features has no undelete value on true.
On the other hand you must know that traceability table will storage precedent information.</translation>
		</message>
		<message>
			<source>The process has been executed. Files generated:</source>
			<translation>Der Prozess wurde ausgeführt. Erstellte Dateien:</translation>
		</message>
		<message>
			<source>The project name can&apos;t be a PostgreSQL reserved keyword</source>
			<translation>Der Projektname kann kein von PostgreSQL reserviertes Schlüsselwort sein</translation>
		</message>
		<message>
			<source>The project name can&apos;t have any upper-case characters</source>
			<translation>Der Projektname darf keine Großbuchstaben enthalten</translation>
		</message>
		<message>
			<source>The project name has invalid character</source>
			<translation>Der Projektname enthält ungültige Zeichen</translation>
		</message>
		<message>
			<source>The QGIS Projects templates was correctly created.</source>
			<translation>Die QGIS Projects Vorlagen wurden korrekt erstellt.</translation>
		</message>
		<message>
			<source>The QML file is invalid</source>
			<translation>Die QML-Datei ist ungültig</translation>
		</message>
		<message>
			<source>The QML file is invalid.</source>
			<translation>Die QML-Datei ist ungültig.</translation>
		</message>
		<message>
			<source>There are missing values in these nodes:</source>
			<translation>In diesen Knotenpunkten fehlen Werte:</translation>
		</message>
		<message>
			<source>There are multiple queries configured. These are the lists that will be used. Do you want to continue?</source>
			<translation>Es sind mehrere Abfragen konfiguriert. Dies sind die Listen, die verwendet werden sollen. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>There are multple tabs in order to configure all the necessary catalogs.</source>
			<translation>Es gibt mehrere Registerkarten, um alle notwendigen Kataloge zu konfigurieren.</translation>
		</message>
		<message>
			<source>There are no results available to display.</source>
			<translation>Es sind keine Ergebnisse vorhanden, die angezeigt werden können.</translation>
		</message>
		<message>
			<source>There are no visible mincuts in the table. Try a different filter or make one</source>
			<translation>In der Tabelle gibt es keine sichtbaren Mincuts. Versuchen Sie einen anderen Filter oder erstellen Sie einen</translation>
		</message>
		<message>
			<source>There are some error in the records with id</source>
			<translation>There are some error in the records with id</translation>
		</message>
		<message>
			<source>There are some topological inconsistences on psector &apos;{0}&apos;. Would you like to see the log?</source>
			<translation>There are some topological inconsistences on psector &apos;{0}&apos;. Would you like to see the log?</translation>
		</message>
		<message>
			<source>There have been errors translating:</source>
			<translation>Bei der Übersetzung sind Fehler aufgetreten:</translation>
		</message>
		<message>
			<source>There is an error in the configuration of the pgservice file, please check it or consult your administrator</source>
			<translation>Es liegt ein Fehler in der Konfiguration der pgservice-Datei vor, bitte überprüfen Sie diese oder wenden Sie sich an Ihren Administrator</translation>
		</message>
		<message>
			<source>There is an error in the configuration of the pgservice file, please check it or consult your administrator ({0})</source>
			<translation>There is an error in the configuration of the pgservice file, please check it or consult your administrator ({0})</translation>
		</message>
		<message>
			<source>There is another function dialog open.</source>
			<translation>There is another function dialog open.</translation>
		</message>
		<message>
			<source>There is another report open. Please close it first.</source>
			<translation>There is another report open. Please close it first.</translation>
		</message>
		<message>
			<source>There is a partially completed file for this folder/file name. Would you like to resume the process?</source>
			<translation>Es gibt eine teilweise abgeschlossene Datei für diesen Ordner/Dateinamen. Möchten Sie den Vorgang fortsetzen?</translation>
		</message>
		<message>
			<source>There is no data in table anl_arc for fid=491 and current user.</source>
			<translation>Es gibt keine Daten in der Tabelle anl_arc für fid=491 und den aktuellen Benutzer.</translation>
		</message>
		<message>
			<source>There is no data in table anl_arc for fid=493 and current user.</source>
			<translation>Es gibt keine Daten in der Tabelle anl_arc für fid=493 und den aktuellen Benutzer.</translation>
		</message>
		<message>
			<source>There is no layer related to {0}.</source>
			<translation>There is no layer related to {0}.</translation>
		</message>
		<message>
			<source>There is no project selected or it is not valid. Please check the first tab...</source>
			<translation>Es ist kein Projekt ausgewählt oder es ist nicht gültig. Bitte überprüfen Sie die erste Registerkarte...</translation>
		</message>
		<message>
			<source>There is no valid shape curve in the list</source>
			<translation>Es gibt keine gültige Formkurve in der Liste</translation>
		</message>
		<message>
			<source>The result cannot be deleted</source>
			<translation>Das Ergebnis kann nicht gelöscht werden</translation>
		</message>
		<message>
			<source>There was an error deleting object.</source>
			<translation>Es ist ein Fehler beim Löschen des Objekts aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error deleting object values.</source>
			<translation>Es ist ein Fehler beim Löschen von Objektwerten aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error deleting old curve values.</source>
			<translation>Beim Löschen alter Kurvenwerte ist ein Fehler aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error deleting old lid values.</source>
			<translation>Beim Löschen alter Deckelwerte ist ein Fehler aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error deleting old pattern values.</source>
			<translation>Beim Löschen alter Musterwerte ist ein Fehler aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error deleting old timeseries values.</source>
			<translation>Beim Löschen alter Zeitreihenwerte ist ein Fehler aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error inserting control.</source>
			<translation>Es ist ein Fehler beim Einfügen der Kontrolle aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error inserting curve.</source>
			<translation>Es ist ein Fehler beim Einfügen der Kurve aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error inserting curve value.</source>
			<translation>Es ist ein Fehler beim Einfügen des Kurvenwertes aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error inserting lid.</source>
			<translation>Beim Einfügen des Deckels ist ein Fehler aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error inserting pattern.</source>
			<translation>Es ist ein Fehler beim Einfügen des Musters aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error inserting pattern value.</source>
			<translation>Es ist ein Fehler beim Einfügen des Musterwertes aufgetreten.</translation>
		</message>
		<message>
			<source>There was an error inserting timeseries.</source>
			<translation>Beim Einfügen der Zeitreihe ist ein Fehler aufgetreten.</translation>
		</message>
		<message>
			<source>There were velocities &gt;50 in the rpt file. You have activated the option to force the import so they have been set to 50.</source>
			<translation>In der rpt-Datei waren Geschwindigkeiten &gt;50 vorhanden. Sie haben die Option aktiviert, den Import zu erzwingen, so dass sie auf 50 gesetzt wurden.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlaped, it seems you need to improve your simulation. Please ckeck and fix it before continue. 
{0}</source>
			<translation>The rpt file is not valid to import. Because columns on rpt file are overlaped, it seems you need to improve your simulation. Please ckeck and fix it before continue. 
{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlapped, it seems you need to improve your simulation. Please check and fix it before continuing.
{0}</source>
			<translation>The rpt file is not valid to import. Because columns on rpt file are overlapped, it seems you need to improve your simulation. Please check and fix it before continuing.
{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. 
{0}</source>
			<translation>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. 
{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. 
Note: You can force the import by activating the variable &apos;{0}&apos; on the {1} file. 
{2}</source>
			<translation>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. 
Note: You can force the import by activating the variable &apos;{0}&apos; on the {1} file. 
{2}</translation>
		</message>
		<message>
			<source>The rule &apos;{0}&apos; is already on database. Skipping...</source>
			<translation>The rule &apos;{0}&apos; is already on database. Skipping...</translation>
		</message>
		<message>
			<source>The [SCENARIOS] section of the configuration file is empty.</source>
			<translation>Der Abschnitt [SCENARIOS] in der Konfigurationsdatei ist leer.</translation>
		</message>
		<message>
			<source>The schema &apos;{0}&apos; is being used in production! It can&apos;t be deleted.</source>
			<translation>Das Schema &apos;{0}&apos; wird in der Produktion verwendet! Es kann nicht gelöscht werden.</translation>
		</message>
		<message>
			<source>The schema version has to be updated to make rename</source>
			<translation>The schema version has to be updated to make rename</translation>
		</message>
		<message>
			<source>These are the lists that will be used. Do you want to continue?</source>
			<translation>Dies sind die Listen, die verwendet werden. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>The second tab is the &apos;Features&apos; tab, where you can select the corresponding feature classes for each type of feature on the network.</source>
			<translation>Die zweite Registerkarte ist die Registerkarte &quot;Merkmale&quot;, auf der Sie die entsprechenden Merkmalsklassen für jede Art von Merkmal im Netz auswählen können.</translation>
		</message>
		<message>
			<source>The selected node is planified in another psector.
Node psector: {0}
Current psector: {1}</source>
			<translation>The selected node is planified in another psector.
Node psector: {0}
Current psector: {1}</translation>
		</message>
		<message>
			<source>The selected node should have exactly two linked arcs.</source>
			<translation>Der ausgewählte Knoten sollte genau zwei verbundene Bögen haben.</translation>
		</message>
		<message>
			<source>These links could not be located within the network: </source>
			<translation>Diese Verbindungen konnten innerhalb des Netzes nicht lokalisiert werden:</translation>
		</message>
		<message>
			<source>These pipes will NOT be assigned a priority value as the configured unknown material, {1}, is not listed in the configuration tab for materials.</source>
			<translation>Diesen Rohren wird KEIN Prioritätswert zugewiesen, da das konfigurierte unbekannte Material {1} nicht in der Konfigurationsregisterkarte für Materialien aufgeführt ist.</translation>
		</message>
		<message>
			<source>The start date must be before the end date</source>
			<translation>The start date must be before the end date</translation>
		</message>
		<message>
			<source>The start date real must be before the end date real</source>
			<translation>The start date real must be before the end date real</translation>
		</message>
		<message>
			<source>The sum of weights must equal 1. Please adjust the values accordingly.</source>
			<translation>Die Summe der Gewichte muss gleich 1 sein. Bitte passen Sie die Werte entsprechend an.</translation>
		</message>
		<message>
			<source>The table &apos;plan_psector&apos; contains NULL values in the column &apos;atlas_id&apos;. Please fix this before continuing.</source>
			<translation>Die Tabelle &apos;plan_psector&apos; enthält NULL-Werte in der Spalte &apos;atlas_id&apos;. Bitte korrigieren Sie dies, bevor Sie fortfahren.</translation>
		</message>
		<message>
			<source>The target year must be between {0} and {1}.</source>
			<translation>Das Zieljahr muss zwischen {0} und {1} liegen.</translation>
		</message>
		<message>
			<source>The team name already exists</source>
			<translation>The team name already exists</translation>
		</message>
		<message>
			<source>The template &apos;{0}&apos; is missing some expected items: {1}. The layout will open, but these features won&apos;t be automatically configured. Make sure your template includes items with IDs: &apos;Mapa&apos; (for the map) and &apos;title&apos; (for the title).</source>
			<translation>The template &apos;{0}&apos; is missing some expected items: {1}. The layout will open, but these features won&apos;t be automatically configured. Make sure your template includes items with IDs: &apos;Mapa&apos; (for the map) and &apos;title&apos; (for the title).</translation>
		</message>
		<message>
			<source>The third tab is the &apos;Materials&apos; tab, where you can select the corresponding material for each roughness value.</source>
			<translation>Die dritte Registerkarte ist die Registerkarte &quot;Materialien&quot;, auf der Sie das entsprechende Material für jeden Rauheitswert auswählen können.</translation>
		</message>
		<message>
			<source>The third tab is the &apos;Materials&apos; tab, where you can select the corresponding roughness value for each material.</source>
			<translation>Die dritte Registerkarte ist die Registerkarte &quot;Materialien&quot;, auf der Sie den entsprechenden Rauhigkeitswert für jedes Material auswählen können.</translation>
		</message>
		<message>
			<source>The timeseries &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing timeseries.</source>
			<translation>The timeseries &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing timeseries.</translation>
		</message>
		<message>
			<source>The timeseries &quot;{0}&quot; was not imported.</source>
			<translation>The timeseries &quot;{0}&quot; was not imported.</translation>
		</message>
		<message>
			<source>The user config files have been recreated. A backup of the broken ones have been created at</source>
			<translation>Die Benutzer-Konfigurationsdateien wurden neu erstellt. Ein Backup der defekten Dateien wurde erstellt unter</translation>
		</message>
		<message>
			<source>The Workcat_id &quot;{0}&quot; is already in use. Please enter a different ID.</source>
			<translation>The Workcat_id &quot;{0}&quot; is already in use. Please enter a different ID.</translation>
		</message>
		<message>
			<source>This action cannot be undone. Do you want to proceed?</source>
			<translation>This action cannot be undone. Do you want to proceed?</translation>
		</message>
		<message>
			<source>This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector</source>
			<translation>Dieses Verhalten kann in der Tabelle &apos;config_param_system&apos; konfiguriert werden (Parameter = &apos;basic_selector</translation>
		</message>
		<message>
			<source>This dma doesn&apos;t exist</source>
			<translation>Dieses dma gibt es nicht</translation>
		</message>
		<message>
			<source>This feature has no log changes, please update this feature before.</source>
			<translation>Diese Funktion hat keine Protokolländerungen, bitte aktualisieren Sie diese Funktion vorher.</translation>
		</message>
		<message>
			<source>This parameter is mandatory. Please, set a value</source>
			<translation>Dieser Parameter ist obligatorisch. Bitte setzen Sie einen Wert</translation>
		</message>
		<message>
			<source>This presszone doesn&apos;t exist</source>
			<translation>Diese Pressezone gibt es nicht</translation>
		</message>
		<message>
			<source>This process will active snapshot. Are you sure to continue?</source>
			<translation>Dieser Vorgang ist ein aktiver Schnappschuss. Sind Sie sicher, dass Sie fortfahren wollen?</translation>
		</message>
		<message>
			<source>This process will take a few seconds. Are you sure to continue?</source>
			<translation>Dieser Vorgang wird einige Sekunden dauern. Sind Sie sicher, dass Sie fortfahren möchten?</translation>
		</message>
		<message>
			<source>This process will take time (few minutes). Are you sure to continue?</source>
			<translation>Dieser Vorgang wird einige Zeit in Anspruch nehmen (einige Minuten). Sind Sie sicher, dass Sie fortfahren wollen?</translation>
		</message>
		<message>
			<source>This &apos;Project_name&apos; already exist. Do you want rename old schema to &apos;{0}&apos;</source>
			<translation>Dieses &apos;Projekt_name&apos; existiert bereits. Möchten Sie das alte Schema in &apos;{0}&apos; umbenennen?</translation>
		</message>
		<message>
			<source>This project name alredy exist.</source>
			<translation>Dieser Projektname existiert bereits.</translation>
		</message>
		<message>
			<source>This result name already exists</source>
			<translation>Dieser Ergebnisname existiert bereits</translation>
		</message>
		<message>
			<source>This SRID value does not exist on Postgres Database. Please select a diferent one.</source>
			<translation>Dieser SRID-Wert existiert nicht in der Postgres-Datenbank. Bitte wählen Sie einen anderen Wert.</translation>
		</message>
		<message>
			<source>This task may take some time to complete, do you want to proceed?</source>
			<translation>Diese Aufgabe kann einige Zeit in Anspruch nehmen. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>This will also delete the database user(s):</source>
			<translation>Dabei wird auch der/die Datenbankbenutzer gelöscht:</translation>
		</message>
		<message>
			<source>!!!!! THIS WILL DELETE ALL DATA IN THE DATABASE !!!!!
ARE YOU SURE YOU WANT TO PROCEED?</source>
			<translation>!!!!! THIS WILL DELETE ALL DATA IN THE DATABASE !!!!!
ARE YOU SURE YOU WANT TO PROCEED?</translation>
		</message>
		<message>
			<source>This will modify your inp file, so a backup will be created.
Do you want to proceed?</source>
			<translation>This will modify your inp file, so a backup will be created.
Do you want to proceed?</translation>
		</message>
		<message>
			<source>This wizard will help with the process of importing a network from a {0} INP file into the Giswater database.</source>
			<translation>Dieser Assistent hilft Ihnen beim Importieren eines Netzes aus einer INP-Datei (0) in die Giswater-Datenbank.</translation>
		</message>
		<message>
			<source>This Workcat already exist</source>
			<translation>Dieser Workcat existiert bereits</translation>
		</message>
		<message>
			<source>This Workcat is already exist</source>
			<translation>Dieser Workcat ist bereits vorhanden</translation>
		</message>
		<message>
			<source>Timestep for input flows not informed.</source>
			<translation>Timestep for input flows not informed.</translation>
		</message>
		<message>
			<source>Title item &apos;title&apos; not found in template. Template may be empty or use different item IDs.</source>
			<translation>Title item &apos;title&apos; not found in template. Template may be empty or use different item IDs.</translation>
		</message>
		<message>
			<source>To add:</source>
			<translation>To add:</translation>
		</message>
		<message>
			<source>Toggle active</source>
			<translation>Toggle active</translation>
		</message>
		<message>
			<source>Toggle Active</source>
			<translation>Toggle Active</translation>
		</message>
		<message>
			<source>Toggle validated</source>
			<translation>Toggle validated</translation>
		</message>
		<message>
			<source>To make the result id {0} corporate, is necessary to make not corporate the following result ids: {1}. Do you want to proceed?</source>
			<translation>Um die Ergebnis-ID {0} korporativ zu machen, ist es notwendig, die folgenden Ergebnis-IDs nicht korporativ zu machen: {1}. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>Toolbox task is already active!</source>
			<translation>Die Toolbox-Aufgabe ist bereits aktiv!</translation>
		</message>
		<message>
			<source>Too many actions on CONTROL &apos;{0}&apos;</source>
			<translation>Too many actions on CONTROL &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>To remove:</source>
			<translation>To remove:</translation>
		</message>
		<message>
			<source>Total</source>
			<translation>Total</translation>
		</message>
		<message>
			<source>Total replacement cost (€):</source>
			<translation>Total replacement cost (€):</translation>
		</message>
		<message>
			<source>translation canceled</source>
			<translation>Übersetzung storniert</translation>
		</message>
		<message>
			<source>translation failed in table</source>
			<translation>Übersetzung in Tabelle fehlgeschlagen</translation>
		</message>
		<message>
			<source>Translations</source>
			<translation>Translations</translation>
		</message>
		<message>
			<source>translation successful</source>
			<translation>Übersetzung erfolgreich</translation>
		</message>
		<message>
			<source>Tried to set {0} to &apos;{1}&apos; but it&apos;s not an integer. Defaulting to 4 threads.</source>
			<translation>Ich habe versucht, {0} auf &apos;{1}&apos; zu setzen, aber es ist keine ganze Zahl. Standardmäßig werden 4 Threads verwendet.</translation>
		</message>
		<message>
			<source>Triggers updated successfully</source>
			<translation>Auslöser erfolgreich aktualisiert</translation>
		</message>
		<message>
			<source>Try again</source>
			<translation>Erneut versuchen</translation>
		</message>
		<message>
			<source>Type</source>
			<translation>Type</translation>
		</message>
		<message>
			<source>Typeahead &apos;{0}&apos; doesn&apos;t have neither a queryText nor comboIds/comboNames.</source>
			<translation>Typeahead &apos;{0}&apos; hat weder einen queryText noch comboIds/comboNames.</translation>
		</message>
		<message>
			<source>Type to search...</source>
			<translation>Type to search...</translation>
		</message>
		<message>
			<source>Unable to activate psector. </source>
			<translation>Unable to activate psector.</translation>
		</message>
		<message>
			<source>Unable to find table</source>
			<translation>Unable to find table</translation>
		</message>
		<message>
			<source>Unable to highlight the snapped arc.</source>
			<translation>Unable to highlight the snapped arc.</translation>
		</message>
		<message>
			<source>Unable to highlight the snapped node.</source>
			<translation>Der gefangene Knoten kann nicht markiert werden.</translation>
		</message>
		<message>
			<source>Unexpected languages payload from ({0})</source>
			<translation>Unexpected languages payload from ({0})</translation>
		</message>
		<message>
			<source>Unhandled Error</source>
			<translation>Unbehandelter Fehler</translation>
		</message>
		<message>
			<source>Unit for values of input flows not informed.</source>
			<translation>Unit for values of input flows not informed.</translation>
		</message>
		<message>
			<source>Units not specified in the INP file.</source>
			<translation>Units not specified in the INP file.</translation>
		</message>
		<message>
			<source>Unknown control for EPANET INP files: {0}</source>
			<translation>Unknown control for EPANET INP files: {0}</translation>
		</message>
		<message>
			<source>Unknown error</source>
			<translation>Unknown error</translation>
		</message>
		<message>
			<source>Unrecognised form type</source>
			<translation>Unbekannter Formulartyp</translation>
		</message>
		<message>
			<source>Unsafe path in ZIP archive: {0}</source>
			<translation>Unsafe path in ZIP archive: {0}</translation>
		</message>
		<message>
			<source>Unset corporate before unvalidating this result</source>
			<translation>Unset corporate before unvalidating this result</translation>
		</message>
		<message>
			<source>Unsuported geometry type</source>
			<translation>Unsuported geometry type</translation>
		</message>
		<message>
			<source>Unsupported layer_type: {0}</source>
			<translation>Unsupported layer_type: {0}</translation>
		</message>
		<message>
			<source>Unsupported locales combo flag: {0}</source>
			<translation>Unsupported locales combo flag: {0}</translation>
		</message>
		<message>
			<source>Unsupported project type for hydraulic engine: {0}</source>
			<translation>Unsupported project type for hydraulic engine: {0}</translation>
		</message>
		<message>
			<source>Unsupported URI encoding: {0}</source>
			<translation>Unsupported URI encoding: {0}</translation>
		</message>
		<message>
			<source>Unsupported widget type: {0}</source>
			<translation>Unsupported widget type: {0}</translation>
		</message>
		<message>
			<source>Update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>Update {0} ({1})</source>
			<translation>Update {0} ({1})</translation>
		</message>
		<message>
			<source>Update AM Layers Symbology</source>
			<translation>Update AM Layers Symbology</translation>
		</message>
		<message>
			<source>Update am schema</source>
			<translation>Update am schema</translation>
		</message>
		<message>
			<source>Update audit schema</source>
			<translation>Update audit schema</translation>
		</message>
		<message>
			<source>Update cibs schema</source>
			<translation>Update cibs schema</translation>
		</message>
		<message>
			<source>Update cm schema</source>
			<translation>Update cm schema</translation>
		</message>
		<message>
			<source>Update configuration</source>
			<translation>Konfiguration aktualisieren</translation>
		</message>
		<message>
			<source>Update Confirmation</source>
			<translation>Update-Bestätigung</translation>
		</message>
		<message>
			<source>Update field on &quot;{0}&quot;</source>
			<translation>Update field on &quot;{0}&quot;</translation>
		</message>
		<message>
			<source>Update language files?</source>
			<translation>Update language files?</translation>
		</message>
		<message>
			<source>Update multi field</source>
			<translation>Update multi field</translation>
		</message>
		<message>
			<source>Update multilang schema</source>
			<translation>Update multilang schema</translation>
		</message>
		<message>
			<source>Update Multilang translation?</source>
			<translation>Update Multilang translation?</translation>
		</message>
		<message>
			<source>Update multilang translations?</source>
			<translation>Update multilang translations?</translation>
		</message>
		<message>
			<source>Update multilang translations for ({0})</source>
			<translation>Update multilang translations for ({0})</translation>
		</message>
		<message>
			<source>Update network requires a WS or UD anchor.</source>
			<translation>Update network requires a WS or UD anchor.</translation>
		</message>
		<message>
			<source>Update records</source>
			<translation>Datensätze aktualisieren</translation>
		</message>
		<message>
			<source>Update translation?</source>
			<translation>Update translation?</translation>
		</message>
		<message>
			<source>Updating {0}...</source>
			<translation>Aktualisierung von {0}...</translation>
		</message>
		<message>
			<source>Updating language files for ({0})...</source>
			<translation>Updating language files for ({0})...</translation>
		</message>
		<message>
			<source>Updating multilang translations for ({0})...</source>
			<translation>Updating multilang translations for ({0})...</translation>
		</message>
		<message>
			<source>Updating municipality...</source>
			<translation>Updating municipality...</translation>
		</message>
		<message>
			<source>Updating tables</source>
			<translation>Updating tables</translation>
		</message>
		<message>
			<source>User</source>
			<translation>User</translation>
		</message>
		<message>
			<source>User not found</source>
			<translation>Benutzer nicht gefunden</translation>
		</message>
		<message>
			<source>Using this form you can configure graphconfig field for the selected mapzone.

How does it work?
1- Select the header of the mapzone using the nodeParent selection tool.
2- Select the direction of the water using the toArc selection tool. Multiple selection is allowed.
3- Press ADD to visualize your configuration on the Preview. If there are more headers, repeat the process and they will be added to the Preview.
4- If you want to configure an arc that will always be closed for this mapzone, select it using the forceClosed tool and ADD.
To remove some wrong configuration, you have to select the affected nodeParent and click REMOVE. This node and its related toArc will be deleted from the Preview.

Click OK to end set your Preview as the value on graphconfig field.</source>
			<translation>Using this form you can configure graphconfig field for the selected mapzone.

How does it work?
1- Select the header of the mapzone using the nodeParent selection tool.
2- Select the direction of the water using the toArc selection tool. Multiple selection is allowed.
3- Press ADD to visualize your configuration on the Preview. If there are more headers, repeat the process and they will be added to the Preview.
4- If you want to configure an arc that will always be closed for this mapzone, select it using the forceClosed tool and ADD.
To remove some wrong configuration, you have to select the affected nodeParent and click REMOVE. This node and its related toArc will be deleted from the Preview.

Click OK to end set your Preview as the value on graphconfig field.</translation>
		</message>
		<message>
			<source>Using this form you can configure graphconfig field for the selected mapzone.

How does it work?
1- Select the header of the mapzone using the nodeParent selection tool.
2- Select the direction of the water using the toArc selection tool. Multiple selection is allowed.
3- Press ADD to visualize your configuration on the Preview. If there are more headers, repeat the process and they will be added to the Preview.
4- If you want to configure a node that will always be closed for this mapzone, select it using the forceClosed tool and ADD.
To remove some wrong configuration, you have to select the affected nodeParent and click REMOVE. This node and its related toArc will be deleted from the Preview.

Click OK to end set your Preview as the value on graphconfig field.</source>
			<translation>Using this form you can configure graphconfig field for the selected mapzone.

How does it work?
1- Select the header of the mapzone using the nodeParent selection tool.
2- Select the direction of the water using the toArc selection tool. Multiple selection is allowed.
3- Press ADD to visualize your configuration on the Preview. If there are more headers, repeat the process and they will be added to the Preview.
4- If you want to configure a node that will always be closed for this mapzone, select it using the forceClosed tool and ADD.
To remove some wrong configuration, you have to select the affected nodeParent and click REMOVE. This node and its related toArc will be deleted from the Preview.

Click OK to end set your Preview as the value on graphconfig field.</translation>
		</message>
		<message>
			<source>Utils schema does not exist. Create it first.</source>
			<translation>Utils schema does not exist. Create it first.</translation>
		</message>
		<message>
			<source>Vacuum executed: {0}.{1}</source>
			<translation>Vakuum ausgeführt: {0}.{1}</translation>
		</message>
		<message>
			<source>Validate inputs</source>
			<translation>Validate inputs</translation>
		</message>
		<message>
			<source>Validating inputs...</source>
			<translation>Validating inputs...</translation>
		</message>
		<message>
			<source>Value</source>
			<translation>Value</translation>
		</message>
		<message>
			<source>Value_distribution must be SIMPLE or HOURLY.</source>
			<translation>Value_distribution must be SIMPLE or HOURLY.</translation>
		</message>
		<message>
			<source>Value in addparam must be in a json format</source>
			<translation>Der Wert in addparam muss im json-Format vorliegen.</translation>
		</message>
		<message>
			<source>ValueRelation lookup table not found: {0}</source>
			<translation>ValueRelation lookup table not found: {0}</translation>
		</message>
		<message>
			<source>Values for input flows not informed.</source>
			<translation>Values for input flows not informed.</translation>
		</message>
		<message>
			<source>Values has been updated</source>
			<translation>Die Werte wurden aktualisiert</translation>
		</message>
		<message>
			<source>Values saved successfully.</source>
			<translation>Werte erfolgreich gespeichert.</translation>
		</message>
		<message>
			<source>Valve Operation Check</source>
			<translation>Valve Operation Check</translation>
		</message>
		<message>
			<source>Valves couldn&apos;t be inserted!</source>
			<translation>Valves couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>Valve type not recognized: {0}</source>
			<translation>Valve type not recognized: {0}</translation>
		</message>
		<message>
			<source>Variable log_sql from user config file has been disabled.</source>
			<translation>Die Variable log_sql aus der Benutzerkonfigurationsdatei wurde deaktiviert.</translation>
		</message>
		<message>
			<source>Variable log_sql from user config file has been enabled.</source>
			<translation>Die Variable log_sql aus der Benutzerkonfigurationsdatei wurde aktiviert.</translation>
		</message>
		<message>
			<source>Version</source>
			<translation>Version</translation>
		</message>
		<message>
			<source>Visual objects</source>
			<translation>Visual objects</translation>
		</message>
		<message>
			<source>Warning</source>
			<translation>Warnung</translation>
		</message>
		<message>
			<source>WARNING</source>
			<translation>WARNUNG</translation>
		</message>
		<message>
			<source>Warning: Are you sure to continue?. This button will update your plugin qgis templates file replacing all strings defined on the config/dev.config file. Be sure your config file is OK before continue</source>
			<translation>Warnung: Sind Sie sicher, dass Sie fortfahren wollen? Diese Schaltfläche aktualisiert Ihre Plugin-Qgis-Templates-Datei und ersetzt alle in der Datei config/dev.config definierten Strings. Stellen Sie sicher, dass Ihre Konfigurationsdatei in Ordnung ist, bevor Sie fortfahren.</translation>
		</message>
		<message>
			<source>WARNING: This will remove the &apos;utils_workspace_current&apos; variable for your user!
Are you sure you want to delete these records?</source>
			<translation>WARNING: This will remove the &apos;utils_workspace_current&apos; variable for your user!
Are you sure you want to delete these records?</translation>
		</message>
		<message>
			<source>We are downloading the necessary language files. Please do not close QGIS.</source>
			<translation>We are downloading the necessary language files. Please do not close QGIS.</translation>
		</message>
		<message>
			<source>Weir</source>
			<translation>Weir</translation>
		</message>
		<message>
			<source>Weirs couldn&apos;t be inserted!</source>
			<translation>Weirs couldn&apos;t be inserted!</translation>
		</message>
		<message>
			<source>What&apos;s New</source>
			<translation>What&apos;s New</translation>
		</message>
		<message>
			<source>widget {0} has associated function {1}, but {2} not exist</source>
			<translation>Widget {0} hat eine zugehörige Funktion {1}, aber {2} existiert nicht</translation>
		</message>
		<message>
			<source>widget {0} has not columnname and can&apos;t be configured</source>
			<translation>Widget {0} hat keinen Spaltennamen und kann nicht konfiguriert werden</translation>
		</message>
		<message>
			<source>widget {0} has not columnname and cant be configured</source>
			<translation>Widget {0} hat keinen Spaltennamen und kann nicht konfiguriert werden</translation>
		</message>
		<message>
			<source>widget {0} have associated function {1}, but {2} not exist</source>
			<translation>Widget {0} hat zugehörige Funktion {1}, aber {2} existiert nicht</translation>
		</message>
		<message>
			<source>widget {0} in tab {1} has not columnname and can&apos;t be configured</source>
			<translation>Widget {0} in Registerkarte {1} hat keinen Spaltennamen und kann nicht konfiguriert werden</translation>
		</message>
		<message>
			<source>widget {0} in tab {1} has not columnname and cant be configured</source>
			<translation>Widget {0} in Registerkarte {1} hat keinen Spaltennamen und kann nicht konfiguriert werden</translation>
		</message>
		<message>
			<source>Widget {0} is not configured or have a bad config</source>
			<translation>Widget {0} ist nicht konfiguriert oder hat eine falsche Konfiguration</translation>
		</message>
		<message>
			<source>Widget &apos;{0}&apos; not found in the composer</source>
			<translation>Widget &apos;{0}&apos; not found in the composer</translation>
		</message>
		<message>
			<source>Widget &apos;{0}&apos; not found in the dialog.</source>
			<translation>Widget &apos;{0}&apos; not found in the dialog.</translation>
		</message>
		<message>
			<source>Widget: {0} not in form.</source>
			<translation>Widget: {0} nicht im Formular.</translation>
		</message>
		<message>
			<source>Widget expl_id not found</source>
			<translation>Widget expl_id nicht gefunden</translation>
		</message>
		<message>
			<source>Widget is not a QTableView</source>
			<translation>Widget is not a QTableView</translation>
		</message>
		<message>
			<source>Widget model is none: {0}</source>
			<translation>Widget-Modell ist keines: {0}</translation>
		</message>
		<message>
			<source>widgetname not found. </source>
			<translation>widgetname nicht gefunden.</translation>
		</message>
		<message>
			<source>Widget not found</source>
			<translation>Widget nicht gefunden</translation>
		</message>
		<message>
			<source>widgettype is wrongly configured. Needs to be in </source>
			<translation>widgettype ist falsch konfiguriert. Muss in</translation>
		</message>
		<message>
			<source>widgettype not found. </source>
			<translation>widgettype nicht gefunden.</translation>
		</message>
		<message>
			<source>Without replacements</source>
			<translation>Without replacements</translation>
		</message>
		<message>
			<source>With replacements</source>
			<translation>With replacements</translation>
		</message>
		<message>
			<source>Workcat created successfully.</source>
			<translation>Workcat erfolgreich erstellt.</translation>
		</message>
		<message>
			<source>Work_id field is empty</source>
			<translation>Feld work_id ist leer</translation>
		</message>
		<message>
			<source>Write inp file........: {0}</source>
			<translation>Schreiben Sie inp file........: {0}</translation>
		</message>
		<message>
			<source>Wrong number of parameters for node {0} in config file.</source>
			<translation>Wrong number of parameters for node {0} in config file.</translation>
		</message>
		<message>
			<source>Year</source>
			<translation>Year</translation>
		</message>
		<message>
			<source>Year:</source>
			<translation>Year:</translation>
		</message>
		<message>
			<source>You are about to adapt schema &apos;{0}&apos; to cibs.

Are you sure you want to continue?</source>
			<translation>You are about to adapt schema &apos;{0}&apos; to cibs.

Are you sure you want to continue?</translation>
		</message>
		<message>
			<source>You are about to delete the result</source>
			<translation>Sie sind dabei, das Ergebnis zu löschen</translation>
		</message>
		<message>
			<source>You are about to import the INP file in TESTING MODE. This will delete all the data in the database related to the network you are importing. Are you sure you want to proceed?</source>
			<translation>Sie sind dabei, die INP-Datei im TESTMODUS zu importieren. Dadurch werden alle Daten in der Datenbank gelöscht, die sich auf das zu importierende Netz beziehen. Sind Sie sicher, dass Sie fortfahren wollen?</translation>
		</message>
		<message>
			<source>You are about to integrate AM with the following WS schema: {0}

Are you sure you want to continue?</source>
			<translation>You are about to integrate AM with the following WS schema: {0}

Are you sure you want to continue?</translation>
		</message>
		<message>
			<source>You are about to perform this action aiming to the following schema: {0}

Are you sure you want to continue?</source>
			<translation>You are about to perform this action aiming to the following schema: {0}

Are you sure you want to continue?</translation>
		</message>
		<message>
			<source>You are going to change the epa_type. With this operation you will lose information about current epa_type values of this object. Would you like to continue?</source>
			<translation>Sie werden den epa_type ändern. Mit diesem Vorgang verlieren Sie Informationen über die aktuellen epa_type-Werte dieses Objekts. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>You are going to make this result corporate. From now on the result values will appear on feature form. Do you want to continue?</source>
			<translation>Sie werden dieses Ergebnis zu einem Unternehmen machen. Von nun an werden die Ergebniswerte im Feature-Formular erscheinen. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>You are not enabled to modify this {0} widget</source>
			<translation>Sie sind nicht berechtigt, dieses {0} Widget zu ändern</translation>
		</message>
		<message>
			<source>You are trying to add/remove a record from the table, with changes to the current records. If you continue, the changes will be discarded without saving. Do you want to continue?</source>
			<translation>Sie versuchen, einen Datensatz aus der Tabelle hinzuzufügen oder zu entfernen, wobei die aktuellen Datensätze geändert werden. Wenn Sie fortfahren, werden die Änderungen ohne Speicherung verworfen. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>You are trying to add/remove a record from the table, with changes to the current records.If you continue, the changes will be discarded without saving. Do you want to continue?</source>
			<translation>Sie versuchen, einen Datensatz aus der Tabelle hinzuzufügen/zu entfernen, wobei die aktuellen Datensätze geändert werden. Wenn Sie fortfahren, werden die Änderungen ohne Speicherung verworfen. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>You are trying to delete your current psector. Please, change your current psector before delete.</source>
			<translation>Sie versuchen, Ihren aktuellen Sektor zu löschen. Bitte ändern Sie Ihren aktuellen Sektor, bevor Sie ihn löschen.</translation>
		</message>
		<message>
			<source>You cannot change the status of a result with status &apos;FINISHED&apos;.</source>
			<translation>Sie können den Status eines Ergebnisses mit dem Status &apos;ABGESCHLOSSEN&apos; nicht ändern.</translation>
		</message>
		<message>
			<source>You cannot insert more than one feature at the same time, finish editing the previous feature</source>
			<translation>Sie können nicht mehr als ein Merkmal gleichzeitig einfügen, beenden Sie die Bearbeitung des vorherigen Merkmals</translation>
		</message>
		<message>
			<source>You can only delete results with the status &apos;CANCELED&apos;.</source>
			<translation>You can only delete results with the status &apos;CANCELED&apos;.</translation>
		</message>
		<message>
			<source>You can save the current configuration to a file and load it later, or load the last saved configuration.</source>
			<translation>Sie können die aktuelle Konfiguration in einer Datei speichern und später laden oder die zuletzt gespeicherte Konfiguration laden.</translation>
		</message>
		<message>
			<source>You can&apos;t delete these mincuts because they aren&apos;t planified 
or they were created by another user:</source>
			<translation>You can&apos;t delete these mincuts because they aren&apos;t planified 
or they were created by another user:</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time.</source>
			<translation>Sie haben ein Ventil geschlossen, dies ändert die aktuellen Mapzones und kann etwas Zeit in Anspruch nehmen.</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time. Would you like to continue?</source>
			<translation>Sie haben ein Ventil geschlossen, dies wird die aktuellen Mapzones ändern und kann etwas Zeit in Anspruch nehmen. Möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time.Would you like to continue?</source>
			<translation>Sie haben ein Ventil geschlossen, dies wird die aktuellen Mapzones ändern und kann etwas Zeit in Anspruch nehmen, möchten Sie fortfahren?</translation>
		</message>
		<message>
			<source>You do not have permission to execute this application</source>
			<translation>Sie haben keine Berechtigung, diese Anwendung auszuführen</translation>
		</message>
		<message>
			<source>You don&apos;t have any connection to PostGIS database configurated. Check your QGIS data source manager and create at least one</source>
			<translation>Sie haben keine Verbindung zur PostGIS-Datenbank konfiguriert. Überprüfen Sie Ihren QGIS-Datenquellenmanager und erstellen Sie mindestens eine</translation>
		</message>
		<message>
			<source>You have selected multiple documents. In this case, name will be a sequential number for all selected documents and your name won&apos;t be used.</source>
			<translation>Sie haben mehrere Dokumente ausgewählt. In diesem Fall wird der Name eine fortlaufende Nummer für alle ausgewählten Dokumente sein und Ihr Name wird nicht verwendet.</translation>
		</message>
		<message>
			<source>You have to fill in &apos;date&apos;, &apos;time&apos; and &apos;value&apos; fields!</source>
			<translation>Sie müssen die Felder &quot;Datum&quot;, &quot;Uhrzeit&quot; und &quot;Wert&quot; ausfüllen!</translation>
		</message>
		<message>
			<source>You have to fill in &apos;time&apos; and &apos;value&apos; fields!</source>
			<translation>Sie müssen die Felder &quot;Zeit&quot; und &quot;Wert&quot; ausfüllen!</translation>
		</message>
		<message>
			<source>You have to import a ibergis GPKG project first</source>
			<translation>Sie müssen zuerst ein ibergis GPKG Projekt importieren</translation>
		</message>
		<message>
			<source>You have to set this parameter</source>
			<translation>Sie müssen diesen Parameter einstellen</translation>
		</message>
		<message>
			<source>You have to set this parameter: INP file</source>
			<translation>You have to set this parameter: INP file</translation>
		</message>
		<message>
			<source>You have unsaved changes in the campaign selector. Close without saving?</source>
			<translation>You have unsaved changes in the campaign selector. Close without saving?</translation>
		</message>
		<message>
			<source>You must choose at least one action</source>
			<translation>You must choose at least one action</translation>
		</message>
		<message>
			<source>You must select two different points</source>
			<translation>Sie müssen zwei verschiedene Punkte auswählen</translation>
		</message>
		<message>
			<source>You need at least one row of values.</source>
			<translation>Sie benötigen mindestens eine Zeile mit Werten.</translation>
		</message>
		<message>
			<source>You need to enter a customer code</source>
			<translation>Sie müssen einen Kundencode eingeben</translation>
		</message>
		<message>
			<source>You need to enter a feature id</source>
			<translation>Sie müssen eine Feature-ID eingeben</translation>
		</message>
		<message>
			<source>You need to enter a psector name</source>
			<translation>Sie müssen einen Sektornamen eingeben</translation>
		</message>
		<message>
			<source>You need to enter a visit ID</source>
			<translation>Sie müssen eine Besuchs-ID eingeben</translation>
		</message>
		<message>
			<source>You need to enter a workcat id</source>
			<translation>Sie müssen eine Workcat-ID eingeben</translation>
		</message>
		<message>
			<source>You need to enter hydrometer_id</source>
			<translation>Sie müssen hydrometer_id eingeben</translation>
		</message>
		<message>
			<source>You need to have a mesh</source>
			<translation>Sie benötigen ein Netz</translation>
		</message>
		<message>
			<source>You need to insert a document name</source>
			<translation>Sie müssen einen Dokumentennamen eingeben</translation>
		</message>
		<message>
			<source>You need to insert data</source>
			<translation>Sie müssen Daten einfügen</translation>
		</message>
		<message>
			<source>You need to insert psector_id</source>
			<translation>Sie müssen psector_id einfügen</translation>
		</message>
		<message>
			<source>You need to insert visit_id</source>
			<translation>Sie müssen visit_id einfügen</translation>
		</message>
		<message>
			<source>You need to reexecute the mincut</source>
			<translation>You need to reexecute the mincut</translation>
		</message>
		<message>
			<source>You need to select a template</source>
			<translation>Sie müssen eine Vorlage auswählen</translation>
		</message>
		<message>
			<source>You need to select at least one process</source>
			<translation>Sie müssen mindestens einen Prozess auswählen</translation>
		</message>
		<message>
			<source>You need to select a valid parameter id</source>
			<translation>Sie müssen eine gültige Parameterkennung auswählen</translation>
		</message>
		<message>
			<source>You need to select some sector</source>
			<translation>Sie müssen einen Sektor auswählen</translation>
		</message>
		<message>
			<source>Your composer&apos;s path is bad configured. Please, modify it and try again.</source>
			<translation>Der Pfad Ihres Composers ist falsch konfiguriert. Bitte ändern Sie ihn und versuchen Sie es erneut.</translation>
		</message>
		<message>
			<source>Your exploitation selector has been updated</source>
			<translation>Ihr Betriebswahlschalter wurde aktualisiert</translation>
		</message>
		<message>
			<source>You should inform a file name!</source>
			<translation>Sie sollten einen Dateinamen angeben!</translation>
		</message>
		<message>
			<source>You should select a config file!</source>
			<translation>Sie sollten eine Konfigurationsdatei auswählen!</translation>
		</message>
		<message>
			<source>You should select an config file!</source>
			<translation>Sie sollten eine Konfigurationsdatei auswählen!</translation>
		</message>
		<message>
			<source>You should select an input INP file!</source>
			<translation>Sie sollten eine INP-Eingabedatei auswählen!</translation>
		</message>
		<message>
			<source>You should select an output folder!</source>
			<translation>Sie sollten einen Ausgabeordner auswählen!</translation>
		</message>
		<message>
			<source>Zoom to selection</source>
			<translation>Zoom to selection</translation>
		</message>
	</context>
<!-- UI TRANSLATION -->
	<context>
		<name>about</name>
		<message>
			<source>title</source>
			<translation>About Giswater</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Close</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_copy</source>
			<translation>Copy to clipboard</translation>
		</message>
		<message>
			<source>tooltip_btn_copy</source>
			<translation>btn_copy</translation>
		</message>
		<message>
			<source>btn_homepage</source>
			<translation>Giswater Home Page</translation>
		</message>
		<message>
			<source>tooltip_btn_homepage</source>
			<translation>btn_homepage</translation>
		</message>
		<message>
			<source>btn_issue</source>
			<translation>Report an issue</translation>
		</message>
		<message>
			<source>tooltip_btn_issue</source>
			<translation>btn_issue</translation>
		</message>
		<message>
			<source>btn_release</source>
			<translation>View on GitHub</translation>
		</message>
		<message>
			<source>tooltip_btn_release</source>
			<translation>btn_release</translation>
		</message>
		<message>
			<source>dlg_about</source>
			<translation>About Giswater</translation>
		</message>
		<message>
			<source>tooltip_dlg_about</source>
			<translation>dlg_about</translation>
		</message>
		<message>
			<source>lbl_acknowledgments</source>
			<translation>Special thanks to our founding contributors:</translation>
		</message>
		<message>
			<source>tooltip_lbl_acknowledgments</source>
			<translation>lbl_acknowledgments</translation>
		</message>
		<message>
			<source>lbl_license</source>
			<translation>Giswater is licensed under the GNU General Public License</translation>
		</message>
		<message>
			<source>tooltip_lbl_license</source>
			<translation>lbl_license</translation>
		</message>
		<message>
			<source>lbl_license_url</source>
			<translation>&lt;a href=&quot;https://www.gnu.org/licenses/&quot;&gt;https://www.gnu.org/licenses/&lt;/a&gt;</translation>
		</message>
		<message>
			<source>tooltip_lbl_license_url</source>
			<translation>lbl_license_url</translation>
		</message>
		<message>
			<source>lbl_members</source>
			<translation>Everyone who has committed to Giswater:</translation>
		</message>
		<message>
			<source>tooltip_lbl_members</source>
			<translation>lbl_members</translation>
		</message>
		<message>
			<source>lbl_translations</source>
			<translation>Available translations:</translation>
		</message>
		<message>
			<source>tooltip_lbl_translations</source>
			<translation>lbl_translations</translation>
		</message>
		<message>
			<source>lbl_translations_link</source>
			<translation>&lt;a href=&quot;https://github.com/giswater/translations&quot;&gt;github.com/giswater/translations&lt;/a&gt;</translation>
		</message>
		<message>
			<source>tooltip_lbl_translations_link</source>
			<translation>lbl_translations_link</translation>
		</message>
		<message>
			<source>lbl_version_release</source>
			<translation>Version</translation>
		</message>
		<message>
			<source>tooltip_lbl_version_release</source>
			<translation>lbl_version_release</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_inventory</name>
		<message>
			<source>add_campaign</source>
			<translation>Kampagne</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Kampagne</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Elementbeziehungen</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_review</name>
		<message>
			<source>add_campaign</source>
			<translation>Kampagne</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Kampagne</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Elementbeziehungen</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_review_old</name>
		<message>
			<source>action_selector</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_action_selector</source>
			<translation>action_selector</translation>
		</message>
		<message>
			<source>active</source>
			<translation>Aktiv:</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Kampagne</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_export_rel</source>
			<translation>Exportieren nach csv</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_export_rel</source>
			<translation>campaign_btn_export_rel</translation>
		</message>
		<message>
			<source>campaign_btn_path_rel</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_path_rel</source>
			<translation>campaign_btn_path_rel</translation>
		</message>
		<message>
			<source>CampaignTab</source>
			<translation>Kampagne</translation>
		</message>
		<message>
			<source>tooltip_CampaignTab</source>
			<translation>CampaignTab</translation>
		</message>
		<message>
			<source>grb_campaign</source>
			<translation>Kampagne:</translation>
		</message>
		<message>
			<source>tooltip_grb_campaign</source>
			<translation>grb_campaign</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Übung:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Serie:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Ein echter Start:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Echtes Ende:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Organisation:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Dauer:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Adresse:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Elementtyp:</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>label_feature_type</translation>
		</message>
		<message>
			<source>label_flexunion_code_5</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_label_flexunion_code_5</source>
			<translation>label_flexunion_code_5</translation>
		</message>
		<message>
			<source>label_node_type</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type</source>
			<translation>label_node_type</translation>
		</message>
		<message>
			<source>label_node_type_2</source>
			<translation>Geplantes Ende:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_2</source>
			<translation>label_node_type_2</translation>
		</message>
		<message>
			<source>label_node_type_3</source>
			<translation>Geplanter Start:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_3</source>
			<translation>label_node_type_3</translation>
		</message>
		<message>
			<source>label_node_type_5</source>
			<translation>Rotation:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_5</source>
			<translation>label_node_type_5</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Beziehungen zwischen den Elementen</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>RelationsTab</translation>
		</message>
		<message>
			<source>reviewclass_id</source>
			<translation>Klasse überprüfen:</translation>
		</message>
		<message>
			<source>tooltip_reviewclass_id</source>
			<translation>reviewclass_id</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_visit</name>
		<message>
			<source>add_campaign</source>
			<translation>Besuchen Sie</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Kampagne</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Elementbeziehungen</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_visit_old</name>
		<message>
			<source>action_selector</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_action_selector</source>
			<translation>action_selector</translation>
		</message>
		<message>
			<source>active</source>
			<translation>Aktiv:</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Los</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_export_rel</source>
			<translation>Exportieren nach csv</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_export_rel</source>
			<translation>campaign_btn_export_rel</translation>
		</message>
		<message>
			<source>campaign_btn_path_rel</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_path_rel</source>
			<translation>campaign_btn_path_rel</translation>
		</message>
		<message>
			<source>CampaignTab</source>
			<translation>Kampagne</translation>
		</message>
		<message>
			<source>tooltip_CampaignTab</source>
			<translation>CampaignTab</translation>
		</message>
		<message>
			<source>grb_campaign</source>
			<translation>Kampagne:</translation>
		</message>
		<message>
			<source>tooltip_grb_campaign</source>
			<translation>grb_campaign</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Übung:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Serie:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Ein echter Start:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Echtes Ende:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Organisation:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Dauer:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Adresse:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Art des Elements</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>label_feature_type</translation>
		</message>
		<message>
			<source>label_flexunion_code_5</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_label_flexunion_code_5</source>
			<translation>label_flexunion_code_5</translation>
		</message>
		<message>
			<source>label_node_type</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type</source>
			<translation>label_node_type</translation>
		</message>
		<message>
			<source>label_node_type_2</source>
			<translation>Geplantes Ende:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_2</source>
			<translation>label_node_type_2</translation>
		</message>
		<message>
			<source>label_node_type_3</source>
			<translation>Geplanter Start:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_3</source>
			<translation>label_node_type_3</translation>
		</message>
		<message>
			<source>label_node_type_5</source>
			<translation>Rotation:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_5</source>
			<translation>label_node_type_5</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Beziehungen zwischen den Elementen</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>RelationsTab</translation>
		</message>
		<message>
			<source>visitclass_id</source>
			<translation>Klasse besuchen:</translation>
		</message>
		<message>
			<source>tooltip_visitclass_id</source>
			<translation>visitclass_id</translation>
		</message>
	</context>
	<context>
		<name>add_lot</name>
		<message>
			<source>title</source>
			<translation>Los</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_visit</source>
			<translation>Besuch löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_visit</source>
			<translation>Besuch löschen</translation>
		</message>
		<message>
			<source>btn_export_visits</source>
			<translation>Exportieren nach csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_visits</source>
			<translation>Exportieren nach csv</translation>
		</message>
		<message>
			<source>btn_open_photo</source>
			<translation>Open photo</translation>
		</message>
		<message>
			<source>tooltip_btn_open_photo</source>
			<translation>Open photo</translation>
		</message>
		<message>
			<source>btn_open_visit</source>
			<translation>Offener Besuch</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit</source>
			<translation>Offener Besuch</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_validate_all</source>
			<translation>Alle validieren</translation>
		</message>
		<message>
			<source>tooltip_btn_validate_all</source>
			<translation>Alle validieren</translation>
		</message>
		<message>
			<source>dlg_add_lot</source>
			<translation>Los</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_lot</source>
			<translation>dlg_add_lot</translation>
		</message>
		<message>
			<source>grb_lot</source>
			<translation>Los:</translation>
		</message>
		<message>
			<source>tooltip_grb_lot</source>
			<translation>Los:</translation>
		</message>
		<message>
			<source>label_data_event_from</source>
			<translation>Von:</translation>
		</message>
		<message>
			<source>tooltip_label_data_event_from</source>
			<translation>Von:</translation>
		</message>
		<message>
			<source>label_data_event_to</source>
			<translation>Bis:</translation>
		</message>
		<message>
			<source>tooltip_label_data_event_to</source>
			<translation>An:</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Nach Element-ID filtern:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>Nach Element-ID filtern:</translation>
		</message>
		<message>
			<source>LotTab</source>
			<translation>Los</translation>
		</message>
		<message>
			<source>tooltip_LotTab</source>
			<translation>Los</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Elementbeziehungen</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>Elemente Beziehung</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>VisitsTab</source>
			<translation>Besuche</translation>
		</message>
		<message>
			<source>tooltip_VisitsTab</source>
			<translation>Besuche</translation>
		</message>
	</context>
	<context>
		<name>add_workorder</name>
		<message>
			<source>title</source>
			<translation>Arbeitsauftrag</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_add_workorder</source>
			<translation>Arbeitsauftrag</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_workorder</source>
			<translation>dlg_add_workorder</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Arbeitsauftrag</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
	</context>
	<context>
		<name>admin</name>
		<message>
			<source>title</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>btn_activate_audit</source>
			<translation>Aktivieren der Prüfumgebung</translation>
		</message>
		<message>
			<source>tooltip_btn_activate_audit</source>
			<translation>It will generate a copy of the network layers from your current schema into the audit schema</translation>
		</message>
		<message>
			<source>btn_adapt_cibs</source>
			<translation>Adapt schema to use cibs</translation>
		</message>
		<message>
			<source>tooltip_btn_adapt_cibs</source>
			<translation>btn_adapt_cibs</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_copy</source>
			<translation>Kopieren</translation>
		</message>
		<message>
			<source>tooltip_btn_copy</source>
			<translation>btn_copy</translation>
		</message>
		<message>
			<source>btn_create_asset</source>
			<translation>DB-Asset-Schema erstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_create_asset</source>
			<translation>btn_create_asset</translation>
		</message>
		<message>
			<source>btn_create_audit</source>
			<translation>DB-Audit-Schema erstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_create_audit</source>
			<translation>btn_create_audit</translation>
		</message>
		<message>
			<source>btn_create_cibs</source>
			<translation>Create cibs schema</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cibs</source>
			<translation>btn_create_cibs</translation>
		</message>
		<message>
			<source>btn_create_cm</source>
			<translation>DB cm Schema erstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cm</source>
			<translation>btn_create_cm</translation>
		</message>
		<message>
			<source>btn_create_field</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create_field</source>
			<translation>btn_create_field</translation>
		</message>
		<message>
			<source>btn_create_qgis_template</source>
			<translation>QGIS-Vorlagen</translation>
		</message>
		<message>
			<source>tooltip_btn_create_qgis_template</source>
			<translation>btn_create_qgis_template</translation>
		</message>
		<message>
			<source>btn_create_utils</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create_utils</source>
			<translation>btn_create_utils</translation>
		</message>
		<message>
			<source>btn_custom_load_file</source>
			<translation>SQL-Dateien laden</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_load_file</source>
			<translation>btn_custom_load_file</translation>
		</message>
		<message>
			<source>btn_custom_select_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_select_file</source>
			<translation>btn_custom_select_file</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_delete_field</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_field</source>
			<translation>btn_delete_field</translation>
		</message>
		<message>
			<source>btn_gis_create</source>
			<translation>QGIS-Projektdatei erstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_create</source>
			<translation>btn_gis_create</translation>
		</message>
		<message>
			<source>btn_gis_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_folder</source>
			<translation>btn_gis_folder</translation>
		</message>
		<message>
			<source>btn_import_osm_streetaxis</source>
			<translation>OSM Streetaxis importieren</translation>
		</message>
		<message>
			<source>tooltip_btn_import_osm_streetaxis</source>
			<translation>btn_import_osm_streetaxis</translation>
		</message>
		<message>
			<source>btn_info</source>
			<translation>Projektschema aktualisieren</translation>
		</message>
		<message>
			<source>tooltip_btn_info</source>
			<translation>Version eines ausgewählten Datenbankschemas aktualisieren</translation>
		</message>
		<message>
			<source>btn_manage_languages</source>
			<translation>Manage Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_languages</source>
			<translation>btn_manage_languages</translation>
		</message>
		<message>
			<source>btn_manage_schemas</source>
			<translation>Manage schemas</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_schemas</source>
			<translation>btn_manage_schemas</translation>
		</message>
		<message>
			<source>btn_markdown_generator</source>
			<translation>Markdown-Generator</translation>
		</message>
		<message>
			<source>tooltip_btn_markdown_generator</source>
			<translation>btn_markdown_generator</translation>
		</message>
		<message>
			<source>btn_reload_audit_triggers</source>
			<translation>Audit auffrischen</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_audit_triggers</source>
			<translation>Allow to start/end auditing tables updating the triggers</translation>
		</message>
		<message>
			<source>btn_reload_fct_ftrg</source>
			<translation>Ausführen</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_fct_ftrg</source>
			<translation>btn_reload_fct_ftrg</translation>
		</message>
		<message>
			<source>btn_schema_create</source>
			<translation>DB-Projektschema erstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_create</source>
			<translation>btn_schema_create</translation>
		</message>
		<message>
			<source>btn_schema_rename</source>
			<translation>Umbenennen</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_rename</source>
			<translation>btn_schema_rename</translation>
		</message>
		<message>
			<source>btn_update_asset</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_asset</source>
			<translation>btn_update_asset</translation>
		</message>
		<message>
			<source>btn_update_cm</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_cm</source>
			<translation>btn_update_cm</translation>
		</message>
		<message>
			<source>btn_update_field</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_field</source>
			<translation>btn_update_field</translation>
		</message>
		<message>
			<source>btn_update_utils</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_utils</source>
			<translation>btn_update_utils</translation>
		</message>
		<message>
			<source>btn_vacuum</source>
			<translation>Ausführen</translation>
		</message>
		<message>
			<source>tooltip_btn_vacuum</source>
			<translation>btn_vacuum</translation>
		</message>
		<message>
			<source>chk_add_fields_multi</source>
			<translation>Addfeld Multikreation</translation>
		</message>
		<message>
			<source>tooltip_chk_add_fields_multi</source>
			<translation>chk_add_fields_multi</translation>
		</message>
		<message>
			<source>dlg_admin</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin</source>
			<translation>dlg_admin</translation>
		</message>
		<message>
			<source>grb_conection</source>
			<translation>Verbindung</translation>
		</message>
		<message>
			<source>tooltip_grb_conection</source>
			<translation>grb_conection</translation>
		</message>
		<message>
			<source>grb_files_generator</source>
			<translation>Generator für Plugin-Dateien</translation>
		</message>
		<message>
			<source>tooltip_grb_files_generator</source>
			<translation>grb_files_generator</translation>
		</message>
		<message>
			<source>grb_load_cf</source>
			<translation>Benutzerdefinierte Datei laden</translation>
		</message>
		<message>
			<source>tooltip_grb_load_cf</source>
			<translation>grb_load_cf</translation>
		</message>
		<message>
			<source>grb_manage_addfields</source>
			<translation>Hinzufügen von Feldern verwalten</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_addfields</source>
			<translation>grb_manage_addfields</translation>
		</message>
		<message>
			<source>grb_manage_schemas</source>
			<translation>Additional schema management</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_schemas</source>
			<translation>grb_manage_schemas</translation>
		</message>
		<message>
			<source>grb_project_scin</source>
			<translation>Informationen zum Projektschema</translation>
		</message>
		<message>
			<source>tooltip_grb_project_scin</source>
			<translation>grb_project_scin</translation>
		</message>
		<message>
			<source>grb_schema_manager</source>
			<translation>Schema-Verwaltung</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_manager</source>
			<translation>grb_schema_manager</translation>
		</message>
		<message>
			<source>grb_schema_reload</source>
			<translation>Schema-Verwaltung</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_reload</source>
			<translation>grb_schema_reload</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Schema Utils</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Zusätzliche Schemaverwaltung</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_cibs</source>
			<translation>Schema cibs</translation>
		</message>
		<message>
			<source>tooltip_groupBox_cibs</source>
			<translation>groupBox_cibs</translation>
		</message>
		<message>
			<source>grp_i18n_update</source>
			<translation>Schema-i18n-Aktualisierung</translation>
		</message>
		<message>
			<source>tooltip_grp_i18n_update</source>
			<translation>grp_i18n_update</translation>
		</message>
		<message>
			<source>grp_import_osm</source>
			<translation>OSM Streetaxis importieren</translation>
		</message>
		<message>
			<source>tooltip_grp_import_osm</source>
			<translation>grp_import_osm</translation>
		</message>
		<message>
			<source>label</source>
			<translation>WS:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>UD:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_cibs_schema</source>
			<translation>Schema:</translation>
		</message>
		<message>
			<source>tooltip_label_cibs_schema</source>
			<translation>label_cibs_schema</translation>
		</message>
		<message>
			<source>lbl_add_fields_feature</source>
			<translation>Name des Merkmals:</translation>
		</message>
		<message>
			<source>tooltip_lbl_add_fields_feature</source>
			<translation>lbl_add_fields_feature</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Name der Verbindung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_export_user_pass</source>
			<translation>Export user password:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_user_pass</source>
			<translation>lbl_export_user_pass</translation>
		</message>
		<message>
			<source>lbl_gis_file</source>
			<translation>GIS file name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_file</source>
			<translation>lbl_gis_file</translation>
		</message>
		<message>
			<source>lbl_gis_folder</source>
			<translation>GIS folder:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_folder</source>
			<translation>lbl_gis_folder</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_reload_fct_ftrg</source>
			<translation>Funktionen neu laden &amp;amp; Funktionsauslöser</translation>
		</message>
		<message>
			<source>tooltip_lbl_reload_fct_ftrg</source>
			<translation>lbl_reload_fct_ftrg</translation>
		</message>
		<message>
			<source>lbl_vacuum</source>
			<translation>Vakuum im ausgewählten Schema ausführen</translation>
		</message>
		<message>
			<source>tooltip_lbl_vacuum</source>
			<translation>lbl_vacuum</translation>
		</message>
		<message>
			<source>tab_advanced</source>
			<translation>Fortgeschrittene</translation>
		</message>
		<message>
			<source>tooltip_tab_advanced</source>
			<translation>tab_advanced</translation>
		</message>
		<message>
			<source>tab_dev</source>
			<translation>Dev</translation>
		</message>
		<message>
			<source>tooltip_tab_dev</source>
			<translation>tab_dev</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Allgemein</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>txt_roletype</source>
			<translation>inventory</translation>
		</message>
		<message>
			<source>tooltip_txt_roletype</source>
			<translation>txt_roletype</translation>
		</message>
	</context>
	<context>
		<name>admin_addfields</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Öffnen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_admin_addfields</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_addfields</source>
			<translation>dlg_admin_addfields</translation>
		</message>
		<message>
			<source>grb_additional</source>
			<translation>Zusätzliche Konfiguration</translation>
		</message>
		<message>
			<source>tooltip_grb_additional</source>
			<translation>grb_additional</translation>
		</message>
		<message>
			<source>grb_mandatory</source>
			<translation>Obligatorische Addfields-Konfiguration</translation>
		</message>
		<message>
			<source>tooltip_grb_mandatory</source>
			<translation>grb_mandatory</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Aktiv:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_columnname</source>
			<translation>Name der Spalte:</translation>
		</message>
		<message>
			<source>tooltip_lbl_columnname</source>
			<translation>lbl_columnname</translation>
		</message>
		<message>
			<source>lbl_datatype</source>
			<translation>Datentyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_datatype</source>
			<translation>lbl_datatype</translation>
		</message>
		<message>
			<source>lbl_dv_orderby</source>
			<translation>Bestellung nach Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_orderby</source>
			<translation>lbl_dv_orderby</translation>
		</message>
		<message>
			<source>lbl_dv_querynullvalue</source>
			<translation>Nullwert abfragen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_querynullvalue</source>
			<translation>lbl_dv_querynullvalue</translation>
		</message>
		<message>
			<source>lbl_dv_querytext</source>
			<translation>Abfragetext:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_querytext</source>
			<translation>lbl_dv_querytext</translation>
		</message>
		<message>
			<source>lbl_field_name</source>
			<translation>Feldname:</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_name</source>
			<translation>lbl_field_name</translation>
		</message>
		<message>
			<source>lbl_formtype</source>
			<translation>Art des Formulars:</translation>
		</message>
		<message>
			<source>tooltip_lbl_formtype</source>
			<translation>lbl_formtype</translation>
		</message>
		<message>
			<source>lbl_hidden</source>
			<translation>Versteckt:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hidden</source>
			<translation>lbl_hidden</translation>
		</message>
		<message>
			<source>lbl_iseditable</source>
			<translation>Bearbeitbar:</translation>
		</message>
		<message>
			<source>tooltip_lbl_iseditable</source>
			<translation>lbl_iseditable</translation>
		</message>
		<message>
			<source>lbl_ismandatory</source>
			<translation>Obligatorisch:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ismandatory</source>
			<translation>lbl_ismandatory</translation>
		</message>
		<message>
			<source>lbl_label</source>
			<translation>Etikett:</translation>
		</message>
		<message>
			<source>tooltip_lbl_label</source>
			<translation>lbl_label</translation>
		</message>
		<message>
			<source>lbl_layoutname</source>
			<translation>Name des Layouts:</translation>
		</message>
		<message>
			<source>tooltip_lbl_layoutname</source>
			<translation>lbl_layoutname</translation>
		</message>
		<message>
			<source>lbl_linkedobject</source>
			<translation>Verknüpftes Objekt:</translation>
		</message>
		<message>
			<source>tooltip_lbl_linkedobject</source>
			<translation>lbl_linkedobject</translation>
		</message>
		<message>
			<source>lbl_multifeaturetype</source>
			<translation>Funktion zum mehrfachen Erstellen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multifeaturetype</source>
			<translation>lbl_multifeaturetype</translation>
		</message>
		<message>
			<source>lbl_placeholder</source>
			<translation>Platzhalter:</translation>
		</message>
		<message>
			<source>tooltip_lbl_placeholder</source>
			<translation>lbl_placeholder</translation>
		</message>
		<message>
			<source>lbl_stylesheet</source>
			<translation>Stylesheet:</translation>
		</message>
		<message>
			<source>tooltip_lbl_stylesheet</source>
			<translation>lbl_stylesheet</translation>
		</message>
		<message>
			<source>lbl_tooltip</source>
			<translation>Tooltip:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tooltip</source>
			<translation>lbl_tooltip</translation>
		</message>
		<message>
			<source>lbl_widgetcontrols</source>
			<translation>Widget-Steuerungen</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgetcontrols</source>
			<translation>Beispiel für Konfigurationsschlüssel {&quot;widgetdim&quot;: 150, &quot;setMultiline&quot;:true, &quot;vdefault&quot;: &quot;01-01-2014&quot;, &quot;filterSign&quot;: &quot;&gt;}</translation>
		</message>
		<message>
			<source>lbl_widgettype</source>
			<translation>Widget-Typ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgettype</source>
			<translation>lbl_widgettype</translation>
		</message>
		<message>
			<source>stylesheet</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;{&amp;amp;quot;label&amp;amp;quot;:&amp;amp;quot;color:green; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;widget&amp;amp;quot;:{&amp;amp;quot;enabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;disabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;}}&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_stylesheet</source>
			<translation>{&quot;label&quot;:&quot;color:green; font-weight:bold;&quot;,&quot;widget&quot;:{&quot;enabled&quot;:&quot;color:black; font-weight:bold;&quot;,&quot;disabled&quot;:&quot;color:black; font-weight:bold;&quot;}}</translation>
		</message>
		<message>
			<source>tab_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_tab_create</source>
			<translation>tab_create</translation>
		</message>
		<message>
			<source>tab_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_tab_delete</source>
			<translation>tab_delete</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_tab_update</source>
			<translation>tab_update</translation>
		</message>
	</context>
	<context>
		<name>admin_cm_create</name>
		<message>
			<source>title</source>
			<translation>Projekt erstellen</translation>
		</message>
		<message>
			<source>btn_base_schema</source>
			<translation>cm-Schema erstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_base_schema</source>
			<translation>btn_base_schema</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Aufgabe abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_example</source>
			<translation>Beispiel erstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_example</source>
			<translation>btn_example</translation>
		</message>
		<message>
			<source>btn_parent_schema</source>
			<translation>Link zum übergeordneten Schema</translation>
		</message>
		<message>
			<source>tooltip_btn_parent_schema</source>
			<translation>btn_parent_schema</translation>
		</message>
		<message>
			<source>btn_pschema_qgis_file</source>
			<translation>Pschema qgis-Datei erstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_pschema_qgis_file</source>
			<translation>btn_pschema_qgis_file</translation>
		</message>
		<message>
			<source>dlg_admin_cm_create</source>
			<translation>Projekt erstellen</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_cm_create</source>
			<translation>dlg_admin_cm_create</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>CM schema options</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
	</context>
	<context>
		<name>admin_credentials</name>
		<message>
			<source>title</source>
			<translation>Anmeldeinformationen für die Verbindung</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>dlg_admin_credentials</source>
			<translation>Anmeldeinformationen für die Verbindung</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_credentials</source>
			<translation>dlg_admin_credentials</translation>
		</message>
		<message>
			<source>label</source>
			<translation>SSL-Modus:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_connec</source>
			<translation>Verbindung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connec</source>
			<translation>lbl_connec</translation>
		</message>
		<message>
			<source>lbl_connection_message</source>
			<translation>Die Verbindungsparameter für konnten nicht abgerufen werden:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection_message</source>
			<translation>lbl_connection_message</translation>
		</message>
		<message>
			<source>lbl_password</source>
			<translation>Kennwort:</translation>
		</message>
		<message>
			<source>tooltip_lbl_password</source>
			<translation>lbl_password</translation>
		</message>
		<message>
			<source>lbl_user_name</source>
			<translation>Name des Benutzers:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user_name</source>
			<translation>lbl_user_name</translation>
		</message>
	</context>
	<context>
		<name>admin_dbproject</name>
		<message>
			<source>title</source>
			<translation>Projekt erstellen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Aufgabe abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>btn_language</source>
			<translation>btn_language</translation>
		</message>
		<message>
			<source>tooltip_btn_language</source>
			<translation>Manage languages</translation>
		</message>
		<message>
			<source>dlg_admin_dbproject</source>
			<translation>Projekt erstellen</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_dbproject</source>
			<translation>dlg_admin_dbproject</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>Projektschema Einstellungen</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filter SRID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>Bezeichner des räumlichen Bezugs. Es sind nur die in der nachstehenden Tabelle aufgeführten Werte zulässig.</translation>
		</message>
		<message>
			<source>lbl_locale</source>
			<translation>Lokal:</translation>
		</message>
		<message>
			<source>tooltip_lbl_locale</source>
			<translation>Schemasprache</translation>
		</message>
		<message>
			<source>lbl_project_name</source>
			<translation>Name des Projekts:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_name</source>
			<translation>Name eines neuen Schemas. Der Name muss in Kleinbuchstaben geschrieben werden, wobei nur Buchstaben des englischen Alphabets und keine Leerzeichen oder Bindestriche verwendet werden dürfen</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Projekttyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_source</source>
			<translation>Datenquelle:</translation>
		</message>
		<message>
			<source>tooltip_lbl_source</source>
			<translation>lbl_source</translation>
		</message>
		<message>
			<source>rdb_empty</source>
			<translation>Leere Daten</translation>
		</message>
		<message>
			<source>tooltip_rdb_empty</source>
			<translation>rdb_empty</translation>
		</message>
		<message>
			<source>rdb_sample_full</source>
			<translation>Vollständiges Beispiel</translation>
		</message>
		<message>
			<source>tooltip_rdb_sample_full</source>
			<translation>rdb_sample_full</translation>
		</message>
		<message>
			<source>rdb_sample_inv</source>
			<translation>Beispiel für eine Bestandsaufnahme</translation>
		</message>
		<message>
			<source>tooltip_rdb_sample_inv</source>
			<translation>rdb_sample_inv</translation>
		</message>
	</context>
	<context>
		<name>admin_gisproject</name>
		<message>
			<source>title</source>
			<translation>GIS-Projekt erstellen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>btn_gis_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_folder</source>
			<translation>btn_gis_folder</translation>
		</message>
		<message>
			<source>dlg_admin_gisproject</source>
			<translation>GIS-Projekt erstellen</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_gisproject</source>
			<translation>dlg_admin_gisproject</translation>
		</message>
		<message>
			<source>lbl_export_user_pass</source>
			<translation>Benutzerpasswort exportieren:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_user_pass</source>
			<translation>lbl_export_user_pass</translation>
		</message>
		<message>
			<source>lbl_gis_file</source>
			<translation>Name der GIS-Datei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_file</source>
			<translation>lbl_gis_file</translation>
		</message>
		<message>
			<source>lbl_gis_folder</source>
			<translation>GIS-Ordner:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_folder</source>
			<translation>lbl_gis_folder</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Projekttyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>txt_roletype</source>
			<translation>Inventar</translation>
		</message>
		<message>
			<source>tooltip_txt_roletype</source>
			<translation>txt_roletype</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_hot_update</name>
		<message>
			<source>title</source>
			<translation>Manage languages</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Apply</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>btn_apply</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Close</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_manage_language_hot_update</source>
			<translation>Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_language_hot_update</source>
			<translation>btn_manage_language_hot_update</translation>
		</message>
		<message>
			<source>btn_manage_language_multilang</source>
			<translation>Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_language_multilang</source>
			<translation>btn_manage_language_multilang</translation>
		</message>
		<message>
			<source>btn_refresh</source>
			<translation>Refresh</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh</source>
			<translation>btn_refresh</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>chk_add_tab_data</source>
			<translation>Translate tab_data</translation>
		</message>
		<message>
			<source>tooltip_chk_add_tab_data</source>
			<translation>chk_add_tab_data</translation>
		</message>
		<message>
			<source>chk_use_selected_tables</source>
			<translation>Use selected tables only</translation>
		</message>
		<message>
			<source>tooltip_chk_use_selected_tables</source>
			<translation>chk_use_selected_tables</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_hot_update</source>
			<translation>Manage languages</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_hot_update</source>
			<translation>dlg_admin_i18n_hot_update</translation>
		</message>
		<message>
			<source>grb_connection</source>
			<translation>Connection</translation>
		</message>
		<message>
			<source>tooltip_grb_connection</source>
			<translation>grb_connection</translation>
		</message>
		<message>
			<source>grb_params</source>
			<translation>Parameters</translation>
		</message>
		<message>
			<source>tooltip_grb_params</source>
			<translation>grb_params</translation>
		</message>
		<message>
			<source>grb_schemas</source>
			<translation>Schemas</translation>
		</message>
		<message>
			<source>tooltip_grb_schemas</source>
			<translation>grb_schemas</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Language:</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Language</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Connection name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_schema_selection</source>
			<translation>Schema: select a row below</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_selection</source>
			<translation>lbl_schema_selection</translation>
		</message>
		<message>
			<source>lbl_tables</source>
			<translation>Tables filter:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tables</source>
			<translation>lbl_tables</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Hot Update</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_2</source>
			<translation>Multilang</translation>
		</message>
		<message>
			<source>tooltip_tab_2</source>
			<translation>tab_2</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_languages</name>
		<message>
			<source>title</source>
			<translation>Manage language</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Close</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_download</source>
			<translation>Download</translation>
		</message>
		<message>
			<source>tooltip_btn_download</source>
			<translation>btn_download</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>chk_download_latest</source>
			<translation>Download latest translation version</translation>
		</message>
		<message>
			<source>tooltip_chk_download_latest</source>
			<translation>Download translations from the latest published version instead of the version matched to this plugin. For advanced users only.</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_languages</source>
			<translation>Manage language</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_languages</source>
			<translation>dlg_admin_i18n_languages</translation>
		</message>
		<message>
			<source>grb_locales</source>
			<translation>Available Languages</translation>
		</message>
		<message>
			<source>tooltip_grb_locales</source>
			<translation>grb_locales</translation>
		</message>
		<message>
			<source>lbl_language</source>
			<translation>Select a language to manage</translation>
		</message>
		<message>
			<source>tooltip_lbl_language</source>
			<translation>lbl_language</translation>
		</message>
		<message>
			<source>txt_filter</source>
			<translation>Filter locales...</translation>
		</message>
		<message>
			<source>tooltip_txt_filter</source>
			<translation>txt_filter</translation>
		</message>
	</context>
	<context>
		<name>admin_import_osm</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Ausführen</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_admin_import_osm</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_import_osm</source>
			<translation>dlg_admin_import_osm</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Gemeinden</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Logs</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>admin_manage_schemas</name>
		<message>
			<source>title</source>
			<translation>Manage schemas</translation>
		</message>
		<message>
			<source>btn_activate_audit</source>
			<translation>Activate</translation>
		</message>
		<message>
			<source>tooltip_btn_activate_audit</source>
			<translation>Generate a copy of network layers from the anchor schema into audit</translation>
		</message>
		<message>
			<source>btn_cibs_copy</source>
			<translation>Copy data</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_copy</source>
			<translation>btn_cibs_copy</translation>
		</message>
		<message>
			<source>btn_cibs_create</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_create</source>
			<translation>btn_cibs_create</translation>
		</message>
		<message>
			<source>btn_cibs_integrate</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_integrate</source>
			<translation>Link cibs to the selected network schema</translation>
		</message>
		<message>
			<source>btn_cibs_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_update</source>
			<translation>btn_cibs_update</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Close</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_cm_integrate</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_integrate</source>
			<translation>Link CM to the selected network schema</translation>
		</message>
		<message>
			<source>btn_cm_qgis</source>
			<translation>btn_cm_qgis</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_qgis</source>
			<translation>Create pschema qgis file</translation>
		</message>
		<message>
			<source>btn_cm_sample</source>
			<translation>Sample</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_sample</source>
			<translation>Load CM example data for the selected network schema</translation>
		</message>
		<message>
			<source>btn_create_am</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_create_am</source>
			<translation>btn_create_am</translation>
		</message>
		<message>
			<source>btn_create_am_sample</source>
			<translation>+ Sample</translation>
		</message>
		<message>
			<source>tooltip_btn_create_am_sample</source>
			<translation>Create AM schema with sample leaks data</translation>
		</message>
		<message>
			<source>btn_create_audit</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_create_audit</source>
			<translation>btn_create_audit</translation>
		</message>
		<message>
			<source>btn_create_cm</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cm</source>
			<translation>btn_create_cm</translation>
		</message>
		<message>
			<source>btn_delete_am</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_am</source>
			<translation>btn_delete_am</translation>
		</message>
		<message>
			<source>btn_delete_audit</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_audit</source>
			<translation>btn_delete_audit</translation>
		</message>
		<message>
			<source>btn_delete_cm</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_cm</source>
			<translation>btn_delete_cm</translation>
		</message>
		<message>
			<source>btn_i18n_create</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_create</source>
			<translation>btn_i18n_create</translation>
		</message>
		<message>
			<source>btn_i18n_delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_delete</source>
			<translation>btn_i18n_delete</translation>
		</message>
		<message>
			<source>btn_i18n_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_update</source>
			<translation>btn_i18n_update</translation>
		</message>
		<message>
			<source>btn_integrate_am</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_integrate_am</source>
			<translation>Wire am into the selected WS network schema</translation>
		</message>
		<message>
			<source>btn_integrate_am_sample</source>
			<translation>Int. + Sample</translation>
		</message>
		<message>
			<source>tooltip_btn_integrate_am_sample</source>
			<translation>Integrate am and seed config from parent WS catalogs</translation>
		</message>
		<message>
			<source>btn_languages</source>
			<translation>Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_languages</source>
			<translation>btn_languages</translation>
		</message>
		<message>
			<source>btn_network_delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_network_delete</source>
			<translation>btn_network_delete</translation>
		</message>
		<message>
			<source>btn_network_rename</source>
			<translation>Rename</translation>
		</message>
		<message>
			<source>tooltip_btn_network_rename</source>
			<translation>btn_network_rename</translation>
		</message>
		<message>
			<source>btn_refresh</source>
			<translation>Refresh</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh</source>
			<translation>btn_refresh</translation>
		</message>
		<message>
			<source>btn_reload_audit_triggers</source>
			<translation>Triggers</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_audit_triggers</source>
			<translation>Refresh audit triggers on the anchor schema</translation>
		</message>
		<message>
			<source>btn_update_am</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_am</source>
			<translation>btn_update_am</translation>
		</message>
		<message>
			<source>btn_update_audit</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_audit</source>
			<translation>btn_update_audit</translation>
		</message>
		<message>
			<source>btn_update_cm</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_cm</source>
			<translation>btn_update_cm</translation>
		</message>
		<message>
			<source>btn_update_network</source>
			<translation>Update network</translation>
		</message>
		<message>
			<source>tooltip_btn_update_network</source>
			<translation>Update anchor WS/UD and linked satellites to the plugin version</translation>
		</message>
		<message>
			<source>btn_utils_create</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_create</source>
			<translation>btn_utils_create</translation>
		</message>
		<message>
			<source>btn_utils_integrate</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_integrate</source>
			<translation>Link utils to the selected network schema</translation>
		</message>
		<message>
			<source>btn_utils_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_update</source>
			<translation>btn_utils_update</translation>
		</message>
		<message>
			<source>dlg_admin_manage_schemas</source>
			<translation>Manage schemas</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_manage_schemas</source>
			<translation>dlg_admin_manage_schemas</translation>
		</message>
		<message>
			<source>grb_am</source>
			<translation>AM</translation>
		</message>
		<message>
			<source>tooltip_grb_am</source>
			<translation>grb_am</translation>
		</message>
		<message>
			<source>grb_audit</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>tooltip_grb_audit</source>
			<translation>grb_audit</translation>
		</message>
		<message>
			<source>grb_cibs</source>
			<translation>Cibs</translation>
		</message>
		<message>
			<source>tooltip_grb_cibs</source>
			<translation>grb_cibs</translation>
		</message>
		<message>
			<source>grb_cm</source>
			<translation>CM</translation>
		</message>
		<message>
			<source>tooltip_grb_cm</source>
			<translation>grb_cm</translation>
		</message>
		<message>
			<source>grb_connection</source>
			<translation>Connection</translation>
		</message>
		<message>
			<source>tooltip_grb_connection</source>
			<translation>grb_connection</translation>
		</message>
		<message>
			<source>grb_i18n</source>
			<translation>Multilang</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n</source>
			<translation>grb_i18n</translation>
		</message>
		<message>
			<source>grb_network</source>
			<translation>Network (WS / UD)</translation>
		</message>
		<message>
			<source>tooltip_grb_network</source>
			<translation>grb_network</translation>
		</message>
		<message>
			<source>grb_utils</source>
			<translation>Utils</translation>
		</message>
		<message>
			<source>tooltip_grb_utils</source>
			<translation>grb_utils</translation>
		</message>
		<message>
			<source>lbl_am_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_am_info</source>
			<translation>lbl_am_info</translation>
		</message>
		<message>
			<source>lbl_audit_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_audit_info</source>
			<translation>lbl_audit_info</translation>
		</message>
		<message>
			<source>lbl_cibs_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_cibs_info</source>
			<translation>lbl_cibs_info</translation>
		</message>
		<message>
			<source>lbl_cm_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_cm_info</source>
			<translation>lbl_cm_info</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Connection name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_i18n_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_i18n_info</source>
			<translation>lbl_i18n_info</translation>
		</message>
		<message>
			<source>lbl_network_selection</source>
			<translation>Anchor: select a row below</translation>
		</message>
		<message>
			<source>tooltip_lbl_network_selection</source>
			<translation>lbl_network_selection</translation>
		</message>
		<message>
			<source>lbl_utils_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_utils_info</source>
			<translation>lbl_utils_info</translation>
		</message>
	</context>
	<context>
		<name>admin_markdown</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_generate</source>
			<translation>Erzeugen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_generate</source>
			<translation>btn_generate</translation>
		</message>
		<message>
			<source>dlg_admin_markdown</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_markdown</source>
			<translation>dlg_admin_markdown</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Projekttyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Name des Schemas:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lb_path</source>
			<translation>Dateipfad:</translation>
		</message>
		<message>
			<source>tooltip_lb_path</source>
			<translation>lb_path</translation>
		</message>
		<message>
			<source>pushButton_2</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_pushButton_2</source>
			<translation>pushButton_2</translation>
		</message>
	</context>
	<context>
		<name>admin_markdown_generator</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_generate</source>
			<translation>Erzeugen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_generate</source>
			<translation>btn_generate</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>cmb_projecttype</source>
			<translation>ud</translation>
		</message>
		<message>
			<source>tooltip_cmb_projecttype</source>
			<translation>cmb_projecttype</translation>
		</message>
		<message>
			<source>dlg_admin_markdown_generator</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_markdown_generator</source>
			<translation>dlg_admin_markdown_generator</translation>
		</message>
		<message>
			<source>grp_markdown_destination</source>
			<translation>Markdown-Beschreibung</translation>
		</message>
		<message>
			<source>tooltip_grp_markdown_destination</source>
			<translation>grp_markdown_destination</translation>
		</message>
		<message>
			<source>grp_origin_schema</source>
			<translation>Ursprungsschema</translation>
		</message>
		<message>
			<source>tooltip_grp_origin_schema</source>
			<translation>grp_origin_schema</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Projekttyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Name des Schemas:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lb_path</source>
			<translation>Dateipfad:</translation>
		</message>
		<message>
			<source>tooltip_lb_path</source>
			<translation>lb_path</translation>
		</message>
	</context>
	<context>
		<name>admin_projectinfo</name>
		<message>
			<source>title</source>
			<translation>SQL-Update</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>dlg_admin_projectinfo</source>
			<translation>SQL-Update</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_projectinfo</source>
			<translation>dlg_admin_projectinfo</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Informationen über neue Updates</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>tab_main</source>
			<translation>Hauptseite</translation>
		</message>
		<message>
			<source>tooltip_tab_main</source>
			<translation>tab_main</translation>
		</message>
	</context>
	<context>
		<name>admin_renameproj</name>
		<message>
			<source>title</source>
			<translation>Umbenennen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>dlg_admin_renameproj</source>
			<translation>Umbenennen</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_renameproj</source>
			<translation>dlg_admin_renameproj</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Bitte geben Sie einen neuen Projektnamen ein:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>lbl_rename_copy</translation>
		</message>
	</context>
	<context>
		<name>admin_visitclass</name>
		<message>
			<source>title</source>
			<translation>Manage visit class</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_class_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_class_cancel</source>
			<translation>btn_class_cancel</translation>
		</message>
		<message>
			<source>btn_class_ok</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_class_ok</source>
			<translation>btn_class_ok</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_param_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_param_create</source>
			<translation>btn_param_create</translation>
		</message>
		<message>
			<source>btn_param_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_param_delete</source>
			<translation>btn_param_delete</translation>
		</message>
		<message>
			<source>btn_param_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_param_update</source>
			<translation>btn_param_update</translation>
		</message>
		<message>
			<source>dlg_admin_visitclass</source>
			<translation>Manage visit class</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_visitclass</source>
			<translation>dlg_admin_visitclass</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Klasse</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Parameter</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Aktiv:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_class_id</source>
			<translation>Klasse id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_class_id</source>
			<translation>lbl_class_id</translation>
		</message>
		<message>
			<source>lbl_class_name</source>
			<translation>Name der Klasse:</translation>
		</message>
		<message>
			<source>tooltip_lbl_class_name</source>
			<translation>lbl_class_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Deskript:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_feat_type</source>
			<translation>Merkmalstyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_type</source>
			<translation>lbl_feat_type</translation>
		</message>
		<message>
			<source>lbl_multi_event</source>
			<translation>Multi-Event:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multi_event</source>
			<translation>lbl_multi_event</translation>
		</message>
		<message>
			<source>lbl_multi_feat</source>
			<translation>Multi-Funktion:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multi_feat</source>
			<translation>lbl_multi_feat</translation>
		</message>
		<message>
			<source>lbl_param_opt</source>
			<translation>Param-Optionen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_param_opt</source>
			<translation>lbl_param_opt</translation>
		</message>
		<message>
			<source>lbl_viewname</source>
			<translation>Name anzeigen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_viewname</source>
			<translation>lbl_viewname</translation>
		</message>
		<message>
			<source>lbl_visit_type</source>
			<translation>Art des Besuchs:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_type</source>
			<translation>lbl_visit_type</translation>
		</message>
	</context>
	<context>
		<name>admin_visitparam</name>
		<message>
			<source>title</source>
			<translation>Besuchsparameter verwalten</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_admin_visitparam</source>
			<translation>Besuchsparameter verwalten</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_visitparam</source>
			<translation>dlg_admin_visitparam</translation>
		</message>
		<message>
			<source>grb_params</source>
			<translation>Parameter</translation>
		</message>
		<message>
			<source>tooltip_grb_params</source>
			<translation>grb_params</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation>Code:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_data_type</source>
			<translation>Datentyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_type</source>
			<translation>lbl_data_type</translation>
		</message>
		<message>
			<source>lbl_default_value</source>
			<translation>Standardwert:</translation>
		</message>
		<message>
			<source>tooltip_lbl_default_value</source>
			<translation>lbl_default_value</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Deskript:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_editable</source>
			<translation>Bearbeitbar:</translation>
		</message>
		<message>
			<source>tooltip_lbl_editable</source>
			<translation>lbl_editable</translation>
		</message>
		<message>
			<source>lbl_enabled</source>
			<translation>Aktiviert:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enabled</source>
			<translation>lbl_enabled</translation>
		</message>
		<message>
			<source>lbl_form_type</source>
			<translation>Art des Formulars:</translation>
		</message>
		<message>
			<source>tooltip_lbl_form_type</source>
			<translation>lbl_form_type</translation>
		</message>
		<message>
			<source>lbl_mandatory</source>
			<translation>Obligatorisch:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mandatory</source>
			<translation>lbl_mandatory</translation>
		</message>
		<message>
			<source>lbl_parameter_name</source>
			<translation>Name des Parameters:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_name</source>
			<translation>lbl_parameter_name</translation>
		</message>
		<message>
			<source>lbl_parameter_type</source>
			<translation>Parameter-Typ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_type</source>
			<translation>lbl_parameter_type</translation>
		</message>
		<message>
			<source>lbl_query_text</source>
			<translation>Abfragetext:</translation>
		</message>
		<message>
			<source>tooltip_lbl_query_text</source>
			<translation>lbl_query_text</translation>
		</message>
		<message>
			<source>lbl_short_descript</source>
			<translation>Kurzbeschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_short_descript</source>
			<translation>lbl_short_descript</translation>
		</message>
		<message>
			<source>lbl_widgettype</source>
			<translation>Widget-Typ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgettype</source>
			<translation>lbl_widgettype</translation>
		</message>
	</context>
	<context>
		<name>arc_fusion</name>
		<message>
			<source>title</source>
			<translation>Lichtbogenfusion</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_arc_fusion</source>
			<translation>Lichtbogenfusion</translation>
		</message>
		<message>
			<source>tooltip_dlg_arc_fusion</source>
			<translation>dlg_arc_fusion</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>lbl_arc1asset</source>
			<translation>Arc 1 asset:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc1asset</source>
			<translation>lbl_arc1asset</translation>
		</message>
		<message>
			<source>lbl_arc1cat</source>
			<translation>Katalog Bogen 1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc1cat</source>
			<translation>lbl_arc1cat</translation>
		</message>
		<message>
			<source>lbl_arc2asset</source>
			<translation>Arc 2 asset:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc2asset</source>
			<translation>lbl_arc2asset</translation>
		</message>
		<message>
			<source>lbl_arc2cat</source>
			<translation>Arc 2 Katalog:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc2cat</source>
			<translation>lbl_arc2cat</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Enddatum:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_new_asset</source>
			<translation>New asset:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_asset</source>
			<translation>lbl_new_asset</translation>
		</message>
		<message>
			<source>lbl_new_cat</source>
			<translation>Neuer Katalog:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_cat</source>
			<translation>lbl_new_cat</translation>
		</message>
		<message>
			<source>lbl_nodeaction</source>
			<translation>Knotenpunkt-Aktion:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodeaction</source>
			<translation>lbl_nodeaction</translation>
		</message>
		<message>
			<source>lbl_statetype</source>
			<translation>Staatstyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_statetype</source>
			<translation>lbl_statetype</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Workcat id Ende:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Lichtbogenfusion</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>assignation</name>
		<message>
			<source>title</source>
			<translation>Pannenhilfe-Zuweisung</translation>
		</message>
		<message>
			<source>chk_all_leaks</source>
			<translation>Alle Lecks verwenden</translation>
		</message>
		<message>
			<source>tooltip_chk_all_leaks</source>
			<translation>Calculates leaks per kilometer per year using all available data, regardless of the &apos;years to calculate&apos; parameter.</translation>
		</message>
		<message>
			<source>dlg_assignation</source>
			<translation>Pannenhilfe-Zuweisung</translation>
		</message>
		<message>
			<source>tooltip_dlg_assignation</source>
			<translation>dlg_assignation</translation>
		</message>
		<message>
			<source>lbl_buffer</source>
			<translation>Pufferabstand (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_buffer</source>
			<translation>Distance from a leak at which pipes are selected to be assigned that leak.</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Nach Baudatum filtern:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>Uses only pipes that match the builtdate range of the initial one.</translation>
		</message>
		<message>
			<source>lbl_builtdate_range</source>
			<translation>Erbauter Datumsbereich (Jahre):</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate_range</source>
			<translation>Built date range, in years before and after the initial pipe.</translation>
		</message>
		<message>
			<source>lbl_cluster_length</source>
			<translation>Länge des Clusters (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_cluster_length</source>
			<translation>Maximum sum of pipe lengths within a cluster, in meters.</translation>
		</message>
		<message>
			<source>lbl_diameter</source>
			<translation>Nach Durchmesser filtern:</translation>
		</message>
		<message>
			<source>tooltip_lbl_diameter</source>
			<translation>Uses only pipes that match the diameter range of the initial one.</translation>
		</message>
		<message>
			<source>lbl_diameter_range</source>
			<translation>Durchmesserbereich:</translation>
		</message>
		<message>
			<source>tooltip_lbl_diameter_range</source>
			<translation>Diameter range based on factors of the initial pipe.</translation>
		</message>
		<message>
			<source>lbl_leaks</source>
			<translation>Lecks</translation>
		</message>
		<message>
			<source>tooltip_lbl_leaks</source>
			<translation>lbl_leaks</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Nach Material filtern:</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>Uses only pipes of the same material as the initial one.</translation>
		</message>
		<message>
			<source>lbl_max_distance</source>
			<translation>Maximale Entfernung (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_max_distance</source>
			<translation>Maximum distance, in meters, between the initial pipe and other pipes included in the cluster.</translation>
		</message>
		<message>
			<source>lbl_pipes</source>
			<translation>Pfeifen</translation>
		</message>
		<message>
			<source>tooltip_lbl_pipes</source>
			<translation>lbl_pipes</translation>
		</message>
		<message>
			<source>lbl_years</source>
			<translation>Zu berechnende Jahre:</translation>
		</message>
		<message>
			<source>tooltip_lbl_years</source>
			<translation>Number of years of leak data to consider, based on recency.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>audit</name>
		<message>
			<source>title</source>
			<translation>Prüfung</translation>
		</message>
		<message>
			<source>dlg_audit</source>
			<translation>Prüfung</translation>
		</message>
		<message>
			<source>tooltip_dlg_audit</source>
			<translation>dlg_audit</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Aktualisierte Werte</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
	</context>
	<context>
		<name>audit_manager</name>
		<message>
			<source>title</source>
			<translation>Audit Manager</translation>
		</message>
		<message>
			<source>dlg_audit_manager</source>
			<translation>Audit Manager</translation>
		</message>
		<message>
			<source>tooltip_dlg_audit_manager</source>
			<translation>Audit Manager</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Logs</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Logs</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Datum bis</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Datum bis</translation>
		</message>
	</context>
	<context>
		<name>auxcircle</name>
		<message>
			<source>title</source>
			<translation>CAD Zeichnen Kreis</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_delete_prev</source>
			<translation>Vorherige Kreise löschen</translation>
		</message>
		<message>
			<source>tooltip_chk_delete_prev</source>
			<translation>chk_delete_prev</translation>
		</message>
		<message>
			<source>dlg_auxcircle</source>
			<translation>CAD Zeichnen Kreis</translation>
		</message>
		<message>
			<source>tooltip_dlg_auxcircle</source>
			<translation>dlg_auxcircle</translation>
		</message>
		<message>
			<source>lbl_ins_radius</source>
			<translation>Radius einfügen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ins_radius</source>
			<translation>lbl_ins_radius</translation>
		</message>
		<message>
			<source>radius</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_radius</source>
			<translation>radius</translation>
		</message>
	</context>
	<context>
		<name>auxpoint</name>
		<message>
			<source>title</source>
			<translation>CAD Punkt hinzufügen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_delete_prev</source>
			<translation>Vorherige Punkte löschen</translation>
		</message>
		<message>
			<source>tooltip_chk_delete_prev</source>
			<translation>chk_delete_prev</translation>
		</message>
		<message>
			<source>dist_x</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_dist_x</source>
			<translation>dist_x</translation>
		</message>
		<message>
			<source>dist_y</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_dist_y</source>
			<translation>dist_y</translation>
		</message>
		<message>
			<source>dlg_auxpoint</source>
			<translation>CAD Punkt hinzufügen</translation>
		</message>
		<message>
			<source>tooltip_dlg_auxpoint</source>
			<translation>dlg_auxpoint</translation>
		</message>
		<message>
			<source>grb_from</source>
			<translation>Von:</translation>
		</message>
		<message>
			<source>tooltip_grb_from</source>
			<translation>grb_from</translation>
		</message>
		<message>
			<source>lbl_distx</source>
			<translation>Entfernung (X):</translation>
		</message>
		<message>
			<source>tooltip_lbl_distx</source>
			<translation>lbl_distx</translation>
		</message>
		<message>
			<source>lbl_disty</source>
			<translation>Entfernung (Y):</translation>
		</message>
		<message>
			<source>tooltip_lbl_disty</source>
			<translation>lbl_disty</translation>
		</message>
		<message>
			<source>rb_left</source>
			<translation>Init Punkt</translation>
		</message>
		<message>
			<source>tooltip_rb_left</source>
			<translation>rb_left</translation>
		</message>
		<message>
			<source>rb_right</source>
			<translation>Endpunkt</translation>
		</message>
		<message>
			<source>tooltip_rb_right</source>
			<translation>rb_right</translation>
		</message>
	</context>
	<context>
		<name>campaign_management</name>
		<message>
			<source>title</source>
			<translation>Kampagnenleiter</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_child</source>
			<translation>Create Child Campaign</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_child</source>
			<translation>campaign_btn_child</translation>
		</message>
		<message>
			<source>campaign_btn_delete</source>
			<translation>Kampagne löschen</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_delete</source>
			<translation>Kampagne löschen</translation>
		</message>
		<message>
			<source>campaign_btn_open</source>
			<translation>Offene Kampagne</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_open</source>
			<translation>Offene Kampagne</translation>
		</message>
		<message>
			<source>campaign_chk_show_nulls</source>
			<translation>Nullwerte anzeigen</translation>
		</message>
		<message>
			<source>tooltip_campaign_chk_show_nulls</source>
			<translation>Leere Werte anzeigen</translation>
		</message>
		<message>
			<source>dlg_campaign_management</source>
			<translation>Kampagnenleiter</translation>
		</message>
		<message>
			<source>tooltip_dlg_campaign_management</source>
			<translation>Verwaltung von Kampagnen</translation>
		</message>
		<message>
			<source>lbl_column_filter_dates</source>
			<translation>Spalte Daten filtern</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter_dates</source>
			<translation>Spalte Daten filtern:</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Von:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>Von:</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Bis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>An:</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Staat</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Staat:</translation>
		</message>
	</context>
	<context>
		<name>check_project</name>
		<message>
			<source>title</source>
			<translation>Projekt prüfen</translation>
		</message>
		<message>
			<source>brb_database_check</source>
			<translation>Gesundheitscheck der Datenbank:</translation>
		</message>
		<message>
			<source>tooltip_brb_database_check</source>
			<translation>brb_database_check</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_check_project</source>
			<translation>Projekt prüfen</translation>
		</message>
		<message>
			<source>tooltip_dlg_check_project</source>
			<translation>dlg_check_project</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_system_check</source>
			<translation>Überprüfung des Systemzustands:</translation>
		</message>
		<message>
			<source>tooltip_grb_system_check</source>
			<translation>grb_system_check</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Datenbank-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Logs</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>check_project_cm</name>
		<message>
			<source>title</source>
			<translation>Projekt prüfen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>chk_manage_config</source>
			<translation>Verwaltungskonfigurationen prüfen</translation>
		</message>
		<message>
			<source>tooltip_chk_manage_config</source>
			<translation>chk_manage_config</translation>
		</message>
		<message>
			<source>dlg_check_project_cm</source>
			<translation>Projekt prüfen</translation>
		</message>
		<message>
			<source>tooltip_dlg_check_project_cm</source>
			<translation>dlg_check_project_cm</translation>
		</message>
		<message>
			<source>grb_database_health_check</source>
			<translation>Gesundheitscheck der Datenbank</translation>
		</message>
		<message>
			<source>tooltip_grb_database_health_check</source>
			<translation>grb_database_health_check</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_system_health_check</source>
			<translation>Überprüfung des Systemzustands</translation>
		</message>
		<message>
			<source>tooltip_grb_system_health_check</source>
			<translation>grb_system_health_check</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Datenbank-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Logs</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>common</name>
		<message>
			<source>btn_help</source>
			<translation>Hilfe</translation>
		</message>
		<message>
			<source>tooltip_btn_help</source>
			<translation>Hilfe</translation>
		</message>
	</context>
	<context>
		<name>config</name>
		<message>
			<source>title</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_dlg_config</source>
			<translation>dlg_config</translation>
		</message>
		<message>
			<source>grb_addfields</source>
			<translation>Addfields</translation>
		</message>
		<message>
			<source>tooltip_grb_addfields</source>
			<translation>grb_addfields</translation>
		</message>
		<message>
			<source>grb_admin_om</source>
			<translation>O&amp;&amp;M</translation>
		</message>
		<message>
			<source>tooltip_grb_admin_om</source>
			<translation>grb_admin_om</translation>
		</message>
		<message>
			<source>grb_admin_other</source>
			<translation>Andere</translation>
		</message>
		<message>
			<source>tooltip_grb_admin_other</source>
			<translation>grb_admin_other</translation>
		</message>
		<message>
			<source>grb_arc</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>tooltip_grb_arc</source>
			<translation>grb_arc</translation>
		</message>
		<message>
			<source>grb_basic</source>
			<translation>Grundlegend</translation>
		</message>
		<message>
			<source>tooltip_grb_basic</source>
			<translation>grb_basic</translation>
		</message>
		<message>
			<source>grb_category_type</source>
			<translation>Kategorie Typ</translation>
		</message>
		<message>
			<source>tooltip_grb_category_type</source>
			<translation>grb_category_type</translation>
		</message>
		<message>
			<source>grb_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_grb_connec</source>
			<translation>grb_connec</translation>
		</message>
		<message>
			<source>grb_epa</source>
			<translation>Epa</translation>
		</message>
		<message>
			<source>tooltip_grb_epa</source>
			<translation>grb_epa</translation>
		</message>
		<message>
			<source>grb_fluid_type</source>
			<translation>Flüssigkeitstyp</translation>
		</message>
		<message>
			<source>tooltip_grb_fluid_type</source>
			<translation>grb_fluid_type</translation>
		</message>
		<message>
			<source>grb_function_type</source>
			<translation>Funktionstyp</translation>
		</message>
		<message>
			<source>tooltip_grb_function_type</source>
			<translation>grb_function_type</translation>
		</message>
		<message>
			<source>grb_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_grb_gully</source>
			<translation>grb_gully</translation>
		</message>
		<message>
			<source>grb_inventory</source>
			<translation>Bestandsaufnahme</translation>
		</message>
		<message>
			<source>tooltip_grb_inventory</source>
			<translation>grb_inventory</translation>
		</message>
		<message>
			<source>grb_link</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>tooltip_grb_link</source>
			<translation>grb_link</translation>
		</message>
		<message>
			<source>grb_location_type</source>
			<translation>Standorttyp</translation>
		</message>
		<message>
			<source>tooltip_grb_location_type</source>
			<translation>grb_location_type</translation>
		</message>
		<message>
			<source>grb_masterplan</source>
			<translation>MasterPlan</translation>
		</message>
		<message>
			<source>tooltip_grb_masterplan</source>
			<translation>grb_masterplan</translation>
		</message>
		<message>
			<source>grb_node</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>tooltip_grb_node</source>
			<translation>grb_node</translation>
		</message>
		<message>
			<source>grb_om</source>
			<translation>O&amp;&amp;M</translation>
		</message>
		<message>
			<source>tooltip_grb_om</source>
			<translation>grb_om</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Andere</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_system</source>
			<translation>System</translation>
		</message>
		<message>
			<source>tooltip_grb_system</source>
			<translation>grb_system</translation>
		</message>
		<message>
			<source>grb_topology</source>
			<translation>Topologie</translation>
		</message>
		<message>
			<source>tooltip_grb_topology</source>
			<translation>grb_topology</translation>
		</message>
		<message>
			<source>grb_utils</source>
			<translation>Werkzeuge</translation>
		</message>
		<message>
			<source>tooltip_grb_utils</source>
			<translation>grb_utils</translation>
		</message>
		<message>
			<source>tab_addfields</source>
			<translation>Addfields</translation>
		</message>
		<message>
			<source>tooltip_tab_addfields</source>
			<translation>tab_addfields</translation>
		</message>
		<message>
			<source>tab_admin</source>
			<translation>Verwaltung</translation>
		</message>
		<message>
			<source>tooltip_tab_admin</source>
			<translation>tab_admin</translation>
		</message>
		<message>
			<source>tab_basic</source>
			<translation>Grundlegend</translation>
		</message>
		<message>
			<source>tooltip_tab_basic</source>
			<translation>tab_basic</translation>
		</message>
		<message>
			<source>tab_featurecat</source>
			<translation>Featurecat</translation>
		</message>
		<message>
			<source>tooltip_tab_featurecat</source>
			<translation>tab_featurecat</translation>
		</message>
		<message>
			<source>tab_mantype</source>
			<translation>Typ Mann</translation>
		</message>
		<message>
			<source>tooltip_tab_mantype</source>
			<translation>tab_mantype</translation>
		</message>
	</context>
	<context>
		<name>connect_link</name>
		<message>
			<source>title</source>
			<translation>Mit dem Netzwerk verbinden</translation>
		</message>
		<message>
			<source>dlg_connect_link</source>
			<translation>Mit dem Netzwerk verbinden</translation>
		</message>
		<message>
			<source>tooltip_dlg_connect_link</source>
			<translation>dlg_connect_link</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Link-Konfiguration</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Verbindungen</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_3</source>
			<translation>Bögen</translation>
		</message>
		<message>
			<source>tooltip_groupBox_3</source>
			<translation>groupBox_3</translation>
		</message>
		<message>
			<source>groupBox_4</source>
			<translation>Nodes</translation>
		</message>
		<message>
			<source>tooltip_groupBox_4</source>
			<translation>groupBox_4</translation>
		</message>
		<message>
			<source>groupBox_5</source>
			<translation>Extra filters</translation>
		</message>
		<message>
			<source>tooltip_groupBox_5</source>
			<translation>groupBox_5</translation>
		</message>
		<message>
			<source>tab_connect</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>tooltip_tab_connect</source>
			<translation>tab_connect</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>csv</name>
		<message>
			<source>title</source>
			<translation>CSV importieren</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>btn_file_csv</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_csv</source>
			<translation>btn_file_csv</translation>
		</message>
		<message>
			<source>dlg_csv</source>
			<translation>CSV importieren</translation>
		</message>
		<message>
			<source>tooltip_dlg_csv</source>
			<translation>dlg_csv</translation>
		</message>
		<message>
			<source>lbl_decimal</source>
			<translation>Dezimaltrennzeichen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_decimal</source>
			<translation>lbl_decimal</translation>
		</message>
		<message>
			<source>lbl_delimiter</source>
			<translation>Begrenzungszeichen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_delimiter</source>
			<translation>lbl_delimiter</translation>
		</message>
		<message>
			<source>lbl_file</source>
			<translation>Datei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_file</source>
			<translation>lbl_file</translation>
		</message>
		<message>
			<source>lbl_ignore_header</source>
			<translation>Kopfzeilen ignorieren:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ignore_header</source>
			<translation>lbl_ignore_header</translation>
		</message>
		<message>
			<source>lbl_import_label</source>
			<translation>Import label:</translation>
		</message>
		<message>
			<source>tooltip_lbl_import_label</source>
			<translation>lbl_import_label</translation>
		</message>
		<message>
			<source>lbl_import_type</source>
			<translation>Art der Einfuhr:</translation>
		</message>
		<message>
			<source>tooltip_lbl_import_type</source>
			<translation>lbl_import_type</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_set_of_charac</source>
			<translation>Satz von Zeichen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_set_of_charac</source>
			<translation>lbl_set_of_charac</translation>
		</message>
		<message>
			<source>rb_comma</source>
			<translation>,</translation>
		</message>
		<message>
			<source>tooltip_rb_comma</source>
			<translation>rb_comma</translation>
		</message>
		<message>
			<source>rb_dec_comma</source>
			<translation>,</translation>
		</message>
		<message>
			<source>tooltip_rb_dec_comma</source>
			<translation>rb_dec_comma</translation>
		</message>
		<message>
			<source>rb_dec_period</source>
			<translation>.</translation>
		</message>
		<message>
			<source>tooltip_rb_dec_period</source>
			<translation>rb_dec_period</translation>
		</message>
		<message>
			<source>rb_semicolon</source>
			<translation>;</translation>
		</message>
		<message>
			<source>tooltip_rb_semicolon</source>
			<translation>rb_semicolon</translation>
		</message>
		<message>
			<source>rb_space</source>
			<translation>Weltraum</translation>
		</message>
		<message>
			<source>tooltip_rb_space</source>
			<translation>rb_space</translation>
		</message>
		<message>
			<source>tab_info</source>
			<translation>Info-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_info</source>
			<translation>tab_info</translation>
		</message>
		<message>
			<source>tab_preview</source>
			<translation>Vorschau</translation>
		</message>
		<message>
			<source>tooltip_tab_preview</source>
			<translation>tab_preview</translation>
		</message>
	</context>
	<context>
		<name>dimensioning</name>
		<message>
			<source>actionEdit</source>
			<translation>actionEdit</translation>
		</message>
		<message>
			<source>tooltip_actionEdit</source>
			<translation>Edit</translation>
		</message>
		<message>
			<source>actionOrientation</source>
			<translation>actionOrientation</translation>
		</message>
		<message>
			<source>tooltip_actionOrientation</source>
			<translation>Orientation</translation>
		</message>
		<message>
			<source>actionSnapping</source>
			<translation>actionSnapping</translation>
		</message>
		<message>
			<source>tooltip_actionSnapping</source>
			<translation>Snapping</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>grb_depth</source>
			<translation>Messungen</translation>
		</message>
		<message>
			<source>tooltip_grb_depth</source>
			<translation>grb_depth</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Andere</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_symbology</source>
			<translation>Kreis-Symbologie</translation>
		</message>
		<message>
			<source>tooltip_grb_symbology</source>
			<translation>grb_symbology</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>doc</name>
		<message>
			<source>title</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Geom hinzufügen</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>Geom hinzufügen</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Bewerbung</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>Bewerbung</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_path_doc</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path_doc</source>
			<translation>btn_path_doc</translation>
		</message>
		<message>
			<source>btn_path_url</source>
			<translation>Web</translation>
		</message>
		<message>
			<source>tooltip_btn_path_url</source>
			<translation>Öffnen Sie den Explorer, damit Sie den Webpfad auswählen können. Es ist auch möglich, den Pfad einfach in das Textfeld Link einzufügen</translation>
		</message>
		<message>
			<source>date</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_date</source>
			<translation>date</translation>
		</message>
		<message>
			<source>dlg_doc</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_dlg_doc</source>
			<translation>dlg_doc</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Datum:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_doc_name</source>
			<translation>Name des Arztes:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_name</source>
			<translation>lbl_doc_name</translation>
		</message>
		<message>
			<source>lbl_doc_type</source>
			<translation>Dokumenttyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_type</source>
			<translation>lbl_doc_type</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Link:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Beobachtungen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Besuchen Sie</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_doc</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_tab_doc</source>
			<translation>tab_doc</translation>
		</message>
		<message>
			<source>tab_elem</source>
			<translation>Element</translation>
		</message>
		<message>
			<source>tooltip_tab_elem</source>
			<translation>tab_elem</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_psector</source>
			<translation>Psektor</translation>
		</message>
		<message>
			<source>tooltip_tab_psector</source>
			<translation>tab_psector</translation>
		</message>
		<message>
			<source>tab_rel</source>
			<translation>Beziehungen</translation>
		</message>
		<message>
			<source>tooltip_tab_rel</source>
			<translation>tab_rel</translation>
		</message>
		<message>
			<source>tab_workcat</source>
			<translation>Workcat</translation>
		</message>
		<message>
			<source>tooltip_tab_workcat</source>
			<translation>tab_workcat</translation>
		</message>
	</context>
	<context>
		<name>doc_manager</name>
		<message>
			<source>title</source>
			<translation>Dokumentenmanagement</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_doc_manager</source>
			<translation>Dokumentenmanagement</translation>
		</message>
		<message>
			<source>tooltip_dlg_doc_manager</source>
			<translation>dlg_doc_manager</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtern nach: Name des Arztes</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>dscenario</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_properties</source>
			<translation>Eigenschaften</translation>
		</message>
		<message>
			<source>tooltip_btn_properties</source>
			<translation>btn_properties</translation>
		</message>
		<message>
			<source>dlg_dscenario</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_dscenario</source>
			<translation>dlg_dscenario</translation>
		</message>
	</context>
	<context>
		<name>dscenario_manager</name>
		<message>
			<source>title</source>
			<translation>Dszenario-Manager</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>     erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplizieren Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Aktiv umschalten</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Aktiv umschalten</translation>
		</message>
		<message>
			<source>btn_toolbox</source>
			<translation>Aktionen</translation>
		</message>
		<message>
			<source>tooltip_btn_toolbox</source>
			<translation>btn_toolbox</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>btn_update_dscenario</source>
			<translation>Aktuelles Dszenario</translation>
		</message>
		<message>
			<source>tooltip_btn_update_dscenario</source>
			<translation>btn_update_dscenario</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Inaktiv anzeigen</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Inaktiv anzeigen</translation>
		</message>
		<message>
			<source>dlg_dscenario_manager</source>
			<translation>Dszenario-Manager</translation>
		</message>
		<message>
			<source>tooltip_dlg_dscenario_manager</source>
			<translation>dlg_dscenario_manager</translation>
		</message>
		<message>
			<source>lbl_dscenario_name</source>
			<translation>Filtern nach: Dszenario Name</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario_name</source>
			<translation>lbl_dscenario_name</translation>
		</message>
	</context>
	<context>
		<name>element_manager</name>
		<message>
			<source>title</source>
			<translation>Element management</translation>
		</message>
		<message>
			<source>dlg_element_manager</source>
			<translation>Element management</translation>
		</message>
		<message>
			<source>tooltip_dlg_element_manager</source>
			<translation>dlg_element_manager</translation>
		</message>
	</context>
	<context>
		<name>epa_export</name>
		<message>
			<source>title</source>
			<translation>Export EPA Result Families</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Accept</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_browse</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_browse</source>
			<translation>btn_browse</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancel</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_format_json</source>
			<translation>Format Json</translation>
		</message>
		<message>
			<source>tooltip_chk_format_json</source>
			<translation>chk_format_json</translation>
		</message>
		<message>
			<source>dlg_epa_export</source>
			<translation>Export EPA Result Families</translation>
		</message>
		<message>
			<source>tooltip_dlg_epa_export</source>
			<translation>dlg_epa_export</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Export path:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Result ID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
	</context>
	<context>
		<name>epatools_add_demand_check</name>
		<message>
			<source>title</source>
			<translation>Zusätzliche Bedarfsprüfung</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_add_demand_check</source>
			<translation>Zusätzliche Bedarfsprüfung</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_add_demand_check</source>
			<translation>dlg_epatools_add_demand_check</translation>
		</message>
		<message>
			<source>lbl_config</source>
			<translation>Konfigurationsdatei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config</source>
			<translation>lbl_config</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Dateiname:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>INP-Datei eingeben:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Verwenden Sie Knoten aus:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Ausgabeordner:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>rdb_nodes_config</source>
			<translation>Konfigurationsdatei</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_config</source>
			<translation>Retrieve node data from the &quot;nodes&quot; property within the configuration file.</translation>
		</message>
		<message>
			<source>rdb_nodes_database</source>
			<translation>Datenbank</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_database</source>
			<translation>Retrieve node data with fid=491 from the anl_node table.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_emitter_calibration</name>
		<message>
			<source>title</source>
			<translation>Emitter-Kalibrierung</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_emitter_calibration</source>
			<translation>Emitter-Kalibrierung</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_emitter_calibration</source>
			<translation>dlg_epatools_emitter_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Konfigurationsdatei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Dateiname:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>INP-Datei eingeben:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_filename</source>
			<translation>Name der Ausgabedateien:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_filename</source>
			<translation>lbl_output_filename</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>epatools_quantized_demands</name>
		<message>
			<source>title</source>
			<translation>Quantisierte Anforderungen</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_quantized_demands</source>
			<translation>Quantisierte Anforderungen</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_quantized_demands</source>
			<translation>dlg_epatools_quantized_demands</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Konfigurationsdatei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Dateiname:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>INP-Datei eingeben:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Ausgabeordner:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_recursive_go2epa</name>
		<message>
			<source>title</source>
			<translation>Epa-Multi-Anrufe</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_recursive_go2epa</source>
			<translation>Epa-Multi-Anrufe</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_recursive_go2epa</source>
			<translation>dlg_epatools_recursive_go2epa</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Konfigurationsdatei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Dateiname:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Ausgabeordner:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_static_calibration</name>
		<message>
			<source>title</source>
			<translation>Statische Kalibrierung</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>btn_save_dscenario</source>
			<translation>Änderungen an dscenario speichern</translation>
		</message>
		<message>
			<source>tooltip_btn_save_dscenario</source>
			<translation>btn_save_dscenario</translation>
		</message>
		<message>
			<source>dlg_epatools_static_calibration</source>
			<translation>Statische Kalibrierung</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_static_calibration</source>
			<translation>dlg_epatools_static_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Konfigurationsdatei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>The .ini file with the calibrations to make</translation>
		</message>
		<message>
			<source>lbl_dscenario</source>
			<translation>Szenario:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario</source>
			<translation>lbl_dscenario</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Dateiname:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_inp_input_file</source>
			<translation>INP-Datei eingeben:</translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_input_file</source>
			<translation>The EPANET file to calibrate</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Ausgabeordner:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_valve_operation_check</name>
		<message>
			<source>title</source>
			<translation>Ventilbetrieb prüfen</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_valve_operation_check</source>
			<translation>Ventilbetrieb prüfen</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_valve_operation_check</source>
			<translation>dlg_epatools_valve_operation_check</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Konfigurationsdatei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Dateiname:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>INP-Datei eingeben:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Ausgabeordner:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>lbl_scenarios</source>
			<translation>Verwenden Sie Szenarien aus:</translation>
		</message>
		<message>
			<source>tooltip_lbl_scenarios</source>
			<translation>lbl_scenarios</translation>
		</message>
		<message>
			<source>rdb_scenarios_config</source>
			<translation>Konfigurationsdatei</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_config</source>
			<translation>Retrieve scenarios data from the [SCENARIOS] section within the configuration file.</translation>
		</message>
		<message>
			<source>rdb_scenarios_database</source>
			<translation>Datenbank</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_database</source>
			<translation>Retrieve scenarios data with fid=493 from the anl_arc table.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>feature_delete</name>
		<message>
			<source>title</source>
			<translation>Funktion löschen</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>       Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ausgewähltes Merkmal löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>btn_delete_another</source>
			<translation>Ein anderes Merkmal löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_another</source>
			<translation>btn_delete_another</translation>
		</message>
		<message>
			<source>btn_relations</source>
			<translation>Merkmalsbeziehungen anzeigen</translation>
		</message>
		<message>
			<source>tooltip_btn_relations</source>
			<translation>btn_relations</translation>
		</message>
		<message>
			<source>dlg_feature_delete</source>
			<translation>Funktion löschen</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_delete</source>
			<translation>dlg_feature_delete</translation>
		</message>
		<message>
			<source>lbl_feature_id</source>
			<translation>Merkmal id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_id</source>
			<translation>lbl_feature_id</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Merkmalstyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>tab_del_feature</source>
			<translation>Funktion löschen</translation>
		</message>
		<message>
			<source>tooltip_tab_del_feature</source>
			<translation>tab_del_feature</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Info-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>feature_end</name>
		<message>
			<source>title</source>
			<translation>Merkmal beenden</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>btn_new_workcat</source>
			<translation>btn_new_workcat</translation>
		</message>
		<message>
			<source>tooltip_btn_new_workcat</source>
			<translation>btn_new_workcat</translation>
		</message>
		<message>
			<source>builtdate</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_builtdate</source>
			<translation>builtdate</translation>
		</message>
		<message>
			<source>dlg_feature_end</source>
			<translation>Merkmal beenden</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_end</source>
			<translation>dlg_feature_end</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Enddatum:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_state_type</source>
			<translation>Zustandstyp Ende:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state_type</source>
			<translation>lbl_state_type</translation>
		</message>
		<message>
			<source>lbl_workcat_date</source>
			<translation>Workcat Datum:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_date</source>
			<translation>lbl_workcat_date</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Workcat id Ende:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_elem</source>
			<translation>Elem</translation>
		</message>
		<message>
			<source>tooltip_tab_elem</source>
			<translation>tab_elem</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Beziehungen</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Beziehungen</translation>
		</message>
		<message>
			<source>tab_workcat</source>
			<translation>Workcat</translation>
		</message>
		<message>
			<source>tooltip_tab_workcat</source>
			<translation>tab_workcat</translation>
		</message>
	</context>
	<context>
		<name>feature_end_connec</name>
		<message>
			<source>title</source>
			<translation>Workcat Endliste</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>dlg_feature_end_connec</source>
			<translation>Workcat Endliste</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_end_connec</source>
			<translation>dlg_feature_end_connec</translation>
		</message>
		<message>
			<source>lbl_filter_by</source>
			<translation>Filter nach arc_id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_by</source>
			<translation>lbl_filter_by</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Diese Verbindungen oder Gullys werden unterbrochen, wenn ausgewählte Bögen gelöscht werden.</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
	</context>
	<context>
		<name>feature_replace</name>
		<message>
			<source>title</source>
			<translation>Funktion &quot;Ersetzen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Ok</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_config</source>
			<translation>config</translation>
		</message>
		<message>
			<source>dlg_feature_replace</source>
			<translation>Funktion &quot;Ersetzen</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_replace</source>
			<translation>dlg_feature_replace</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>grb_end_parameters</source>
			<translation>Parameter beenden</translation>
		</message>
		<message>
			<source>tooltip_grb_end_parameters</source>
			<translation>grb_end_parameters</translation>
		</message>
		<message>
			<source>grb_feature_parameters</source>
			<translation>Parameter der Merkmale</translation>
		</message>
		<message>
			<source>tooltip_grb_feature_parameters</source>
			<translation>grb_feature_parameters</translation>
		</message>
		<message>
			<source>lbl_current_catalog_id</source>
			<translation>Aktuelle Katalognummer:</translation>
		</message>
		<message>
			<source>tooltip_lbl_current_catalog_id</source>
			<translation>lbl_current_catalog_id</translation>
		</message>
		<message>
			<source>lbl_description</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_description</source>
			<translation>lbl_description</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Datum austauschen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Aktueller Merkmalstyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>lbl_keep_asset_id</source>
			<translation>Asset-ID behalten:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_asset_id</source>
			<translation>lbl_keep_asset_id</translation>
		</message>
		<message>
			<source>lbl_keep_customer_code</source>
			<translation>Keep customer code:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_customer_code</source>
			<translation>lbl_keep_customer_code</translation>
		</message>
		<message>
			<source>lbl_keep_elements</source>
			<translation>Elemente behalten:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_elements</source>
			<translation>lbl_keep_elements</translation>
		</message>
		<message>
			<source>lbl_keep_epa_values</source>
			<translation>EPA-Werte beibehalten:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_epa_values</source>
			<translation>lbl_keep_epa_values</translation>
		</message>
		<message>
			<source>lbl_keep_sys_code</source>
			<translation>Keep sys code:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_sys_code</source>
			<translation>lbl_keep_sys_code</translation>
		</message>
		<message>
			<source>lbl_new_catalog_id</source>
			<translation>Neue Katalognummer:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_catalog_id</source>
			<translation>lbl_new_catalog_id</translation>
		</message>
		<message>
			<source>lbl_new_feature_type</source>
			<translation>Neuer Merkmalstyp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_feature_type</source>
			<translation>lbl_new_feature_type</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Workcat id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Info-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>featuretype_change</name>
		<message>
			<source>title</source>
			<translation>Merkmalstyp ändern</translation>
		</message>
		<message>
			<source>dlg_featuretype_change</source>
			<translation>Merkmalstyp ändern</translation>
		</message>
		<message>
			<source>tooltip_dlg_featuretype_change</source>
			<translation>dlg_featuretype_change</translation>
		</message>
	</context>
	<context>
		<name>go2epa</name>
		<message>
			<source>title</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>btn_file_inp</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_inp</source>
			<translation>btn_file_inp</translation>
		</message>
		<message>
			<source>btn_file_rpt</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_rpt</source>
			<translation>btn_file_rpt</translation>
		</message>
		<message>
			<source>btn_hs_ds</source>
			<translation>Selektor</translation>
		</message>
		<message>
			<source>tooltip_btn_hs_ds</source>
			<translation>btn_hs_ds</translation>
		</message>
		<message>
			<source>btn_options</source>
			<translation>Optionen</translation>
		</message>
		<message>
			<source>tooltip_btn_options</source>
			<translation>btn_options</translation>
		</message>
		<message>
			<source>chk_exec</source>
			<translation>Ausführen der EPA-Software</translation>
		</message>
		<message>
			<source>tooltip_chk_exec</source>
			<translation>chk_exec</translation>
		</message>
		<message>
			<source>chk_export</source>
			<translation>Export INP</translation>
		</message>
		<message>
			<source>tooltip_chk_export</source>
			<translation>chk_export</translation>
		</message>
		<message>
			<source>chk_export_subcatch</source>
			<translation>UD Teileinzugsgebiete exportieren</translation>
		</message>
		<message>
			<source>tooltip_chk_export_subcatch</source>
			<translation>chk_export_subcatch</translation>
		</message>
		<message>
			<source>chk_import_result</source>
			<translation>Ergebnis importieren</translation>
		</message>
		<message>
			<source>tooltip_chk_import_result</source>
			<translation>chk_import_result</translation>
		</message>
		<message>
			<source>dlg_go2epa</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa</source>
			<translation>dlg_go2epa</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Vorverarbeitungsoptionen</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Dateimanager</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_inp_file</source>
			<translation>INP-Datei:            </translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_file</source>
			<translation>lbl_inp_file</translation>
		</message>
		<message>
			<source>lbl_result_name</source>
			<translation>Name des Ergebnisses:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name</source>
			<translation>lbl_result_name</translation>
		</message>
		<message>
			<source>lbl_rpt_file</source>
			<translation>RPT-Datei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rpt_file</source>
			<translation>lbl_rpt_file</translation>
		</message>
		<message>
			<source>tab_file_manager</source>
			<translation>Dateimanager</translation>
		</message>
		<message>
			<source>tooltip_tab_file_manager</source>
			<translation>tab_file_manager</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Info-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>go2epa_manager</name>
		<message>
			<source>title</source>
			<translation>EPA Ergebnismanagement</translation>
		</message>
		<message>
			<source>btn_archive</source>
			<translation>Archiv umschalten</translation>
		</message>
		<message>
			<source>tooltip_btn_archive</source>
			<translation>Archiv umschalten</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>btn_edit</source>
			<translation>bearbeiten</translation>
		</message>
		<message>
			<source>tooltip_btn_edit</source>
			<translation>bearbeiten</translation>
		</message>
		<message>
			<source>btn_show_inp_data</source>
			<translation>Inp-Daten anzeigen</translation>
		</message>
		<message>
			<source>tooltip_btn_show_inp_data</source>
			<translation>Inp-Daten anzeigen</translation>
		</message>
		<message>
			<source>btn_toggle_corporate</source>
			<translation>Toggle corporate</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_corporate</source>
			<translation>btn_toggle_corporate</translation>
		</message>
		<message>
			<source>btn_toggle_validated</source>
			<translation>Toggle validated</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_validated</source>
			<translation>btn_toggle_validated</translation>
		</message>
		<message>
			<source>chk_archived</source>
			<translation>Show archived</translation>
		</message>
		<message>
			<source>tooltip_chk_archived</source>
			<translation>chk_archived</translation>
		</message>
		<message>
			<source>chk_corporate</source>
			<translation>Show corporate</translation>
		</message>
		<message>
			<source>tooltip_chk_corporate</source>
			<translation>chk_corporate</translation>
		</message>
		<message>
			<source>chk_validated</source>
			<translation>Show validated</translation>
		</message>
		<message>
			<source>tooltip_chk_validated</source>
			<translation>chk_validated</translation>
		</message>
		<message>
			<source>dlg_go2epa_manager</source>
			<translation>EPA Ergebnismanagement</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_manager</source>
			<translation>dlg_go2epa_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_date_exec_from</source>
			<translation>From:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_exec_from</source>
			<translation>lbl_date_exec_from</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Exploitation:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_network_type</source>
			<translation>Network type:</translation>
		</message>
		<message>
			<source>tooltip_lbl_network_type</source>
			<translation>lbl_network_type</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Filtern nach: Ergebnis-ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
	</context>
	<context>
		<name>go2epa_options</name>
		<message>
			<source>title</source>
			<translation>Go2Epa - Optionen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_go2epa_options</source>
			<translation>Go2Epa - Optionen</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_options</source>
			<translation>dlg_go2epa_options</translation>
		</message>
		<message>
			<source>grb_energy</source>
			<translation>Energie</translation>
		</message>
		<message>
			<source>tooltip_grb_energy</source>
			<translation>grb_energy</translation>
		</message>
		<message>
			<source>grb_general</source>
			<translation>Allgemein</translation>
		</message>
		<message>
			<source>tooltip_grb_general</source>
			<translation>grb_general</translation>
		</message>
		<message>
			<source>grb_hydraulics</source>
			<translation>Hydraulik</translation>
		</message>
		<message>
			<source>tooltip_grb_hydraulics</source>
			<translation>grb_hydraulics</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Andere</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_reactions</source>
			<translation>Reaktionen</translation>
		</message>
		<message>
			<source>tooltip_grb_reactions</source>
			<translation>grb_reactions</translation>
		</message>
		<message>
			<source>grb_reports</source>
			<translation>Berichte</translation>
		</message>
		<message>
			<source>tooltip_grb_reports</source>
			<translation>grb_reports</translation>
		</message>
		<message>
			<source>grb_time_steps</source>
			<translation>Datum &amp;amp; Zeitschritte</translation>
		</message>
		<message>
			<source>tooltip_grb_time_steps</source>
			<translation>grb_time_steps</translation>
		</message>
		<message>
			<source>tab_inp</source>
			<translation>Inp</translation>
		</message>
		<message>
			<source>tooltip_tab_inp</source>
			<translation>tab_inp</translation>
		</message>
		<message>
			<source>tab_other</source>
			<translation>Andere</translation>
		</message>
		<message>
			<source>tooltip_tab_other</source>
			<translation>tab_other</translation>
		</message>
	</context>
	<context>
		<name>go2epa_selector</name>
		<message>
			<source>title</source>
			<translation>Selektor für den Ergebnisvergleich</translation>
		</message>
		<message>
			<source>dlg_go2epa_selector</source>
			<translation>Selektor für den Ergebnisvergleich</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_selector</source>
			<translation>dlg_go2epa_selector</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Ergebnis</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
		<message>
			<source>tab_time</source>
			<translation>Datum Uhrzeit</translation>
		</message>
		<message>
			<source>tooltip_tab_time</source>
			<translation>tab_time</translation>
		</message>
	</context>
	<context>
		<name>go2iber</name>
		<message>
			<source>title</source>
			<translation>Go2Iber</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_iber_options</source>
			<translation>Iber Options</translation>
		</message>
		<message>
			<source>tooltip_btn_iber_options</source>
			<translation>Iber Options</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_swmm_options</source>
			<translation>SWMM-Optionen</translation>
		</message>
		<message>
			<source>tooltip_btn_swmm_options</source>
			<translation>SWMM-Optionen</translation>
		</message>
		<message>
			<source>dlg_go2iber</source>
			<translation>Go2Iber</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2iber</source>
			<translation>dlg_go2iber</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Optionen</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>lbl_mesh</source>
			<translation>Masche:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mesh</source>
			<translation>lbl_mesh</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Pfad des Ordners:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
		<message>
			<source>lbl_result_name</source>
			<translation>Name des Ergebnisses:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name</source>
			<translation>lbl_result_name</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>info_catalog</name>
		<message>
			<source>title</source>
			<translation>Katalog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_info_catalog</source>
			<translation>Katalog</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_catalog</source>
			<translation>dlg_info_catalog</translation>
		</message>
	</context>
	<context>
		<name>info_crossect</name>
		<message>
			<source>title</source>
			<translation>Abschnitt</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>dlg_info_crossect</source>
			<translation>Abschnitt</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_crossect</source>
			<translation>dlg_info_crossect</translation>
		</message>
		<message>
			<source>lbl_cost_area</source>
			<translation>Leitungsbereich:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_area</source>
			<translation>lbl_cost_area</translation>
		</message>
		<message>
			<source>lbl_cost_bulk</source>
			<translation>Schüttgut aus der Leitung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_bulk</source>
			<translation>lbl_cost_bulk</translation>
		</message>
		<message>
			<source>lbl_cost_exc</source>
			<translation>m3/ml Überschuss:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_exc</source>
			<translation>lbl_cost_exc</translation>
		</message>
		<message>
			<source>lbl_cost_excav</source>
			<translation>m3/ml Aushub:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_excav</source>
			<translation>lbl_cost_excav</translation>
		</message>
		<message>
			<source>lbl_cost_fill</source>
			<translation>m3/ml Füllung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_fill</source>
			<translation>lbl_cost_fill</translation>
		</message>
		<message>
			<source>lbl_cost_trench</source>
			<translation>% Trenchlining:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_trench</source>
			<translation>lbl_cost_trench</translation>
		</message>
	</context>
	<context>
		<name>info_epa</name>
		<message>
			<source>title</source>
			<translation>InfoEpa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_info_epa</source>
			<translation>InfoEpa</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_epa</source>
			<translation>dlg_info_epa</translation>
		</message>
		<message>
			<source>page_base</source>
			<translation>Basis</translation>
		</message>
		<message>
			<source>tooltip_page_base</source>
			<translation>page_base</translation>
		</message>
		<message>
			<source>page_dscenario</source>
			<translation>Dszenario</translation>
		</message>
		<message>
			<source>tooltip_page_dscenario</source>
			<translation>page_dscenario</translation>
		</message>
		<message>
			<source>page_dwf</source>
			<translation>DWF</translation>
		</message>
		<message>
			<source>tooltip_page_dwf</source>
			<translation>page_dwf</translation>
		</message>
		<message>
			<source>page_inflows</source>
			<translation>EINFLÜSSE</translation>
		</message>
		<message>
			<source>tooltip_page_inflows</source>
			<translation>page_inflows</translation>
		</message>
	</context>
	<context>
		<name>info_feature</name>
		<message>
			<source>title</source>
			<translation>Kreuzung</translation>
		</message>
		<message>
			<source>actionCopyPaste</source>
			<translation>actionCopyPaste</translation>
		</message>
		<message>
			<source>tooltip_actionCopyPaste</source>
			<translation>Copy&amp;Paste</translation>
		</message>
		<message>
			<source>actionEdit</source>
			<translation>actionEdit</translation>
		</message>
		<message>
			<source>tooltip_actionEdit</source>
			<translation>Edit</translation>
		</message>
		<message>
			<source>actionGetArcId</source>
			<translation>actionGetArcId</translation>
		</message>
		<message>
			<source>tooltip_actionGetArcId</source>
			<translation>Get new arc id</translation>
		</message>
		<message>
			<source>actionHelp</source>
			<translation>actionHelp</translation>
		</message>
		<message>
			<source>tooltip_actionHelp</source>
			<translation>Help</translation>
		</message>
		<message>
			<source>actionInterpolate</source>
			<translation>actionInterpolate</translation>
		</message>
		<message>
			<source>tooltip_actionInterpolate</source>
			<translation>Interpolate</translation>
		</message>
		<message>
			<source>actionLink</source>
			<translation>actionLink</translation>
		</message>
		<message>
			<source>tooltip_actionLink</source>
			<translation>Link</translation>
		</message>
		<message>
			<source>actionSection</source>
			<translation>actionSection</translation>
		</message>
		<message>
			<source>tooltip_actionSection</source>
			<translation>Show section</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Bewerbung</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>Bewerbung</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>btn_link</source>
			<translation>btn_link</translation>
		</message>
		<message>
			<source>tooltip_btn_link</source>
			<translation>btn_link</translation>
		</message>
		<message>
			<source>btn_new_element</source>
			<translation>btn_new_element</translation>
		</message>
		<message>
			<source>tooltip_btn_new_element</source>
			<translation>btn_new_element</translation>
		</message>
		<message>
			<source>btn_new_visit</source>
			<translation>btn_new_visit</translation>
		</message>
		<message>
			<source>tooltip_btn_new_visit</source>
			<translation>btn_new_visit</translation>
		</message>
		<message>
			<source>btn_open_element</source>
			<translation>btn_open_element</translation>
		</message>
		<message>
			<source>tooltip_btn_open_element</source>
			<translation>btn_open_element</translation>
		</message>
		<message>
			<source>btn_open_gallery</source>
			<translation>btn_open_gallery</translation>
		</message>
		<message>
			<source>tooltip_btn_open_gallery</source>
			<translation>btn_open_gallery</translation>
		</message>
		<message>
			<source>btn_open_visit</source>
			<translation>btn_open_visit</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit</source>
			<translation>btn_open_visit</translation>
		</message>
		<message>
			<source>btn_open_visit_doc</source>
			<translation>btn_open_visit_doc</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit_doc</source>
			<translation>btn_open_visit_doc</translation>
		</message>
		<message>
			<source>btn_open_visit_event</source>
			<translation>btn_open_visit_event</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit_event</source>
			<translation>btn_open_visit_event</translation>
		</message>
		<message>
			<source>dlg_info_feature</source>
			<translation>Kreuzung</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_feature</source>
			<translation>dlg_info_feature</translation>
		</message>
		<message>
			<source>grb_frelem_dscenario</source>
			<translation>Dszenario</translation>
		</message>
		<message>
			<source>tooltip_grb_frelem_dscenario</source>
			<translation>grb_frelem_dscenario</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>INP</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>RPT</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>page_add</source>
			<translation>Zusätzliche Daten</translation>
		</message>
		<message>
			<source>tooltip_page_add</source>
			<translation>page_add</translation>
		</message>
		<message>
			<source>page_dscenario</source>
			<translation>Dscenario</translation>
		</message>
		<message>
			<source>tooltip_page_dscenario</source>
			<translation>page_dscenario</translation>
		</message>
		<message>
			<source>page_epa</source>
			<translation>Data</translation>
		</message>
		<message>
			<source>tooltip_page_epa</source>
			<translation>page_epa</translation>
		</message>
		<message>
			<source>page_main</source>
			<translation>Wichtigste Daten</translation>
		</message>
		<message>
			<source>tooltip_page_main</source>
			<translation>page_main</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_connections</source>
			<translation>Konnektionen</translation>
		</message>
		<message>
			<source>tooltip_tab_connections</source>
			<translation>tab_connections</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Daten</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_documents</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_tab_documents</source>
			<translation>tab_documents</translation>
		</message>
		<message>
			<source>tab_elements</source>
			<translation>Elements</translation>
		</message>
		<message>
			<source>tooltip_tab_elements</source>
			<translation>tab_elements</translation>
		</message>
		<message>
			<source>tab_epa</source>
			<translation>EPA</translation>
		</message>
		<message>
			<source>tooltip_tab_epa</source>
			<translation>tab_epa</translation>
		</message>
		<message>
			<source>tab_event</source>
			<translation>Veranstaltung</translation>
		</message>
		<message>
			<source>tooltip_tab_event</source>
			<translation>tab_event</translation>
		</message>
		<message>
			<source>tab_features</source>
			<translation>Eigenschaften</translation>
		</message>
		<message>
			<source>tooltip_tab_features</source>
			<translation>tab_features</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_hydrometer</source>
			<translation>Hydrometer</translation>
		</message>
		<message>
			<source>tooltip_tab_hydrometer</source>
			<translation>tab_hydrometer</translation>
		</message>
		<message>
			<source>tab_hydrometer_val</source>
			<translation>Aräometerwerte</translation>
		</message>
		<message>
			<source>tooltip_tab_hydrometer_val</source>
			<translation>tab_hydrometer_val</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_orifice</source>
			<translation>Blende</translation>
		</message>
		<message>
			<source>tooltip_tab_orifice</source>
			<translation>tab_orifice</translation>
		</message>
		<message>
			<source>tab_outlet</source>
			<translation>Auslass</translation>
		</message>
		<message>
			<source>tooltip_tab_outlet</source>
			<translation>tab_outlet</translation>
		</message>
		<message>
			<source>tab_plan</source>
			<translation>Plan</translation>
		</message>
		<message>
			<source>tooltip_tab_plan</source>
			<translation>tab_plan</translation>
		</message>
		<message>
			<source>tab_pump</source>
			<translation>Pumpe</translation>
		</message>
		<message>
			<source>tooltip_tab_pump</source>
			<translation>tab_pump</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Beziehungen</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Beziehungen</translation>
		</message>
		<message>
			<source>tab_rpt</source>
			<translation>Rpt</translation>
		</message>
		<message>
			<source>tooltip_tab_rpt</source>
			<translation>tab_rpt</translation>
		</message>
		<message>
			<source>tab_shortpipe</source>
			<translation>Shortpipe</translation>
		</message>
		<message>
			<source>tooltip_tab_shortpipe</source>
			<translation>tab_shortpipe</translation>
		</message>
		<message>
			<source>tab_valve</source>
			<translation>Ventil</translation>
		</message>
		<message>
			<source>tooltip_tab_valve</source>
			<translation>tab_valve</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Besuchen Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
		<message>
			<source>tab_weir</source>
			<translation>Wehranlage</translation>
		</message>
		<message>
			<source>tooltip_tab_weir</source>
			<translation>tab_weir</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>info_generic</name>
		<message>
			<source>title</source>
			<translation>Grundlegende Informationen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_info_generic</source>
			<translation>Grundlegende Informationen</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_generic</source>
			<translation>dlg_info_generic</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>info_workcat</name>
		<message>
			<source>title</source>
			<translation>Neue Arbeitskatze</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>builtdate</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_builtdate</source>
			<translation>builtdate</translation>
		</message>
		<message>
			<source>dlg_info_workcat</source>
			<translation>Neue Arbeitskatze</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_workcat</source>
			<translation>dlg_info_workcat</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Baudatum:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>lbl_builtdate</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Link:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>lbl_link</translation>
		</message>
		<message>
			<source>lbl_work_id</source>
			<translation>Arbeit id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_id</source>
			<translation>lbl_work_id</translation>
		</message>
		<message>
			<source>lbl_workid_key_1</source>
			<translation>Workid-Schlüssel 1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workid_key_1</source>
			<translation>lbl_workid_key_1</translation>
		</message>
		<message>
			<source>lbl_workid_key_2</source>
			<translation>Workid-Schlüssel 2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workid_key_2</source>
			<translation>lbl_workid_key_2</translation>
		</message>
	</context>
	<context>
		<name>inp_config_import</name>
		<message>
			<source>title</source>
			<translation>INP-Import konfigurieren</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_load</source>
			<translation>Laden...</translation>
		</message>
		<message>
			<source>tooltip_btn_load</source>
			<translation>btn_load</translation>
		</message>
		<message>
			<source>btn_reload</source>
			<translation>Optionen zum Nachladen</translation>
		</message>
		<message>
			<source>tooltip_btn_reload</source>
			<translation>btn_reload</translation>
		</message>
		<message>
			<source>btn_save</source>
			<translation>Speichern...</translation>
		</message>
		<message>
			<source>tooltip_btn_save</source>
			<translation>btn_save</translation>
		</message>
		<message>
			<source>chk_force_commit</source>
			<translation>Commit erzwingen</translation>
		</message>
		<message>
			<source>tooltip_chk_force_commit</source>
			<translation>chk_force_commit</translation>
		</message>
		<message>
			<source>dlg_inp_config_import</source>
			<translation>INP-Import konfigurieren</translation>
		</message>
		<message>
			<source>tooltip_dlg_inp_config_import</source>
			<translation>dlg_inp_config_import</translation>
		</message>
		<message>
			<source>grb_basic</source>
			<translation>Grundlegend</translation>
		</message>
		<message>
			<source>tooltip_grb_basic</source>
			<translation>grb_basic</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_mapzones</source>
			<translation>Karten</translation>
		</message>
		<message>
			<source>tooltip_grb_mapzones</source>
			<translation>grb_mapzones</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Psektor:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Betrieb:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Stadtbezirk:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Sektor:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>lbl_arcs</source>
			<translation>Wählen Sie für jede Bogenkombination die entsprechende arccat_id aus den unten stehenden Optionen. Wenn Sie &amp;quot;Neu erstellen&amp;quot; wählen, geben Sie den neuen Namen in der Spalte &amp;quot;Neuer Katalogname&amp;quot; ein.</translation>
		</message>
		<message>
			<source>tooltip_lbl_arcs</source>
			<translation>lbl_arcs</translation>
		</message>
		<message>
			<source>lbl_dscenario</source>
			<translation>Verlangt dscenario name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario</source>
			<translation>lbl_dscenario</translation>
		</message>
		<message>
			<source>lbl_feature</source>
			<translation>Wählen Sie für jeden EPA-Typ die entsprechende feature_id aus den unten stehenden Optionen aus. Bei Bedarf können Sie einen neuen Merkmalstyp im Giswater-Katalog hinzufügen und auf die Schaltfläche &amp;quot;Optionen neu laden&amp;quot; klicken.</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature</source>
			<translation>lbl_feature</translation>
		</message>
		<message>
			<source>lbl_flwreg</source>
			<translation>Wählen Sie für jeden Durchflussregler die entsprechende Katalognummer aus den unten stehenden Optionen aus. Wenn Sie &amp;quot;Neu erstellen&amp;quot; wählen, geben Sie den neuen Namen in der Spalte &amp;quot;Neuer Katalogname&amp;quot; ein.</translation>
		</message>
		<message>
			<source>tooltip_lbl_flwreg</source>
			<translation>lbl_flwreg</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Wählen Sie aus den unten stehenden Optionen das geeignete Material für jede Rauheit aus. Bei Bedarf können Sie im Giswater-Katalog ein neues Material hinzufügen und unten auf die Schaltfläche &amp;quot;Optionen neu laden&amp;quot; klicken.</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>lbl_material</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Wählen Sie für jeden EPA-Typ die entsprechende nodecat_id aus den unten stehenden Optionen aus. Wenn Sie &amp;quot;Neu erstellen&amp;quot; wählen, geben Sie den neuen Namen in der Spalte &amp;quot;Neuer Katalogname&amp;quot; ein.</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_raingage</source>
			<translation>Standard-Raingage:</translation>
		</message>
		<message>
			<source>tooltip_lbl_raingage</source>
			<translation>lbl_raingage</translation>
		</message>
		<message>
			<source>lbl_workcat</source>
			<translation>Workcat_id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat</source>
			<translation>lbl_workcat</translation>
		</message>
		<message>
			<source>tab_arccat</source>
			<translation>Bögen</translation>
		</message>
		<message>
			<source>tooltip_tab_arccat</source>
			<translation>tab_arccat</translation>
		</message>
		<message>
			<source>tab_basic</source>
			<translation>Grundlegend</translation>
		</message>
		<message>
			<source>tooltip_tab_basic</source>
			<translation>tab_basic</translation>
		</message>
		<message>
			<source>tab_feature</source>
			<translation>Eigenschaften</translation>
		</message>
		<message>
			<source>tooltip_tab_feature</source>
			<translation>tab_feature</translation>
		</message>
		<message>
			<source>tab_flwreg</source>
			<translation>Durchflussregler</translation>
		</message>
		<message>
			<source>tooltip_tab_flwreg</source>
			<translation>tab_flwreg</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Info-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>tooltip_tab_material</source>
			<translation>tab_material</translation>
		</message>
		<message>
			<source>tab_nodecat</source>
			<translation>Knotenpunkte</translation>
		</message>
		<message>
			<source>tooltip_tab_nodecat</source>
			<translation>tab_nodecat</translation>
		</message>
		<message>
			<source>tbl_arcs</source>
			<translation>Neuer Katalogname</translation>
		</message>
		<message>
			<source>tooltip_tbl_arcs</source>
			<translation>tbl_arcs</translation>
		</message>
		<message>
			<source>tbl_feature</source>
			<translation>Merkmal</translation>
		</message>
		<message>
			<source>tooltip_tbl_feature</source>
			<translation>tbl_feature</translation>
		</message>
		<message>
			<source>tbl_flwreg</source>
			<translation>Neuer Katalogname</translation>
		</message>
		<message>
			<source>tooltip_tbl_flwreg</source>
			<translation>tbl_flwreg</translation>
		</message>
		<message>
			<source>tbl_material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>tooltip_tbl_material</source>
			<translation>tbl_material</translation>
		</message>
		<message>
			<source>tbl_nodes</source>
			<translation>Neuer Katalogname</translation>
		</message>
		<message>
			<source>tooltip_tbl_nodes</source>
			<translation>tbl_nodes</translation>
		</message>
	</context>
	<context>
		<name>inp_parsing</name>
		<message>
			<source>title</source>
			<translation>Parsing der INP-Datei</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>dlg_inp_parsing</source>
			<translation>Parsing der INP-Datei</translation>
		</message>
		<message>
			<source>tooltip_dlg_inp_parsing</source>
			<translation>dlg_inp_parsing</translation>
		</message>
		<message>
			<source>tab_databaselog</source>
			<translation>Info-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_databaselog</source>
			<translation>tab_databaselog</translation>
		</message>
	</context>
	<context>
		<name>interpolate</name>
		<message>
			<source>title</source>
			<translation>Interpolieren</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_interpolate</source>
			<translation>Interpolieren</translation>
		</message>
		<message>
			<source>tooltip_dlg_interpolate</source>
			<translation>dlg_interpolate</translation>
		</message>
		<message>
			<source>rb_extrapolate</source>
			<translation>Extrapolieren Sie</translation>
		</message>
		<message>
			<source>tooltip_rb_extrapolate</source>
			<translation>rb_extrapolate</translation>
		</message>
		<message>
			<source>rb_interpolate</source>
			<translation>Interpolieren</translation>
		</message>
		<message>
			<source>tooltip_rb_interpolate</source>
			<translation>rb_interpolate</translation>
		</message>
	</context>
	<context>
		<name>load_menu</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_load_menu</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_load_menu</source>
			<translation>dlg_load_menu</translation>
		</message>
	</context>
	<context>
		<name>lot_management</name>
		<message>
			<source>title</source>
			<translation>Grundstücksverwalter</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Los löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Partie löschen</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Open Lot</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>Offene Partie</translation>
		</message>
		<message>
			<source>chk_show_nulls</source>
			<translation>Nullwerte anzeigen</translation>
		</message>
		<message>
			<source>tooltip_chk_show_nulls</source>
			<translation>Leere Werte anzeigen</translation>
		</message>
		<message>
			<source>dlg_lot_management</source>
			<translation>Grundstücksverwalter</translation>
		</message>
		<message>
			<source>tooltip_dlg_lot_management</source>
			<translation>dlg_lot_management</translation>
		</message>
		<message>
			<source>lbl_column_filter</source>
			<translation>Spalte Daten filtern:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter</source>
			<translation>Datenspaltenfilter:</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Von:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>Von:</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Bis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>An:</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Staat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Staat:</translation>
		</message>
	</context>
	<context>
		<name>mapzone_config</name>
		<message>
			<source>title</source>
			<translation>Mapzone Konfig</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_forceClosed</source>
			<translation>ADD</translation>
		</message>
		<message>
			<source>tooltip_btn_add_forceClosed</source>
			<translation>btn_add_forceClosed</translation>
		</message>
		<message>
			<source>btn_add_ignore</source>
			<translation>ADD</translation>
		</message>
		<message>
			<source>tooltip_btn_add_ignore</source>
			<translation>btn_add_ignore</translation>
		</message>
		<message>
			<source>btn_add_nodeParent</source>
			<translation>ADD</translation>
		</message>
		<message>
			<source>tooltip_btn_add_nodeParent</source>
			<translation>btn_add_nodeParent</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_clear_preview</source>
			<translation>Klare Vorschau</translation>
		</message>
		<message>
			<source>tooltip_btn_clear_preview</source>
			<translation>btn_clear_preview</translation>
		</message>
		<message>
			<source>btn_remove_forceClosed</source>
			<translation>REMOVE</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_forceClosed</source>
			<translation>btn_remove_forceClosed</translation>
		</message>
		<message>
			<source>btn_remove_ignore</source>
			<translation>REMOVE</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_ignore</source>
			<translation>btn_remove_ignore</translation>
		</message>
		<message>
			<source>btn_remove_nodeParent</source>
			<translation>REMOVE</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_nodeParent</source>
			<translation>btn_remove_nodeParent</translation>
		</message>
		<message>
			<source>dlg_mapzone_config</source>
			<translation>Mapzone Konfig</translation>
		</message>
		<message>
			<source>tooltip_dlg_mapzone_config</source>
			<translation>dlg_mapzone_config</translation>
		</message>
		<message>
			<source>lbl_forceClosed</source>
			<translation>forceClosed:</translation>
		</message>
		<message>
			<source>tooltip_lbl_forceClosed</source>
			<translation>lbl_forceClosed</translation>
		</message>
		<message>
			<source>lbl_ignore</source>
			<translation>ignorieren.</translation>
		</message>
		<message>
			<source>tooltip_lbl_ignore</source>
			<translation>lbl_ignore</translation>
		</message>
		<message>
			<source>lbl_nodeParent</source>
			<translation>nodeParent:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodeParent</source>
			<translation>lbl_nodeParent</translation>
		</message>
		<message>
			<source>lbl_preview</source>
			<translation>Vorschau:</translation>
		</message>
		<message>
			<source>tooltip_lbl_preview</source>
			<translation>lbl_preview</translation>
		</message>
		<message>
			<source>lbl_toArc</source>
			<translation>toArc:</translation>
		</message>
		<message>
			<source>tooltip_lbl_toArc</source>
			<translation>lbl_toArc</translation>
		</message>
	</context>
	<context>
		<name>mapzone_manager</name>
		<message>
			<source>title</source>
			<translation>Mapzones manager</translation>
		</message>
		<message>
			<source>dlg_mapzone_manager</source>
			<translation>Mapzones manager</translation>
		</message>
		<message>
			<source>tooltip_dlg_mapzone_manager</source>
			<translation>dlg_mapzone_manager</translation>
		</message>
	</context>
	<context>
		<name>massive_composer</name>
		<message>
			<source>title</source>
			<translation>Komponistenseiten automatisch drucken</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>dlg_massive_composer</source>
			<translation>Komponistenseiten automatisch drucken</translation>
		</message>
		<message>
			<source>tooltip_dlg_massive_composer</source>
			<translation>dlg_massive_composer</translation>
		</message>
		<message>
			<source>grb_comp</source>
			<translation>Liste der Komponisten</translation>
		</message>
		<message>
			<source>tooltip_grb_comp</source>
			<translation>grb_comp</translation>
		</message>
		<message>
			<source>lbl_composers</source>
			<translation>Komponist auswählen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_composers</source>
			<translation>lbl_composers</translation>
		</message>
		<message>
			<source>lbl_folder</source>
			<translation>Ordner auswählen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_folder</source>
			<translation>lbl_folder</translation>
		</message>
		<message>
			<source>lbl_prefix</source>
			<translation>Präfix-Datei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prefix</source>
			<translation>lbl_prefix</translation>
		</message>
		<message>
			<source>lbl_single</source>
			<translation>Einzelne Datei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_single</source>
			<translation>lbl_single</translation>
		</message>
		<message>
			<source>lbl_sleep</source>
			<translation>Schlafenszeit:</translation>
		</message>
		<message>
			<source>tooltip_lbl_sleep</source>
			<translation>lbl_sleep</translation>
		</message>
	</context>
	<context>
		<name>mincut</name>
		<message>
			<source>title</source>
			<translation>Mincut</translation>
		</message>
		<message>
			<source>actionCustomMincut</source>
			<translation>actionCustomMincut</translation>
		</message>
		<message>
			<source>tooltip_actionCustomMincut</source>
			<translation>Inaccessible valve</translation>
		</message>
		<message>
			<source>actionExportHydroCsv</source>
			<translation>actionExportHydroCsv</translation>
		</message>
		<message>
			<source>tooltip_actionExportHydroCsv</source>
			<translation>Export Hydro Csv</translation>
		</message>
		<message>
			<source>actionMincut</source>
			<translation>Network Mincut</translation>
		</message>
		<message>
			<source>tooltip_actionMincut</source>
			<translation>Automatic Mincut</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Aufgabe abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_end</source>
			<translation>Ende</translation>
		</message>
		<message>
			<source>tooltip_btn_end</source>
			<translation>btn_end</translation>
		</message>
		<message>
			<source>btn_start</source>
			<translation>Start</translation>
		</message>
		<message>
			<source>tooltip_btn_start</source>
			<translation>btn_start</translation>
		</message>
		<message>
			<source>cbx_date_end</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end</source>
			<translation>cbx_date_end</translation>
		</message>
		<message>
			<source>cbx_date_end_predict</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end_predict</source>
			<translation>cbx_date_end_predict</translation>
		</message>
		<message>
			<source>cbx_date_start</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start</source>
			<translation>cbx_date_start</translation>
		</message>
		<message>
			<source>cbx_date_start_predict</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start_predict</source>
			<translation>cbx_date_start_predict</translation>
		</message>
		<message>
			<source>cbx_recieved_day</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_cbx_recieved_day</source>
			<translation>cbx_recieved_day</translation>
		</message>
		<message>
			<source>chk_use_planified</source>
			<translation>Geplantes Netz verwenden</translation>
		</message>
		<message>
			<source>tooltip_chk_use_planified</source>
			<translation>chk_use_planified</translation>
		</message>
		<message>
			<source>dlg_mincut</source>
			<translation>Mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut</source>
			<translation>dlg_mincut</translation>
		</message>
		<message>
			<source>grb_adress</source>
			<translation>Adress</translation>
		</message>
		<message>
			<source>tooltip_grb_adress</source>
			<translation>grb_adress</translation>
		</message>
		<message>
			<source>grb_exec_realdates</source>
			<translation>Echte Daten</translation>
		</message>
		<message>
			<source>tooltip_grb_exec_realdates</source>
			<translation>grb_exec_realdates</translation>
		</message>
		<message>
			<source>grb_plan_details</source>
			<translation>Einzelheiten</translation>
		</message>
		<message>
			<source>tooltip_grb_plan_details</source>
			<translation>grb_plan_details</translation>
		</message>
		<message>
			<source>grb_plan_forecasted_dates</source>
			<translation>Prognostizierte Daten</translation>
		</message>
		<message>
			<source>tooltip_grb_plan_forecasted_dates</source>
			<translation>grb_plan_forecasted_dates</translation>
		</message>
		<message>
			<source>lbl_assigned_to</source>
			<translation>Zugewiesen an:</translation>
		</message>
		<message>
			<source>tooltip_lbl_assigned_to</source>
			<translation>lbl_assigned_to</translation>
		</message>
		<message>
			<source>lbl_cause</source>
			<translation>Die Ursache:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cause</source>
			<translation>lbl_cause</translation>
		</message>
		<message>
			<source>lbl_chlorine</source>
			<translation>Chlor:</translation>
		</message>
		<message>
			<source>tooltip_lbl_chlorine</source>
			<translation>lbl_chlorine</translation>
		</message>
		<message>
			<source>lbl_depth</source>
			<translation>Die Tiefe:</translation>
		</message>
		<message>
			<source>tooltip_lbl_depth</source>
			<translation>lbl_depth</translation>
		</message>
		<message>
			<source>lbl_descript_pd</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_pd</source>
			<translation>lbl_descript_pd</translation>
		</message>
		<message>
			<source>lbl_descript_rd</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_rd</source>
			<translation>lbl_descript_rd</translation>
		</message>
		<message>
			<source>lbl_dist_from_plot</source>
			<translation>Entfernung vom Grundstück:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dist_from_plot</source>
			<translation>lbl_dist_from_plot</translation>
		</message>
		<message>
			<source>lbl_end</source>
			<translation>An:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end</source>
			<translation>lbl_end</translation>
		</message>
		<message>
			<source>lbl_equipment_code</source>
			<translation>Chlorine measurement equipment:</translation>
		</message>
		<message>
			<source>tooltip_lbl_equipment_code</source>
			<translation>lbl_equipment_code</translation>
		</message>
		<message>
			<source>lbl_exec_appropriate</source>
			<translation>Angemessen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_appropriate</source>
			<translation>Wenn &quot;true&quot;, stimmt der tatsächliche Standort mit den geplanten Mincut-Informationen überein</translation>
		</message>
		<message>
			<source>lbl_exec_enddate</source>
			<translation>Enddatum:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_enddate</source>
			<translation>lbl_exec_enddate</translation>
		</message>
		<message>
			<source>lbl_exec_startdate</source>
			<translation>Startdatum:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_startdate</source>
			<translation>Visit ID</translation>
		</message>
		<message>
			<source>lbl_exec_user</source>
			<translation>Exec-Benutzer:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_user</source>
			<translation>lbl_exec_user</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_municiplity</source>
			<translation>Municipality</translation>
		</message>
		<message>
			<source>tooltip_lbl_municiplity</source>
			<translation>lbl_municiplity</translation>
		</message>
		<message>
			<source>lbl_postnumber</source>
			<translation>Number</translation>
		</message>
		<message>
			<source>tooltip_lbl_postnumber</source>
			<translation>lbl_postnumber</translation>
		</message>
		<message>
			<source>lbl_reagent_lot</source>
			<translation>Chlorine reagent lot:</translation>
		</message>
		<message>
			<source>tooltip_lbl_reagent_lot</source>
			<translation>lbl_reagent_lot</translation>
		</message>
		<message>
			<source>lbl_received_date</source>
			<translation>Empfangsdatum:</translation>
		</message>
		<message>
			<source>tooltip_lbl_received_date</source>
			<translation>lbl_received_date</translation>
		</message>
		<message>
			<source>lbl_start</source>
			<translation>Von:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start</source>
			<translation>lbl_start</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Staat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
		<message>
			<source>lbl_street</source>
			<translation>Street</translation>
		</message>
		<message>
			<source>tooltip_lbl_street</source>
			<translation>lbl_street</translation>
		</message>
		<message>
			<source>lbl_turbidity</source>
			<translation>Trübung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_turbidity</source>
			<translation>lbl_turbidity</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Art:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
		<message>
			<source>lbl_work_order</source>
			<translation>Arbeitsauftrag:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_order</source>
			<translation>lbl_work_order</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Exec</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Plan</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_hydro</source>
			<translation>Hydro</translation>
		</message>
		<message>
			<source>tooltip_tab_hydro</source>
			<translation>tab_hydro</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>mincut_composer</name>
		<message>
			<source>title</source>
			<translation>Mincut Komponist</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Öffnen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_mincut_composer</source>
			<translation>Mincut Komponist</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_composer</source>
			<translation>dlg_mincut_composer</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Mincut Komponist</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_rotation</source>
			<translation>Rotation:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rotation</source>
			<translation>lbl_rotation</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Vorlage:</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Titel:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
	</context>
	<context>
		<name>mincut_connec</name>
		<message>
			<source>title</source>
			<translation>Mincut-Verbindung</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>dlg_mincut_connec</source>
			<translation>Mincut-Verbindung</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_connec</source>
			<translation>dlg_mincut_connec</translation>
		</message>
		<message>
			<source>lbl_search</source>
			<translation>Suche nach Kundencode:</translation>
		</message>
		<message>
			<source>tooltip_lbl_search</source>
			<translation>lbl_search</translation>
		</message>
	</context>
	<context>
		<name>mincut_end</name>
		<message>
			<source>title</source>
			<translation>Mincut Ende</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_set_real_location</source>
			<translation>Realen Standort festlegen</translation>
		</message>
		<message>
			<source>tooltip_btn_set_real_location</source>
			<translation>btn_set_real_location</translation>
		</message>
		<message>
			<source>cbx_date_end_fin</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end_fin</source>
			<translation>cbx_date_end_fin</translation>
		</message>
		<message>
			<source>cbx_date_start_fin</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start_fin</source>
			<translation>cbx_date_start_fin</translation>
		</message>
		<message>
			<source>cbx_hours_start_fin</source>
			<translation>H:mm:ss</translation>
		</message>
		<message>
			<source>tooltip_cbx_hours_start_fin</source>
			<translation>cbx_hours_start_fin</translation>
		</message>
		<message>
			<source>dlg_mincut_end</source>
			<translation>Mincut Ende</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_end</source>
			<translation>dlg_mincut_end</translation>
		</message>
		<message>
			<source>grb_adress</source>
			<translation>Adress</translation>
		</message>
		<message>
			<source>tooltip_grb_adress</source>
			<translation>grb_adress</translation>
		</message>
		<message>
			<source>grb_close_mincut</source>
			<translation>Minschnitt schließen</translation>
		</message>
		<message>
			<source>tooltip_grb_close_mincut</source>
			<translation>grb_close_mincut</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Dates</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>lbl_end_date</source>
			<translation>An:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_date</source>
			<translation>lbl_end_date</translation>
		</message>
		<message>
			<source>lbl_end_hour</source>
			<translation>Ende der Stunde:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_hour</source>
			<translation>lbl_end_hour</translation>
		</message>
		<message>
			<source>lbl_executed</source>
			<translation>Ausgeführt von:</translation>
		</message>
		<message>
			<source>tooltip_lbl_executed</source>
			<translation>lbl_executed</translation>
		</message>
		<message>
			<source>lbl_mincut</source>
			<translation>Mincut:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mincut</source>
			<translation>lbl_mincut</translation>
		</message>
		<message>
			<source>lbl_msg</source>
			<translation>Keine Ergebnisse gefunden</translation>
		</message>
		<message>
			<source>tooltip_lbl_msg</source>
			<translation>lbl_msg</translation>
		</message>
		<message>
			<source>lbl_municiplity</source>
			<translation>Municipality</translation>
		</message>
		<message>
			<source>tooltip_lbl_municiplity</source>
			<translation>lbl_municiplity</translation>
		</message>
		<message>
			<source>lbl_postnumber</source>
			<translation>Number</translation>
		</message>
		<message>
			<source>tooltip_lbl_postnumber</source>
			<translation>lbl_postnumber</translation>
		</message>
		<message>
			<source>lbl_start_date</source>
			<translation>Von:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_date</source>
			<translation>lbl_start_date</translation>
		</message>
		<message>
			<source>lbl_start_hour</source>
			<translation>Beginn der Stunde:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_hour</source>
			<translation>lbl_start_hour</translation>
		</message>
		<message>
			<source>lbl_street</source>
			<translation>Straße:</translation>
		</message>
		<message>
			<source>tooltip_lbl_street</source>
			<translation>lbl_street</translation>
		</message>
		<message>
			<source>lbl_work_order</source>
			<translation>Arbeitsauftrag:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_order</source>
			<translation>lbl_work_order</translation>
		</message>
	</context>
	<context>
		<name>mincut_hydrometer</name>
		<message>
			<source>title</source>
			<translation>Mincut-Aräometer</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>dlg_mincut_hydrometer</source>
			<translation>Mincut-Aräometer</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_hydrometer</source>
			<translation>dlg_mincut_hydrometer</translation>
		</message>
		<message>
			<source>lbl_ccc</source>
			<translation>Connec Kundencode:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ccc</source>
			<translation>lbl_ccc</translation>
		</message>
		<message>
			<source>lbl_hcc</source>
			<translation>Aräometer Kundencode:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hcc</source>
			<translation>lbl_hcc</translation>
		</message>
	</context>
	<context>
		<name>mincut_manager</name>
		<message>
			<source>title</source>
			<translation>Mincut-Verwaltung</translation>
		</message>
		<message>
			<source>btn_selector_mincut</source>
			<translation>btn_selector_mincut</translation>
		</message>
		<message>
			<source>tooltip_btn_selector_mincut</source>
			<translation>btn_selector_mincut</translation>
		</message>
		<message>
			<source>dlg_mincut_manager</source>
			<translation>Mincut-Verwaltung</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_manager</source>
			<translation>dlg_mincut_manager</translation>
		</message>
	</context>
	<context>
		<name>netscenario</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_config</source>
			<translation>btn_config</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Aktiv umschalten</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>btn_toggle_closed</source>
			<translation>Toggle geschlossen</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_closed</source>
			<translation>btn_toggle_closed</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>dlg_netscenario</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_netscenario</source>
			<translation>dlg_netscenario</translation>
		</message>
		<message>
			<source>lbl_mapzone_id</source>
			<translation>Mapzone id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mapzone_id</source>
			<translation>lbl_mapzone_id</translation>
		</message>
	</context>
	<context>
		<name>netscenario_manager</name>
		<message>
			<source>title</source>
			<translation>Netscenario-Manager</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>     erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplizieren Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>Duplizieren Sie</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Aktiv umschalten</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Aktiv umschalten</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>btn_update_netscenario</source>
			<translation>Aktuelles Netzszenario</translation>
		</message>
		<message>
			<source>tooltip_btn_update_netscenario</source>
			<translation>Aktuelles Netzszenario</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Inaktiv anzeigen</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Inaktiv anzeigen</translation>
		</message>
		<message>
			<source>dlg_netscenario_manager</source>
			<translation>Netscenario-Manager</translation>
		</message>
		<message>
			<source>tooltip_dlg_netscenario_manager</source>
			<translation>dlg_netscenario_manager</translation>
		</message>
		<message>
			<source>lbl_netscenario_name</source>
			<translation>Filtern nach: Name des Netzszenarios</translation>
		</message>
		<message>
			<source>tooltip_lbl_netscenario_name</source>
			<translation>Filtern nach: Name des Netzszenarios</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_controls</name>
		<message>
			<source>title</source>
			<translation>Editor für einfache Steuerelemente</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Aktiv</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_controls</source>
			<translation>Editor für einfache Steuerelemente</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_controls</source>
			<translation>dlg_nonvisual_controls</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observ</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_sector_id</source>
			<translation>Sektor-ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_sector_id</source>
			<translation>lbl_sector_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_curve</name>
		<message>
			<source>title</source>
			<translation>Kurven-Editor</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_curve</source>
			<translation>Kurven-Editor</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_curve</source>
			<translation>dlg_nonvisual_curve</translation>
		</message>
		<message>
			<source>lbl_curve_id</source>
			<translation>Kurven-ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_id</source>
			<translation>lbl_curve_id</translation>
		</message>
		<message>
			<source>lbl_curve_type</source>
			<translation>Kurve Typ</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_type</source>
			<translation>lbl_curve_type</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Beschreibung</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>Betrieb ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>tbl_curve_value</source>
			<translation>Y</translation>
		</message>
		<message>
			<source>tooltip_tbl_curve_value</source>
			<translation>tbl_curve_value</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_lids</name>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_help</source>
			<translation>Hilfe</translation>
		</message>
		<message>
			<source>tooltip_btn_help</source>
			<translation>btn_help</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>Dialog</source>
			<translation>LIDS</translation>
		</message>
		<message>
			<source>tooltip_Dialog</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>drain</source>
			<translation>Abfluss</translation>
		</message>
		<message>
			<source>tooltip_drain</source>
			<translation>drain</translation>
		</message>
		<message>
			<source>drainmat</source>
			<translation>Drainage Mat</translation>
		</message>
		<message>
			<source>tooltip_drainmat</source>
			<translation>drainmat</translation>
		</message>
		<message>
			<source>label_source_img</source>
			<translation>Quelle: SWMM 5.1</translation>
		</message>
		<message>
			<source>tooltip_label_source_img</source>
			<translation>label_source_img</translation>
		</message>
		<message>
			<source>lbl_berm_height</source>
			<translation>Bermenhöhe (in. oder mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_berm_height</source>
			<translation>lbl_berm_height</translation>
		</message>
		<message>
			<source>lbl_clogging_factor_pavement</source>
			<translation>Clogging-Faktor</translation>
		</message>
		<message>
			<source>tooltip_lbl_clogging_factor_pavement</source>
			<translation>lbl_clogging_factor_pavement</translation>
		</message>
		<message>
			<source>lbl_clogging_factor_storage</source>
			<translation>Clogging-Faktor</translation>
		</message>
		<message>
			<source>tooltip_lbl_clogging_factor_storage</source>
			<translation>lbl_clogging_factor_storage</translation>
		</message>
		<message>
			<source>lbl_closed_level</source>
			<translation>Geschlossener Füllstand (in oder mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_closed_level</source>
			<translation>lbl_closed_level</translation>
		</message>
		<message>
			<source>lbl_conducticity_slope</source>
			<translation>Leitfähigkeit Neigung</translation>
		</message>
		<message>
			<source>tooltip_lbl_conducticity_slope</source>
			<translation>lbl_conducticity_slope</translation>
		</message>
		<message>
			<source>lbl_conductivity</source>
			<translation>Leitfähigkeit (in/hr oder mm/hr)</translation>
		</message>
		<message>
			<source>tooltip_lbl_conductivity</source>
			<translation>lbl_conductivity</translation>
		</message>
		<message>
			<source>lbl_control_curve</source>
			<translation>Kontrollkurve</translation>
		</message>
		<message>
			<source>tooltip_lbl_control_curve</source>
			<translation>lbl_control_curve</translation>
		</message>
		<message>
			<source>lbl_control_name</source>
			<translation>Control Name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_control_name</source>
			<translation>lbl_control_name</translation>
		</message>
		<message>
			<source>lbl_drain_delay</source>
			<translation>Abflussverzögerung (Std.)</translation>
		</message>
		<message>
			<source>tooltip_lbl_drain_delay</source>
			<translation>lbl_drain_delay</translation>
		</message>
		<message>
			<source>lbl_field_capacity</source>
			<translation>Feldkapazität (Volumenanteil)</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_capacity</source>
			<translation>lbl_field_capacity</translation>
		</message>
		<message>
			<source>lbl_flow_capacity</source>
			<translation>Durchflusskapazität (in/hr oder mm/hr)</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_capacity</source>
			<translation>lbl_flow_capacity</translation>
		</message>
		<message>
			<source>lbl__flow_coefficient</source>
			<translation>Durchflusskoeffizient*</translation>
		</message>
		<message>
			<source>tooltip_lbl__flow_coefficient</source>
			<translation>lbl__flow_coefficient</translation>
		</message>
		<message>
			<source>lbl_flow_description</source>
			<translation>*Der Durchfluss wird in in/hr oder mm/hr angegeben; verwenden Sie 0, wenn kein Abfluss vorhanden ist.</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_description</source>
			<translation>lbl_flow_description</translation>
		</message>
		<message>
			<source>lbl_flow_exponent</source>
			<translation>Strömungsexponent</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_exponent</source>
			<translation>lbl_flow_exponent</translation>
		</message>
		<message>
			<source>lbl_imprevious_surface</source>
			<translation>Anteil der undurchsichtigen Oberfläche</translation>
		</message>
		<message>
			<source>tooltip_lbl_imprevious_surface</source>
			<translation>lbl_imprevious_surface</translation>
		</message>
		<message>
			<source>lbl_lid_type</source>
			<translation>LID-Typ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_lid_type</source>
			<translation>lbl_lid_type</translation>
		</message>
		<message>
			<source>lbl_offset</source>
			<translation>Versatz (in oder mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_offset</source>
			<translation>lbl_offset</translation>
		</message>
		<message>
			<source>lbl_open_level</source>
			<translation>Offener Füllstand (in oder mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_open_level</source>
			<translation>lbl_open_level</translation>
		</message>
		<message>
			<source>lbl__permeability</source>
			<translation>Durchlässigkeit (in/hr oder mm/hr)</translation>
		</message>
		<message>
			<source>tooltip_lbl__permeability</source>
			<translation>lbl__permeability</translation>
		</message>
		<message>
			<source>lbl_porosity</source>
			<translation>Porosität (Volumenanteil)</translation>
		</message>
		<message>
			<source>tooltip_lbl_porosity</source>
			<translation>lbl_porosity</translation>
		</message>
		<message>
			<source>lbl_regeneration_fraction</source>
			<translation>Regenerationsfraktion</translation>
		</message>
		<message>
			<source>tooltip_lbl_regeneration_fraction</source>
			<translation>lbl_regeneration_fraction</translation>
		</message>
		<message>
			<source>lbl_regeneration_interval</source>
			<translation>Regenerationsintervall (Tage)</translation>
		</message>
		<message>
			<source>tooltip_lbl_regeneration_interval</source>
			<translation>lbl_regeneration_interval</translation>
		</message>
		<message>
			<source>lbl_roughness</source>
			<translation>Rauhigkeit (Mannings n)</translation>
		</message>
		<message>
			<source>tooltip_lbl_roughness</source>
			<translation>lbl_roughness</translation>
		</message>
		<message>
			<source>lbl_seepage_rate</source>
			<translation>Seepage Rate (in/hr or mm/hr)</translation>
		</message>
		<message>
			<source>tooltip_lbl_seepage_rate</source>
			<translation>lbl_seepage_rate</translation>
		</message>
		<message>
			<source>lbl_suction_head</source>
			<translation>Ansaughöhe (in. oder mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_suction_head</source>
			<translation>lbl_suction_head</translation>
		</message>
		<message>
			<source>lbl_surface_roughness</source>
			<translation>Oberflächenrauhigkeit (Mannings n)</translation>
		</message>
		<message>
			<source>tooltip_lbl_surface_roughness</source>
			<translation>lbl_surface_roughness</translation>
		</message>
		<message>
			<source>lbl_surface_slope</source>
			<translation>Neigung der Oberfläche (Prozent)</translation>
		</message>
		<message>
			<source>tooltip_lbl_surface_slope</source>
			<translation>lbl_surface_slope</translation>
		</message>
		<message>
			<source>lbl_swale_side_slope</source>
			<translation>Seitenneigung der Senke (Steigung / Gefälle)</translation>
		</message>
		<message>
			<source>tooltip_lbl_swale_side_slope</source>
			<translation>lbl_swale_side_slope</translation>
		</message>
		<message>
			<source>lbl_thickness</source>
			<translation>Dicke (in. oder mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness</source>
			<translation>lbl_thickness</translation>
		</message>
		<message>
			<source>lbl_thickness_drainage</source>
			<translation>Dicke (in. oder mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness_drainage</source>
			<translation>lbl_thickness_drainage</translation>
		</message>
		<message>
			<source>lbl_thickness_storage</source>
			<translation>Dicke (in. oder mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness_storage</source>
			<translation>lbl_thickness_storage</translation>
		</message>
		<message>
			<source>lbl_thinkness_pavement</source>
			<translation>Dicke (in. oder mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thinkness_pavement</source>
			<translation>lbl_thinkness_pavement</translation>
		</message>
		<message>
			<source>lbl_vegetation_volume</source>
			<translation>Volumenanteil der Vegetation</translation>
		</message>
		<message>
			<source>tooltip_lbl_vegetation_volume</source>
			<translation>lbl_vegetation_volume</translation>
		</message>
		<message>
			<source>lbl_void_fraction</source>
			<translation>Leere Bruchteil</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_fraction</source>
			<translation>lbl_void_fraction</translation>
		</message>
		<message>
			<source>lbl_void_ratio_pavement</source>
			<translation>Hohlraumverhältnis (Hohlraum / Feststoffe)</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_ratio_pavement</source>
			<translation>lbl_void_ratio_pavement</translation>
		</message>
		<message>
			<source>lbl_void_ratio_storage</source>
			<translation>Hohlraumverhältnis (Hohlräume / Feststoffe)</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_ratio_storage</source>
			<translation>lbl_void_ratio_storage</translation>
		</message>
		<message>
			<source>lbl_wilting_point</source>
			<translation>Verwelkungspunkt (Volumenanteil)</translation>
		</message>
		<message>
			<source>tooltip_lbl_wilting_point</source>
			<translation>lbl_wilting_point</translation>
		</message>
		<message>
			<source>pavement</source>
			<translation>Bürgersteig</translation>
		</message>
		<message>
			<source>tooltip_pavement</source>
			<translation>pavement</translation>
		</message>
		<message>
			<source>rooftop</source>
			<translation>Dachentwässerung</translation>
		</message>
		<message>
			<source>tooltip_rooftop</source>
			<translation>rooftop</translation>
		</message>
		<message>
			<source>soil</source>
			<translation>Boden</translation>
		</message>
		<message>
			<source>tooltip_soil</source>
			<translation>soil</translation>
		</message>
		<message>
			<source>storage</source>
			<translation>Lagerung</translation>
		</message>
		<message>
			<source>tooltip_storage</source>
			<translation>storage</translation>
		</message>
		<message>
			<source>surface</source>
			<translation>Oberfläche</translation>
		</message>
		<message>
			<source>tooltip_surface</source>
			<translation>surface</translation>
		</message>
		<message>
			<source>txt_1_berm_height</source>
			<translation>0.0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_berm_height</source>
			<translation>txt_1_berm_height</translation>
		</message>
		<message>
			<source>txt_1_flow_coefficient</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_flow_coefficient</source>
			<translation>txt_1_flow_coefficient</translation>
		</message>
		<message>
			<source>txt_1_thickness</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness</source>
			<translation>txt_1_thickness</translation>
		</message>
		<message>
			<source>txt_1_thickness_drainage</source>
			<translation>3</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_drainage</source>
			<translation>txt_1_thickness_drainage</translation>
		</message>
		<message>
			<source>txt_1_thickness_pavement</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_pavement</source>
			<translation>txt_1_thickness_pavement</translation>
		</message>
		<message>
			<source>txt_1_thickness_storage</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_storage</source>
			<translation>txt_1_thickness_storage</translation>
		</message>
		<message>
			<source>txt_2_flow_exponent</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_flow_exponent</source>
			<translation>txt_2_flow_exponent</translation>
		</message>
		<message>
			<source>txt_2_porosity</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_porosity</source>
			<translation>txt_2_porosity</translation>
		</message>
		<message>
			<source>txt_2_vegetation_volume</source>
			<translation>0.0</translation>
		</message>
		<message>
			<source>tooltip_txt_2_vegetation_volume</source>
			<translation>txt_2_vegetation_volume</translation>
		</message>
		<message>
			<source>txt_2_void_fraction</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_fraction</source>
			<translation>txt_2_void_fraction</translation>
		</message>
		<message>
			<source>txt_2_void_ratio_pavement</source>
			<translation>0.15</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_ratio_pavement</source>
			<translation>txt_2_void_ratio_pavement</translation>
		</message>
		<message>
			<source>txt_2_void_ratio_storage</source>
			<translation>0.75</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_ratio_storage</source>
			<translation>txt_2_void_ratio_storage</translation>
		</message>
		<message>
			<source>txt_3_field_capacity</source>
			<translation>0.2</translation>
		</message>
		<message>
			<source>tooltip_txt_3_field_capacity</source>
			<translation>txt_3_field_capacity</translation>
		</message>
		<message>
			<source>txt_3_imprevious_surface</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_3_imprevious_surface</source>
			<translation>txt_3_imprevious_surface</translation>
		</message>
		<message>
			<source>txt_3_offset</source>
			<translation>6</translation>
		</message>
		<message>
			<source>tooltip_txt_3_offset</source>
			<translation>txt_3_offset</translation>
		</message>
		<message>
			<source>txt_3_roughness</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_3_roughness</source>
			<translation>txt_3_roughness</translation>
		</message>
		<message>
			<source>txt_3_seepage_rate</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_3_seepage_rate</source>
			<translation>txt_3_seepage_rate</translation>
		</message>
		<message>
			<source>txt_3_surface_roughness</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_3_surface_roughness</source>
			<translation>txt_3_surface_roughness</translation>
		</message>
		<message>
			<source>txt_4_clogging_factor_storage</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_4_clogging_factor_storage</source>
			<translation>txt_4_clogging_factor_storage</translation>
		</message>
		<message>
			<source>txt_4_drain_delay</source>
			<translation>6</translation>
		</message>
		<message>
			<source>tooltip_txt_4_drain_delay</source>
			<translation>txt_4_drain_delay</translation>
		</message>
		<message>
			<source>txt_4_permeability</source>
			<translation>100</translation>
		</message>
		<message>
			<source>tooltip_txt_4_permeability</source>
			<translation>txt_4_permeability</translation>
		</message>
		<message>
			<source>txt_4_surface_slope</source>
			<translation>1.0</translation>
		</message>
		<message>
			<source>tooltip_txt_4_surface_slope</source>
			<translation>txt_4_surface_slope</translation>
		</message>
		<message>
			<source>txt_4_wilting_point</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_4_wilting_point</source>
			<translation>txt_4_wilting_point</translation>
		</message>
		<message>
			<source>txt_5_clogging_factor_pavement</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_5_clogging_factor_pavement</source>
			<translation>txt_5_clogging_factor_pavement</translation>
		</message>
		<message>
			<source>txt_5_conductivity</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_5_conductivity</source>
			<translation>txt_5_conductivity</translation>
		</message>
		<message>
			<source>txt_5_open_level</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_5_open_level</source>
			<translation>txt_5_open_level</translation>
		</message>
		<message>
			<source>txt_5_swale_side_slope</source>
			<translation>5</translation>
		</message>
		<message>
			<source>tooltip_txt_5_swale_side_slope</source>
			<translation>txt_5_swale_side_slope</translation>
		</message>
		<message>
			<source>txt_6_closed_level</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_closed_level</source>
			<translation>txt_6_closed_level</translation>
		</message>
		<message>
			<source>txt_6_conducticity_slope</source>
			<translation>10.0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_conducticity_slope</source>
			<translation>txt_6_conducticity_slope</translation>
		</message>
		<message>
			<source>txt_6_regeneration_interval</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_regeneration_interval</source>
			<translation>txt_6_regeneration_interval</translation>
		</message>
		<message>
			<source>txt_7_regeneration_fraction</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_7_regeneration_fraction</source>
			<translation>txt_7_regeneration_fraction</translation>
		</message>
		<message>
			<source>txt_7_suction_head</source>
			<translation>3.5</translation>
		</message>
		<message>
			<source>tooltip_txt_7_suction_head</source>
			<translation>txt_7_suction_head</translation>
		</message>
		<message>
			<source>txt_flow_capacity</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_flow_capacity</source>
			<translation>txt_flow_capacity</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_manager</name>
		<message>
			<source>title</source>
			<translation>Manager für nicht-visuelle Objekte</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplizieren Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>Duplizieren Sie</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Form zu PNG</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>btn_print</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Aktiv umschalten</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Inaktiv anzeigen</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Inaktiv anzeigen</translation>
		</message>
		<message>
			<source>dlg_nonvisual_manager</source>
			<translation>Manager für nicht-visuelle Objekte</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_manager</source>
			<translation>dlg_nonvisual_manager</translation>
		</message>
		<message>
			<source>lbl_curve_type</source>
			<translation>Typ der Kurve:</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_type</source>
			<translation>Typ der Kurve</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtern nach:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Art des Musters:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>Typ des Musters</translation>
		</message>
		<message>
			<source>lbl_timser_type</source>
			<translation>Typ der Zeitreihe:</translation>
		</message>
		<message>
			<source>tooltip_lbl_timser_type</source>
			<translation>Typ der Zeitreihe</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_pattern_ud</name>
		<message>
			<source>title</source>
			<translation>Muster-Editor</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_pattern_ud</source>
			<translation>Muster-Editor</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_pattern_ud</source>
			<translation>dlg_nonvisual_pattern_ud</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>Betrieb ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Beobachtung</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_pattern_id</source>
			<translation>Muster-ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_id</source>
			<translation>lbl_pattern_id</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Pattern Type</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>lbl_pattern_type</translation>
		</message>
		<message>
			<source>tbl_daily</source>
			<translation>SONNE</translation>
		</message>
		<message>
			<source>tooltip_tbl_daily</source>
			<translation>tbl_daily</translation>
		</message>
		<message>
			<source>tbl_hourly</source>
			<translation>11PM</translation>
		</message>
		<message>
			<source>tooltip_tbl_hourly</source>
			<translation>tbl_hourly</translation>
		</message>
		<message>
			<source>tbl_monthly</source>
			<translation>DEC</translation>
		</message>
		<message>
			<source>tooltip_tbl_monthly</source>
			<translation>tbl_monthly</translation>
		</message>
		<message>
			<source>tbl_weekend</source>
			<translation>11PM</translation>
		</message>
		<message>
			<source>tooltip_tbl_weekend</source>
			<translation>tbl_weekend</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_pattern_ws</name>
		<message>
			<source>title</source>
			<translation>Muster-Editor</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_pattern_ws</source>
			<translation>Muster-Editor</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_pattern_ws</source>
			<translation>dlg_nonvisual_pattern_ws</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Beobachtung</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_pattern_id</source>
			<translation>Muster-ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_id</source>
			<translation>lbl_pattern_id</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Betrieb ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>lbl_pattern_type</translation>
		</message>
		<message>
			<source>tbl_pattern_value</source>
			<translation>18</translation>
		</message>
		<message>
			<source>tooltip_tbl_pattern_value</source>
			<translation>tbl_pattern_value</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_print</name>
		<message>
			<source>title</source>
			<translation>Nicht-visuelles Objekt Drucken</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>chk_cross_arccat</source>
			<translation>Kreuz mit arccat</translation>
		</message>
		<message>
			<source>tooltip_chk_cross_arccat</source>
			<translation>chk_cross_arccat</translation>
		</message>
		<message>
			<source>dlg_nonvisual_print</source>
			<translation>Nicht-visuelles Objekt Drucken</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_print</source>
			<translation>dlg_nonvisual_print</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_roughness</name>
		<message>
			<source>title</source>
			<translation>Editor für regelbasierte Steuerelemente</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Aktiv</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_roughness</source>
			<translation>Editor für regelbasierte Steuerelemente</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_roughness</source>
			<translation>dlg_nonvisual_roughness</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Zeitraum-ID</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Anfangsalter</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Alter beenden</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Rauhigkeit</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Beschreibung</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>lbl_matcat_id</source>
			<translation>Matratzennummer</translation>
		</message>
		<message>
			<source>tooltip_lbl_matcat_id</source>
			<translation>lbl_matcat_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_rules</name>
		<message>
			<source>title</source>
			<translation>Editor für regelbasierte Steuerelemente</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Aktiv</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_rules</source>
			<translation>Editor für regelbasierte Steuerelemente</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_rules</source>
			<translation>dlg_nonvisual_rules</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observ</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_sector_id</source>
			<translation>Sektor-ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_sector_id</source>
			<translation>lbl_sector_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_timeseries</name>
		<message>
			<source>title</source>
			<translation>Zeitreihen-Editor</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_timeseries</source>
			<translation>Zeitreihen-Editor</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_timeseries</source>
			<translation>dlg_nonvisual_timeseries</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Zeiten Typ</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Beschreibung</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Betrieb ID</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Aktiv</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_addparam</source>
			<translation>Addparam (json)</translation>
		</message>
		<message>
			<source>tooltip_lbl_addparam</source>
			<translation>lbl_addparam</translation>
		</message>
		<message>
			<source>lbl_curve_id</source>
			<translation>Zeitreihen-ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_id</source>
			<translation>lbl_curve_id</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Zeitreihen-Typ</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_fname</source>
			<translation>Name der Datei</translation>
		</message>
		<message>
			<source>tooltip_lbl_fname</source>
			<translation>lbl_fname</translation>
		</message>
		<message>
			<source>tbl_timeseries_value</source>
			<translation>Wert</translation>
		</message>
		<message>
			<source>tooltip_tbl_timeseries_value</source>
			<translation>tbl_timeseries_value</translation>
		</message>
	</context>
	<context>
		<name>print</name>
		<message>
			<source>title</source>
			<translation>Fastprint</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_preview</source>
			<translation>Vorschau</translation>
		</message>
		<message>
			<source>tooltip_btn_preview</source>
			<translation>btn_preview</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Drucken</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>btn_print</translation>
		</message>
		<message>
			<source>dlg_print</source>
			<translation>Fastprint</translation>
		</message>
		<message>
			<source>tooltip_dlg_print</source>
			<translation>dlg_print</translation>
		</message>
		<message>
			<source>grb_map_options</source>
			<translation>Kartenoptionen:</translation>
		</message>
		<message>
			<source>tooltip_grb_map_options</source>
			<translation>grb_map_options</translation>
		</message>
		<message>
			<source>grb_option_values</source>
			<translation>Optionale Werte:</translation>
		</message>
		<message>
			<source>tooltip_grb_option_values</source>
			<translation>grb_option_values</translation>
		</message>
	</context>
	<context>
		<name>priority</name>
		<message>
			<source>title</source>
			<translation>Prioritätsberechnung</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>ausführen.</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_again</source>
			<translation>Weiter</translation>
		</message>
		<message>
			<source>tooltip_btn_again</source>
			<translation>btn_again</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_save2file</source>
			<translation>Ergebnisse in einer Excel-Datei speichern...</translation>
		</message>
		<message>
			<source>tooltip_btn_save2file</source>
			<translation>btn_save2file</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>Merkmale auf Leinwand auswählen</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Select features on canvas</translation>
		</message>
		<message>
			<source>dlg_priority</source>
			<translation>Prioritätsberechnung</translation>
		</message>
		<message>
			<source>tooltip_dlg_priority</source>
			<translation>dlg_priority</translation>
		</message>
		<message>
			<source>grb_engine_1</source>
			<translation>grb_motor_1</translation>
		</message>
		<message>
			<source>tooltip_grb_engine_1</source>
			<translation>grb_engine_1</translation>
		</message>
		<message>
			<source>grb_engine_2</source>
			<translation>grb_motor_2</translation>
		</message>
		<message>
			<source>tooltip_grb_engine_2</source>
			<translation>grb_engine_2</translation>
		</message>
		<message>
			<source>grb_global</source>
			<translation>Berechnungsparameter</translation>
		</message>
		<message>
			<source>tooltip_grb_global</source>
			<translation>grb_global</translation>
		</message>
		<message>
			<source>grb_selection</source>
			<translation>Auswahl der Merkmale</translation>
		</message>
		<message>
			<source>tooltip_grb_selection</source>
			<translation>grb_selection</translation>
		</message>
		<message>
			<source>lbl_budget</source>
			<translation>Jährliches Budget:</translation>
		</message>
		<message>
			<source>tooltip_lbl_budget</source>
			<translation>lbl_budget</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_dnom</source>
			<translation>Durchmesser:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dnom</source>
			<translation>lbl_dnom</translation>
		</message>
		<message>
			<source>lbl_expl_selection</source>
			<translation>Betrieb:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_selection</source>
			<translation>lbl_expl_selection</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Material:</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>lbl_material</translation>
		</message>
		<message>
			<source>lbl_presszone</source>
			<translation>Pressebereich:</translation>
		</message>
		<message>
			<source>tooltip_lbl_presszone</source>
			<translation>lbl_presszone</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Name des Ergebnisses:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_year</source>
			<translation>Jahr des Horizonts:</translation>
		</message>
		<message>
			<source>tooltip_lbl_year</source>
			<translation>lbl_year</translation>
		</message>
		<message>
			<source>tab_calc</source>
			<translation>Berechnung</translation>
		</message>
		<message>
			<source>tooltip_tab_calc</source>
			<translation>tab_calc</translation>
		</message>
		<message>
			<source>tab_catalog</source>
			<translation>Katalog</translation>
		</message>
		<message>
			<source>tooltip_tab_catalog</source>
			<translation>tab_catalog</translation>
		</message>
		<message>
			<source>tab_engine</source>
			<translation>Motor</translation>
		</message>
		<message>
			<source>tooltip_tab_engine</source>
			<translation>tab_engine</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>tooltip_tab_material</source>
			<translation>tab_material</translation>
		</message>
	</context>
	<context>
		<name>priority_manager</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_corporate</source>
			<translation>Satz Unternehmen</translation>
		</message>
		<message>
			<source>tooltip_btn_corporate</source>
			<translation>btn_corporate</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplizieren Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_edit</source>
			<translation>bearbeiten</translation>
		</message>
		<message>
			<source>tooltip_btn_edit</source>
			<translation>btn_edit</translation>
		</message>
		<message>
			<source>btn_status</source>
			<translation>Status ändern</translation>
		</message>
		<message>
			<source>tooltip_btn_status</source>
			<translation>btn_status</translation>
		</message>
		<message>
			<source>dlg_priority_manager</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_priority_manager</source>
			<translation>dlg_priority_manager</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Betrieb:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtern nach: Name des Ergebnisses</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Art:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
	</context>
	<context>
		<name>profile</name>
		<message>
			<source>title</source>
			<translation>Profil zeichnen</translation>
		</message>
		<message>
			<source>actionAddPoint</source>
			<translation>actionAddPoint</translation>
		</message>
		<message>
			<source>tooltip_actionAddPoint</source>
			<translation>Add additional point</translation>
		</message>
		<message>
			<source>actionProfile</source>
			<translation>actionProfile</translation>
		</message>
		<message>
			<source>tooltip_actionProfile</source>
			<translation>Set nodes</translation>
		</message>
		<message>
			<source>btn_clear_profile</source>
			<translation>Klares Profil</translation>
		</message>
		<message>
			<source>tooltip_btn_clear_profile</source>
			<translation>btn_clear_profile</translation>
		</message>
		<message>
			<source>btn_delete_additional_point</source>
			<translation>btn_delete_additional_point</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_additional_point</source>
			<translation>btn_delete_additional_point</translation>
		</message>
		<message>
			<source>btn_draw_profile</source>
			<translation>Profil zeichnen</translation>
		</message>
		<message>
			<source>tooltip_btn_draw_profile</source>
			<translation>btn_draw_profile</translation>
		</message>
		<message>
			<source>btn_load_profile</source>
			<translation>Lastprofile</translation>
		</message>
		<message>
			<source>tooltip_btn_load_profile</source>
			<translation>btn_load_profile</translation>
		</message>
		<message>
			<source>btn_save_profile</source>
			<translation>Profil speichern</translation>
		</message>
		<message>
			<source>tooltip_btn_save_profile</source>
			<translation>btn_save_profile</translation>
		</message>
		<message>
			<source>date</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_date</source>
			<translation>date</translation>
		</message>
		<message>
			<source>dlg_profile</source>
			<translation>Profil zeichnen</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile</source>
			<translation>dlg_profile</translation>
		</message>
		<message>
			<source>grb_composer</source>
			<translation>Parameters</translation>
		</message>
		<message>
			<source>tooltip_grb_composer</source>
			<translation>grb_composer</translation>
		</message>
		<message>
			<source>grb_profile</source>
			<translation>Profil</translation>
		</message>
		<message>
			<source>tooltip_grb_profile</source>
			<translation>grb_profile</translation>
		</message>
		<message>
			<source>lbl_date</source>
			<translation>Datum:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date</source>
			<translation>Date to be displayed</translation>
		</message>
		<message>
			<source>lbl_min_distance</source>
			<translation>Vnode Min Dist:</translation>
		</message>
		<message>
			<source>tooltip_lbl_min_distance</source>
			<translation>Minimum distance between vnodes to be displayed</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Titel:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>Profile title to be displayed</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>txt_profile_id</source>
			<translation>Optionale Profil-ID</translation>
		</message>
		<message>
			<source>tooltip_txt_profile_id</source>
			<translation>Optional profile ID</translation>
		</message>
	</context>
	<context>
		<name>profile_interpolation</name>
		<message>
			<source>title</source>
			<translation>Profile interpolation</translation>
		</message>
		<message>
			<source>dlg_profile_interpolation</source>
			<translation>Profile interpolation</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile_interpolation</source>
			<translation>dlg_profile_interpolation</translation>
		</message>
	</context>
	<context>
		<name>profile_list</name>
		<message>
			<source>title</source>
			<translation>Lastprofile</translation>
		</message>
		<message>
			<source>btn_delete_profile</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_profile</source>
			<translation>btn_delete_profile</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Öffnen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_profile_list</source>
			<translation>Lastprofile</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile_list</source>
			<translation>dlg_profile_list</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Liste der Profile</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
	</context>
	<context>
		<name>project_check</name>
		<message>
			<source>title</source>
			<translation>Projekt prüfen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>dlg_project_check</source>
			<translation>Projekt prüfen</translation>
		</message>
		<message>
			<source>tooltip_dlg_project_check</source>
			<translation>dlg_project_check</translation>
		</message>
		<message>
			<source>tab_databaselog</source>
			<translation>Datenbank-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_databaselog</source>
			<translation>tab_databaselog</translation>
		</message>
	</context>
	<context>
		<name>psector</name>
		<message>
			<source>title</source>
			<translation>Plan pSektor</translation>
		</message>
		<message>
			<source>btn_remove</source>
			<translation>entfernen</translation>
		</message>
		<message>
			<source>tooltip_btn_remove</source>
			<translation>btn_remove</translation>
		</message>
		<message>
			<source>btn_reports</source>
			<translation>Bericht generieren</translation>
		</message>
		<message>
			<source>tooltip_btn_reports</source>
			<translation>btn_reports</translation>
		</message>
		<message>
			<source>btn_select</source>
			<translation>hinzufügen</translation>
		</message>
		<message>
			<source>tooltip_btn_select</source>
			<translation>btn_select</translation>
		</message>
		<message>
			<source>btn_set_geom</source>
			<translation>Geometrie festlegen</translation>
		</message>
		<message>
			<source>tooltip_btn_set_geom</source>
			<translation>btn_set_geom</translation>
		</message>
		<message>
			<source>dlg_psector</source>
			<translation>Plan pSektor</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector</source>
			<translation>dlg_psector</translation>
		</message>
		<message>
			<source>gexpenses_label</source>
			<translation>Allgemeine Kosten</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label</source>
			<translation>gexpenses_label</translation>
		</message>
		<message>
			<source>gexpenses_label_10</source>
			<translation>Bögen insgesamt:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_10</source>
			<translation>gexpenses_label_10</translation>
		</message>
		<message>
			<source>gexpenses_label_3</source>
			<translation>Knotenpunkte insgesamt:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_3</source>
			<translation>gexpenses_label_3</translation>
		</message>
		<message>
			<source>gexpenses_label_4</source>
			<translation>Sonstige Preise insgesamt:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_4</source>
			<translation>gexpenses_label_4</translation>
		</message>
		<message>
			<source>gexpenses_label_5</source>
			<translation>Insgesamt:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_5</source>
			<translation>gexpenses_label_5</translation>
		</message>
		<message>
			<source>gexpenses_label_6</source>
			<translation>Insgesamt:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_6</source>
			<translation>gexpenses_label_6</translation>
		</message>
		<message>
			<source>gexpenses_label_7</source>
			<translation>Insgesamt:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_7</source>
			<translation>gexpenses_label_7</translation>
		</message>
		<message>
			<source>gexpenses_label_8</source>
			<translation>Insgesamt:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_8</source>
			<translation>gexpenses_label_8</translation>
		</message>
		<message>
			<source>lbl_num_value</source>
			<translation>Ziffernwert:</translation>
		</message>
		<message>
			<source>tooltip_lbl_num_value</source>
			<translation>lbl_num_value</translation>
		</message>
		<message>
			<source>lbl_text3</source>
			<translation>Text 3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text3</source>
			<translation>lbl_text3</translation>
		</message>
		<message>
			<source>lbl_text4</source>
			<translation>Text 4:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text4</source>
			<translation>lbl_text4</translation>
		</message>
		<message>
			<source>lbl_text5</source>
			<translation>Text 5:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text5</source>
			<translation>lbl_text5</translation>
		</message>
		<message>
			<source>lbl_text6</source>
			<translation>Text 6:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text6</source>
			<translation>lbl_text6</translation>
		</message>
		<message>
			<source>lbl_total</source>
			<translation>Insgesamt :</translation>
		</message>
		<message>
			<source>tooltip_lbl_total</source>
			<translation>lbl_total</translation>
		</message>
		<message>
			<source>lbl_total_count</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_lbl_total_count</source>
			<translation>lbl_total_count</translation>
		</message>
		<message>
			<source>other_label</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label</source>
			<translation>other_label</translation>
		</message>
		<message>
			<source>other_label_2</source>
			<translation>Sonstige Ausgaben</translation>
		</message>
		<message>
			<source>tooltip_other_label_2</source>
			<translation>other_label_2</translation>
		</message>
		<message>
			<source>other_label_3</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_3</source>
			<translation>other_label_3</translation>
		</message>
		<message>
			<source>other_label_4</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_4</source>
			<translation>other_label_4</translation>
		</message>
		<message>
			<source>tab_additional_info</source>
			<translation>Zusätzliche Informationen</translation>
		</message>
		<message>
			<source>tooltip_tab_additional_info</source>
			<translation>tab_additional_info</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_budget</source>
			<translation>Haushalt</translation>
		</message>
		<message>
			<source>tooltip_tab_budget</source>
			<translation>tab_budget</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>tab_document</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Allgemein</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_other_prices</source>
			<translation>Andere Preise</translation>
		</message>
		<message>
			<source>tooltip_tab_other_prices</source>
			<translation>tab_other_prices</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Beziehungen</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
		<message>
			<source>vat_label</source>
			<translation>MEHRWERTSTEUER:</translation>
		</message>
		<message>
			<source>tooltip_vat_label</source>
			<translation>vat_label</translation>
		</message>
	</context>
	<context>
		<name>psector_duplicate</name>
		<message>
			<source>title</source>
			<translation>Duplizieren von psector</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_psector_duplicate</source>
			<translation>Duplizieren von psector</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_duplicate</source>
			<translation>dlg_psector_duplicate</translation>
		</message>
		<message>
			<source>lbl_duplicate_psector</source>
			<translation>Duplizieren Sie psector:</translation>
		</message>
		<message>
			<source>tooltip_lbl_duplicate_psector</source>
			<translation>lbl_duplicate_psector</translation>
		</message>
		<message>
			<source>lbl_new_psector</source>
			<translation>Neuer Name des Sektors:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_psector</source>
			<translation>lbl_new_psector</translation>
		</message>
		<message>
			<source>tab_duplicate_psector</source>
			<translation>Duplizieren von psector</translation>
		</message>
		<message>
			<source>tooltip_tab_duplicate_psector</source>
			<translation>tab_duplicate_psector</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Info-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>psector_manager</name>
		<message>
			<source>title</source>
			<translation>Verwaltung des Sektors</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplizieren Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_merge</source>
			<translation>Zusammenführen</translation>
		</message>
		<message>
			<source>tooltip_btn_merge</source>
			<translation>Um mehrere Sektoren zu einem einzigen zusammenzufügen, müssen Sie sie zuvor mit der Strg-Taste auswählen und dann auf diese Schaltfläche klicken</translation>
		</message>
		<message>
			<source>btn_restore</source>
			<translation>Wiederherstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_restore</source>
			<translation>btn_restore</translation>
		</message>
		<message>
			<source>btn_show</source>
			<translation>anzeigen</translation>
		</message>
		<message>
			<source>tooltip_btn_show</source>
			<translation>btn_show</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Aktiv umschalten</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>btn_update_psector</source>
			<translation>Strom umschalten</translation>
		</message>
		<message>
			<source>tooltip_btn_update_psector</source>
			<translation>btn_update_psector</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Inaktiv anzeigen</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Inaktiv anzeigen</translation>
		</message>
		<message>
			<source>chk_archived</source>
			<translation>Archiviert anzeigen</translation>
		</message>
		<message>
			<source>tooltip_chk_archived</source>
			<translation>chk_archived</translation>
		</message>
		<message>
			<source>chk_filter_canvas</source>
			<translation>Filter aus der Leinwand</translation>
		</message>
		<message>
			<source>tooltip_chk_filter_canvas</source>
			<translation>Nur im Canvas sichtbare Sektoren anzeigen</translation>
		</message>
		<message>
			<source>dlg_psector_manager</source>
			<translation>Verwaltung des Sektors</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_manager</source>
			<translation>dlg_psector_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_psector_name</source>
			<translation>Filtern nach: Name des Sektors</translation>
		</message>
		<message>
			<source>tooltip_lbl_psector_name</source>
			<translation>lbl_psector_name</translation>
		</message>
	</context>
	<context>
		<name>psector_rapport</name>
		<message>
			<source>title</source>
			<translation>Psektor-Bericht</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>chk_composer</source>
			<translation>Composer pdf-Datei</translation>
		</message>
		<message>
			<source>tooltip_chk_composer</source>
			<translation>chk_composer</translation>
		</message>
		<message>
			<source>dlg_psector_rapport</source>
			<translation>Psektor-Bericht</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_rapport</source>
			<translation>dlg_psector_rapport</translation>
		</message>
		<message>
			<source>grb_rapport</source>
			<translation>Rapport</translation>
		</message>
		<message>
			<source>tooltip_grb_rapport</source>
			<translation>grb_rapport</translation>
		</message>
		<message>
			<source>lbl_detail_csv</source>
			<translation>Detail csv-Datei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_detail_csv</source>
			<translation>lbl_detail_csv</translation>
		</message>
		<message>
			<source>lbl_prices_list</source>
			<translation>Preise Liste csv-Datei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prices_list</source>
			<translation>lbl_prices_list</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Vorlage</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
	</context>
	<context>
		<name>psector_repair</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_repair</source>
			<translation>Reparatur</translation>
		</message>
		<message>
			<source>tooltip_btn_repair</source>
			<translation>btn_repair</translation>
		</message>
		<message>
			<source>dlg_psector_repair</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_repair</source>
			<translation>dlg_psector_repair</translation>
		</message>
	</context>
	<context>
		<name>replace_in_file</name>
		<message>
			<source>title</source>
			<translation>Ersetzen von Text in der Datei</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_replace_in_file</source>
			<translation>Ersetzen von Text in der Datei</translation>
		</message>
		<message>
			<source>tooltip_dlg_replace_in_file</source>
			<translation>dlg_replace_in_file</translation>
		</message>
		<message>
			<source>lbl_subtitle</source>
			<translation>Es gibt Objekte mit mehr als 16 Zeichen in ihrem Namen</translation>
		</message>
		<message>
			<source>tooltip_lbl_subtitle</source>
			<translation>lbl_subtitle</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Ersetzen Sie diese Namen durch neue Namen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
	</context>
	<context>
		<name>resources_management</name>
		<message>
			<source>btn_assign_team</source>
			<translation>Team zuweisen</translation>
		</message>
		<message>
			<source>tooltip_btn_assign_team</source>
			<translation>btn_assign_team</translation>
		</message>
		<message>
			<source>btn_campaign_save</source>
			<translation>Save</translation>
		</message>
		<message>
			<source>tooltip_btn_campaign_save</source>
			<translation>btn_campaign_save</translation>
		</message>
		<message>
			<source>btn_change_team</source>
			<translation>Change team</translation>
		</message>
		<message>
			<source>tooltip_btn_change_team</source>
			<translation>btn_change_team</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>btn_remove_team</source>
			<translation>Team entfernen</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_team</source>
			<translation>btn_remove_team</translation>
		</message>
		<message>
			<source>btn_team_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_team_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>btn_team_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_team_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>btn_team_toggle_active</source>
			<translation>Aktiv umschalten</translation>
		</message>
		<message>
			<source>tooltip_btn_team_toggle_active</source>
			<translation>btn_team_toggle_active</translation>
		</message>
		<message>
			<source>btn_team_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_team_update</source>
			<translation>Ändern Sie</translation>
		</message>
		<message>
			<source>btn_user_toggle_active</source>
			<translation>Aktiv umschalten</translation>
		</message>
		<message>
			<source>tooltip_btn_user_toggle_active</source>
			<translation>btn_user_toggle_active</translation>
		</message>
		<message>
			<source>cmb_team</source>
			<translation>Team auswählen</translation>
		</message>
		<message>
			<source>tooltip_cmb_team</source>
			<translation>cmb_team</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Nach Namen filtern:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Nach Organisation filtern:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Nach Teams filtern:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>lbl_campaign</source>
			<translation>Campaign:</translation>
		</message>
		<message>
			<source>tooltip_lbl_campaign</source>
			<translation>lbl_campaign</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>User:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
		<message>
			<source>resource_management</source>
			<translation>Resource Management</translation>
		</message>
		<message>
			<source>tooltip_resource_management</source>
			<translation>resource_management</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Campaign revision</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_organizations</source>
			<translation>Organisationen</translation>
		</message>
		<message>
			<source>tooltip_tab_organizations</source>
			<translation>tab_organizations</translation>
		</message>
		<message>
			<source>tab_teams</source>
			<translation>Mannschaften</translation>
		</message>
		<message>
			<source>tooltip_tab_teams</source>
			<translation>tab_teams</translation>
		</message>
		<message>
			<source>tab_users</source>
			<translation>Benutzer</translation>
		</message>
		<message>
			<source>tooltip_tab_users</source>
			<translation>tab_users</translation>
		</message>
	</context>
	<context>
		<name>result_selector</name>
		<message>
			<source>title</source>
			<translation>Ergebnis-Selektor</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_result_selector</source>
			<translation>Ergebnis-Selektor</translation>
		</message>
		<message>
			<source>tooltip_dlg_result_selector</source>
			<translation>dlg_result_selector</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_descript_compare</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_compare</source>
			<translation>lbl_descript_compare</translation>
		</message>
		<message>
			<source>lbl_result_compare</source>
			<translation>Ergebnis zu vergleichen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_compare</source>
			<translation>lbl_result_compare</translation>
		</message>
		<message>
			<source>lbl_result_main</source>
			<translation>Ergebnis zu zeigen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_main</source>
			<translation>lbl_result_main</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Ergebnis</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
	</context>
	<context>
		<name>scada_graph</name>
		<message>
			<source>title</source>
			<translation>Scada graph</translation>
		</message>
		<message>
			<source>dlg_scada_graph</source>
			<translation>Scada graph</translation>
		</message>
		<message>
			<source>tooltip_dlg_scada_graph</source>
			<translation>dlg_scada_graph</translation>
		</message>
	</context>
	<context>
		<name>search_workcat</name>
		<message>
			<source>title</source>
			<translation>Workcat Suche</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_export_to_csv</source>
			<translation>Exportieren nach csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_to_csv</source>
			<translation>btn_export_to_csv</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_state0</source>
			<translation>Aktivieren Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_state0</source>
			<translation>btn_state0</translation>
		</message>
		<message>
			<source>btn_state1</source>
			<translation>Aktivieren Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_state1</source>
			<translation>btn_state1</translation>
		</message>
		<message>
			<source>dlg_search_workcat</source>
			<translation>Workcat Suche</translation>
		</message>
		<message>
			<source>tooltip_dlg_search_workcat</source>
			<translation>dlg_search_workcat</translation>
		</message>
		<message>
			<source>lbl_destination_path</source>
			<translation>Zielpfad:</translation>
		</message>
		<message>
			<source>tooltip_lbl_destination_path</source>
			<translation>lbl_destination_path</translation>
		</message>
		<message>
			<source>lbl_end</source>
			<translation>Filtern nach: Code</translation>
		</message>
		<message>
			<source>tooltip_lbl_end</source>
			<translation>lbl_end</translation>
		</message>
		<message>
			<source>lbl_feat_end</source>
			<translation>Funktionen, die mit dem ausgewählten Workcat entfernt wurden</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_end</source>
			<translation>lbl_feat_end</translation>
		</message>
		<message>
			<source>lbl_feat_ini</source>
			<translation>Mit dem ausgewählten Workcat installierte Funktionen</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_ini</source>
			<translation>lbl_feat_ini</translation>
		</message>
		<message>
			<source>lbl_init</source>
			<translation>Filtern nach: Code</translation>
		</message>
		<message>
			<source>tooltip_lbl_init</source>
			<translation>lbl_init</translation>
		</message>
		<message>
			<source>lbl_total1</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;&amp;lt;span style=&amp;quot; font-weight:600;&amp;quot;&amp;gt;Zahlen insgesamt:&amp;lt;/span&amp;gt;&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_lbl_total1</source>
			<translation>lbl_total1</translation>
		</message>
		<message>
			<source>lbl_total2</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;&amp;lt;span style=&amp;quot; font-weight:600;&amp;quot;&amp;gt;Zahlen insgesamt:&amp;lt;/span&amp;gt;&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_lbl_total2</source>
			<translation>lbl_total2</translation>
		</message>
		<message>
			<source>tab_doc</source>
			<translation>Dokumente</translation>
		</message>
		<message>
			<source>tooltip_tab_doc</source>
			<translation>tab_doc</translation>
		</message>
		<message>
			<source>tab_ended</source>
			<translation>Entfernt</translation>
		</message>
		<message>
			<source>tooltip_tab_ended</source>
			<translation>tab_ended</translation>
		</message>
		<message>
			<source>tab_init</source>
			<translation>Installiert</translation>
		</message>
		<message>
			<source>tooltip_tab_init</source>
			<translation>tab_init</translation>
		</message>
	</context>
	<context>
		<name>selector</name>
		<message>
			<source>title</source>
			<translation>Selektor</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_selector</source>
			<translation>Selektor</translation>
		</message>
		<message>
			<source>tooltip_dlg_selector</source>
			<translation>dlg_selector</translation>
		</message>
	</context>
	<context>
		<name>selector_date</name>
		<message>
			<source>title</source>
			<translation>Datumselektor</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>date_from</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_date_from</source>
			<translation>date_from</translation>
		</message>
		<message>
			<source>date_to</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_date_to</source>
			<translation>date_to</translation>
		</message>
		<message>
			<source>dlg_selector_date</source>
			<translation>Datumselektor</translation>
		</message>
		<message>
			<source>tooltip_dlg_selector_date</source>
			<translation>dlg_selector_date</translation>
		</message>
		<message>
			<source>lbl_date_from</source>
			<translation>Datum vom:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_from</source>
			<translation>lbl_date_from</translation>
		</message>
		<message>
			<source>lbl_date_to</source>
			<translation>Datum bis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_to</source>
			<translation>lbl_date_to</translation>
		</message>
	</context>
	<context>
		<name>snapshot_view</name>
		<message>
			<source>Audit</source>
			<translation>Prüfung</translation>
		</message>
		<message>
			<source>tooltip_Audit</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Funktionen zur Wiederherstellung</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Funktionen zur Wiederherstellung</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Zeitliche und räumliche Auswahl</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Zeitliche und räumliche Auswahl</translation>
		</message>
	</context>
	<context>
		<name>status_selector</name>
		<message>
			<source>title</source>
			<translation>Status Selektor</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_status_selector</source>
			<translation>Status Selektor</translation>
		</message>
		<message>
			<source>tooltip_dlg_status_selector</source>
			<translation>dlg_status_selector</translation>
		</message>
		<message>
			<source>lbl_new_status</source>
			<translation>Neuer Status:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_status</source>
			<translation>lbl_new_status</translation>
		</message>
		<message>
			<source>lbl_result</source>
			<translation>result_id: result_name</translation>
		</message>
		<message>
			<source>tooltip_lbl_result</source>
			<translation>lbl_result</translation>
		</message>
		<message>
			<source>lbl_result_main</source>
			<translation>Sie ändern den Status des folgenden Ergebnisses:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_main</source>
			<translation>lbl_result_main</translation>
		</message>
	</context>
	<context>
		<name>style</name>
		<message>
			<source>title</source>
			<translation>Kategorie hinzufügen</translation>
		</message>
		<message>
			<source>addparam</source>
			<translation>{&quot;orderBy&quot;:1}</translation>
		</message>
		<message>
			<source>tooltip_addparam</source>
			<translation>addparam</translation>
		</message>
		<message>
			<source>btn_add</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_add</source>
			<translation>btn_add</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_style</source>
			<translation>Kategorie hinzufügen</translation>
		</message>
		<message>
			<source>tooltip_dlg_style</source>
			<translation>dlg_style</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Active:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_addparam</source>
			<translation>Addparam:</translation>
		</message>
		<message>
			<source>tooltip_lbl_addparam</source>
			<translation>lbl_addparam</translation>
		</message>
		<message>
			<source>lbl_cat_id</source>
			<translation>Kategorie-ID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_id</source>
			<translation>lbl_cat_id</translation>
		</message>
		<message>
			<source>lbl_cat_name</source>
			<translation>Name der Kategorie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_name</source>
			<translation>lbl_cat_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_is_templayer</source>
			<translation>Is templayer:</translation>
		</message>
		<message>
			<source>tooltip_lbl_is_templayer</source>
			<translation>lbl_is_templayer</translation>
		</message>
		<message>
			<source>lbl_role</source>
			<translation>Die Rolle:</translation>
		</message>
		<message>
			<source>tooltip_lbl_role</source>
			<translation>lbl_role</translation>
		</message>
		<message>
			<source>tab_del_feature</source>
			<translation>Daten</translation>
		</message>
		<message>
			<source>tooltip_tab_del_feature</source>
			<translation>tab_del_feature</translation>
		</message>
	</context>
	<context>
		<name>style_manager</name>
		<message>
			<source>title</source>
			<translation>Style management</translation>
		</message>
		<message>
			<source>btn_add_style</source>
			<translation>Stil hinzufügen</translation>
		</message>
		<message>
			<source>tooltip_btn_add_style</source>
			<translation>Stil hinzufügen</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>btn_delete_style</source>
			<translation>Stil löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_style</source>
			<translation>btn_delete_style</translation>
		</message>
		<message>
			<source>btn_refresh_all</source>
			<translation>Alle aktualisieren</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh_all</source>
			<translation>Alle aktualisieren</translation>
		</message>
		<message>
			<source>btn_update_group</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_group</source>
			<translation>Ausgewählte Kategorie aktualisieren</translation>
		</message>
		<message>
			<source>btn_update_style</source>
			<translation>Stil aktualisieren</translation>
		</message>
		<message>
			<source>tooltip_btn_update_style</source>
			<translation>Stil aktualisieren</translation>
		</message>
		<message>
			<source>dlg_style_manager</source>
			<translation>Style management</translation>
		</message>
		<message>
			<source>tooltip_dlg_style_manager</source>
			<translation>dlg_style_manager</translation>
		</message>
		<message>
			<source>lbl_filter_category</source>
			<translation>Filtern nach: Kategorie</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_category</source>
			<translation>lbl_filter_category</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtern nach: layername</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>style_update_category</name>
		<message>
			<source>title</source>
			<translation>Kategorie umbenennen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_style_update_category</source>
			<translation>Kategorie umbenennen</translation>
		</message>
		<message>
			<source>tooltip_dlg_style_update_category</source>
			<translation>dlg_style_update_category</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Bitte wählen Sie einen neuen Kategorienamen:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>lbl_rename_copy</translation>
		</message>
	</context>
	<context>
		<name>team_create</name>
		<message>
			<source>title</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>dlg_team_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_dlg_team_create</source>
			<translation>dlg_team_create</translation>
		</message>
		<message>
			<source>grb_team</source>
			<translation>Mannschaft:</translation>
		</message>
		<message>
			<source>tooltip_grb_team</source>
			<translation>grb_team</translation>
		</message>
		<message>
			<source>TeamTab</source>
			<translation>Team</translation>
		</message>
		<message>
			<source>tooltip_TeamTab</source>
			<translation>TeamTab</translation>
		</message>
	</context>
	<context>
		<name>team_management</name>
		<message>
			<source>title</source>
			<translation>Ausrüstungsmanager</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_user_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_user_select</source>
			<translation>btn_user_select</translation>
		</message>
		<message>
			<source>btn_user_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_user_unselect</source>
			<translation>btn_user_unselect</translation>
		</message>
		<message>
			<source>btn_vehicle_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_vehicle_select</source>
			<translation>btn_vehicle_select</translation>
		</message>
		<message>
			<source>btn_vehicle_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_vehicle_unselect</source>
			<translation>btn_vehicle_unselect</translation>
		</message>
		<message>
			<source>btn_visitclass_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_visitclass_select</source>
			<translation>btn_visitclass_select</translation>
		</message>
		<message>
			<source>btn_visitclass_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_visitclass_unselect</source>
			<translation>btn_visitclass_unselect</translation>
		</message>
		<message>
			<source>dlg_team_management</source>
			<translation>Ausrüstungsmanager</translation>
		</message>
		<message>
			<source>tooltip_dlg_team_management</source>
			<translation>dlg_team_management</translation>
		</message>
		<message>
			<source>tab_user</source>
			<translation>Benutzer</translation>
		</message>
		<message>
			<source>tooltip_tab_user</source>
			<translation>Benutzer</translation>
		</message>
		<message>
			<source>tab_vehicles</source>
			<translation>Fahrzeuge</translation>
		</message>
		<message>
			<source>tooltip_tab_vehicles</source>
			<translation>Fahrzeuge</translation>
		</message>
		<message>
			<source>tab_visit_class</source>
			<translation>Klasse besuchen</translation>
		</message>
		<message>
			<source>tooltip_tab_visit_class</source>
			<translation>Klasse besuchen</translation>
		</message>
	</context>
	<context>
		<name>toolbox</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>dlg_toolbox</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_toolbox</source>
			<translation>dlg_toolbox</translation>
		</message>
	</context>
	<context>
		<name>toolbox_reports</name>
		<message>
			<source>title</source>
			<translation>Berichte</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_export</source>
			<translation>Exportieren</translation>
		</message>
		<message>
			<source>tooltip_btn_export</source>
			<translation>btn_export</translation>
		</message>
		<message>
			<source>btn_export_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_export_path</source>
			<translation>btn_export_path</translation>
		</message>
		<message>
			<source>dlg_toolbox_reports</source>
			<translation>Berichte</translation>
		</message>
		<message>
			<source>tooltip_dlg_toolbox_reports</source>
			<translation>dlg_toolbox_reports</translation>
		</message>
		<message>
			<source>grb_filters</source>
			<translation>Filters</translation>
		</message>
		<message>
			<source>tooltip_grb_filters</source>
			<translation>grb_filters</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Abfrage:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>lbl_export_path</source>
			<translation>Pfad:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_path</source>
			<translation>lbl_export_path</translation>
		</message>
	</context>
	<context>
		<name>toolbox_tool</name>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_run</source>
			<translation>ausführen.</translation>
		</message>
		<message>
			<source>tooltip_btn_run</source>
			<translation>btn_run</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_input_layer</source>
			<translation>Eingabeschicht:</translation>
		</message>
		<message>
			<source>tooltip_grb_input_layer</source>
			<translation>grb_input_layer</translation>
		</message>
		<message>
			<source>grb_parameters</source>
			<translation>Parameter der Option:</translation>
		</message>
		<message>
			<source>tooltip_grb_parameters</source>
			<translation>grb_parameters</translation>
		</message>
		<message>
			<source>grb_selection_type</source>
			<translation>Art der Auswahl:</translation>
		</message>
		<message>
			<source>tooltip_grb_selection_type</source>
			<translation>grb_selection_type</translation>
		</message>
		<message>
			<source>progressBar</source>
			<translation>%p%</translation>
		</message>
		<message>
			<source>tooltip_progressBar</source>
			<translation>progressBar</translation>
		</message>
		<message>
			<source>rbt_layer</source>
			<translation>Alle Merkmale</translation>
		</message>
		<message>
			<source>tooltip_rbt_layer</source>
			<translation>rbt_layer</translation>
		</message>
		<message>
			<source>rbt_previous</source>
			<translation>Nur ausgewählte Merkmale</translation>
		</message>
		<message>
			<source>tooltip_rbt_previous</source>
			<translation>rbt_previous</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfigurieren Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Info-Log</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>visit</name>
		<message>
			<source>title</source>
			<translation>Besuchen Sie</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Geom hinzufügen</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>btn_add_geom</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_event_delete</source>
			<translation>VERANSTALTUNG LÖSCHEN</translation>
		</message>
		<message>
			<source>tooltip_btn_event_delete</source>
			<translation>btn_event_delete</translation>
		</message>
		<message>
			<source>btn_event_insert</source>
			<translation>EREIGNIS EINFÜGEN</translation>
		</message>
		<message>
			<source>tooltip_btn_event_insert</source>
			<translation>btn_event_insert</translation>
		</message>
		<message>
			<source>btn_event_update</source>
			<translation>UPDATE EVENT</translation>
		</message>
		<message>
			<source>tooltip_btn_event_update</source>
			<translation>btn_event_update</translation>
		</message>
		<message>
			<source>btn_feature_delete</source>
			<translation>btn_feature_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_delete</source>
			<translation>btn_feature_delete</translation>
		</message>
		<message>
			<source>btn_feature_insert</source>
			<translation>btn_feature_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_insert</source>
			<translation>btn_feature_insert</translation>
		</message>
		<message>
			<source>btn_feature_snapping</source>
			<translation>btn_feature_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_snapping</source>
			<translation>btn_feature_snapping</translation>
		</message>
		<message>
			<source>dlg_visit</source>
			<translation>Besuchen Sie</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit</source>
			<translation>dlg_visit</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Merkmalstyp:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation>Code:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_end_date</source>
			<translation>Enddatum:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_date</source>
			<translation>lbl_end_date</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Betrieb:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>In der Symbolleiste sind nur STANDARD-EREIGNISSE aktiviert.</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_start_date</source>
			<translation>Startdatum:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_date</source>
			<translation>lbl_start_date</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_user_name</source>
			<translation>Name des Benutzers:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user_name</source>
			<translation>lbl_user_name</translation>
		</message>
		<message>
			<source>lbl_visitcat_id</source>
			<translation>Visitcat-ID:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_visitcat_id</source>
			<translation>lbl_visitcat_id</translation>
		</message>
		<message>
			<source>startdate</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_startdate</source>
			<translation>startdate</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Bogen</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>tab_document</translation>
		</message>
		<message>
			<source>tab_event</source>
			<translation>Veranstaltung</translation>
		</message>
		<message>
			<source>tooltip_tab_event</source>
			<translation>tab_event</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link zu</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Knotenpunkt</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Beziehungen</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Besuchen Sie</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
	</context>
	<context>
		<name>visit_document</name>
		<message>
			<source>title</source>
			<translation>Dokumente laden</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Öffnen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_visit_document</source>
			<translation>Dokumente laden</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_document</source>
			<translation>dlg_visit_document</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Liste der Dokumente</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Id besuchen</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_event</name>
		<message>
			<source>title</source>
			<translation>Standard-Ereignis</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_file</source>
			<translation>Datei hinzufügen</translation>
		</message>
		<message>
			<source>tooltip_btn_add_file</source>
			<translation>btn_add_file</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_file</source>
			<translation>Datei löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_file</source>
			<translation>btn_delete_file</translation>
		</message>
		<message>
			<source>dlg_visit_event</source>
			<translation>Standard-Ereignis</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event</source>
			<translation>dlg_visit_event</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Ereignis_code:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Dateien:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Parameter id:      </translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Position id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Positionswert:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Text:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_value</source>
			<translation>Wert:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value</source>
			<translation>lbl_value</translation>
		</message>
	</context>
	<context>
		<name>visit_event_full</name>
		<message>
			<source>title</source>
			<translation>Veranstaltung</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_visit_event_full</source>
			<translation>Veranstaltung</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event_full</source>
			<translation>dlg_visit_event_full</translation>
		</message>
		<message>
			<source>lbl_compass</source>
			<translation>Kompass:</translation>
		</message>
		<message>
			<source>tooltip_lbl_compass</source>
			<translation>lbl_compass</translation>
		</message>
		<message>
			<source>lbl_event_code</source>
			<translation>Ereignis-Code:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_code</source>
			<translation>lbl_event_code</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Dateien:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_geom1</source>
			<translation>Geom1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom1</source>
			<translation>lbl_geom1</translation>
		</message>
		<message>
			<source>lbl_geom2</source>
			<translation>Geom2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom2</source>
			<translation>lbl_geom2</translation>
		</message>
		<message>
			<source>lbl_geom3</source>
			<translation>Geom3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom3</source>
			<translation>lbl_geom3</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_index_val</source>
			<translation>Index-Falle:</translation>
		</message>
		<message>
			<source>tooltip_lbl_index_val</source>
			<translation>lbl_index_val</translation>
		</message>
		<message>
			<source>lbl_is_last</source>
			<translation>Ist letzte:</translation>
		</message>
		<message>
			<source>tooltip_lbl_is_last</source>
			<translation>lbl_is_last</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Parameter id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Position id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Positionswert:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Text:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_tstamp</source>
			<translation>T-Stempel:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tstamp</source>
			<translation>lbl_tstamp</translation>
		</message>
		<message>
			<source>lbl_value</source>
			<translation>Wert:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value</source>
			<translation>lbl_value</translation>
		</message>
		<message>
			<source>lbl_value1</source>
			<translation>Wert1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value1</source>
			<translation>lbl_value1</translation>
		</message>
		<message>
			<source>lbl_value2</source>
			<translation>Wert2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value2</source>
			<translation>lbl_value2</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Besuchen Sie id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
		<message>
			<source>lbl_xcoord</source>
			<translation>Xcoord:</translation>
		</message>
		<message>
			<source>tooltip_lbl_xcoord</source>
			<translation>lbl_xcoord</translation>
		</message>
		<message>
			<source>lbl_ycoord</source>
			<translation>Ycoord:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ycoord</source>
			<translation>lbl_ycoord</translation>
		</message>
		<message>
			<source>tab_files</source>
			<translation>Dateien</translation>
		</message>
		<message>
			<source>tooltip_tab_files</source>
			<translation>tab_files</translation>
		</message>
		<message>
			<source>tab_info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>tooltip_tab_info</source>
			<translation>tab_info</translation>
		</message>
	</context>
	<context>
		<name>visit_event_rehab</name>
		<message>
			<source>title</source>
			<translation>Rehabilitation Bogen Ereignis</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_file</source>
			<translation>Datei hinzufügen</translation>
		</message>
		<message>
			<source>tooltip_btn_add_file</source>
			<translation>btn_add_file</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_file</source>
			<translation>Datei löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_file</source>
			<translation>btn_delete_file</translation>
		</message>
		<message>
			<source>dlg_visit_event_rehab</source>
			<translation>Rehabilitation Bogen Ereignis</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event_rehab</source>
			<translation>dlg_visit_event_rehab</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Dateien:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_geom1</source>
			<translation>Geom1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom1</source>
			<translation>lbl_geom1</translation>
		</message>
		<message>
			<source>lbl_geom2</source>
			<translation>Geom2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom2</source>
			<translation>lbl_geom2</translation>
		</message>
		<message>
			<source>lbl_geom3</source>
			<translation>Geom3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom3</source>
			<translation>lbl_geom3</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Parameter id:      </translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Position id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Positionswert:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Text:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_value1</source>
			<translation>Wert1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value1</source>
			<translation>lbl_value1</translation>
		</message>
		<message>
			<source>lbl_value2</source>
			<translation>Wert2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value2</source>
			<translation>lbl_value2</translation>
		</message>
	</context>
	<context>
		<name>visit_gallery</name>
		<message>
			<source>title</source>
			<translation>Galerie</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_next</source>
			<translation>btn_next</translation>
		</message>
		<message>
			<source>tooltip_btn_next</source>
			<translation>btn_next</translation>
		</message>
		<message>
			<source>btn_previous</source>
			<translation>btn_previous</translation>
		</message>
		<message>
			<source>tooltip_btn_previous</source>
			<translation>btn_previous</translation>
		</message>
		<message>
			<source>dlg_visit_gallery</source>
			<translation>Galerie</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_gallery</source>
			<translation>dlg_visit_gallery</translation>
		</message>
		<message>
			<source>lbl_event_id</source>
			<translation>Ereignis-Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_id</source>
			<translation>lbl_event_id</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Besuchen Sie id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_gallery_zoom</name>
		<message>
			<source>title</source>
			<translation>Galerie-Zoom</translation>
		</message>
		<message>
			<source>btn_slideNext</source>
			<translation>btn_slideNext</translation>
		</message>
		<message>
			<source>tooltip_btn_slideNext</source>
			<translation>btn_slideNext</translation>
		</message>
		<message>
			<source>btn_slidePrevious</source>
			<translation>btn_slidePrevious</translation>
		</message>
		<message>
			<source>tooltip_btn_slidePrevious</source>
			<translation>btn_slidePrevious</translation>
		</message>
		<message>
			<source>dlg_visit_gallery_zoom</source>
			<translation>Galerie-Zoom</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_gallery_zoom</source>
			<translation>dlg_visit_gallery_zoom</translation>
		</message>
		<message>
			<source>lbl_event_id</source>
			<translation>Ereignis-Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_id</source>
			<translation>lbl_event_id</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Besuchen Sie id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_manager</name>
		<message>
			<source>title</source>
			<translation>Verwaltung besuchen</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Besuch löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Offener Besuch</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>date_event_from</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_date_event_from</source>
			<translation>date_event_from</translation>
		</message>
		<message>
			<source>date_event_to</source>
			<translation>tt/MM/jjjj</translation>
		</message>
		<message>
			<source>tooltip_date_event_to</source>
			<translation>date_event_to</translation>
		</message>
		<message>
			<source>dlg_visit_manager</source>
			<translation>Verwaltung besuchen</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_manager</source>
			<translation>dlg_visit_manager</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Von:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>lbl_data_event_from</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>An:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>lbl_data_event_to</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Nach Code filtern:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
	</context>
	<context>
		<name>workcat_manager</name>
		<message>
			<source>title</source>
			<translation>Workcat-Verwaltung</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_workcat_manager</source>
			<translation>Workcat-Verwaltung</translation>
		</message>
		<message>
			<source>tooltip_dlg_workcat_manager</source>
			<translation>dlg_workcat_manager</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtern nach: Workcat Name</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>workorder_management</name>
		<message>
			<source>title</source>
			<translation>Workorder Management</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Create Workorder</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_create_wclass</source>
			<translation>Klasse erstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_create_wclass</source>
			<translation>btn_create_wclass</translation>
		</message>
		<message>
			<source>btn_create_wtype</source>
			<translation>Typ erstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_create_wtype</source>
			<translation>btn_create_wtype</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Delete Workorder</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_workorder_management</source>
			<translation>Workorder Management</translation>
		</message>
		<message>
			<source>tooltip_dlg_workorder_management</source>
			<translation>dlg_workorder_management</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Nach Namen filtern:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_column_filter_dates</source>
			<translation>Workorder Type:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter_dates</source>
			<translation>lbl_column_filter_dates</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Arbeitsauftrag Klasse:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
	</context>
	<context>
		<name>workspace_create</name>
		<message>
			<source>title</source>
			<translation>Neuen Arbeitsbereich erstellen</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akzeptieren</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Abbrechen</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_workspace_create</source>
			<translation>Neuen Arbeitsbereich erstellen</translation>
		</message>
		<message>
			<source>tooltip_dlg_workspace_create</source>
			<translation>dlg_workspace_create</translation>
		</message>
		<message>
			<source>lbl_new_workspace</source>
			<translation>Name des Arbeitsbereichs:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace</source>
			<translation>Name des Arbeitsbereichs</translation>
		</message>
		<message>
			<source>lbl_new_workspace_chk</source>
			<translation>Privater Arbeitsbereich:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace_chk</source>
			<translation>lbl_new_workspace_chk</translation>
		</message>
		<message>
			<source>lbl_new_workspace_descript</source>
			<translation>Beschreibung:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace_descript</source>
			<translation>Beschreibung des Arbeitsbereichs</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Info-Protokoll</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
		<message>
			<source>tab_new_workspace</source>
			<translation>Neuen Arbeitsbereich erstellen</translation>
		</message>
		<message>
			<source>tooltip_tab_new_workspace</source>
			<translation>tab_new_workspace</translation>
		</message>
	</context>
	<context>
		<name>workspace_manager</name>
		<message>
			<source>title</source>
			<translation>Arbeitsbereich-Manager</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Schließen Sie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>erstellen.</translation>
		</message>
		<message>
			<source>btn_current</source>
			<translation>Strom einstellen</translation>
		</message>
		<message>
			<source>tooltip_btn_current</source>
			<translation>Den aktuellen Arbeitsbereich festlegen</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Löschen</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Den ausgewählten Arbeitsbereich löschen</translation>
		</message>
		<message>
			<source>btn_toggle_privacy</source>
			<translation>Toggle privacy</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_privacy</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Toggle privacy</translation>
		</message>
		<message>
			<source>dlg_workspace_manager</source>
			<translation>Arbeitsbereich-Manager</translation>
		</message>
		<message>
			<source>tooltip_dlg_workspace_manager</source>
			<translation>dlg_workspace_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_workspace_name</source>
			<translation>Filtern nach: Name des Arbeitsbereichs</translation>
		</message>
		<message>
			<source>tooltip_lbl_workspace_name</source>
			<translation>lbl_workspace_name</translation>
		</message>
	</context>
</TS>
