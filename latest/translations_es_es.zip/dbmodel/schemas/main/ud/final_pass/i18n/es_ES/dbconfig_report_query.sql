/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = SCHEMA_NAME, public, pg_catalog;
UPDATE config_report AS t SET query_text = v.text FROM (
	VALUES
	(100, 'SELECT name as "Explotación", arccat_id as "Catálogo de arcos", sum(gis_length) as "Longitud" FROM ve_arc JOIN exploitation USING (expl_id) GROUP BY arccat_id, name')
) AS v(id, text)
WHERE t.id = v.id;

UPDATE config_report AS t SET query_text = v.text FROM (
	VALUES
	(101, 'SELECT e.name as "Exploitation", vec.connec_id as "ID de Connexión", vec.code as "Código", vec.customer_code as "Código del cliente" FROM ve_connec vec JOIN exploitation e USING (expl_id) ')
) AS v(id, text)
WHERE t.id = v.id;

UPDATE config_report AS t SET query_text = v.text FROM (
	VALUES
	(101, 'SELECT e.name as "Explotación", vec.connec_id, vec.code, vec.customer_code FROM ve_connec vec JOIN exploitation e USING (expl_id) ')
) AS v(id, text)
WHERE t.id = v.id;

UPDATE config_report AS t SET query_text = v.text FROM (
	VALUES
	(105, 'SELECT name as "Explotación", node_type as "Tipo de nodo", count(*) as "Unidades" FROM ve_node JOIN exploitation USING (expl_id) GROUP BY node_type, name')
) AS v(id, text)
WHERE t.id = v.id;