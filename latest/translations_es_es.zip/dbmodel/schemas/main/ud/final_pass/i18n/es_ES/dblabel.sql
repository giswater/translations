/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = SCHEMA_NAME, public, pg_catalog;
UPDATE sys_label AS t SET idval = v.idval FROM (
	VALUES
	(1001, 'INFO'),
    (1002, 'ADVERTENCIA'),
    (1003, 'ERROR'),
    (1004, 'ERRORES CRÍTICOS'),
    (1005, 'CONSEJO'),
    (2000, ' '),
    (2007, '-------'),
    (2008, '--------'),
    (2009, '---------'),
    (2010, '----------'),
    (2011, '-----------'),
    (2014, '--------------'),
    (2022, '----------------------'),
    (2025, '-------------------------'),
    (2030, '------------------------------'),
    (2049, '-------------------------------------------------'),
    (3001, 'INFO'),
    (3002, 'ADVERTENCIAS'),
    (3003, 'ERRORES'),
    (3006, 'DIVIDIR ARCO = TRUE'),
    (3008, 'DIVIDIR ARCO = FALSE'),
    (3009, 'REANUDAR'),
    (3010, 'SISTEMA DE CONTROL'),
    (3011, 'COMPROBAR DATOS DE BASE DE DATOS'),
    (3012, 'DETALLES'),
    (4001, 'Datos principales'),
    (4002, 'Datos adicionales'),
    (4003, 'Datos'),
    (4004, 'Dscenario')
) AS v(id, idval)
WHERE t.id = v.id;