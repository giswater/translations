<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es_es">
<!-- TOOLBARS AND ACTIONS -->
	<context>
		<name>giswater</name>
		<message>
			<source>18_text</source>
			<translation>Conexión con comercial</translation>
		</message>
		<message>
			<source>19_text</source>
			<translation>Caja de herramientas</translation>
		</message>
		<message>
			<source>24_text</source>
			<translation>Ir a EPA express</translation>
		</message>
		<message>
			<source>301_text</source>
			<translation>Planificador anual</translation>
		</message>
		<message>
			<source>302_text</source>
			<translation>Planificador mensual</translation>
		</message>
		<message>
			<source>303_text</source>
			<translation>Generador de precios</translation>
		</message>
		<message>
			<source>304_text</source>
			<translation>Añadir visita</translation>
		</message>
		<message>
			<source>305_text</source>
			<translation>Planificador unitario</translation>
		</message>
		<message>
			<source>309_text</source>
			<translation>Gestor de incidencias</translation>
		</message>
		<message>
			<source>36_text</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>38_text</source>
			<translation>Nuevo coste de la red</translation>
		</message>
		<message>
			<source>47_text</source>
			<translation>Selector de sectores de planificación</translation>
		</message>
		<message>
			<source>74_text</source>
			<translation>Añadir nuevo lote</translation>
		</message>
		<message>
			<source>75_text</source>
			<translation>Gestor de lotes</translation>
		</message>
		<message>
			<source>76_text</source>
			<translation>Filtro de lotes</translation>
		</message>
		<message>
			<source>81_text</source>
			<translation>Nuevo sector de planificación O&amp;amp;M</translation>
		</message>
		<message>
			<source>82_text</source>
			<translation>Gestor de sectores de planificación O&amp;amp;M</translation>
		</message>
		<message>
			<source>98_text</source>
			<translation>Editor de configuración</translation>
		</message>
		<message>
			<source>Actions</source>
			<translation>Acciones</translation>
		</message>
		<message>
			<source>Add drain GPKG project</source>
			<translation>Agregar proyecto de drenaje GPKG</translation>
		</message>
		<message>
			<source>Additional demand check</source>
			<translation>Verificación de demanda adicional</translation>
		</message>
		<message>
			<source>Advanced</source>
			<translation>Avanzado</translation>
		</message>
		<message>
			<source>AmBreakage</source>
			<translation>Herramienta de administración</translation>
		</message>
		<message>
			<source>AmPriority</source>
			<translation>Cálculo de prioridades y selección</translation>
		</message>
		<message>
			<source>Analytics</source>
			<translation>Analítica</translation>
		</message>
		<message>
			<source>ARC</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>Breakdown Assignation</source>
			<translation>Asignación de fugas</translation>
		</message>
		<message>
			<source>Calibration</source>
			<translation>Calibración</translation>
		</message>
		<message>
			<source>Closest arcs</source>
			<translation>Arcos más cercanos</translation>
		</message>
		<message>
			<source>CONNEC</source>
			<translation>Acometida</translation>
		</message>
		<message>
			<source>DRAG-DROP</source>
			<translation>Arrastrar y soltar</translation>
		</message>
		<message>
			<source>Dscenario</source>
			<translation>Escenarios dinámicos</translation>
		</message>
		<message>
			<source>DWF scenario</source>
			<translation>Escenarios DWF</translation>
		</message>
		<message>
			<source>Emitter calibration</source>
			<translation>Calibración del emisor</translation>
		</message>
		<message>
			<source>EPA multi calls</source>
			<translation>Llamadas múltiples de EPA</translation>
		</message>
		<message>
			<source>Export</source>
			<translation>Exportar</translation>
		</message>
		<message>
			<source>Fast print</source>
			<translation>Impresión rápida</translation>
		</message>
		<message>
			<source>Forced arcs</source>
			<translation>Arcos forzados</translation>
		</message>
		<message>
			<source>Forced arcs (selecting only arcs)</source>
			<translation>Arcos forzados (seleccionar sólo arcos)</translation>
		</message>
		<message>
			<source>Get help</source>
			<translation>Ayuda</translation>
		</message>
		<message>
			<source>Go2IBER</source>
			<translation>Ir a IBER</translation>
		</message>
		<message>
			<source>GULLY</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>GwAddCampaignButton</source>
			<translation>Añadir Camapaña</translation>
		</message>
		<message>
			<source>GwAddChildLayerButton</source>
			<translation>Cargar capa Giswater</translation>
		</message>
		<message>
			<source>GwAddLotButton</source>
			<translation>Añadir Lote</translation>
		</message>
		<message>
			<source>GwAmBreakageButton</source>
			<translation>Herramienta de administración</translation>
		</message>
		<message>
			<source>GwAmPriorityButton</source>
			<translation>Cálculo de prioridad por selección</translation>
		</message>
		<message>
			<source>GwArcAddButton</source>
			<translation>Insertar arco</translation>
		</message>
		<message>
			<source>GwArcDivideButton</source>
			<translation>Dividir arco</translation>
		</message>
		<message>
			<source>GwArcFusionButton</source>
			<translation>Fusionar arco</translation>
		</message>
		<message>
			<source>GwAuxCircleAddButton</source>
			<translation>Crear círculo</translation>
		</message>
		<message>
			<source>GwAuxPointAddButton</source>
			<translation>Crear punto</translation>
		</message>
		<message>
			<source>GwConfigButton</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>GwConnectLinkButton</source>
			<translation>Conectar a la red</translation>
		</message>
		<message>
			<source>GwCSVButton</source>
			<translation>Importar CSV</translation>
		</message>
		<message>
			<source>GwDateSelectorButton</source>
			<translation>Selector de fecha</translation>
		</message>
		<message>
			<source>GwDimensioningButton</source>
			<translation>Acotaciones</translation>
		</message>
		<message>
			<source>GwDocumentButton</source>
			<translation>Añadir documento</translation>
		</message>
		<message>
			<source>GwDocumentManagerButton</source>
			<translation>Gestor de documentos</translation>
		</message>
		<message>
			<source>GwDscenarioManagerButton</source>
			<translation>Gestor de escenarios dinámicos</translation>
		</message>
		<message>
			<source>GwElementButton</source>
			<translation>Añadir elemento</translation>
		</message>
		<message>
			<source>GwElementManagerButton</source>
			<translation>Gestor de elementos</translation>
		</message>
		<message>
			<source>GwEpaTools</source>
			<translation>Herramientas de EPA</translation>
		</message>
		<message>
			<source>GwFeatureDeleteButton</source>
			<translation>Eliminar objeto de red</translation>
		</message>
		<message>
			<source>GwFeatureEndButton</source>
			<translation>Dar de baja</translation>
		</message>
		<message>
			<source>GwFeatureReplaceButton</source>
			<translation>Reemplazar objeto</translation>
		</message>
		<message>
			<source>GwFeatureTypeChangeButton</source>
			<translation>Cambiar tipo de objeto</translation>
		</message>
		<message>
			<source>GwFlowExitButton</source>
			<translation>Salida de flujo</translation>
		</message>
		<message>
			<source>GwFlowTraceButton</source>
			<translation>Rastreo de flujo</translation>
		</message>
		<message>
			<source>GwGo2EpaButton</source>
			<translation>Ir a EPA</translation>
		</message>
		<message>
			<source>GwGo2EpaManagerButton</source>
			<translation>Gestor de resultados EPA</translation>
		</message>
		<message>
			<source>GwGo2EpaSelectorButton</source>
			<translation>Selector de resultados EPA</translation>
		</message>
		<message>
			<source>GwInfoButton</source>
			<translation>Info Giswater</translation>
		</message>
		<message>
			<source>GwLayerStyleChangeButton</source>
			<translation>Estilos Giswater</translation>
		</message>
		<message>
			<source>GwLotResourceManagementButton</source>
			<translation>Gestor de recursos de lote</translation>
		</message>
		<message>
			<source>GwManageCampaignLotButton</source>
			<translation>Gestor de lotes de campaña</translation>
		</message>
		<message>
			<source>GwMincutButton</source>
			<translation>Nuevo polígono de corte</translation>
		</message>
		<message>
			<source>GwMincutManagerButton</source>
			<translation>Gestor de polígonos de corte</translation>
		</message>
		<message>
			<source>GwNetscenarioManagerButton</source>
			<translation>Gestor de netscenarios</translation>
		</message>
		<message>
			<source>GwNonVisualManagerButton</source>
			<translation>Gestor de objetos no visuales</translation>
		</message>
		<message>
			<source>GwPointAddButton</source>
			<translation>Insertar punto</translation>
		</message>
		<message>
			<source>GwPriceManagerButton</source>
			<translation>Gestionar coste de la red</translation>
		</message>
		<message>
			<source>GwPrintButton</source>
			<translation>Impresión</translation>
		</message>
		<message>
			<source>GwProfileButton</source>
			<translation>Herramienta de perfil</translation>
		</message>
		<message>
			<source>GwProjectCheckButton</source>
			<translation>Verificar proyecto</translation>
		</message>
		<message>
			<source>GwPsectorButton</source>
			<translation>Nuevo sector de planificaciones</translation>
		</message>
		<message>
			<source>GwPsectorManagerButton</source>
			<translation>Gestor de sectores de planificación</translation>
		</message>
		<message>
			<source>GwResultManagerButton</source>
			<translation>Gestor de resultados</translation>
		</message>
		<message>
			<source>GwResultSelectorButton</source>
			<translation>Selector de resultados</translation>
		</message>
		<message>
			<source>GwSearchButton</source>
			<translation>Buscador</translation>
		</message>
		<message>
			<source>GwSelectorButton</source>
			<translation>Selectores</translation>
		</message>
		<message>
			<source>GwSnapshotViewButton</source>
			<translation>Captura de la red</translation>
		</message>
		<message>
			<source>GwToolBoxButton</source>
			<translation>Caja de herramientas</translation>
		</message>
		<message>
			<source>GwUtilsManagerButton</source>
			<translation>Gestor de utilidades</translation>
		</message>
		<message>
			<source>GwVisitButton</source>
			<translation>Añadir visita</translation>
		</message>
		<message>
			<source>GwVisitManagerButton</source>
			<translation>Gestor de visitas</translation>
		</message>
		<message>
			<source>GwWorkspaceManagerButton</source>
			<translation>Espacios de trabajo</translation>
		</message>
		<message>
			<source>Hydrology scenario</source>
			<translation>Escenarios hidrológicos</translation>
		</message>
		<message>
			<source>Import</source>
			<translation>Importar</translation>
		</message>
		<message>
			<source>Import CSV</source>
			<translation>Importar CSV</translation>
		</message>
		<message>
			<source>Import INP file</source>
			<translation>Importar archivo INP</translation>
		</message>
		<message>
			<source>Manage Campaign</source>
			<translation>Gestor de campaña</translation>
		</message>
		<message>
			<source>Manage Campaign</source>
			<translation>Gestor de campañas</translation>
		</message>
		<message>
			<source>Manage Lot</source>
			<translation>Gestor de lote</translation>
		</message>
		<message>
			<source>Manage Lot</source>
			<translation>Gestion de lotes</translation>
		</message>
		<message>
			<source>Manage Workorder</source>
			<translation>Gestor de ordenes de trabajo</translation>
		</message>
		<message>
			<source>Mapzones manager</source>
			<translation>Gestor de Mapzones</translation>
		</message>
		<message>
			<source>Massive composer</source>
			<translation>Composer masivo</translation>
		</message>
		<message>
			<source>menu_name</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>Multi psector print</source>
			<translation>Impresión de multi psector</translation>
		</message>
		<message>
			<source>NODE</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>Open plugin folder</source>
			<translation>Abrir carpeta del plugin</translation>
		</message>
		<message>
			<source>Open user folder</source>
			<translation>Abrir carpeta de usuario</translation>
		</message>
		<message>
			<source>Priority Calculation (Global)</source>
			<translation>Cálculo de prioridad (Global)</translation>
		</message>
		<message>
			<source>Quantized demands</source>
			<translation>Demandas cuantizadas</translation>
		</message>
		<message>
			<source>Reset dialogs</source>
			<translation>Reiniciar dialogos</translation>
		</message>
		<message>
			<source>Reset plugin</source>
			<translation>Reiniciar plugin</translation>
		</message>
		<message>
			<source>ResultManager</source>
			<translation>Gestor de resultados</translation>
		</message>
		<message>
			<source>ResultSelector</source>
			<translation>Selector de resultados</translation>
		</message>
		<message>
			<source>Review</source>
			<translation>Revisar</translation>
		</message>
		<message>
			<source>SELECT</source>
			<translation>Seleccionar</translation>
		</message>
		<message>
			<source>Show current selectors</source>
			<translation>Mostrar selectores actuales</translation>
		</message>
		<message>
			<source>Static calibration</source>
			<translation>Calibración estática</translation>
		</message>
		<message>
			<source>Style manager</source>
			<translation>Gestor de estilos</translation>
		</message>
		<message>
			<source>Toggle Log DB</source>
			<translation>Activar/Desactivar registros de BD</translation>
		</message>
		<message>
			<source>toolbar_am_name</source>
			<translation>Giswater - Asset Manager</translation>
		</message>
		<message>
			<source>toolbar_basic_name</source>
			<translation>Giswater - Basic</translation>
		</message>
		<message>
			<source>toolbar_cm_name</source>
			<translation>Giswater - Gestor de Campañas</translation>
		</message>
		<message>
			<source>toolbar_custom_name</source>
			<translation>Giswater - Custom</translation>
		</message>
		<message>
			<source>toolbar_edit_name</source>
			<translation>Giswater - Edit</translation>
		</message>
		<message>
			<source>toolbar_epa_name</source>
			<translation>Giswater - Epa</translation>
		</message>
		<message>
			<source>toolbar_om_name</source>
			<translation>Giswater - O&amp;M</translation>
		</message>
		<message>
			<source>toolbar_plan_name</source>
			<translation>Giswater - Masterplan</translation>
		</message>
		<message>
			<source>toolbar_utilities_name</source>
			<translation>Giswater - Utilidades</translation>
		</message>
		<message>
			<source>Valve operation check</source>
			<translation>Comprobación del funcionamiento de la válvula</translation>
		</message>
		<message>
			<source>Visit</source>
			<translation>Visita</translation>
		</message>
		<message>
			<source>Workcat manager</source>
			<translation>Gestor de Workcat</translation>
		</message>
	</context>
<!-- PYTHON MESSAGES -->
	<context>
		<name>giswater</name>
		<message>
			<source></source>
			<translation></translation>
		</message>
		<message>
			<source> </source>
			<translation> </translation>
		</message>
		<message>
			<source>, </source>
			<translation>,</translation>
		</message>
		<message>
			<source>{0}</source>
			<translation>{0}</translation>
		</message>
		<message>
			<source>{0} --&gt; {1}</source>
			<translation>{0} --&gt; {1}</translation>
		</message>
		<message>
			<source>{0}: {1}</source>
			<translation>{0}: {1}</translation>
		</message>
		<message>
			<source>{0} --&gt; {1} --&gt; {2}</source>
			<translation>{0} --&gt; {1} --&gt; {2}</translation>
		</message>
		<message>
			<source>{0}: {1} Python function: tools_gw.set_widgets. WHERE columname=&apos;{2}&apos; AND widgetname=&apos;{3}&apos; AND widgettype=&apos;{4}&apos;</source>
			<translation>{0}: {1} Función Python: tools_gw.set_widgets. WHERE columname=&apos;{2}&apos; AND widgetname=&apos;{3}&apos; AND widgettype=&apos;{4}&apos;</translation>
		</message>
		<message>
			<source>{0}: {1}. widgetname=&apos;{2}&apos; AND widgettype=&apos;{3}&apos;</source>
			<translation>{0}: {1}. widgetname=&apos;{2}&apos; AND widgettype=&apos;{3}&apos;</translation>
		</message>
		<message>
			<source>{0} callback raised: {1}</source>
			<translation>Callback {0} generó: {1}</translation>
		</message>
		<message>
			<source>{0} campaign(s) deleted.</source>
			<translation>{0} campaña(s) eliminada(s).</translation>
		</message>
		<message>
			<source>{0}: Config file is not set</source>
			<translation>{0}: El archivo de configuración no está configurado</translation>
		</message>
		<message>
			<source>{0}: Database translation canceled.</source>
			<translation>{0}: Traducción de Base de datos cancelada.</translation>
		</message>
		<message>
			<source>{0}: Database translation failed.</source>
			<translation>{0}: Traducción de la Base de datos fallida.</translation>
		</message>
		<message>
			<source>{0}: Database translation successful to {1}.</source>
			<translation>{0}: Traducción de la Base de datos exitosa a {1}.</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; does not exist. Please select a valid config file.</source>
			<translation>&quot;{0}&quot; no existe. Por favor seleccione un archivo de configuración válido.</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; does not exist. Please select a valid folder.</source>
			<translation>&quot;{0}&quot; no existe. Por favor seleccione una carpeta válida.</translation>
		</message>
		<message>
			<source>{0} error {1}</source>
			<translation>{0} error {1}</translation>
		</message>
		<message>
			<source>{0} error: {1}</source>
			<translation>{0} error: {1}</translation>
		</message>
		<message>
			<source>{0}: Errors: {1}</source>
			<translation>{0}: Errores: {1}</translation>
		</message>
		<message>
			<source>{0} exception: {1}</source>
			<translation>{0} excepción: {1}</translation>
		</message>
		<message>
			<source>{0} Exception: {1}</source>
			<translation>{0} Excepción: {1}</translation>
		</message>
		<message>
			<source>{0} exception [{1}]: {2}</source>
			<translation>{0} excepción [{1}]: {2}</translation>
		</message>
		<message>
			<source>{0} failed.</source>
			<translation>{0} falló.</translation>
		</message>
		<message>
			<source>{0}: Failed to update Multilang language preference: {1}</source>
			<translation>{0}: Error al actualizar la preferencia de idioma Multilang: {1}</translation>
		</message>
		<message>
			<source>{0} id:</source>
			<translation>{0} id:</translation>
		</message>
		<message>
			<source>{0} ID is missing.</source>
			<translation>Falta el ID de {0}.</translation>
		</message>
		<message>
			<source>{0} is not a table name or {1}</source>
			<translation>{0} no es un nombre de tabla o {1}</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; is not a valid calibration_mode.</source>
			<translation>&quot;{0}&quot; no es un calibration_mode válido.</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; is not a valid target_parameter.</source>
			<translation>&quot;{0}&quot; no es un target_parameter válido.</translation>
		</message>
		<message>
			<source>{0} item(s) removed from the list: {1}</source>
			<translation>{0} elemento(s) eliminados de la lista: {1}</translation>
		</message>
		<message>
			<source>{0} lot(s) deleted.</source>
			<translation>{0} lote(s) eliminado(s).</translation>
		</message>
		<message>
			<source>{0}: Multilang language preference updated to {1}.</source>
			<translation>{0}: Preferencia de idioma Multilang actualizada a {1}.</translation>
		</message>
		<message>
			<source>{0} must contain {1} line{2}.</source>
			<translation>{0} debe contener {1} línea{2}.</translation>
		</message>
		<message>
			<source>{0} must contain just one line.</source>
			<translation>{0} debe contener solo una línea.</translation>
		</message>
		<message>
			<source>{0} not found in {1} scenario.</source>
			<translation>{0} no encontrado en el escenario {1}.</translation>
		</message>
		<message>
			<source>{0} not found in [OPTIONS] section.</source>
			<translation>{0} no encontrado en la sección [OPTIONS].</translation>
		</message>
		<message>
			<source>{0}: project type &apos;{1}&apos; not supported</source>
			<translation>{0}: no se admite el tipo de proyecto &apos;{1}</translation>
		</message>
		<message>
			<source>{0}: Reference {1} = &apos;{2}&apos; it is not managed</source>
			<translation>{0}: Referencia {1} = &apos;{2}&apos; no se gestiona</translation>
		</message>
		<message>
			<source>{0}: Refusing to write invalid user_params.config [{1}]: {2}</source>
			<translation>{0}: Negándose a escribir user_params.config inválido [{1}]: {2}</translation>
		</message>
		<message>
			<source>{0}: Refusing to write plugin user_params.config while GwDevMode is enabled</source>
			<translation>{0}: Negándose a escribir plugin user_params.config mientras GwDevMode está habilitado</translation>
		</message>
		<message>
			<source>{0}.sql: {1}</source>
			<translation>{0}.sql: {1}</translation>
		</message>
		<message>
			<source>{0} successfully saved.</source>
			<translation>{0} guardado con éxito.</translation>
		</message>
		<message>
			<source>{0} task is already active!</source>
			<translation>{0} ¡la tarea ya está activa!</translation>
		</message>
		<message>
			<source>{0}: unsupported type {1}</source>
			<translation>{0}: tipo no soportado {1}</translation>
		</message>
		<message>
			<source>{0}: widget not found</source>
			<translation>{0}: widget no encontrado</translation>
		</message>
		<message>
			<source>{0} workorder(s) deleted.</source>
			<translation>{0} orden(es) de trabajo eliminada(s).</translation>
		</message>
		<message>
			<source>Accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>Action has no function!!</source>
			<translation>¡¡La acción no tiene función!!</translation>
		</message>
		<message>
			<source>Activate water netowrk snapshot</source>
			<translation>Activar instantánea de red de agua</translation>
		</message>
		<message>
			<source>Active</source>
			<translation>Activo</translation>
		</message>
		<message>
			<source>Adapt schema to cibs</source>
			<translation>Adaptar esquema a cibs</translation>
		</message>
		<message>
			<source>Add document</source>
			<translation>Añadir documento</translation>
		</message>
		<message>
			<source>Add translator ({0})</source>
			<translation>Añadir traductor ({0})</translation>
		</message>
		<message>
			<source>A diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.</source>
			<translation>Un valor de diámetro se considera inválido si es cero, negativo, NULL o mayor que el diámetro máximo de la tabla de configuración. Como resultado, a estas tuberías NO se les asignará un valor de prioridad.</translation>
		</message>
		<message>
			<source>Advanced Menu</source>
			<translation>Menú avanzado</translation>
		</message>
		<message>
			<source>Alert</source>
			<translation>Alerta</translation>
		</message>
		<message>
			<source>ALL</source>
			<translation>ALL</translation>
		</message>
		<message>
			<source>

ALL DONE! INP successfully imported.</source>
			<translation>¡TODO LISTO! INP importado correctamente.</translation>
		</message>
		<message>
			<source>ALL DONE! INP successfully imported.</source>
			<translation>¡TODO LISTO! INP importado correctamente.</translation>
		</message>
		<message>
			<source>All layers have been successfully refreshed.</source>
			<translation>Todas las capas se han actualizado correctamente.</translation>
		</message>
		<message>
			<source>All the values in the column &apos;atlas_id&apos; from the table &apos;plan_psector&apos; have to be INTEGER. This is not the case for your table, please fix this before continuing.</source>
			<translation>Todos los valores de la columna &apos;atlas_id&apos; de la tabla &apos;plan_psector&apos; tienen que ser INTEGER. Este no es el caso de su tabla, por favor corrija esto antes de continuar.</translation>
		</message>
		<message>
			<source>A material is considered invalid if it is not listed in the material configuration table.</source>
			<translation>Se considera que un material no es válido si no se encuentra en la tabla de configuración de materiales.</translation>
		</message>
		<message>
			<source>An arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.</source>
			<translation>Se considera que un arccat_id no es válido si no aparece en la tabla de configuración del catálogo. Como resultado, a estas tuberías NO se les asignará un valor de prioridad.</translation>
		</message>
		<message>
			<source>An error occurred saving the workorder.</source>
			<translation>Ocurrió un error guardando la orden de trabajo.</translation>
		</message>
		<message>
			<source>An error occurred while adding the style for layer &apos;{0}&apos;:
{1}</source>
			<translation>Ocurrió un error al agregar el estilo para la capa &apos;{0}&apos;:
{1}</translation>
		</message>
		<message>
			<source>A new style has been added to &apos;{0}&apos; for the layer &apos;{1}&apos; using the &apos;GwBasic&apos; style information.
You can change it and use &apos;Update Style&apos; to create a personalized version.</source>
			<translation>Se ha agregado un nuevo estilo a &apos;{0}&apos; para la capa &apos;{1}&apos; usando la información de estilo &apos;GwBasic&apos;.
Puede cambiarlo y usar &apos;Actualizar Estilo&apos; para crear una versión personalizada.</translation>
		</message>
		<message>
			<source>Any connec_id found with this customer_code</source>
			<translation>Cualquier connec_id encontrado con este customer_code</translation>
		</message>
		<message>
			<source>Any document selected</source>
			<translation>Cualquier documento seleccionado</translation>
		</message>
		<message>
			<source>Any record found</source>
			<translation>Cualquier registro encontrado</translation>
		</message>
		<message>
			<source>Any record selected</source>
			<translation>Ningún registro seleccionado</translation>
		</message>
		<message>
			<source>Applied styles for context</source>
			<translation>Estilos aplicados al contexto</translation>
		</message>
		<message>
			<source>Apply Multilang translation ({0}) to schema ({1})?</source>
			<translation>¿Aplicar traducción Multilenguaje ({0}) al esquema ({1})?</translation>
		</message>
		<message>
			<source>Apply to Multilang</source>
			<translation>Aplicar a Multilang</translation>
		</message>
		<message>
			<source>Apply translation ({0}) to schema ({1}) using local SQL files?</source>
			<translation>¿Aplicar traducción ({0}) al esquema ({1}) usando archivos SQL locales?</translation>
		</message>
		<message>
			<source>Arc already selected</source>
			<translation>Arco ya seleccionado</translation>
		</message>
		<message>
			<source>Arc catalog</source>
			<translation>Catálogo de arcos</translation>
		</message>
		<message>
			<source>Arc fusion</source>
			<translation>Fusionar arco</translation>
		</message>
		<message>
			<source>Arc layer not found. Cannot start inundation from arc.</source>
			<translation>Capa de arco no encontrada. No se puede iniciar inundación desde arco.</translation>
		</message>
		<message>
			<source>Arcs</source>
			<translation>Arcos</translation>
		</message>
		<message>
			<source>Are you sure to execute vacuum on selected schema?</source>
			<translation>¿Está seguro de ejecutar el vacío en el esquema seleccionado?</translation>
		</message>
		<message>
			<source>Are you sure to save this feature?</source>
			<translation>¿Está seguro de Guardar este Elemento?</translation>
		</message>
		<message>
			<source>Are you sure to update the project schema to last version?</source>
			<translation>¿Está seguro de actualizar el esquema del proyecto a la última versión?</translation>
		</message>
		<message>
			<source>Are you sure you want delete schema &apos;{0}&apos;?</source>
			<translation>¿Está seguro de que desea eliminar el esquema &apos;{0}&apos;?</translation>
		</message>
		<message>
			<source>Are you sure you want to assign team &apos;{0}&apos; to {1} selected user(s)?</source>
			<translation>¿Está seguro de que desea asignar el equipo &apos;{0}&apos; a {1} usuario(s) seleccionado(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to cancel these mincuts?</source>
			<translation>¿Está seguro de que desea cancelar estos polígonos de corte?</translation>
		</message>
		<message>
			<source>Are you sure you want to change to team &apos;{0}&apos; for {1} selected user(s)?</source>
			<translation>¿Está seguro de que desea cambiar al equipo &apos;{0}&apos; para {1} usuario(s) seleccionado(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} campaign(s)?</source>
			<translation>¿Está seguro de que desea eliminar {0} campaña(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} lot(s)?</source>
			<translation>¿Está seguro de que desea eliminar {0} lote(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} workorder(s)?</source>
			<translation>¿Está seguro de que desea eliminar {0} orden(es) de trabajo?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the selected styles?</source>
			<translation>¿Está seguro de que quiere borrar los estilos seleccionados?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these mincuts?</source>
			<translation>¿Está seguro de querer eliminar estos polígonos de corte?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records:</source>
			<translation>¿Está seguro de que desea eliminar estos registros?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records?</source>
			<translation>¿Está seguro de que desea eliminar estos registros?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records: ({0})?</source>
			<translation>¿Está seguro de que desea eliminar estos registros: ({0})?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records: ({0})?
This will also delete the database user(s): {1}</source>
			<translation>¿Está seguro de que desea eliminar estos registros: ({0})?
Esto también eliminará el/los usuario(s) de la Base de datos: {1}</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records?
Some events have documents</source>
			<translation>¿Está seguro de que desea eliminar estos registros?
Algunos eventos tienen documentos</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the style group &apos;{0}&apos;?

This will also delete all related entries in the sys_style table.Confirm Cascade Delete</source>
			<translation>¿Está seguro de que desea eliminar el grupo de estilos &apos;{0}&apos;?

Esto también eliminará todas las entradas relacionadas en la tabla sys_style.Confirmar Eliminación en Cascada</translation>
		</message>
		<message>
			<source>Are you sure you want to disconnect this elements?</source>
			<translation>¿Seguro que quiere desconectar estos elementos?</translation>
		</message>
		<message>
			<source>Are you sure you want to override the configuration of this workspace?</source>
			<translation>¿Está seguro de que desea anular la configuración de este espacio de trabajo?</translation>
		</message>
		<message>
			<source>Are you sure you want to overwrite this file?</source>
			<translation>¿Está seguro de que quiere sobrescribir este archivo?</translation>
		</message>
		<message>
			<source>Are you sure you want to remove team assignment from {0} selected user(s)?</source>
			<translation>¿Está seguro de que desea quitar la asignación de equipo de {0} usuario(s) seleccionados?</translation>
		</message>
		<message>
			<source>Are you sure you want to replace selected feature with a new one?</source>
			<translation>¿Está seguro de que desea reemplazar el elemento de red seleccionado por uno de nuevo?</translation>
		</message>
		<message>
			<source>Are you sure you want to replace selected feature with a new one?
If you have different addfields in your feature, they will be deleted.</source>
			<translation>¿Está seguro de que desea reemplazar el elemento seleccionado por uno nuevo?
Si tiene addfields diferentes en su Elemento, serán eliminados.</translation>
		</message>
		<message>
			<source>Are you sure you want to update the style of {0} ({1}) with the symbology of the layer in the project? 
You are going to lose previous information!</source>
			<translation>¿Está seguro de que desea actualizar el estilo de {0} ({1}) con la simbología de la capa en el Proyecto?
¡Va a perder la información previa!</translation>
		</message>
		<message>
			<source>A rollback on schema will be done.</source>
			<translation>Se realizará un retroceso del esquema.</translation>
		</message>
		<message>
			<source>As a result, the material of these pipes will be treated as the configured unknown material, {0}.</source>
			<translation>Como resultado, el material de estas tuberías se tratará como el material desconocido configurado, {0}.</translation>
		</message>
		<message>
			<source>A scenario cannot be named &apos;base&apos;.</source>
			<translation>Un escenario no puede llamarse &apos;base&apos;.</translation>
		</message>
		<message>
			<source>Assign Team</source>
			<translation>Asignar Equipo</translation>
		</message>
		<message>
			<source>A style already exists for the layer &apos;{0}&apos; in the selected style group.</source>
			<translation>Ya existe un estilo para la capa &apos;{0}&apos; en el grupo de estilos seleccionado.</translation>
		</message>
		<message>
			<source>Atlas ID must be an integer.</source>
			<translation>El ID de Atlas debe ser un entero.</translation>
		</message>
		<message>
			<source>Automatic language provisioning failed: {0}</source>
			<translation>Provisionamiento automático de idioma falló: {0}</translation>
		</message>
		<message>
			<source>Automatic language provisioning failed to start: {0}</source>
			<translation>La provisión automática de idioma no pudo iniciarse: {0}</translation>
		</message>
		<message>
			<source>Automatic language provisioning timed out after {0} seconds</source>
			<translation>La provisión automática de idiomas caducó después de {0} segundos</translation>
		</message>
		<message>
			<source>&lt;b&gt;Key: &lt;/b&gt;{0}&lt;br&gt;&lt;b&gt;Key container: &lt;/b&gt;body/data/ &lt;br&gt;&lt;b&gt;Python file: &lt;/b&gt;{1} &lt;br&gt;&lt;b&gt;Python function:&lt;/b&gt; {2} &lt;br&gt;</source>
			<translation>&lt;b&gt;Clave: &lt;/b&gt;{0}&lt;br&gt;&lt;b&gt;Contenedor de clave: &lt;/b&gt;body/data/ &lt;br&gt;&lt;b&gt;Archivo Python: &lt;/b&gt;{1} &lt;br&gt;&lt;b&gt;Función Python:&lt;/b&gt; {2} &lt;br&gt;</translation>
		</message>
		<message>
			<source>Breakdown Assignation</source>
			<translation>Asignación de Averías</translation>
		</message>
		<message>
			<source>Calculating values</source>
			<translation>Calculando valores</translation>
		</message>
		<message>
			<source>Campaign</source>
			<translation>Campaña</translation>
		</message>
		<message>
			<source>Campaign ID not found.</source>
			<translation>No se ha encontrado el ID de la campaña.</translation>
		</message>
		<message>
			<source>Campaign saved successfully</source>
			<translation>Campaña guardada correctamente</translation>
		</message>
		<message>
			<source>Cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>Canceling task...</source>
			<translation>Cancelando tarea...</translation>
		</message>
		<message>
			<source>Cancelled ({0}/{1})</source>
			<translation>Cancelado ({0}/{1})</translation>
		</message>
		<message>
			<source>Cancelling...</source>
			<translation>Cancelando...</translation>
		</message>
		<message>
			<source>Cancel mincut</source>
			<translation>Cancelar mincut</translation>
		</message>
		<message>
			<source>Cancel mincuts</source>
			<translation>Cancelar cortes de red.</translation>
		</message>
		<message>
			<source>Cannot calibrate {0} ({1}).</source>
			<translation>No se puede calibrar {0} ({1}).</translation>
		</message>
		<message>
			<source>Cannot create file, check if its open</source>
			<translation>No se puede crear el archivo, verifique si está abierto</translation>
		</message>
		<message>
			<source>Cannot create file, check if selected composer is the correct composer</source>
			<translation>No se puede crear el archivo, verifique si el compositor seleccionado es el compositor correcto</translation>
		</message>
		<message>
			<source>Cannot create file, check if selected giswater_advancedtools is the correct giswater_advancedtools</source>
			<translation>No se puede crear el archivo, compruebe si el giswater_advancedtools seleccionado es el giswater_advancedtools correcto</translation>
		</message>
		<message>
			<source>Cannot delete the current scenario. Please set another scenario as current first.</source>
			<translation>No se puede eliminar el escenario actual. Por favor, primero establezca otro escenario como actual.</translation>
		</message>
		<message>
			<source>Cannot duplicate archived psector {0}. Please unarchive it first.</source>
			<translation>No se puede duplicar el psector archivado {0}. Por favor, desarchívelo primero.</translation>
		</message>
		<message>
			<source>Cannot force connection to a node while arcs are selected.</source>
			<translation>No se puede forzar la conexión a un nodo mientras haya arcos seleccionados.</translation>
		</message>
		<message>
			<source>Cannot merge archived psector {0}. Please unarchive it first.</source>
			<translation>No se puede fusionar psector archivado {0}. Por favor, desarchívelo primero.</translation>
		</message>
		<message>
			<source>Cannot set inactive a current scenario. Please update current first.</source>
			<translation>No se puede inactivar un escenario actual. Por favor, actualice primero el actual.</translation>
		</message>
		<message>
			<source>Cannot set the active state of archived psector {0}. Please unarchive it first.</source>
			<translation>No se puede establecer el estado activo del psector archivado {0}. Por favor, desarchívelo primero.</translation>
		</message>
		<message>
			<source>Cannot set the current {0} scenario of an inactive scenario. Please activate it first.</source>
			<translation>No se puede fijar el escenario actual {0} de un escenario inactivo. Por favor, actívelo primero.</translation>
		</message>
		<message>
			<source>Cannot set the current netscenario of an inactive scenario. Please activate it first.</source>
			<translation>No se puede establecer el netscenario actual de un escenario inactivo. Por favor, actívelo primero.</translation>
		</message>
		<message>
			<source>Can&apos;t create curve with only one value if flow is 0. Add more values or change the flow value.</source>
			<translation>No se puede crear una curva con un solo valor si el caudal es 0. Añada más valores o cambie el valor del caudal.</translation>
		</message>
		<message>
			<source>Category name cannot be empty.</source>
			<translation>El nombre de la categoría no puede estar vacío</translation>
		</message>
		<message>
			<source>Category updated successfully!</source>
			<translation>Categoría actualizada correctamente</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a dscenario will delete data from features related to the dscenario.
Are you sure you want to delete these records?</source>
			<translation>¡PRECAUCIÓN! Eliminar un dscenario borrará datos de los elementos relacionados con el dscenario.
¿Está seguro de que desea eliminar estos registros?</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a netscenario will delete data from features related to the netscenario.
Are you sure you want to delete these records?</source>
			<translation>¡PRECAUCIÓN! Eliminar un netscenario borrará datos de los elementos relacionados con el netscenario.
¿Está seguro de que desea eliminar estos registros?</translation>
		</message>
		<message>
			<source>Change epa_type</source>
			<translation>Cambiar epa_type</translation>
		</message>
		<message>
			<source>Changes applied to &quot;{0}&quot; successfully.</source>
			<translation>Cambios aplicados a &quot;{0}&quot; correctamente.</translation>
		</message>
		<message>
			<source>Changes on this page are dangerous and can break Giswater plugin in various ways. 
You will need to restart QGIS or reload Giswater plugin to apply changes. Do you want continue?</source>
			<translation>Los cambios en esta página son peligrosos y pueden romper el complemento Giswater de varias maneras.
Necesitará reiniciar QGIS o recargar el complemento Giswater para aplicar los cambios. ¿Desea continuar?</translation>
		</message>
		<message>
			<source>Changes saved.</source>
			<translation>Cambios guardados.</translation>
		</message>
		<message>
			<source>Change Team</source>
			<translation>Cambiar Equipo</translation>
		</message>
		<message>
			<source>Check all</source>
			<translation>Marcar todo</translation>
		</message>
		<message>
			<source>Check fields from table or view</source>
			<translation>Verifique los campos de la tabla o vista</translation>
		</message>
		<message>
			<source>Checking any item will not uncheck any other item.</source>
			<translation>Al marcar un elemento no se desmarcará ningún otro.</translation>
		</message>
		<message>
			<source>Checking any item will uncheck all other items.</source>
			<translation>Al marcar cualquier opción, se desmarcan todas las demás.</translation>
		</message>
		<message>
			<source>Checking any item will uncheck all other items unless Shift is pressed.</source>
			<translation>Al marcar cualquier elemento, se desmarcarán todos los demás, a menos que se pulse Mayús.</translation>
		</message>
		<message>
			<source>Check project failed: no response from database function &apos;{0}&apos;.</source>
			<translation>Error al comprobar el Proyecto: no hay respuesta de la función de la Base de datos &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Choose dscenario</source>
			<translation>Choose dscenario</translation>
		</message>
		<message>
			<source>cibs schema does not exist. Create it first.</source>
			<translation>el esquema cibs no existe. Créelo primero.</translation>
		</message>
		<message>
			<source>Cibs schema does not exist. Create it first.</source>
			<translation>El esquema Cibs no existe. Créelo primero.</translation>
		</message>
		<message>
			<source>cibs schema is not supported for parent_type=&apos;{0}&apos; in this dbmodel. Missing schemas/addon/cibs/integration/{1}/integration.sql.</source>
			<translation>El esquema cibs no es compatible con parent_type=&apos;{0}&apos; en este dbmodel. Falta schemas/addon/cibs/integration/{1}/integration.sql.</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it. </source>
			<translation>Al hacer clic en un elemento, se marcará/desmarcará.</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.
Checking any item will not uncheck any other item.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Hacer clic en un elemento lo marcará/desmarcará.
Marcar cualquier elemento no desmarcará ningún otro elemento.
Este comportamiento se puede configurar en la tabla &apos;config_param_system&apos; (parámetro = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.
Checking any item will uncheck all other items.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Hacer clic en un elemento lo marcará/desmarcará.
Marcar cualquier elemento desmarcará todos los demás elementos.
Este comportamiento se puede configurar en la tabla &apos;config_param_system&apos; (parámetro = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.
Checking any item will uncheck all other items unless Shift is pressed.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Hacer clic en un elemento lo marcará/desmarcará.
Marcar cualquier elemento desmarcará todos los demás elementos a menos que se presione Shift.
Este comportamiento se puede configurar en la tabla &apos;config_param_system&apos; (parámetro = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it.
This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector_{0}&apos;).</source>
			<translation>Hacer clic en un elemento lo marcará/desmarcará.
Este comportamiento se puede configurar en la tabla &apos;config_param_system&apos; (parámetro = &apos;basic_selector_{0}&apos;).</translation>
		</message>
		<message>
			<source>Click on 2 places on the map, creating a line, then set the location of a point</source>
			<translation>Haga clic en 2 lugares en el mapa, la creación de una línea, a continuación, establecer la ubicación de un punto</translation>
		</message>
		<message>
			<source>Click on a node to force the connection.</source>
			<translation>Haga clic en un nodo para forzar la conexión.</translation>
		</message>
		<message>
			<source>Click on arcs to select them. Use Alt+click to unselect selected arcs.</source>
			<translation>Haga clic en los arcos para seleccionarlos. Utilice Alt+clic para deseleccionar los arcos seleccionados.</translation>
		</message>
		<message>
			<source>Click on disconnected node, move the pointer to the desired location on pipe to break it</source>
			<translation>Seleccione el nodo desconectado haciendo clic en él, mueva el puntero a la ubicación deseada dentro de una tubería y haga clic nuevamente</translation>
		</message>
		<message>
			<source>Click on feature or any place on the map and set radius of a circle</source>
			<translation>Seleccione un elemento y haga clic en él para establecer el radio de un círculo</translation>
		</message>
		<message>
			<source>Click on feature to replace it with a new one. You can select other layer to snap a different feature type.</source>
			<translation>Haga clic en el Elemento para reemplazarlo por uno nuevo. Puede seleccionar otra Capa para acoplar un tipo de Elemento diferente.</translation>
		</message>
		<message>
			<source>Click on node, that joins two pipes, in order to remove it and merge pipes</source>
			<translation>Haga clic en el nodo que une dos tuberías para eliminarlo y fusionar las tuberías.</translation>
		</message>
		<message>
			<source>Click on the object to change its class</source>
			<translation>Haga clic en el objeto para cambiar su clase</translation>
		</message>
		<message>
			<source>Close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>cm schema is not supported for parent_type=&apos;{0}&apos; in this dbmodel. Missing schemas/addon/cm/integration/{1}/integration.sql.</source>
			<translation>El esquema cm no es compatible con parent_type=&apos;{0}&apos; en este dbmodel. Falta schemas/addon/cm/integration/{1}/integration.sql.</translation>
		</message>
		<message>
			<source>Column name already exists.</source>
			<translation>El nombre de la columna ya existe.</translation>
		</message>
		<message>
			<source>Column name and Label fields are mandatory. Please set correct value.</source>
			<translation>Los campos Nombre de columna y Etiqueta son obligatorios. Establezca el valor correcto.</translation>
		</message>
		<message>
			<source>Column not found in table: {0}</source>
			<translation>Columna no encontrada en la tabla: {0}</translation>
		</message>
		<message>
			<source>Completed with no exception and no result</source>
			<translation>Completado sin excepción y sin resultado</translation>
		</message>
		<message>
			<source>Compliance Grade</source>
			<translation>Grado de cumplimiento</translation>
		</message>
		<message>
			<source>Composer disabled: atlas coverage layer must be &apos;v_plan_psector&apos;.</source>
			<translation>Compositor deshabilitado: la capa de cobertura atlas debe ser &apos;v_plan_psector&apos;.</translation>
		</message>
		<message>
			<source>Composer disabled: atlas must be enabled with coverage layer &apos;v_plan_psector&apos;.</source>
			<translation>Compositor deshabilitado: atlas debe estar habilitado con la capa de cobertura &apos;v_plan_psector&apos;.</translation>
		</message>
		<message>
			<source>Composer disabled: export failed, check layout configuration.</source>
			<translation>Composer deshabilitado: exportación fallida, revise la configuración del diseño.</translation>
		</message>
		<message>
			<source>Composer disabled: file is empty.</source>
			<translation>Composer deshabilitado: el archivo está vacío.</translation>
		</message>
		<message>
			<source>Composer disabled: layout not found.</source>
			<translation>Compositor deshabilitado: diseño no encontrado.</translation>
		</message>
		<message>
			<source>Composer disabled: no layouts available.</source>
			<translation>Composer deshabilitado: no hay diseños disponibles.</translation>
		</message>
		<message>
			<source>Composer disabled: select a template.</source>
			<translation>Composer deshabilitado: seleccione una plantilla.</translation>
		</message>
		<message>
			<source>Conduits couldn&apos;t be inserted!</source>
			<translation>¡Los conductos no pudieron ser insertados!</translation>
		</message>
		<message>
			<source>Config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>Config database file not found</source>
			<translation>No se ha encontrado el archivo de configuración de la base de datos</translation>
		</message>
		<message>
			<source>Config file not found: {0}</source>
			<translation>Archivo de Configuración no encontrado: {0}</translation>
		</message>
		<message>
			<source>Config file not found at</source>
			<translation>Archivo de configuración no encontrado en</translation>
		</message>
		<message>
			<source>Config file not found at: {0}</source>
			<translation>Archivo de Configuración no encontrado en: {0}</translation>
		</message>
		<message>
			<source>Configuration file couldn&apos;t be imported:
{0}</source>
			<translation>No se pudo importar el archivo de configuración:
{0}</translation>
		</message>
		<message>
			<source>Configuration file not found, please make sure it is located in the correct directory and try again: {0}</source>
			<translation>Archivo de configuración no encontrado, por favor asegúrese de que está ubicado en el directorio correcto e inténtelo de nuevo: {0}</translation>
		</message>
		<message>
			<source>Configuration loaded successfully</source>
			<translation>Configuración cargada correctamente</translation>
		</message>
		<message>
			<source>Configuration saved to {0}</source>
			<translation>Configuración guardada en {0}</translation>
		</message>
		<message>
			<source>Confirm</source>
			<translation>Confirmar</translation>
		</message>
		<message>
			<source>Confirm Deletion</source>
			<translation>Confirmar borrado</translation>
		</message>
		<message>
			<source>Connec management</source>
			<translation>Gestión de Connexión</translation>
		</message>
		<message>
			<source>Connecting...</source>
			<translation>Conectando...</translation>
		</message>
		<message>
			<source>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;</source>
			<translation>Conexión &apos;{0}&apos; no encontrada en el archivo &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;. Trying in &apos;{2}&apos;...</source>
			<translation>Conexión &apos;{0}&apos; no encontrada en el archivo &apos;{1}&apos;. Intentando en &apos;{2}&apos;...</translation>
		</message>
		<message>
			<source>Connection failed. Please, check connection parameters</source>
			<translation>Conexión fallida. Por favor, compruebe los parámetros de conexión</translation>
		</message>
		<message>
			<source>Connection Failed. Please, check connection parameters</source>
			<translation>Conexión fallida. Por favor, compruebe los parámetros de conexión</translation>
		</message>
		<message>
			<source>Connection Failed. Please, check connection parameters ({0})</source>
			<translation>Conexión fallida. Por favor, compruebe los parámetros de conexión ({0})</translation>
		</message>
		<message>
			<source>Connect link</source>
			<translation>Conectar enlace</translation>
		</message>
		<message>
			<source>Connect link task is already active!</source>
			<translation>¡La tarea de enlace de conexión ya está activa!</translation>
		</message>
		<message>
			<source>Connec to network</source>
			<translation>Conectar a red</translation>
		</message>
		<message>
			<source>Connect to network</source>
			<translation>Conectar a la red</translation>
		</message>
		<message>
			<source>Context</source>
			<translation>Contexto</translation>
		</message>
		<message>
			<source>Converting to flwreg...</source>
			<translation>Convirtiendo a flwreg...</translation>
		</message>
		<message>
			<source>Copy project - {0}</source>
			<translation>Copiar proyecto - {0}</translation>
		</message>
		<message>
			<source>Cost (€)</source>
			<translation>Coste (€)</translation>
		</message>
		<message>
			<source>Could not delete language files ({0}): {1}</source>
			<translation>No se pudieron eliminar los archivos de idioma ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not delete manifest.json: {0}</source>
			<translation>No se pudo eliminar manifest.json: {0}</translation>
		</message>
		<message>
			<source>Could not delete multilang translations ({0}): {1}</source>
			<translation>No se pudieron eliminar las traducciones multilang ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not determine event point coordinates</source>
			<translation>No se han podido determinar las coordenadas del punto de evento</translation>
		</message>
		<message>
			<source>Could not download language files ({0}): {1}</source>
			<translation>No se pudieron descargar los archivos de idioma ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not download language files in time. The project will continue to load.</source>
			<translation>No se pudieron descargar los archivos de idioma a tiempo. El Proyecto continuará cargando.</translation>
		</message>
		<message>
			<source>Could not download language files. The project will continue to load. {0}</source>
			<translation>No se pudieron descargar los archivos de idioma. El Proyecto continuará cargando. {0}</translation>
		</message>
		<message>
			<source>Could not extract language files: Unknown error</source>
			<translation>No se pudieron extraer los archivos de idioma: Error desconocido</translation>
		</message>
		<message>
			<source>Could not find an ID for the style group &apos;{0}&apos;.</source>
			<translation>No se ha podido encontrar un ID para el grupo de estilos &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Could not find config_style ID for idval &apos;{0}&apos;.</source>
			<translation>No se pudo encontrar config_style ID para idval &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Could not find ID column &apos;{0}&apos;.</source>
			<translation>No se pudo encontrar la columna ID &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Could not find the corresponding ID for the selected style {0}.</source>
			<translation>No se ha podido encontrar el ID correspondiente para el estilo seleccionado {0}.</translation>
		</message>
		<message>
			<source>Could not get feature ID from snapped point</source>
			<translation>No se ha podido obtener el ID de característica del punto de encaje</translation>
		</message>
		<message>
			<source>Could not load EPA Results layers</source>
			<translation>No se pudieron cargar las capas de resultados EPA</translation>
		</message>
		<message>
			<source>Could not open database connection for multilang task.</source>
			<translation>No se pudo abrir la conexión a la base de datos para la tarea multilenguaje.</translation>
		</message>
		<message>
			<source>Could not reach the translations server. Showing downloaded languages only.</source>
			<translation>No se pudo contactar con el servidor de traducciones. Mostrando solo los idiomas descargados.</translation>
		</message>
		<message>
			<source>could not remove: {0}</source>
			<translation>no se pudo eliminar: {0}</translation>
		</message>
		<message>
			<source>Could not retrieve feature from layer</source>
			<translation>No se ha podido recuperar la característica de la capa</translation>
		</message>
		<message>
			<source>Could not seed multilang translations ({0}): {1}</source>
			<translation>No se pudieron sembrar las traducciones multilenguaje ({0}): {1}</translation>
		</message>
		<message>
			<source>Could not update locale metadata</source>
			<translation>No se pudo actualizar los metadatos locales</translation>
		</message>
		<message>
			<source>Could not write control {0} - skipping</source>
			<translation>No se pudo escribir el control {0} - omitiendo</translation>
		</message>
		<message>
			<source>Couldn&apos;t add group.</source>
			<translation>No se pudo añadir el grupo.</translation>
		</message>
		<message>
			<source>Couldn&apos;t draw profile. You may need to select another exploitation.</source>
			<translation>No se pudo dibujar el perfil. Es posible que deba seleccionar otra explotación.</translation>
		</message>
		<message>
			<source>Couldn&apos;t find layer to zoom to</source>
			<translation>No se encontró la capa para hacer zoom</translation>
		</message>
		<message>
			<source>Couldn&apos;t find node &apos;{0}&apos; for source &apos;{1}&apos;.</source>
			<translation>No se pudo encontrar el nodo &apos;{0}&apos; para la fuente &apos;{1}&apos;.</translation>
		</message>
		<message>
			<source>Couldn&apos;t import swmm_api package. Try to reload the Giswater plugin. If the issue persists restart QGIS.</source>
			<translation>No se ha podido importar el paquete swmm_api. Intente recargar el plugin Giswater. Si el problema persiste reinicie QGIS.</translation>
		</message>
		<message>
			<source>Create {0} schema</source>
			<translation>Crear {0} esquema</translation>
		</message>
		<message>
			<source>Create am schema</source>
			<translation>Crear esquema am</translation>
		</message>
		<message>
			<source>Create am schema with sample data</source>
			<translation>Crear Esquema am con datos de ejemplo</translation>
		</message>
		<message>
			<source>Create base schema</source>
			<translation>Crear esquema base</translation>
		</message>
		<message>
			<source>Create catalogs</source>
			<translation>Crear catálogos</translation>
		</message>
		<message>
			<source>Created</source>
			<translation>Creado</translation>
		</message>
		<message>
			<source>Created locales database from seed</source>
			<translation>Creada la Base de datos de locales desde seed</translation>
		</message>
		<message>
			<source>Create example</source>
			<translation>Crear ejemplo</translation>
		</message>
		<message>
			<source>Create field on &quot;{0}&quot;</source>
			<translation>Crear campo en &quot;{0}&quot;</translation>
		</message>
		<message>
			<source>Create multi field</source>
			<translation>Crear multi campo</translation>
		</message>
		<message>
			<source>Create multilang schema</source>
			<translation>Crear esquema multilenguaje</translation>
		</message>
		<message>
			<source>Create Project - {0}</source>
			<translation>Crear Proyecto - {0}</translation>
		</message>
		<message>
			<source>Create schema of type &apos;{0}&apos;: &apos;{1}&apos;</source>
			<translation>Crear esquema de tipo &apos;{0}&apos;: &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Creating demand dscenario...</source>
			<translation>Creando escenario de Demanda...</translation>
		</message>
		<message>
			<source>Creating GIS file... {0}</source>
			<translation>Creando archivo GIS... {0}</translation>
		</message>
		<message>
			<source>Creating new flwreg catalogs</source>
			<translation>Creando nuevos catálogos flwreg</translation>
		</message>
		<message>
			<source>Creating new node catalogs</source>
			<translation>Creando nuevos catálogos de nodos</translation>
		</message>
		<message>
			<source>Creating new node catalogs...</source>
			<translation>Creando nuevos catálogos de nodos...</translation>
		</message>
		<message>
			<source>Creating new pipe catalogs</source>
			<translation>Creando nuevos catálogos de tuberías</translation>
		</message>
		<message>
			<source>Creating new pipe catalogs...</source>
			<translation>Creando nuevos catálogos de tuberías...</translation>
		</message>
		<message>
			<source>Creating new varc catalogs</source>
			<translation>Creando nuevos catálogos varc</translation>
		</message>
		<message>
			<source>Creating new varc catalogs...</source>
			<translation>Creando nuevos catálogos varc...</translation>
		</message>
		<message>
			<source>Creating parser for file: {0}</source>
			<translation>Creando analizador para archivo: {0}</translation>
		</message>
		<message>
			<source>Creating quantized model...</source>
			<translation>Creando modelo cuantizado...</translation>
		</message>
		<message>
			<source>Creating user config folder</source>
			<translation>Creación de la carpeta de configuración de usuario</translation>
		</message>
		<message>
			<source>Creating user config folder: {0}</source>
			<translation>Creando carpeta de configuración de usuario: {0}</translation>
		</message>
		<message>
			<source>Creating workcat</source>
			<translation>Creando workcat</translation>
		</message>
		<message>
			<source>Creating workcat...</source>
			<translation>Creando workcat...</translation>
		</message>
		<message>
			<source>Creation type</source>
			<translation>Tipo de creación</translation>
		</message>
		<message>
			<source>Credentials will be stored in the GIS project file as plain text, and will apply to both existing and future layers. Do you want to proceed?</source>
			<translation>Las credenciales se almacenarán en el archivo de proyecto del SIG como texto sin formato, y se aplicarán tanto a las capas existentes como a las futuras. ¿Desea continuar?</translation>
		</message>
		<message>
			<source>CRITICAL ERROR in update_expl_sector_combos: {0}</source>
			<translation>ERROR CRÍTICO en update_expl_sector_combos: {0}</translation>
		</message>
		<message>
			<source>CSV not generated. Check fields from table or view</source>
			<translation>CSV no generado. Verifique los campos de la tabla o vista</translation>
		</message>
		<message>
			<source>Current feature has state &apos;{0}&apos;. Therefore it is not fusionable</source>
			<translation>La característica actual tiene el estado &quot;{0}&quot;. Por lo tanto, no es fusionable</translation>
		</message>
		<message>
			<source>Current feature has state &apos;{0}&apos;. Therefore it is not replaceable</source>
			<translation>La función actual tiene el estado &apos;{0}&apos;. Por lo tanto, no es reemplazable</translation>
		</message>
		<message>
			<source>Current feature is planified. You should activate plan mode to work with it.</source>
			<translation>La función actual está planificada. Debe activar el modo plan para trabajar con ella.</translation>
		</message>
		<message>
			<source>Current network cost (€):</source>
			<translation>Coste actual de la red (€):</translation>
		</message>
		<message>
			<source>Current node is not located over an arc. Please, select option &apos;DRAG-DROP&apos;</source>
			<translation>El nodo actual no está situado sobre un arco. Por favor, seleccione la opción &apos;DRAG-DROP&apos;.</translation>
		</message>
		<message>
			<source>Current psector</source>
			<translation>Sector actual</translation>
		</message>
		<message>
			<source>Current Result</source>
			<translation>Resultado actual</translation>
		</message>
		<message>
			<source>Database connection error: {0}</source>
			<translation>Error de conexión a la base de datos: {0}</translation>
		</message>
		<message>
			<source>Database connection error ({0}): {1}</source>
			<translation>Error de conexión a la Base de datos ({0}): {1}</translation>
		</message>
		<message>
			<source>Database connection error. Please check your connection parameters.</source>
			<translation>Error de conexión a la Base de datos. Por favor, verifique sus parámetros de conexión.</translation>
		</message>
		<message>
			<source>Database connection error (psycopg2). Please open plugin log file to get more details</source>
			<translation>Error de conexión a la Base de datos (psycopg2). Por favor abra el archivo de registro del complemento para obtener más detalles</translation>
		</message>
		<message>
			<source>Database connection error (QSqlDatabase). Please open plugin log file to get more details</source>
			<translation>Error de conexión a la Base de datos (QSqlDatabase). Por favor abra el archivo de registro del complemento para obtener más detalles</translation>
		</message>
		<message>
			<source>Database connection is not available</source>
			<translation>La conexión con la Base de datos no está disponible</translation>
		</message>
		<message>
			<source>Database connection is not available.</source>
			<translation>La conexión a la Base de datos no está disponible.</translation>
		</message>
		<message>
			<source>Database connection reset, please try again</source>
			<translation>Conexión a la Base de datos restablecida, por favor intente de nuevo</translation>
		</message>
		<message>
			<source>Database connection was closed and reconnected</source>
			<translation>La conexión a la base de datos se cerró y reconectó</translation>
		</message>
		<message>
			<source>Database error</source>
			<translation>Error de Base de datos</translation>
		</message>
		<message>
			<source>Database Error</source>
			<translation>Error de base de datos</translation>
		</message>
		<message>
			<source>Database execution failed</source>
			<translation>Fallo en la ejecución de la base de datos</translation>
		</message>
		<message>
			<source>Database name contains special characters that are not supported</source>
			<translation>El nombre de la base de datos contiene caracteres especiales que no se admiten</translation>
		</message>
		<message>
			<source>Database returned null. Check postgres function &apos;{0}&apos;</source>
			<translation>La base de datos devuelve null. Compruebe la función postgres &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Database translation canceled.</source>
			<translation>Traducción de base de datos cancelada.</translation>
		</message>
		<message>
			<source>Database translation failed.</source>
			<translation>Error en la traducción de la base de datos.</translation>
		</message>
		<message>
			<source>Database translation successful to</source>
			<translation>Traducción correcta de la base de datos a</translation>
		</message>
		<message>
			<source>Data insertion completed: {0} successful, {1} errors.</source>
			<translation>Inserción de datos completada: {0} con éxito, {1} errores.</translation>
		</message>
		<message>
			<source>Data retrieved and displayed successfully.</source>
			<translation>Datos recuperados y visualizados correctamente.</translation>
		</message>
		<message>
			<source>Date from:</source>
			<translation>Fecha de:</translation>
		</message>
		<message>
			<source>Date of creation</source>
			<translation>Fecha de creación</translation>
		</message>
		<message>
			<source>Date of last update</source>
			<translation>Fecha de la última actualización</translation>
		</message>
		<message>
			<source>Date to:</source>
			<translation>Fecha a:</translation>
		</message>
		<message>
			<source>DEBUG: {0}</source>
			<translation>DEPURACIÓN: {0}</translation>
		</message>
		<message>
			<source>DEBUG: catalog: {0}, arctype_id: {1}, material: {2}, pipe_dint: {3}</source>
			<translation>DEBUG: catálogo: {0}, arctype_id: {1}, material: {2}, pipe_dint: {3}</translation>
		</message>
		<message>
			<source>DEBUG: OPTIONS:</source>
			<translation>DEBUG: OPCIONES:</translation>
		</message>
		<message>
			<source>Default Built Date</source>
			<translation>Fecha de construcción predeterminada</translation>
		</message>
		<message>
			<source>Delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>Delete base</source>
			<translation>Eliminar base</translation>
		</message>
		<message>
			<source>Delete dscenario</source>
			<translation>Eliminar dscenario</translation>
		</message>
		<message>
			<source>Delete field on &quot;{0}&quot;</source>
			<translation>Eliminar Campo en &quot;{0}&quot;</translation>
		</message>
		<message>
			<source>Delete function</source>
			<translation>Eliminar función</translation>
		</message>
		<message>
			<source>Delete inflows</source>
			<translation>Eliminar entradas de caudal</translation>
		</message>
		<message>
			<source>Delete language files?</source>
			<translation>¿Eliminar archivos de idioma?</translation>
		</message>
		<message>
			<source>Delete Lot(s)</source>
			<translation>Eliminar Lote(s)</translation>
		</message>
		<message>
			<source>Delete mincut</source>
			<translation>Eliminar mincut</translation>
		</message>
		<message>
			<source>Delete multi field</source>
			<translation>Eliminar campo múltiple</translation>
		</message>
		<message>
			<source>Delete multilang translations</source>
			<translation>Eliminar traducciones multilang</translation>
		</message>
		<message>
			<source>Delete multilang translations for ({0})</source>
			<translation>Eliminar traducciones multilang para ({0})</translation>
		</message>
		<message>
			<source>Delete multilang translations for ({0})?</source>
			<translation>¿Eliminar traducciones multilang para ({0})?</translation>
		</message>
		<message>
			<source>Delete records</source>
			<translation>Eliminar registros</translation>
		</message>
		<message>
			<source>Delete schema failed: {0}</source>
			<translation>Eliminar esquema falló: {0}</translation>
		</message>
		<message>
			<source>Delete Workorder(s)</source>
			<translation>Eliminar Orden(es) de trabajo</translation>
		</message>
		<message>
			<source>Deleting multilang translations for ({0})...</source>
			<translation>Eliminando traducciones multilang para ({0})...</translation>
		</message>
		<message>
			<source>Demand</source>
			<translation>Demanda</translation>
		</message>
		<message>
			<source>Description</source>
			<translation>Descripción</translation>
		</message>
		<message>
			<source>Detail</source>
			<translation>Detalle</translation>
		</message>
		<message>
			<source>Diameter</source>
			<translation>Diámetro</translation>
		</message>
		<message>
			<source>Disconnect elements</source>
			<translation>Elementos de desconexión</translation>
		</message>
		<message>
			<source>Dividers couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar divisores!</translation>
		</message>
		<message>
			<source>Document already exist</source>
			<translation>El documento ya existe</translation>
		</message>
		<message>
			<source>Document already exists</source>
			<translation>El documento ya existe</translation>
		</message>
		<message>
			<source>Document inserted successfully</source>
			<translation>Documento insertado correctamente</translation>
		</message>
		<message>
			<source>Document name not found</source>
			<translation>Nombre de documento no encontrado</translation>
		</message>
		<message>
			<source>Document PDF created in</source>
			<translation>Documento PDF creado en</translation>
		</message>
		<message>
			<source>Documents deleted successfully</source>
			<translation>Documentos eliminados correctamente</translation>
		</message>
		<message>
			<source>done!</source>
			<translation>¡hecho!</translation>
		</message>
		<message>
			<source>DOWNGRADE NODE</source>
			<translation>DEGRADAR NODO</translation>
		</message>
		<message>
			<source>Download cancelled or timed out</source>
			<translation>Descarga cancelada o caducada</translation>
		</message>
		<message>
			<source>Downloading language files for ({0})...</source>
			<translation>Descargando archivos de idioma para ({0})...</translation>
		</message>
		<message>
			<source>Download language files?</source>
			<translation>¿Descargar archivos de idioma?</translation>
		</message>
		<message>
			<source>Do you want to copy its values to the current node?</source>
			<translation>¿Quieres copiar sus valores en el nodo actual?</translation>
		</message>
		<message>
			<source>Do you want to delete local language files for ({0})?</source>
			<translation>¿Desea eliminar los archivos de idioma locales para ({0})?</translation>
		</message>
		<message>
			<source>Do you want to download local language files for ({0})?</source>
			<translation>¿Desea descargar archivos de idioma locales para ({0})?</translation>
		</message>
		<message>
			<source>Do you want to insert {0} selected features? (First 50: {1} ...)</source>
			<translation>¿Desea insertar {0} características seleccionadas? (Primeros 50: {1} ...)</translation>
		</message>
		<message>
			<source>Do you want to insert the selected features?
{0}</source>
			<translation>¿Desea insertar los elementos seleccionados?
{0}</translation>
		</message>
		<message>
			<source>Do you want to insert the selected features? {0}</source>
			<translation>¿Desea insertar las características seleccionadas? {0}</translation>
		</message>
		<message>
			<source>Do you want to overwrite custom values?</source>
			<translation>¿Desea sobrescribir los valores personalizados?</translation>
		</message>
		<message>
			<source>Do you want to overwrite file?</source>
			<translation>¿Quiere sobrescribir el archivo?</translation>
		</message>
		<message>
			<source>Do you want to proceed?</source>
			<translation>¿Desea continuar?</translation>
		</message>
		<message>
			<source>Do you want to save changes to dscenario &quot;{0}&quot;?
This operation cannot be undone.

(Please note that any changes made to node elevations cannot be saved to dscenarios.)</source>
			<translation>¿Desea guardar los cambios en dscenario &quot;{0}&quot;?
Esta operación no puede deshacerse.

(Tenga en cuenta que cualquier cambio realizado en las elevaciones de los Nodo no puede guardarse en dscenarios.)</translation>
		</message>
		<message>
			<source>Do you want to seed multilang translations for ({0})?</source>
			<translation>¿Desea sembrar traducciones multilenguaje para ({0})?</translation>
		</message>
		<message>
			<source>Do you want to set this psector as current?</source>
			<translation>¿Desea establecer este psector como actual?</translation>
		</message>
		<message>
			<source>Do you want to update local language files for ({0})?</source>
			<translation>¿Desea actualizar los archivos de idioma locales para ({0})?</translation>
		</message>
		<message>
			<source>Do you want to update multilang translations for ({0})?</source>
			<translation>¿Desea actualizar las traducciones multilenguaje para ({0})?</translation>
		</message>
		<message>
			<source>Do you want to update the symbology of the layers currently loaded in the project?</source>
			<translation>¿Desea actualizar la simbología de las capas cargadas actualmente en el proyecto?</translation>
		</message>
		<message>
			<source>Draw Profile</source>
			<translation>Dibujar Perfil</translation>
		</message>
		<message>
			<source>Dscenario manager</source>
			<translation>Escenarios dinámicos</translation>
		</message>
		<message>
			<source>Duplicate</source>
			<translation>Duplicado</translation>
		</message>
		<message>
			<source>Duplicate user and campaign pairs are not allowed. Remove duplicates before saving.</source>
			<translation>No se permiten pares duplicados de usuario y campaña. Elimine duplicados antes de Guardar.</translation>
		</message>
		<message>
			<source>DWF &amp; INFLOWS</source>
			<translation>DWF &amp; INFLOWS</translation>
		</message>
		<message>
			<source>DWF scenario manager</source>
			<translation>Escenarios DWF</translation>
		</message>
		<message>
			<source>Edit base</source>
			<translation>Editar base</translation>
		</message>
		<message>
			<source>Edit dscenario</source>
			<translation>Editar dscenario</translation>
		</message>
		<message>
			<source>Edit inflows</source>
			<translation>Editar afluencias</translation>
		</message>
		<message>
			<source>Empty coordinate list</source>
			<translation>Lista de coordenadas vacía</translation>
		</message>
		<message>
			<source>Empty response</source>
			<translation>Respuesta vacía</translation>
		</message>
		<message>
			<source>Empty response from database function.</source>
			<translation>Respuesta vacía de la función de la Base de datos.</translation>
		</message>
		<message>
			<source>English locale not found</source>
			<translation>Localización en inglés no encontrada</translation>
		</message>
		<message>
			<source>Epa2data execution failed. See logs for more details...</source>
			<translation>La ejecución de Epa2data falló. Ver registros para más detalles...</translation>
		</message>
		<message>
			<source>EPA model finished.</source>
			<translation>Modelo EPA finalizado.</translation>
		</message>
		<message>
			<source>EPA model finished. </source>
			<translation>Modelo EPA terminado.</translation>
		</message>
		<message>
			<source>EPA Result Families exported successfully:
{0}</source>
			<translation>Familias de Resultados EPA exportadas correctamente:
{0}</translation>
		</message>
		<message>
			<source>EPA type</source>
			<translation>Tipo EPA</translation>
		</message>
		<message>
			<source>Epa type is not defined for element {0}</source>
			<translation>Tipo Epa no definido para el elemento {0}</translation>
		</message>
		<message>
			<source>Error</source>
			<translation>Error</translation>
		</message>
		<message>
			<source>ERROR -&gt; {0}</source>
			<translation>ERROR -&gt; {0}</translation>
		</message>
		<message>
			<source>Error: &apos;{0}&apos; or &apos;{1}&apos; field is missing in the result.</source>
			<translation>Error: Falta el campo &apos;{0}&apos; o &apos;{1}&apos; en el resultado.</translation>
		</message>
		<message>
			<source>Error assigning team: {0}</source>
			<translation>Error asignando equipo: {0}</translation>
		</message>
		<message>
			<source>Error canceling mincut task: {0}</source>
			<translation>Error al cancelar la tarea mincut: {0}</translation>
		</message>
		<message>
			<source>Error changing team: {0}</source>
			<translation>Error cambiando de equipo: {0}</translation>
		</message>
		<message>
			<source>Error closing mincut cursor: {0}</source>
			<translation>Error cerrando cursor mincut: {0}</translation>
		</message>
		<message>
			<source>Error connecting to database (layer)</source>
			<translation>Error al conectar a la Base de datos (capa)</translation>
		</message>
		<message>
			<source>Error connecting to database (settings)</source>
			<translation>Error al conectar a la Base de datos (ajustes)</translation>
		</message>
		<message>
			<source>Error creating auxiliary connection for vacuum</source>
			<translation>Error al crear conexión auxiliar para vacío</translation>
		</message>
		<message>
			<source>Error creating dynamic dialog: {0}</source>
			<translation>Error creando diálogo dinámico: {0}</translation>
		</message>
		<message>
			<source>Error creating mincut cursor: {0}</source>
			<translation>Error creando cursor mincut: {0}</translation>
		</message>
		<message>
			<source>Error creating or updating team</source>
			<translation>Error creando o actualizando equipo</translation>
		</message>
		<message>
			<source>Error creating Workcat.</source>
			<translation>Error al crear Workcat.</translation>
		</message>
		<message>
			<source>Error. Database returned null. Check postgres function &apos;{0}&apos;</source>
			<translation>Error. La base de datos ha devuelto null. Compruebe la función postgres &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Error deleting data</source>
			<translation>Error eliminando datos</translation>
		</message>
		<message>
			<source>Error deleting records</source>
			<translation>Error al eliminar registros</translation>
		</message>
		<message>
			<source>ERROR: DIVIDER &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: DIVIDER &apos;{0}&apos; no tiene coordenadas en la sección [COORDINATES].</translation>
		</message>
		<message>
			<source>Error during point selection: {0}</source>
			<translation>Error durante la selección de puntos: {0}</translation>
		</message>
		<message>
			<source>Error executing {0} - {1}</source>
			<translation>Error ejecutando {0} - {1}</translation>
		</message>
		<message>
			<source>Error executing EPA software</source>
			<translation>Error al ejecutar el software EPA</translation>
		</message>
		<message>
			<source>Error executing EPA software: {0}</source>
			<translation>Error al ejecutar el software EPA: {0}</translation>
		</message>
		<message>
			<source>Error executing gw_fct_create_dscenario_empty</source>
			<translation>Error al ejecutar gw_fct_create_dscenario_empty</translation>
		</message>
		<message>
			<source>Error executing gw_fct_import_swmm_flwreg - {0}</source>
			<translation>Error al ejecutar gw_fct_import_swmm_flwreg - {0}</translation>
		</message>
		<message>
			<source>Error executing setmincut with cursor: {0}</source>
			<translation>Error al ejecutar setmincut con cursor: {0}</translation>
		</message>
		<message>
			<source>Error executing vacuum: {0}</source>
			<translation>Error al ejecutar vacío: {0}</translation>
		</message>
		<message>
			<source>Error fusing arcs</source>
			<translation>Error al fusionar arcos</translation>
		</message>
		<message>
			<source>Error getting current psector</source>
			<translation>Error al obtener el psector actual</translation>
		</message>
		<message>
			<source>Error getting database parameters</source>
			<translation>Error al obtener los parámetros de la base de datos</translation>
		</message>
		<message>
			<source>Error getting default connection (settings)</source>
			<translation>Error obteniendo la conexión predeterminada (ajustes)</translation>
		</message>
		<message>
			<source>Error getting exploitation</source>
			<translation>Error al obtener la explotación</translation>
		</message>
		<message>
			<source>Error getting locale from schema: {0}</source>
			<translation>Error obteniendo la localización desde el Esquema: {0}</translation>
		</message>
		<message>
			<source>Error getting source symbol: {0}</source>
			<translation>Error al obtener el símbolo de fuente: {0}</translation>
		</message>
		<message>
			<source>Error getting UI language locale: {0}</source>
			<translation>Error obteniendo la localización del idioma de la UI: {0}</translation>
		</message>
		<message>
			<source>Error importing IBERGIS project</source>
			<translation>Error al importar el proyecto IBERGIS</translation>
		</message>
		<message>
			<source>Error importing simulation results into database</source>
			<translation>Error al importar los resultados de la simulación en la base de datos</translation>
		</message>
		<message>
			<source>Error in _manage_selection_changed: {0}</source>
			<translation>Error en _manage_selection_changed: {0}</translation>
		</message>
		<message>
			<source>Error in remove function: {0}</source>
			<translation>Error en la función remove: {0}</translation>
		</message>
		<message>
			<source>Error inserting row: {0}</source>
			<translation>Error al insertar fila: {0}</translation>
		</message>
		<message>
			<source>ERROR: JUNCTION &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: UNIÓN &apos;{0}&apos; no tiene coordenadas en la sección [COORDINATES].</translation>
		</message>
		<message>
			<source>Error logging</source>
			<translation>Error al registrar</translation>
		</message>
		<message>
			<source>Error near line</source>
			<translation>Error cerca de la línea</translation>
		</message>
		<message>
			<source>Error near line {0} -&gt; {1}</source>
			<translation>Error cerca de la línea {0} -&gt; {1}</translation>
		</message>
		<message>
			<source>Error on create auto mincut, you need to review data</source>
			<translation>Error al crear polígono de corte automático, es necesario revisar los datos</translation>
		</message>
		<message>
			<source>ERROR: OUTFALL &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: OUTFALL &apos;{0}&apos; no tiene coordenadas en la sección [COORDINATES].</translation>
		</message>
		<message>
			<source>Error parsing file: {0}</source>
			<translation>Error parseando archivo: {0}</translation>
		</message>
		<message>
			<source>Error processing muni_id {0}: {1}</source>
			<translation>Error al procesar muni_id {0}: {1}</translation>
		</message>
		<message>
			<source>ERROR: RAINGAGE &apos;{0}&apos; has no coordinates in [SYMBOLS] section.</source>
			<translation>ERROR: PLUVióMETRO &apos;{0}&apos; no tiene coordenadas en la sección [SYMBOLS].</translation>
		</message>
		<message>
			<source>Error reading configuration file: {0}</source>
			<translation>Error al leer el archivo de configuración: {0}</translation>
		</message>
		<message>
			<source>Error removing items: {0}</source>
			<translation>Error al eliminar elementos: {0}</translation>
		</message>
		<message>
			<source>Error removing team assignment: {0}</source>
			<translation>Error al eliminar asignación de equipo: {0}</translation>
		</message>
		<message>
			<source>Error replacing feature</source>
			<translation>Error al reemplazar el elemento de red</translation>
		</message>
		<message>
			<source>Error replacing feature. Chose a valid catalog.</source>
			<translation>Función de sustitución de errores. Elija un catálogo válido.</translation>
		</message>
		<message>
			<source>Error saving lot</source>
			<translation>Error al guardar lote</translation>
		</message>
		<message>
			<source>Error saving the configuration</source>
			<translation>Error al guardar la configuración</translation>
		</message>
		<message>
			<source>Error setting node</source>
			<translation>Error al establecer nodo</translation>
		</message>
		<message>
			<source>ERROR: STORAGE &apos;{0}&apos; has no coordinates in [COORDINATES] section.</source>
			<translation>ERROR: STORAGE &apos;{0}&apos; no tiene coordenadas en la sección [COORDINATES].</translation>
		</message>
		<message>
			<source>Error toggling state: {0}</source>
			<translation>Error al alternar estado: {0}</translation>
		</message>
		<message>
			<source>Error type</source>
			<translation>Tipo de error</translation>
		</message>
		<message>
			<source>Error updating element in table, you need to review data</source>
			<translation>Error al actualizar el elemento en la tabla, necesita revisar los datos</translation>
		</message>
		<message>
			<source>Error updating expl_id: {0}</source>
			<translation>Error al actualizar expl_id: {0}</translation>
		</message>
		<message>
			<source>Error updating table</source>
			<translation>Error al actualizar la tabla</translation>
		</message>
		<message>
			<source>EXCEPTION</source>
			<translation>EXCEPCIÓN</translation>
		</message>
		<message>
			<source>Exception: {0}</source>
			<translation>Excepción: {0}</translation>
		</message>
		<message>
			<source>Exception: {0}.</source>
			<translation>Excepción: {0}.</translation>
		</message>
		<message>
			<source>EXCEPTION -&gt; {0}</source>
			<translation>EXCEPCIÓN -&gt; {0}</translation>
		</message>
		<message>
			<source>EXCEPTION: {0}, {1}</source>
			<translation>EXCEPCIÓN: {0}, {1}</translation>
		</message>
		<message>
			<source>Exception error: {0}</source>
			<translation>Error de excepción: {0}</translation>
		</message>
		<message>
			<source>Exception in {0}</source>
			<translation>Excepción en {0}</translation>
		</message>
		<message>
			<source>Exception in {0} (executing {1} from {2}): {3}</source>
			<translation>Excepción en {0} (ejecutando {1} desde {2}): {3}</translation>
		</message>
		<message>
			<source>Exception in info</source>
			<translation>Excepción en info</translation>
		</message>
		<message>
			<source>Exception in info (def _get_id)</source>
			<translation>Excepción en info (def _get_id)</translation>
		</message>
		<message>
			<source>Exception in resync_map_after_db_reconnect: {0}</source>
			<translation>Excepción en resync_map_after_db_reconnect: {0}</translation>
		</message>
		<message>
			<source>Exception in unload when {0}</source>
			<translation>Excepción en descarga cuando {0}</translation>
		</message>
		<message>
			<source>Exception in unload when deleting {0}</source>
			<translation>Excepción en la descarga al borrar {0}</translation>
		</message>
		<message>
			<source>Exception in unload when disconnecting {0} signal</source>
			<translation>Excepción en la descarga al desconectar la señal {0}.</translation>
		</message>
		<message>
			<source>Exception in unload when reset values for {0}</source>
			<translation>Excepción en la descarga cuando se restablecen los valores para {0}</translation>
		</message>
		<message>
			<source>Exception in unload when unset signals</source>
			<translation>Excepción en la descarga cuando se desactivan las señales</translation>
		</message>
		<message>
			<source>Exception message not shown to user</source>
			<translation>Mensaje de excepción no mostrado al usuario</translation>
		</message>
		<message>
			<source>Exception when replacing inp strings</source>
			<translation>Excepción al sustituir cadenas inp</translation>
		</message>
		<message>
			<source>Exception while moving/deleting old user config files</source>
			<translation>Excepción al mover/eliminar archivos antiguos de configuración de usuario </translation>
		</message>
		<message>
			<source>Exec. time: {0}</source>
			<translation>Tiempo de ejecución: {0}</translation>
		</message>
		<message>
			<source>Execute EPA software</source>
			<translation>Ejecutar el software EPA</translation>
		</message>
		<message>
			<source>Execute EPA software......</source>
			<translation>Ejecutando software EPA......</translation>
		</message>
		<message>
			<source>Execute EPA software......

</source>
			<translation>Ejecutando software EPA......</translation>
		</message>
		<message>
			<source>Execute failed.</source>
			<translation>Error de ejecución.</translation>
		</message>
		<message>
			<source>Executing calibration &quot;{0}&quot; ({1}/{2})...</source>
			<translation>Ejecutando calibración &quot;{0}&quot; ({1}/{2})...</translation>
		</message>
		<message>
			<source>Executing vacuum</source>
			<translation>Ejecución del vacío</translation>
		</message>
		<message>
			<source>EXECUTION FAILED! Check logs for more information</source>
			<translation>¡EJECUCIÓN FALLIDA! Consulte los registros para más información</translation>
		</message>
		<message>
			<source>Execution of {0} failed.</source>
			<translation>Fallo en la ejecución de {0}.</translation>
		</message>
		<message>
			<source>Export done succesfully</source>
			<translation>Exportación realizada con éxito</translation>
		</message>
		<message>
			<source>Export INP file into PostgreSQL</source>
			<translation>Exportar archivo INP a PostgreSQL</translation>
		</message>
		<message>
			<source>Export INP finished. </source>
			<translation>Exportación INP finalizada.</translation>
		</message>
		<message>
			<source>Expression Error</source>
			<translation>Error de expresión</translation>
		</message>
		<message>
			<source>Extension</source>
			<translation>Extensión</translation>
		</message>
		<message>
			<source>FAIL {0}</source>
			<translation>FALLO {0}</translation>
		</message>
		<message>
			<source>Failed to add feature</source>
			<translation>No se ha podido añadir la función</translation>
		</message>
		<message>
			<source>Failed to configure layer &apos;{0}&apos;. Skipping...</source>
			<translation>Error al configurar la capa &apos;{0}&apos;. Omitiendo...</translation>
		</message>
		<message>
			<source>Failed to create child campaign</source>
			<translation>Error al crear campaña hija</translation>
		</message>
		<message>
			<source>Failed to create layout from template</source>
			<translation>No se pudo crear el diseño a partir de la plantilla</translation>
		</message>
		<message>
			<source>Failed to delete multilang rows for removed project types.</source>
			<translation>Error al eliminar filas multilenguaje para tipos de Proyecto eliminados.</translation>
		</message>
		<message>
			<source>Failed to delete records from {0}.</source>
			<translation>Error al eliminar registros de {0}.</translation>
		</message>
		<message>
			<source>Failed to delete style group</source>
			<translation>No se ha podido eliminar el grupo de estilos</translation>
		</message>
		<message>
			<source>Failed to delete styles</source>
			<translation>Error al borrar estilos</translation>
		</message>
		<message>
			<source>Failed to drop database user &apos;{0}&apos;. It may need to be removed manually.</source>
			<translation>Error al eliminar el usuario de base de datos &apos;{0}&apos;. Puede que sea necesario eliminarlo manualmente.</translation>
		</message>
		<message>
			<source>Failed to execute the mapzones analysis.</source>
			<translation>No se ha podido ejecutar el análisis de mapzones.</translation>
		</message>
		<message>
			<source>Failed to fetch dialog configuration</source>
			<translation>Error al recuperar la configuración del diálogo</translation>
		</message>
		<message>
			<source>Failed to get a valid response from gw_fct_config_mapzones.</source>
			<translation>No se ha podido obtener una respuesta válida de gw_fct_config_mapzones.</translation>
		</message>
		<message>
			<source>Failed to load campaign form</source>
			<translation>Error al cargar el formulario de campaña</translation>
		</message>
		<message>
			<source>Failed to load layers</source>
			<translation>Error al cargar capas</translation>
		</message>
		<message>
			<source>Failed to load layers.</source>
			<translation>Error al cargar capas.</translation>
		</message>
		<message>
			<source>Failed to load lot form</source>
			<translation>Error al cargar el formulario de lote }</translation>
		</message>
		<message>
			<source>Failed to load profile interpolation dialog.</source>
			<translation>Error al cargar el diálogo de interpolación de perfil.</translation>
		</message>
		<message>
			<source>Failed to load scada graph dialog.</source>
			<translation>Error al cargar el diálogo de gráfico SCADA.</translation>
		</message>
		<message>
			<source>Failed to load team creation dialog configuration. Please check database configuration.</source>
			<translation>No se pudo cargar la configuración del diálogo de creación de equipo. Por favor, verifique la configuración de la Base de datos.</translation>
		</message>
		<message>
			<source>Failed to load workorder form</source>
			<translation>No se pudo cargar el formulario de orden de trabajo</translation>
		</message>
		<message>
			<source>Failed to parse JSON result from database.</source>
			<translation>Error al analizar el resultado JSON desde la base de datos.</translation>
		</message>
		<message>
			<source>Failed to retrieve GeoJSON data.</source>
			<translation>Error al recuperar datos GeoJSON.</translation>
		</message>
		<message>
			<source>Failed to retrieve sector features.</source>
			<translation>Error al recuperar las características del sector.</translation>
		</message>
		<message>
			<source>Failed to retrieve the temporal layer</source>
			<translation>Error al recuperar la capa temporal</translation>
		</message>
		<message>
			<source>Failed to save campaign</source>
			<translation>Error al Guardar campaña</translation>
		</message>
		<message>
			<source>Failed to set {0} scenario</source>
			<translation>Fallo al establecer {0} escenario</translation>
		</message>
		<message>
			<source>Failed to set netscenario</source>
			<translation>Fallo al configurar netscenario</translation>
		</message>
		<message>
			<source>Failed to set psector {0} as current</source>
			<translation>Falló al establecer psector {0} como actual</translation>
		</message>
		<message>
			<source>Failed to set ValueRelation for field &apos;{0}&apos;: {1}</source>
			<translation>Error al establecer ValueRelation para el campo &apos;{0}&apos;: {1}</translation>
		</message>
		<message>
			<source>Failed to update category</source>
			<translation>Error al actualizar la categoría</translation>
		</message>
		<message>
			<source>Failed to update styles</source>
			<translation>Error al actualizar estilos</translation>
		</message>
		<message>
			<source>Failed to write export file:
{0}</source>
			<translation>Error al escribir el archivo de exportación:
{0}</translation>
		</message>
		<message>
			<source>Failing data: {0}</source>
			<translation>Datos fallidos: {0}</translation>
		</message>
		<message>
			<source>Feature added successfully!</source>
			<translation>Función añadida correctamente.</translation>
		</message>
		<message>
			<source>Feature already in the list</source>
			<translation>Elemento de red ya en la lista</translation>
		</message>
		<message>
			<source>Feature class not found: {0}</source>
			<translation>Clase de Elemento no encontrada: {0}</translation>
		</message>
		<message>
			<source>Feature has not been updated because no catalog has been selected</source>
			<translation>El elemento no se ha actualizado porque no se ha seleccionado ningún catálogo</translation>
		</message>
		<message>
			<source>Feature ID and Idval cannot be empty.</source>
			<translation>El Id. de característica y el Idval no pueden estar vacíos.</translation>
		</message>
		<message>
			<source>Feature_id is mandatory.</source>
			<translation>Feature_id es obligatorio.</translation>
		</message>
		<message>
			<source>Feature not upserted</source>
			<translation>Elemento no insertado/actualizado</translation>
		</message>
		<message>
			<source>Feature replaced successfully</source>
			<translation>Elemento de red reemplazado con éxito</translation>
		</message>
		<message>
			<source>Feature upserted</source>
			<translation>Elemento insertado/actualizado</translation>
		</message>
		<message>
			<source>Field catalog_id required!</source>
			<translation>¡El campo catalog_id es obligatorio!</translation>
		</message>
		<message>
			<source>Field child_layer of id: </source>
			<translation>Campo child_layer de id:</translation>
		</message>
		<message>
			<source>Field child_layer of id: {0} is not defined in table cat_feature</source>
			<translation>Campo child_layer del id: {0} no está definido en la tabla cat_feature</translation>
		</message>
		<message>
			<source>Field configured in &apos;config_form_fields&apos;</source>
			<translation>Campo configurado en &apos;config_form_fields&apos;</translation>
		</message>
		<message>
			<source>Field update in &apos;config_form_fields&apos;</source>
			<translation>Actualización de Campo en &apos;config_form_fields&apos;</translation>
		</message>
		<message>
			<source>File cannot be created. Check if it is already opened</source>
			<translation>No se puede crear el archivo. Compruebe si ya está abierto</translation>
		</message>
		<message>
			<source>File extension not valid</source>
			<translation>Extensión de archivo no válida</translation>
		</message>
		<message>
			<source>File INP not found</source>
			<translation>Archivo INP no encontrado</translation>
		</message>
		<message>
			<source>File name</source>
			<translation>Nombre del fichero</translation>
		</message>
		<message>
			<source>File name is required</source>
			<translation>El nombre del archivo es obligatorio</translation>
		</message>
		<message>
			<source>File not found</source>
			<translation>No se ha encontrado el archivo</translation>
		</message>
		<message>
			<source>File not found: {0}</source>
			<translation>Archivo no encontrado: {0}</translation>
		</message>
		<message>
			<source>File path doesn&apos;t exist or you dont have permission or file is opened</source>
			<translation>La ruta del archivo no existe, no tiene permiso o el archivo está abierto</translation>
		</message>
		<message>
			<source>File path not found</source>
			<translation>Ruta de archivo no encontrada</translation>
		</message>
		<message>
			<source>File RPT not found</source>
			<translation>Archivo RPT no encontrado</translation>
		</message>
		<message>
			<source>Files defined in environment variables &apos;{0}&apos; and &apos;{1}&apos; not found.</source>
			<translation>Archivos definidos en las variables de entorno &apos;{0}&apos; y &apos;{1}&apos; no encontrados.</translation>
		</message>
		<message>
			<source>File type</source>
			<translation>Tipo de archivo</translation>
		</message>
		<message>
			<source>Fill table</source>
			<translation>Rellenar tabla</translation>
		</message>
		<message>
			<source>Filter</source>
			<translation>Filtro</translation>
		</message>
		<message>
			<source>Filter by code</source>
			<translation>Filtrar por código</translation>
		</message>
		<message>
			<source>Filter by ext_code</source>
			<translation>Filtrar por ext_code</translation>
		</message>
		<message>
			<source>Finished!</source>
			<translation>¡Finalizado!</translation>
		</message>
		<message>
			<source>First node already selected with id: {0}. Select second one.</source>
			<translation>Primer nodo ya seleccionado con id: {0}. Seleccione el segundo.</translation>
		</message>
		<message>
			<source>Flood analysis will start from arc ID</source>
			<translation>El análisis de inundación comenzará desde el ID de arco</translation>
		</message>
		<message>
			<source>Flood analysis will start from node ID</source>
			<translation>El análisis de inundaciones comenzará a partir del ID de nodo</translation>
		</message>
		<message>
			<source>Flow regulators</source>
			<translation>Reguladores de Caudal</translation>
		</message>
		<message>
			<source>Folder not found</source>
			<translation>Carpeta no encontrada</translation>
		</message>
		<message>
			<source>Folder path</source>
			<translation>Ruta de la carpeta</translation>
		</message>
		<message>
			<source>Force commit</source>
			<translation>Forzar compromiso</translation>
		</message>
		<message>
			<source>For mode &apos;{0}&apos;, an result_id must be informed.</source>
			<translation>Para el modo &apos;{0}&apos;, debe informarse un result_id.</translation>
		</message>
		<message>
			<source>For select on canvas is mandatory to load v_asset_arc_input layer</source>
			<translation>Para seleccionar en el lienzo es obligatorio cargar la capa v_asset_arc_input</translation>
		</message>
		<message>
			<source>Function {0} error: {1} from last function is invalid</source>
			<translation>Función {0} error: {1} de la última función no es válida</translation>
		</message>
		<message>
			<source>Function {0} error: {1} returned null</source>
			<translation>Función {0} error: {1} devuelve null</translation>
		</message>
		<message>
			<source>Function {0} error: missing key {1}</source>
			<translation>Función {0} error: falta la tecla {1}</translation>
		</message>
		<message>
			<source>Function {0} failed</source>
			<translation>Función {0} fallida</translation>
		</message>
		<message>
			<source>Function {0} finished successfully</source>
			<translation>Función {0} finalizada con éxito</translation>
		</message>
		<message>
			<source>Function {0} returned {1}</source>
			<translation>La función {0} devuelve {1}</translation>
		</message>
		<message>
			<source>Function error: {0}</source>
			<translation>Error de función: {0}</translation>
		</message>
		<message>
			<source>Function error: gw_fct_setmincut</source>
			<translation>Error de función: gw_fct_setmincut</translation>
		</message>
		<message>
			<source>Function failed finished</source>
			<translation>Fallo de la función finalizada</translation>
		</message>
		<message>
			<source>Function gw_fct_create_dscenario_empty returned no dscenario_id</source>
			<translation>Function gw_fct_create_dscenario_empty returned no dscenario_id</translation>
		</message>
		<message>
			<source>Function gw_fct_psector_duplicate executed with no result</source>
			<translation>La función gw_fct_psector_duplicate se ejecutó sin resultado</translation>
		</message>
		<message>
			<source>Function gw_fct_setfeaturedelete executed with no result </source>
			<translation>Función gw_fct_setfeaturedelete ejecutada sin resultado</translation>
		</message>
		<message>
			<source>Function name</source>
			<translation>Nombre de la función</translation>
		</message>
		<message>
			<source>Function not found</source>
			<translation>No se encontró la función</translation>
		</message>
		<message>
			<source>Function not found in database</source>
			<translation>Función no encontrada en la base de datos</translation>
		</message>
		<message>
			<source>Function not found in database: {0}</source>
			<translation>Función no encontrada en la base de datos: {0}</translation>
		</message>
		<message>
			<source>Generate INP algorithm</source>
			<translation>Generar algoritmo INP</translation>
		</message>
		<message>
			<source>Generating markdown for {0}.</source>
			<translation>Generando markdown para {0}.</translation>
		</message>
		<message>
			<source>Generating markdown from {0}...</source>
			<translation>Generando markdown de {0}...</translation>
		</message>
		<message>
			<source>Generating result stats</source>
			<translation>Generando estadísticas de resultados</translation>
		</message>
		<message>
			<source>Generation of atlas uses ve_plan_psector as coverage layer ordered by atlas_id column. Please update the atlas&apos; coverage layer before continuing.</source>
			<translation>La generación del atlas utiliza ve_plan_psector como capa de cobertura ordenada por la columna atlas_id. Actualice la capa de cobertura del atlas antes de continuar.</translation>
		</message>
		<message>
			<source>Geometry has been added!</source>
			<translation>¡Se ha añadido geometría!</translation>
		</message>
		<message>
			<source>Geometry set correctly.</source>
			<translation>Geometría ajustada correctamente.</translation>
		</message>
		<message>
			<source>Geometry type ({0}) not found in layer: {1}</source>
			<translation>Tipo de geometría ({0}) no encontrado en la capa: {1}</translation>
		</message>
		<message>
			<source>Getting {0} from .{1} file</source>
			<translation>Obteniendo {0} del archivo .{1}</translation>
		</message>
		<message>
			<source>Getting auxiliary data from DB</source>
			<translation>Obteniendo datos auxiliares desde la BD</translation>
		</message>
		<message>
			<source>Getting options</source>
			<translation>Obteniendo opciones</translation>
		</message>
		<message>
			<source>Getting pipe data from DB</source>
			<translation>Obteniendo datos de tuberías desde la BD</translation>
		</message>
		<message>
			<source>Getting units...</source>
			<translation>Obteniendo unidades...</translation>
		</message>
		<message>
			<source>GIS file generated successfully</source>
			<translation>Archivo SIG generado correctamente</translation>
		</message>
		<message>
			<source>GIS file name not set</source>
			<translation>Nombre de archivo SIG no configurado</translation>
		</message>
		<message>
			<source>GIS folder not set</source>
			<translation>Carpeta SIG no configurada</translation>
		</message>
		<message>
			<source>Giswater ({0})</source>
			<translation>Giswater ({0})</translation>
		</message>
		<message>
			<source>Giswater plugin cannot be loaded</source>
			<translation>No se puede cargar el plugin Giswater</translation>
		</message>
		<message>
			<source>GitHub Issues</source>
			<translation>Problemas en GitHub</translation>
		</message>
		<message>
			<source>Go2Epa</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>Go2Epa task is already active!</source>
			<translation>¡La tarea Go2Epa ya está activa!</translation>
		</message>
		<message>
			<source>GO2EPA - Work in progress</source>
			<translation>GO2EPA - En progreso</translation>
		</message>
		<message>
			<source>Go2Iber task is already active!</source>
			<translation>¡La tarea Go2Iber ya está activa!</translation>
		</message>
		<message>
			<source>GO2IBER - Work in progress</source>
			<translation>GO2IBER - Obra en progreso</translation>
		</message>
		<message>
			<source>Group &apos;{0}&apos; not found in layer tree.</source>
			<translation>Grupo &apos;{0}&apos; no encontrado en el árbol de capas.</translation>
		</message>
		<message>
			<source>Gullies</source>
			<translation>Sumideros</translation>
		</message>
		<message>
			<source>Gully to network</source>
			<translation>Imbornal a la red</translation>
		</message>
		<message>
			<source>gw_fct_set_rpt_archived execution failed. See logs for more details...</source>
			<translation>Ha fallado la ejecución de gw_fct_set_rpt_archived. Consulte los registros para obtener más detalles...</translation>
		</message>
		<message>
			<source>Hemisphere of the node has been updated. Value is</source>
			<translation>Se ha actualizado el hemisferio del nodo. El valor es</translation>
		</message>
		<message>
			<source>Here you can choose how the pumps and valves will be imported, either left as arcs (virual arcs) or converted to nodes.</source>
			<translation>Aquí puede elegir cómo se importarán las bombas y válvulas, dejándolas como arcos (arcos virtuales) o convirtiéndolas en nodos.</translation>
		</message>
		<message>
			<source>Here you can choose how the pumps, weirs, orifices, and outlets will be imported, either left as arcs (virual arcs) or converted to flwreg.</source>
			<translation>Aquí puede elegir cómo se importarán las bombas, vertederos, orificios y salidas, dejándolos como arcos (arcos virtuales) o convirtiéndolos a flwreg.</translation>
		</message>
		<message>
			<source>Highlighting large dataset ({0} features) - this may take a moment...</source>
			<translation>Resaltando conjunto de datos grande ({0} elementos) - esto puede tardar un momento...</translation>
		</message>
		<message>
			<source>Hot update completed for {0} schema(s) using language ({1}).</source>
			<translation>Actualización en caliente completada para {0} esquema(s) usando el idioma ({1}).</translation>
		</message>
		<message>
			<source>Hot update finished with errors. Updated: {0}. Failed: {1}.</source>
			<translation>La actualización en caliente ha finalizado con errores. Actualizados: {0}. Fallidos: {1}.</translation>
		</message>
		<message>
			<source>Hot update schemas?</source>
			<translation>¿Actualizar esquemas en caliente?</translation>
		</message>
		<message>
			<source>Hot updating {0}...</source>
			<translation>Actualizando {0} en caliente...</translation>
		</message>
		<message>
			<source>Hydraulic engine imported successfully</source>
			<translation>Motor hidráulico importado con éxito</translation>
		</message>
		<message>
			<source>Hydraulic engine not imported. Using default EPA software.</source>
			<translation>Motor hidráulico no importado. Usando el software EPA por defecto.</translation>
		</message>
		<message>
			<source>Hydrology scenario manager</source>
			<translation>Escenarios hidrológicos</translation>
		</message>
		<message>
			<source>Hydrometer management</source>
			<translation>Gestión de hidrómetros</translation>
		</message>
		<message>
			<source>IBERGIS plugin not found</source>
			<translation>No se ha encontrado el plugin IBERGIS</translation>
		</message>
		<message>
			<source>IBERGIS project imported successfully</source>
			<translation>Proyecto IBERGIS importado con éxito</translation>
		</message>
		<message>
			<source>Id already selected</source>
			<translation>Id ya seleccionado</translation>
		</message>
		<message>
			<source>If not, you can ignore the tab.</source>
			<translation>Si no, puede ignorar la ficha.</translation>
		</message>
		<message>
			<source>If you chose to import the flow regulators as flwreg objects, the sixth tab is where you can select the catalog for each flow regulator (pumps, weirs, orifices, outlets) on the network.</source>
			<translation>Si ha optado por importar los reguladores de caudal como objetos flwreg, en la sexta pestaña podrá seleccionar el catálogo de cada regulador de caudal (bombas, vertederos, orificios, salidas) de la red.</translation>
		</message>
		<message>
			<source>If you have any questions, please contact the Giswater team via</source>
			<translation>Si tiene alguna pregunta, póngase en contacto con el equipo de Giswater a través de</translation>
		</message>
		<message>
			<source>imported</source>
			<translation>importado</translation>
		</message>
		<message>
			<source>Importing conduits</source>
			<translation>Importando conductos</translation>
		</message>
		<message>
			<source>Importing controls</source>
			<translation>Importando controles</translation>
		</message>
		<message>
			<source>Importing controls and rules...</source>
			<translation>Importando controles y reglas...</translation>
		</message>
		<message>
			<source>Importing curves</source>
			<translation>Importando curvas</translation>
		</message>
		<message>
			<source>Importing curves...</source>
			<translation>Importando curvas...</translation>
		</message>
		<message>
			<source>Importing dividers</source>
			<translation>Importando divisores</translation>
		</message>
		<message>
			<source>Importing DWF</source>
			<translation>Importando DWF</translation>
		</message>
		<message>
			<source>Importing files...</source>
			<translation>Importando archivos...</translation>
		</message>
		<message>
			<source>Importing inflows</source>
			<translation>Importando entradas (inflows)</translation>
		</message>
		<message>
			<source>Importing junctions</source>
			<translation>Importando nodos de unión</translation>
		</message>
		<message>
			<source>Importing junctions...</source>
			<translation>Importando empalmes...</translation>
		</message>
		<message>
			<source>Importing LIDs</source>
			<translation>Importando LIDs</translation>
		</message>
		<message>
			<source>Importing options...</source>
			<translation>Importando opciones...</translation>
		</message>
		<message>
			<source>Importing orifices</source>
			<translation>Importando orificios</translation>
		</message>
		<message>
			<source>Importing outfalls</source>
			<translation>Importando salidas (outfalls)</translation>
		</message>
		<message>
			<source>Importing outlets</source>
			<translation>Importando salidas</translation>
		</message>
		<message>
			<source>Importing patterns</source>
			<translation>Importando patrones</translation>
		</message>
		<message>
			<source>Importing patterns...</source>
			<translation>Importando patrones...</translation>
		</message>
		<message>
			<source>Importing pipes...</source>
			<translation>Importando tuberías...</translation>
		</message>
		<message>
			<source>Importing pumps</source>
			<translation>Importando bombas</translation>
		</message>
		<message>
			<source>Importing pumps...</source>
			<translation>Importando bombas...</translation>
		</message>
		<message>
			<source>Importing raingages</source>
			<translation>Importando pluviómetros</translation>
		</message>
		<message>
			<source>Importing reservoirs...</source>
			<translation>Importando depósitos...</translation>
		</message>
		<message>
			<source>Importing sources...</source>
			<translation>Importando fuentes...</translation>
		</message>
		<message>
			<source>Importing storage units</source>
			<translation>Importando unidades de almacenamiento</translation>
		</message>
		<message>
			<source>Importing subcatchments</source>
			<translation>Importando subcuencas</translation>
		</message>
		<message>
			<source>Importing tanks...</source>
			<translation>Importando tanques...</translation>
		</message>
		<message>
			<source>Importing timeseries</source>
			<translation>Importando series temporales</translation>
		</message>
		<message>
			<source>Importing title...</source>
			<translation>Importando título...</translation>
		</message>
		<message>
			<source>Importing valves...</source>
			<translation>Importando válvulas...</translation>
		</message>
		<message>
			<source>Importing weirs</source>
			<translation>Importando vertederos</translation>
		</message>
		<message>
			<source>Import INP</source>
			<translation>Importar INP</translation>
		</message>
		<message>
			<source>IMPORT INP</source>
			<translation>IMPORTAR INP</translation>
		</message>
		<message>
			<source>Import INP is only available on Python 3.10 or higher. Please update your QGIS&apos;s Python version.</source>
			<translation>Importar INP sólo está disponible en Python 3.10 o superior. Por favor, actualice la versión de Python de su QGIS.</translation>
		</message>
		<message>
			<source>Import INP is still in developement. It may not work as intended yet. Please report any unexpected behaviour to the Giswater team.</source>
			<translation>Import INP aún está en desarrollo. Es posible que aún no funcione como está previsto. Por favor, comunique cualquier comportamiento inesperado al equipo de Giswater.</translation>
		</message>
		<message>
			<source>Import INP (TESTING MODE)</source>
			<translation>Importar INP (MODO DE PRUEBA)</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis is only available on Python 3.10 or higher. Please update your QGIS&apos;s Python version.</source>
			<translation>Importar OSM Streetaxis solo está disponible en Python 3.10 o superior. Por favor actualice la versión de Python de su QGIS.</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis its only for WS projects</source>
			<translation>Importar OSM Streetaxis es sólo para proyectos WS</translation>
		</message>
		<message>
			<source>Import results requires Execute EPA software</source>
			<translation>Importar resultados requiere Ejecutar el software EPA</translation>
		</message>
		<message>
			<source>Import RPT file</source>
			<translation>Importar archivo RPT</translation>
		</message>
		<message>
			<source>Import rpt file........: {0}</source>
			<translation>Importar archivo rpt........: {0}</translation>
		</message>
		<message>
			<source>Import RPT file finished.</source>
			<translation>Importar archivo RPT finalizado.</translation>
		</message>
		<message>
			<source>Import RPT file finished. </source>
			<translation>Importación de archivo RPT finalizada.</translation>
		</message>
		<message>
			<source>Import simulation results........: {0}</source>
			<translation>Importar resultados de simulación........: {0}</translation>
		</message>
		<message>
			<source>Import simulation results finished</source>
			<translation>Importación de resultados de simulación finalizada</translation>
		</message>
		<message>
			<source>Import simulation results into database</source>
			<translation>Importar resultados de simulación en la base de datos</translation>
		</message>
		<message>
			<source>Incompatible version of PostgreSQL</source>
			<translation>Versión incompatible de PostgreSQL</translation>
		</message>
		<message>
			<source>Incorrect option ({0}) for scenario {1}.</source>
			<translation>Opción incorrecta ({0}) para el escenario {1}.</translation>
		</message>
		<message>
			<source>Incorrect valve status ({0}) for arc {1}.</source>
			<translation>Estado de válvula incorrecto ({0}) para el Arco {1}.</translation>
		</message>
		<message>
			<source>Incorrect valve status ({0}) for scenario {1}.</source>
			<translation>Estado de válvula incorrecto ({0}) para el escenario {1}.</translation>
		</message>
		<message>
			<source>Info</source>
			<translation>Información</translation>
		</message>
		<message>
			<source>Info Message</source>
			<translation>Mensaje informativo</translation>
		</message>
		<message>
			<source>Information about exception</source>
			<translation>Información sobre la excepción</translation>
		</message>
		<message>
			<source>Initialize plugin</source>
			<translation>Inicializar plugin</translation>
		</message>
		<message>
			<source>In order to create a qgis project you have to create a schema first.</source>
			<translation>Para crear un proyecto qgis, primero hay que crear un esquema.</translation>
		</message>
		<message>
			<source>INP file couldn&apos;t be imported:
{0}</source>
			<translation>No se pudo importar el archivo INP:
{0}</translation>
		</message>
		<message>
			<source>INP file not found</source>
			<translation>Archivo INP no encontrado</translation>
		</message>
		<message>
			<source>Inp Options</source>
			<translation>Opciones Inp</translation>
		</message>
		<message>
			<source>In schema</source>
			<translation>En el esquema</translation>
		</message>
		<message>
			<source>Integrate am</source>
			<translation>Integrar am</translation>
		</message>
		<message>
			<source>Integrate utils requires a WS or UD anchor.</source>
			<translation>Integrar utils requiere un ancla WS o UD.</translation>
		</message>
		<message>
			<source>Interpolate tool.
To modify columns (top_elev, ymax, elev among others) to be interpolated set variable edit_node_interpolate on table config_param_user</source>
			<translation>Herramienta de interpolación.
Para modificar columnas (top_elev, ymax, elev entre otras) a interpolar establezca la variable edit_node_interpolate en la tabla config_param_user</translation>
		</message>
		<message>
			<source>Invalid {0} &apos;{1}&apos; provided. No configuration performed.</source>
			<translation>No válido {0} &apos;{1}&apos; proporcionado. No se ha realizado ninguna configuración.</translation>
		</message>
		<message>
			<source>Invalid arccat_ids: {0}.</source>
			<translation>Arccat_ids inválido: {0}.</translation>
		</message>
		<message>
			<source>Invalid buffer value. Please enter an integer less than 1000.</source>
			<translation>Valor de búfer no válido. Introduzca un número entero inferior a 1000.</translation>
		</message>
		<message>
			<source>Invalid buffer value. Please enter an valid integer.</source>
			<translation>Valor de búfer no válido. Introduzca un número entero válido.</translation>
		</message>
		<message>
			<source>Invalid campaign ID</source>
			<translation>ID de campaña inválido</translation>
		</message>
		<message>
			<source>Invalid campaign mode: {0}</source>
			<translation>Modo de campaña inválido: {0}</translation>
		</message>
		<message>
			<source>Invalid diameters: {1}.</source>
			<translation>Diámetros no válidos: {1}.</translation>
		</message>
		<message>
			<source>Invalid layer:
provider={0}
uri={1}</source>
			<translation>Capa inválida:
provider={0}
uri={1}</translation>
		</message>
		<message>
			<source>Invalid lot ID</source>
			<translation>ID de lote inválido</translation>
		</message>
		<message>
			<source>Invalid materials: {3}.</source>
			<translation>Materiales no válidos: {3}.</translation>
		</message>
		<message>
			<source>Invalid tuple: {0}</source>
			<translation>Tupla inválida: {0}</translation>
		</message>
		<message>
			<source>Invalid value for field</source>
			<translation>Valor no válido para el campo</translation>
		</message>
		<message>
			<source>Invalid value for scenario_results in [OPTIONS] section.</source>
			<translation>Valor no válido para scenario_results en la sección [OPTIONS].</translation>
		</message>
		<message>
			<source>Invalid value for type of priority dialog. Please pass either &apos;GLOBAL&apos; or &apos;SELECTION&apos;. Value passed: {0}</source>
			<translation>Valor inválido para el tipo de diálogo de prioridad. Por favor pase &apos;GLOBAL&apos; o &apos;SELECTION&apos;. Valor pasado: {0}</translation>
		</message>
		<message>
			<source>Invalid WKT string</source>
			<translation>Cadena WKT no válida</translation>
		</message>
		<message>
			<source>Invalid workorder ID</source>
			<translation>ID de orden de trabajo inválido</translation>
		</message>
		<message>
			<source>Invert the current selection in the table</source>
			<translation>Invertir la selección actual en la tabla</translation>
		</message>
		<message>
			<source>Investment (€/year):</source>
			<translation>Inversión (€/año):</translation>
		</message>
		<message>
			<source>is not defined in table cat_feature</source>
			<translation>no está definido en la tabla cat_feature</translation>
		</message>
		<message>
			<source>It will then show the log of the process in the last tab.</source>
			<translation>A continuación, mostrará el registro del proceso en la última pestaña.</translation>
		</message>
		<message>
			<source>IVI</source>
			<translation>IVI</translation>
		</message>
		<message>
			<source>IVI (Horizon year):</source>
			<translation>IVI (año horizonte):</translation>
		</message>
		<message>
			<source>Junctions couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar las Uniones!</translation>
		</message>
		<message>
			<source>KEEP OPERATIVE</source>
			<translation>MANTENER OPERATIVO</translation>
		</message>
		<message>
			<source>Key</source>
			<translation>Clave</translation>
		</message>
		<message>
			<source>Key ({0}) is not unique in the config catalog.</source>
			<translation>La clave ({0}) no es única en el catálogo de configuración.</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE columname=&apos;{0}&apos; AND widgetname=&apos;{1}&apos;</source>
			<translation>key &apos;comboIds&apos; or/and comboNames not found WHERE columname=&apos;{0}&apos; AND widgetname=&apos;{1}&apos;</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE widgetname=&apos;{0}&apos; AND widgettype=&apos;{1}&apos;</source>
			<translation>key &apos;comboIds&apos; or/and comboNames not found WHERE widgetname=&apos;{0}&apos; AND widgettype=&apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Key container</source>
			<translation>Contenedor de llaves</translation>
		</message>
		<message>
			<source>Key not found</source>
			<translation>Clave no encontrada</translation>
		</message>
		<message>
			<source>Key on returned json from ddbb is missed</source>
			<translation>No existe la clave en el JSON recuperado de la BD</translation>
		</message>
		<message>
			<source>Key on returned json from ddbb is missed.</source>
			<translation>Falta la clave en el json devuelto por ddbb.</translation>
		</message>
		<message>
			<source>Kind</source>
			<translation>Clase</translation>
		</message>
		<message>
			<source>Language</source>
			<translation>Idioma</translation>
		</message>
		<message>
			<source>Language: {0}</source>
			<translation>Idioma: {0}</translation>
		</message>
		<message>
			<source>Language ({0}) is in use and cannot be deleted. Used by: {1}</source>
			<translation>El idioma ({0}) está en uso y no puede eliminarse. Usado por: {1}</translation>
		</message>
		<message>
			<source>Language ({0}) is used by {1} schema(s): {2}. Do you want to hot update them now?</source>
			<translation>El idioma ({0}) es utilizado por {1} esquema(s): {2}. ¿Desea actualizarlos en caliente ahora?</translation>
		</message>
		<message>
			<source>Language files</source>
			<translation>Archivos de idioma</translation>
		</message>
		<message>
			<source>Language files deleted and locale deactivated ({0}).</source>
			<translation>Archivos de idioma eliminados y locale desactivado ({0}).</translation>
		</message>
		<message>
			<source>Language files downloaded and locale activated ({0}).</source>
			<translation>Archivos de idioma descargados y locale activado ({0}).</translation>
		</message>
		<message>
			<source>Language files updated and locale activated ({0}).</source>
			<translation>Archivos de idioma actualizados y localidad activada ({0}).</translation>
		</message>
		<message>
			<source>Language provision cancel failed: {0}</source>
			<translation>Error al cancelar la provisión de idioma: {0}</translation>
		</message>
		<message>
			<source>Language provision pre-check failed: {0}</source>
			<translation>Comprobación previa de provisión de idioma fallida: {0}</translation>
		</message>
		<message>
			<source>Last update</source>
			<translation>Última actualización</translation>
		</message>
		<message>
			<source>Layer {0} does not found, therefore, not configured</source>
			<translation>Capa {0} no encontrada, por lo tanto, no configurada</translation>
		</message>
		<message>
			<source>Layer &apos;{0}&apos; is None and settings is None</source>
			<translation>La capa &apos;{0}&apos; es None y los ajustes son None</translation>
		</message>
		<message>
			<source>Layer &apos;{0}&apos; not found in QGIS.</source>
			<translation>Capa &apos;{0}&apos; no encontrada en QGIS.</translation>
		</message>
		<message>
			<source>Layer failed to load!</source>
			<translation>¡La capa no se pudo cargar!</translation>
		</message>
		<message>
			<source>Layer is broken</source>
			<translation>La capa está dañada</translation>
		</message>
		<message>
			<source>Layer not found</source>
			<translation>No se encontró la capa</translation>
		</message>
		<message>
			<source>Layer of CM project will be added to the project when create</source>
			<translation>La Capa del Proyecto CM se añadirá al Proyecto cuando se cree</translation>
		</message>
		<message>
			<source>Layout not found</source>
			<translation>Diseño no encontrado</translation>
		</message>
		<message>
			<source>layoutorder not found.</source>
			<translation>layoutorder no encontrado.</translation>
		</message>
		<message>
			<source>LIDS</source>
			<translation>LIDS</translation>
		</message>
		<message>
			<source>Line number</source>
			<translation>Número de línea</translation>
		</message>
		<message>
			<source>Linked</source>
			<translation>Vinculado</translation>
		</message>
		<message>
			<source>Locale</source>
			<translation>Configuración regional</translation>
		</message>
		<message>
			<source>Locale not found</source>
			<translation>Localización no encontrada</translation>
		</message>
		<message>
			<source>Locales seed file not found</source>
			<translation>Archivo seed de locales no encontrado</translation>
		</message>
		<message>
			<source>Log file</source>
			<translation>Archivo de registro</translation>
		</message>
		<message>
			<source>Lot ID not found.</source>
			<translation>ID de lote no encontrado.</translation>
		</message>
		<message>
			<source>Manage languages</source>
			<translation>Gestionar idiomas</translation>
		</message>
		<message>
			<source>Managing nodarcs (pumps/valves as nodes)...</source>
			<translation>Gestionando nodarcs (bombas/válvulas como nodos)...</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please, set a value</source>
			<translation>Falta el campo obligatorio. Por favor, establezca un valor</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please, set a value for field</source>
			<translation>Falta un campo obligatorio. Por favor, introduzca un valor para el campo</translation>
		</message>
		<message>
			<source>Map item &apos;Mapa&apos; not found in template. Template may be empty or use different item IDs.</source>
			<translation>Elemento del Mapa &apos;Mapa&apos; no encontrado en la plantilla. La plantilla puede estar vacía o usar IDs de elemento diferentes.</translation>
		</message>
		<message>
			<source>Mapzone config - {0}</source>
			<translation>Configuración Mapzone - {0}</translation>
		</message>
		<message>
			<source>Mapzone config - {0} (Netscenario {1})</source>
			<translation>Configuración de Mapzone - {0} (Netscenario {1})</translation>
		</message>
		<message>
			<source>Mapzone dynamic widgets not found: {0}</source>
			<translation>Widgets dinámicos de mapzone no encontrados: {0}</translation>
		</message>
		<message>
			<source>Mapzone manager dynamic config not found.</source>
			<translation>Configuración dinámica del gestor de Mapzone no encontrada.</translation>
		</message>
		<message>
			<source>Mapzone manager tabs not configured in DB.</source>
			<translation>Las pestañas del gestor de Mapzone no están configuradas en la BD.</translation>
		</message>
		<message>
			<source>Mapzones analysis completed successfully.</source>
			<translation>Análisis de Mapzones completado con éxito.</translation>
		</message>
		<message>
			<source>Markdown Generated from {0}.</source>
			<translation>Markdown generado a partir de {0}.</translation>
		</message>
		<message>
			<source>Marked values must be greater than 0</source>
			<translation>Los valores marcados deben ser superiores a 0</translation>
		</message>
		<message>
			<source>Material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>Max. Longevity</source>
			<translation>Longevidad máxima</translation>
		</message>
		<message>
			<source>Med. Longevity</source>
			<translation>Longevidad media</translation>
		</message>
		<message>
			<source>Merge</source>
			<translation>Fusionar</translation>
		</message>
		<message>
			<source>Merge requires at least 2 psectors to be selected</source>
			<translation>La fusión necesita por lo menos tener 2 sectores seleccionados</translation>
		</message>
		<message>
			<source>Message</source>
			<translation>Mensaje</translation>
		</message>
		<message>
			<source>Message error</source>
			<translation>Error de mensaje</translation>
		</message>
		<message>
			<source>Mincut canceled!</source>
			<translation>¡Mincut cancelado!</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict and overlaps with</source>
			<translation>Polígono de corte generado pero tiene conflicto y se superpone con</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict and overlaps with other mincuts</source>
			<translation>Mincut realizado, pero tiene conflicto y se solapa con otros mincuts</translation>
		</message>
		<message>
			<source>Mincut done successfully</source>
			<translation>Polígono de corte generado con éxito</translation>
		</message>
		<message>
			<source>Mincut execute</source>
			<translation>Ejecutar mincut</translation>
		</message>
		<message>
			<source>Mincut task is already active!</source>
			<translation>¡La tarea polígono de corte ya está activa!</translation>
		</message>
		<message>
			<source>Min. Longevity</source>
			<translation>Longevidad mínima</translation>
		</message>
		<message>
			<source>...min_message_level</source>
			<translation>...min_message_level</translation>
		</message>
		<message>
			<source>Missing Data</source>
			<translation>Datos faltantes</translation>
		</message>
		<message>
			<source>Missing required fields</source>
			<translation>Faltan campos obligatorios</translation>
		</message>
		<message>
			<source>More than one event selected. Select just one</source>
			<translation>Más de un evento seleccionado. Seleccione solo uno</translation>
		</message>
		<message>
			<source>More then one document selected. Select just one document.</source>
			<translation>Más de un documento seleccionado. Seleccione sólo un documento.</translation>
		</message>
		<message>
			<source>Move node: Error updating geometry</source>
			<translation>Mover nodo: error al actualizar la geometría</translation>
		</message>
		<message>
			<source>Multilang function failed</source>
			<translation>Función multilenguaje fallida</translation>
		</message>
		<message>
			<source>Multilang function failed.</source>
			<translation>La función multilenguaje falló.</translation>
		</message>
		<message>
			<source>Multilang function failed. SQL: {0}</source>
			<translation>Función multilenguaje fallida. SQL: {0}</translation>
		</message>
		<message>
			<source>Multilang function response</source>
			<translation>Respuesta de función multilenguaje</translation>
		</message>
		<message>
			<source>Multilang function returned an invalid JSON response.</source>
			<translation>La función Multilang devolvió una respuesta JSON inválida.</translation>
		</message>
		<message>
			<source>Multilang function returned unexpected status</source>
			<translation>La función multilenguaje devolvió un estado inesperado</translation>
		</message>
		<message>
			<source>Multilang function SQL failed</source>
			<translation>Falló SQL de la función multilenguaje</translation>
		</message>
		<message>
			<source>Multilang language currently used: {0}.</source>
			<translation>Idioma multilenguaje actualmente usado: {0}.</translation>
		</message>
		<message>
			<source>Multilang language delete completed for {0}.</source>
			<translation>Eliminación de idioma Multilang completada para {0}.</translation>
		</message>
		<message>
			<source>Multilang on_done callback raised: {0}</source>
			<translation>Callback multilenguaje on_done mostró: {0}</translation>
		</message>
		<message>
			<source>Multilang SchemaBuilder exception: {0}</source>
			<translation>Excepción de SchemaBuilder multilang: {0}</translation>
		</message>
		<message>
			<source>Multilang schema build failed: {0}</source>
			<translation>Error en la construcción del esquema multilenguaje: {0}</translation>
		</message>
		<message>
			<source>Multilang schema is not available on this connection.</source>
			<translation>El esquema multilenguaje no está disponible en esta conexión.</translation>
		</message>
		<message>
			<source>Multilang schema task failed during baseline seed.</source>
			<translation>La tarea de esquema multilang falló durante la semilla inicial.</translation>
		</message>
		<message>
			<source>Multilang seed failed for project_type {0}: {1}</source>
			<translation>Falló la siembra multilenguaje para project_type {0}: {1}</translation>
		</message>
		<message>
			<source>Multilang seed: no baseline SQL for project_type={0} (lang={1}); skipping.</source>
			<translation>Multilang seed: no hay SQL base para project_type={0} (lang={1}); omitiendo.</translation>
		</message>
		<message>
			<source>Multilang seed: no project types with bundled baselines detected; only cat_language ensured for {0}.</source>
			<translation>Multilang seed: no project types with bundled baselines detected; only cat_language ensured for {0}.</translation>
		</message>
		<message>
			<source>Multilang seed: no project types with bundled baselines detected; skipping import.</source>
			<translation>Semilla Multilang: no se detectaron tipos de proyecto con baselines integradas; saltando importación.</translation>
		</message>
		<message>
			<source>Multilang translations deleted and locale deactivated ({0}).</source>
			<translation>Traducciones multilenguaje eliminadas y locale desactivado ({0}).</translation>
		</message>
		<message>
			<source>Multilang translations seeded and locale activated ({0}).</source>
			<translation>Traducciones multilang inicializadas y locale activado ({0}).</translation>
		</message>
		<message>
			<source>Multilang translations updated ({0}).</source>
			<translation>Traducciones Multilang actualizadas ({0}).</translation>
		</message>
		<message>
			<source>Multilang user parameter provisioning</source>
			<translation>Provisionamiento de parámetros multilenguaje de usuario</translation>
		</message>
		<message>
			<source>Multilang user parameter rollback failed.</source>
			<translation>Reversión de parámetro de usuario Multilang fallida.</translation>
		</message>
		<message>
			<source>Multilang views provisioning</source>
			<translation>Provisionamiento de vistas multilenguaje</translation>
		</message>
		<message>
			<source>Multilang views rollback failed.</source>
			<translation>Reversión de vistas Multilang fallida.</translation>
		</message>
		<message>
			<source>Multiple psectors selected. Please select only one.</source>
			<translation>Se han seleccionado varios sectores. Seleccione sólo uno.</translation>
		</message>
		<message>
			<source>Municipality</source>
			<translation>Municipio</translation>
		</message>
		<message>
			<source>Municipality with ID: {0} deleted from selection</source>
			<translation>Municipio con ID: {0} eliminado de la selección</translation>
		</message>
		<message>
			<source>Municipality with id[{0}] is already imported on om_streetaxis.
Do you want to overwrite it?
(This decision will not cancel the other selections, the process will keep running)</source>
			<translation>El municipio con id[{0}] ya está importado en om_streetaxis.
¿Desea sobrescribirlo?
(Esta decisión no cancelará las demás selecciones, el proceso continuará ejecutándose)</translation>
		</message>
		<message>
			<source>Name</source>
			<translation>Nombre</translation>
		</message>
		<message>
			<source>New {0}</source>
			<translation>Nuevo {0}</translation>
		</message>
		<message>
			<source>New catalog name</source>
			<translation>Nombre del nuevo catálogo</translation>
		</message>
		<message>
			<source>New feature type is null. Please, select a valid value</source>
			<translation>El nuevo tipo de objeto es nulo. Por favor, seleccione un valor válido</translation>
		</message>
		<message>
			<source>New feature type is null. Please, select a valid value.</source>
			<translation>El nuevo tipo de objeto es nulo. Por favor, seleccione un valor válido.</translation>
		</message>
		<message>
			<source>Next</source>
			<translation>Siguiente</translation>
		</message>
		<message>
			<source>n must be at least one</source>
			<translation>n debe ser al menos uno</translation>
		</message>
		<message>
			<source>No action found</source>
			<translation>No se ha encontrado ninguna acción</translation>
		</message>
		<message>
			<source>No active locales configured</source>
			<translation>No hay locales activos configurados</translation>
		</message>
		<message>
			<source>No arc ID found at the snapped location.</source>
			<translation>No se encontró ID de arco en la ubicación ajustada.</translation>
		</message>
		<message>
			<source>No campaign selected</source>
			<translation>No hay campaña seleccionada</translation>
		</message>
		<message>
			<source>No changes to save.</source>
			<translation>No hay cambios para Guardar.</translation>
		</message>
		<message>
			<source>No composers found.</source>
			<translation>No se encontraron compositores.</translation>
		</message>
		<message>
			<source>No current psector selected</source>
			<translation>No se ha seleccionado ningún sector</translation>
		</message>
		<message>
			<source>Nodarcs</source>
			<translation>Nodarcs</translation>
		</message>
		<message>
			<source>No database connection available for hydraulic engine export</source>
			<translation>No hay conexión a la Base de datos disponible para exportación del motor hidráulico</translation>
		</message>
		<message>
			<source>Node {0} duplicated in config file.</source>
			<translation>Nodo {0} duplicado en el archivo de configuración.</translation>
		</message>
		<message>
			<source>node1 and node2 are required for profile interpolation.</source>
			<translation>node1 y node2 son requeridos para la interpolación del perfil.</translation>
		</message>
		<message>
			<source>Node 1 selected</source>
			<translation>Nodo 1 seleccionado</translation>
		</message>
		<message>
			<source>Node 2 selected</source>
			<translation>Nodo 2 seleccionado</translation>
		</message>
		<message>
			<source>Node already selected</source>
			<translation>Nodo ya seleccionado</translation>
		</message>
		<message>
			<source>Node id:</source>
			<translation>Id. de nodo:</translation>
		</message>
		<message>
			<source>Node ID for {0} not found!</source>
			<translation>¡ID de Nodo para {0} no encontrado!</translation>
		</message>
		<message>
			<source>Node layer not found in the project.</source>
			<translation>Capa de Nodo no encontrada en el Proyecto.</translation>
		</message>
		<message>
			<source>Node not found: {0}</source>
			<translation>Nodo no encontrado: {0}</translation>
		</message>
		<message>
			<source>Node selected</source>
			<translation>Nodo seleccionado</translation>
		</message>
		<message>
			<source>Node set correctly</source>
			<translation>Nodo establecido correctamente</translation>
		</message>
		<message>
			<source>No document selected.</source>
			<translation>Ningún documento seleccionado.</translation>
		</message>
		<message>
			<source>No EPA results found. You must first simulate with Go2Epa.</source>
			<translation>No se encontraron resultados EPA. Debe simular primero con Go2Epa.</translation>
		</message>
		<message>
			<source>No event provided for point selection</source>
			<translation>No se ha previsto ningún evento para la selección de puntos</translation>
		</message>
		<message>
			<source>No features found in the selection for {0}.</source>
			<translation>No se encontraron elementos en la selección para {0}.</translation>
		</message>
		<message>
			<source>No features found in the selection for the enabled tabs ({0}).</source>
			<translation>No se encontraron elementos en la selección para las pestañas activadas ({0}).</translation>
		</message>
		<message>
			<source>NO FEATURE TYPE DEFINED</source>
			<translation>NO SE HA DEFINIDO NINGÚN TIPO DE OBJETO</translation>
		</message>
		<message>
			<source>No help file found</source>
			<translation>No se encontró ningún archivo de ayuda</translation>
		</message>
		<message>
			<source>No link in common between network and scenario {0}.</source>
			<translation>No hay enlace en común entre la red y el escenario {0}.</translation>
		</message>
		<message>
			<source>No listValues for</source>
			<translation>No hay listValues para</translation>
		</message>
		<message>
			<source>No local i18n baseline SQL found for ({0}). Download plugin language files first.</source>
			<translation>No se encontró SQL local de referencia i18n para ({0}). Descargue primero los archivos de idioma del complemento.</translation>
		</message>
		<message>
			<source>No local SQL files found for language ({0}). Download them first.</source>
			<translation>No se encontraron archivos SQL locales para el idioma ({0}). Descárguelos primero.</translation>
		</message>
		<message>
			<source>No municipalities selected</source>
			<translation>Ningún municipio seleccionado</translation>
		</message>
		<message>
			<source>No new features to insert. All selected features already exist in the table.</source>
			<translation>No hay nuevos elementos para insertar. Todos los objetos seleccionados ya existen en la tabla.</translation>
		</message>
		<message>
			<source>No node ID found at the snapped location.</source>
			<translation>No se ha encontrado ningún ID de nodo en la ubicación ajustada.</translation>
		</message>
		<message>
			<source>Non-visual objects</source>
			<translation>Objetos no visuales</translation>
		</message>
		<message>
			<source>No parameters found in section {0}</source>
			<translation>No se encontraron parámetros en la sección {0}</translation>
		</message>
		<message>
			<source>No pictures for this event.</source>
			<translation>No hay fotos de este evento.</translation>
		</message>
		<message>
			<source>No pipes found matching your budget. (Hint: increase the yearly budget or/and the horizon year)</source>
			<translation>No se encontraron tuberías que coincidan con su Presupuesto. (Sugerencia: aumente el presupuesto anual y/o el año horizonte)</translation>
		</message>
		<message>
			<source>No pipes found matching your selected filters.</source>
			<translation>No se encontraron tuberías que coincidan con sus filtros seleccionados.</translation>
		</message>
		<message>
			<source>No primary key value set</source>
			<translation>No se ha establecido ningún valor de clave principal</translation>
		</message>
		<message>
			<source>No psector selected. Please select at least one.</source>
			<translation>No se ha seleccionado ningún sector. Por favor, seleccione al menos uno.</translation>
		</message>
		<message>
			<source>No psector values</source>
			<translation>Sin valores psectoriales</translation>
		</message>
		<message>
			<source>No records selected</source>
			<translation>No hay registros seleccionados</translation>
		</message>
		<message>
			<source>No results</source>
			<translation>Sin resultados</translation>
		</message>
		<message>
			<source>No results found. Please check values set on selector of state and exploitation</source>
			<translation>No se han encontrado resultados. Verifique los valores establecidos en el selector de estado y explotacion</translation>
		</message>
		<message>
			<source>No results returned from the database.</source>
			<translation>No se devolvieron resultados desde la base de datos.</translation>
		</message>
		<message>
			<source>No snapshots available. Please create a snapshot first or wait for tomorrow to travel since today.</source>
			<translation>No hay instantáneas disponibles. Por favor, cree primero una instantánea o espere a mañana para viajar desde hoy.</translation>
		</message>
		<message>
			<source>No SQL context available.</source>
			<translation>No hay contexto SQL disponible.</translation>
		</message>
		<message>
			<source>No teams available to switch to.</source>
			<translation>No hay equipos disponibles para cambiar.</translation>
		</message>
		<message>
			<source>Not found: {0}</source>
			<translation>No se ha encontrado: {0}</translation>
		</message>
		<message>
			<source>No URI builder for provider: {0}</source>
			<translation>No hay constructor de URI para el proveedor: {0}</translation>
		</message>
		<message>
			<source>No valid data received from the SQL function.</source>
			<translation>No se han recibido datos válidos de la función SQL.</translation>
		</message>
		<message>
			<source>No valid psector IDs found</source>
			<translation>No se encontraron IDs de psector válidos.</translation>
		</message>
		<message>
			<source>No valid snapping result. Please select a valid arc.</source>
			<translation>No hay resultado de snap válido. Por favor seleccione un arco válido.</translation>
		</message>
		<message>
			<source>No valid snapping result. Please select a valid point.</source>
			<translation>No hay ningún resultado válido. Por favor, seleccione un punto válido.</translation>
		</message>
		<message>
			<source>No visit values</source>
			<translation>Ningún valor de visita</translation>
		</message>
		<message>
			<source>No workcat values</source>
			<translation>No hay valores de workcat</translation>
		</message>
		<message>
			<source>object_1 and object_2 are required.</source>
			<translation>object_1 y object_2 son obligatorios.</translation>
		</message>
		<message>
			<source>object_1 and object_2 must be different.</source>
			<translation>object_1 y object_2 deben ser diferentes.</translation>
		</message>
		<message>
			<source>object_1 and object_2 must be numeric node ids.</source>
			<translation>object_1 y object_2 deben ser ids numéricos de Nodo.</translation>
		</message>
		<message>
			<source>Object already associated with this feature</source>
			<translation>Objeto ya asociado con ese elemento de red</translation>
		</message>
		<message>
			<source>Object id not found</source>
			<translation>Id de objeto no encontrado</translation>
		</message>
		<message>
			<source>Offline mincut failed (gw_fct_getmincutminsector)</source>
			<translation>mincut sin conexión falló (gw_fct_getmincutminsector)</translation>
		</message>
		<message>
			<source>Once you have configured all the necessary catalogs, you can click on the &apos;Accept&apos; button to start the import process.</source>
			<translation>Una vez que haya configurado todos los catálogos necesarios, puede hacer clic en el botón &quot;Aceptar&quot; para iniciar el proceso de importación.</translation>
		</message>
		<message>
			<source>Only FRELEM can be added to dscenario</source>
			<translation>Sólo FRELEM puede añadirse a dscenario</translation>
		</message>
		<message>
			<source>Only one record can be selected</source>
			<translation>Sólo se puede seleccionar un registro</translation>
		</message>
		<message>
			<source>Only PARTIAL or COMPLETED results can be validated</source>
			<translation>Solo resultados PARCIALES o COMPLETADOS pueden ser validados</translation>
		</message>
		<message>
			<source>Only rows with values are allowed to be deleted.</source>
			<translation>Sólo se permite borrar las filas con valores.</translation>
		</message>
		<message>
			<source>Open</source>
			<translation>Abrir</translation>
		</message>
		<message>
			<source>Open Manage Schemas to create and integrate am</source>
			<translation>Abra Gestionar Esquemas para crear e integrar am</translation>
		</message>
		<message>
			<source>Option &apos;{0}&apos; in scenario {1} must have 2 values.</source>
			<translation>La opción &apos;{0}&apos; en el escenario {1} debe tener 2 valores.</translation>
		</message>
		<message>
			<source>or</source>
			<translation>o</translation>
		</message>
		<message>
			<source>Orifice</source>
			<translation>Orificio</translation>
		</message>
		<message>
			<source>Orifices couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar los orificios!</translation>
		</message>
		<message>
			<source>Other catalogs:</source>
			<translation>Otros catálogos:</translation>
		</message>
		<message>
			<source>Other feature ids:</source>
			<translation>Otros ids de elemento:</translation>
		</message>
		<message>
			<source>Other materials:</source>
			<translation>Otros materiales:</translation>
		</message>
		<message>
			<source>Others</source>
			<translation>Otros</translation>
		</message>
		<message>
			<source>our website</source>
			<translation>nuestro sitio web</translation>
		</message>
		<message>
			<source>Outfalls couldn&apos;t be inserted!</source>
			<translation>Salidas no pudieron ser insertadas!</translation>
		</message>
		<message>
			<source>Outlet</source>
			<translation>Salida</translation>
		</message>
		<message>
			<source>Outlets couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar las salidas!</translation>
		</message>
		<message>
			<source>Overwrite</source>
			<translation>Sobrescribir</translation>
		</message>
		<message>
			<source>Overwrite file</source>
			<translation>Sobrescribir archivo</translation>
		</message>
		<message>
			<source>Overwrite values</source>
			<translation>Sobrescribir valores</translation>
		</message>
		<message>
			<source>Page not found.</source>
			<translation>Página no encontrada.</translation>
		</message>
		<message>
			<source>Parameter &apos;{0}&apos; is None</source>
			<translation>El parámetro &apos;{0}&apos; es Ninguno</translation>
		</message>
		<message>
			<source>Parameter button_function is null for button</source>
			<translation>El parámetro button_function es nulo para el botón</translation>
		</message>
		<message>
			<source>Parameter functionName is null for button</source>
			<translation>El parámetro functionName es nulo para el botón</translation>
		</message>
		<message>
			<source>Parameter functionName is null for check</source>
			<translation>El parámetro functionName es nulo para la comprobación</translation>
		</message>
		<message>
			<source>Parameter not found: {parameter}</source>
			<translation>Parámetro no encontrado: {parámetro}</translation>
		</message>
		<message>
			<source>Parameter &apos;Query text:&apos; is mandatory for &apos;combo&apos; widgets. Please set value.</source>
			<translation>El parámetro &apos;Texto de consulta:&apos; es obligatorio para los componentes &apos;combo&apos;. Por favor, establezca el valor.</translation>
		</message>
		<message>
			<source>Parameter widgetfunction is null for widget hyperlink</source>
			<translation>El parámetro widgetfunction es nulo para el hipervínculo del componente</translation>
		</message>
		<message>
			<source>Parameter widgetfunction not found for widget type hyperlink</source>
			<translation>No se encontró la función de widget de parámetro para el tipo de componente hipervínculo</translation>
		</message>
		<message>
			<source>Parent ID does not exist.</source>
			<translation>El ID padre no existe.</translation>
		</message>
		<message>
			<source>Parent ID must be an integer.</source>
			<translation>El ID padre debe ser un entero.</translation>
		</message>
		<message>
			<source>Parse INP task</source>
			<translation>Analizar tarea INP</translation>
		</message>
		<message>
			<source>Parsing error fixed</source>
			<translation>Error de análisis sintáctico corregido</translation>
		</message>
		<message>
			<source>PgRouting version</source>
			<translation>Versión de PgRouting</translation>
		</message>
		<message>
			<source>pgRouting version is not compatible with Giswater. Please check wiki</source>
			<translation>La versión de pgRouting no es compatible con Giswater. Consulte la wiki</translation>
		</message>
		<message>
			<source>PIPE</source>
			<translation>TUBERÍA</translation>
		</message>
		<message>
			<source>Pipes couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar las Tuberías!</translation>
		</message>
		<message>
			<source>Pipes with invalid arccat_ids: {0}.</source>
			<translation>Tuberías con arccat_ids inválidos: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid arccat_ids: {0}.
Invalid arccat_ids: {1}.

An arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.

Do you want to proceed?</source>
			<translation>Tuberías con arccat_ids inválidos: {0}.
arccat_ids inválidos: {1}.

Se considera que un arccat_id es inválido si no está listado en la tabla de configuración del catálogo. Como resultado, estas tuberías NO recibirán un valor de prioridad.

¿Desea continuar?</translation>
		</message>
		<message>
			<source>Pipes with invalid diameters: {0}.</source>
			<translation>Tuberías con diámetros no válidos: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid diameters: {0}.
Invalid diameters: {1}.

A diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.

Do you want to proceed?</source>
			<translation>Tuberías con diámetros inválidos: {0}.
Diámetros inválidos: {1}.

Se considera que un valor de Diámetro es inválido si es cero, negativo, NULL o mayor que el diámetro máximo en la tabla de configuración. Como resultado, estas tuberías NO recibirán un valor de prioridad.

¿Desea continuar?</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {0}.qtd</source>
			<translation>Tuberías con materiales no válidos: {0}.qtd</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {2}.</source>
			<translation>Tuberías con materiales no válidos: {2}.</translation>
		</message>
		<message>
			<source>Pipes with invalid pressures: {0}.
These pipes have no pressure information for their nodes. This will result in them receiving the maximum longevity value for their material, which may affect the final priority value.

Do you want to proceed?</source>
			<translation>Tuberías con presiones inválidas: {0}.
Estas tuberías no tienen información de Presión para sus Nodos. Esto resultará en que reciban el valor máximo de longevidad para su Material, lo que puede afectar el valor final de prioridad.

¿Desea continuar?</translation>
		</message>
		<message>
			<source>Planified features cannot be replaced</source>
			<translation>Las características planificadas no pueden sustituirse</translation>
		</message>
		<message>
			<source>Plan psector - {0} ({1})</source>
			<translation>Plan psector - {0} ({1})</translation>
		</message>
		<message>
			<source>Please choose a csv file</source>
			<translation>Elija un archivo CSV</translation>
		</message>
		<message>
			<source>Please choose a different name.</source>
			<translation>Por favor, elija un nombre diferente.</translation>
		</message>
		<message>
			<source>Please choose a valid path</source>
			<translation>Elija una ruta válida</translation>
		</message>
		<message>
			<source>Please close all &apos;Psector manager&apos; dialogs and try again</source>
			<translation>Por favor cierre todos los diálogos de &apos;Psector manager&apos; e intente de nuevo</translation>
		</message>
		<message>
			<source>Please enter a demands dscenario name to proceed with this import.</source>
			<translation>Por favor, introduzca un nombre de escenario de demanda para proceder con esta importación.</translation>
		</message>
		<message>
			<source>Please enter a new catalog name when the &quot;{0}&quot; option is selected.</source>
			<translation>Por favor, introduzca un nuevo nombre de catálogo cuando la opción &quot;{0}&quot; esté seleccionada.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the built date range.</source>
			<translation>Introduzca un número entero válido para el intervalo de fechas de construcción.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the cluster length.</source>
			<translation>Por favor introduzca un número entero válido para la longitud del clúster.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the maximum distance.</source>
			<translation>Por favor, introduzca un número entero válido para la distancia máxima.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the number of years.</source>
			<translation>Por favor, introduzca un número entero válido para el número de años.</translation>
		</message>
		<message>
			<source>Please enter a valid number.</source>
			<translation>Por favor ingrese un número válido.</translation>
		</message>
		<message>
			<source>Please enter a valid number for the budget.</source>
			<translation>Introduzca un número válido para el presupuesto.</translation>
		</message>
		<message>
			<source>Please enter a valid target year.</source>
			<translation>Por favor, introduzca un año horizonte válido</translation>
		</message>
		<message>
			<source>Please enter a Workcat_id to proceed with this import.</source>
			<translation>Por favor, introduzca un Workcat_id para proceder con esta importación.</translation>
		</message>
		<message>
			<source>Please enter the diameter range in this format: [minimum factor]-[maximum factor]. For example, 0.75-1.5</source>
			<translation>Por favor, introduzca el intervalo de diámetros en este formato: [factor mínimo]-[factor máximo]. Por ejemplo, 0.75-1.5</translation>
		</message>
		<message>
			<source>Please fill all mandatory fields (highlighted in red).</source>
			<translation>Por favor complete todos los campos obligatorios (resaltados en rojo).</translation>
		</message>
		<message>
			<source>Please fill link catalog field in the dialog</source>
			<translation>Rellene el campo del catálogo de enlaces en el cuadro de diálogo</translation>
		</message>
		<message>
			<source>Please provide a result name.</source>
			<translation>Por favor indique el nombre del resultado.</translation>
		</message>
		<message>
			<source>Please select a catalog item for all elements in the tabs: Features, Nodes, Arcs, Materials.</source>
			<translation>Seleccione un elemento del catálogo para todos los elementos de las pestañas: Características, Nodos, Arcos, Materiales.</translation>
		</message>
		<message>
			<source>Please select a catalog item for all elements in the tabs: Nodes, Arcs, Materials, Features.</source>
			<translation>Seleccione un elemento del catálogo para todos los elementos de las fichas: Nodos, Arcos, Materiales, Características.</translation>
		</message>
		<message>
			<source>Please select a category to update.</source>
			<translation>Por favor, seleccione una categoría para actualizar</translation>
		</message>
		<message>
			<source>Please select a default raingage to proceed with this import.</source>
			<translation>Por favor, seleccione un raingage por defecto para proceder con esta importación.</translation>
		</message>
		<message>
			<source>Please, select a diferent project name than current.</source>
			<translation>Por favor, seleccione un nombre de proyecto diferente al actual.</translation>
		</message>
		<message>
			<source>Please select a feature to add</source>
			<translation>Seleccione la función que desea añadir</translation>
		</message>
		<message>
			<source>Please select a lot to open</source>
			<translation>Por favor seleccione un lote para abrir</translation>
		</message>
		<message>
			<source>Please select a municipality to proceed with this import.</source>
			<translation>Seleccione un municipio para proceder a la importación.</translation>
		</message>
		<message>
			<source>Please select an element to zoom to.</source>
			<translation>Por favor seleccione un Elemento para hacer zoom.</translation>
		</message>
		<message>
			<source>Please select an exploitation to proceed with this import.</source>
			<translation>Seleccione una explotación para proceder a esta importación.</translation>
		</message>
		<message>
			<source>Please, select a project to delete</source>
			<translation>Por favor, seleccione el proyecto que desea eliminar</translation>
		</message>
		<message>
			<source>Please, select a project to rename</source>
			<translation>Por favor, seleccione un Proyecto para renombrar</translation>
		</message>
		<message>
			<source>Please select a result and an export path.</source>
			<translation>Por favor seleccione un resultado y una ruta de exportación.</translation>
		</message>
		<message>
			<source>Please select a result with not empty type</source>
			<translation>Por favor seleccione un resultado con tipo no vacío</translation>
		</message>
		<message>
			<source>Please select a row first</source>
			<translation>Por favor seleccione una fila primero</translation>
		</message>
		<message>
			<source>Please select a sector to proceed with this import.</source>
			<translation>Seleccione un sector para proceder a la importación.</translation>
		</message>
		<message>
			<source>Please select a style group before adding a new style.</source>
			<translation>Seleccione un grupo de estilos antes de añadir un nuevo estilo.</translation>
		</message>
		<message>
			<source>Please select a style group to delete.</source>
			<translation>Por favor, seleccione el grupo de estilos que desea eliminar.</translation>
		</message>
		<message>
			<source>Please select a team to assign.</source>
			<translation>Por favor seleccione un equipo para asignar.</translation>
		</message>
		<message>
			<source>Please select at least one user to assign a team.</source>
			<translation>Por favor seleccione al menos un usuario para asignar un equipo.</translation>
		</message>
		<message>
			<source>Please select at least one user to change team.</source>
			<translation>Por favor seleccione al menos un usuario para cambiar de equipo.</translation>
		</message>
		<message>
			<source>Please select at least one user to remove team assignment.</source>
			<translation>Por favor seleccione al menos un Usuario para eliminar la asignación de equipo.</translation>
		</message>
		<message>
			<source>Please select a valid team to assign.</source>
			<translation>Por favor seleccione un equipo válido para asignar.</translation>
		</message>
		<message>
			<source>Please select a workorder to open</source>
			<translation>Por favor seleccione un orden de trabajo para abrir</translation>
		</message>
		<message>
			<source>Please select both a user and a campaign before adding a row.</source>
			<translation>Por favor seleccione tanto un usuario como una campaña antes de añadir una fila.</translation>
		</message>
		<message>
			<source>Please select one or more styles to delete.</source>
			<translation>Por favor, seleccione uno o más estilos para eliminar.</translation>
		</message>
		<message>
			<source>Please select one or more styles to update.</source>
			<translation>Por favor, seleccione uno o varios estilos para actualizar.</translation>
		</message>
		<message>
			<source>Please select only one result before changing its status.</source>
			<translation>Por favor seleccione sólo un resultado antes de cambiar su estado.</translation>
		</message>
		<message>
			<source>Please select rows to remove from the table</source>
			<translation>Seleccione las filas que desea eliminar de la tabla</translation>
		</message>
		<message>
			<source>Plugin version not found</source>
			<translation>Versión del Complemento no encontrada</translation>
		</message>
		<message>
			<source>PostGis version</source>
			<translation>Versión PostGis</translation>
		</message>
		<message>
			<source>PostgreSQL PID: {0}</source>
			<translation>PostgreSQL PID: {0}</translation>
		</message>
		<message>
			<source>PostgreSQL version</source>
			<translation>Versión de PostgreSQL</translation>
		</message>
		<message>
			<source>PostgreSQL version is not compatible with Giswater. Please check wiki</source>
			<translation>La versión de PostgreSQL no es compatible con Giswater. Por favor revise la wiki</translation>
		</message>
		<message>
			<source>prefer</source>
			<translation>prefiera</translation>
		</message>
		<message>
			<source>Preparing network...</source>
			<translation>Preparando la red...</translation>
		</message>
		<message>
			<source>Price list csv file name is required</source>
			<translation>Se requiere el nombre del archivo csv de la lista de precios</translation>
		</message>
		<message>
			<source>Price list detail csv file name is required</source>
			<translation>Se requiere el nombre del archivo csv del detalle de la lista de precios</translation>
		</message>
		<message>
			<source>Priority Calculation (Global)</source>
			<translation>Cálculo de Prioridad (Global)</translation>
		</message>
		<message>
			<source>Prob. of Failure</source>
			<translation>Prob. de fallo</translation>
		</message>
		<message>
			<source>Processes</source>
			<translation>Procesos</translation>
		</message>
		<message>
			<source>Process finished.

INP file created on:
{0}

Report file created on:
{1}</source>
			<translation>Proceso finalizado.

Archivo INP creado en:
{0}

Archivo de informe creado en:
{1}</translation>
		</message>
		<message>
			<source>Process finished.

INP file created on:
{0}

Statistics file created on:
{1}</source>
			<translation>Proceso finalizado.

Archivo INP creado en:
{0}

Archivo de estadísticas creado en:
{1}</translation>
		</message>
		<message>
			<source>Process finished successfully</source>
			<translation>Proceso finalizado con éxito</translation>
		</message>
		<message>
			<source>Process finished successfully: Delete schema</source>
			<translation>Proceso finalizado con éxito: Eliminar esquema</translation>
		</message>
		<message>
			<source>Process finished with some errors</source>
			<translation>Proceso terminado con algunos errores</translation>
		</message>
		<message>
			<source>Processing folder</source>
			<translation>Carpeta de tratamiento</translation>
		</message>
		<message>
			<source>Processing muni_id {0}</source>
			<translation>Procesando muni_id {0}</translation>
		</message>
		<message>
			<source>Profile</source>
			<translation>Perfil</translation>
		</message>
		<message>
			<source>Profile image path: {0}</source>
			<translation>Ruta de la imagen de perfil: {0}</translation>
		</message>
		<message>
			<source>Profile interpolation</source>
			<translation>Interpolación de perfil</translation>
		</message>
		<message>
			<source>Profile name is mandatory.</source>
			<translation>El nombre del perfil es obligatorio.</translation>
		</message>
		<message>
			<source>Project check task is already active!</source>
			<translation>¡La tarea de verificación del Proyecto ya está activa!</translation>
		</message>
		<message>
			<source>Project read finished</source>
			<translation>Proyecto de lectura finalizado</translation>
		</message>
		<message>
			<source>Project read finished with different versions on plugin metadata ({0}) and PostgreSQL sys_version table ({1}).</source>
			<translation>La lectura del proyecto finalizó con diferentes versiones en los metadatos del plugin ({0}) y en la tabla sys_version de PostgreSQL ({1}).</translation>
		</message>
		<message>
			<source>Project read started</source>
			<translation>Inicio de la lectura del proyecto</translation>
		</message>
		<message>
			<source>Psector &apos;{0}&apos; has no workcat_id value set. Do you want to continue with the default value?</source>
			<translation>Psector &apos;{0}&apos; no tiene valor workcat_id establecido. ¿Desea continuar con el valor por defecto?</translation>
		</message>
		<message>
			<source>Psector actual</source>
			<translation>Psector actual</translation>
		</message>
		<message>
			<source>Psector could not be updated because of the following errors: </source>
			<translation>El Psector no se pudo actualizar debido a los siguientes errores:</translation>
		</message>
		<message>
			<source>Psector could not be updated because of the following errors: {0}</source>
			<translation>No se pudo actualizar Psector debido a los siguientes errores: {0}</translation>
		</message>
		<message>
			<source>Psector features loaded successfully on the map.</source>
			<translation>Las características del psector se han cargado correctamente en el mapa.</translation>
		</message>
		<message>
			<source>Psector ID not found</source>
			<translation>No se encontró el ID del psector.</translation>
		</message>
		<message>
			<source>Psector is not archived</source>
			<translation>Psector no está archivado</translation>
		</message>
		<message>
			<source>Psector name not found</source>
			<translation>No se ha encontrado el nombre del sector</translation>
		</message>
		<message>
			<source>Psector values updated successfully</source>
			<translation>Valores de psector actualizados con éxito</translation>
		</message>
		<message>
			<source>Pumps couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar las bombas!</translation>
		</message>
		<message>
			<source>Python file</source>
			<translation>Archivo Python</translation>
		</message>
		<message>
			<source>Python function</source>
			<translation>Función Python</translation>
		</message>
		<message>
			<source>Python package &apos;{0}&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>El paquete Python &apos;{0}&apos; no está instalado. Por favor instálelo usando pip o el complemento &apos;qpip&apos; de QGIS.</translation>
		</message>
		<message>
			<source>Python package &apos;matplotlib&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>El paquete de Python &apos;matplotlib&apos; no está instalado. Instálelo usando pip o el complemento &apos;qpip&apos; de QGIS.</translation>
		</message>
		<message>
			<source>Python package &apos;swmm-api&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>El paquete de Python &apos;swmm-api&apos; no está instalado. Instálelo usando pip o el complemento &apos;qpip&apos; de QGIS.</translation>
		</message>
		<message>
			<source>Python package &apos;wntr&apos; is not installed. Please install it using pip or the &apos;qpip&apos; QGIS plugin.</source>
			<translation>El paquete de Python &apos;wntr&apos; no está instalado. Por favor instálelo usando pip o el complemento &apos;qpip&apos; de QGIS.</translation>
		</message>
		<message>
			<source>Python translation canceled</source>
			<translation>Cancelada la traducción a Python</translation>
		</message>
		<message>
			<source>Python translation failed</source>
			<translation>Error en la traducción a Python</translation>
		</message>
		<message>
			<source>Python translation successful</source>
			<translation>Traducción a Python realizada con éxito</translation>
		</message>
		<message>
			<source>QGIS project has more than one {0} layer coming from different schemas. If you are looking to manage two schemas, it is mandatory to define which is the master and which isn&apos;t. To do this, you need to configure the QGIS project setting this project&apos;s variables: {1} and {2}.</source>
			<translation>Un proyecto QGIS tiene más de una capa {0} procedente de diferentes esquemas. Si desea gestionar dos esquemas, es obligatorio definir cuál es el maestro y cuál no. Para ello, es necesario configurar el proyecto QGIS estableciendo las variables de este proyecto: {1} y {2}.</translation>
		</message>
		<message>
			<source>QGIS project seems to be a Giswater project, but layer(s) {0} are missing</source>
			<translation>El proyecto QGIS parece ser un Proyecto Giswater, pero falta(n) la(s) capa(s) {0}</translation>
		</message>
		<message>
			<source>QgsLayerTree not found for project.</source>
			<translation>QgsLayerTree no encontrado para el Proyecto.</translation>
		</message>
		<message>
			<source>QML file {0} not found</source>
			<translation>Archivo QML {0} no encontrado</translation>
		</message>
		<message>
			<source>QML is empty!</source>
			<translation>¡QML está vacío!</translation>
		</message>
		<message>
			<source>Quantized Demands</source>
			<translation>Demandas cuantizadas</translation>
		</message>
		<message>
			<source>Raingages couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar pluviómetros!</translation>
		</message>
		<message>
			<source>Raports</source>
			<translation>Reportes</translation>
		</message>
		<message>
			<source>Reading file</source>
			<translation>Archivo de lectura</translation>
		</message>
		<message>
			<source>Reading input files...</source>
			<translation>Leyendo archivos de entrada...</translation>
		</message>
		<message>
			<source>Real location has been updated</source>
			<translation>La ubicación real ha sido actualizada</translation>
		</message>
		<message>
			<source>Recommended catalogs:</source>
			<translation>Catálogos recomendados:</translation>
		</message>
		<message>
			<source>Recommended feature ids:</source>
			<translation>IDs de Elemento recomendados:</translation>
		</message>
		<message>
			<source>Recommended materials:</source>
			<translation>Materiales recomendados:</translation>
		</message>
		<message>
			<source>Record deleted</source>
			<translation>Registro eliminado</translation>
		</message>
		<message>
			<source>Records deleted</source>
			<translation>Registros eliminados</translation>
		</message>
		<message>
			<source>Recursive Go2Epa</source>
			<translation>Go2Epa recursivo</translation>
		</message>
		<message>
			<source>Reload failed</source>
			<translation>Error de recarga</translation>
		</message>
		<message>
			<source>Remaining: {0} ({1}/{2})</source>
			<translation>Restante: {0} ({1}/{2})</translation>
		</message>
		<message>
			<source>Remove layer from project?</source>
			<translation>¿Quitar capa del proyecto?</translation>
		</message>
		<message>
			<source>REMOVE NODE</source>
			<translation>ELIMINAR NODO</translation>
		</message>
		<message>
			<source>Remove Team Assignment</source>
			<translation>Eliminar asignación de equipo</translation>
		</message>
		<message>
			<source>Rename project - {0}</source>
			<translation>Renombrar proyecto - {0}</translation>
		</message>
		<message>
			<source>Repair cost</source>
			<translation>Coste de reparación</translation>
		</message>
		<message>
			<source>Replace feature</source>
			<translation>Reemplazar objeto</translation>
		</message>
		<message>
			<source>Replace feature done successfully</source>
			<translation>Reemplazo de elemento realizado con éxito</translation>
		</message>
		<message>
			<source>Replacement cost</source>
			<translation>Coste de sustitución</translation>
		</message>
		<message>
			<source>Replacement rate (%/year):</source>
			<translation>Tasa de sustitución (%/año):</translation>
		</message>
		<message>
			<source>REPLACEMENTS PER YEAR</source>
			<translation>SUSTITUCIONES POR AÑO</translation>
		</message>
		<message>
			<source>Replacing template text</source>
			<translation>Sustitución del texto de la plantilla</translation>
		</message>
		<message>
			<source>REPORT</source>
			<translation>REPORTE</translation>
		</message>
		<message>
			<source>Reports generated successfully</source>
			<translation>Informes generados correctamente.</translation>
		</message>
		<message>
			<source>Required fields are missing</source>
			<translation>Faltan campos obligatorios</translation>
		</message>
		<message>
			<source>Reservoirs couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar los embalses!</translation>
		</message>
		<message>
			<source>Reset position form done successfully.</source>
			<translation>Se ha reestablecido la posición del formulario con éxito.</translation>
		</message>
		<message>
			<source>Response from {0} is not a ZIP archive</source>
			<translation>La respuesta de {0} no es un archivo ZIP</translation>
		</message>
		<message>
			<source>Result name</source>
			<translation>Nombre del resultado</translation>
		</message>
		<message>
			<source>Result name already exists, do you want overwrite?</source>
			<translation>El nombre del resultado ya existe, ¿desea sobrescribirlo?</translation>
		</message>
		<message>
			<source>Result name not found. It&apos;s not possible to import RPT file into database</source>
			<translation>Nombre del resultado no encontrado. No es posible importar el archivo RPT a la base de datos</translation>
		</message>
		<message>
			<source>Retrieving process ({0}/{1})...</source>
			<translation>Recuperando proceso ({0}/{1})...</translation>
		</message>
		<message>
			<source>Rotation must be a number.</source>
			<translation>La rotación debe ser un número.</translation>
		</message>
		<message>
			<source>Rpt fail</source>
			<translation>Rpt fail</translation>
		</message>
		<message>
			<source>RPT file path is required when importing results or executing EPA</source>
			<translation>La ruta de archivo RPT es obligatoria al importar resultados o ejecutar EPA</translation>
		</message>
		<message>
			<source>Running simulation...</source>
			<translation>Ejecutando simulación...</translation>
		</message>
		<message>
			<source>Sample projects are only allowed with locales en_US, es_ES, ca_ES or es_CR, and SRID 25831.
Do you want to apply the required values and continue?</source>
			<translation>Los proyectos de ejemplo solo se permiten con las configuraciones regionales en_US, es_ES, ca_ES o es_CR, y el SRID 25831.
¿Desea aplicar los valores requeridos y continuar?</translation>
		</message>
		<message>
			<source>Save feature</source>
			<translation>Guardar Elemento</translation>
		</message>
		<message>
			<source>Save these changes to campaign selector?</source>
			<translation>¿Guardar estos cambios en el selector de campañas?</translation>
		</message>
		<message>
			<source>Saving INP file...</source>
			<translation>Guardando archivo INP...</translation>
		</message>
		<message>
			<source>Saving output files...</source>
			<translation>Guardando archivos de salida...</translation>
		</message>
		<message>
			<source>Saving statistics file...</source>
			<translation>Guardando archivo de estadísticas...</translation>
		</message>
		<message>
			<source>Scada graph</source>
			<translation>Gráfico SCADA</translation>
		</message>
		<message>
			<source>Scada graph edge already exists.</source>
			<translation>Scada graph edge already exists.</translation>
		</message>
		<message>
			<source>Scada graph edge created</source>
			<translation>Gráfica SCADA de arista creada</translation>
		</message>
		<message>
			<source>Scada graph saved in DB but om_graph layer could not be loaded.</source>
			<translation>Gráfico Scada guardado en la BD pero la capa om_graph no se pudo cargar.</translation>
		</message>
		<message>
			<source>Scale must be a number.</source>
			<translation>La Escala debe ser un número.</translation>
		</message>
		<message>
			<source>Schema</source>
			<translation>Esquema</translation>
		</message>
		<message>
			<source>Schema: {0}</source>
			<translation>Esquema: {0}</translation>
		</message>
		<message>
			<source>Schema audit not found, please create it first</source>
			<translation>Auditoría de esquema no encontrada, por favor créela primero</translation>
		</message>
		<message>
			<source>SchemaBuilder exception: {0}</source>
			<translation>Excepción de SchemaBuilder: {0}</translation>
		</message>
		<message>
			<source>SchemaBuilder failed: {0}</source>
			<translation>SchemaBuilder falló: {0}</translation>
		</message>
		<message>
			<source>SchemaBuilder failed without first_failure</source>
			<translation>SchemaBuilder falló sin first_failure</translation>
		</message>
		<message>
			<source>Schema cibs already exists.</source>
			<translation>El Esquema cibs ya existe.</translation>
		</message>
		<message>
			<source>Schema multilang already exists.</source>
			<translation>El esquema Multilang ya existe.</translation>
		</message>
		<message>
			<source>Schema name</source>
			<translation>Nombre del esquema</translation>
		</message>
		<message>
			<source>Schema: select a row below</source>
			<translation>Esquema: seleccione una fila abajo</translation>
		</message>
		<message>
			<source>Schema Utils already exist.</source>
			<translation>Schema Utils ya existe.</translation>
		</message>
		<message>
			<source>Schema vacuum executed</source>
			<translation>Vacío de esquema ejecutado</translation>
		</message>
		<message>
			<source>Seeding {0} ({1}/{2})</source>
			<translation>Sembrando {0} ({1}/{2})</translation>
		</message>
		<message>
			<source>Seeding multilang translations for ({0})...</source>
			<translation>Sembrando traducciones multilenguaje para ({0})...</translation>
		</message>
		<message>
			<source>Seed multilang translations?</source>
			<translation>¿Sembrar traducciones multilenguaje?</translation>
		</message>
		<message>
			<source>Seed multilang translations for ({0})</source>
			<translation>Sembrar traducciones multilang para ({0})</translation>
		</message>
		<message>
			<source>Select a campaign to create a child campaign.</source>
			<translation>Seleccione una campaña para crear una campaña hija.</translation>
		</message>
		<message>
			<source>Select a campaign to delete.</source>
			<translation>Seleccione una campaña para eliminar.</translation>
		</message>
		<message>
			<source>Select a language</source>
			<translation>Seleccione un idioma</translation>
		</message>
		<message>
			<source>Select a language to manage</source>
			<translation>Seleccione un idioma para gestionar</translation>
		</message>
		<message>
			<source>Select a locale</source>
			<translation>Seleccione una configuración regional</translation>
		</message>
		<message>
			<source>Select a lot to delete</source>
			<translation>Seleccione un lote para eliminar</translation>
		</message>
		<message>
			<source>Select an arc to start inundation analysis.</source>
			<translation>Seleccione un arco para iniciar el análisis de inundación.</translation>
		</message>
		<message>
			<source>Select a network anchor to copy cibs data.</source>
			<translation>Seleccione un ancla de red para copiar datos cibs.</translation>
		</message>
		<message>
			<source>Select a network anchor to integrate cibs.</source>
			<translation>Seleccione un ancla de red para integrar cibs.</translation>
		</message>
		<message>
			<source>Select a schema</source>
			<translation>Seleccione un esquema</translation>
		</message>
		<message>
			<source>Select a schema to see the Multilang language currently used.</source>
			<translation>Seleccione un Esquema para ver el idioma Multilang actualmente usado.</translation>
		</message>
		<message>
			<source>Select a UD schema to integrate.</source>
			<translation>Seleccione un esquema UD para integrar.</translation>
		</message>
		<message>
			<source>Select a workorder to delete</source>
			<translation>Seleccione una orden de trabajo para eliminar</translation>
		</message>
		<message>
			<source>Select a WS anchor in the network table.</source>
			<translation>Seleccione un ancla WS en la tabla de red.</translation>
		</message>
		<message>
			<source>Select a WS or UD anchor in the network table.</source>
			<translation>Seleccione un anclaje WS o UD en la tabla de red.</translation>
		</message>
		<message>
			<source>Select a WS or UD schema for the cibs operation</source>
			<translation>Seleccione un esquema WS o UD para la operación cibs</translation>
		</message>
		<message>
			<source>Select a WS or UD schema in the table.</source>
			<translation>Seleccione un esquema WS o UD en la tabla.</translation>
		</message>
		<message>
			<source>Select a WS or UD schema to adapt to cibs</source>
			<translation>Seleccione un esquema WS o UD para adaptar a cibs</translation>
		</message>
		<message>
			<source>Select a WS or UD schema to copy data to cibs</source>
			<translation>Seleccione un Esquema WS o UD para copiar datos a cibs</translation>
		</message>
		<message>
			<source>Select a WS schema to integrate.</source>
			<translation>Seleccione un esquema WS para integrar.</translation>
		</message>
		<message>
			<source>Select a WS/UD anchor in the network table.</source>
			<translation>Seleccione un anclaje WS/UD en la tabla de la red.</translation>
		</message>
		<message>
			<source>Select connecs or gullies with qgis tool and use right click to connect them with network. CTRL + SHIFT over selection to remove it</source>
			<translation>Seleccione los connecs o sumideros con la herramienta qgis y utilice el botón derecho del ratón para conectarlos con la red. CTRL + SHIFT sobre la selección para eliminarla</translation>
		</message>
		<message>
			<source>Selected {0}</source>
			<translation>Seleccionado {0}</translation>
		</message>
		<message>
			<source>Selected date interval is not valid</source>
			<translation>El intervalo de fecha seleccionado no es válido</translation>
		</message>
		<message>
			<source>Selected element already in the list</source>
			<translation>El elemento seleccionado ya está en la lista</translation>
		</message>
		<message>
			<source>Selected hydrometer_id not found</source>
			<translation>No se encontró el Hydrometer_id seleccionado</translation>
		</message>
		<message>
			<source>Selected node</source>
			<translation>Nodo seleccionado</translation>
		</message>
		<message>
			<source>Selected schema is already adapted to cibs.</source>
			<translation>El esquema seleccionado ya está adaptado a cibs.</translation>
		</message>
		<message>
			<source>Selected schema is already integrated with utils.</source>
			<translation>El esquema seleccionado ya está integrado con utils.</translation>
		</message>
		<message>
			<source>Selected schema must be adapted to cibs before copying data</source>
			<translation>El esquema seleccionado debe adaptarse a cibs antes de copiar datos</translation>
		</message>
		<message>
			<source>Selected schema not found</source>
			<translation>No se encontró el esquema seleccionado</translation>
		</message>
		<message>
			<source>Selected snapped feature_id to copy values from</source>
			<translation>Seleccionado snapped feature_id para copiar valores de</translation>
		</message>
		<message>
			<source>Selected snapped feature_id to copy values from: {0}
Do you want to copy its values to the current node?

{1}</source>
			<translation>Elemento seleccionado snapped feature_id para copiar valores desde: {0}
¿Desea copiar sus valores al Nodo actual?

{1}</translation>
		</message>
		<message>
			<source>Selected styles updated successfully!</source>
			<translation>¡Estilos seleccionados actualizados con éxito!</translation>
		</message>
		<message>
			<source>Selected styles were successfully deleted.</source>
			<translation>Los estilos seleccionados se han eliminado correctamente.</translation>
		</message>
		<message>
			<source>Select Feature(s)</source>
			<translation>Seleccionar Elemento(s)</translation>
		</message>
		<message>
			<source>Select features by expression</source>
			<translation>Seleccionar elementos por expresión</translation>
		</message>
		<message>
			<source>Select Features by Freehand</source>
			<translation>Seleccionar Elementos a mano alzada</translation>
		</message>
		<message>
			<source>Select Features by Polygon</source>
			<translation>Seleccionar Elementos por Polígono</translation>
		</message>
		<message>
			<source>Select Features by Radius</source>
			<translation>Seleccionar entidades por radio</translation>
		</message>
		<message>
			<source>Select folder</source>
			<translation>Seleccionar carpeta</translation>
		</message>
		<message>
			<source>Select INP file</source>
			<translation>Seleccione archivo INP</translation>
		</message>
		<message>
			<source>Select just one document</source>
			<translation>Seleccione solo un documento</translation>
		</message>
		<message>
			<source>Select just one visit</source>
			<translation>Seleccione sólo una visita</translation>
		</message>
		<message>
			<source>Select new team:</source>
			<translation>Seleccionar nuevo equipo:</translation>
		</message>
		<message>
			<source>Select one</source>
			<translation>Seleccione un</translation>
		</message>
		<message>
			<source>selector</source>
			<translation>selector</translation>
		</message>
		<message>
			<source>Selector help</source>
			<translation>Ayuda del selector</translation>
		</message>
		<message>
			<source>Select RPT file</source>
			<translation>Seleccionar archivo RPT</translation>
		</message>
		<message>
			<source>Select the arc to perform a visual execution</source>
			<translation>Seleccione el arco para realizar una ejecución visual</translation>
		</message>
		<message>
			<source>Select valid INP file</source>
			<translation>Seleccione un archivo INP válido</translation>
		</message>
		<message>
			<source>Select valid RPT file</source>
			<translation>Seleccione un archivo RPT válido</translation>
		</message>
		<message>
			<source>SERVER RESPONSE</source>
			<translation>RESPUESTA DEL SERVIDOR</translation>
		</message>
		<message>
			<source>Service database connection error (psycopg2). Please open plugin log file to get more details</source>
			<translation>Error de conexión a la Base de datos del servicio (psycopg2). Por favor, abra el archivo de registro del Complemento para obtener más detalles</translation>
		</message>
		<message>
			<source>Service database connection error (QSqlDatabase). Please open plugin log file to get more details</source>
			<translation>Error de conexión a la Base de datos del servicio (QSqlDatabase). Por favor, abra el archivo de registro del Complemento para obtener más detalles</translation>
		</message>
		<message>
			<source>Set rpt archived execution successful.</source>
			<translation>Set rpt archived ejecución exitosa.</translation>
		</message>
		<message>
			<source>SHAPE</source>
			<translation>FORMA</translation>
		</message>
		<message>
			<source>Shift+Click to uncheck all</source>
			<translation>Shift+Click para desmarcar todo</translation>
		</message>
		<message>
			<source>Show</source>
			<translation>Mostrar</translation>
		</message>
		<message>
			<source>Show selection on top</source>
			<translation>Mostrar selección en primer plano</translation>
		</message>
		<message>
			<source>Skipping map highlighting for very large dataset ({0} features)</source>
			<translation>Saltando resaltado en el Mapa por conjunto de datos muy grande ({0} elementos)</translation>
		</message>
		<message>
			<source>Skipping muni_id {0}: Invalid geometry</source>
			<translation>Omitiendo muni_id {0}: Geometría no válida</translation>
		</message>
		<message>
			<source>Snapped feature is not in a valid layer</source>
			<translation>El elemento seleccionado no se encuentra en una capa válida</translation>
		</message>
		<message>
			<source>Some data is missing. Check gis_length for arc</source>
			<translation>Faltan algunos datos. Compruebe gis_length para el arco</translation>
		</message>
		<message>
			<source>Some mandatory fields are missing. Please fill the required fields (marked in red).</source>
			<translation>Faltan algunos campos obligatorios. Por favor, rellene los campos requeridos (marcados en rojo).</translation>
		</message>
		<message>
			<source>Some mandatory values are missing. Please check the widgets marked in red.</source>
			<translation>Faltan algunos valores obligatorios. Compruebe los widgets marcados en rojo.</translation>
		</message>
		<message>
			<source>Sources</source>
			<translation>Orígenes</translation>
		</message>
		<message>
			<source>SQL</source>
			<translation>SQL</translation>
		</message>
		<message>
			<source>SQL: {0}</source>
			<translation>SQL: {0}</translation>
		</message>
		<message>
			<source>SQL Context</source>
			<translation>Contexto SQL</translation>
		</message>
		<message>
			<source>SQL execution failed.</source>
			<translation>Ejecución SQL fallida.</translation>
		</message>
		<message>
			<source>SQL File</source>
			<translation>Archivos SQL</translation>
		</message>
		<message>
			<source>SQL folder not found</source>
			<translation>Carpeta SQL no encontrada</translation>
		</message>
		<message>
			<source>SRID</source>
			<translation>SRID</translation>
		</message>
		<message>
			<source>Started task &apos;{0}&apos;</source>
			<translation>Iniciada tarea &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Started task {0}</source>
			<translation>Tarea iniciada {0}</translation>
		</message>
		<message>
			<source>Starting execute_vacuum method</source>
			<translation>Inicio del método execute_vacuum</translation>
		</message>
		<message>
			<source>Starting process...</source>
			<translation>Iniciando proceso...</translation>
		</message>
		<message>
			<source>Static Calibration</source>
			<translation>Calibración estática</translation>
		</message>
		<message>
			<source>Storage units couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar las unidades de almacenamiento!</translation>
		</message>
		<message>
			<source>Style group &apos;{0}&apos; and related entries have been deleted.</source>
			<translation>Se han eliminado el grupo de estilos &apos;{0}&apos; y las entradas relacionadas.</translation>
		</message>
		<message>
			<source>Successfully assigned team &apos;{0}&apos; to {1} user(s).</source>
			<translation>Equipo &apos;{0}&apos; asignado correctamente a {1} Usuario(s).</translation>
		</message>
		<message>
			<source>Successfully changed to team &apos;{0}&apos; for {1} user(s).</source>
			<translation>Cambiado con éxito al equipo &apos;{0}&apos; para {1} usuario(s).</translation>
		</message>
		<message>
			<source>Successfully removed team assignment from {0} user(s).</source>
			<translation>Asignación de equipo eliminada con éxito de {0} Usuario(s).</translation>
		</message>
		<message>
			<source>SUCCESS IN DUPLICATING PSECTOR</source>
			<translation>ÉXITO AL DUPLICAR PSECTOR</translation>
		</message>
		<message>
			<source>SUMMARY</source>
			<translation>RESUMEN</translation>
		</message>
		<message>
			<source>Table not found</source>
			<translation>No se encontró la tabla</translation>
		</message>
		<message>
			<source>Table not found: &apos;{0}&apos;</source>
			<translation>Tabla no encontrada: &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Table not found: {0}</source>
			<translation>Tabla no encontrada: {0}</translation>
		</message>
		<message>
			<source>Tab not found.</source>
			<translation>Pestaña no encontrada.</translation>
		</message>
		<message>
			<source>Tanks couldn&apos;t be inserted!</source>
			<translation>¡Los tanques no pudieron ser insertados!</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; completed</source>
			<translation>Tarea &apos;{0}&apos; completada</translation>
		</message>
		<message>
			<source>Task {0} completed
</source>
			<translation>Tarea {0} completada</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; Exception: {1}</source>
			<translation>Tarea &apos;{0}&apos; Excepción: {1}</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; execute function &apos;{1}&apos;</source>
			<translation>Tarea &apos;{0}&apos; ejecuta función &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; execute procedure &apos;{1}&apos; with parameters: &apos;{2}&apos;, &apos;{3}&apos;, &apos;{4}&apos;</source>
			<translation>La tarea &quot;{0}&quot; ejecuta el procedimiento &quot;{1}&quot; con los parámetros: &quot;{2}&quot;, &quot;{3}&quot;, &quot;{4}&quot;.</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; manage json response</source>
			<translation>Tarea &apos;{0}&apos; gestionar respuesta json</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; manage json response with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Tarea &apos;{0}&apos; gestionar respuesta json con parámetros: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; not successful but without exception</source>
			<translation>Tarea &apos;{0}&apos; sin éxito pero sin excepción</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; was cancelled</source>
			<translation>Tarea &apos;{0}&apos; cancelada</translation>
		</message>
		<message>
			<source>Task aborted - {0}</source>
			<translation>Tarea abortada - {0}</translation>
		</message>
		<message>
			<source>Task aborted: {0}.</source>
			<translation>Tarea abortada: {0}.</translation>
		</message>
		<message>
			<source>Task canceled!</source>
			<translation>¡Tarea cancelada!</translation>
		</message>
		<message>
			<source>Task canceled.</source>
			<translation>Tarea cancelada.</translation>
		</message>
		<message>
			<source>Task canceled:</source>
			<translation>Tarea cancelada:</translation>
		</message>
		<message>
			<source>Task canceled - {0}</source>
			<translation>Tarea cancelada - {0}</translation>
		</message>
		<message>
			<source>Task &apos;Check project&apos; execute function &apos;{0}&apos;</source>
			<translation>Tarea &apos;Comprobar proyecto&apos; ejecutar función &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>task_completed</source>
			<translation>tarea_realizada</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute function &apos;{0}&apos; from &apos;{1}&apos; with parameters: &apos;{2}&apos;</source>
			<translation>Tarea &apos;Conectar enlace&apos; ejecutar función &apos;{0}&apos; de &apos;{1}&apos; con parámetros: &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute function &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;</source>
			<translation>Tarea &apos;Conectar enlace&apos; ejecutar función &apos;{0}&apos; con parámetros: &apos;{1}&apos;, &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute procedure &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>La tarea &quot;Conectar enlace&quot; ejecuta el procedimiento &quot;{0}&quot; con los parámetros: &quot;{1}&quot;, &quot;{2}&quot;, &quot;{3}&quot;.</translation>
		</message>
		<message>
			<source>Task failed: {0}. This is probably a DB error, check postgres function &apos;{1}&apos;.</source>
			<translation>Tarea fallida: {0}. Probablemente se trata de un error de la base de datos, compruebe la función postgres &apos;{1}&apos;.</translation>
		</message>
		<message>
			<source>Task finished!</source>
			<translation>¡Tarea finalizada!</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;{0}&apos;</source>
			<translation>Tarea &apos;Go2Epa&apos; ejecutar función &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;{0}&apos; from &apos;{1}&apos;</source>
			<translation>Tarea &apos;Go2Epa&apos; ejecutar función &apos;{0}&apos; de &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;def _exec_import_function&apos;</source>
			<translation>Tarea &apos;Go2Epa&apos; ejecutar función &apos;def _exec_import_function&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{0}&apos; step {1}</source>
			<translation>Tarea &apos;Go2Epa&apos; ejecutar procedimiento &apos;{0}&apos; paso {1}</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{1}&apos; step {2} with parameters: &apos;{1}&apos;, &apos;{3}&apos;, &apos;{4}&apos;, &apos;{5}&apos;, &apos;{6}&apos;</source>
			<translation>Tarea &apos;Go2Epa&apos; ejecuta procedimiento &apos;{1}&apos; paso {2} con parámetros: &apos;{1}&apos;, &apos;{3}&apos;, &apos;{4}&apos;, &apos;{5}&apos;, &apos;{6}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Mincut execute&apos; execute procedure &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>La tarea &quot;Mincut execute&quot; ejecuta el procedimiento &quot;{0}&quot; con los parámetros: &quot;{1}&quot;, &quot;{2}&quot;, &quot;{3}&quot;.</translation>
		</message>
		<message>
			<source>Task &apos;Mincut execute&apos; manage json response with parameters: &apos;{0}&apos;, &apos;{1}&apos;, &apos;{2}&apos;</source>
			<translation>La tarea &apos;Mincut execute&apos; gestiona la respuesta json con los parámetros: &apos;{0}&apos;, &apos;{1}&apos;, &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Template not managed: {0}</source>
			<translation>Plantilla no gestionada: {0}</translation>
		</message>
		<message>
			<source>Temporal layer created successfully.</source>
			<translation>Capa temporal creada con éxito.</translation>
		</message>
		<message>
			<source>The &quot;{0}&quot; curve does not have a specified curve type and was not imported.</source>
			<translation>La curva &quot;{0}&quot; no tiene un tipo de curva especificado y no se importó.</translation>
		</message>
		<message>
			<source>The &apos;{0}&apos; field is required.</source>
			<translation>El campo &quot;{0}&quot; es obligatorio.</translation>
		</message>
		<message>
			<source>The base language (en_US) cannot be deleted.</source>
			<translation>El idioma base (en_US) no puede ser eliminado.</translation>
		</message>
		<message>
			<source>The configuration file doesn&apos;t match the selected INP file. Some options may not be loaded or may be incorrect. Do you want to continue?</source>
			<translation>El archivo de configuración no coincide con el archivo INP seleccionado. Es posible que algunas opciones no se carguen o sean incorrectas. ¿Quieres continuar?</translation>
		</message>
		<message>
			<source>The connection to the database is broken.</source>
			<translation>La conexión a la Base de datos está interrumpida.</translation>
		</message>
		<message>
			<source>The connection to the database is broken: {0}</source>
			<translation>La conexión a la base de datos está rota: {0}</translation>
		</message>
		<message>
			<source>The control &apos;{0}&apos; is already on database. Skipping...</source>
			<translation>El control &apos;{0}&apos; ya está en la base de datos. Omitiendo...</translation>
		</message>
		<message>
			<source>The csv file has been successfully exported</source>
			<translation>El archivo csv se ha exportado correctamente</translation>
		</message>
		<message>
			<source>The curve &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing curve.</source>
			<translation>La curva &quot;{0}&quot; ha sido renombrada a &quot;{1}&quot; para evitar una colisión con una curva existente.</translation>
		</message>
		<message>
			<source>The &apos;Description&apos; field is required.</source>
			<translation>El campo &apos;Descripción&apos; es obligatorio.</translation>
		</message>
		<message>
			<source>The field layoutname is not configured for</source>
			<translation>El campo layoutname no está configurado para</translation>
		</message>
		<message>
			<source>The field layoutorder is not configured for</source>
			<translation>El campo layoutorder no está configurado para</translation>
		</message>
		<message>
			<source>The field widgettype is not configured for</source>
			<translation>El campo widgettype no está configurado para</translation>
		</message>
		<message>
			<source>The fifth tab is the &apos;Arcs&apos; tab, where you can select the catalog for each type of arc on the network.</source>
			<translation>La quinta pestaña es la de &quot;Arcos&quot;, donde puede seleccionar el catálogo para cada tipo de arco de la red.</translation>
		</message>
		<message>
			<source>The file {0} already exists. Do you want to overwrite it?</source>
			<translation>El fichero {0} ya existe. ¿Desea sobrescribirlo?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.csv&quot; already exists. Do you want to overwrite it?</source>
			<translation>El archivo &quot;{0}.csv&quot; ya existe. ¿Desea sobrescribirlo?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.in&quot; already exists. Do you want to overwrite it?</source>
			<translation>El archivo &quot;{0}.in&quot; ya existe. ¿Desea sobrescribirlo?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.inp&quot; already exists. Do you want to overwrite it?</source>
			<translation>El archivo &quot;{0}.inp&quot; ya existe. ¿Desea sobrescribirlo?</translation>
		</message>
		<message>
			<source>The files {0} already exist. Do you want to overwrite them?</source>
			<translation>Los ficheros {0} ya existen. ¿Desea sobrescribirlos?</translation>
		</message>
		<message>
			<source>The files &quot;{0}.in&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</source>
			<translation>Los archivos &quot;{0}.in&quot; y &quot;{1}.csv&quot; ya existen. ¿Desea sobrescribirlos?</translation>
		</message>
		<message>
			<source>The files &quot;{0}.inp&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</source>
			<translation>Los archivos &quot;{0}.inp&quot; y &quot;{1}.csv&quot; ya existen. ¿Desea sobrescribirlos?</translation>
		</message>
		<message>
			<source>The file selected is not a GPKG file</source>
			<translation>El archivo seleccionado no es un archivo GPKG</translation>
		</message>
		<message>
			<source>The file selected is not an INP file</source>
			<translation>El fichero seleccionado no es un fichero INP</translation>
		</message>
		<message>
			<source>The first tab is the &apos;Basic&apos; tab, where you can select the exploitation, sector, municipality, and other basic information.</source>
			<translation>La primera pestaña es la pestaña &quot;Básica&quot;, donde puede seleccionar la explotación, el sector, el municipio y otra información básica.</translation>
		</message>
		<message>
			<source>The flow data timestep must be a multiple of the desired timestep.</source>
			<translation>El intervalo de tiempo de los datos de caudal debe ser múltiplo del intervalo de tiempo deseado.</translation>
		</message>
		<message>
			<source>The following fields differ between the selected arcs. You are about to merge them using the selected values.

{0}

Do you want to continue?</source>
			<translation>Los siguientes campos difieren entre los arcos seleccionados. Está a punto de fusionarlos usando los valores seleccionados.

{0}

¿Desea continuar?</translation>
		</message>
		<message>
			<source>The fourth tab is the &apos;Nodes&apos; tab, where you can select the catalog for each type of node on the network.</source>
			<translation>La cuarta pestaña es la de &quot;Nodos&quot;, donde puedes seleccionar el catálogo para cada tipo de nodo de la red.</translation>
		</message>
		<message>
			<source>The hour value must be between 0 and 23, inclusive. Value supplied: {0}</source>
			<translation>El valor de la hora debe estar entre 0 y 23, inclusive. Valor suministrado: {0}</translation>
		</message>
		<message>
			<source>The [JUNCTIONS] section of the configuration file is empty.</source>
			<translation>La sección [JUNCTIONS] del archivo de configuración está vacía.</translation>
		</message>
		<message>
			<source>The lid &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing lid.</source>
			<translation>El lid &quot;{0}&quot; ha sido renombrado a &quot;{1}&quot; para evitar una colisión con un lid existente.</translation>
		</message>
		<message>
			<source>The link &apos;{0}&apos; does not exist in the network.</source>
			<translation>El enlace &apos;{0}&apos; no existe en la red.</translation>
		</message>
		<message>
			<source>The link &apos;{0}&apos; is not a pump.</source>
			<translation>El enlace &apos;{0}&apos; no es una bomba.</translation>
		</message>
		<message>
			<source>The link &apos;{0}&apos; is not a valve.</source>
			<translation>El Enlace &apos;{0}&apos; no es una Válvula.</translation>
		</message>
		<message>
			<source>The multilang language has been changed. To update the TOC and toolbar tooltips language, restart QGIS.</source>
			<translation>El idioma multilang ha sido cambiado. Para actualizar el TOC y las descripciones emergentes de la barra de herramientas, reinicie QGIS.</translation>
		</message>
		<message>
			<source>The name is current in use</source>
			<translation>El nombre está actualmente en uso</translation>
		</message>
		<message>
			<source>The node &apos;{0}&apos; does not exist in the network.</source>
			<translation>El Nodo &apos;{0}&apos; no existe en la red.</translation>
		</message>
		<message>
			<source>The node is obsolete, this tool doesn&apos;t work with obsolete nodes.</source>
			<translation>El nodo está obsoleto, esta herramienta no funciona con nodos obsoletos.</translation>
		</message>
		<message>
			<source>The number of pages in your composition does not match the number of psectors. ({0} != {1})</source>
			<translation>El número de páginas en su composición no coincide con el número de psectors. ({0} != {1})</translation>
		</message>
		<message>
			<source>The pattern &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing pattern.</source>
			<translation>El patrón &quot;{0}&quot; ha sido renombrado a &quot;{1}&quot; para evitar una colisión con un patrón existente.</translation>
		</message>
		<message>
			<source>The procedure will delete features on database unless it is a node that doesn&apos;t divide arcs.
Please ensure that features has no undelete value on true.
On the other hand you must know that traceability table will storage precedent information.</source>
			<translation>El procedimiento eliminará elementos en la Base de datos a menos que sea un Nodo que no divide arcos.
Por favor asegúrese de que los elementos no tengan undelete en true.
Por otro lado debe saber que la tabla de trazabilidad almacenará la información precedente.</translation>
		</message>
		<message>
			<source>The process has been executed. Files generated:</source>
			<translation>El proceso se ha ejecutado. Ficheros generados:</translation>
		</message>
		<message>
			<source>The project name can&apos;t be a PostgreSQL reserved keyword</source>
			<translation>El nombre del proyecto no puede ser una palabra clave reservada de PostgreSQL</translation>
		</message>
		<message>
			<source>The project name can&apos;t have any upper-case characters</source>
			<translation>El nombre del proyecto no puede tener caracteres en mayúscula</translation>
		</message>
		<message>
			<source>The project name has invalid character</source>
			<translation>El nombre del proyecto tiene un carácter no válido</translation>
		</message>
		<message>
			<source>The QGIS Projects templates was correctly created.</source>
			<translation>Las plantillas de proyectos de QGIS se crearon correctamente.</translation>
		</message>
		<message>
			<source>The QML file is invalid</source>
			<translation>El archivo QML no es válido</translation>
		</message>
		<message>
			<source>The QML file is invalid.</source>
			<translation>El archivo QML no es válido.</translation>
		</message>
		<message>
			<source>There are missing values in these nodes:</source>
			<translation>Faltan valores en estos nodos:</translation>
		</message>
		<message>
			<source>There are multiple queries configured. These are the lists that will be used. Do you want to continue?</source>
			<translation>Hay varias consultas configuradas. Estas son las listas que se utilizarán. ¿Quieres continuar?</translation>
		</message>
		<message>
			<source>There are multple tabs in order to configure all the necessary catalogs.</source>
			<translation>Hay varias pestañas para configurar todos los catálogos necesarios.</translation>
		</message>
		<message>
			<source>There are no results available to display.</source>
			<translation>No hay resultados disponibles para mostrar.</translation>
		</message>
		<message>
			<source>There are no visible mincuts in the table. Try a different filter or make one</source>
			<translation>No hay minicortes visibles en la tabla. Pruebe con otro filtro o cree uno</translation>
		</message>
		<message>
			<source>There are some error in the records with id</source>
			<translation>Hay algunos errores en los registros con id</translation>
		</message>
		<message>
			<source>There are some topological inconsistences on psector &apos;{0}&apos;. Would you like to see the log?</source>
			<translation>Hay algunas inconsistencias topológicas en psector &apos;{0}&apos;. ¿Desea ver el registro?</translation>
		</message>
		<message>
			<source>There have been errors translating:</source>
			<translation>Ha habido errores de traducción:</translation>
		</message>
		<message>
			<source>There is an error in the configuration of the pgservice file, please check it or consult your administrator</source>
			<translation>Hay un error en la configuración del fichero pgservice, por favor compruébelo o consulte a su administrador</translation>
		</message>
		<message>
			<source>There is an error in the configuration of the pgservice file, please check it or consult your administrator ({0})</source>
			<translation>Hay un error en la configuración del archivo pgservice, por favor compruébelo o consulte con su administrador ({0})</translation>
		</message>
		<message>
			<source>There is another function dialog open.</source>
			<translation>Hay otro diálogo de función abierto.</translation>
		</message>
		<message>
			<source>There is another report open. Please close it first.</source>
			<translation>Hay otro informe abierto. Por favor ciérrelo primero.</translation>
		</message>
		<message>
			<source>There is a partially completed file for this folder/file name. Would you like to resume the process?</source>
			<translation>Hay un archivo parcialmente completado para esta carpeta/nombre de archivo. Desea reanudar el proceso?</translation>
		</message>
		<message>
			<source>There is no data in table anl_arc for fid=491 and current user.</source>
			<translation>No hay datos en la tabla anl_arc para fid=491 y usuario actual.</translation>
		</message>
		<message>
			<source>There is no data in table anl_arc for fid=493 and current user.</source>
			<translation>No hay datos en la tabla anl_arc para fid=493 y usuario actual.</translation>
		</message>
		<message>
			<source>There is no project selected or it is not valid. Please check the first tab...</source>
			<translation>No hay ningún proyecto seleccionado o no es válido. Por favor revise la primera pestaña...</translation>
		</message>
		<message>
			<source>There is no valid shape curve in the list</source>
			<translation>No hay ninguna curva de forma válida en la lista</translation>
		</message>
		<message>
			<source>The result cannot be deleted</source>
			<translation>El resultado no puede borrarse</translation>
		</message>
		<message>
			<source>There was an error deleting object.</source>
			<translation>Se produjo un error al eliminar el objeto.</translation>
		</message>
		<message>
			<source>There was an error deleting object values.</source>
			<translation>Se produjo un error al eliminar los valores de los objetos.</translation>
		</message>
		<message>
			<source>There was an error deleting old curve values.</source>
			<translation>Se produjo un error al eliminar los valores de curva antiguos.</translation>
		</message>
		<message>
			<source>There was an error deleting old lid values.</source>
			<translation>Se produjo un error al eliminar los valores de lid antiguos.</translation>
		</message>
		<message>
			<source>There was an error deleting old pattern values.</source>
			<translation>Se produjo un error al eliminar los valores de patrones antiguos.</translation>
		</message>
		<message>
			<source>There was an error deleting old timeseries values.</source>
			<translation>Se produjo un error al eliminar los valores antiguos de series temporales.</translation>
		</message>
		<message>
			<source>There was an error inserting control.</source>
			<translation>Se produjo un error al insertar el control.</translation>
		</message>
		<message>
			<source>There was an error inserting curve.</source>
			<translation>Se produjo un error al insertar la curva.</translation>
		</message>
		<message>
			<source>There was an error inserting curve value.</source>
			<translation>Se produjo un error al insertar el valor de la curva.</translation>
		</message>
		<message>
			<source>There was an error inserting lid.</source>
			<translation>Se produjo un error al insertar la tapa.</translation>
		</message>
		<message>
			<source>There was an error inserting pattern.</source>
			<translation>Se produjo un error al insertar el patrón.</translation>
		</message>
		<message>
			<source>There was an error inserting pattern value.</source>
			<translation>Se produjo un error al insertar el valor del patrón.</translation>
		</message>
		<message>
			<source>There was an error inserting timeseries.</source>
			<translation>Se produjo un error al insertar series de tiempo.</translation>
		</message>
		<message>
			<source>There were velocities &gt;50 in the rpt file. You have activated the option to force the import so they have been set to 50.</source>
			<translation>Había velocidades &gt;50 en el fichero rpt. Has activado la opción de forzar la importación por lo que se han fijado en 50.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlaped, it seems you need to improve your simulation. Please ckeck and fix it before continue. 
{0}</source>
			<translation>El archivo rpt no es válido para Importar. Porque las columnas del archivo rpt están solapadas, parece que necesita mejorar su simulación. Por favor ckeck y arréglelo antes de continuar. 
{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlapped, it seems you need to improve your simulation. Please check and fix it before continuing.
{0}</source>
			<translation>El archivo rpt no es válido para Importar. Porque las columnas del archivo rpt están solapadas, parece que necesita mejorar su simulación. Por favor revise y arréglelo antes de continuar.
{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. 
{0}</source>
			<translation>El archivo rpt no es válido para Importar. Porque la Velocidad no tiene un valor numérico (&gt;50), parece que necesita mejorar su simulación. Por favor ckeck y arréglelo antes de continuar. 
{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. 
Note: You can force the import by activating the variable &apos;{0}&apos; on the {1} file. 
{2}</source>
			<translation>El archivo rpt no es válido para Importar. Porque la Velocidad no tiene un valor numérico (&gt;50), parece que necesita mejorar su simulación. Por favor ckeck y arréglelo antes de continuar. 
Nota: Puede forzar la Importación activando la variable &apos;{0}&apos; en el archivo {1}. 
{2}</translation>
		</message>
		<message>
			<source>The rule &apos;{0}&apos; is already on database. Skipping...</source>
			<translation>La regla &apos;{0}&apos; ya existe en la base de datos. Omisión...</translation>
		</message>
		<message>
			<source>The [SCENARIOS] section of the configuration file is empty.</source>
			<translation>La sección [ESCENARIOS] del archivo de configuración está vacía.</translation>
		</message>
		<message>
			<source>The schema &apos;{0}&apos; is being used in production! It can&apos;t be deleted.</source>
			<translation>El esquema &apos;{0}&apos; se está utilizando en producción. No se puede eliminar.</translation>
		</message>
		<message>
			<source>The schema version has to be updated to make rename</source>
			<translation>Este nombre de proyecto ya existe.</translation>
		</message>
		<message>
			<source>These are the lists that will be used. Do you want to continue?</source>
			<translation>Estas son las listas que se utilizarán. ¿Quieres continuar?</translation>
		</message>
		<message>
			<source>The second tab is the &apos;Features&apos; tab, where you can select the corresponding feature classes for each type of feature on the network.</source>
			<translation>La segunda pestaña es la de &quot;Características&quot;, donde puede seleccionar las clases de características correspondientes para cada tipo de característica de la red.</translation>
		</message>
		<message>
			<source>The selected node is planified in another psector.
Node psector: {0}
Current psector: {1}</source>
			<translation>El Nodo seleccionado está planificado en otro psector.
Psector del Nodo: {0}
Psector actual: {1}</translation>
		</message>
		<message>
			<source>The selected node should have exactly two linked arcs.</source>
			<translation>El nodo seleccionado debe tener exactamente dos arcos enlazados.</translation>
		</message>
		<message>
			<source>These links could not be located within the network: </source>
			<translation>Estos enlaces no han podido ser localizados en la red:</translation>
		</message>
		<message>
			<source>These pipes will NOT be assigned a priority value as the configured unknown material, {1}, is not listed in the configuration tab for materials.</source>
			<translation>A estas tuberías NO se les asignará un valor de prioridad ya que el material desconocido configurado, {1}, no aparece en la pestaña de configuración de materiales.</translation>
		</message>
		<message>
			<source>The start date must be before the end date</source>
			<translation>La fecha de inicio debe ser anterior a la fecha de fin</translation>
		</message>
		<message>
			<source>The start date real must be before the end date real</source>
			<translation>La fecha real de inicio debe ser anterior a la fecha real de fin</translation>
		</message>
		<message>
			<source>The sum of weights must equal 1. Please adjust the values accordingly.</source>
			<translation>La suma de los pesos debe ser igual a 1. Ajuste los valores de acuerdo a esta condición.</translation>
		</message>
		<message>
			<source>The table &apos;plan_psector&apos; contains NULL values in the column &apos;atlas_id&apos;. Please fix this before continuing.</source>
			<translation>La tabla &apos;plan_psector&apos; contiene valores NULL en la columna &apos;atlas_id&apos;. Por favor, corrígelo antes de continuar.</translation>
		</message>
		<message>
			<source>The target year must be between {0} and {1}.</source>
			<translation>El año objetivo debe estar comprendido entre {0} y {1}.</translation>
		</message>
		<message>
			<source>The team name already exists</source>
			<translation>El nombre del equipo ya existe</translation>
		</message>
		<message>
			<source>The template &apos;{0}&apos; is missing some expected items: {1}. The layout will open, but these features won&apos;t be automatically configured. Make sure your template includes items with IDs: &apos;Mapa&apos; (for the map) and &apos;title&apos; (for the title).</source>
			<translation>La plantilla &apos;{0}&apos; carece de algunos elementos esperados: {1}. El diseño se abrirá, pero estos elementos no se configurarán automáticamente. Asegúrese de que su plantilla incluya elementos con IDs: &apos;Mapa&apos; (para el mapa) y &apos;title&apos; (para el título).</translation>
		</message>
		<message>
			<source>The third tab is the &apos;Materials&apos; tab, where you can select the corresponding material for each roughness value.</source>
			<translation>La tercera pestaña es la de &quot;Materiales&quot;, donde puede seleccionar el material correspondiente para cada valor de rugosidad.</translation>
		</message>
		<message>
			<source>The third tab is the &apos;Materials&apos; tab, where you can select the corresponding roughness value for each material.</source>
			<translation>La tercera pestaña es la de &quot;Materiales&quot;, donde puede seleccionar el valor de rugosidad correspondiente a cada material.</translation>
		</message>
		<message>
			<source>The timeseries &quot;{0}&quot; has been renamed to &quot;{1}&quot; to avoid a collision with an existing timeseries.</source>
			<translation>La serie temporal &quot;{0}&quot; ha sido renombrada a &quot;{1}&quot; para evitar una colisión con una serie temporal existente.</translation>
		</message>
		<message>
			<source>The timeseries &quot;{0}&quot; was not imported.</source>
			<translation>La serie temporal &quot;{0}&quot; no fue importada.</translation>
		</message>
		<message>
			<source>The user config files have been recreated. A backup of the broken ones have been created at</source>
			<translation>Se han recreado los archivos de configuración de usuario. Se ha creado una copia de seguridad de los rotos en</translation>
		</message>
		<message>
			<source>The Workcat_id &quot;{0}&quot; is already in use. Please enter a different ID.</source>
			<translation>El Workcat_id &quot;{0}&quot; ya está en uso. Por favor, introduzca un ID diferente.</translation>
		</message>
		<message>
			<source>This action cannot be undone. Do you want to proceed?</source>
			<translation>Esta acción no se puede deshacer. ¿Desea continuar?</translation>
		</message>
		<message>
			<source>This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector</source>
			<translation>Este comportamiento puede configurarse en la tabla &apos;config_param_system&apos; (parámetro = &apos;basic_selector</translation>
		</message>
		<message>
			<source>This dma doesn&apos;t exist</source>
			<translation>Este dma no existe</translation>
		</message>
		<message>
			<source>This feature has no log changes, please update this feature before.</source>
			<translation>Esta característica no tiene cambios de registro, por favor, actualice esta característica antes.</translation>
		</message>
		<message>
			<source>This parameter is mandatory. Please, set a value</source>
			<translation>Este parámetro es obligatorio. Por favor, establezca un valor</translation>
		</message>
		<message>
			<source>This presszone doesn&apos;t exist</source>
			<translation>Esta zona de prensa no existe</translation>
		</message>
		<message>
			<source>This process will active snapshot. Are you sure to continue?</source>
			<translation>Este proceso activará la instantánea. ¿Está seguro de continuar?</translation>
		</message>
		<message>
			<source>This process will take a few seconds. Are you sure to continue?</source>
			<translation>Este proceso durará unos segundos. ¿Está seguro de continuar?</translation>
		</message>
		<message>
			<source>This process will take time (few minutes). Are you sure to continue?</source>
			<translation>Este proceso llevará tiempo (unos minutos). ¿Estás seguro de continuar?</translation>
		</message>
		<message>
			<source>This &apos;Project_name&apos; already exist. Do you want rename old schema to &apos;{0}&apos;</source>
			<translation>Este &apos;Nombre_de_proyecto&apos; ya existe. ¿Quiere renombrar el antiguo esquema a &apos;{0}&apos;?</translation>
		</message>
		<message>
			<source>This project name alredy exist.</source>
			<translation>Este nombre de proyecto ya existe.</translation>
		</message>
		<message>
			<source>This result name already exists</source>
			<translation>Este nombre de resultado ya existe</translation>
		</message>
		<message>
			<source>This SRID value does not exist on Postgres Database. Please select a diferent one.</source>
			<translation>Este valor SRID no existe en la base de datos de Postgres. Seleccione uno diferente.</translation>
		</message>
		<message>
			<source>This task may take some time to complete, do you want to proceed?</source>
			<translation>Esta tarea puede tardar algún tiempo en completarse, ¿desea continuar?</translation>
		</message>
		<message>
			<source>This will also delete the database user(s):</source>
			<translation>Esto también eliminará los usuarios de la base de datos:</translation>
		</message>
		<message>
			<source>!!!!! THIS WILL DELETE ALL DATA IN THE DATABASE !!!!!
ARE YOU SURE YOU WANT TO PROCEED?</source>
			<translation>!!!!! ¡ESTO ELIMINARÁ TODOS LOS DATOS EN LA BASE DE DATOS !!!!
¿ESTÁ SEGURO DE QUE DESEA CONTINUAR?</translation>
		</message>
		<message>
			<source>This will modify your inp file, so a backup will be created.
Do you want to proceed?</source>
			<translation>Esto modificará su archivo inp, por lo que se creará una copia de seguridad.
¿Desea continuar?</translation>
		</message>
		<message>
			<source>This wizard will help with the process of importing a network from a {0} INP file into the Giswater database.</source>
			<translation>Este asistente le ayudará en el proceso de importación de una red desde un fichero {0} INP a la base de datos Giswater.</translation>
		</message>
		<message>
			<source>This Workcat already exist</source>
			<translation>Este Workcat ya existe</translation>
		</message>
		<message>
			<source>This Workcat is already exist</source>
			<translation>Este Workcat ya existe</translation>
		</message>
		<message>
			<source>Timestep for input flows not informed.</source>
			<translation>No se informó el timestep para los flujos de entrada.</translation>
		</message>
		<message>
			<source>Title item &apos;title&apos; not found in template. Template may be empty or use different item IDs.</source>
			<translation>Elemento título &apos;title&apos; no encontrado en la plantilla. La plantilla puede estar vacía o usar IDs de elemento diferentes.</translation>
		</message>
		<message>
			<source>To add:</source>
			<translation>Para añadir:</translation>
		</message>
		<message>
			<source>Toggle active</source>
			<translation>Alternar activo</translation>
		</message>
		<message>
			<source>Toggle Active</source>
			<translation>Alternar Activo</translation>
		</message>
		<message>
			<source>Toggle validated</source>
			<translation>Alternar validado</translation>
		</message>
		<message>
			<source>To make the result id {0} corporate, is necessary to make not corporate the following result ids: {1}. Do you want to proceed?</source>
			<translation>Para hacer corporativo el id de resultado {0}, es necesario hacer no corporativos los siguientes ids de resultado: {1}. ¿Desea continuar?</translation>
		</message>
		<message>
			<source>Toolbox task is already active!</source>
			<translation>¡La tarea Toolbox ya está activa!</translation>
		</message>
		<message>
			<source>Too many actions on CONTROL &apos;{0}&apos;</source>
			<translation>Demasiadas acciones en CONTROL &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>To remove:</source>
			<translation>Para eliminar:</translation>
		</message>
		<message>
			<source>Total</source>
			<translation>Total</translation>
		</message>
		<message>
			<source>Total municipalities processed: {0}</source>
			<translation>Total de municipios procesados: {0}</translation>
		</message>
		<message>
			<source>Total replacement cost (€):</source>
			<translation>Coste total de sustitución (€):</translation>
		</message>
		<message>
			<source>translation canceled</source>
			<translation>traducción cancelada</translation>
		</message>
		<message>
			<source>translation failed in table</source>
			<translation>error de traducción en la tabla</translation>
		</message>
		<message>
			<source>translation successful</source>
			<translation>éxito de la traducción</translation>
		</message>
		<message>
			<source>Tried to set {0} to &apos;{1}&apos; but it&apos;s not an integer. Defaulting to 4 threads.</source>
			<translation>Intenté poner {0} a &apos;{1}&apos; pero no es un entero. Por defecto 4 hilos.</translation>
		</message>
		<message>
			<source>Triggers updated successfully</source>
			<translation>Activadores actualizados correctamente</translation>
		</message>
		<message>
			<source>Try again</source>
			<translation>Intentar de nuevo</translation>
		</message>
		<message>
			<source>Type</source>
			<translation>Tipo</translation>
		</message>
		<message>
			<source>Typeahead &apos;{0}&apos; doesn&apos;t have neither a queryText nor comboIds/comboNames.</source>
			<translation>Typeahead &apos;{0}&apos; no tiene ni queryText ni comboIds/comboNames.</translation>
		</message>
		<message>
			<source>Type to search...</source>
			<translation>Escriba para buscar...</translation>
		</message>
		<message>
			<source>Unable to activate psector. </source>
			<translation>No se pudo activar psector.</translation>
		</message>
		<message>
			<source>Unable to find table</source>
			<translation>No se puede encontrar la tabla</translation>
		</message>
		<message>
			<source>Unable to highlight the snapped arc.</source>
			<translation>No se puede resaltar el arco capturado.</translation>
		</message>
		<message>
			<source>Unable to highlight the snapped node.</source>
			<translation>No se puede resaltar el nodo encajado.</translation>
		</message>
		<message>
			<source>Unexpected languages payload from ({0})</source>
			<translation>Carga de idiomas inesperada desde ({0})</translation>
		</message>
		<message>
			<source>Unhandled Error</source>
			<translation>Error no controlado</translation>
		</message>
		<message>
			<source>Unit for values of input flows not informed.</source>
			<translation>Unidad para valores de flujos de entrada no informada.</translation>
		</message>
		<message>
			<source>Units not specified in the INP file.</source>
			<translation>Unidades no especificadas en el archivo INP.</translation>
		</message>
		<message>
			<source>Unknown control for EPANET INP files: {0}</source>
			<translation>Control desconocido para archivos EPANET INP: {0}</translation>
		</message>
		<message>
			<source>Unknown error</source>
			<translation>Error desconocido</translation>
		</message>
		<message>
			<source>Unrecognised form type</source>
			<translation>Tipo de formulario no reconocido</translation>
		</message>
		<message>
			<source>Unsafe path in ZIP archive: {0}</source>
			<translation>Ruta insegura en el archivo ZIP: {0}</translation>
		</message>
		<message>
			<source>Unset corporate before unvalidating this result</source>
			<translation>Desmarcar corporate antes de invalidar este resultado</translation>
		</message>
		<message>
			<source>Unsuported geometry type</source>
			<translation>Tipo de geometría sin soporte</translation>
		</message>
		<message>
			<source>Unsupported layer_type: {0}</source>
			<translation>Tipo de capa no soportado: {0}</translation>
		</message>
		<message>
			<source>Unsupported locales combo flag: {0}</source>
			<translation>Indicador de combinación de locales no compatible: {0}</translation>
		</message>
		<message>
			<source>Unsupported project type for hydraulic engine: {0}</source>
			<translation>Tipo de proyecto no compatible con el motor hidráulico: {0}</translation>
		</message>
		<message>
			<source>Unsupported URI encoding: {0}</source>
			<translation>Codificación de URI no soportada: {0}</translation>
		</message>
		<message>
			<source>Unsupported widget type: {0}</source>
			<translation>Tipo de widget no soportado: {0}</translation>
		</message>
		<message>
			<source>Update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>Update {0} ({1})</source>
			<translation>Actualizar {0} ({1})</translation>
		</message>
		<message>
			<source>Update AM Layers Symbology</source>
			<translation>Actualizar simbología de Capa AM</translation>
		</message>
		<message>
			<source>Update am schema</source>
			<translation>Actualizar es Esquema am</translation>
		</message>
		<message>
			<source>Update audit schema</source>
			<translation>Actualizar esquema de auditoría</translation>
		</message>
		<message>
			<source>Update cibs schema</source>
			<translation>Actualizar esquema cibs</translation>
		</message>
		<message>
			<source>Update cm schema</source>
			<translation>Actualizar esquema cm</translation>
		</message>
		<message>
			<source>Update configuration</source>
			<translation>Actualizar configuración</translation>
		</message>
		<message>
			<source>Update Confirmation</source>
			<translation>Confirmación de actualización</translation>
		</message>
		<message>
			<source>Update field on &quot;{0}&quot;</source>
			<translation>Actualizar Campo en &quot;{0}&quot;</translation>
		</message>
		<message>
			<source>Update language files?</source>
			<translation>¿Actualizar archivos de idioma?</translation>
		</message>
		<message>
			<source>Update multi field</source>
			<translation>Actualizar campo múltiple</translation>
		</message>
		<message>
			<source>Update multilang schema</source>
			<translation>Actualizar esquema multilenguaje</translation>
		</message>
		<message>
			<source>Update Multilang translation?</source>
			<translation>¿Actualizar traducción multilenguaje?</translation>
		</message>
		<message>
			<source>Update multilang translations?</source>
			<translation>¿Actualizar traducciones multilang?</translation>
		</message>
		<message>
			<source>Update multilang translations for ({0})</source>
			<translation>Actualizar traducciones Multilang para ({0})</translation>
		</message>
		<message>
			<source>Update network requires a WS or UD anchor.</source>
			<translation>Actualizar la red requiere un ancla WS o UD.</translation>
		</message>
		<message>
			<source>Update records</source>
			<translation>Actualizar registros</translation>
		</message>
		<message>
			<source>Update translation?</source>
			<translation>¿Actualizar traducción?</translation>
		</message>
		<message>
			<source>Updating {0}...</source>
			<translation>Actualizando {0}...</translation>
		</message>
		<message>
			<source>Updating language files for ({0})...</source>
			<translation>Actualizando archivos de idioma para ({0})...</translation>
		</message>
		<message>
			<source>Updating multilang translations for ({0})...</source>
			<translation>Actualizando traducciones multilang para ({0})...</translation>
		</message>
		<message>
			<source>Updating municipality...</source>
			<translation>Actualizando municipio...</translation>
		</message>
		<message>
			<source>Updating tables</source>
			<translation>Actualizando tablas</translation>
		</message>
		<message>
			<source>User</source>
			<translation>Usuario</translation>
		</message>
		<message>
			<source>User not found</source>
			<translation>Usuario no encontrado</translation>
		</message>
		<message>
			<source>Using this form you can configure graphconfig field for the selected mapzone.

How does it work?
1- Select the header of the mapzone using the nodeParent selection tool.
2- Select the direction of the water using the toArc selection tool. Multiple selection is allowed.
3- Press ADD to visualize your configuration on the Preview. If there are more headers, repeat the process and they will be added to the Preview.
4- If you want to configure a node that will always be closed for this mapzone, select it using the forceClosed tool and ADD.
To remove some wrong configuration, you have to select the affected nodeParent and click REMOVE. This node and its related toArc will be deleted from the Preview.

Click OK to end set your Preview as the value on graphconfig field.</source>
			<translation>Usando este formulario puede configurar el campo graphconfig para la mapzone seleccionada.

¿Cómo funciona?
1- Seleccione el encabezado de la mapzone usando la herramienta nodeParent.
2- Seleccione la dirección del agua usando la herramienta toArc. Se permite selección múltiple.
3- Pulse AÑADIR para visualizar su configuración en la Vista previa. Si hay más encabezados, repita el proceso y se añadirán a la Vista previa.
4- Si desea configurar un Nodo que siempre estará cerrado para esta mapzone, selecciónelo con la herramienta forceClosed y AÑADIR.
Para eliminar alguna configuración errónea, debe seleccionar el nodeParent afectado y hacer clic en ELIMINAR. Este Nodo y su toArc relacionado se eliminarán de la Vista previa.

Haga clic en Aceptar para finalizar y establecer su Vista previa como el Valor en el campo graphconfig.</translation>
		</message>
		<message>
			<source>Utils schema does not exist. Create it first.</source>
			<translation>El esquema utils no existe. Créelo primero.</translation>
		</message>
		<message>
			<source>Vacuum executed: {0}.{1}</source>
			<translation>Vacío ejecutado: {0}.{1}</translation>
		</message>
		<message>
			<source>Validate inputs</source>
			<translation>Validar entradas</translation>
		</message>
		<message>
			<source>Validating inputs...</source>
			<translation>Validando entradas...</translation>
		</message>
		<message>
			<source>Value</source>
			<translation>Valor</translation>
		</message>
		<message>
			<source>Value_distribution must be SIMPLE or HOURLY.</source>
			<translation>Value_distribution debe ser SIMPLE u HORARIA.</translation>
		</message>
		<message>
			<source>Value in addparam must be in a json format</source>
			<translation>El valor en addparam debe estar en formato json</translation>
		</message>
		<message>
			<source>ValueRelation lookup table not found: {0}</source>
			<translation>No se ha encontrado la tabla de búsqueda de ValueRelation: {0}</translation>
		</message>
		<message>
			<source>Values for input flows not informed.</source>
			<translation>Valores para los flujos de entrada no informados.</translation>
		</message>
		<message>
			<source>Values has been updated</source>
			<translation>Valores actualizados</translation>
		</message>
		<message>
			<source>Values saved successfully.</source>
			<translation>Valores guardados correctamente.</translation>
		</message>
		<message>
			<source>Valve Operation Check</source>
			<translation>Comprobación de operación de Válvula</translation>
		</message>
		<message>
			<source>Valves couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar válvulas!</translation>
		</message>
		<message>
			<source>Valve type not recognized: {0}</source>
			<translation>Tipo de Válvula no reconocido: {0}</translation>
		</message>
		<message>
			<source>Variable log_sql from user config file has been disabled.</source>
			<translation>Se ha deshabilitado la variable log_sql del archivo de configuración del usuario.</translation>
		</message>
		<message>
			<source>Variable log_sql from user config file has been enabled.</source>
			<translation>Se ha habilitado la variable log_sql del archivo de configuración del usuario.</translation>
		</message>
		<message>
			<source>Version</source>
			<translation>Versión</translation>
		</message>
		<message>
			<source>Visual objects</source>
			<translation>Objetos visuales</translation>
		</message>
		<message>
			<source>Warning</source>
			<translation>Advertencia</translation>
		</message>
		<message>
			<source>WARNING</source>
			<translation>ADVERTENCIA</translation>
		</message>
		<message>
			<source>Warning: Are you sure to continue?. This button will update your plugin qgis templates file replacing all strings defined on the config/dev.config file. Be sure your config file is OK before continue</source>
			<translation>Advertencia: ¿Está seguro de continuar? Este botón actualizará el archivo de plantillas del plugin qgis reemplazando todas las cadenas definidas en el archivo config/dev.config. Asegúrese de que su archivo config está bien antes de continuar</translation>
		</message>
		<message>
			<source>WARNING: This will remove the &apos;utils_workspace_current&apos; variable for your user!
Are you sure you want to delete these records?</source>
			<translation>ADVERTENCIA: ¡Esto eliminará la variable &apos;utils_workspace_current&apos; para su Usuario!
¿Está seguro de que desea eliminar estos registros?</translation>
		</message>
		<message>
			<source>We are downloading the necessary language files. Please do not close QGIS.</source>
			<translation>Estamos descargando los archivos de idioma necesarios. Por favor no cierre QGIS.</translation>
		</message>
		<message>
			<source>Weir</source>
			<translation>Vertedero</translation>
		</message>
		<message>
			<source>Weirs couldn&apos;t be inserted!</source>
			<translation>¡No se pudieron insertar vertederos!</translation>
		</message>
		<message>
			<source>widget {0} has associated function {1}, but {2} not exist</source>
			<translation>el widget {0} tiene asociada la función {1}, pero {2} no existe</translation>
		</message>
		<message>
			<source>widget {0} has not columnname and can&apos;t be configured</source>
			<translation>widget {0} no tiene nombre de columna y no se puede configurar</translation>
		</message>
		<message>
			<source>widget {0} has not columnname and cant be configured</source>
			<translation>widget {0} no tiene nombre de columna y no se puede configurar</translation>
		</message>
		<message>
			<source>widget {0} have associated function {1}, but {2} not exist</source>
			<translation>el widget {0} tiene asociada la función {1}, pero {2} no existe</translation>
		</message>
		<message>
			<source>widget {0} in tab {1} has not columnname and can&apos;t be configured</source>
			<translation>widget {0} en pestaña {1} no tiene nombre de columna y no se puede configurar</translation>
		</message>
		<message>
			<source>widget {0} in tab {1} has not columnname and cant be configured</source>
			<translation>widget {0} en pestaña {1} no tiene nombre de columna y no se puede configurar</translation>
		</message>
		<message>
			<source>Widget {0} is not configured or have a bad config</source>
			<translation>Widget {0} no está configurado o tiene una mala configuración</translation>
		</message>
		<message>
			<source>Widget &apos;{0}&apos; not found in the composer</source>
			<translation>Widget &apos;{0}&apos; no encontrado en el composer</translation>
		</message>
		<message>
			<source>Widget &apos;{0}&apos; not found in the dialog.</source>
			<translation>Widget &apos;{0}&apos; no encontrado en el diálogo.</translation>
		</message>
		<message>
			<source>Widget: {0} not in form.</source>
			<translation>Widget: {0} no está en el formulario.</translation>
		</message>
		<message>
			<source>Widget expl_id not found</source>
			<translation>Componente expl_id no encontrado</translation>
		</message>
		<message>
			<source>Widget is not a QTableView</source>
			<translation>El widget no es un QTableView</translation>
		</message>
		<message>
			<source>Widget model is none: {0}</source>
			<translation>El modelo de widget es ninguno: {0}</translation>
		</message>
		<message>
			<source>widgetname not found. </source>
			<translation>widgetname no encontrado.</translation>
		</message>
		<message>
			<source>Widget not found</source>
			<translation>Componente no encontrado</translation>
		</message>
		<message>
			<source>widgettype is wrongly configured. Needs to be in </source>
			<translation>widgettype está mal configurado. Debe estar en</translation>
		</message>
		<message>
			<source>widgettype not found. </source>
			<translation>widgettype no encontrado.</translation>
		</message>
		<message>
			<source>Without replacements</source>
			<translation>Sin sustituciones</translation>
		</message>
		<message>
			<source>With replacements</source>
			<translation>Con sustituciones</translation>
		</message>
		<message>
			<source>Workcat created successfully.</source>
			<translation>Workcat creado con éxito.</translation>
		</message>
		<message>
			<source>Work_id field is empty</source>
			<translation>El campo Work_id está vacío</translation>
		</message>
		<message>
			<source>Write inp file........: {0}</source>
			<translation>Escribe inp file........: {0}</translation>
		</message>
		<message>
			<source>Wrong number of parameters for node {0} in config file.</source>
			<translation>Número incorrecto de parámetros para el Nodo {0} en el archivo de configuración.</translation>
		</message>
		<message>
			<source>Year</source>
			<translation>Año</translation>
		</message>
		<message>
			<source>Year:</source>
			<translation>Año:</translation>
		</message>
		<message>
			<source>You are about to adapt schema &apos;{0}&apos; to cibs.

Are you sure you want to continue?</source>
			<translation>Está a punto de adaptar el Esquema &apos;{0}&apos; a cibs.

¿Está seguro de que desea continuar?</translation>
		</message>
		<message>
			<source>You are about to delete the result</source>
			<translation>Está a punto de eiminar el resultado</translation>
		</message>
		<message>
			<source>You are about to import the INP file in TESTING MODE. This will delete all the data in the database related to the network you are importing. Are you sure you want to proceed?</source>
			<translation>Está a punto de importar el fichero INP en MODO DE PRUEBA. Esto eliminará todos los datos de la base de datos relacionados con la red que está importando. ¿Está seguro de que desea continuar?</translation>
		</message>
		<message>
			<source>You are about to integrate AM with the following WS schema: {0}

Are you sure you want to continue?</source>
			<translation>Está a punto de integrar AM con el siguiente Esquema WS: {0}

¿Está seguro de que desea continuar?</translation>
		</message>
		<message>
			<source>You are about to perform this action aiming to the following schema: {0}

Are you sure you want to continue?</source>
			<translation>Está a punto de realizar esta acción dirigida al siguiente Esquema: {0}

¿Está seguro de que desea continuar?</translation>
		</message>
		<message>
			<source>You are going to change the epa_type. With this operation you will lose information about current epa_type values of this object. Would you like to continue?</source>
			<translation>Va a cambiar el epa_type. Con esta operación perderá la información sobre los valores actuales de epa_type de este objeto. ¿Desea continuar?</translation>
		</message>
		<message>
			<source>You are going to make this result corporate. From now on the result values will appear on feature form. Do you want to continue?</source>
			<translation>Vas a hacer que este resultado sea corporativo. A partir de ahora, los valores del resultado aparecerán en el formulario del elemento. ¿Quieres continuar?</translation>
		</message>
		<message>
			<source>You are not enabled to modify this {0} widget</source>
			<translation>No puede modificar este widget {0}</translation>
		</message>
		<message>
			<source>You are trying to add/remove a record from the table, with changes to the current records. If you continue, the changes will be discarded without saving. Do you want to continue?</source>
			<translation>Estás intentando añadir o eliminar un registro de la tabla, habiendo cambios en los registros actuales. Si continúas, los cambios se descartarán sin guardar. ¿Quieres continuar?</translation>
		</message>
		<message>
			<source>You are trying to add/remove a record from the table, with changes to the current records.If you continue, the changes will be discarded without saving. Do you want to continue?</source>
			<translation>Estás intentando añadir o eliminar un registro de la tabla, habiendo cambios en los registros actuales. Si continúas, los cambios se descartarán sin guardar. ¿Quieres continuar?</translation>
		</message>
		<message>
			<source>You are trying to delete your current psector. Please, change your current psector before delete.</source>
			<translation>Está intentando eliminar su psector actual. Por favor, cambie su psector actual antes de eliminarlo.</translation>
		</message>
		<message>
			<source>You cannot change the status of a result with status &apos;FINISHED&apos;.</source>
			<translation>No se puede modificar el estado de un resultado con estado &apos;FINALIZADO&apos;.</translation>
		</message>
		<message>
			<source>You cannot insert more than one feature at the same time, finish editing the previous feature</source>
			<translation>No puede insertar más de una característica al mismo tiempo, termine de editar la característica anterior</translation>
		</message>
		<message>
			<source>You can only delete results with the status &apos;CANCELED&apos;.</source>
			<translation>Solo puede eliminar resultados con estado &apos;CANCELED&apos;.</translation>
		</message>
		<message>
			<source>You can save the current configuration to a file and load it later, or load the last saved configuration.</source>
			<translation>Puede guardar la configuración actual en un archivo y cargarla más tarde, o cargar la última configuración guardada.</translation>
		</message>
		<message>
			<source>You can&apos;t delete these mincuts because they aren&apos;t planified 
or they were created by another user:</source>
			<translation>No puede Eliminar estos mincuts porque no están planificados 
o fueron creados por otro Usuario:</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time.</source>
			<translation>Cerraste una válvula, esto modificará las mapzones actuales y puede tardar un poco.</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time. Would you like to continue?</source>
			<translation>Ha cerrado una válvula, esto modificará las zonas del mapa actuales y puede tardar un poco. ¿Desea continuar?</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time.Would you like to continue?</source>
			<translation>Has cerrado una válvula, esto modificará las mapzones actuales y puede tardar un poco.¿Quieres continuar?</translation>
		</message>
		<message>
			<source>You do not have permission to execute this application</source>
			<translation>No tiene permiso para ejecutar esta aplicación</translation>
		</message>
		<message>
			<source>You don&apos;t have any connection to PostGIS database configurated. Check your QGIS data source manager and create at least one</source>
			<translation>No tienes configurada ninguna conexión con la base de datos PostGIS. Comprueba tu gestor de fuentes de datos QGIS y crea al menos una</translation>
		</message>
		<message>
			<source>You have selected multiple documents. In this case, name will be a sequential number for all selected documents and your name won&apos;t be used.</source>
			<translation>Ha seleccionado varios documentos. En este caso, el nombre será un número secuencial para todos los documentos seleccionados y no se utilizará tu nombre.</translation>
		</message>
		<message>
			<source>You have to fill in &apos;date&apos;, &apos;time&apos; and &apos;value&apos; fields!</source>
			<translation>Debe rellenar los campos &quot;fecha&quot;, &quot;hora&quot; y &quot;valor&quot;.</translation>
		</message>
		<message>
			<source>You have to fill in &apos;time&apos; and &apos;value&apos; fields!</source>
			<translation>¡Tiene que completar los campos de &apos;tiempo&apos; y &apos;valor&apos;!</translation>
		</message>
		<message>
			<source>You have to import a ibergis GPKG project first</source>
			<translation>Primero tienes que importar un proyecto ibergis GPKG</translation>
		</message>
		<message>
			<source>You have to set this parameter</source>
			<translation>Tiene que configurar este parámetro.</translation>
		</message>
		<message>
			<source>You have to set this parameter: INP file</source>
			<translation>Debes establecer este parámetro: archivo INP.</translation>
		</message>
		<message>
			<source>You have unsaved changes in the campaign selector. Close without saving?</source>
			<translation>Tiene cambios sin guardar en el selector de campaña. ¿Cerrar sin guardar?</translation>
		</message>
		<message>
			<source>You must choose at least one action</source>
			<translation>Debes elegir al menos una acción</translation>
		</message>
		<message>
			<source>You must select two different points</source>
			<translation>Debe seleccionar dos puntos diferentes</translation>
		</message>
		<message>
			<source>You need at least one row of values.</source>
			<translation>Necesita al menos una fila de valores.</translation>
		</message>
		<message>
			<source>You need to enter a customer code</source>
			<translation>Necesita ingresar un código de cliente</translation>
		</message>
		<message>
			<source>You need to enter a feature id</source>
			<translation>Debe ingresar una identificación del elemento de red</translation>
		</message>
		<message>
			<source>You need to enter a psector name</source>
			<translation>Debe introducir un nombre de psector</translation>
		</message>
		<message>
			<source>You need to enter a visit ID</source>
			<translation>Debe introducir un identificador de visita</translation>
		</message>
		<message>
			<source>You need to enter a workcat id</source>
			<translation>Debe introducir un identificador de workcat</translation>
		</message>
		<message>
			<source>You need to enter hydrometer_id</source>
			<translation>Debe ingresar hydrometer_id</translation>
		</message>
		<message>
			<source>You need to have a mesh</source>
			<translation>Necesitas tener una malla</translation>
		</message>
		<message>
			<source>You need to insert a document name</source>
			<translation>Es necesario insertar un nombre de documento</translation>
		</message>
		<message>
			<source>You need to insert data</source>
			<translation>Necesita insertar datos</translation>
		</message>
		<message>
			<source>You need to insert psector_id</source>
			<translation>Necesita insertar psector_id</translation>
		</message>
		<message>
			<source>You need to insert visit_id</source>
			<translation>Necesita insertar visit_id</translation>
		</message>
		<message>
			<source>You need to reexecute the mincut</source>
			<translation>Necesita reejecutar el mincut</translation>
		</message>
		<message>
			<source>You need to select a template</source>
			<translation>Necesita seleccionar una plantilla</translation>
		</message>
		<message>
			<source>You need to select at least one process</source>
			<translation>Debe seleccionar al menos un proceso</translation>
		</message>
		<message>
			<source>You need to select a valid parameter id</source>
			<translation>Debe seleccionar una identificación de parámetro válida</translation>
		</message>
		<message>
			<source>You need to select some sector</source>
			<translation>Tiene que seleccionar algún sector</translation>
		</message>
		<message>
			<source>Your composer&apos;s path is bad configured. Please, modify it and try again.</source>
			<translation>La ruta de su compositor está mal configurada. Por favor, modifíquela y vuelva a intentarlo.</translation>
		</message>
		<message>
			<source>Your exploitation selector has been updated</source>
			<translation>Su selector de explotación ha sido actualizado</translation>
		</message>
		<message>
			<source>You should inform a file name!</source>
			<translation>Debería informar de un nombre de archivo.</translation>
		</message>
		<message>
			<source>You should select a config file!</source>
			<translation>Debe seleccionar un archivo de configuración.</translation>
		</message>
		<message>
			<source>You should select an config file!</source>
			<translation>Debe seleccionar un archivo de configuración.</translation>
		</message>
		<message>
			<source>You should select an input INP file!</source>
			<translation>Debe seleccionar un archivo INP de entrada.</translation>
		</message>
		<message>
			<source>You should select an output folder!</source>
			<translation>Debe seleccionar una carpeta de salida.</translation>
		</message>
		<message>
			<source>Zoom to selection</source>
			<translation>Zoom a la selección</translation>
		</message>
	</context>
<!-- UI TRANSLATION -->
	<context>
		<name>add_campaign_inventory</name>
		<message>
			<source>add_campaign</source>
			<translation>Campaña</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Acometida</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Campaña</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relaciones</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_review</name>
		<message>
			<source>add_campaign</source>
			<translation>Campaña</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Campaña</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relaciones</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_review_old</name>
		<message>
			<source>action_selector</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_action_selector</source>
			<translation>action_selector</translation>
		</message>
		<message>
			<source>active</source>
			<translation>Activa:</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Campaña</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_export_rel</source>
			<translation>Exportar a csv</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_export_rel</source>
			<translation>campaign_btn_export_rel</translation>
		</message>
		<message>
			<source>campaign_btn_path_rel</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_path_rel</source>
			<translation>campaign_btn_path_rel</translation>
		</message>
		<message>
			<source>CampaignTab</source>
			<translation>Campaña</translation>
		</message>
		<message>
			<source>tooltip_CampaignTab</source>
			<translation>CampaignTab</translation>
		</message>
		<message>
			<source>grb_campaign</source>
			<translation>Campaña:</translation>
		</message>
		<message>
			<source>tooltip_grb_campaign</source>
			<translation>grb_campaign</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Ejercicio:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Series:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Inicio real:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Fin real:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Organización:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Duración:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Estado:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Dirección:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Tipo de elemento</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>label_feature_type</translation>
		</message>
		<message>
			<source>label_flexunion_code_5</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_label_flexunion_code_5</source>
			<translation>label_flexunion_code_5</translation>
		</message>
		<message>
			<source>label_node_type</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type</source>
			<translation>label_node_type</translation>
		</message>
		<message>
			<source>label_node_type_2</source>
			<translation>Final planificado:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_2</source>
			<translation>label_node_type_2</translation>
		</message>
		<message>
			<source>label_node_type_3</source>
			<translation>Inici planificado:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_3</source>
			<translation>label_node_type_3</translation>
		</message>
		<message>
			<source>label_node_type_5</source>
			<translation>Rotación:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_5</source>
			<translation>label_node_type_5</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Relación de elementos</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>RelationsTab</translation>
		</message>
		<message>
			<source>reviewclass_id</source>
			<translation>Clase de revisión:</translation>
		</message>
		<message>
			<source>tooltip_reviewclass_id</source>
			<translation>reviewclass_id</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_visit</name>
		<message>
			<source>add_campaign</source>
			<translation>Visita</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Campaña</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relaciones</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_visit_old</name>
		<message>
			<source>action_selector</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_action_selector</source>
			<translation>action_selector</translation>
		</message>
		<message>
			<source>active</source>
			<translation>Activa:</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Lote</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_export_rel</source>
			<translation>Exportar a csv</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_export_rel</source>
			<translation>campaign_btn_export_rel</translation>
		</message>
		<message>
			<source>campaign_btn_path_rel</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_path_rel</source>
			<translation>campaign_btn_path_rel</translation>
		</message>
		<message>
			<source>CampaignTab</source>
			<translation>Campaña</translation>
		</message>
		<message>
			<source>tooltip_CampaignTab</source>
			<translation>CampaignTab</translation>
		</message>
		<message>
			<source>grb_campaign</source>
			<translation>Campaña:</translation>
		</message>
		<message>
			<source>tooltip_grb_campaign</source>
			<translation>grb_campaign</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Ejercicio:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Series:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Inicio real:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Fin real:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Organización:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Duración:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Estado:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Dirección:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Tipo de elemento:</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>label_feature_type</translation>
		</message>
		<message>
			<source>label_flexunion_code_5</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_label_flexunion_code_5</source>
			<translation>label_flexunion_code_5</translation>
		</message>
		<message>
			<source>label_node_type</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type</source>
			<translation>label_node_type</translation>
		</message>
		<message>
			<source>label_node_type_2</source>
			<translation>Final planificado:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_2</source>
			<translation>label_node_type_2</translation>
		</message>
		<message>
			<source>label_node_type_3</source>
			<translation>Inici planificado:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_3</source>
			<translation>label_node_type_3</translation>
		</message>
		<message>
			<source>label_node_type_5</source>
			<translation>Rotación:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_5</source>
			<translation>label_node_type_5</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Relación de elementos</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>RelationsTab</translation>
		</message>
		<message>
			<source>visitclass_id</source>
			<translation>Visitclass:</translation>
		</message>
		<message>
			<source>tooltip_visitclass_id</source>
			<translation>visitclass_id</translation>
		</message>
	</context>
	<context>
		<name>add_lot</name>
		<message>
			<source>title</source>
			<translation>Lote</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_visit</source>
			<translation>Eliminar visita</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_visit</source>
			<translation>Eliminar visita</translation>
		</message>
		<message>
			<source>btn_export_visits</source>
			<translation>Exportar a csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_visits</source>
			<translation>Exportar a csv</translation>
		</message>
		<message>
			<source>btn_open_photo</source>
			<translation>Abrir foto</translation>
		</message>
		<message>
			<source>tooltip_btn_open_photo</source>
			<translation>Abrir foto</translation>
		</message>
		<message>
			<source>btn_open_visit</source>
			<translation>Abrir visita</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit</source>
			<translation>Abrir visita</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_validate_all</source>
			<translation>Validar todo</translation>
		</message>
		<message>
			<source>tooltip_btn_validate_all</source>
			<translation>Validar todo</translation>
		</message>
		<message>
			<source>dlg_add_lot</source>
			<translation>Lote</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_lot</source>
			<translation>dlg_add_lot</translation>
		</message>
		<message>
			<source>grb_lot</source>
			<translation>Lote:</translation>
		</message>
		<message>
			<source>tooltip_grb_lot</source>
			<translation>Lote:</translation>
		</message>
		<message>
			<source>label_data_event_from</source>
			<translation>Desde:</translation>
		</message>
		<message>
			<source>tooltip_label_data_event_from</source>
			<translation>Desde:</translation>
		</message>
		<message>
			<source>label_data_event_to</source>
			<translation>Hasta:</translation>
		</message>
		<message>
			<source>tooltip_label_data_event_to</source>
			<translation>Hasta:</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtrar por el id del elemento:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>Filtrar por el id del elemento:</translation>
		</message>
		<message>
			<source>LotTab</source>
			<translation>Lote</translation>
		</message>
		<message>
			<source>tooltip_LotTab</source>
			<translation>Lote</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Relación de elementos</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>Relación de elementos</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>VisitsTab</source>
			<translation>Visitas</translation>
		</message>
		<message>
			<source>tooltip_VisitsTab</source>
			<translation>Visitas</translation>
		</message>
	</context>
	<context>
		<name>add_workorder</name>
		<message>
			<source>title</source>
			<translation>Orden de trabajo</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_add_workorder</source>
			<translation>Orden de trabajo</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_workorder</source>
			<translation>dlg_add_workorder</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Orden de trabajo</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
	</context>
	<context>
		<name>admin</name>
		<message>
			<source>title</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>btn_activate_audit</source>
			<translation>Activar el entorno de auditoría</translation>
		</message>
		<message>
			<source>tooltip_btn_activate_audit</source>
			<translation>Generará una copia de las capas de la red de su esquema actual en el esquema de auditoría</translation>
		</message>
		<message>
			<source>btn_adapt_cibs</source>
			<translation>Adaptar Esquema para usar cibs</translation>
		</message>
		<message>
			<source>tooltip_btn_adapt_cibs</source>
			<translation>btn_adapt_cibs</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_copy</source>
			<translation>Copia</translation>
		</message>
		<message>
			<source>tooltip_btn_copy</source>
			<translation>btn_copy</translation>
		</message>
		<message>
			<source>btn_create_asset</source>
			<translation>Crear esquema de activos de BD</translation>
		</message>
		<message>
			<source>tooltip_btn_create_asset</source>
			<translation>btn_create_asset</translation>
		</message>
		<message>
			<source>btn_create_audit</source>
			<translation>Crear esquema de auditoría de BD</translation>
		</message>
		<message>
			<source>tooltip_btn_create_audit</source>
			<translation>btn_create_audit</translation>
		</message>
		<message>
			<source>btn_create_cibs</source>
			<translation>Crear esquema cibs</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cibs</source>
			<translation>btn_create_cibs</translation>
		</message>
		<message>
			<source>btn_create_cm</source>
			<translation>Crear esquema BD cm</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cm</source>
			<translation>btn_create_cm</translation>
		</message>
		<message>
			<source>btn_create_field</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create_field</source>
			<translation>btn_create_field</translation>
		</message>
		<message>
			<source>btn_create_qgis_template</source>
			<translation>Plantillas QGIS</translation>
		</message>
		<message>
			<source>tooltip_btn_create_qgis_template</source>
			<translation>btn_create_qgis_template</translation>
		</message>
		<message>
			<source>btn_create_utils</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create_utils</source>
			<translation>btn_create_utils</translation>
		</message>
		<message>
			<source>btn_custom_load_file</source>
			<translation>Cargar archivos SQL</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_load_file</source>
			<translation>btn_custom_load_file</translation>
		</message>
		<message>
			<source>btn_custom_select_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_select_file</source>
			<translation>btn_custom_select_file</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_delete_field</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_field</source>
			<translation>btn_delete_field</translation>
		</message>
		<message>
			<source>btn_gis_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_create</source>
			<translation>btn_gis_create</translation>
		</message>
		<message>
			<source>btn_gis_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_folder</source>
			<translation>btn_gis_folder</translation>
		</message>
		<message>
			<source>btn_import_osm_streetaxis</source>
			<translation>Importar OSM Streetaxis</translation>
		</message>
		<message>
			<source>tooltip_btn_import_osm_streetaxis</source>
			<translation>btn_import_osm_streetaxis</translation>
		</message>
		<message>
			<source>btn_info</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_info</source>
			<translation>Actualizar version del esquema seleccionado</translation>
		</message>
		<message>
			<source>btn_manage_languages</source>
			<translation>Gestionar Idiomas</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_languages</source>
			<translation>btn_manage_languages</translation>
		</message>
		<message>
			<source>btn_manage_schemas</source>
			<translation>Gestionar Esquemas</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_schemas</source>
			<translation>btn_manage_schemas</translation>
		</message>
		<message>
			<source>btn_markdown_generator</source>
			<translation>Generador Markdown</translation>
		</message>
		<message>
			<source>tooltip_btn_markdown_generator</source>
			<translation>btn_markdown_generator</translation>
		</message>
		<message>
			<source>btn_reload_audit_triggers</source>
			<translation>Actualizar auditoría</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_audit_triggers</source>
			<translation>Permitir iniciar/finalizar la auditoría de tablas actualizando los triggers</translation>
		</message>
		<message>
			<source>btn_reload_fct_ftrg</source>
			<translation>Ejecutar</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_fct_ftrg</source>
			<translation>btn_reload_fct_ftrg</translation>
		</message>
		<message>
			<source>btn_schema_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_create</source>
			<translation>btn_schema_create</translation>
		</message>
		<message>
			<source>btn_schema_rename</source>
			<translation>Renombrar</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_rename</source>
			<translation>btn_schema_rename</translation>
		</message>
		<message>
			<source>btn_update_asset</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update_asset</source>
			<translation>btn_update_asset</translation>
		</message>
		<message>
			<source>btn_update_cm</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update_cm</source>
			<translation>btn_update_cm</translation>
		</message>
		<message>
			<source>btn_update_field</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update_field</source>
			<translation>btn_update_field</translation>
		</message>
		<message>
			<source>btn_update_utils</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update_utils</source>
			<translation>btn_update_utils</translation>
		</message>
		<message>
			<source>btn_vacuum</source>
			<translation>Ejecutar</translation>
		</message>
		<message>
			<source>tooltip_btn_vacuum</source>
			<translation>btn_vacuum</translation>
		</message>
		<message>
			<source>chk_add_fields_multi</source>
			<translation>Addfield multicreado</translation>
		</message>
		<message>
			<source>tooltip_chk_add_fields_multi</source>
			<translation>chk_add_fields_multi</translation>
		</message>
		<message>
			<source>dlg_admin</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin</source>
			<translation>dlg_admin</translation>
		</message>
		<message>
			<source>grb_conection</source>
			<translation>Conexión</translation>
		</message>
		<message>
			<source>tooltip_grb_conection</source>
			<translation>grb_conection</translation>
		</message>
		<message>
			<source>grb_files_generator</source>
			<translation>Generador de archivos de plugin</translation>
		</message>
		<message>
			<source>tooltip_grb_files_generator</source>
			<translation>grb_files_generator</translation>
		</message>
		<message>
			<source>grb_load_cf</source>
			<translation>Cargar archivo personalizado</translation>
		</message>
		<message>
			<source>tooltip_grb_load_cf</source>
			<translation>grb_load_cf</translation>
		</message>
		<message>
			<source>grb_manage_addfields</source>
			<translation>Gestionar campos de adición</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_addfields</source>
			<translation>grb_manage_addfields</translation>
		</message>
		<message>
			<source>grb_manage_schemas</source>
			<translation>Gestión adicional de Esquemas</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_schemas</source>
			<translation>grb_manage_schemas</translation>
		</message>
		<message>
			<source>grb_project_scin</source>
			<translation>Esquema del proyecto</translation>
		</message>
		<message>
			<source>tooltip_grb_project_scin</source>
			<translation>grb_project_scin</translation>
		</message>
		<message>
			<source>grb_schema_manager</source>
			<translation>Gestión de proyecto QGIS</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_manager</source>
			<translation>grb_schema_manager</translation>
		</message>
		<message>
			<source>grb_schema_reload</source>
			<translation>Gestión de esquemas</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_reload</source>
			<translation>grb_schema_reload</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Utilidades</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Gestión adicional de esquemas</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_cibs</source>
			<translation>Esquema cibs</translation>
		</message>
		<message>
			<source>tooltip_groupBox_cibs</source>
			<translation>groupBox_cibs</translation>
		</message>
		<message>
			<source>grp_i18n_update</source>
			<translation>Actualización de esquema multilingüe</translation>
		</message>
		<message>
			<source>tooltip_grp_i18n_update</source>
			<translation>grp_i18n_update</translation>
		</message>
		<message>
			<source>grp_import_osm</source>
			<translation>Importar OSM Streetaxis</translation>
		</message>
		<message>
			<source>tooltip_grp_import_osm</source>
			<translation>grp_import_osm</translation>
		</message>
		<message>
			<source>label</source>
			<translation>WS:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>UD:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_cibs_schema</source>
			<translation>Esquema:</translation>
		</message>
		<message>
			<source>tooltip_label_cibs_schema</source>
			<translation>label_cibs_schema</translation>
		</message>
		<message>
			<source>lbl_add_fields_feature</source>
			<translation>Nombre de la función:</translation>
		</message>
		<message>
			<source>tooltip_lbl_add_fields_feature</source>
			<translation>lbl_add_fields_feature</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Nombre de la conexión:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_export_user_pass</source>
			<translation>Exportar contraseña usuario:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_user_pass</source>
			<translation>lbl_export_user_pass</translation>
		</message>
		<message>
			<source>lbl_gis_file</source>
			<translation>Nombre archivo GIS:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_file</source>
			<translation>lbl_gis_file</translation>
		</message>
		<message>
			<source>lbl_gis_folder</source>
			<translation>Carpeta GIS:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_folder</source>
			<translation>lbl_gis_folder</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Nombre:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_reload_fct_ftrg</source>
			<translation>Recargar funciones &amp;amp; activadores de funciones</translation>
		</message>
		<message>
			<source>tooltip_lbl_reload_fct_ftrg</source>
			<translation>lbl_reload_fct_ftrg</translation>
		</message>
		<message>
			<source>lbl_vacuum</source>
			<translation>Ejecutar el vacío en el esquema seleccionado</translation>
		</message>
		<message>
			<source>tooltip_lbl_vacuum</source>
			<translation>lbl_vacuum</translation>
		</message>
		<message>
			<source>tab_advanced</source>
			<translation>Avanzado</translation>
		</message>
		<message>
			<source>tooltip_tab_advanced</source>
			<translation>tab_advanced</translation>
		</message>
		<message>
			<source>tab_dev</source>
			<translation>Dev</translation>
		</message>
		<message>
			<source>tooltip_tab_dev</source>
			<translation>tab_dev</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>General</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>txt_roletype</source>
			<translation>inventario</translation>
		</message>
		<message>
			<source>tooltip_txt_roletype</source>
			<translation>txt_roletype</translation>
		</message>
	</context>
	<context>
		<name>admin_addfields</name>
		<message>
			<source>title</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Abrir</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_admin_addfields</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_addfields</source>
			<translation>dlg_admin_addfields</translation>
		</message>
		<message>
			<source>grb_additional</source>
			<translation>Configuracíon adicional</translation>
		</message>
		<message>
			<source>tooltip_grb_additional</source>
			<translation>grb_additional</translation>
		</message>
		<message>
			<source>grb_mandatory</source>
			<translation>Configuración obligatoria de campos añadidos</translation>
		</message>
		<message>
			<source>tooltip_grb_mandatory</source>
			<translation>grb_mandatory</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Activo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_columnname</source>
			<translation>Nombre de columna:</translation>
		</message>
		<message>
			<source>tooltip_lbl_columnname</source>
			<translation>lbl_columnname</translation>
		</message>
		<message>
			<source>lbl_datatype</source>
			<translation>Tipo de dato:</translation>
		</message>
		<message>
			<source>tooltip_lbl_datatype</source>
			<translation>lbl_datatype</translation>
		</message>
		<message>
			<source>lbl_dv_orderby</source>
			<translation>Ordenar por id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_orderby</source>
			<translation>lbl_dv_orderby</translation>
		</message>
		<message>
			<source>lbl_dv_querynullvalue</source>
			<translation>Consultar valor nulo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_querynullvalue</source>
			<translation>lbl_dv_querynullvalue</translation>
		</message>
		<message>
			<source>lbl_dv_querytext</source>
			<translation>Texto de consulta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_querytext</source>
			<translation>lbl_dv_querytext</translation>
		</message>
		<message>
			<source>lbl_field_name</source>
			<translation>Nombre del campo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_name</source>
			<translation>lbl_field_name</translation>
		</message>
		<message>
			<source>lbl_formtype</source>
			<translation>Tipo de formulario:</translation>
		</message>
		<message>
			<source>tooltip_lbl_formtype</source>
			<translation>lbl_formtype</translation>
		</message>
		<message>
			<source>lbl_hidden</source>
			<translation>Escondido:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hidden</source>
			<translation>lbl_hidden</translation>
		</message>
		<message>
			<source>lbl_iseditable</source>
			<translation>Editable:</translation>
		</message>
		<message>
			<source>tooltip_lbl_iseditable</source>
			<translation>lbl_iseditable</translation>
		</message>
		<message>
			<source>lbl_ismandatory</source>
			<translation>Obligatorio:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ismandatory</source>
			<translation>lbl_ismandatory</translation>
		</message>
		<message>
			<source>lbl_label</source>
			<translation>Etiqueta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_label</source>
			<translation>lbl_label</translation>
		</message>
		<message>
			<source>lbl_layoutname</source>
			<translation>Nombre del diseño:</translation>
		</message>
		<message>
			<source>tooltip_lbl_layoutname</source>
			<translation>lbl_layoutname</translation>
		</message>
		<message>
			<source>lbl_linkedobject</source>
			<translation>Objeto vinculado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_linkedobject</source>
			<translation>lbl_linkedobject</translation>
		</message>
		<message>
			<source>lbl_multifeaturetype</source>
			<translation>Función de creación múltiple:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multifeaturetype</source>
			<translation>lbl_multifeaturetype</translation>
		</message>
		<message>
			<source>lbl_placeholder</source>
			<translation>Marcador de posición</translation>
		</message>
		<message>
			<source>tooltip_lbl_placeholder</source>
			<translation>lbl_placeholder</translation>
		</message>
		<message>
			<source>lbl_stylesheet</source>
			<translation>Hoja de estilo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_stylesheet</source>
			<translation>lbl_stylesheet</translation>
		</message>
		<message>
			<source>lbl_tooltip</source>
			<translation>Tooltip:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tooltip</source>
			<translation>lbl_tooltip</translation>
		</message>
		<message>
			<source>lbl_widgetcontrols</source>
			<translation>Controles del widget:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgetcontrols</source>
			<translation>Ejemplo de la configuración {&quot;widgetdim&quot;: 150,&quot;setMultiline&quot;:true,&quot;vdefault&quot;: &quot;01-01-2014&quot;, &quot;filterSign&quot;: &quot;&gt;}</translation>
		</message>
		<message>
			<source>lbl_widgettype</source>
			<translation>Tipo de widget:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgettype</source>
			<translation>lbl_widgettype</translation>
		</message>
		<message>
			<source>stylesheet</source>
			<translation>&amp;amp;html&amp;gt;&amp;amp;head/&amp;gt;&amp;amp;body&amp;gt;&amp;amp;p&amp;gt;{amp;quot;label&amp;amp;quot; &amp;amp;quot;color:verde; font-weight:negrita;&amp;amp;quot;,&amp;amp;quot;widget&amp;amp;quot;:{amp;quot;enabled&amp;amp;quot;:&amp;amp;quot;color:negro; font-weight:negrita;&amp;amp;quot;,&amp;amp;quot;desactivado&amp;amp;quot; &amp;amp;quot;color:negro; font-weight:negrita;&amp;amp;quot;}}&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_stylesheet</source>
			<translation>{&quot;label&quot;:&quot;color:green; font-weight:bold;&quot;,&quot;widget&quot;:{&quot;enabled&quot;:&quot;color:black; font-weight:bold;&quot;,&quot;disabled&quot;:&quot;color:black; font-weight:bold;&quot;}}</translation>
		</message>
		<message>
			<source>tab_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_tab_create</source>
			<translation>tab_create</translation>
		</message>
		<message>
			<source>tab_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_tab_delete</source>
			<translation>tab_delete</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_tab_update</source>
			<translation>tab_update</translation>
		</message>
	</context>
	<context>
		<name>admin_cm_create</name>
		<message>
			<source>title</source>
			<translation>Crear proyecto</translation>
		</message>
		<message>
			<source>btn_base_schema</source>
			<translation>Crear esquema cm</translation>
		</message>
		<message>
			<source>tooltip_btn_base_schema</source>
			<translation>btn_base_schema</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Cancelar tarea</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_example</source>
			<translation>Crear ejemplo</translation>
		</message>
		<message>
			<source>tooltip_btn_example</source>
			<translation>btn_example</translation>
		</message>
		<message>
			<source>btn_parent_schema</source>
			<translation>Enlace al esquema padre</translation>
		</message>
		<message>
			<source>tooltip_btn_parent_schema</source>
			<translation>btn_parent_schema</translation>
		</message>
		<message>
			<source>btn_pschema_qgis_file</source>
			<translation>Crear archivo qgis pschema</translation>
		</message>
		<message>
			<source>tooltip_btn_pschema_qgis_file</source>
			<translation>btn_pschema_qgis_file</translation>
		</message>
		<message>
			<source>dlg_admin_cm_create</source>
			<translation>Crear proyecto</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_cm_create</source>
			<translation>dlg_admin_cm_create</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>Opciones del esquema CM</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
	</context>
	<context>
		<name>admin_credentials</name>
		<message>
			<source>title</source>
			<translation>Credenciales de conexión</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>dlg_admin_credentials</source>
			<translation>Credenciales de conexión</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_credentials</source>
			<translation>dlg_admin_credentials</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Modo SSL:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_connec</source>
			<translation>Conexión:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connec</source>
			<translation>lbl_connec</translation>
		</message>
		<message>
			<source>lbl_connection_message</source>
			<translation>No se pudieron recuperar los parámetros de conexión para:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection_message</source>
			<translation>lbl_connection_message</translation>
		</message>
		<message>
			<source>lbl_password</source>
			<translation>Contraseña:</translation>
		</message>
		<message>
			<source>tooltip_lbl_password</source>
			<translation>lbl_password</translation>
		</message>
		<message>
			<source>lbl_user_name</source>
			<translation>Nombre de usuario:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user_name</source>
			<translation>lbl_user_name</translation>
		</message>
	</context>
	<context>
		<name>admin_dbproject</name>
		<message>
			<source>title</source>
			<translation>Crear proyecto</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Cancelar tarea</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_language</source>
			<translation>btn_language</translation>
		</message>
		<message>
			<source>tooltip_btn_language</source>
			<translation>Gestionar idiomas</translation>
		</message>
		<message>
			<source>dlg_admin_dbproject</source>
			<translation>Crear proyecto</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_dbproject</source>
			<translation>dlg_admin_dbproject</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>Configuracion del esquema de proyecto</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtrar SRID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>Identificador de la referencia espacial. Solo se permiten los valores que se muestran en la tabla</translation>
		</message>
		<message>
			<source>lbl_locale</source>
			<translation>Idioma:</translation>
		</message>
		<message>
			<source>tooltip_lbl_locale</source>
			<translation>Idioma del esquema</translation>
		</message>
		<message>
			<source>lbl_project_name</source>
			<translation>Nombre proyecto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_name</source>
			<translation>Nombre de un esquema nuevo. El nombre debe escribirse en minúsculas, utilizando solo letras del alfabeto inglés y sin espacios ni guiones</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Tipo de proyecto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_source</source>
			<translation>Fuente de datos:</translation>
		</message>
		<message>
			<source>tooltip_lbl_source</source>
			<translation>lbl_source</translation>
		</message>
		<message>
			<source>rdb_empty</source>
			<translation>Sin datos</translation>
		</message>
		<message>
			<source>tooltip_rdb_empty</source>
			<translation>rdb_empty</translation>
		</message>
		<message>
			<source>rdb_sample_full</source>
			<translation>Ejemplo completo</translation>
		</message>
		<message>
			<source>tooltip_rdb_sample_full</source>
			<translation>rdb_sample_full</translation>
		</message>
		<message>
			<source>rdb_sample_inv</source>
			<translation>Ejemplo inventario</translation>
		</message>
		<message>
			<source>tooltip_rdb_sample_inv</source>
			<translation>rdb_sample_inv</translation>
		</message>
	</context>
	<context>
		<name>admin_gisproject</name>
		<message>
			<source>title</source>
			<translation>Crear un proyecto SIG</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_gis_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_folder</source>
			<translation>btn_gis_folder</translation>
		</message>
		<message>
			<source>dlg_admin_gisproject</source>
			<translation>Crear un proyecto SIG</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_gisproject</source>
			<translation>dlg_admin_gisproject</translation>
		</message>
		<message>
			<source>lbl_export_user_pass</source>
			<translation>Exportar contraseña usuario:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_user_pass</source>
			<translation>lbl_export_user_pass</translation>
		</message>
		<message>
			<source>lbl_gis_file</source>
			<translation>Nombre archivo GIS:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_file</source>
			<translation>lbl_gis_file</translation>
		</message>
		<message>
			<source>lbl_gis_folder</source>
			<translation>Carpeta GIS:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_folder</source>
			<translation>lbl_gis_folder</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Tipo de proyecto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>txt_roletype</source>
			<translation>inventario</translation>
		</message>
		<message>
			<source>tooltip_txt_roletype</source>
			<translation>txt_roletype</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_hot_update</name>
		<message>
			<source>title</source>
			<translation>Gestionar idiomas</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Aplicar</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>btn_apply</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_manage_language_hot_update</source>
			<translation>Idiomas</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_language_hot_update</source>
			<translation>btn_manage_language_hot_update</translation>
		</message>
		<message>
			<source>btn_manage_language_multilang</source>
			<translation>Idiomas</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_language_multilang</source>
			<translation>btn_manage_language_multilang</translation>
		</message>
		<message>
			<source>btn_refresh</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh</source>
			<translation>btn_refresh</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>chk_add_tab_data</source>
			<translation>Traducir tab_data</translation>
		</message>
		<message>
			<source>tooltip_chk_add_tab_data</source>
			<translation>chk_add_tab_data</translation>
		</message>
		<message>
			<source>chk_use_selected_tables</source>
			<translation>Usar solo tablas seleccionadas</translation>
		</message>
		<message>
			<source>tooltip_chk_use_selected_tables</source>
			<translation>chk_use_selected_tables</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_hot_update</source>
			<translation>Gestionar idiomas</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_hot_update</source>
			<translation>dlg_admin_i18n_hot_update</translation>
		</message>
		<message>
			<source>grb_connection</source>
			<translation>Conexión</translation>
		</message>
		<message>
			<source>tooltip_grb_connection</source>
			<translation>grb_connection</translation>
		</message>
		<message>
			<source>grb_params</source>
			<translation>Parámetros</translation>
		</message>
		<message>
			<source>tooltip_grb_params</source>
			<translation>grb_params</translation>
		</message>
		<message>
			<source>grb_schemas</source>
			<translation>Esquemas</translation>
		</message>
		<message>
			<source>tooltip_grb_schemas</source>
			<translation>grb_schemas</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Idioma:</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Idioma</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Nombre de conexión:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_schema_selection</source>
			<translation>Esquema: seleccione una fila a continuación</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_selection</source>
			<translation>lbl_schema_selection</translation>
		</message>
		<message>
			<source>lbl_tables</source>
			<translation>Filtro de tablas:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tables</source>
			<translation>lbl_tables</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Actualización en caliente</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_2</source>
			<translation>Multilenguaje</translation>
		</message>
		<message>
			<source>tooltip_tab_2</source>
			<translation>tab_2</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_languages</name>
		<message>
			<source>title</source>
			<translation>Gestionar idioma</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_download</source>
			<translation>Descargar</translation>
		</message>
		<message>
			<source>tooltip_btn_download</source>
			<translation>btn_download</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>chk_download_latest</source>
			<translation>Descargar la última versión de traducción</translation>
		</message>
		<message>
			<source>tooltip_chk_download_latest</source>
			<translation>Descargar traducciones desde la última versión publicada en lugar de la versión emparejada con este complemento. Solo para usuarios avanzados.</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_languages</source>
			<translation>Gestionar idioma</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_languages</source>
			<translation>dlg_admin_i18n_languages</translation>
		</message>
		<message>
			<source>grb_locales</source>
			<translation>Idiomas disponibles</translation>
		</message>
		<message>
			<source>tooltip_grb_locales</source>
			<translation>grb_locales</translation>
		</message>
		<message>
			<source>lbl_language</source>
			<translation>Seleccione un idioma para gestionar</translation>
		</message>
		<message>
			<source>tooltip_lbl_language</source>
			<translation>lbl_language</translation>
		</message>
		<message>
			<source>txt_filter</source>
			<translation>Filtrar locales...</translation>
		</message>
		<message>
			<source>tooltip_txt_filter</source>
			<translation>txt_filter</translation>
		</message>
	</context>
	<context>
		<name>admin_import_osm</name>
		<message>
			<source>title</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Ejecutar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_admin_import_osm</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_import_osm</source>
			<translation>dlg_admin_import_osm</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Municipios</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Registros</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>admin_manage_schemas</name>
		<message>
			<source>title</source>
			<translation>Gestionar Esquemas</translation>
		</message>
		<message>
			<source>btn_activate_audit</source>
			<translation>Activar</translation>
		</message>
		<message>
			<source>tooltip_btn_activate_audit</source>
			<translation>Generar una copia de las capas de la red desde el Esquema ancla en la auditoría</translation>
		</message>
		<message>
			<source>btn_cibs_copy</source>
			<translation>Copiar datos</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_copy</source>
			<translation>btn_cibs_copy</translation>
		</message>
		<message>
			<source>btn_cibs_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_create</source>
			<translation>btn_cibs_create</translation>
		</message>
		<message>
			<source>btn_cibs_integrate</source>
			<translation>Integrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_integrate</source>
			<translation>Enlazar cibs con el Esquema de red seleccionado</translation>
		</message>
		<message>
			<source>btn_cibs_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_update</source>
			<translation>btn_cibs_update</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_cm_integrate</source>
			<translation>Integrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_integrate</source>
			<translation>Enlazar CM con el esquema de red seleccionado</translation>
		</message>
		<message>
			<source>btn_cm_qgis</source>
			<translation>btn_cm_qgis</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_qgis</source>
			<translation>Crear archivo pschema qgis</translation>
		</message>
		<message>
			<source>btn_cm_sample</source>
			<translation>Ejemplo</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_sample</source>
			<translation>Cargar datos de ejemplo CM para el Esquema de red seleccionado</translation>
		</message>
		<message>
			<source>btn_create_am</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create_am</source>
			<translation>btn_create_am</translation>
		</message>
		<message>
			<source>btn_create_am_sample</source>
			<translation>+ Muestra</translation>
		</message>
		<message>
			<source>tooltip_btn_create_am_sample</source>
			<translation>Crear Esquema AM con datos de fugas de muestra</translation>
		</message>
		<message>
			<source>btn_create_audit</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create_audit</source>
			<translation>btn_create_audit</translation>
		</message>
		<message>
			<source>btn_create_cm</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cm</source>
			<translation>btn_create_cm</translation>
		</message>
		<message>
			<source>btn_delete_am</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_am</source>
			<translation>btn_delete_am</translation>
		</message>
		<message>
			<source>btn_delete_audit</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_audit</source>
			<translation>btn_delete_audit</translation>
		</message>
		<message>
			<source>btn_delete_cm</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_cm</source>
			<translation>btn_delete_cm</translation>
		</message>
		<message>
			<source>btn_i18n_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_create</source>
			<translation>btn_i18n_create</translation>
		</message>
		<message>
			<source>btn_i18n_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_delete</source>
			<translation>btn_i18n_delete</translation>
		</message>
		<message>
			<source>btn_i18n_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_update</source>
			<translation>btn_i18n_update</translation>
		</message>
		<message>
			<source>btn_integrate_am</source>
			<translation>Integrar</translation>
		</message>
		<message>
			<source>tooltip_btn_integrate_am</source>
			<translation>Conectar AM al Esquema de red WS seleccionado</translation>
		</message>
		<message>
			<source>btn_integrate_am_sample</source>
			<translation>Int. + Ejemplo</translation>
		</message>
		<message>
			<source>tooltip_btn_integrate_am_sample</source>
			<translation>Integrar configuración am y seed desde los catálogos WS padre</translation>
		</message>
		<message>
			<source>btn_languages</source>
			<translation>Idiomas</translation>
		</message>
		<message>
			<source>tooltip_btn_languages</source>
			<translation>btn_languages</translation>
		</message>
		<message>
			<source>btn_network_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_network_delete</source>
			<translation>btn_network_delete</translation>
		</message>
		<message>
			<source>btn_network_rename</source>
			<translation>Renombrar</translation>
		</message>
		<message>
			<source>tooltip_btn_network_rename</source>
			<translation>btn_network_rename</translation>
		</message>
		<message>
			<source>btn_refresh</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh</source>
			<translation>btn_refresh</translation>
		</message>
		<message>
			<source>btn_reload_audit_triggers</source>
			<translation>Disparadores</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_audit_triggers</source>
			<translation>Actualizar disparadores de auditoría en el Esquema ancla</translation>
		</message>
		<message>
			<source>btn_update_am</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update_am</source>
			<translation>btn_update_am</translation>
		</message>
		<message>
			<source>btn_update_audit</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update_audit</source>
			<translation>btn_update_audit</translation>
		</message>
		<message>
			<source>btn_update_cm</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update_cm</source>
			<translation>btn_update_cm</translation>
		</message>
		<message>
			<source>btn_update_network</source>
			<translation>Actualizar red</translation>
		</message>
		<message>
			<source>tooltip_btn_update_network</source>
			<translation>Actualizar WS/UD ancla y satélites vinculados a la versión del complemento</translation>
		</message>
		<message>
			<source>btn_utils_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_create</source>
			<translation>btn_utils_create</translation>
		</message>
		<message>
			<source>btn_utils_integrate</source>
			<translation>Integrar</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_integrate</source>
			<translation>Enlazar utilidades al Esquema de red seleccionado</translation>
		</message>
		<message>
			<source>btn_utils_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_update</source>
			<translation>btn_utils_update</translation>
		</message>
		<message>
			<source>dlg_admin_manage_schemas</source>
			<translation>Gestionar Esquemas</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_manage_schemas</source>
			<translation>dlg_admin_manage_schemas</translation>
		</message>
		<message>
			<source>grb_am</source>
			<translation>AM</translation>
		</message>
		<message>
			<source>tooltip_grb_am</source>
			<translation>grb_am</translation>
		</message>
		<message>
			<source>grb_audit</source>
			<translation>Auditoría</translation>
		</message>
		<message>
			<source>tooltip_grb_audit</source>
			<translation>grb_audit</translation>
		</message>
		<message>
			<source>grb_cibs</source>
			<translation>Cibs</translation>
		</message>
		<message>
			<source>tooltip_grb_cibs</source>
			<translation>grb_cibs</translation>
		</message>
		<message>
			<source>grb_cm</source>
			<translation>CM</translation>
		</message>
		<message>
			<source>tooltip_grb_cm</source>
			<translation>grb_cm</translation>
		</message>
		<message>
			<source>grb_connection</source>
			<translation>Conexión</translation>
		</message>
		<message>
			<source>tooltip_grb_connection</source>
			<translation>grb_connection</translation>
		</message>
		<message>
			<source>grb_i18n</source>
			<translation>Multilenguaje</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n</source>
			<translation>grb_i18n</translation>
		</message>
		<message>
			<source>grb_network</source>
			<translation>Red (WS / UD)</translation>
		</message>
		<message>
			<source>tooltip_grb_network</source>
			<translation>grb_network</translation>
		</message>
		<message>
			<source>grb_utils</source>
			<translation>Utilidades</translation>
		</message>
		<message>
			<source>tooltip_grb_utils</source>
			<translation>grb_utils</translation>
		</message>
		<message>
			<source>lbl_am_info</source>
			<translation>No instalado</translation>
		</message>
		<message>
			<source>tooltip_lbl_am_info</source>
			<translation>lbl_am_info</translation>
		</message>
		<message>
			<source>lbl_audit_info</source>
			<translation>No instalado</translation>
		</message>
		<message>
			<source>tooltip_lbl_audit_info</source>
			<translation>lbl_audit_info</translation>
		</message>
		<message>
			<source>lbl_cibs_info</source>
			<translation>No instalado</translation>
		</message>
		<message>
			<source>tooltip_lbl_cibs_info</source>
			<translation>lbl_cibs_info</translation>
		</message>
		<message>
			<source>lbl_cm_info</source>
			<translation>No instalado</translation>
		</message>
		<message>
			<source>tooltip_lbl_cm_info</source>
			<translation>lbl_cm_info</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Nombre de conexión:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_i18n_info</source>
			<translation>No instalado</translation>
		</message>
		<message>
			<source>tooltip_lbl_i18n_info</source>
			<translation>lbl_i18n_info</translation>
		</message>
		<message>
			<source>lbl_network_selection</source>
			<translation>Ancla: seleccione una fila a continuación</translation>
		</message>
		<message>
			<source>tooltip_lbl_network_selection</source>
			<translation>lbl_network_selection</translation>
		</message>
		<message>
			<source>lbl_utils_info</source>
			<translation>No instalado</translation>
		</message>
		<message>
			<source>tooltip_lbl_utils_info</source>
			<translation>lbl_utils_info</translation>
		</message>
	</context>
	<context>
		<name>admin_markdown</name>
		<message>
			<source>title</source>
			<translation>A</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_generate</source>
			<translation>Genere</translation>
		</message>
		<message>
			<source>tooltip_btn_generate</source>
			<translation>btn_generate</translation>
		</message>
		<message>
			<source>dlg_admin_markdown</source>
			<translation>A</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_markdown</source>
			<translation>dlg_admin_markdown</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Tipo de proyecto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Nombre del esquema:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lb_path</source>
			<translation>Ruta del archivo:</translation>
		</message>
		<message>
			<source>tooltip_lb_path</source>
			<translation>lb_path</translation>
		</message>
		<message>
			<source>pushButton_2</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_pushButton_2</source>
			<translation>pushButton_2</translation>
		</message>
	</context>
	<context>
		<name>admin_markdown_generator</name>
		<message>
			<source>title</source>
			<translation>A</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_generate</source>
			<translation>Genere</translation>
		</message>
		<message>
			<source>tooltip_btn_generate</source>
			<translation>btn_generate</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>cmb_projecttype</source>
			<translation>ud</translation>
		</message>
		<message>
			<source>tooltip_cmb_projecttype</source>
			<translation>cmb_projecttype</translation>
		</message>
		<message>
			<source>dlg_admin_markdown_generator</source>
			<translation>A</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_markdown_generator</source>
			<translation>dlg_admin_markdown_generator</translation>
		</message>
		<message>
			<source>grp_markdown_destination</source>
			<translation>Descripción Markdown</translation>
		</message>
		<message>
			<source>tooltip_grp_markdown_destination</source>
			<translation>grp_markdown_destination</translation>
		</message>
		<message>
			<source>grp_origin_schema</source>
			<translation>Esquema de origen</translation>
		</message>
		<message>
			<source>tooltip_grp_origin_schema</source>
			<translation>grp_origin_schema</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Tipo de proyecto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Nombre del esquema:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lb_path</source>
			<translation>Ruta del archivo:</translation>
		</message>
		<message>
			<source>tooltip_lb_path</source>
			<translation>lb_path</translation>
		</message>
	</context>
	<context>
		<name>admin_projectinfo</name>
		<message>
			<source>title</source>
			<translation>Actualizar SQL</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>dlg_admin_projectinfo</source>
			<translation>Actualizar SQL</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_projectinfo</source>
			<translation>dlg_admin_projectinfo</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Información sobre nuevas actualizaciones</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>tab_main</source>
			<translation>Principal</translation>
		</message>
		<message>
			<source>tooltip_tab_main</source>
			<translation>tab_main</translation>
		</message>
	</context>
	<context>
		<name>admin_renameproj</name>
		<message>
			<source>title</source>
			<translation>Renombrar</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>dlg_admin_renameproj</source>
			<translation>Renombrar</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_renameproj</source>
			<translation>dlg_admin_renameproj</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Por favor, configure un nuevo nombre de proyecto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>lbl_rename_copy</translation>
		</message>
	</context>
	<context>
		<name>admin_visitclass</name>
		<message>
			<source>title</source>
			<translation>Gestionar la clase de visita</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_class_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_class_cancel</source>
			<translation>btn_class_cancel</translation>
		</message>
		<message>
			<source>btn_class_ok</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_class_ok</source>
			<translation>btn_class_ok</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_param_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_param_create</source>
			<translation>btn_param_create</translation>
		</message>
		<message>
			<source>btn_param_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_param_delete</source>
			<translation>btn_param_delete</translation>
		</message>
		<message>
			<source>btn_param_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_param_update</source>
			<translation>btn_param_update</translation>
		</message>
		<message>
			<source>dlg_admin_visitclass</source>
			<translation>Gestionar la clase de visita</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_visitclass</source>
			<translation>dlg_admin_visitclass</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Clase</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Parámetro</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Activo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_class_id</source>
			<translation>Id clase:</translation>
		</message>
		<message>
			<source>tooltip_lbl_class_id</source>
			<translation>lbl_class_id</translation>
		</message>
		<message>
			<source>lbl_class_name</source>
			<translation>Nombre clase:</translation>
		</message>
		<message>
			<source>tooltip_lbl_class_name</source>
			<translation>lbl_class_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_feat_type</source>
			<translation>Tipo de objeto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_type</source>
			<translation>lbl_feat_type</translation>
		</message>
		<message>
			<source>lbl_multi_event</source>
			<translation>Evento múltiple:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multi_event</source>
			<translation>lbl_multi_event</translation>
		</message>
		<message>
			<source>lbl_multi_feat</source>
			<translation>Elemento múltiple:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multi_feat</source>
			<translation>lbl_multi_feat</translation>
		</message>
		<message>
			<source>lbl_param_opt</source>
			<translation>Opciones parámetro:</translation>
		</message>
		<message>
			<source>tooltip_lbl_param_opt</source>
			<translation>lbl_param_opt</translation>
		</message>
		<message>
			<source>lbl_viewname</source>
			<translation>Ver nombre:</translation>
		</message>
		<message>
			<source>tooltip_lbl_viewname</source>
			<translation>lbl_viewname</translation>
		</message>
		<message>
			<source>lbl_visit_type</source>
			<translation>Tipo visita:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_type</source>
			<translation>lbl_visit_type</translation>
		</message>
	</context>
	<context>
		<name>admin_visitparam</name>
		<message>
			<source>title</source>
			<translation>Gestionar el parámetro de visita</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_admin_visitparam</source>
			<translation>Gestionar el parámetro de visita</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_visitparam</source>
			<translation>dlg_admin_visitparam</translation>
		</message>
		<message>
			<source>grb_params</source>
			<translation>Parametros</translation>
		</message>
		<message>
			<source>tooltip_grb_params</source>
			<translation>grb_params</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation>Código:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_data_type</source>
			<translation>Tipo dato:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_type</source>
			<translation>lbl_data_type</translation>
		</message>
		<message>
			<source>lbl_default_value</source>
			<translation>Valor por defecto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_default_value</source>
			<translation>lbl_default_value</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_editable</source>
			<translation>Editable:</translation>
		</message>
		<message>
			<source>tooltip_lbl_editable</source>
			<translation>lbl_editable</translation>
		</message>
		<message>
			<source>lbl_enabled</source>
			<translation>Habilitado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enabled</source>
			<translation>lbl_enabled</translation>
		</message>
		<message>
			<source>lbl_form_type</source>
			<translation>Tipo formulario:</translation>
		</message>
		<message>
			<source>tooltip_lbl_form_type</source>
			<translation>lbl_form_type</translation>
		</message>
		<message>
			<source>lbl_mandatory</source>
			<translation>Obligatorio:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mandatory</source>
			<translation>lbl_mandatory</translation>
		</message>
		<message>
			<source>lbl_parameter_name</source>
			<translation>Nombre parámetro:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_name</source>
			<translation>lbl_parameter_name</translation>
		</message>
		<message>
			<source>lbl_parameter_type</source>
			<translation>Tipo parámetro:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_type</source>
			<translation>lbl_parameter_type</translation>
		</message>
		<message>
			<source>lbl_query_text</source>
			<translation>Texto de consulta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_query_text</source>
			<translation>lbl_query_text</translation>
		</message>
		<message>
			<source>lbl_short_descript</source>
			<translation>Descripción corta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_short_descript</source>
			<translation>lbl_short_descript</translation>
		</message>
		<message>
			<source>lbl_widgettype</source>
			<translation>Tipo de widget:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgettype</source>
			<translation>lbl_widgettype</translation>
		</message>
	</context>
	<context>
		<name>arc_fusion</name>
		<message>
			<source>title</source>
			<translation>Fusionar arco</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>dlg_arc_fusion</source>
			<translation>Fusionar arco</translation>
		</message>
		<message>
			<source>tooltip_dlg_arc_fusion</source>
			<translation>dlg_arc_fusion</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>lbl_arc1asset</source>
			<translation>Arco 1 activo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc1asset</source>
			<translation>lbl_arc1asset</translation>
		</message>
		<message>
			<source>lbl_arc1cat</source>
			<translation>Catálogo Arco 1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc1cat</source>
			<translation>lbl_arc1cat</translation>
		</message>
		<message>
			<source>lbl_arc2asset</source>
			<translation>Arco 2 activo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc2asset</source>
			<translation>lbl_arc2asset</translation>
		</message>
		<message>
			<source>lbl_arc2cat</source>
			<translation>Catálogo Arco 2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc2cat</source>
			<translation>lbl_arc2cat</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Fecha de finalización:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_new_asset</source>
			<translation>Nuevo activo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_asset</source>
			<translation>lbl_new_asset</translation>
		</message>
		<message>
			<source>lbl_new_cat</source>
			<translation>Nuevo catálogo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_cat</source>
			<translation>lbl_new_cat</translation>
		</message>
		<message>
			<source>lbl_nodeaction</source>
			<translation>Acción sobre nodo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodeaction</source>
			<translation>lbl_nodeaction</translation>
		</message>
		<message>
			<source>lbl_statetype</source>
			<translation>Estado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_statetype</source>
			<translation>lbl_statetype</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Id expdte baja:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Fusionar arco</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>assignation</name>
		<message>
			<source>title</source>
			<translation>Asignación de fugas</translation>
		</message>
		<message>
			<source>chk_all_leaks</source>
			<translation>Utilizar todas las fugas</translation>
		</message>
		<message>
			<source>tooltip_chk_all_leaks</source>
			<translation>Calcula fugas por kilómetro por año usando todos los datos disponibles, independientemente del parámetro &apos;años a calcular&apos;.</translation>
		</message>
		<message>
			<source>dlg_assignation</source>
			<translation>Asignación de fugas</translation>
		</message>
		<message>
			<source>tooltip_dlg_assignation</source>
			<translation>dlg_assignation</translation>
		</message>
		<message>
			<source>lbl_buffer</source>
			<translation>Distancia de seguridad (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_buffer</source>
			<translation>Distancia desde una fuga a la que se seleccionan tuberías para asignar esa fuga.</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Filtrar por fecha de construcción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>Usa solo tuberías que coinciden con el rango de fecha de construcción de la inicial.</translation>
		</message>
		<message>
			<source>lbl_builtdate_range</source>
			<translation>Rango de fechas de construcción (años):</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate_range</source>
			<translation>Rango de fecha de construcción, en años antes y después de la tubería inicial.</translation>
		</message>
		<message>
			<source>lbl_cluster_length</source>
			<translation>Longitud del racimo (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_cluster_length</source>
			<translation>Suma máxima de longitudes de tubería dentro de un clúster, en metros.</translation>
		</message>
		<message>
			<source>lbl_diameter</source>
			<translation>Filtrar por diámetro:</translation>
		</message>
		<message>
			<source>tooltip_lbl_diameter</source>
			<translation>Usa solo tuberías que coinciden con el rango de Diámetro de la inicial.</translation>
		</message>
		<message>
			<source>lbl_diameter_range</source>
			<translation>Rango de diámetros:</translation>
		</message>
		<message>
			<source>tooltip_lbl_diameter_range</source>
			<translation>Rango de Diámetro basado en factores de la tubería inicial.</translation>
		</message>
		<message>
			<source>lbl_leaks</source>
			<translation>Fugas</translation>
		</message>
		<message>
			<source>tooltip_lbl_leaks</source>
			<translation>lbl_leaks</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Filtrar por material:</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>Usa solo tuberías del mismo Material que la inicial.</translation>
		</message>
		<message>
			<source>lbl_max_distance</source>
			<translation>Distancia máxima (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_max_distance</source>
			<translation>Distancia máxima, en metros, entre la tubería inicial y otras tuberías incluidas en el clúster.</translation>
		</message>
		<message>
			<source>lbl_pipes</source>
			<translation>Tuberías</translation>
		</message>
		<message>
			<source>tooltip_lbl_pipes</source>
			<translation>lbl_pipes</translation>
		</message>
		<message>
			<source>lbl_years</source>
			<translation>Años para calcular:</translation>
		</message>
		<message>
			<source>tooltip_lbl_years</source>
			<translation>Número de años de datos de fugas a considerar, basados en la recencia.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>audit</name>
		<message>
			<source>title</source>
			<translation>Auditoría</translation>
		</message>
		<message>
			<source>dlg_audit</source>
			<translation>Auditoría</translation>
		</message>
		<message>
			<source>tooltip_dlg_audit</source>
			<translation>dlg_audit</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Valores actualizados</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
	</context>
	<context>
		<name>audit_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de registros</translation>
		</message>
		<message>
			<source>dlg_audit_manager</source>
			<translation>Gestor de registros</translation>
		</message>
		<message>
			<source>tooltip_dlg_audit_manager</source>
			<translation>Director de auditoría</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Registros</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Registros</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Fecha a ir</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Fecha a</translation>
		</message>
	</context>
	<context>
		<name>auxcircle</name>
		<message>
			<source>title</source>
			<translation>Dibujar circulo CAD</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>chk_delete_prev</source>
			<translation>Eliminar círculos anteriores</translation>
		</message>
		<message>
			<source>tooltip_chk_delete_prev</source>
			<translation>chk_delete_prev</translation>
		</message>
		<message>
			<source>dlg_auxcircle</source>
			<translation>Dibujar circulo CAD</translation>
		</message>
		<message>
			<source>tooltip_dlg_auxcircle</source>
			<translation>dlg_auxcircle</translation>
		</message>
		<message>
			<source>lbl_ins_radius</source>
			<translation>Insertar radio:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ins_radius</source>
			<translation>lbl_ins_radius</translation>
		</message>
		<message>
			<source>radius</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_radius</source>
			<translation>radius</translation>
		</message>
	</context>
	<context>
		<name>auxpoint</name>
		<message>
			<source>title</source>
			<translation>Añadir punto CAD</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>chk_delete_prev</source>
			<translation>Eliminar puntos anteriores</translation>
		</message>
		<message>
			<source>tooltip_chk_delete_prev</source>
			<translation>chk_delete_prev</translation>
		</message>
		<message>
			<source>dist_x</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_dist_x</source>
			<translation>dist_x</translation>
		</message>
		<message>
			<source>dist_y</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_dist_y</source>
			<translation>dist_y</translation>
		</message>
		<message>
			<source>dlg_auxpoint</source>
			<translation>Añadir punto CAD</translation>
		</message>
		<message>
			<source>tooltip_dlg_auxpoint</source>
			<translation>dlg_auxpoint</translation>
		</message>
		<message>
			<source>grb_from</source>
			<translation>Desde</translation>
		</message>
		<message>
			<source>tooltip_grb_from</source>
			<translation>grb_from</translation>
		</message>
		<message>
			<source>lbl_distx</source>
			<translation>Distancia X:</translation>
		</message>
		<message>
			<source>tooltip_lbl_distx</source>
			<translation>lbl_distx</translation>
		</message>
		<message>
			<source>lbl_disty</source>
			<translation>Distancia Y:</translation>
		</message>
		<message>
			<source>tooltip_lbl_disty</source>
			<translation>lbl_disty</translation>
		</message>
		<message>
			<source>rb_left</source>
			<translation>Punto inicial</translation>
		</message>
		<message>
			<source>tooltip_rb_left</source>
			<translation>rb_left</translation>
		</message>
		<message>
			<source>rb_right</source>
			<translation>Punto final</translation>
		</message>
		<message>
			<source>tooltip_rb_right</source>
			<translation>rb_right</translation>
		</message>
	</context>
	<context>
		<name>campaign_management</name>
		<message>
			<source>title</source>
			<translation>Administrador de campañas</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_child</source>
			<translation>Crear Campaña hija</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_child</source>
			<translation>campaign_btn_child</translation>
		</message>
		<message>
			<source>campaign_btn_delete</source>
			<translation>Eliminar campaña</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_delete</source>
			<translation>Eliminar campaña</translation>
		</message>
		<message>
			<source>campaign_btn_open</source>
			<translation>Abrir campaña</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_open</source>
			<translation>Abrir campaña</translation>
		</message>
		<message>
			<source>campaign_chk_show_nulls</source>
			<translation>Mostrar valores vacíos</translation>
		</message>
		<message>
			<source>tooltip_campaign_chk_show_nulls</source>
			<translation>Mostrar valores vacíos</translation>
		</message>
		<message>
			<source>dlg_campaign_management</source>
			<translation>Administrador de campañas</translation>
		</message>
		<message>
			<source>tooltip_dlg_campaign_management</source>
			<translation>Administrador de campañas</translation>
		</message>
		<message>
			<source>lbl_column_filter_dates</source>
			<translation>Columna filtrar datos:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter_dates</source>
			<translation>Columna filtrar datos:</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Desde:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>Desde:</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Hasta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>Hasta:</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Estado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Estado:</translation>
		</message>
	</context>
	<context>
		<name>check_project</name>
		<message>
			<source>title</source>
			<translation>Verificar proyecto</translation>
		</message>
		<message>
			<source>brb_database_check</source>
			<translation>Chequeo de la base de datos:</translation>
		</message>
		<message>
			<source>tooltip_brb_database_check</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_check_project</source>
			<translation>Verificar proyecto</translation>
		</message>
		<message>
			<source>tooltip_dlg_check_project</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Información:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>grb_system_check</source>
			<translation>Chequeo del sistema:</translation>
		</message>
		<message>
			<source>tooltip_grb_system_check</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Database log</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Registros</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>check_project_cm</name>
		<message>
			<source>title</source>
			<translation>Verificar proyecto</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>chk_manage_config</source>
			<translation>Comprobar la configuración de gestión</translation>
		</message>
		<message>
			<source>tooltip_chk_manage_config</source>
			<translation>chk_manage_config</translation>
		</message>
		<message>
			<source>dlg_check_project_cm</source>
			<translation>Verificar proyecto</translation>
		</message>
		<message>
			<source>tooltip_dlg_check_project_cm</source>
			<translation>dlg_check_project_cm</translation>
		</message>
		<message>
			<source>grb_database_health_check</source>
			<translation>Comprobación del estado de la base de datos</translation>
		</message>
		<message>
			<source>tooltip_grb_database_health_check</source>
			<translation>grb_database_health_check</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_system_health_check</source>
			<translation>Comprobación del estado del sistema</translation>
		</message>
		<message>
			<source>tooltip_grb_system_health_check</source>
			<translation>grb_system_health_check</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Info de base de datos:</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Registros</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>common</name>
		<message>
			<source>btn_help</source>
			<translation>Ayuda</translation>
		</message>
		<message>
			<source>tooltip_btn_help</source>
			<translation>Ayuda</translation>
		</message>
	</context>
	<context>
		<name>config</name>
		<message>
			<source>title</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>dlg_config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_dlg_config</source>
			<translation>dlg_config</translation>
		</message>
		<message>
			<source>grb_addfields</source>
			<translation>Campos adicionales</translation>
		</message>
		<message>
			<source>tooltip_grb_addfields</source>
			<translation>grb_addfields</translation>
		</message>
		<message>
			<source>grb_admin_om</source>
			<translation>O&amp;&amp;M</translation>
		</message>
		<message>
			<source>tooltip_grb_admin_om</source>
			<translation>grb_admin_om</translation>
		</message>
		<message>
			<source>grb_admin_other</source>
			<translation>Otros</translation>
		</message>
		<message>
			<source>tooltip_grb_admin_other</source>
			<translation>grb_admin_other</translation>
		</message>
		<message>
			<source>grb_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_grb_arc</source>
			<translation>grb_arc</translation>
		</message>
		<message>
			<source>grb_basic</source>
			<translation>Básico</translation>
		</message>
		<message>
			<source>tooltip_grb_basic</source>
			<translation>grb_basic</translation>
		</message>
		<message>
			<source>grb_category_type</source>
			<translation>Tipo de categoría</translation>
		</message>
		<message>
			<source>tooltip_grb_category_type</source>
			<translation>grb_category_type</translation>
		</message>
		<message>
			<source>grb_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_grb_connec</source>
			<translation>grb_connec</translation>
		</message>
		<message>
			<source>grb_epa</source>
			<translation>Epa</translation>
		</message>
		<message>
			<source>tooltip_grb_epa</source>
			<translation>grb_epa</translation>
		</message>
		<message>
			<source>grb_fluid_type</source>
			<translation>Tipo de fluido</translation>
		</message>
		<message>
			<source>tooltip_grb_fluid_type</source>
			<translation>grb_fluid_type</translation>
		</message>
		<message>
			<source>grb_function_type</source>
			<translation>Tipo de función</translation>
		</message>
		<message>
			<source>tooltip_grb_function_type</source>
			<translation>grb_function_type</translation>
		</message>
		<message>
			<source>grb_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_grb_gully</source>
			<translation>grb_gully</translation>
		</message>
		<message>
			<source>grb_inventory</source>
			<translation>Inventario</translation>
		</message>
		<message>
			<source>tooltip_grb_inventory</source>
			<translation>grb_inventory</translation>
		</message>
		<message>
			<source>grb_link</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>tooltip_grb_link</source>
			<translation>grb_link</translation>
		</message>
		<message>
			<source>grb_location_type</source>
			<translation>Tipo de ubicación</translation>
		</message>
		<message>
			<source>tooltip_grb_location_type</source>
			<translation>grb_location_type</translation>
		</message>
		<message>
			<source>grb_masterplan</source>
			<translation>MasterPlan</translation>
		</message>
		<message>
			<source>tooltip_grb_masterplan</source>
			<translation>grb_masterplan</translation>
		</message>
		<message>
			<source>grb_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tooltip_grb_node</source>
			<translation>grb_node</translation>
		</message>
		<message>
			<source>grb_om</source>
			<translation>O&amp;&amp;M</translation>
		</message>
		<message>
			<source>tooltip_grb_om</source>
			<translation>grb_om</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Otros</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_system</source>
			<translation>Sistema</translation>
		</message>
		<message>
			<source>tooltip_grb_system</source>
			<translation>grb_system</translation>
		</message>
		<message>
			<source>grb_topology</source>
			<translation>Topología</translation>
		</message>
		<message>
			<source>tooltip_grb_topology</source>
			<translation>grb_topology</translation>
		</message>
		<message>
			<source>grb_utils</source>
			<translation>Utilidades</translation>
		</message>
		<message>
			<source>tooltip_grb_utils</source>
			<translation>grb_utils</translation>
		</message>
		<message>
			<source>tab_addfields</source>
			<translation>Campos adicionales</translation>
		</message>
		<message>
			<source>tooltip_tab_addfields</source>
			<translation>tab_addfields</translation>
		</message>
		<message>
			<source>tab_admin</source>
			<translation>Admin</translation>
		</message>
		<message>
			<source>tooltip_tab_admin</source>
			<translation>tab_admin</translation>
		</message>
		<message>
			<source>tab_basic</source>
			<translation>Básico</translation>
		</message>
		<message>
			<source>tooltip_tab_basic</source>
			<translation>tab_basic</translation>
		</message>
		<message>
			<source>tab_featurecat</source>
			<translation>Elemento de catálogo</translation>
		</message>
		<message>
			<source>tooltip_tab_featurecat</source>
			<translation>tab_featurecat</translation>
		</message>
		<message>
			<source>tab_mantype</source>
			<translation>Tipos de gestión</translation>
		</message>
		<message>
			<source>tooltip_tab_mantype</source>
			<translation>tab_mantype</translation>
		</message>
	</context>
	<context>
		<name>connect_link</name>
		<message>
			<source>title</source>
			<translation>Conectar a la red</translation>
		</message>
		<message>
			<source>dlg_connect_link</source>
			<translation>Conectar a la red</translation>
		</message>
		<message>
			<source>tooltip_dlg_connect_link</source>
			<translation>dlg_connect_link</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Configuración de enlaces</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Conexiones</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_3</source>
			<translation>Arcos</translation>
		</message>
		<message>
			<source>tooltip_groupBox_3</source>
			<translation>groupBox_3</translation>
		</message>
		<message>
			<source>groupBox_4</source>
			<translation>Nodos</translation>
		</message>
		<message>
			<source>tooltip_groupBox_4</source>
			<translation>groupBox_4</translation>
		</message>
		<message>
			<source>groupBox_5</source>
			<translation>Filtros extra</translation>
		</message>
		<message>
			<source>tooltip_groupBox_5</source>
			<translation>groupBox_5</translation>
		</message>
		<message>
			<source>tab_connect</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>tooltip_tab_connect</source>
			<translation>tab_connect</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>csv</name>
		<message>
			<source>title</source>
			<translation>Importar CSV</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_file_csv</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_csv</source>
			<translation>btn_file_csv</translation>
		</message>
		<message>
			<source>dlg_csv</source>
			<translation>Importar CSV</translation>
		</message>
		<message>
			<source>tooltip_dlg_csv</source>
			<translation>dlg_csv</translation>
		</message>
		<message>
			<source>lbl_decimal</source>
			<translation>Separador decimal</translation>
		</message>
		<message>
			<source>tooltip_lbl_decimal</source>
			<translation>lbl_decimal</translation>
		</message>
		<message>
			<source>lbl_delimiter</source>
			<translation>Delimitador:</translation>
		</message>
		<message>
			<source>tooltip_lbl_delimiter</source>
			<translation>lbl_delimiter</translation>
		</message>
		<message>
			<source>lbl_file</source>
			<translation>Archivo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_file</source>
			<translation>lbl_file</translation>
		</message>
		<message>
			<source>lbl_ignore_header</source>
			<translation>Ignorar cabeceras:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ignore_header</source>
			<translation>lbl_ignore_header</translation>
		</message>
		<message>
			<source>lbl_import_label</source>
			<translation>Importar etiqueta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_import_label</source>
			<translation>lbl_import_label</translation>
		</message>
		<message>
			<source>lbl_import_type</source>
			<translation>Importar tipo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_import_type</source>
			<translation>lbl_import_type</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Información:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_set_of_charac</source>
			<translation>Conjunto de caracteres</translation>
		</message>
		<message>
			<source>tooltip_lbl_set_of_charac</source>
			<translation>lbl_set_of_charac</translation>
		</message>
		<message>
			<source>rb_comma</source>
			<translation>,</translation>
		</message>
		<message>
			<source>tooltip_rb_comma</source>
			<translation>rb_comma</translation>
		</message>
		<message>
			<source>rb_dec_comma</source>
			<translation>,</translation>
		</message>
		<message>
			<source>tooltip_rb_dec_comma</source>
			<translation>rb_dec_comma</translation>
		</message>
		<message>
			<source>rb_dec_period</source>
			<translation>.</translation>
		</message>
		<message>
			<source>tooltip_rb_dec_period</source>
			<translation>rb_dec_period</translation>
		</message>
		<message>
			<source>rb_semicolon</source>
			<translation>;</translation>
		</message>
		<message>
			<source>tooltip_rb_semicolon</source>
			<translation>rb_semicolon</translation>
		</message>
		<message>
			<source>rb_space</source>
			<translation>Espacio</translation>
		</message>
		<message>
			<source>tooltip_rb_space</source>
			<translation>rb_space</translation>
		</message>
		<message>
			<source>tab_info</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_info</source>
			<translation>tab_info</translation>
		</message>
		<message>
			<source>tab_preview</source>
			<translation>Vista previa</translation>
		</message>
		<message>
			<source>tooltip_tab_preview</source>
			<translation>tab_preview</translation>
		</message>
	</context>
	<context>
		<name>dimensioning</name>
		<message>
			<source>actionEdit</source>
			<translation>actionEdit</translation>
		</message>
		<message>
			<source>tooltip_actionEdit</source>
			<translation>Edit</translation>
		</message>
		<message>
			<source>actionOrientation</source>
			<translation>actionOrientation</translation>
		</message>
		<message>
			<source>tooltip_actionOrientation</source>
			<translation>Orientation</translation>
		</message>
		<message>
			<source>actionSnapping</source>
			<translation>actionSnapping</translation>
		</message>
		<message>
			<source>tooltip_actionSnapping</source>
			<translation>Snapping</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>grb_depth</source>
			<translation>Mediciones</translation>
		</message>
		<message>
			<source>tooltip_grb_depth</source>
			<translation>grb_depth</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Otros</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_symbology</source>
			<translation>Simbología del círculo</translation>
		</message>
		<message>
			<source>tooltip_grb_symbology</source>
			<translation>grb_symbology</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>Editar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>doc</name>
		<message>
			<source>title</source>
			<translation>Documento</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Agregar geom</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>Agregar geometría</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Aplicar</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>Aplicar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_path_doc</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path_doc</source>
			<translation>Ruta</translation>
		</message>
		<message>
			<source>btn_path_url</source>
			<translation>Web</translation>
		</message>
		<message>
			<source>tooltip_btn_path_url</source>
			<translation>Abra el explorador para permitir la selección de la ruta web. También es posible simplemente pegar la ruta en el cuadro de enlace de texto </translation>
		</message>
		<message>
			<source>date</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date</source>
			<translation>date</translation>
		</message>
		<message>
			<source>dlg_doc</source>
			<translation>Documento</translation>
		</message>
		<message>
			<source>tooltip_dlg_doc</source>
			<translation>dlg_doc</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Fecha:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_doc_name</source>
			<translation>Nombre doc:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_name</source>
			<translation>Nombre documento</translation>
		</message>
		<message>
			<source>lbl_doc_type</source>
			<translation>Tipo doc:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_type</source>
			<translation>Tipo documento</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Enlace:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observaciones:</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Visita</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Acometida</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>Acometida</translation>
		</message>
		<message>
			<source>tab_doc</source>
			<translation>Documento</translation>
		</message>
		<message>
			<source>tooltip_tab_doc</source>
			<translation>tab_doc</translation>
		</message>
		<message>
			<source>tab_elem</source>
			<translation>Elemento</translation>
		</message>
		<message>
			<source>tooltip_tab_elem</source>
			<translation>tab_elem</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tab_psector</source>
			<translation>Psector</translation>
		</message>
		<message>
			<source>tooltip_tab_psector</source>
			<translation>tab_psector</translation>
		</message>
		<message>
			<source>tab_rel</source>
			<translation>Relaciones</translation>
		</message>
		<message>
			<source>tooltip_tab_rel</source>
			<translation>tab_rel</translation>
		</message>
		<message>
			<source>tab_workcat</source>
			<translation>Workcat</translation>
		</message>
		<message>
			<source>tooltip_tab_workcat</source>
			<translation>tab_workcat</translation>
		</message>
	</context>
	<context>
		<name>doc_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de documentos</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>dlg_doc_manager</source>
			<translation>Gestor de documentos</translation>
		</message>
		<message>
			<source>tooltip_dlg_doc_manager</source>
			<translation>dlg_doc_manager</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtrar por: Nombre doc</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>dscenario</name>
		<message>
			<source>title</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_properties</source>
			<translation>Propiedades</translation>
		</message>
		<message>
			<source>tooltip_btn_properties</source>
			<translation>btn_properties</translation>
		</message>
		<message>
			<source>dlg_dscenario</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>tooltip_dlg_dscenario</source>
			<translation>dlg_dscenario</translation>
		</message>
	</context>
	<context>
		<name>dscenario_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de escenarios dinámicos</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplicar</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Alternar activo</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Alternar activo</translation>
		</message>
		<message>
			<source>btn_toolbox</source>
			<translation>Actions</translation>
		</message>
		<message>
			<source>tooltip_btn_toolbox</source>
			<translation>btn_toolbox</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>btn_update_dscenario</source>
			<translation>Escenario actual</translation>
		</message>
		<message>
			<source>tooltip_btn_update_dscenario</source>
			<translation>btn_update_dscenario</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Mostrar inactivos</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Mostrar inactivos</translation>
		</message>
		<message>
			<source>dlg_dscenario_manager</source>
			<translation>Gestor de escenarios dinámicos</translation>
		</message>
		<message>
			<source>tooltip_dlg_dscenario_manager</source>
			<translation>dlg_dscenario_manager</translation>
		</message>
		<message>
			<source>lbl_dscenario_name</source>
			<translation>Filtrador por: Nombre dscenario</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario_name</source>
			<translation>lbl_dscenario_name</translation>
		</message>
	</context>
	<context>
		<name>element_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de elementos</translation>
		</message>
		<message>
			<source>dlg_element_manager</source>
			<translation>Gestor de elementos</translation>
		</message>
		<message>
			<source>tooltip_dlg_element_manager</source>
			<translation>dlg_element_manager</translation>
		</message>
	</context>
	<context>
		<name>epa_export</name>
		<message>
			<source>title</source>
			<translation>Exportar familias de resultados EPA</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_browse</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_browse</source>
			<translation>btn_browse</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_format_json</source>
			<translation>Formatear JSON</translation>
		</message>
		<message>
			<source>tooltip_chk_format_json</source>
			<translation>chk_format_json</translation>
		</message>
		<message>
			<source>dlg_epa_export</source>
			<translation>Exportar familias de resultados EPA</translation>
		</message>
		<message>
			<source>tooltip_dlg_epa_export</source>
			<translation>dlg_epa_export</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Ruta de Exportar:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>ID de resultado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
	</context>
	<context>
		<name>epatools_add_demand_check</name>
		<message>
			<source>title</source>
			<translation>Comprobación de la demanda adicional</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_add_demand_check</source>
			<translation>Comprobación de la demanda adicional</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_add_demand_check</source>
			<translation>dlg_epatools_add_demand_check</translation>
		</message>
		<message>
			<source>lbl_config</source>
			<translation>Archivo de configuración:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config</source>
			<translation>lbl_config</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nombre del fichero:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Archivo INP de entrada:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Utiliza nodos de:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Carpeta de salida:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>rdb_nodes_config</source>
			<translation>Archivo de configuración</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_config</source>
			<translation>Recuperar datos de nodos de la propiedad &quot;nodes&quot; dentro del archivo de configuración.</translation>
		</message>
		<message>
			<source>rdb_nodes_database</source>
			<translation>Base de datos</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_database</source>
			<translation>Recuperar datos de nodo con fid=491 de la tabla anl_node.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_emitter_calibration</name>
		<message>
			<source>title</source>
			<translation>Calibración del emisor</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_emitter_calibration</source>
			<translation>Calibración del emisor</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_emitter_calibration</source>
			<translation>dlg_epatools_emitter_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Archivo de configuración:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nombre del fichero:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Archivo INP de entrada:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_filename</source>
			<translation>Nombre de los archivos de salida:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_filename</source>
			<translation>lbl_output_filename</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>epatools_quantized_demands</name>
		<message>
			<source>title</source>
			<translation>Exigencias cuantificadas</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_quantized_demands</source>
			<translation>Exigencias cuantificadas</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_quantized_demands</source>
			<translation>dlg_epatools_quantized_demands</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Archivo de configuración:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nombre del fichero:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Archivo INP de entrada:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Carpeta de salida:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_recursive_go2epa</name>
		<message>
			<source>title</source>
			<translation>Llamadas múltiples Epa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_recursive_go2epa</source>
			<translation>Llamadas múltiples Epa</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_recursive_go2epa</source>
			<translation>dlg_epatools_recursive_go2epa</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Archivo de configuración:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nombre del fichero:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Carpeta de salida:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_static_calibration</name>
		<message>
			<source>title</source>
			<translation>Calibración estática</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>btn_save_dscenario</source>
			<translation>Guardar cambios en dscenario</translation>
		</message>
		<message>
			<source>tooltip_btn_save_dscenario</source>
			<translation>btn_save_dscenario</translation>
		</message>
		<message>
			<source>dlg_epatools_static_calibration</source>
			<translation>Calibración estática</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_static_calibration</source>
			<translation>dlg_epatools_static_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Archivo de configuración:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>El archivo .ini con las calibraciones a realizar</translation>
		</message>
		<message>
			<source>lbl_dscenario</source>
			<translation>Dscenario:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario</source>
			<translation>lbl_dscenario</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nombre del fichero:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_inp_input_file</source>
			<translation>Archivo INP de entrada:</translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_input_file</source>
			<translation>El archivo EPANET a calibrar</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Carpeta de salida:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_valve_operation_check</name>
		<message>
			<source>title</source>
			<translation>Comprobación del funcionamiento de la válvula</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_valve_operation_check</source>
			<translation>Comprobación del funcionamiento de la válvula</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_valve_operation_check</source>
			<translation>dlg_epatools_valve_operation_check</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Archivo de configuración:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nombre del fichero:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Archivo INP de entrada:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Carpeta de salida:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>lbl_scenarios</source>
			<translation>Utiliza escenarios de:</translation>
		</message>
		<message>
			<source>tooltip_lbl_scenarios</source>
			<translation>lbl_scenarios</translation>
		</message>
		<message>
			<source>rdb_scenarios_config</source>
			<translation>Archivo de configuración</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_config</source>
			<translation>Recuperar datos de escenarios de la sección [SCENARIOS] dentro del archivo de configuración.</translation>
		</message>
		<message>
			<source>rdb_scenarios_database</source>
			<translation>Base de datos</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_database</source>
			<translation>Recuperar datos de escenarios con fid=493 de la tabla anl_arc.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>feature_delete</name>
		<message>
			<source>title</source>
			<translation>Eliminar objeto de red</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Borrar objeto seleccionado</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>btn_delete_another</source>
			<translation>Eliminar otro objeto</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_another</source>
			<translation>btn_delete_another</translation>
		</message>
		<message>
			<source>btn_relations</source>
			<translation>Mostrar relaciones del objeto</translation>
		</message>
		<message>
			<source>tooltip_btn_relations</source>
			<translation>btn_relations</translation>
		</message>
		<message>
			<source>dlg_feature_delete</source>
			<translation>Eliminar objeto de red</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_delete</source>
			<translation>dlg_feature_delete</translation>
		</message>
		<message>
			<source>lbl_feature_id</source>
			<translation>Id objeto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_id</source>
			<translation>lbl_feature_id</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Tipo de objeto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>tab_del_feature</source>
			<translation>Eliminar objeto de red</translation>
		</message>
		<message>
			<source>tooltip_tab_del_feature</source>
			<translation>tab_del_feature</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>feature_end</name>
		<message>
			<source>title</source>
			<translation>Dar de baja</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_new_workcat</source>
			<translation>btn_new_workcat</translation>
		</message>
		<message>
			<source>tooltip_btn_new_workcat</source>
			<translation>btn_new_workcat</translation>
		</message>
		<message>
			<source>builtdate</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_builtdate</source>
			<translation>builtdate</translation>
		</message>
		<message>
			<source>dlg_feature_end</source>
			<translation>Dar de baja</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_end</source>
			<translation>dlg_feature_end</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Fecha de finalización:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_state_type</source>
			<translation>Tipo estado final:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state_type</source>
			<translation>lbl_state_type</translation>
		</message>
		<message>
			<source>lbl_workcat_date</source>
			<translation>Fecha expdte:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_date</source>
			<translation>lbl_workcat_date</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Id expdte baja:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Acometida</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_elem</source>
			<translation>Elemento</translation>
		</message>
		<message>
			<source>tooltip_tab_elem</source>
			<translation>tab_elem</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relaciones</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Relaciones</translation>
		</message>
		<message>
			<source>tab_workcat</source>
			<translation>Expediente</translation>
		</message>
		<message>
			<source>tooltip_tab_workcat</source>
			<translation>tab_workcat</translation>
		</message>
	</context>
	<context>
		<name>feature_end_connec</name>
		<message>
			<source>title</source>
			<translation>Elementos desconectados de tramo</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>dlg_feature_end_connec</source>
			<translation>Elementos desconectados de tramo</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_end_connec</source>
			<translation>dlg_feature_end_connec</translation>
		</message>
		<message>
			<source>lbl_filter_by</source>
			<translation>Filtrar por id arco:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_by</source>
			<translation>lbl_filter_by</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Lista de elementos que quedarán desconectados cuando los tramos seleccionados sean dados de baja:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
	</context>
	<context>
		<name>feature_replace</name>
		<message>
			<source>title</source>
			<translation>Reemplazar objeto</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_config</source>
			<translation>config</translation>
		</message>
		<message>
			<source>dlg_feature_replace</source>
			<translation>Reemplazar objeto</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_replace</source>
			<translation>dlg_feature_replace</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>grb_end_parameters</source>
			<translation>Parámetros de baja:</translation>
		</message>
		<message>
			<source>tooltip_grb_end_parameters</source>
			<translation>grb_end_parameters</translation>
		</message>
		<message>
			<source>grb_feature_parameters</source>
			<translation>Parámetros del objeto</translation>
		</message>
		<message>
			<source>tooltip_grb_feature_parameters</source>
			<translation>grb_feature_parameters</translation>
		</message>
		<message>
			<source>lbl_current_catalog_id</source>
			<translation>Id. de catálogo actual:</translation>
		</message>
		<message>
			<source>tooltip_lbl_current_catalog_id</source>
			<translation>lbl_current_catalog_id</translation>
		</message>
		<message>
			<source>lbl_description</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_description</source>
			<translation>lbl_description</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Fecha de reemplazo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Tipo de objeto actual:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>lbl_keep_asset_id</source>
			<translation>Mantener ID de activo</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_asset_id</source>
			<translation>lbl_keep_asset_id</translation>
		</message>
		<message>
			<source>lbl_keep_customer_code</source>
			<translation>Mantener código de cliente:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_customer_code</source>
			<translation>lbl_keep_customer_code</translation>
		</message>
		<message>
			<source>lbl_keep_elements</source>
			<translation>Mantener elementos</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_elements</source>
			<translation>lbl_keep_elements</translation>
		</message>
		<message>
			<source>lbl_keep_epa_values</source>
			<translation>Mantener valores de EPA</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_epa_values</source>
			<translation>lbl_keep_epa_values</translation>
		</message>
		<message>
			<source>lbl_keep_sys_code</source>
			<translation>Mantener código sys</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_sys_code</source>
			<translation>lbl_keep_sys_code</translation>
		</message>
		<message>
			<source>lbl_new_catalog_id</source>
			<translation>Nuevo identificador de catálogo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_catalog_id</source>
			<translation>lbl_new_catalog_id</translation>
		</message>
		<message>
			<source>lbl_new_feature_type</source>
			<translation>Nuevo tipo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_feature_type</source>
			<translation>lbl_new_feature_type</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Id expdte obra:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>featuretype_change</name>
		<message>
			<source>title</source>
			<translation>Cambiar tipo de objeto</translation>
		</message>
		<message>
			<source>dlg_featuretype_change</source>
			<translation>Cambiar tipo de objeto</translation>
		</message>
		<message>
			<source>tooltip_dlg_featuretype_change</source>
			<translation>dlg_featuretype_change</translation>
		</message>
	</context>
	<context>
		<name>go2epa</name>
		<message>
			<source>title</source>
			<translation>Ir a Epa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_file_inp</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_inp</source>
			<translation>btn_file_inp</translation>
		</message>
		<message>
			<source>btn_file_rpt</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_rpt</source>
			<translation>btn_file_rpt</translation>
		</message>
		<message>
			<source>btn_hs_ds</source>
			<translation>Selector</translation>
		</message>
		<message>
			<source>tooltip_btn_hs_ds</source>
			<translation>btn_hs_ds</translation>
		</message>
		<message>
			<source>btn_options</source>
			<translation>Opciones</translation>
		</message>
		<message>
			<source>tooltip_btn_options</source>
			<translation>btn_options</translation>
		</message>
		<message>
			<source>chk_exec</source>
			<translation>Ejecutar software EPA</translation>
		</message>
		<message>
			<source>tooltip_chk_exec</source>
			<translation>chk_exec</translation>
		</message>
		<message>
			<source>chk_export</source>
			<translation>Exportar INP</translation>
		</message>
		<message>
			<source>tooltip_chk_export</source>
			<translation>chk_export</translation>
		</message>
		<message>
			<source>chk_export_subcatch</source>
			<translation>Exportar subcuencas UD</translation>
		</message>
		<message>
			<source>tooltip_chk_export_subcatch</source>
			<translation>chk_export_subcatch</translation>
		</message>
		<message>
			<source>chk_import_result</source>
			<translation>Importar resultado</translation>
		</message>
		<message>
			<source>tooltip_chk_import_result</source>
			<translation>chk_import_result</translation>
		</message>
		<message>
			<source>dlg_go2epa</source>
			<translation>Ir a Epa</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa</source>
			<translation>dlg_go2epa</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Opciones de preprocesamiento</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Gestor de archivos</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_inp_file</source>
			<translation>Archivo INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_file</source>
			<translation>lbl_inp_file</translation>
		</message>
		<message>
			<source>lbl_result_name</source>
			<translation>Nombre del resultado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name</source>
			<translation>lbl_result_name</translation>
		</message>
		<message>
			<source>lbl_rpt_file</source>
			<translation>Archivo RPT:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rpt_file</source>
			<translation>lbl_rpt_file</translation>
		</message>
		<message>
			<source>tab_file_manager</source>
			<translation>Gestor de archivos</translation>
		</message>
		<message>
			<source>tooltip_tab_file_manager</source>
			<translation>tab_file_manager</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>go2epa_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de resultados EPA</translation>
		</message>
		<message>
			<source>btn_archive</source>
			<translation>Alternar archivo</translation>
		</message>
		<message>
			<source>tooltip_btn_archive</source>
			<translation>Alternar archivo</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>btn_edit</source>
			<translation>Editar</translation>
		</message>
		<message>
			<source>tooltip_btn_edit</source>
			<translation>Editar</translation>
		</message>
		<message>
			<source>btn_show_inp_data</source>
			<translation>Mostrar datos de entrada</translation>
		</message>
		<message>
			<source>tooltip_btn_show_inp_data</source>
			<translation>Mostrar datos INP</translation>
		</message>
		<message>
			<source>btn_toggle_corporate</source>
			<translation>Alternar corporativo</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_corporate</source>
			<translation>btn_toggle_corporate</translation>
		</message>
		<message>
			<source>btn_toggle_validated</source>
			<translation>Alternar validados</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_validated</source>
			<translation>btn_toggle_validated</translation>
		</message>
		<message>
			<source>chk_archived</source>
			<translation>Mostrar archivados</translation>
		</message>
		<message>
			<source>tooltip_chk_archived</source>
			<translation>chk_archived</translation>
		</message>
		<message>
			<source>chk_corporate</source>
			<translation>Mostrar corporativos</translation>
		</message>
		<message>
			<source>tooltip_chk_corporate</source>
			<translation>chk_corporate</translation>
		</message>
		<message>
			<source>chk_validated</source>
			<translation>Mostrar validados</translation>
		</message>
		<message>
			<source>tooltip_chk_validated</source>
			<translation>chk_validated</translation>
		</message>
		<message>
			<source>dlg_go2epa_manager</source>
			<translation>Gestor de resultados EPA</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_manager</source>
			<translation>dlg_go2epa_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_date_exec_from</source>
			<translation>Desde:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_exec_from</source>
			<translation>lbl_date_exec_from</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Explotación:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_network_type</source>
			<translation>Tipo de red:</translation>
		</message>
		<message>
			<source>tooltip_lbl_network_type</source>
			<translation>lbl_network_type</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Filtrar por: Id resultado</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Estado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
	</context>
	<context>
		<name>go2epa_options</name>
		<message>
			<source>title</source>
			<translation>Go2Epa - opciones</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>dlg_go2epa_options</source>
			<translation>Go2Epa - opciones</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_options</source>
			<translation>dlg_go2epa_options</translation>
		</message>
		<message>
			<source>grb_energy</source>
			<translation>Energía</translation>
		</message>
		<message>
			<source>tooltip_grb_energy</source>
			<translation>grb_energy</translation>
		</message>
		<message>
			<source>grb_general</source>
			<translation>General</translation>
		</message>
		<message>
			<source>tooltip_grb_general</source>
			<translation>grb_general</translation>
		</message>
		<message>
			<source>grb_hydraulics</source>
			<translation>Hidráulica</translation>
		</message>
		<message>
			<source>tooltip_grb_hydraulics</source>
			<translation>grb_hydraulics</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Otros</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_reactions</source>
			<translation>Calidad</translation>
		</message>
		<message>
			<source>tooltip_grb_reactions</source>
			<translation>grb_reactions</translation>
		</message>
		<message>
			<source>grb_reports</source>
			<translation>Informes</translation>
		</message>
		<message>
			<source>tooltip_grb_reports</source>
			<translation>grb_reports</translation>
		</message>
		<message>
			<source>grb_time_steps</source>
			<translation>Pasos de tiempo</translation>
		</message>
		<message>
			<source>tooltip_grb_time_steps</source>
			<translation>grb_time_steps</translation>
		</message>
		<message>
			<source>tab_inp</source>
			<translation>Inp</translation>
		</message>
		<message>
			<source>tooltip_tab_inp</source>
			<translation>tab_inp</translation>
		</message>
		<message>
			<source>tab_other</source>
			<translation>Otros</translation>
		</message>
		<message>
			<source>tooltip_tab_other</source>
			<translation>tab_other</translation>
		</message>
	</context>
	<context>
		<name>go2epa_selector</name>
		<message>
			<source>title</source>
			<translation>Selector de comparación de resultados</translation>
		</message>
		<message>
			<source>dlg_go2epa_selector</source>
			<translation>Selector de comparación de resultados</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_selector</source>
			<translation>dlg_go2epa_selector</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Resultado</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
		<message>
			<source>tab_time</source>
			<translation>Fecha Hora</translation>
		</message>
		<message>
			<source>tooltip_tab_time</source>
			<translation>tab_time</translation>
		</message>
	</context>
	<context>
		<name>go2iber</name>
		<message>
			<source>title</source>
			<translation>Ir a Iber</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_iber_options</source>
			<translation>Opciones de Iber</translation>
		</message>
		<message>
			<source>tooltip_btn_iber_options</source>
			<translation>Opciones Iber</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_swmm_options</source>
			<translation>Opciones de SWMM</translation>
		</message>
		<message>
			<source>tooltip_btn_swmm_options</source>
			<translation>Opciones SWMM</translation>
		</message>
		<message>
			<source>dlg_go2iber</source>
			<translation>Ir a Iber</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2iber</source>
			<translation>dlg_go2iber</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Opciones</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>lbl_mesh</source>
			<translation>Malla:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mesh</source>
			<translation>lbl_mesh</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Ruta de la carpeta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
		<message>
			<source>lbl_result_name</source>
			<translation>Nombre del resultado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name</source>
			<translation>lbl_result_name</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>info_catalog</name>
		<message>
			<source>title</source>
			<translation>Catálogo</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_info_catalog</source>
			<translation>Catálogo</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_catalog</source>
			<translation>dlg_info_catalog</translation>
		</message>
	</context>
	<context>
		<name>info_crossect</name>
		<message>
			<source>title</source>
			<translation>Sección</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>dlg_info_crossect</source>
			<translation>Sección</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_crossect</source>
			<translation>dlg_info_crossect</translation>
		</message>
		<message>
			<source>lbl_cost_area</source>
			<translation>Área de costo</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_area</source>
			<translation>lbl_cost_area</translation>
		</message>
		<message>
			<source>lbl_cost_bulk</source>
			<translation>Costo a granel</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_bulk</source>
			<translation>lbl_cost_bulk</translation>
		</message>
		<message>
			<source>lbl_cost_exc</source>
			<translation>Costo exc</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_exc</source>
			<translation>lbl_cost_exc</translation>
		</message>
		<message>
			<source>lbl_cost_excav</source>
			<translation>Costo excavación</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_excav</source>
			<translation>lbl_cost_excav</translation>
		</message>
		<message>
			<source>lbl_cost_fill</source>
			<translation>Costo relleno</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_fill</source>
			<translation>lbl_cost_fill</translation>
		</message>
		<message>
			<source>lbl_cost_trench</source>
			<translation>Costo zanja</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_trench</source>
			<translation>lbl_cost_trench</translation>
		</message>
	</context>
	<context>
		<name>info_epa</name>
		<message>
			<source>title</source>
			<translation>InfoEpa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_info_epa</source>
			<translation>InfoEpa</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_epa</source>
			<translation>dlg_info_epa</translation>
		</message>
		<message>
			<source>page_base</source>
			<translation>Base</translation>
		</message>
		<message>
			<source>tooltip_page_base</source>
			<translation>page_base</translation>
		</message>
		<message>
			<source>page_dscenario</source>
			<translation>Dscenario</translation>
		</message>
		<message>
			<source>tooltip_page_dscenario</source>
			<translation>page_dscenario</translation>
		</message>
		<message>
			<source>page_dwf</source>
			<translation>DWF</translation>
		</message>
		<message>
			<source>tooltip_page_dwf</source>
			<translation>page_dwf</translation>
		</message>
		<message>
			<source>page_inflows</source>
			<translation>FLUJOS DE ENTRADA</translation>
		</message>
		<message>
			<source>tooltip_page_inflows</source>
			<translation>page_inflows</translation>
		</message>
	</context>
	<context>
		<name>info_feature</name>
		<message>
			<source>title</source>
			<translation>Información característica</translation>
		</message>
		<message>
			<source>actionCopyPaste</source>
			<translation>actionCopyPaste</translation>
		</message>
		<message>
			<source>tooltip_actionCopyPaste</source>
			<translation>Copy&amp;amp;Paste</translation>
		</message>
		<message>
			<source>actionEdit</source>
			<translation>actionEdit</translation>
		</message>
		<message>
			<source>tooltip_actionEdit</source>
			<translation>Edit</translation>
		</message>
		<message>
			<source>actionGetArcId</source>
			<translation>actionGetArcId</translation>
		</message>
		<message>
			<source>tooltip_actionGetArcId</source>
			<translation>Get new arc id</translation>
		</message>
		<message>
			<source>actionHelp</source>
			<translation>actionHelp</translation>
		</message>
		<message>
			<source>tooltip_actionHelp</source>
			<translation>Help</translation>
		</message>
		<message>
			<source>actionInterpolate</source>
			<translation>actionInterpolate</translation>
		</message>
		<message>
			<source>tooltip_actionInterpolate</source>
			<translation>Interpolate</translation>
		</message>
		<message>
			<source>actionLink</source>
			<translation>actionLink</translation>
		</message>
		<message>
			<source>tooltip_actionLink</source>
			<translation>Link</translation>
		</message>
		<message>
			<source>actionSection</source>
			<translation>actionSection</translation>
		</message>
		<message>
			<source>tooltip_actionSection</source>
			<translation>Show section</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Aplicar</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>Aplicar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_link</source>
			<translation>btn_link</translation>
		</message>
		<message>
			<source>tooltip_btn_link</source>
			<translation>btn_link</translation>
		</message>
		<message>
			<source>btn_new_element</source>
			<translation>btn_new_element</translation>
		</message>
		<message>
			<source>tooltip_btn_new_element</source>
			<translation>btn_new_element</translation>
		</message>
		<message>
			<source>btn_new_visit</source>
			<translation>btn_new_visit</translation>
		</message>
		<message>
			<source>tooltip_btn_new_visit</source>
			<translation>btn_new_visit</translation>
		</message>
		<message>
			<source>btn_open_element</source>
			<translation>btn_open_element</translation>
		</message>
		<message>
			<source>tooltip_btn_open_element</source>
			<translation>btn_open_element</translation>
		</message>
		<message>
			<source>btn_open_gallery</source>
			<translation>btn_open_gallery</translation>
		</message>
		<message>
			<source>tooltip_btn_open_gallery</source>
			<translation>btn_open_gallery</translation>
		</message>
		<message>
			<source>btn_open_visit</source>
			<translation>btn_open_visit</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit</source>
			<translation>btn_open_visit</translation>
		</message>
		<message>
			<source>btn_open_visit_doc</source>
			<translation>btn_open_visit_doc</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit_doc</source>
			<translation>btn_open_visit_doc</translation>
		</message>
		<message>
			<source>btn_open_visit_event</source>
			<translation>btn_open_visit_event</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit_event</source>
			<translation>btn_open_visit_event</translation>
		</message>
		<message>
			<source>dlg_info_feature</source>
			<translation>Información característica</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_feature</source>
			<translation>dlg_info_feature</translation>
		</message>
		<message>
			<source>grb_frelem_dscenario</source>
			<translation>Dscenario</translation>
		</message>
		<message>
			<source>tooltip_grb_frelem_dscenario</source>
			<translation>grb_frelem_dscenario</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>INP</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>RPT</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>page</source>
			<translation>Datos</translation>
		</message>
		<message>
			<source>tooltip_page</source>
			<translation>page</translation>
		</message>
		<message>
			<source>page_2</source>
			<translation>Dscenario</translation>
		</message>
		<message>
			<source>tooltip_page_2</source>
			<translation>page_2</translation>
		</message>
		<message>
			<source>page_add</source>
			<translation>Datos adicionales</translation>
		</message>
		<message>
			<source>tooltip_page_add</source>
			<translation>page_add</translation>
		</message>
		<message>
			<source>page_main</source>
			<translation>Datos principales</translation>
		</message>
		<message>
			<source>tooltip_page_main</source>
			<translation>page_main</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_connections</source>
			<translation>Conexiones</translation>
		</message>
		<message>
			<source>tooltip_tab_connections</source>
			<translation>tab_connections</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Datos</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_documents</source>
			<translation>Documentos</translation>
		</message>
		<message>
			<source>tooltip_tab_documents</source>
			<translation>tab_documents</translation>
		</message>
		<message>
			<source>tab_elements</source>
			<translation>Elementos</translation>
		</message>
		<message>
			<source>tooltip_tab_elements</source>
			<translation>tab_elements</translation>
		</message>
		<message>
			<source>tab_epa</source>
			<translation>EPA</translation>
		</message>
		<message>
			<source>tooltip_tab_epa</source>
			<translation>tab_epa</translation>
		</message>
		<message>
			<source>tab_event</source>
			<translation>Evento</translation>
		</message>
		<message>
			<source>tooltip_tab_event</source>
			<translation>tab_event</translation>
		</message>
		<message>
			<source>tab_features</source>
			<translation>Características</translation>
		</message>
		<message>
			<source>tooltip_tab_features</source>
			<translation>tab_features</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_hydrometer</source>
			<translation>Hidrómetro</translation>
		</message>
		<message>
			<source>tooltip_tab_hydrometer</source>
			<translation>tab_hydrometer</translation>
		</message>
		<message>
			<source>tab_hydrometer_val</source>
			<translation>Valores hidrómetro</translation>
		</message>
		<message>
			<source>tooltip_tab_hydrometer_val</source>
			<translation>tab_hydrometer_val</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_orifice</source>
			<translation>Orificio</translation>
		</message>
		<message>
			<source>tooltip_tab_orifice</source>
			<translation>tab_orifice</translation>
		</message>
		<message>
			<source>tab_outlet</source>
			<translation>Salida</translation>
		</message>
		<message>
			<source>tooltip_tab_outlet</source>
			<translation>tab_outlet</translation>
		</message>
		<message>
			<source>tab_plan</source>
			<translation>Plan</translation>
		</message>
		<message>
			<source>tooltip_tab_plan</source>
			<translation>tab_plan</translation>
		</message>
		<message>
			<source>tab_pump</source>
			<translation>Bomba</translation>
		</message>
		<message>
			<source>tooltip_tab_pump</source>
			<translation>tab_pump</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relaciones</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Relaciones</translation>
		</message>
		<message>
			<source>tab_rpt</source>
			<translation>Rpt</translation>
		</message>
		<message>
			<source>tooltip_tab_rpt</source>
			<translation>tab_rpt</translation>
		</message>
		<message>
			<source>tab_shortpipe</source>
			<translation>Pipa corta</translation>
		</message>
		<message>
			<source>tooltip_tab_shortpipe</source>
			<translation>tab_shortpipe</translation>
		</message>
		<message>
			<source>tab_valve</source>
			<translation>Válvula</translation>
		</message>
		<message>
			<source>tooltip_tab_valve</source>
			<translation>tab_valve</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Visita</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
		<message>
			<source>tab_weir</source>
			<translation>Presa</translation>
		</message>
		<message>
			<source>tooltip_tab_weir</source>
			<translation>tab_weir</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>Demanda</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>info_generic</name>
		<message>
			<source>title</source>
			<translation>Información básica</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_info_generic</source>
			<translation>Información básica</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_generic</source>
			<translation>dlg_info_generic</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>Set To Arc</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>info_workcat</name>
		<message>
			<source>title</source>
			<translation>Nuevo Workcat</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>builtdate</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_builtdate</source>
			<translation>builtdate</translation>
		</message>
		<message>
			<source>dlg_info_workcat</source>
			<translation>Nuevo Workcat</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_workcat</source>
			<translation>dlg_info_workcat</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Fecha de construcción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>lbl_builtdate</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Enlace:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>lbl_link</translation>
		</message>
		<message>
			<source>lbl_work_id</source>
			<translation>Identificación de trabajo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_id</source>
			<translation>lbl_work_id</translation>
		</message>
		<message>
			<source>lbl_workid_key_1</source>
			<translation>Llave de trabajo 1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workid_key_1</source>
			<translation>lbl_workid_key_1</translation>
		</message>
		<message>
			<source>lbl_workid_key_2</source>
			<translation>Clave de trabajo 2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workid_key_2</source>
			<translation>lbl_workid_key_2</translation>
		</message>
	</context>
	<context>
		<name>inp_config_import</name>
		<message>
			<source>title</source>
			<translation>Config INP importación</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_load</source>
			<translation>Carga...</translation>
		</message>
		<message>
			<source>tooltip_btn_load</source>
			<translation>btn_load</translation>
		</message>
		<message>
			<source>btn_reload</source>
			<translation>Opciones de recarga</translation>
		</message>
		<message>
			<source>tooltip_btn_reload</source>
			<translation>btn_reload</translation>
		</message>
		<message>
			<source>btn_save</source>
			<translation>Guardar...</translation>
		</message>
		<message>
			<source>tooltip_btn_save</source>
			<translation>btn_save</translation>
		</message>
		<message>
			<source>chk_force_commit</source>
			<translation>Forzar compromiso</translation>
		</message>
		<message>
			<source>tooltip_chk_force_commit</source>
			<translation>chk_force_commit</translation>
		</message>
		<message>
			<source>dlg_inp_config_import</source>
			<translation>Config INP importación</translation>
		</message>
		<message>
			<source>tooltip_dlg_inp_config_import</source>
			<translation>dlg_inp_config_import</translation>
		</message>
		<message>
			<source>grb_basic</source>
			<translation>Básico</translation>
		</message>
		<message>
			<source>tooltip_grb_basic</source>
			<translation>grb_basic</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Información</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_mapzones</source>
			<translation>Mapzones</translation>
		</message>
		<message>
			<source>tooltip_grb_mapzones</source>
			<translation>grb_mapzones</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Psector:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Explotación:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Municipio:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Sector:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>lbl_arcs</source>
			<translation>Seleccione el arccat_id apropiado para cada combinación de arco de las opciones siguientes. Si selecciona &amp;quot;Crear nuevo&amp;quot;, introduzca el nuevo nombre en la columna &amp;quot;Nuevo nombre de catálogo&amp;quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_arcs</source>
			<translation>lbl_arcs</translation>
		</message>
		<message>
			<source>lbl_dscenario</source>
			<translation>Demanda dscenario nombre:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario</source>
			<translation>lbl_dscenario</translation>
		</message>
		<message>
			<source>lbl_feature</source>
			<translation>Seleccione el feature_id apropiado para cada tipo de EPA de las opciones de abajo. Si es necesario, puede agregar un nuevo tipo de objeto en el catálogo de Giswater y haga clic en el &amp;quot;Recargar Opciones&amp;quot; botón de abajo.</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature</source>
			<translation>lbl_feature</translation>
		</message>
		<message>
			<source>lbl_flwreg</source>
			<translation>Seleccione el identificador de catálogo adecuado para cada regulador de caudal entre las opciones siguientes. Si selecciona &amp;quot;Crear nuevo&amp;quot;, introduzca el nuevo nombre en la columna &amp;quot;Nuevo nombre de catálogo&amp;quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_flwreg</source>
			<translation>lbl_flwreg</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Seleccione el material apropiado para cada rugosidad de las opciones de abajo. Si es necesario, puede añadir un nuevo material en el catálogo Giswater y haga clic en el &amp;quot;Recargar opciones&amp;quot; botón de abajo.</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>lbl_material</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Seleccione el nodecat_id adecuado para cada tipo de EPA entre las opciones siguientes. Si selecciona &amp;quot;Crear nuevo&amp;quot;, introduzca el nuevo nombre en la columna &amp;quot;Nuevo nombre de catálogo&amp;quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_raingage</source>
			<translation>Raging por defecto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_raingage</source>
			<translation>lbl_raingage</translation>
		</message>
		<message>
			<source>lbl_workcat</source>
			<translation>Workcat_id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat</source>
			<translation>lbl_workcat</translation>
		</message>
		<message>
			<source>tab_arccat</source>
			<translation>Arcos</translation>
		</message>
		<message>
			<source>tooltip_tab_arccat</source>
			<translation>tab_arccat</translation>
		</message>
		<message>
			<source>tab_basic</source>
			<translation>Básico</translation>
		</message>
		<message>
			<source>tooltip_tab_basic</source>
			<translation>tab_basic</translation>
		</message>
		<message>
			<source>tab_feature</source>
			<translation>Características</translation>
		</message>
		<message>
			<source>tooltip_tab_feature</source>
			<translation>tab_feature</translation>
		</message>
		<message>
			<source>tab_flwreg</source>
			<translation>Reguladores de caudal</translation>
		</message>
		<message>
			<source>tooltip_tab_flwreg</source>
			<translation>tab_flwreg</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>tooltip_tab_material</source>
			<translation>tab_material</translation>
		</message>
		<message>
			<source>tab_nodecat</source>
			<translation>Nodos</translation>
		</message>
		<message>
			<source>tooltip_tab_nodecat</source>
			<translation>tab_nodecat</translation>
		</message>
		<message>
			<source>tbl_arcs</source>
			<translation>Nuevo nombre de catálogo</translation>
		</message>
		<message>
			<source>tooltip_tbl_arcs</source>
			<translation>tbl_arcs</translation>
		</message>
		<message>
			<source>tbl_feature</source>
			<translation>Característica</translation>
		</message>
		<message>
			<source>tooltip_tbl_feature</source>
			<translation>tbl_feature</translation>
		</message>
		<message>
			<source>tbl_flwreg</source>
			<translation>Nuevo nombre de catálogo</translation>
		</message>
		<message>
			<source>tooltip_tbl_flwreg</source>
			<translation>tbl_flwreg</translation>
		</message>
		<message>
			<source>tbl_material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>tooltip_tbl_material</source>
			<translation>tbl_material</translation>
		</message>
		<message>
			<source>tbl_nodes</source>
			<translation>Nuevo nombre de catálogo</translation>
		</message>
		<message>
			<source>tooltip_tbl_nodes</source>
			<translation>tbl_nodes</translation>
		</message>
	</context>
	<context>
		<name>inp_parsing</name>
		<message>
			<source>title</source>
			<translation>Análisis del fichero INP</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>dlg_inp_parsing</source>
			<translation>Análisis del fichero INP</translation>
		</message>
		<message>
			<source>tooltip_dlg_inp_parsing</source>
			<translation>dlg_inp_parsing</translation>
		</message>
		<message>
			<source>tab_databaselog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_databaselog</source>
			<translation>tab_databaselog</translation>
		</message>
	</context>
	<context>
		<name>interpolate</name>
		<message>
			<source>title</source>
			<translation>Interpolar</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_interpolate</source>
			<translation>Interpolar</translation>
		</message>
		<message>
			<source>tooltip_dlg_interpolate</source>
			<translation>dlg_interpolate</translation>
		</message>
		<message>
			<source>rb_extrapolate</source>
			<translation>Extrapolar</translation>
		</message>
		<message>
			<source>tooltip_rb_extrapolate</source>
			<translation>rb_extrapolate</translation>
		</message>
		<message>
			<source>rb_interpolate</source>
			<translation>Interpolar</translation>
		</message>
		<message>
			<source>tooltip_rb_interpolate</source>
			<translation>rb_interpolate</translation>
		</message>
	</context>
	<context>
		<name>load_menu</name>
		<message>
			<source>title</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_load_menu</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>tooltip_dlg_load_menu</source>
			<translation>dlg_load_menu</translation>
		</message>
	</context>
	<context>
		<name>lot_management</name>
		<message>
			<source>title</source>
			<translation>Administrador de lotes</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar lote</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Eliminar lote</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Abrir lote</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>Abrir lote</translation>
		</message>
		<message>
			<source>chk_show_nulls</source>
			<translation>Mostrar valores vacíos</translation>
		</message>
		<message>
			<source>tooltip_chk_show_nulls</source>
			<translation>Mostrar valores vacíos</translation>
		</message>
		<message>
			<source>dlg_lot_management</source>
			<translation>Administrador de lotes</translation>
		</message>
		<message>
			<source>tooltip_dlg_lot_management</source>
			<translation>dlg_lot_management</translation>
		</message>
		<message>
			<source>lbl_column_filter</source>
			<translation>Columna filtrar datos:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter</source>
			<translation>Columna filtrar datos:</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Desde:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>Desde:</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Hasta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>Hasta:</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Nombre:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Estado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Estado:</translation>
		</message>
	</context>
	<context>
		<name>mapzone_config</name>
		<message>
			<source>title</source>
			<translation>Config Mapzone</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_forceClosed</source>
			<translation>AÑADE</translation>
		</message>
		<message>
			<source>tooltip_btn_add_forceClosed</source>
			<translation>btn_add_forceClosed</translation>
		</message>
		<message>
			<source>btn_add_ignore</source>
			<translation>AÑADE</translation>
		</message>
		<message>
			<source>tooltip_btn_add_ignore</source>
			<translation>btn_add_ignore</translation>
		</message>
		<message>
			<source>btn_add_nodeParent</source>
			<translation>AÑADE</translation>
		</message>
		<message>
			<source>tooltip_btn_add_nodeParent</source>
			<translation>btn_add_nodeParent</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_clear_preview</source>
			<translation>Vista previa</translation>
		</message>
		<message>
			<source>tooltip_btn_clear_preview</source>
			<translation>btn_clear_preview</translation>
		</message>
		<message>
			<source>btn_remove_forceClosed</source>
			<translation>ELIMINAR</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_forceClosed</source>
			<translation>btn_remove_forceClosed</translation>
		</message>
		<message>
			<source>btn_remove_ignore</source>
			<translation>ELIMINAR</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_ignore</source>
			<translation>btn_remove_ignore</translation>
		</message>
		<message>
			<source>btn_remove_nodeParent</source>
			<translation>ELIMINAR</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_nodeParent</source>
			<translation>btn_remove_nodeParent</translation>
		</message>
		<message>
			<source>dlg_mapzone_config</source>
			<translation>Config Mapzone</translation>
		</message>
		<message>
			<source>tooltip_dlg_mapzone_config</source>
			<translation>dlg_mapzone_config</translation>
		</message>
		<message>
			<source>lbl_forceClosed</source>
			<translation>forzarCierre:</translation>
		</message>
		<message>
			<source>tooltip_lbl_forceClosed</source>
			<translation>lbl_forceClosed</translation>
		</message>
		<message>
			<source>lbl_ignore</source>
			<translation>ignorar</translation>
		</message>
		<message>
			<source>tooltip_lbl_ignore</source>
			<translation>lbl_ignore</translation>
		</message>
		<message>
			<source>lbl_nodeParent</source>
			<translation>nodoPadre:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodeParent</source>
			<translation>lbl_nodeParent</translation>
		</message>
		<message>
			<source>lbl_preview</source>
			<translation>Vista previa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_preview</source>
			<translation>lbl_preview</translation>
		</message>
		<message>
			<source>lbl_toArc</source>
			<translation>toArc:</translation>
		</message>
		<message>
			<source>tooltip_lbl_toArc</source>
			<translation>lbl_toArc</translation>
		</message>
	</context>
	<context>
		<name>mapzone_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de zonas de mapa</translation>
		</message>
		<message>
			<source>dlg_mapzone_manager</source>
			<translation>Gestor de zonas de mapa</translation>
		</message>
		<message>
			<source>tooltip_dlg_mapzone_manager</source>
			<translation>dlg_mapzone_manager</translation>
		</message>
	</context>
	<context>
		<name>massive_composer</name>
		<message>
			<source>title</source>
			<translation>Imprime automáticamente páginas compuestas</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>dlg_massive_composer</source>
			<translation>Imprime automáticamente páginas compuestas</translation>
		</message>
		<message>
			<source>tooltip_dlg_massive_composer</source>
			<translation>dlg_massive_composer</translation>
		</message>
		<message>
			<source>grb_comp</source>
			<translation>Lista de compositores</translation>
		</message>
		<message>
			<source>tooltip_grb_comp</source>
			<translation>grb_comp</translation>
		</message>
		<message>
			<source>lbl_composers</source>
			<translation>Selecciona compositor:</translation>
		</message>
		<message>
			<source>tooltip_lbl_composers</source>
			<translation>lbl_composers</translation>
		</message>
		<message>
			<source>lbl_folder</source>
			<translation>Selecciona la carpeta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_folder</source>
			<translation>lbl_folder</translation>
		</message>
		<message>
			<source>lbl_prefix</source>
			<translation>Archivo de prefijos:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prefix</source>
			<translation>lbl_prefix</translation>
		</message>
		<message>
			<source>lbl_single</source>
			<translation>Archivo único:</translation>
		</message>
		<message>
			<source>tooltip_lbl_single</source>
			<translation>lbl_single</translation>
		</message>
		<message>
			<source>lbl_sleep</source>
			<translation>Hora de dormir:</translation>
		</message>
		<message>
			<source>tooltip_lbl_sleep</source>
			<translation>lbl_sleep</translation>
		</message>
	</context>
	<context>
		<name>mincut</name>
		<message>
			<source>title</source>
			<translation>Polígono de corte</translation>
		</message>
		<message>
			<source>actionCustomMincut</source>
			<translation>actionCustomMincut</translation>
		</message>
		<message>
			<source>tooltip_actionCustomMincut</source>
			<translation>Inaccessible valve</translation>
		</message>
		<message>
			<source>actionExportHydroCsv</source>
			<translation>actionExportHydroCsv</translation>
		</message>
		<message>
			<source>tooltip_actionExportHydroCsv</source>
			<translation>Export Hydro Csv</translation>
		</message>
		<message>
			<source>actionMincut</source>
			<translation>Red del Polígono de Corte</translation>
		</message>
		<message>
			<source>tooltip_actionMincut</source>
			<translation>Polígono de Corte Automatico</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Cancelar tarea</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_end</source>
			<translation>Fin</translation>
		</message>
		<message>
			<source>tooltip_btn_end</source>
			<translation>btn_end</translation>
		</message>
		<message>
			<source>btn_start</source>
			<translation>Inicio</translation>
		</message>
		<message>
			<source>tooltip_btn_start</source>
			<translation>btn_start</translation>
		</message>
		<message>
			<source>cbx_date_end</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end</source>
			<translation>cbx_date_end</translation>
		</message>
		<message>
			<source>cbx_date_end_predict</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end_predict</source>
			<translation>cbx_date_end_predict</translation>
		</message>
		<message>
			<source>cbx_date_start</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start</source>
			<translation>cbx_date_start</translation>
		</message>
		<message>
			<source>cbx_date_start_predict</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start_predict</source>
			<translation>cbx_date_start_predict</translation>
		</message>
		<message>
			<source>cbx_recieved_day</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_recieved_day</source>
			<translation>cbx_recieved_day</translation>
		</message>
		<message>
			<source>chk_use_planified</source>
			<translation>Usar red planificada</translation>
		</message>
		<message>
			<source>tooltip_chk_use_planified</source>
			<translation>chk_use_planified</translation>
		</message>
		<message>
			<source>dlg_mincut</source>
			<translation>Polígono de corte</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut</source>
			<translation>dlg_mincut</translation>
		</message>
		<message>
			<source>grb_adress</source>
			<translation>Dirección</translation>
		</message>
		<message>
			<source>tooltip_grb_adress</source>
			<translation>grb_adress</translation>
		</message>
		<message>
			<source>grb_exec_realdates</source>
			<translation>Fechas reales</translation>
		</message>
		<message>
			<source>tooltip_grb_exec_realdates</source>
			<translation>grb_exec_realdates</translation>
		</message>
		<message>
			<source>grb_plan_details</source>
			<translation>Detalles</translation>
		</message>
		<message>
			<source>tooltip_grb_plan_details</source>
			<translation>grb_plan_details</translation>
		</message>
		<message>
			<source>grb_plan_forecasted_dates</source>
			<translation>Fechas previstas</translation>
		</message>
		<message>
			<source>tooltip_grb_plan_forecasted_dates</source>
			<translation>grb_plan_forecasted_dates</translation>
		</message>
		<message>
			<source>lbl_assigned_to</source>
			<translation>Asignado a:</translation>
		</message>
		<message>
			<source>tooltip_lbl_assigned_to</source>
			<translation>lbl_assigned_to</translation>
		</message>
		<message>
			<source>lbl_cause</source>
			<translation>Causa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cause</source>
			<translation>lbl_cause</translation>
		</message>
		<message>
			<source>lbl_chlorine</source>
			<translation>Cloro:</translation>
		</message>
		<message>
			<source>tooltip_lbl_chlorine</source>
			<translation>lbl_chlorine</translation>
		</message>
		<message>
			<source>lbl_depth</source>
			<translation>Profundidad:</translation>
		</message>
		<message>
			<source>tooltip_lbl_depth</source>
			<translation>lbl_depth</translation>
		</message>
		<message>
			<source>lbl_descript_pd</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_pd</source>
			<translation>lbl_descript_pd</translation>
		</message>
		<message>
			<source>lbl_descript_rd</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_rd</source>
			<translation>lbl_descript_rd</translation>
		</message>
		<message>
			<source>lbl_dist_from_plot</source>
			<translation>Distancia fachada:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dist_from_plot</source>
			<translation>lbl_dist_from_plot</translation>
		</message>
		<message>
			<source>lbl_end</source>
			<translation>Fin:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end</source>
			<translation>lbl_end</translation>
		</message>
		<message>
			<source>lbl_equipment_code</source>
			<translation>Equipo de medición de cloro:</translation>
		</message>
		<message>
			<source>tooltip_lbl_equipment_code</source>
			<translation>lbl_equipment_code</translation>
		</message>
		<message>
			<source>lbl_exec_appropriate</source>
			<translation>Adecuado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_appropriate</source>
			<translation>Si es verdadero, la ubicación real coincide con la información mincut programada</translation>
		</message>
		<message>
			<source>lbl_exec_enddate</source>
			<translation>Fecha de finalización:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_enddate</source>
			<translation>lbl_exec_enddate</translation>
		</message>
		<message>
			<source>lbl_exec_startdate</source>
			<translation>Fecha incial:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_startdate</source>
			<translation>Visitar ID</translation>
		</message>
		<message>
			<source>lbl_exec_user</source>
			<translation>Usuario ejecutivo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_user</source>
			<translation>lbl_exec_user</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_municiplity</source>
			<translation>Municipio</translation>
		</message>
		<message>
			<source>tooltip_lbl_municiplity</source>
			<translation>lbl_municiplity</translation>
		</message>
		<message>
			<source>lbl_postnumber</source>
			<translation>Número</translation>
		</message>
		<message>
			<source>tooltip_lbl_postnumber</source>
			<translation>lbl_postnumber</translation>
		</message>
		<message>
			<source>lbl_reagent_lot</source>
			<translation>Lote del reactivo de cloro:</translation>
		</message>
		<message>
			<source>tooltip_lbl_reagent_lot</source>
			<translation>lbl_reagent_lot</translation>
		</message>
		<message>
			<source>lbl_received_date</source>
			<translation>Fecha de recepción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_received_date</source>
			<translation>lbl_received_date</translation>
		</message>
		<message>
			<source>lbl_start</source>
			<translation>Inicio:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start</source>
			<translation>lbl_start</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Estado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
		<message>
			<source>lbl_street</source>
			<translation>Calle</translation>
		</message>
		<message>
			<source>tooltip_lbl_street</source>
			<translation>lbl_street</translation>
		</message>
		<message>
			<source>lbl_turbidity</source>
			<translation>Turbiedad:</translation>
		</message>
		<message>
			<source>tooltip_lbl_turbidity</source>
			<translation>lbl_turbidity</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Tipo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
		<message>
			<source>lbl_work_order</source>
			<translation>Orden de trabajo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_order</source>
			<translation>lbl_work_order</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Ejec</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Plan</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_hydro</source>
			<translation>Hidro</translation>
		</message>
		<message>
			<source>tooltip_tab_hydro</source>
			<translation>tab_hydro</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>Exportar Hydro Csv</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>mincut_composer</name>
		<message>
			<source>title</source>
			<translation>Compositor polígono de corte</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Abrir</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_mincut_composer</source>
			<translation>Compositor polígono de corte</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_composer</source>
			<translation>dlg_mincut_composer</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Mincut compositor</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_rotation</source>
			<translation>Rotación:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rotation</source>
			<translation>lbl_rotation</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Modelo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Título:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
	</context>
	<context>
		<name>mincut_connec</name>
		<message>
			<source>title</source>
			<translation>Polígono de corte acometidas</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>dlg_mincut_connec</source>
			<translation>Polígono de corte acometidas</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_connec</source>
			<translation>dlg_mincut_connec</translation>
		</message>
		<message>
			<source>lbl_search</source>
			<translation>Buscar por &apos;customer code&apos;:</translation>
		</message>
		<message>
			<source>tooltip_lbl_search</source>
			<translation>lbl_search</translation>
		</message>
	</context>
	<context>
		<name>mincut_end</name>
		<message>
			<source>title</source>
			<translation>Finalizar polígono de corte</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_set_real_location</source>
			<translation>Establecer ubicación real</translation>
		</message>
		<message>
			<source>tooltip_btn_set_real_location</source>
			<translation>btn_set_real_location</translation>
		</message>
		<message>
			<source>cbx_date_end_fin</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end_fin</source>
			<translation>cbx_date_end_fin</translation>
		</message>
		<message>
			<source>cbx_date_start_fin</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start_fin</source>
			<translation>cbx_date_start_fin</translation>
		</message>
		<message>
			<source>cbx_hours_start_fin</source>
			<translation>H:mm:ss</translation>
		</message>
		<message>
			<source>tooltip_cbx_hours_start_fin</source>
			<translation>cbx_hours_start_fin</translation>
		</message>
		<message>
			<source>dlg_mincut_end</source>
			<translation>Finalizar polígono de corte</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_end</source>
			<translation>dlg_mincut_end</translation>
		</message>
		<message>
			<source>grb_adress</source>
			<translation>Dirección</translation>
		</message>
		<message>
			<source>tooltip_grb_adress</source>
			<translation>grb_adress</translation>
		</message>
		<message>
			<source>grb_close_mincut</source>
			<translation>Cerrar mincut</translation>
		</message>
		<message>
			<source>tooltip_grb_close_mincut</source>
			<translation>grb_close_mincut</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Fechas</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>lbl_end_date</source>
			<translation>Hasta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_date</source>
			<translation>lbl_end_date</translation>
		</message>
		<message>
			<source>lbl_end_hour</source>
			<translation>Hora de finalización:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_hour</source>
			<translation>lbl_end_hour</translation>
		</message>
		<message>
			<source>lbl_executed</source>
			<translation>Ejecutado por:</translation>
		</message>
		<message>
			<source>tooltip_lbl_executed</source>
			<translation>lbl_executed</translation>
		</message>
		<message>
			<source>lbl_mincut</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mincut</source>
			<translation>lbl_mincut</translation>
		</message>
		<message>
			<source>lbl_msg</source>
			<translation>No se han encontrado resultados</translation>
		</message>
		<message>
			<source>tooltip_lbl_msg</source>
			<translation>lbl_msg</translation>
		</message>
		<message>
			<source>lbl_municiplity</source>
			<translation>Municipio</translation>
		</message>
		<message>
			<source>tooltip_lbl_municiplity</source>
			<translation>lbl_municiplity</translation>
		</message>
		<message>
			<source>lbl_postnumber</source>
			<translation>Número</translation>
		</message>
		<message>
			<source>tooltip_lbl_postnumber</source>
			<translation>lbl_postnumber</translation>
		</message>
		<message>
			<source>lbl_start_date</source>
			<translation>Desde:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_date</source>
			<translation>lbl_start_date</translation>
		</message>
		<message>
			<source>lbl_start_hour</source>
			<translation>Hora de inicio:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_hour</source>
			<translation>lbl_start_hour</translation>
		</message>
		<message>
			<source>lbl_street</source>
			<translation>Calle</translation>
		</message>
		<message>
			<source>tooltip_lbl_street</source>
			<translation>lbl_street</translation>
		</message>
		<message>
			<source>lbl_work_order</source>
			<translation>Orden de trabajo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_order</source>
			<translation>lbl_work_order</translation>
		</message>
	</context>
	<context>
		<name>mincut_hydrometer</name>
		<message>
			<source>title</source>
			<translation>Hidrómetro polígono de corte</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>dlg_mincut_hydrometer</source>
			<translation>Hidrómetro polígono de corte</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_hydrometer</source>
			<translation>dlg_mincut_hydrometer</translation>
		</message>
		<message>
			<source>lbl_ccc</source>
			<translation>Conectar código cliente:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ccc</source>
			<translation>lbl_ccc</translation>
		</message>
		<message>
			<source>lbl_hcc</source>
			<translation>Código cliente hidrómetro:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hcc</source>
			<translation>lbl_hcc</translation>
		</message>
	</context>
	<context>
		<name>mincut_manager</name>
		<message>
			<source>title</source>
			<translation>Gestión polígono de corte</translation>
		</message>
		<message>
			<source>btn_selector_mincut</source>
			<translation>btn_selector_mincut</translation>
		</message>
		<message>
			<source>tooltip_btn_selector_mincut</source>
			<translation>btn_selector_mincut</translation>
		</message>
		<message>
			<source>dlg_mincut_manager</source>
			<translation>Gestión polígono de corte</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_manager</source>
			<translation>dlg_mincut_manager</translation>
		</message>
	</context>
	<context>
		<name>netscenario</name>
		<message>
			<source>title</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>btn_config</source>
			<translation>Configuracion</translation>
		</message>
		<message>
			<source>tooltip_btn_config</source>
			<translation>Ejecutar análisis de zonas de mapa</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Ejecutar análisis de zonas de mapa</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Ejecutar análisis de zonas de mapa</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Alternar activo</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Ejecutar análisis de zonas de mapa</translation>
		</message>
		<message>
			<source>btn_toggle_closed</source>
			<translation>Alternar cierre</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_closed</source>
			<translation>Ejecutar análisis de zonas de mapa</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Ejecutar análisis de zonas de mapa</translation>
		</message>
		<message>
			<source>dlg_netscenario</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>tooltip_dlg_netscenario</source>
			<translation>dlg_netscenario</translation>
		</message>
		<message>
			<source>lbl_mapzone_id</source>
			<translation>Mapzone id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mapzone_id</source>
			<translation>Ejecutar análisis de zonas de mapa</translation>
		</message>
	</context>
	<context>
		<name>netscenario_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de escenarios de red</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplicar</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>Duplicar</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Alternar activo</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Alternar activo</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>btn_update_netscenario</source>
			<translation>Escenario de red actual</translation>
		</message>
		<message>
			<source>tooltip_btn_update_netscenario</source>
			<translation>Escenario de red actual</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Mostrar inactivos</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Mostrar inactivos</translation>
		</message>
		<message>
			<source>dlg_netscenario_manager</source>
			<translation>Gestor de escenarios de red</translation>
		</message>
		<message>
			<source>tooltip_dlg_netscenario_manager</source>
			<translation>Gestor d&apos;escenaris de xarxa</translation>
		</message>
		<message>
			<source>lbl_netscenario_name</source>
			<translation>Filtrar por: Nombre del escenario de red</translation>
		</message>
		<message>
			<source>tooltip_lbl_netscenario_name</source>
			<translation>Filtrar por: Nombre del escenario</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_controls</name>
		<message>
			<source>title</source>
			<translation>Editor de controles sencillos</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Activo</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_controls</source>
			<translation>Editor de controles sencillos</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_controls</source>
			<translation>dlg_nonvisual_controls</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observ</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_sector_id</source>
			<translation>Sector ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_sector_id</source>
			<translation>lbl_sector_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_curve</name>
		<message>
			<source>title</source>
			<translation>Editor de curvas</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_curve</source>
			<translation>Editor de curvas</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_curve</source>
			<translation>dlg_nonvisual_curve</translation>
		</message>
		<message>
			<source>lbl_curve_id</source>
			<translation>ID de curva</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_id</source>
			<translation>lbl_curve_id</translation>
		</message>
		<message>
			<source>lbl_curve_type</source>
			<translation>Tipo de curva</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_type</source>
			<translation>lbl_curve_type</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descripción</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>Id explotación</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>tbl_curve_value</source>
			<translation>Y</translation>
		</message>
		<message>
			<source>tooltip_tbl_curve_value</source>
			<translation>tbl_curve_value</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_lids</name>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_help</source>
			<translation>Ayuda</translation>
		</message>
		<message>
			<source>tooltip_btn_help</source>
			<translation>btn_help</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>Dialog</source>
			<translation>LIDS</translation>
		</message>
		<message>
			<source>tooltip_Dialog</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>drain</source>
			<translation>Drenaje</translation>
		</message>
		<message>
			<source>tooltip_drain</source>
			<translation>drain</translation>
		</message>
		<message>
			<source>drainmat</source>
			<translation>Drenaje de esteras</translation>
		</message>
		<message>
			<source>tooltip_drainmat</source>
			<translation>drainmat</translation>
		</message>
		<message>
			<source>label_source_img</source>
			<translation>Fuente: SWMM 5.1</translation>
		</message>
		<message>
			<source>tooltip_label_source_img</source>
			<translation>label_source_img</translation>
		</message>
		<message>
			<source>lbl_berm_height</source>
			<translation>Altura de la berma (pulg. o mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_berm_height</source>
			<translation>lbl_berm_height</translation>
		</message>
		<message>
			<source>lbl_clogging_factor_pavement</source>
			<translation>Factor de obstrucción</translation>
		</message>
		<message>
			<source>tooltip_lbl_clogging_factor_pavement</source>
			<translation>lbl_clogging_factor_pavement</translation>
		</message>
		<message>
			<source>lbl_clogging_factor_storage</source>
			<translation>Factor de obstrucción</translation>
		</message>
		<message>
			<source>tooltip_lbl_clogging_factor_storage</source>
			<translation>lbl_clogging_factor_storage</translation>
		</message>
		<message>
			<source>lbl_closed_level</source>
			<translation>Nivel cerrado (pulg. o mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_closed_level</source>
			<translation>lbl_closed_level</translation>
		</message>
		<message>
			<source>lbl_conducticity_slope</source>
			<translation>Pendiente de conductividad</translation>
		</message>
		<message>
			<source>tooltip_lbl_conducticity_slope</source>
			<translation>lbl_conducticity_slope</translation>
		</message>
		<message>
			<source>lbl_conductivity</source>
			<translation>Conductividad (pulg./hora o mm./hora)</translation>
		</message>
		<message>
			<source>tooltip_lbl_conductivity</source>
			<translation>lbl_conductivity</translation>
		</message>
		<message>
			<source>lbl_control_curve</source>
			<translation>Curva de control</translation>
		</message>
		<message>
			<source>tooltip_lbl_control_curve</source>
			<translation>lbl_control_curve</translation>
		</message>
		<message>
			<source>lbl_control_name</source>
			<translation>Nombre de control:</translation>
		</message>
		<message>
			<source>tooltip_lbl_control_name</source>
			<translation>lbl_control_name</translation>
		</message>
		<message>
			<source>lbl_drain_delay</source>
			<translation>Retraso de drenaje (horas)</translation>
		</message>
		<message>
			<source>tooltip_lbl_drain_delay</source>
			<translation>lbl_drain_delay</translation>
		</message>
		<message>
			<source>lbl_field_capacity</source>
			<translation>Capacidad de campo (fracción de volumen)</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_capacity</source>
			<translation>lbl_field_capacity</translation>
		</message>
		<message>
			<source>lbl_flow_capacity</source>
			<translation>Capacidad de caudal (pulg./hora o mm./hora)</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_capacity</source>
			<translation>lbl_flow_capacity</translation>
		</message>
		<message>
			<source>lbl__flow_coefficient</source>
			<translation>Coeficiente de caudal*</translation>
		</message>
		<message>
			<source>tooltip_lbl__flow_coefficient</source>
			<translation>lbl__flow_coefficient</translation>
		</message>
		<message>
			<source>lbl_flow_description</source>
			<translation>*El caudal es en pulg./hora o mm./hora; utilice 0 si no hay desagüe.</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_description</source>
			<translation>lbl_flow_description</translation>
		</message>
		<message>
			<source>lbl_flow_exponent</source>
			<translation>Exponente de flujo</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_exponent</source>
			<translation>lbl_flow_exponent</translation>
		</message>
		<message>
			<source>lbl_imprevious_surface</source>
			<translation>Fracción de superficie impermeable</translation>
		</message>
		<message>
			<source>tooltip_lbl_imprevious_surface</source>
			<translation>lbl_imprevious_surface</translation>
		</message>
		<message>
			<source>lbl_lid_type</source>
			<translation>Tipo LID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_lid_type</source>
			<translation>lbl_lid_type</translation>
		</message>
		<message>
			<source>lbl_offset</source>
			<translation>Desplazamiento (pulg. o mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_offset</source>
			<translation>lbl_offset</translation>
		</message>
		<message>
			<source>lbl_open_level</source>
			<translation>Nivel abierto (pulg. o mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_open_level</source>
			<translation>lbl_open_level</translation>
		</message>
		<message>
			<source>lbl__permeability</source>
			<translation>Permeabilidad (pulg./hora o mm./hora)</translation>
		</message>
		<message>
			<source>tooltip_lbl__permeability</source>
			<translation>lbl__permeability</translation>
		</message>
		<message>
			<source>lbl_porosity</source>
			<translation>Porosidad (fracción de volumen)</translation>
		</message>
		<message>
			<source>tooltip_lbl_porosity</source>
			<translation>lbl_porosity</translation>
		</message>
		<message>
			<source>lbl_regeneration_fraction</source>
			<translation>Fracción de regeneración</translation>
		</message>
		<message>
			<source>tooltip_lbl_regeneration_fraction</source>
			<translation>lbl_regeneration_fraction</translation>
		</message>
		<message>
			<source>lbl_regeneration_interval</source>
			<translation>Intervalo de regeneración (días)</translation>
		</message>
		<message>
			<source>tooltip_lbl_regeneration_interval</source>
			<translation>lbl_regeneration_interval</translation>
		</message>
		<message>
			<source>lbl_roughness</source>
			<translation>Rugosidad (Mannings n)</translation>
		</message>
		<message>
			<source>tooltip_lbl_roughness</source>
			<translation>lbl_roughness</translation>
		</message>
		<message>
			<source>lbl_seepage_rate</source>
			<translation>Velocidad de infiltración (pulg./hora o mm./hora)</translation>
		</message>
		<message>
			<source>tooltip_lbl_seepage_rate</source>
			<translation>lbl_seepage_rate</translation>
		</message>
		<message>
			<source>lbl_suction_head</source>
			<translation>Altura de aspiración (pulg. o mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_suction_head</source>
			<translation>lbl_suction_head</translation>
		</message>
		<message>
			<source>lbl_surface_roughness</source>
			<translation>Rugosidad superficial (Mannings n)</translation>
		</message>
		<message>
			<source>tooltip_lbl_surface_roughness</source>
			<translation>lbl_surface_roughness</translation>
		</message>
		<message>
			<source>lbl_surface_slope</source>
			<translation>Pendiente de la superficie (porcentaje)</translation>
		</message>
		<message>
			<source>tooltip_lbl_surface_slope</source>
			<translation>lbl_surface_slope</translation>
		</message>
		<message>
			<source>lbl_swale_side_slope</source>
			<translation>Pendiente lateral del canal (recorrido/elevación)</translation>
		</message>
		<message>
			<source>tooltip_lbl_swale_side_slope</source>
			<translation>lbl_swale_side_slope</translation>
		</message>
		<message>
			<source>lbl_thickness</source>
			<translation>Espesor (pulg. o mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness</source>
			<translation>lbl_thickness</translation>
		</message>
		<message>
			<source>lbl_thickness_drainage</source>
			<translation>Espesor (pulg. o mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness_drainage</source>
			<translation>lbl_thickness_drainage</translation>
		</message>
		<message>
			<source>lbl_thickness_storage</source>
			<translation>Espesor (pulg. o mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness_storage</source>
			<translation>lbl_thickness_storage</translation>
		</message>
		<message>
			<source>lbl_thinkness_pavement</source>
			<translation>Espesor (pulg. o mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thinkness_pavement</source>
			<translation>lbl_thinkness_pavement</translation>
		</message>
		<message>
			<source>lbl_vegetation_volume</source>
			<translation>Fracción de volumen de vegetación</translation>
		</message>
		<message>
			<source>tooltip_lbl_vegetation_volume</source>
			<translation>lbl_vegetation_volume</translation>
		</message>
		<message>
			<source>lbl_void_fraction</source>
			<translation>Fracción de vacío</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_fraction</source>
			<translation>lbl_void_fraction</translation>
		</message>
		<message>
			<source>lbl_void_ratio_pavement</source>
			<translation>Índice de vacíos (vacíos / sólidos)</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_ratio_pavement</source>
			<translation>lbl_void_ratio_pavement</translation>
		</message>
		<message>
			<source>lbl_void_ratio_storage</source>
			<translation>Proporción de vacíos (vacíos / sólidos)</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_ratio_storage</source>
			<translation>lbl_void_ratio_storage</translation>
		</message>
		<message>
			<source>lbl_wilting_point</source>
			<translation>Punto de marchitamiento (fracción de volumen)</translation>
		</message>
		<message>
			<source>tooltip_lbl_wilting_point</source>
			<translation>lbl_wilting_point</translation>
		</message>
		<message>
			<source>pavement</source>
			<translation>Pavimento</translation>
		</message>
		<message>
			<source>tooltip_pavement</source>
			<translation>pavement</translation>
		</message>
		<message>
			<source>rooftop</source>
			<translation>Drenaje del tejado</translation>
		</message>
		<message>
			<source>tooltip_rooftop</source>
			<translation>rooftop</translation>
		</message>
		<message>
			<source>soil</source>
			<translation>Suelo</translation>
		</message>
		<message>
			<source>tooltip_soil</source>
			<translation>soil</translation>
		</message>
		<message>
			<source>storage</source>
			<translation>Almacenamiento</translation>
		</message>
		<message>
			<source>tooltip_storage</source>
			<translation>storage</translation>
		</message>
		<message>
			<source>surface</source>
			<translation>Superficie</translation>
		</message>
		<message>
			<source>tooltip_surface</source>
			<translation>surface</translation>
		</message>
		<message>
			<source>txt_1_berm_height</source>
			<translation>0.0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_berm_height</source>
			<translation>txt_1_berm_height</translation>
		</message>
		<message>
			<source>txt_1_flow_coefficient</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_flow_coefficient</source>
			<translation>txt_1_flow_coefficient</translation>
		</message>
		<message>
			<source>txt_1_thickness</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness</source>
			<translation>txt_1_thickness</translation>
		</message>
		<message>
			<source>txt_1_thickness_drainage</source>
			<translation>3</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_drainage</source>
			<translation>txt_1_thickness_drainage</translation>
		</message>
		<message>
			<source>txt_1_thickness_pavement</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_pavement</source>
			<translation>txt_1_thickness_pavement</translation>
		</message>
		<message>
			<source>txt_1_thickness_storage</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_storage</source>
			<translation>txt_1_thickness_storage</translation>
		</message>
		<message>
			<source>txt_2_flow_exponent</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_flow_exponent</source>
			<translation>txt_2_flow_exponent</translation>
		</message>
		<message>
			<source>txt_2_porosity</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_porosity</source>
			<translation>txt_2_porosity</translation>
		</message>
		<message>
			<source>txt_2_vegetation_volume</source>
			<translation>0.0</translation>
		</message>
		<message>
			<source>tooltip_txt_2_vegetation_volume</source>
			<translation>txt_2_vegetation_volume</translation>
		</message>
		<message>
			<source>txt_2_void_fraction</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_fraction</source>
			<translation>txt_2_void_fraction</translation>
		</message>
		<message>
			<source>txt_2_void_ratio_pavement</source>
			<translation>0.15</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_ratio_pavement</source>
			<translation>txt_2_void_ratio_pavement</translation>
		</message>
		<message>
			<source>txt_2_void_ratio_storage</source>
			<translation>0.75</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_ratio_storage</source>
			<translation>txt_2_void_ratio_storage</translation>
		</message>
		<message>
			<source>txt_3_field_capacity</source>
			<translation>0.2</translation>
		</message>
		<message>
			<source>tooltip_txt_3_field_capacity</source>
			<translation>txt_3_field_capacity</translation>
		</message>
		<message>
			<source>txt_3_imprevious_surface</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_3_imprevious_surface</source>
			<translation>txt_3_imprevious_surface</translation>
		</message>
		<message>
			<source>txt_3_offset</source>
			<translation>6</translation>
		</message>
		<message>
			<source>tooltip_txt_3_offset</source>
			<translation>txt_3_offset</translation>
		</message>
		<message>
			<source>txt_3_roughness</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_3_roughness</source>
			<translation>txt_3_roughness</translation>
		</message>
		<message>
			<source>txt_3_seepage_rate</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_3_seepage_rate</source>
			<translation>txt_3_seepage_rate</translation>
		</message>
		<message>
			<source>txt_3_surface_roughness</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_3_surface_roughness</source>
			<translation>txt_3_surface_roughness</translation>
		</message>
		<message>
			<source>txt_4_clogging_factor_storage</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_4_clogging_factor_storage</source>
			<translation>txt_4_clogging_factor_storage</translation>
		</message>
		<message>
			<source>txt_4_drain_delay</source>
			<translation>6</translation>
		</message>
		<message>
			<source>tooltip_txt_4_drain_delay</source>
			<translation>txt_4_drain_delay</translation>
		</message>
		<message>
			<source>txt_4_permeability</source>
			<translation>100</translation>
		</message>
		<message>
			<source>tooltip_txt_4_permeability</source>
			<translation>txt_4_permeability</translation>
		</message>
		<message>
			<source>txt_4_surface_slope</source>
			<translation>1.0</translation>
		</message>
		<message>
			<source>tooltip_txt_4_surface_slope</source>
			<translation>txt_4_surface_slope</translation>
		</message>
		<message>
			<source>txt_4_wilting_point</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_4_wilting_point</source>
			<translation>txt_4_wilting_point</translation>
		</message>
		<message>
			<source>txt_5_clogging_factor_pavement</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_5_clogging_factor_pavement</source>
			<translation>txt_5_clogging_factor_pavement</translation>
		</message>
		<message>
			<source>txt_5_conductivity</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_5_conductivity</source>
			<translation>txt_5_conductivity</translation>
		</message>
		<message>
			<source>txt_5_open_level</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_5_open_level</source>
			<translation>txt_5_open_level</translation>
		</message>
		<message>
			<source>txt_5_swale_side_slope</source>
			<translation>5</translation>
		</message>
		<message>
			<source>tooltip_txt_5_swale_side_slope</source>
			<translation>txt_5_swale_side_slope</translation>
		</message>
		<message>
			<source>txt_6_closed_level</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_closed_level</source>
			<translation>txt_6_closed_level</translation>
		</message>
		<message>
			<source>txt_6_conducticity_slope</source>
			<translation>10.0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_conducticity_slope</source>
			<translation>txt_6_conducticity_slope</translation>
		</message>
		<message>
			<source>txt_6_regeneration_interval</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_regeneration_interval</source>
			<translation>txt_6_regeneration_interval</translation>
		</message>
		<message>
			<source>txt_7_regeneration_fraction</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_7_regeneration_fraction</source>
			<translation>txt_7_regeneration_fraction</translation>
		</message>
		<message>
			<source>txt_7_suction_head</source>
			<translation>3.5</translation>
		</message>
		<message>
			<source>tooltip_txt_7_suction_head</source>
			<translation>txt_7_suction_head</translation>
		</message>
		<message>
			<source>txt_flow_capacity</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_flow_capacity</source>
			<translation>txt_flow_capacity</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de objetos no visuales</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplicar</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>Duplicar</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Forma a PNG</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>Forma a PNG</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Alternar activo</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Duplicar</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Mostrar inactivos</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Mostrar inactivos</translation>
		</message>
		<message>
			<source>dlg_nonvisual_manager</source>
			<translation>Gestor de objetos no visuales</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_manager</source>
			<translation>dlg_nonvisual_manager</translation>
		</message>
		<message>
			<source>lbl_curve_type</source>
			<translation>Tipo de curva</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_type</source>
			<translation>Tipo de curva</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtrar por:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Tipo de patrón</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>Tipo de patrón</translation>
		</message>
		<message>
			<source>lbl_timser_type</source>
			<translation>Tipo de series temporales</translation>
		</message>
		<message>
			<source>tooltip_lbl_timser_type</source>
			<translation>Tipo de serie temporal</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_pattern_ud</name>
		<message>
			<source>title</source>
			<translation>Editor de patrones</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_pattern_ud</source>
			<translation>Editor de patrones</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_pattern_ud</source>
			<translation>dlg_nonvisual_pattern_ud</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>Id explotación</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observación</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_pattern_id</source>
			<translation>Patrón ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_id</source>
			<translation>lbl_pattern_id</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Tipo de patrón</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>lbl_pattern_type</translation>
		</message>
		<message>
			<source>tbl_daily</source>
			<translation>SOL</translation>
		</message>
		<message>
			<source>tooltip_tbl_daily</source>
			<translation>tbl_daily</translation>
		</message>
		<message>
			<source>tbl_hourly</source>
			<translation>11PM</translation>
		</message>
		<message>
			<source>tooltip_tbl_hourly</source>
			<translation>tbl_hourly</translation>
		</message>
		<message>
			<source>tbl_monthly</source>
			<translation>DEC</translation>
		</message>
		<message>
			<source>tooltip_tbl_monthly</source>
			<translation>tbl_monthly</translation>
		</message>
		<message>
			<source>tbl_weekend</source>
			<translation>11PM</translation>
		</message>
		<message>
			<source>tooltip_tbl_weekend</source>
			<translation>tbl_weekend</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_pattern_ws</name>
		<message>
			<source>title</source>
			<translation>Editor de patrones</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_pattern_ws</source>
			<translation>Editor de patrones</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_pattern_ws</source>
			<translation>dlg_nonvisual_pattern_ws</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observación</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_pattern_id</source>
			<translation>Patrón ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_id</source>
			<translation>lbl_pattern_id</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Id explotación</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>lbl_pattern_type</translation>
		</message>
		<message>
			<source>tbl_pattern_value</source>
			<translation>18</translation>
		</message>
		<message>
			<source>tooltip_tbl_pattern_value</source>
			<translation>tbl_pattern_value</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_print</name>
		<message>
			<source>title</source>
			<translation>Objetos no visuales Imprimir</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>chk_cross_arccat</source>
			<translation>Cruz con arccat</translation>
		</message>
		<message>
			<source>tooltip_chk_cross_arccat</source>
			<translation>chk_cross_arccat</translation>
		</message>
		<message>
			<source>dlg_nonvisual_print</source>
			<translation>Objetos no visuales Imprimir</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_print</source>
			<translation>dlg_nonvisual_print</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_roughness</name>
		<message>
			<source>title</source>
			<translation>Editor de controles basados en reglas</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Activo</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_roughness</source>
			<translation>Editor de controles basados en reglas</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_roughness</source>
			<translation>dlg_nonvisual_roughness</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Período ID</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Edad inicial</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Fin de la edad</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Rugosidad</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Descripción</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>lbl_matcat_id</source>
			<translation>Matcat ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_matcat_id</source>
			<translation>lbl_matcat_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_rules</name>
		<message>
			<source>title</source>
			<translation>Editor de controles basados en reglas</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Activo</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_rules</source>
			<translation>Editor de controles basados en reglas</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_rules</source>
			<translation>dlg_nonvisual_rules</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observ</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_sector_id</source>
			<translation>Sector ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_sector_id</source>
			<translation>lbl_sector_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_timeseries</name>
		<message>
			<source>title</source>
			<translation>Editor de series temporales</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_timeseries</source>
			<translation>Editor de series temporales</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_timeseries</source>
			<translation>dlg_nonvisual_timeseries</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Tiempos Tipo</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Descripción</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Id explotación</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Activo</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_addparam</source>
			<translation>Addparam (json)</translation>
		</message>
		<message>
			<source>tooltip_lbl_addparam</source>
			<translation>lbl_addparam</translation>
		</message>
		<message>
			<source>lbl_curve_id</source>
			<translation>ID de la serie temporal</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_id</source>
			<translation>lbl_curve_id</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Tipo de serie temporal</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_fname</source>
			<translation>Nombre del fichero</translation>
		</message>
		<message>
			<source>tooltip_lbl_fname</source>
			<translation>lbl_fname</translation>
		</message>
		<message>
			<source>tbl_timeseries_value</source>
			<translation>Valor</translation>
		</message>
		<message>
			<source>tooltip_tbl_timeseries_value</source>
			<translation>tbl_timeseries_value</translation>
		</message>
	</context>
	<context>
		<name>print</name>
		<message>
			<source>title</source>
			<translation>Impresión</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_preview</source>
			<translation>Vista previa</translation>
		</message>
		<message>
			<source>tooltip_btn_preview</source>
			<translation>btn_preview</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Imprimir</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>btn_print</translation>
		</message>
		<message>
			<source>dlg_print</source>
			<translation>Impresión</translation>
		</message>
		<message>
			<source>tooltip_dlg_print</source>
			<translation>dlg_print</translation>
		</message>
		<message>
			<source>grb_map_options</source>
			<translation>Opciones de mapa:</translation>
		</message>
		<message>
			<source>tooltip_grb_map_options</source>
			<translation>grb_map_options</translation>
		</message>
		<message>
			<source>grb_option_values</source>
			<translation>Valores opcionales:</translation>
		</message>
		<message>
			<source>tooltip_grb_option_values</source>
			<translation>grb_option_values</translation>
		</message>
	</context>
	<context>
		<name>priority</name>
		<message>
			<source>title</source>
			<translation>Cálculo de prioridad</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Ejecutar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_again</source>
			<translation>Siguiente</translation>
		</message>
		<message>
			<source>tooltip_btn_again</source>
			<translation>btn_again</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_save2file</source>
			<translation>Guardar los resultados en un archivo Excel...</translation>
		</message>
		<message>
			<source>tooltip_btn_save2file</source>
			<translation>btn_save2file</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>Seleccione las características del lienzo</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Seleccionar elementos en el lienzo</translation>
		</message>
		<message>
			<source>dlg_priority</source>
			<translation>Cálculo de prioridad</translation>
		</message>
		<message>
			<source>tooltip_dlg_priority</source>
			<translation>dlg_priority</translation>
		</message>
		<message>
			<source>grb_engine_1</source>
			<translation>grb_engine_1</translation>
		</message>
		<message>
			<source>tooltip_grb_engine_1</source>
			<translation>grb_engine_1</translation>
		</message>
		<message>
			<source>grb_engine_2</source>
			<translation>grb_engine_2</translation>
		</message>
		<message>
			<source>tooltip_grb_engine_2</source>
			<translation>grb_engine_2</translation>
		</message>
		<message>
			<source>grb_global</source>
			<translation>Parámetros de cálculo</translation>
		</message>
		<message>
			<source>tooltip_grb_global</source>
			<translation>grb_global</translation>
		</message>
		<message>
			<source>grb_selection</source>
			<translation>Selección de características</translation>
		</message>
		<message>
			<source>tooltip_grb_selection</source>
			<translation>grb_selection</translation>
		</message>
		<message>
			<source>lbl_budget</source>
			<translation>Presupuesto anual:</translation>
		</message>
		<message>
			<source>tooltip_lbl_budget</source>
			<translation>lbl_budget</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_dnom</source>
			<translation>Diámetro:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dnom</source>
			<translation>lbl_dnom</translation>
		</message>
		<message>
			<source>lbl_expl_selection</source>
			<translation>Explotación:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_selection</source>
			<translation>lbl_expl_selection</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Material:</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>lbl_material</translation>
		</message>
		<message>
			<source>lbl_presszone</source>
			<translation>Zona de prensa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_presszone</source>
			<translation>lbl_presszone</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Nombre del resultado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Estado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_year</source>
			<translation>Año horizonte:</translation>
		</message>
		<message>
			<source>tooltip_lbl_year</source>
			<translation>lbl_year</translation>
		</message>
		<message>
			<source>tab_calc</source>
			<translation>Cálculo</translation>
		</message>
		<message>
			<source>tooltip_tab_calc</source>
			<translation>tab_calc</translation>
		</message>
		<message>
			<source>tab_catalog</source>
			<translation>Catálogo</translation>
		</message>
		<message>
			<source>tooltip_tab_catalog</source>
			<translation>tab_catalog</translation>
		</message>
		<message>
			<source>tab_engine</source>
			<translation>Motor</translation>
		</message>
		<message>
			<source>tooltip_tab_engine</source>
			<translation>tab_engine</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>tooltip_tab_material</source>
			<translation>tab_material</translation>
		</message>
	</context>
	<context>
		<name>priority_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de resultados</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_corporate</source>
			<translation>Hacer Corporativo</translation>
		</message>
		<message>
			<source>tooltip_btn_corporate</source>
			<translation>btn_corporate</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplicar</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_edit</source>
			<translation>Editar</translation>
		</message>
		<message>
			<source>tooltip_btn_edit</source>
			<translation>btn_edit</translation>
		</message>
		<message>
			<source>btn_status</source>
			<translation>Cambiar estado</translation>
		</message>
		<message>
			<source>tooltip_btn_status</source>
			<translation>btn_status</translation>
		</message>
		<message>
			<source>dlg_priority_manager</source>
			<translation>Gestor de resultados</translation>
		</message>
		<message>
			<source>tooltip_dlg_priority_manager</source>
			<translation>dlg_priority_manager</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Explotación:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtrar por: Nombre del resultado</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Estado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Tipo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
	</context>
	<context>
		<name>profile</name>
		<message>
			<source>title</source>
			<translation>Dibujar perfil</translation>
		</message>
		<message>
			<source>actionAddPoint</source>
			<translation>actionAddPoint</translation>
		</message>
		<message>
			<source>tooltip_actionAddPoint</source>
			<translation>Add additional point</translation>
		</message>
		<message>
			<source>actionProfile</source>
			<translation>actionProfile</translation>
		</message>
		<message>
			<source>tooltip_actionProfile</source>
			<translation>Set nodes</translation>
		</message>
		<message>
			<source>btn_clear_profile</source>
			<translation>Limpiar perfil</translation>
		</message>
		<message>
			<source>tooltip_btn_clear_profile</source>
			<translation>btn_clear_profile</translation>
		</message>
		<message>
			<source>btn_delete_additional_point</source>
			<translation>btn_delete_additional_point</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_additional_point</source>
			<translation>btn_delete_additional_point</translation>
		</message>
		<message>
			<source>btn_draw_profile</source>
			<translation>Dibujar perfil</translation>
		</message>
		<message>
			<source>tooltip_btn_draw_profile</source>
			<translation>btn_draw_profile</translation>
		</message>
		<message>
			<source>btn_load_profile</source>
			<translation>Cargar perfil</translation>
		</message>
		<message>
			<source>tooltip_btn_load_profile</source>
			<translation>btn_load_profile</translation>
		</message>
		<message>
			<source>btn_save_profile</source>
			<translation>Guardar perfil</translation>
		</message>
		<message>
			<source>tooltip_btn_save_profile</source>
			<translation>btn_save_profile</translation>
		</message>
		<message>
			<source>date</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date</source>
			<translation>date</translation>
		</message>
		<message>
			<source>dlg_profile</source>
			<translation>Dibujar perfil</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile</source>
			<translation>dlg_profile</translation>
		</message>
		<message>
			<source>grb_composer</source>
			<translation>Parámetros</translation>
		</message>
		<message>
			<source>tooltip_grb_composer</source>
			<translation>grb_composer</translation>
		</message>
		<message>
			<source>grb_profile</source>
			<translation>Perfil</translation>
		</message>
		<message>
			<source>tooltip_grb_profile</source>
			<translation>grb_profile</translation>
		</message>
		<message>
			<source>lbl_date</source>
			<translation>Fecha:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date</source>
			<translation>Fecha a mostrar</translation>
		</message>
		<message>
			<source>lbl_min_distance</source>
			<translation>Distancia mínima Vnode:</translation>
		</message>
		<message>
			<source>tooltip_lbl_min_distance</source>
			<translation>Distancia mínima entre vnodes a mostrar</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Título:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>Título del perfil a mostrar</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>Añadir un punto adicional</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>txt_profile_id</source>
			<translation>ID de perfil opcional</translation>
		</message>
		<message>
			<source>tooltip_txt_profile_id</source>
			<translation>ID de perfil opcional</translation>
		</message>
	</context>
	<context>
		<name>profile_interpolation</name>
		<message>
			<source>title</source>
			<translation>Interpolación de perfil</translation>
		</message>
		<message>
			<source>dlg_profile_interpolation</source>
			<translation>Interpolación de perfil</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile_interpolation</source>
			<translation>dlg_profile_interpolation</translation>
		</message>
	</context>
	<context>
		<name>profile_list</name>
		<message>
			<source>title</source>
			<translation>Cargar perfiles</translation>
		</message>
		<message>
			<source>btn_delete_profile</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_profile</source>
			<translation>btn_delete_profile</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Abrir</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_profile_list</source>
			<translation>Cargar perfiles</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile_list</source>
			<translation>dlg_profile_list</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Lista de perfiles</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
	</context>
	<context>
		<name>project_check</name>
		<message>
			<source>title</source>
			<translation>Verificar proyecto</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>dlg_project_check</source>
			<translation>Verificar proyecto</translation>
		</message>
		<message>
			<source>tooltip_dlg_project_check</source>
			<translation>dlg_project_check</translation>
		</message>
		<message>
			<source>tab_databaselog</source>
			<translation>Base de datos log</translation>
		</message>
		<message>
			<source>tooltip_tab_databaselog</source>
			<translation>tab_databaselog</translation>
		</message>
	</context>
	<context>
		<name>psector</name>
		<message>
			<source>title</source>
			<translation>Plan psector</translation>
		</message>
		<message>
			<source>btn_remove</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_remove</source>
			<translation>btn_remove</translation>
		</message>
		<message>
			<source>btn_reports</source>
			<translation>Generar informe</translation>
		</message>
		<message>
			<source>tooltip_btn_reports</source>
			<translation>btn_reports</translation>
		</message>
		<message>
			<source>btn_select</source>
			<translation>Añadir</translation>
		</message>
		<message>
			<source>tooltip_btn_select</source>
			<translation>btn_select</translation>
		</message>
		<message>
			<source>btn_set_geom</source>
			<translation>Fijar geometría</translation>
		</message>
		<message>
			<source>tooltip_btn_set_geom</source>
			<translation>btn_set_geom</translation>
		</message>
		<message>
			<source>dlg_psector</source>
			<translation>Plan psector</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector</source>
			<translation>dlg_psector</translation>
		</message>
		<message>
			<source>gexpenses_label</source>
			<translation>Gastos generales</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label</source>
			<translation>gexpenses_label</translation>
		</message>
		<message>
			<source>gexpenses_label_10</source>
			<translation>Arcos totales:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_10</source>
			<translation>gexpenses_label_10</translation>
		</message>
		<message>
			<source>gexpenses_label_3</source>
			<translation>Nodos totales:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_3</source>
			<translation>gexpenses_label_3</translation>
		</message>
		<message>
			<source>gexpenses_label_4</source>
			<translation>Total otros precios:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_4</source>
			<translation>gexpenses_label_4</translation>
		</message>
		<message>
			<source>gexpenses_label_5</source>
			<translation>Total:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_5</source>
			<translation>gexpenses_label_5</translation>
		</message>
		<message>
			<source>gexpenses_label_6</source>
			<translation>Total:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_6</source>
			<translation>gexpenses_label_6</translation>
		</message>
		<message>
			<source>gexpenses_label_7</source>
			<translation>Total:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_7</source>
			<translation>gexpenses_label_7</translation>
		</message>
		<message>
			<source>gexpenses_label_8</source>
			<translation>Total:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_8</source>
			<translation>gexpenses_label_8</translation>
		</message>
		<message>
			<source>lbl_num_value</source>
			<translation>Valor num:</translation>
		</message>
		<message>
			<source>tooltip_lbl_num_value</source>
			<translation>lbl_num_value</translation>
		</message>
		<message>
			<source>lbl_text3</source>
			<translation>Texto 3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text3</source>
			<translation>lbl_text3</translation>
		</message>
		<message>
			<source>lbl_text4</source>
			<translation>Texto 4:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text4</source>
			<translation>lbl_text4</translation>
		</message>
		<message>
			<source>lbl_text5</source>
			<translation>Texto 5:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text5</source>
			<translation>lbl_text5</translation>
		</message>
		<message>
			<source>lbl_text6</source>
			<translation>Texto 6:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text6</source>
			<translation>lbl_text6</translation>
		</message>
		<message>
			<source>lbl_total</source>
			<translation>Total :</translation>
		</message>
		<message>
			<source>tooltip_lbl_total</source>
			<translation>lbl_total</translation>
		</message>
		<message>
			<source>lbl_total_count</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_lbl_total_count</source>
			<translation>lbl_total_count</translation>
		</message>
		<message>
			<source>other_label</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label</source>
			<translation>other_label</translation>
		</message>
		<message>
			<source>other_label_2</source>
			<translation>Otros gastos</translation>
		</message>
		<message>
			<source>tooltip_other_label_2</source>
			<translation>other_label_2</translation>
		</message>
		<message>
			<source>other_label_3</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_3</source>
			<translation>other_label_3</translation>
		</message>
		<message>
			<source>other_label_4</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_4</source>
			<translation>other_label_4</translation>
		</message>
		<message>
			<source>tab_additional_info</source>
			<translation>Información adicional</translation>
		</message>
		<message>
			<source>tooltip_tab_additional_info</source>
			<translation>tab_additional_info</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_budget</source>
			<translation>Presupuesto</translation>
		</message>
		<message>
			<source>tooltip_tab_budget</source>
			<translation>tab_budget</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Documento</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>tab_document</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>General</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_other_prices</source>
			<translation>Otros precios</translation>
		</message>
		<message>
			<source>tooltip_tab_other_prices</source>
			<translation>tab_other_prices</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relaciones</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
		<message>
			<source>vat_label</source>
			<translation>IVA:</translation>
		</message>
		<message>
			<source>tooltip_vat_label</source>
			<translation>vat_label</translation>
		</message>
	</context>
	<context>
		<name>psector_duplicate</name>
		<message>
			<source>title</source>
			<translation>Duplicar sector</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>dlg_psector_duplicate</source>
			<translation>Duplicar sector</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_duplicate</source>
			<translation>dlg_psector_duplicate</translation>
		</message>
		<message>
			<source>lbl_duplicate_psector</source>
			<translation>Duplicar sector:</translation>
		</message>
		<message>
			<source>tooltip_lbl_duplicate_psector</source>
			<translation>lbl_duplicate_psector</translation>
		</message>
		<message>
			<source>lbl_new_psector</source>
			<translation>Nombre sector nuevo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_psector</source>
			<translation>lbl_new_psector</translation>
		</message>
		<message>
			<source>tab_duplicate_psector</source>
			<translation>Duplicar sector</translation>
		</message>
		<message>
			<source>tooltip_tab_duplicate_psector</source>
			<translation>tab_duplicate_psector</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>psector_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de psector</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplicar</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_merge</source>
			<translation>Fusionar</translation>
		</message>
		<message>
			<source>tooltip_btn_merge</source>
			<translation>Para fusionar varios sectores en uno, tienes que seleccionarlos usando Ctrl y pulsar este botón</translation>
		</message>
		<message>
			<source>btn_restore</source>
			<translation>Restaurar</translation>
		</message>
		<message>
			<source>tooltip_btn_restore</source>
			<translation>btn_restore</translation>
		</message>
		<message>
			<source>btn_show</source>
			<translation>Mostrar</translation>
		</message>
		<message>
			<source>tooltip_btn_show</source>
			<translation>btn_show</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Alternar activo</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>btn_update_psector</source>
			<translation>Alternar actual</translation>
		</message>
		<message>
			<source>tooltip_btn_update_psector</source>
			<translation>btn_update_psector</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Mostrar inactivos</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Mostrar inactivos</translation>
		</message>
		<message>
			<source>chk_archived</source>
			<translation>Mostrar archivados</translation>
		</message>
		<message>
			<source>tooltip_chk_archived</source>
			<translation>chk_archived</translation>
		</message>
		<message>
			<source>chk_filter_canvas</source>
			<translation>Filtrar por mapa</translation>
		</message>
		<message>
			<source>tooltip_chk_filter_canvas</source>
			<translation>Mostrar solo los psector visible en el mapa</translation>
		</message>
		<message>
			<source>dlg_psector_manager</source>
			<translation>Gestor de psector</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_manager</source>
			<translation>dlg_psector_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_psector_name</source>
			<translation>Filtrar por:</translation>
		</message>
		<message>
			<source>tooltip_lbl_psector_name</source>
			<translation>lbl_psector_name</translation>
		</message>
	</context>
	<context>
		<name>psector_rapport</name>
		<message>
			<source>title</source>
			<translation>Generador de informes</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>chk_composer</source>
			<translation>Archivo pdf compositor</translation>
		</message>
		<message>
			<source>tooltip_chk_composer</source>
			<translation>chk_composer</translation>
		</message>
		<message>
			<source>dlg_psector_rapport</source>
			<translation>Generador de informes</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_rapport</source>
			<translation>dlg_psector_rapport</translation>
		</message>
		<message>
			<source>grb_rapport</source>
			<translation>Reporte</translation>
		</message>
		<message>
			<source>tooltip_grb_rapport</source>
			<translation>grb_rapport</translation>
		</message>
		<message>
			<source>lbl_detail_csv</source>
			<translation>Archivo CSV detalle:</translation>
		</message>
		<message>
			<source>tooltip_lbl_detail_csv</source>
			<translation>lbl_detail_csv</translation>
		</message>
		<message>
			<source>lbl_prices_list</source>
			<translation>Archivo CSV lista precios:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prices_list</source>
			<translation>lbl_prices_list</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Modelo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
	</context>
	<context>
		<name>psector_repair</name>
		<message>
			<source>title</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_repair</source>
			<translation>Reparar</translation>
		</message>
		<message>
			<source>tooltip_btn_repair</source>
			<translation>btn_repair</translation>
		</message>
		<message>
			<source>dlg_psector_repair</source>
			<translation>Diálogo</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_repair</source>
			<translation>dlg_psector_repair</translation>
		</message>
	</context>
	<context>
		<name>replace_in_file</name>
		<message>
			<source>title</source>
			<translation>Reemplazar texto en archivo</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_replace_in_file</source>
			<translation>Reemplazar texto en archivo</translation>
		</message>
		<message>
			<source>tooltip_dlg_replace_in_file</source>
			<translation>dlg_replace_in_file</translation>
		</message>
		<message>
			<source>lbl_subtitle</source>
			<translation>Hay objetos con más de 16 caracteres en su nombre</translation>
		</message>
		<message>
			<source>tooltip_lbl_subtitle</source>
			<translation>lbl_subtitle</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Sustituya estos nombres por otros nuevos:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
	</context>
	<context>
		<name>resources_management</name>
		<message>
			<source>btn_assign_team</source>
			<translation>Asignar equipo</translation>
		</message>
		<message>
			<source>tooltip_btn_assign_team</source>
			<translation>btn_assign_team</translation>
		</message>
		<message>
			<source>btn_campaign_save</source>
			<translation>Guardar</translation>
		</message>
		<message>
			<source>tooltip_btn_campaign_save</source>
			<translation>btn_campaign_save</translation>
		</message>
		<message>
			<source>btn_change_team</source>
			<translation>Cambiar equipo</translation>
		</message>
		<message>
			<source>tooltip_btn_change_team</source>
			<translation>btn_change_team</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_remove_team</source>
			<translation>Eliminar equipo</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_team</source>
			<translation>btn_remove_team</translation>
		</message>
		<message>
			<source>btn_team_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_team_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>btn_team_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_team_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>btn_team_toggle_active</source>
			<translation>Alternar activo</translation>
		</message>
		<message>
			<source>tooltip_btn_team_toggle_active</source>
			<translation>btn_team_toggle_active</translation>
		</message>
		<message>
			<source>btn_team_update</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_team_update</source>
			<translation>Modificar</translation>
		</message>
		<message>
			<source>btn_user_toggle_active</source>
			<translation>Alternar activo</translation>
		</message>
		<message>
			<source>tooltip_btn_user_toggle_active</source>
			<translation>btn_user_toggle_active</translation>
		</message>
		<message>
			<source>cmb_team</source>
			<translation>Seleccionar equipo</translation>
		</message>
		<message>
			<source>tooltip_cmb_team</source>
			<translation>cmb_team</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Filtrar por nombre:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Filtrar por organización:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Filtrar por equipo:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>lbl_campaign</source>
			<translation>Campaña:</translation>
		</message>
		<message>
			<source>tooltip_lbl_campaign</source>
			<translation>lbl_campaign</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Usuario:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
		<message>
			<source>resource_management</source>
			<translation>Gestión de recursos</translation>
		</message>
		<message>
			<source>tooltip_resource_management</source>
			<translation>resource_management</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Revisión de campaña</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_organizations</source>
			<translation>Organizaciones</translation>
		</message>
		<message>
			<source>tooltip_tab_organizations</source>
			<translation>tab_organizations</translation>
		</message>
		<message>
			<source>tab_teams</source>
			<translation>Equipos</translation>
		</message>
		<message>
			<source>tooltip_tab_teams</source>
			<translation>tab_teams</translation>
		</message>
		<message>
			<source>tab_users</source>
			<translation>Usuarios</translation>
		</message>
		<message>
			<source>tooltip_tab_users</source>
			<translation>tab_users</translation>
		</message>
	</context>
	<context>
		<name>result_selector</name>
		<message>
			<source>title</source>
			<translation>Selector de resultados</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_result_selector</source>
			<translation>Selector de resultados</translation>
		</message>
		<message>
			<source>tooltip_dlg_result_selector</source>
			<translation>dlg_result_selector</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_descript_compare</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_compare</source>
			<translation>lbl_descript_compare</translation>
		</message>
		<message>
			<source>lbl_result_compare</source>
			<translation>Resultado a comparar:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_compare</source>
			<translation>lbl_result_compare</translation>
		</message>
		<message>
			<source>lbl_result_main</source>
			<translation>Resultado a mostrar:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_main</source>
			<translation>lbl_result_main</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Resultado</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
	</context>
	<context>
		<name>scada_graph</name>
		<message>
			<source>title</source>
			<translation>Gráfico SCADA</translation>
		</message>
		<message>
			<source>dlg_scada_graph</source>
			<translation>Gráfico SCADA</translation>
		</message>
		<message>
			<source>tooltip_dlg_scada_graph</source>
			<translation>dlg_scada_graph</translation>
		</message>
	</context>
	<context>
		<name>search_workcat</name>
		<message>
			<source>title</source>
			<translation>Buscar expdte</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_export_to_csv</source>
			<translation>Exportar a CSV</translation>
		</message>
		<message>
			<source>tooltip_btn_export_to_csv</source>
			<translation>btn_export_to_csv</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_state0</source>
			<translation>Activar</translation>
		</message>
		<message>
			<source>tooltip_btn_state0</source>
			<translation>btn_state0</translation>
		</message>
		<message>
			<source>btn_state1</source>
			<translation>Activar</translation>
		</message>
		<message>
			<source>tooltip_btn_state1</source>
			<translation>btn_state1</translation>
		</message>
		<message>
			<source>dlg_search_workcat</source>
			<translation>Buscar expdte</translation>
		</message>
		<message>
			<source>tooltip_dlg_search_workcat</source>
			<translation>dlg_search_workcat</translation>
		</message>
		<message>
			<source>lbl_destination_path</source>
			<translation>Ruta de destino:</translation>
		</message>
		<message>
			<source>tooltip_lbl_destination_path</source>
			<translation>lbl_destination_path</translation>
		</message>
		<message>
			<source>lbl_end</source>
			<translation>Filtrar por: codigo</translation>
		</message>
		<message>
			<source>tooltip_lbl_end</source>
			<translation>lbl_end</translation>
		</message>
		<message>
			<source>lbl_feat_end</source>
			<translation>Elementos dados de baja</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_end</source>
			<translation>lbl_feat_end</translation>
		</message>
		<message>
			<source>lbl_feat_ini</source>
			<translation>Elementos dados de alta</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_ini</source>
			<translation>lbl_feat_ini</translation>
		</message>
		<message>
			<source>lbl_init</source>
			<translation>Filtrar por: codigo</translation>
		</message>
		<message>
			<source>tooltip_lbl_init</source>
			<translation>lbl_init</translation>
		</message>
		<message>
			<source>lbl_total1</source>
			<translation>Números totales:</translation>
		</message>
		<message>
			<source>tooltip_lbl_total1</source>
			<translation>lbl_total1</translation>
		</message>
		<message>
			<source>lbl_total2</source>
			<translation>Números totales:</translation>
		</message>
		<message>
			<source>tooltip_lbl_total2</source>
			<translation>lbl_total2</translation>
		</message>
		<message>
			<source>tab_doc</source>
			<translation>Documentos</translation>
		</message>
		<message>
			<source>tooltip_tab_doc</source>
			<translation>tab_doc</translation>
		</message>
		<message>
			<source>tab_ended</source>
			<translation>Dado de baja</translation>
		</message>
		<message>
			<source>tooltip_tab_ended</source>
			<translation>tab_ended</translation>
		</message>
		<message>
			<source>tab_init</source>
			<translation>Dado de alta</translation>
		</message>
		<message>
			<source>tooltip_tab_init</source>
			<translation>tab_init</translation>
		</message>
	</context>
	<context>
		<name>selector</name>
		<message>
			<source>title</source>
			<translation>Selector</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_selector</source>
			<translation>Selector</translation>
		</message>
		<message>
			<source>tooltip_dlg_selector</source>
			<translation>dlg_selector</translation>
		</message>
	</context>
	<context>
		<name>selector_date</name>
		<message>
			<source>title</source>
			<translation>Selector de fechas</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>date_from</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date_from</source>
			<translation>date_from</translation>
		</message>
		<message>
			<source>date_to</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date_to</source>
			<translation>date_to</translation>
		</message>
		<message>
			<source>dlg_selector_date</source>
			<translation>Selector de fechas</translation>
		</message>
		<message>
			<source>tooltip_dlg_selector_date</source>
			<translation>dlg_selector_date</translation>
		</message>
		<message>
			<source>lbl_date_from</source>
			<translation>Fecha desde:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_from</source>
			<translation>lbl_date_from</translation>
		</message>
		<message>
			<source>lbl_date_to</source>
			<translation>Fecha hasta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_to</source>
			<translation>lbl_date_to</translation>
		</message>
	</context>
	<context>
		<name>snapshot_view</name>
		<message>
			<source>Audit</source>
			<translation>Auditoría</translation>
		</message>
		<message>
			<source>tooltip_Audit</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Elementos a recuperar</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Funciones a recuperar</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Selección temporal y espacial</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Selección temporal y espacial</translation>
		</message>
	</context>
	<context>
		<name>status_selector</name>
		<message>
			<source>title</source>
			<translation>Selector de estado</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_status_selector</source>
			<translation>Selector de estado</translation>
		</message>
		<message>
			<source>tooltip_dlg_status_selector</source>
			<translation>dlg_status_selector</translation>
		</message>
		<message>
			<source>lbl_new_status</source>
			<translation>Nueva situación:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_status</source>
			<translation>lbl_new_status</translation>
		</message>
		<message>
			<source>lbl_result</source>
			<translation>result_id: nombre_resultado</translation>
		</message>
		<message>
			<source>tooltip_lbl_result</source>
			<translation>lbl_result</translation>
		</message>
		<message>
			<source>lbl_result_main</source>
			<translation>Está cambiando el estado del siguiente resultado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_main</source>
			<translation>lbl_result_main</translation>
		</message>
	</context>
	<context>
		<name>style</name>
		<message>
			<source>title</source>
			<translation>Añadir categoría</translation>
		</message>
		<message>
			<source>btn_add</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_add</source>
			<translation>btn_add</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_style</source>
			<translation>Añadir categoría</translation>
		</message>
		<message>
			<source>tooltip_dlg_style</source>
			<translation>dlg_style</translation>
		</message>
		<message>
			<source>lbl_cat_id</source>
			<translation>Categoría ID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_id</source>
			<translation>lbl_cat_id</translation>
		</message>
		<message>
			<source>lbl_cat_name</source>
			<translation>Nombre de la categoría:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_name</source>
			<translation>lbl_cat_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_role</source>
			<translation>Papel:</translation>
		</message>
		<message>
			<source>tooltip_lbl_role</source>
			<translation>lbl_role</translation>
		</message>
		<message>
			<source>tab_del_feature</source>
			<translation>Datos</translation>
		</message>
		<message>
			<source>tooltip_tab_del_feature</source>
			<translation>tab_del_feature</translation>
		</message>
	</context>
	<context>
		<name>style_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de estilos</translation>
		</message>
		<message>
			<source>btn_add_style</source>
			<translation>Agregar estilo</translation>
		</message>
		<message>
			<source>tooltip_btn_add_style</source>
			<translation>Agregar estilo</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>btn_delete_style</source>
			<translation>Eliminar estilo</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_style</source>
			<translation>btn_delete_style</translation>
		</message>
		<message>
			<source>btn_refresh_all</source>
			<translation>Actualizar todo</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh_all</source>
			<translation>Actualizar todo</translation>
		</message>
		<message>
			<source>btn_update_group</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_update_group</source>
			<translation>Actualizar categoría seleccionada</translation>
		</message>
		<message>
			<source>btn_update_style</source>
			<translation>Actualizar estilo</translation>
		</message>
		<message>
			<source>tooltip_btn_update_style</source>
			<translation>Actualizar estilo</translation>
		</message>
		<message>
			<source>dlg_style_manager</source>
			<translation>Gestor de estilos</translation>
		</message>
		<message>
			<source>tooltip_dlg_style_manager</source>
			<translation>dlg_style_manager</translation>
		</message>
		<message>
			<source>lbl_filter_category</source>
			<translation>Filtrar por: Categoría</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_category</source>
			<translation>lbl_filter_category</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtrar por: Nombre de la capa</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>style_update_category</name>
		<message>
			<source>title</source>
			<translation>Renombrar categoría</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_style_update_category</source>
			<translation>Renombrar categoría</translation>
		</message>
		<message>
			<source>tooltip_dlg_style_update_category</source>
			<translation>dlg_style_update_category</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Por favor, seleccione un nuevo nombre de categoría:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>lbl_rename_copy</translation>
		</message>
	</context>
	<context>
		<name>team_create</name>
		<message>
			<source>title</source>
			<translation>Crear equipo</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>dlg_team_create</source>
			<translation>Crear equipo</translation>
		</message>
		<message>
			<source>tooltip_dlg_team_create</source>
			<translation>dlg_team_create</translation>
		</message>
		<message>
			<source>grb_team</source>
			<translation>Equipo:</translation>
		</message>
		<message>
			<source>tooltip_grb_team</source>
			<translation>grb_team</translation>
		</message>
		<message>
			<source>TeamTab</source>
			<translation>Equipo</translation>
		</message>
		<message>
			<source>tooltip_TeamTab</source>
			<translation>TeamTab</translation>
		</message>
	</context>
	<context>
		<name>team_management</name>
		<message>
			<source>title</source>
			<translation>Gestor de equipos</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_user_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_user_select</source>
			<translation>btn_user_select</translation>
		</message>
		<message>
			<source>btn_user_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_user_unselect</source>
			<translation>btn_user_unselect</translation>
		</message>
		<message>
			<source>btn_vehicle_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_vehicle_select</source>
			<translation>btn_vehicle_select</translation>
		</message>
		<message>
			<source>btn_vehicle_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_vehicle_unselect</source>
			<translation>btn_vehicle_unselect</translation>
		</message>
		<message>
			<source>btn_visitclass_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_visitclass_select</source>
			<translation>btn_visitclass_select</translation>
		</message>
		<message>
			<source>btn_visitclass_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_visitclass_unselect</source>
			<translation>btn_visitclass_unselect</translation>
		</message>
		<message>
			<source>dlg_team_management</source>
			<translation>Gestor de equipos</translation>
		</message>
		<message>
			<source>tooltip_dlg_team_management</source>
			<translation>dlg_team_management</translation>
		</message>
		<message>
			<source>tab_user</source>
			<translation>Usuarios</translation>
		</message>
		<message>
			<source>tooltip_tab_user</source>
			<translation>Usuarios</translation>
		</message>
		<message>
			<source>tab_vehicles</source>
			<translation>Vehículos</translation>
		</message>
		<message>
			<source>tooltip_tab_vehicles</source>
			<translation>Vehículos</translation>
		</message>
		<message>
			<source>tab_visit_class</source>
			<translation>Clase de visita</translation>
		</message>
		<message>
			<source>tooltip_tab_visit_class</source>
			<translation>Clase de visita</translation>
		</message>
	</context>
	<context>
		<name>toolbox</name>
		<message>
			<source>title</source>
			<translation>Caja de herramientas</translation>
		</message>
		<message>
			<source>dlg_toolbox</source>
			<translation>Caja de herramientas</translation>
		</message>
		<message>
			<source>tooltip_dlg_toolbox</source>
			<translation>dlg_toolbox</translation>
		</message>
	</context>
	<context>
		<name>toolbox_reports</name>
		<message>
			<source>title</source>
			<translation>Informes</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_export</source>
			<translation>Exportar</translation>
		</message>
		<message>
			<source>tooltip_btn_export</source>
			<translation>btn_export</translation>
		</message>
		<message>
			<source>btn_export_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_export_path</source>
			<translation>btn_export_path</translation>
		</message>
		<message>
			<source>dlg_toolbox_reports</source>
			<translation>Informes</translation>
		</message>
		<message>
			<source>tooltip_dlg_toolbox_reports</source>
			<translation>dlg_toolbox_reports</translation>
		</message>
		<message>
			<source>grb_filters</source>
			<translation>Filtros</translation>
		</message>
		<message>
			<source>tooltip_grb_filters</source>
			<translation>grb_filters</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Información</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Consulta:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>lbl_export_path</source>
			<translation>Ruta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_path</source>
			<translation>lbl_export_path</translation>
		</message>
	</context>
	<context>
		<name>toolbox_tool</name>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_run</source>
			<translation>Ejecutar</translation>
		</message>
		<message>
			<source>tooltip_btn_run</source>
			<translation>btn_run</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_input_layer</source>
			<translation>Capa de entrada:</translation>
		</message>
		<message>
			<source>tooltip_grb_input_layer</source>
			<translation>grb_input_layer</translation>
		</message>
		<message>
			<source>grb_parameters</source>
			<translation>Parámetros de opción:</translation>
		</message>
		<message>
			<source>tooltip_grb_parameters</source>
			<translation>grb_parameters</translation>
		</message>
		<message>
			<source>grb_selection_type</source>
			<translation>Tipo de selección:</translation>
		</message>
		<message>
			<source>tooltip_grb_selection_type</source>
			<translation>grb_selection_type</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>progressBar</source>
			<translation>%p%</translation>
		</message>
		<message>
			<source>tooltip_progressBar</source>
			<translation>progressBar</translation>
		</message>
		<message>
			<source>rbt_layer</source>
			<translation>Todos los objetos</translation>
		</message>
		<message>
			<source>tooltip_rbt_layer</source>
			<translation>rbt_layer</translation>
		</message>
		<message>
			<source>rbt_previous</source>
			<translation>Solo objetos seleccionados</translation>
		</message>
		<message>
			<source>tooltip_rbt_previous</source>
			<translation>rbt_previous</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configuración</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>visit</name>
		<message>
			<source>title</source>
			<translation>Visita</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Añadir geom</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>btn_add_geom</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_event_delete</source>
			<translation>ELIMINAR EVENTO</translation>
		</message>
		<message>
			<source>tooltip_btn_event_delete</source>
			<translation>btn_event_delete</translation>
		</message>
		<message>
			<source>btn_event_insert</source>
			<translation>INSERTAR EVENTO</translation>
		</message>
		<message>
			<source>tooltip_btn_event_insert</source>
			<translation>btn_event_insert</translation>
		</message>
		<message>
			<source>btn_event_update</source>
			<translation>ACTUALIZAR EVENTO</translation>
		</message>
		<message>
			<source>tooltip_btn_event_update</source>
			<translation>btn_event_update</translation>
		</message>
		<message>
			<source>btn_feature_delete</source>
			<translation>btn_feature_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_delete</source>
			<translation>btn_feature_delete</translation>
		</message>
		<message>
			<source>btn_feature_insert</source>
			<translation>btn_feature_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_insert</source>
			<translation>btn_feature_insert</translation>
		</message>
		<message>
			<source>btn_feature_snapping</source>
			<translation>btn_feature_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_snapping</source>
			<translation>btn_feature_snapping</translation>
		</message>
		<message>
			<source>dlg_visit</source>
			<translation>Visita</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit</source>
			<translation>dlg_visit</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Tipo de objeto:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation>Código:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_end_date</source>
			<translation>Hasta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_date</source>
			<translation>lbl_end_date</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Explotación:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Desde la barra de herramientas sólo se activan los EVENTOS ESTÁNDAR.</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_start_date</source>
			<translation>Desde:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_date</source>
			<translation>lbl_start_date</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Estado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_user_name</source>
			<translation>Nombre de usuario:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user_name</source>
			<translation>lbl_user_name</translation>
		</message>
		<message>
			<source>lbl_visitcat_id</source>
			<translation>Id visita:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visitcat_id</source>
			<translation>lbl_visitcat_id</translation>
		</message>
		<message>
			<source>startdate</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_startdate</source>
			<translation>startdate</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arco</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Connec</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Documento</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>tab_document</translation>
		</message>
		<message>
			<source>tab_event</source>
			<translation>Evento</translation>
		</message>
		<message>
			<source>tooltip_tab_event</source>
			<translation>tab_event</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Sumidero</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Enlace</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nodo</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relaciones</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Visita</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
	</context>
	<context>
		<name>visit_document</name>
		<message>
			<source>title</source>
			<translation>Cargar documentos</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Abrir</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_visit_document</source>
			<translation>Cargar documentos</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_document</source>
			<translation>dlg_visit_document</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Lista de documentos</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Visitar id</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_event</name>
		<message>
			<source>title</source>
			<translation>Evento estándar</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_file</source>
			<translation>Añadir archivo</translation>
		</message>
		<message>
			<source>tooltip_btn_add_file</source>
			<translation>btn_add_file</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_file</source>
			<translation>Eliminar archivo</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_file</source>
			<translation>btn_delete_file</translation>
		</message>
		<message>
			<source>dlg_visit_event</source>
			<translation>Evento estándar</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event</source>
			<translation>dlg_visit_event</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Código_evento:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Archivos:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Parámetro id:      </translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Id posición:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Valor de posición:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Texto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_value</source>
			<translation>Valor:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value</source>
			<translation>lbl_value</translation>
		</message>
	</context>
	<context>
		<name>visit_event_full</name>
		<message>
			<source>title</source>
			<translation>Evento</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_visit_event_full</source>
			<translation>Evento</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event_full</source>
			<translation>dlg_visit_event_full</translation>
		</message>
		<message>
			<source>lbl_compass</source>
			<translation>Brújula:</translation>
		</message>
		<message>
			<source>tooltip_lbl_compass</source>
			<translation>lbl_compass</translation>
		</message>
		<message>
			<source>lbl_event_code</source>
			<translation>Código del evento:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_code</source>
			<translation>lbl_event_code</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Archivos:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_geom1</source>
			<translation>Geom1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom1</source>
			<translation>lbl_geom1</translation>
		</message>
		<message>
			<source>lbl_geom2</source>
			<translation>Geom2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom2</source>
			<translation>lbl_geom2</translation>
		</message>
		<message>
			<source>lbl_geom3</source>
			<translation>Geom3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom3</source>
			<translation>lbl_geom3</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_index_val</source>
			<translation>Trampa de índices:</translation>
		</message>
		<message>
			<source>tooltip_lbl_index_val</source>
			<translation>lbl_index_val</translation>
		</message>
		<message>
			<source>lbl_is_last</source>
			<translation>Is last:</translation>
		</message>
		<message>
			<source>tooltip_lbl_is_last</source>
			<translation>lbl_is_last</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Parámetro id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Id posición:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Valor de posición:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Texto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_tstamp</source>
			<translation>Sello:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tstamp</source>
			<translation>lbl_tstamp</translation>
		</message>
		<message>
			<source>lbl_value</source>
			<translation>Valor:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value</source>
			<translation>lbl_value</translation>
		</message>
		<message>
			<source>lbl_value1</source>
			<translation>Valor1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value1</source>
			<translation>lbl_value1</translation>
		</message>
		<message>
			<source>lbl_value2</source>
			<translation>Valor2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value2</source>
			<translation>lbl_value2</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Visita id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
		<message>
			<source>lbl_xcoord</source>
			<translation>Xcoord:</translation>
		</message>
		<message>
			<source>tooltip_lbl_xcoord</source>
			<translation>lbl_xcoord</translation>
		</message>
		<message>
			<source>lbl_ycoord</source>
			<translation>Ycoord:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ycoord</source>
			<translation>lbl_ycoord</translation>
		</message>
		<message>
			<source>tab_files</source>
			<translation>Archivos</translation>
		</message>
		<message>
			<source>tooltip_tab_files</source>
			<translation>tab_files</translation>
		</message>
		<message>
			<source>tab_info</source>
			<translation>Información</translation>
		</message>
		<message>
			<source>tooltip_tab_info</source>
			<translation>tab_info</translation>
		</message>
	</context>
	<context>
		<name>visit_event_rehab</name>
		<message>
			<source>title</source>
			<translation>Arco de rehabilitación</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_file</source>
			<translation>Añadir archivo</translation>
		</message>
		<message>
			<source>tooltip_btn_add_file</source>
			<translation>btn_add_file</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_file</source>
			<translation>Eliminar archivo</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_file</source>
			<translation>btn_delete_file</translation>
		</message>
		<message>
			<source>dlg_visit_event_rehab</source>
			<translation>Arco de rehabilitación</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event_rehab</source>
			<translation>dlg_visit_event_rehab</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Archivos:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_geom1</source>
			<translation>Geom1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom1</source>
			<translation>lbl_geom1</translation>
		</message>
		<message>
			<source>lbl_geom2</source>
			<translation>Geom2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom2</source>
			<translation>lbl_geom2</translation>
		</message>
		<message>
			<source>lbl_geom3</source>
			<translation>Geom3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom3</source>
			<translation>lbl_geom3</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Parámetro id:      </translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Id posición:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Valor de posición:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Texto:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_value1</source>
			<translation>Valor1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value1</source>
			<translation>lbl_value1</translation>
		</message>
		<message>
			<source>lbl_value2</source>
			<translation>Valor2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value2</source>
			<translation>lbl_value2</translation>
		</message>
	</context>
	<context>
		<name>visit_gallery</name>
		<message>
			<source>title</source>
			<translation>Galería</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_next</source>
			<translation>btn_next</translation>
		</message>
		<message>
			<source>tooltip_btn_next</source>
			<translation>btn_next</translation>
		</message>
		<message>
			<source>btn_previous</source>
			<translation>btn_previous</translation>
		</message>
		<message>
			<source>tooltip_btn_previous</source>
			<translation>btn_previous</translation>
		</message>
		<message>
			<source>dlg_visit_gallery</source>
			<translation>Galería</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_gallery</source>
			<translation>dlg_visit_gallery</translation>
		</message>
		<message>
			<source>lbl_event_id</source>
			<translation>Id de evento:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_id</source>
			<translation>lbl_event_id</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Visita id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_gallery_zoom</name>
		<message>
			<source>title</source>
			<translation>Galería zoom</translation>
		</message>
		<message>
			<source>btn_slideNext</source>
			<translation>btn_slideNext</translation>
		</message>
		<message>
			<source>tooltip_btn_slideNext</source>
			<translation>btn_slideNext</translation>
		</message>
		<message>
			<source>btn_slidePrevious</source>
			<translation>btn_slidePrevious</translation>
		</message>
		<message>
			<source>tooltip_btn_slidePrevious</source>
			<translation>btn_slidePrevious</translation>
		</message>
		<message>
			<source>dlg_visit_gallery_zoom</source>
			<translation>Galería zoom</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_gallery_zoom</source>
			<translation>dlg_visit_gallery_zoom</translation>
		</message>
		<message>
			<source>lbl_event_id</source>
			<translation>Id de evento:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_id</source>
			<translation>lbl_event_id</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Visita id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_manager</name>
		<message>
			<source>title</source>
			<translation>Gestión de visitas</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar visita</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Visita abierta</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>date_event_from</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date_event_from</source>
			<translation>date_event_from</translation>
		</message>
		<message>
			<source>date_event_to</source>
			<translation>dd/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date_event_to</source>
			<translation>date_event_to</translation>
		</message>
		<message>
			<source>dlg_visit_manager</source>
			<translation>Gestión de visitas</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_manager</source>
			<translation>dlg_visit_manager</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>De:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>lbl_data_event_from</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Para:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>lbl_data_event_to</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtrar por código:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
	</context>
	<context>
		<name>workcat_manager</name>
		<message>
			<source>title</source>
			<translation>Gestión de Workcat</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_workcat_manager</source>
			<translation>Gestión de Workcat</translation>
		</message>
		<message>
			<source>tooltip_dlg_workcat_manager</source>
			<translation>dlg_workcat_manager</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtrar por: Nombre del Workcat</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>workorder_management</name>
		<message>
			<source>title</source>
			<translation>Gestión del orden de trabajo</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crear orden de trabajo</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_create_wclass</source>
			<translation>Crear clase</translation>
		</message>
		<message>
			<source>tooltip_btn_create_wclass</source>
			<translation>btn_create_wclass</translation>
		</message>
		<message>
			<source>btn_create_wtype</source>
			<translation>Crear tipo</translation>
		</message>
		<message>
			<source>tooltip_btn_create_wtype</source>
			<translation>btn_create_wtype</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar orden de trabajo</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_workorder_management</source>
			<translation>Gestión del orden de trabajo</translation>
		</message>
		<message>
			<source>tooltip_dlg_workorder_management</source>
			<translation>dlg_workorder_management</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Filtrar por nombre:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_column_filter_dates</source>
			<translation>Tipo de orden de trabajo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter_dates</source>
			<translation>lbl_column_filter_dates</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Clase de orden de trabajo:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
	</context>
	<context>
		<name>workspace_create</name>
		<message>
			<source>title</source>
			<translation>Crear nuevo espacio de trabajo</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aceptar</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancelar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_workspace_create</source>
			<translation>Crear nuevo espacio de trabajo</translation>
		</message>
		<message>
			<source>tooltip_dlg_workspace_create</source>
			<translation>dlg_workspace_create</translation>
		</message>
		<message>
			<source>lbl_new_workspace</source>
			<translation>Nombre:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace</source>
			<translation>Nombre del nuevo espacio de trabajo</translation>
		</message>
		<message>
			<source>lbl_new_workspace_chk</source>
			<translation>Espacio de trabajo privado:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace_chk</source>
			<translation>Nombre del espacio de trabajo</translation>
		</message>
		<message>
			<source>lbl_new_workspace_descript</source>
			<translation>Descripción:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace_descript</source>
			<translation>Descripción del nuevo espacio de trabajo</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Registro</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>Nombre del espacio de trabajo</translation>
		</message>
		<message>
			<source>tab_new_workspace</source>
			<translation>Crear nuevo espacio de trabajo</translation>
		</message>
		<message>
			<source>tooltip_tab_new_workspace</source>
			<translation>Nombre del espacio de trabajo</translation>
		</message>
	</context>
	<context>
		<name>workspace_manager</name>
		<message>
			<source>title</source>
			<translation>Gestor de espacios de trabajo</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cerrar</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Crear</translation>
		</message>
		<message>
			<source>btn_current</source>
			<translation>Establecer actual</translation>
		</message>
		<message>
			<source>tooltip_btn_current</source>
			<translation>Utiliza el espacio de trabajo seleccionado</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Eliminar</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Elimina el espacio de trabajo seleccionado</translation>
		</message>
		<message>
			<source>btn_toggle_privacy</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_privacy</source>
			<translation>Actualizar</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Alternar privacidad</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Alternar privacidad</translation>
		</message>
		<message>
			<source>dlg_workspace_manager</source>
			<translation>Gestor de espacios de trabajo</translation>
		</message>
		<message>
			<source>tooltip_dlg_workspace_manager</source>
			<translation>dlg_workspace_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_workspace_name</source>
			<translation>Filtrar por: Nombre</translation>
		</message>
		<message>
			<source>tooltip_lbl_workspace_name</source>
			<translation>lbl_workspace_name</translation>
		</message>
	</context>
</TS>
