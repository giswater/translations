/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = am, public;
UPDATE config_form_tableview AS t SET alias = v.alias FROM (
	VALUES
	('cat_result', 'budget', 'Presssupost'),
    ('cat_result', 'cur_user', 'Usuari Actual'),
    ('cat_result', 'descript', 'Descr'),
    ('cat_result', 'dnom', 'DNOM'),
    ('cat_result', 'expl_id', 'Id Explotació'),
    ('cat_result', 'features', 'Entitats'),
    ('cat_result', 'iscorporate', 'Corporatiu'),
    ('cat_result', 'material_id', 'Id Material'),
    ('cat_result', 'presszone_id', 'Id Zona Pressió'),
    ('cat_result', 'report', 'Informe'),
    ('cat_result', 'result_id', 'Id Resultat'),
    ('cat_result', 'result_name', 'Nom Resultat'),
    ('cat_result', 'result_type', 'Tipus'),
    ('cat_result', 'status', 'Estat'),
    ('cat_result', 'target_year', 'Any Horitzó'),
    ('cat_result', 'tstamp', 'Pas de temps')
) AS v(objectname, columnname, alias)
WHERE t.objectname = v.objectname AND t.columnname = v.columnname;