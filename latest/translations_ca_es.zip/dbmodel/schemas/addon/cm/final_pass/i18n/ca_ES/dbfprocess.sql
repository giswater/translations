/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = cm, public, public;
UPDATE sys_fprocess AS t SET except_msg = v.except_msg, info_msg = v.info_msg, fprocess_name = v.fprocess_name FROM (
	VALUES
	(100, 'null value on the column %check_column% of %table_name%.', 'The %check_column% on %table_name% have correct values.', 'Check nulls consistence'),
    (200, 'Hi ha alguns usuaris sense equip assignat.', 'Tots els usuaris tenen un equip assignat.', 'Comprovar consistència dels usuaris'),
    (201, 'equips sense usuaris assignats.', 'Tots els equips tenen usuaris assignats.', 'Comprovar consistència dels equips'),
    (202, 'Hi ha alguns nodes òrfans.', 'No hi ha nodes òrfans.', 'Comprovar nodes òrfans'),
    (203, 'nodes duplicats amb estat 1.', 'No hi ha nodes duplicats amb estat 1', 'Comprovar nodes duplicats')
) AS v(fid, except_msg, info_msg, fprocess_name)
WHERE t.fid = v.fid;