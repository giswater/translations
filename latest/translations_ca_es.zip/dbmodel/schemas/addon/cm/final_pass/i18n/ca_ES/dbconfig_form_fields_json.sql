/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = cm, public, public;
UPDATE config_form_fields AS t SET widgetcontrols = v.text::json FROM (
	VALUES
	('active', 'campaign_inventory', 'form_feature', 'tab_data', '{"vdefault_value":"True"}'),
    ('active', 'campaign_review', 'form_feature', 'tab_data', '{"vdefault_value":"True"}'),
    ('active', 'campaign_visit', 'form_feature', 'tab_data', '{"vdefault_value":"True"}'),
    ('txt_info', 'generic', 'check_project_cm', 'tab_data', '{"vdefault_value":"Aquesta funció té com a objectiu passar el control de qualitat d''una campanya, podent escollir de forma concreta un lot específic.<br><br>S''analitzen diferents aspectes sent el més destacat que es configura perquè les dades estiguin operatives en el conjunt d''una campanya perquè el model hidràulic funcioni."}'),
    ('active', 'lot', 'form_feature', 'tab_data', '{"vdefault_value":"True"}')
) AS v(columnname, formname, formtype, tabname, text)
WHERE t.columnname = v.columnname AND t.formname = v.formname AND t.formtype = v.formtype AND t.tabname = v.tabname;