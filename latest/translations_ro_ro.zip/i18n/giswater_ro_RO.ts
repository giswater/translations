<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ro_ro">
<!-- TOOLBARS AND ACTIONS -->
	<context>
		<name>giswater</name>
		<message>
			<source>18_text</source>
			<translation>Conexiune comercială</translation>
		</message>
		<message>
			<source>19_text</source>
			<translation>Instrumente topo</translation>
		</message>
		<message>
			<source>24_text</source>
			<translation>Go2EPA express</translation>
		</message>
		<message>
			<source>301_text</source>
			<translation>Planificator anual</translation>
		</message>
		<message>
			<source>302_text</source>
			<translation>Planificator lunar</translation>
		</message>
		<message>
			<source>303_text</source>
			<translation>Generator de prețuri</translation>
		</message>
		<message>
			<source>304_text</source>
			<translation>Adăugați o vizită</translation>
		</message>
		<message>
			<source>305_text</source>
			<translation>Planificator de unități</translation>
		</message>
		<message>
			<source>309_text</source>
			<translation>Manager de incidente</translation>
		</message>
		<message>
			<source>36_text</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>38_text</source>
			<translation>Costul noii rețele</translation>
		</message>
		<message>
			<source>47_text</source>
			<translation>Selector Psector</translation>
		</message>
		<message>
			<source>74_text</source>
			<translation>Adăugați un lot nou</translation>
		</message>
		<message>
			<source>75_text</source>
			<translation>Manager de lot</translation>
		</message>
		<message>
			<source>76_text</source>
			<translation>Filtru de lot</translation>
		</message>
		<message>
			<source>81_text</source>
			<translation>Psector nou</translation>
		</message>
		<message>
			<source>82_text</source>
			<translation>Manager de sector</translation>
		</message>
		<message>
			<source>98_text</source>
			<translation>Editor de configurare</translation>
		</message>
		<message>
			<source>Actions</source>
			<translation>Acțiuni</translation>
		</message>
		<message>
			<source>Add drain GPKG project</source>
			<translation>Adăugați proiectul GPKG de scurgere</translation>
		</message>
		<message>
			<source>Additional demand check</source>
			<translation>Verificarea cererii suplimentare</translation>
		</message>
		<message>
			<source>Advanced</source>
			<translation>Avansat</translation>
		</message>
		<message>
			<source>AmBreakage</source>
			<translation>Instrument administrativ</translation>
		</message>
		<message>
			<source>AmPriority</source>
			<translation>Selectarea și calcularea priorității</translation>
		</message>
		<message>
			<source>Analytics</source>
			<translation>Analiză</translation>
		</message>
		<message>
			<source>ARC</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>Breakdown Assignation</source>
			<translation>Repartizare Alocarea</translation>
		</message>
		<message>
			<source>Calibration</source>
			<translation>Calibrare</translation>
		</message>
		<message>
			<source>Closest arcs</source>
			<translation>Arcurile cele mai apropiate</translation>
		</message>
		<message>
			<source>CONNEC</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>DRAG-DROP</source>
			<translation>Drag-Drop</translation>
		</message>
		<message>
			<source>Dscenario</source>
			<translation>Dscenario</translation>
		</message>
		<message>
			<source>DWF scenario</source>
			<translation>Scenariul DWF</translation>
		</message>
		<message>
			<source>Emitter calibration</source>
			<translation>Calibrarea emițătorului</translation>
		</message>
		<message>
			<source>EPA multi calls</source>
			<translation>Apeluri multiple EPA</translation>
		</message>
		<message>
			<source>Export</source>
			<translation>Export</translation>
		</message>
		<message>
			<source>Fast print</source>
			<translation>Imprimare rapidă</translation>
		</message>
		<message>
			<source>Forced arcs</source>
			<translation>Arcuri forțate</translation>
		</message>
		<message>
			<source>Forced arcs (selecting only arcs)</source>
			<translation>Arcuri forțate (selectarea numai a arcurilor)</translation>
		</message>
		<message>
			<source>Get help</source>
			<translation>Obțineți ajutor</translation>
		</message>
		<message>
			<source>Go2IBER</source>
			<translation>Go2IBER</translation>
		</message>
		<message>
			<source>GULLY</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>GwAddCampaignButton</source>
			<translation>Adaugă campanie</translation>
		</message>
		<message>
			<source>GwAddChildLayerButton</source>
			<translation>Încărcați stratul Giswater</translation>
		</message>
		<message>
			<source>GwAddLotButton</source>
			<translation>Adaugă lot</translation>
		</message>
		<message>
			<source>GwAmBreakageButton</source>
			<translation>Instrument administrativ</translation>
		</message>
		<message>
			<source>GwAmPriorityButton</source>
			<translation>Selectarea și calcularea priorității</translation>
		</message>
		<message>
			<source>GwArcAddButton</source>
			<translation>Inserție arc</translation>
		</message>
		<message>
			<source>GwArcDivideButton</source>
			<translation>Arc de divizare</translation>
		</message>
		<message>
			<source>GwArcFusionButton</source>
			<translation>Fuziunea arcului</translation>
		</message>
		<message>
			<source>GwAuxCircleAddButton</source>
			<translation>Creați un cerc</translation>
		</message>
		<message>
			<source>GwAuxPointAddButton</source>
			<translation>Creați un punct</translation>
		</message>
		<message>
			<source>GwConfigButton</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>GwConnectLinkButton</source>
			<translation>Conectare la rețea</translation>
		</message>
		<message>
			<source>GwCSVButton</source>
			<translation>Import CSV</translation>
		</message>
		<message>
			<source>GwDateSelectorButton</source>
			<translation>Selector de dată</translation>
		</message>
		<message>
			<source>GwDimensioningButton</source>
			<translation>Dimensionare</translation>
		</message>
		<message>
			<source>GwDocumentButton</source>
			<translation>Adăugați documentul</translation>
		</message>
		<message>
			<source>GwDocumentManagerButton</source>
			<translation>Manager de documente</translation>
		</message>
		<message>
			<source>GwDscenarioManagerButton</source>
			<translation>Dscenario manager</translation>
		</message>
		<message>
			<source>GwElementButton</source>
			<translation>Adăugați un element</translation>
		</message>
		<message>
			<source>GwElementManagerButton</source>
			<translation>Manager de elemente</translation>
		</message>
		<message>
			<source>GwEpaTools</source>
			<translation>Instrumente APE</translation>
		</message>
		<message>
			<source>GwFeatureDeleteButton</source>
			<translation>Ștergeți caracteristica</translation>
		</message>
		<message>
			<source>GwFeatureEndButton</source>
			<translation>Caracteristică finală</translation>
		</message>
		<message>
			<source>GwFeatureReplaceButton</source>
			<translation>Înlocuiți caracteristica</translation>
		</message>
		<message>
			<source>GwFeatureTypeChangeButton</source>
			<translation>Modificarea clasei de caracteristici</translation>
		</message>
		<message>
			<source>GwFlowExitButton</source>
			<translation>Ieșire debit</translation>
		</message>
		<message>
			<source>GwFlowTraceButton</source>
			<translation>Urmărirea debitului</translation>
		</message>
		<message>
			<source>GwGo2EpaButton</source>
			<translation>Go2EPA</translation>
		</message>
		<message>
			<source>GwGo2EpaManagerButton</source>
			<translation>Manager de rezultate APE</translation>
		</message>
		<message>
			<source>GwGo2EpaSelectorButton</source>
			<translation>Selector de rezultate EPA</translation>
		</message>
		<message>
			<source>GwInfoButton</source>
			<translation>Info Giswater</translation>
		</message>
		<message>
			<source>GwLayerStyleChangeButton</source>
			<translation>Stiluri Giswater</translation>
		</message>
		<message>
			<source>GwLotResourceManagementButton</source>
			<translation>Gestionarea resurselor lotului</translation>
		</message>
		<message>
			<source>GwManageCampaignLotButton</source>
			<translation>Gestionați lotul de campanie</translation>
		</message>
		<message>
			<source>GwMincutButton</source>
			<translation>Mincut nou</translation>
		</message>
		<message>
			<source>GwMincutManagerButton</source>
			<translation>Managementul mincut</translation>
		</message>
		<message>
			<source>GwNetscenarioManagerButton</source>
			<translation>Manager Netscenario</translation>
		</message>
		<message>
			<source>GwNonVisualManagerButton</source>
			<translation>Manager de obiecte non-vizuale</translation>
		</message>
		<message>
			<source>GwPointAddButton</source>
			<translation>Inserare punct</translation>
		</message>
		<message>
			<source>GwPriceManagerButton</source>
			<translation>Manager costuri rețea</translation>
		</message>
		<message>
			<source>GwPrintButton</source>
			<translation>Imprimare</translation>
		</message>
		<message>
			<source>GwProfileButton</source>
			<translation>Instrument de profil</translation>
		</message>
		<message>
			<source>GwProjectCheckButton</source>
			<translation>Verificați proiectul</translation>
		</message>
		<message>
			<source>GwPsectorButton</source>
			<translation>Psector nou</translation>
		</message>
		<message>
			<source>GwPsectorManagerButton</source>
			<translation>Manager de sector</translation>
		</message>
		<message>
			<source>GwResultManagerButton</source>
			<translation>Manager de rezultate</translation>
		</message>
		<message>
			<source>GwResultSelectorButton</source>
			<translation>Selector de rezultate</translation>
		</message>
		<message>
			<source>GwSearchButton</source>
			<translation>Căutare plus</translation>
		</message>
		<message>
			<source>GwSelectorButton</source>
			<translation>Selectori</translation>
		</message>
		<message>
			<source>GwSnapshotViewButton</source>
			<translation>Vizualizare instantanee</translation>
		</message>
		<message>
			<source>GwToolBoxButton</source>
			<translation>Cutie de instrumente</translation>
		</message>
		<message>
			<source>GwUtilsManagerButton</source>
			<translation>Manager Utils</translation>
		</message>
		<message>
			<source>GwVisitButton</source>
			<translation>Adăugați o vizită</translation>
		</message>
		<message>
			<source>GwVisitManagerButton</source>
			<translation>Vizitați managerul</translation>
		</message>
		<message>
			<source>GwWorkspaceManagerButton</source>
			<translation>Manager de spațiu de lucru</translation>
		</message>
		<message>
			<source>Hydrology scenario</source>
			<translation>Scenariu hidrologic</translation>
		</message>
		<message>
			<source>Import</source>
			<translation>Import</translation>
		</message>
		<message>
			<source>Import CSV</source>
			<translation>Import CSV</translation>
		</message>
		<message>
			<source>Import INP file</source>
			<translation>Import fișier INP</translation>
		</message>
		<message>
			<source>Manage Campaign</source>
			<translation>Gestionați campania</translation>
		</message>
		<message>
			<source>Manage Campaign</source>
			<translation>Gestionați campania</translation>
		</message>
		<message>
			<source>Manage Lot</source>
			<translation>Gestionați lotul</translation>
		</message>
		<message>
			<source>Manage Lot</source>
			<translation>Gestionați lotul</translation>
		</message>
		<message>
			<source>Manage Workorder</source>
			<translation>Gestionați comanda de lucru</translation>
		</message>
		<message>
			<source>Mapzones manager</source>
			<translation>Mapzones manager</translation>
		</message>
		<message>
			<source>Massive composer</source>
			<translation>Compozitor masiv</translation>
		</message>
		<message>
			<source>menu_name</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>Multi psector print</source>
			<translation>Multi psector print</translation>
		</message>
		<message>
			<source>NODE</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>Open plugin folder</source>
			<translation>Deschideți folderul plugin</translation>
		</message>
		<message>
			<source>Open user folder</source>
			<translation>Deschideți folderul utilizatorului</translation>
		</message>
		<message>
			<source>Priority Calculation (Global)</source>
			<translation>Calcularea priorității (global)</translation>
		</message>
		<message>
			<source>Quantized demands</source>
			<translation>Cereri cuantificate</translation>
		</message>
		<message>
			<source>Reset dialogs</source>
			<translation>Resetarea dialogurilor</translation>
		</message>
		<message>
			<source>Reset plugin</source>
			<translation>Resetare plugin</translation>
		</message>
		<message>
			<source>ResultManager</source>
			<translation>Manager de rezultate</translation>
		</message>
		<message>
			<source>ResultSelector</source>
			<translation>Selector de rezultate</translation>
		</message>
		<message>
			<source>Review</source>
			<translation>Recenzie</translation>
		</message>
		<message>
			<source>SELECT</source>
			<translation>Selectați</translation>
		</message>
		<message>
			<source>Show current selectors</source>
			<translation>Afișați selectorii actuali</translation>
		</message>
		<message>
			<source>Static calibration</source>
			<translation>Calibrare statică</translation>
		</message>
		<message>
			<source>Style manager</source>
			<translation>Manager de stil</translation>
		</message>
		<message>
			<source>Toggle Log DB</source>
			<translation>Toggle Log DB</translation>
		</message>
		<message>
			<source>toolbar_am_name</source>
			<translation>Giswater - Manager de active</translation>
		</message>
		<message>
			<source>toolbar_basic_name</source>
			<translation>Giswater - de bază</translation>
		</message>
		<message>
			<source>toolbar_cm_name</source>
			<translation>Giswater - Manager de campanie</translation>
		</message>
		<message>
			<source>toolbar_custom_name</source>
			<translation>Giswater - Personalizat</translation>
		</message>
		<message>
			<source>toolbar_edit_name</source>
			<translation>Giswater - Editare</translation>
		</message>
		<message>
			<source>toolbar_epa_name</source>
			<translation>Giswater - Epa</translation>
		</message>
		<message>
			<source>toolbar_om_name</source>
			<translation>Giswater - O&amp;M</translation>
		</message>
		<message>
			<source>toolbar_plan_name</source>
			<translation>Giswater - Master plan</translation>
		</message>
		<message>
			<source>toolbar_utilities_name</source>
			<translation>Giswater - Utilități</translation>
		</message>
		<message>
			<source>Valve operation check</source>
			<translation>Verificarea funcționării supapei</translation>
		</message>
		<message>
			<source>Visit</source>
			<translation>Vizită</translation>
		</message>
		<message>
			<source>Workcat manager</source>
			<translation>Manager Workcat</translation>
		</message>
	</context>
<!-- PYTHON MESSAGES -->
	<context>
		<name>giswater</name>
		<message>
			<source></source>
			<translation></translation>
		</message>
		<message>
			<source> </source>
			<translation> </translation>
		</message>
		<message>
			<source>{0}</source>
			<translation>{0}</translation>
		</message>
		<message>
			<source>{0} --&gt; {1}</source>
			<translation>{0} --&gt; {1}</translation>
		</message>
		<message>
			<source>{0}: {1}</source>
			<translation>{0}: {1}</translation>
		</message>
		<message>
			<source>{0} --&gt; {1} --&gt; {2}</source>
			<translation>{0} --&gt; {1} --&gt; {2}</translation>
		</message>
		<message>
			<source>{0} ({1}) - {2} - Updating {3}...</source>
			<translation>{0} ({1}) - {2} - Actualizarea {3}...</translation>
		</message>
		<message>
			<source>{0}: {1} Python function: tools_gw.set_widgets. WHERE columname=&apos;{2}&apos; AND widgetname=&apos;{3}&apos; AND widgettype=&apos;{4}&apos;</source>
			<translation>{0}: {1} Funcție Python: tools_gw.set_widgets. WHERE columname=&apos;{2}&apos; AND widgetname=&apos;{3}&apos; AND widgettype=&apos;{4}&apos;</translation>
		</message>
		<message>
			<source>{0}: {1}. widgetname=&apos;{2}&apos; AND widgettype=&apos;{3}&apos;</source>
			<translation>{0}: {1}. widgetname=&apos;{2}&apos; AND widgettype=&apos;{3}&apos;</translation>
		</message>
		<message>
			<source>{0} campaign(s) deleted.</source>
			<translation>{0} campaign(s) deleted.</translation>
		</message>
		<message>
			<source>{0}: Config file is not set</source>
			<translation>{0}: Fișierul de configurare nu este setat</translation>
		</message>
		<message>
			<source>{0} error {1}</source>
			<translation>{0} eroare {1}</translation>
		</message>
		<message>
			<source>{0} error: {1}</source>
			<translation>{0} eroare: {1}</translation>
		</message>
		<message>
			<source>{0} exception: {1}</source>
			<translation>{0} excepție: {1}</translation>
		</message>
		<message>
			<source>{0} exception [{1}]: {2}</source>
			<translation>{0} excepție [{1}]: {2}</translation>
		</message>
		<message>
			<source>{0} id:</source>
			<translation>{0} id:</translation>
		</message>
		<message>
			<source>{0} is not a table name or {1}</source>
			<translation>{0} nu este un nume de tabel sau {1}</translation>
		</message>
		<message>
			<source>{0} is not defined in table cat_feature</source>
			<translation>{0} nu este definit în tabelul cat_feature</translation>
		</message>
		<message>
			<source>{0} lot(s) deleted.</source>
			<translation>{0} lot(s) deleted.</translation>
		</message>
		<message>
			<source>{0}: project type &apos;{1}&apos; not supported</source>
			<translation>{0}: tipul de proiect &quot;{1}&quot; nu este acceptat</translation>
		</message>
		<message>
			<source>{0}: Reference {1} = &apos;{2}&apos; it is not managed</source>
			<translation>{0}: Referința {1} = &apos;{2}&apos; nu este gestionată</translation>
		</message>
		<message>
			<source>{0} successfully saved.</source>
			<translation>{0} salvat cu succes.</translation>
		</message>
		<message>
			<source>{0} task is already active!</source>
			<translation>{0} sarcina este deja activă!</translation>
		</message>
		<message>
			<source>{0}: widget not found</source>
			<translation>{0}: widget-ul nu a fost găsit</translation>
		</message>
		<message>
			<source>{0} workorder(s) deleted.</source>
			<translation>{0} workorder(s) deleted.</translation>
		</message>
		<message>
			<source>{1}</source>
			<translation>{1}</translation>
		</message>
		<message>
			<source>{2}</source>
			<translation>{2}</translation>
		</message>
		<message>
			<source>Action has no function!!</source>
			<translation>Acțiunea nu are nici o funcție!!</translation>
		</message>
		<message>
			<source>Activate water netowrk snapshot</source>
			<translation>Activați instantaneul rețelei de apă</translation>
		</message>
		<message>
			<source>Adapt schema to cibs</source>
			<translation>Adapt schema to cibs</translation>
		</message>
		<message>
			<source>Add document</source>
			<translation>Adăugați documentul</translation>
		</message>
		<message>
			<source>A diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.</source>
			<translation>O valoare a diametrului este considerată invalidă dacă este zero, negativă, NULL sau mai mare decât diametrul maxim din tabelul de configurare. Ca urmare, acestor conducte NU li se va atribui o valoare de prioritate.</translation>
		</message>
		<message>
			<source>Advanced Menu</source>
			<translation>Meniu avansat</translation>
		</message>
		<message>
			<source>Alert</source>
			<translation>Alertă</translation>
		</message>
		<message>
			<source>All dialogs updated correctly</source>
			<translation>Toate dialogurile actualizate corect</translation>
		</message>
		<message>
			<source>All layers have been successfully refreshed.</source>
			<translation>Toate straturile au fost reîmprospătate cu succes.</translation>
		</message>
		<message>
			<source>All messages updated correctly</source>
			<translation>Toate mesajele sunt actualizate corect</translation>
		</message>
		<message>
			<source>All the values in the column &apos;atlas_id&apos; from the table &apos;plan_psector&apos; have to be INTEGER. This is not the case for your table, please fix this before continuing.</source>
			<translation>Toate valorile din coloana &quot;atlas_id&quot; din tabelul &quot;plan_psector&quot; trebuie să fie INTEGER. Acesta nu este cazul pentru tabelul dvs., vă rugăm să remediați acest lucru înainte de a continua.</translation>
		</message>
		<message>
			<source>A material is considered invalid if it is not listed in the material configuration table.</source>
			<translation>Un material este considerat invalid dacă nu este listat în tabelul de configurare a materialelor.</translation>
		</message>
		<message>
			<source>An arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.</source>
			<translation>Un arccat_id este considerat invalid dacă nu este listat în tabelul de configurare a catalogului. Ca urmare, acestor conducte NU li se va atribui o valoare de prioritate.</translation>
		</message>
		<message>
			<source>An error occurred while adding the style for layer &apos;{0}&apos;:</source>
			<translation>A apărut o eroare în timpul adăugării stilului pentru stratul &apos;{0}&apos;:</translation>
		</message>
		<message>
			<source>A new style has been added to &apos;{0}&apos; for the layer &apos;{1}&apos; using the &apos;GwBasic&apos; style information.</source>
			<translation>Un nou stil a fost adăugat la &quot;{0}&quot; pentru stratul &quot;{1}&quot; folosind informațiile de stil &quot;GwBasic&quot;.</translation>
		</message>
		<message>
			<source>Any connec_id found with this customer_code</source>
			<translation>Orice conec_id găsit cu acest cod_client</translation>
		</message>
		<message>
			<source>Any document selected</source>
			<translation>Orice document selectat</translation>
		</message>
		<message>
			<source>Any record selected</source>
			<translation>Orice înregistrare selectată</translation>
		</message>
		<message>
			<source>Applied styles for context</source>
			<translation>Stiluri aplicate pentru context</translation>
		</message>
		<message>
			<source>Arc fusion</source>
			<translation>Fuziunea arcului</translation>
		</message>
		<message>
			<source>Are you sure to execute vacuum on selected schema?</source>
			<translation>Sunteți sigur că doriți să executați vacuum pe schema selectată?</translation>
		</message>
		<message>
			<source>Are you sure to update the project schema to last version?</source>
			<translation>Sunteți sigur că ați actualizat schema proiectului la ultima versiune?</translation>
		</message>
		<message>
			<source>Are you sure you want delete schema &apos;{0}&apos;?</source>
			<translation>Sunteți sigur că doriți să ștergeți schema &quot;{0}&quot;?</translation>
		</message>
		<message>
			<source>Are you sure you want to cancel these mincuts?</source>
			<translation>Sunteți sigur că doriți să anulați aceste minutaje?</translation>
		</message>
		<message>
			<source>Are you sure you want to continue?</source>
			<translation>Sunteți sigur că doriți să continuați?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} campaign(s)?</source>
			<translation>Are you sure you want to delete {0} campaign(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} lot(s)?</source>
			<translation>Are you sure you want to delete {0} lot(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} workorder(s)?</source>
			<translation>Are you sure you want to delete {0} workorder(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the selected styles?</source>
			<translation>Sunteți sigur că doriți să ștergeți stilurile selectate?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these mincuts?</source>
			<translation>Sunteți sigur că doriți să ștergeți aceste tăieturi?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records:</source>
			<translation>Are you sure you want to delete these records:</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records:</source>
			<translation>Sunteți sigur că doriți să ștergeți aceste înregistrări:</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records?</source>
			<translation>Sunteți sigur că doriți să ștergeți aceste înregistrări?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the style group &apos;{0}&apos;?</source>
			<translation>Sunteți sigur că doriți să ștergeți grupul de stiluri &apos;{0}&apos;?</translation>
		</message>
		<message>
			<source>Are you sure you want to disconnect this elements?</source>
			<translation>Sunteți sigur că doriți să deconectați aceste elemente?</translation>
		</message>
		<message>
			<source>Are you sure you want to override the configuration of this workspace?</source>
			<translation>Sunteți sigur că doriți să suprascrieți configurația acestui spațiu de lucru?</translation>
		</message>
		<message>
			<source>Are you sure you want to overwrite this file?</source>
			<translation>Sunteți sigur că doriți să suprascrieți acest fișier?</translation>
		</message>
		<message>
			<source>ARE YOU SURE YOU WANT TO PROCEED?</source>
			<translation>SUNTEȚI SIGUR CĂ DORIȚI SĂ CONTINUAȚI?</translation>
		</message>
		<message>
			<source>Are you sure you want to replace selected feature with a new one?</source>
			<translation>Sunteți sigur că doriți să înlocuiți caracteristica selectată cu una nouă?</translation>
		</message>
		<message>
			<source>Are you sure you want to update the style of {0} ({1}) with the symbology of the layer in the project? </source>
			<translation>Sunteți sigur că doriți să actualizați stilul lui {0} ({1}) cu simbologia stratului din proiect?</translation>
		</message>
		<message>
			<source>A rollback on schema will be done.</source>
			<translation>Se va efectua un rollback al schemei.</translation>
		</message>
		<message>
			<source>As a result, the material of these pipes will be treated as the configured unknown material, {0}.</source>
			<translation>Ca urmare, materialul acestor conducte va fi tratat ca materialul necunoscut configurat, {0}.</translation>
		</message>
		<message>
			<source>A style already exists for the layer &apos;{0}&apos; in the selected style group.</source>
			<translation>Există deja un stil pentru stratul &quot;{0}&quot; în grupul de stiluri selectat.</translation>
		</message>
		<message>
			<source>Campaign ID not found.</source>
			<translation>ID-ul campaniei nu a fost găsit.</translation>
		</message>
		<message>
			<source>Campaign saved successfully.</source>
			<translation>Campaign saved successfully.</translation>
		</message>
		<message>
			<source>Cancel mincut</source>
			<translation>Cancel mincut</translation>
		</message>
		<message>
			<source>Cancel mincuts</source>
			<translation>Anulează mincuts</translation>
		</message>
		<message>
			<source>Cannot create file, check if its open</source>
			<translation>Nu se poate crea un fișier, verificați dacă acesta este deschis</translation>
		</message>
		<message>
			<source>Cannot create file, check if selected composer is the correct composer</source>
			<translation>Nu se poate crea un fișier, verificați dacă compozitorul selectat este compozitorul corect</translation>
		</message>
		<message>
			<source>Cannot create file, check if selected giswater_advancedtools is the correct giswater_advancedtools</source>
			<translation>Nu se poate crea fișierul, verificați dacă giswater_advancedtools selectat este giswater_advancedtools corect</translation>
		</message>
		<message>
			<source>Cannot set inactive a current scenario. Please update current first.</source>
			<translation>Nu se poate dezactiva un scenariu curent. Vă rugăm să actualizați mai întâi scenariul curent.</translation>
		</message>
		<message>
			<source>Cannot set the current {0} scenario of an inactive scenario. Please activate it first.</source>
			<translation>Nu se poate seta scenariul curent {0} al unui scenariu inactiv. Vă rugăm să-l activați mai întâi.</translation>
		</message>
		<message>
			<source>Cannot set the current netscenario of an inactive scenario. Please activate it first.</source>
			<translation>Nu se poate seta netscenariul curent al unui scenariu inactiv. Vă rugăm să-l activați mai întâi.</translation>
		</message>
		<message>
			<source>Can&apos;t create curve with only one value if flow is 0. Add more values or change the flow value.</source>
			<translation>Nu se poate crea o curbă cu o singură valoare dacă debitul este 0. Adăugați mai multe valori sau modificați valoarea debitului.</translation>
		</message>
		<message>
			<source>Category name cannot be empty.</source>
			<translation>Numele categoriei nu poate fi gol.</translation>
		</message>
		<message>
			<source>Category updated successfully!</source>
			<translation>Categoria a fost actualizată cu succes!</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a dscenario will delete data from features related to the dscenario.</source>
			<translation>ATENȚIE! Ștergerea unui dscenario va șterge datele din caracteristicile legate de dscenario.</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a netscenario will delete data from features related to the netscenario.</source>
			<translation>ATENȚIE! Ștergerea unui netscenariu va șterge datele din caracteristicile legate de netscenariu.</translation>
		</message>
		<message>
			<source>Change epa_type</source>
			<translation>Modificare epa_type</translation>
		</message>
		<message>
			<source>Changes on this page are dangerous and can break Giswater plugin in various ways. </source>
			<translation>Modificările de pe această pagină sunt periculoase și pot afecta pluginul Giswater în diverse moduri.</translation>
		</message>
		<message>
			<source>Check fields from table or view</source>
			<translation>Verificarea câmpurilor din tabel sau vizualizare</translation>
		</message>
		<message>
			<source>Checking any item will not uncheck any other item.</source>
			<translation>Verificarea oricărui element nu va debifa niciun alt element.</translation>
		</message>
		<message>
			<source>Checking any item will uncheck all other items.</source>
			<translation>Dacă bifați orice element, veți debifa toate celelalte elemente.</translation>
		</message>
		<message>
			<source>Checking any item will uncheck all other items unless Shift is pressed.</source>
			<translation>Verificarea oricărui element va debifa toate celelalte elemente, cu excepția cazului în care se apasă Shift.</translation>
		</message>
		<message>
			<source>Choose dscenario</source>
			<translation>Alegeți scenariul</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it. </source>
			<translation>Dacă faceți clic pe un element, acesta va fi bifat/debifat.</translation>
		</message>
		<message>
			<source>Click on 2 places on the map, creating a line, then set the location of a point</source>
			<translation>Faceți clic pe 2 locuri de pe hartă, creând o linie, apoi setați locația unui punct</translation>
		</message>
		<message>
			<source>Click on arcs to select them. Use Alt+click to unselect selected arcs.</source>
			<translation>Faceți clic pe arce pentru a le selecta. Utilizați Alt+clic pentru a deselecta arcele selectate.</translation>
		</message>
		<message>
			<source>Click on disconnected node, move the pointer to the desired location on pipe to break it</source>
			<translation>Faceți clic pe nodul deconectat, mutați indicatorul în locația dorită pe conductă pentru a-l rupe</translation>
		</message>
		<message>
			<source>Click on feature or any place on the map and set radius of a circle</source>
			<translation>Faceți clic pe o caracteristică sau pe orice loc de pe hartă și setați raza unui cerc</translation>
		</message>
		<message>
			<source>Click on node, that joins two pipes, in order to remove it and merge pipes</source>
			<translation>Faceți clic pe nodul care unește două conducte, pentru a-l elimina și a uni conductele</translation>
		</message>
		<message>
			<source>Click on the object to change its class</source>
			<translation>Faceți clic pe obiect pentru a-i schimba clasa</translation>
		</message>
		<message>
			<source>Close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>Column name already exists.</source>
			<translation>Numele coloanei există deja.</translation>
		</message>
		<message>
			<source>Column name and Label fields are mandatory. Please set correct value.</source>
			<translation>Câmpurile Nume coloană și Etichetă sunt obligatorii. Vă rugăm să setați valoarea corectă.</translation>
		</message>
		<message>
			<source>Completed with no exception and no result</source>
			<translation>Completat fără excepție și fără rezultat</translation>
		</message>
		<message>
			<source>Config database file not found</source>
			<translation>Fișierul configurat al bazei de date nu a fost găsit</translation>
		</message>
		<message>
			<source>Config file not found at</source>
			<translation>Fișierul de configurare nu a fost găsit la</translation>
		</message>
		<message>
			<source>Configuration file couldn&apos;t be imported:</source>
			<translation>Fișierul de configurare nu a putut fi importat:</translation>
		</message>
		<message>
			<source>Configuration loaded successfully</source>
			<translation>Configurație încărcată cu succes</translation>
		</message>
		<message>
			<source>Configuration saved to {0}</source>
			<translation>Configurație salvată la {0}</translation>
		</message>
		<message>
			<source>Confirm Deletion</source>
			<translation>Confirmați ștergerea</translation>
		</message>
		<message>
			<source>Connected to {0}</source>
			<translation>Conectat la {0}</translation>
		</message>
		<message>
			<source>Connection Failed. Please, check connection parameters</source>
			<translation>Conexiune eșuată. Vă rugăm, verificați parametrii de conectare</translation>
		</message>
		<message>
			<source>Connect link task is already active!</source>
			<translation>Sarcina Connect link este deja activă!</translation>
		</message>
		<message>
			<source>Context</source>
			<translation>Context</translation>
		</message>
		<message>
			<source>Could not determine event point coordinates</source>
			<translation>Nu s-au putut determina coordonatele punctului evenimentului</translation>
		</message>
		<message>
			<source>Could not find an ID for the style group &apos;{0}&apos;.</source>
			<translation>Nu s-a putut găsi un ID pentru grupul de stiluri &quot;{0}&quot;.</translation>
		</message>
		<message>
			<source>Could not find config_style ID for idval &apos;{0}&apos;.</source>
			<translation>Nu s-a putut găsi ID-ul config_style pentru idval &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Could not find the corresponding ID for the selected style {0}.</source>
			<translation>Nu s-a putut găsi ID-ul corespunzător pentru stilul selectat {0}.</translation>
		</message>
		<message>
			<source>Could not get feature ID from snapped point</source>
			<translation>Nu s-a putut obține ID-ul caracteristicii din punctul fixat</translation>
		</message>
		<message>
			<source>Could not retrieve feature from layer</source>
			<translation>Nu s-a putut extrage caracteristica din strat</translation>
		</message>
		<message>
			<source>Couldn&apos;t draw profile. You may need to select another exploitation.</source>
			<translation>Nu s-a putut desena profilul. Este posibil să trebuiască să selectați o altă exploatare.</translation>
		</message>
		<message>
			<source>Couldn&apos;t import swmm_api package. Try to reload the Giswater plugin. If the issue persists restart QGIS.</source>
			<translation>Nu s-a putut importa pachetul swmm_api. Încercați să reîncărcați pluginul Giswater. Dacă problema persistă, reporniți QGIS.</translation>
		</message>
		<message>
			<source>Create {0} schema</source>
			<translation>Crearea schemei {0}</translation>
		</message>
		<message>
			<source>Create base schema</source>
			<translation>Crearea schemei de bază</translation>
		</message>
		<message>
			<source>Create example</source>
			<translation>Creați un exemplu</translation>
		</message>
		<message>
			<source>Create schema of type &apos;{0}&apos;: &apos;{1}&apos;</source>
			<translation>Crearea schemei de tip &quot;{0}&quot;: &quot;{1}</translation>
		</message>
		<message>
			<source>Creating GIS file... {0}</source>
			<translation>Crearea fișierului GIS... {0}</translation>
		</message>
		<message>
			<source>Creating parser for file: {0}</source>
			<translation>Crearea parserului pentru fișierul: {0}</translation>
		</message>
		<message>
			<source>Creating user config folder</source>
			<translation>Crearea folderului de configurare utilizator</translation>
		</message>
		<message>
			<source>Creating user config folder: {0}</source>
			<translation>Crearea folderului de configurare utilizator: {0}</translation>
		</message>
		<message>
			<source>Credentials will be stored in the GIS project file as plain text, and will apply to both existing and future layers. Do you want to proceed?</source>
			<translation>Legitimațiile vor fi stocate în fișierul proiectului GIS ca text simplu și se vor aplica atât straturilor existente, cât și celor viitoare. Doriți să continuați?</translation>
		</message>
		<message>
			<source>CSV not generated. Check fields from table or view</source>
			<translation>CSV nu este generat. Verificarea câmpurilor din tabel sau vizualizare</translation>
		</message>
		<message>
			<source>Current feature has state &apos;{0}&apos;. Therefore it is not fusionable</source>
			<translation>Caracteristica actuală are starea &quot;{0}&quot;. Prin urmare, aceasta nu poate fi fuzionată</translation>
		</message>
		<message>
			<source>Current feature has state &apos;{0}&apos;. Therefore it is not replaceable</source>
			<translation>Caracteristica actuală are starea &quot;{0}&quot;. Prin urmare, aceasta nu poate fi înlocuită</translation>
		</message>
		<message>
			<source>Current feature is planified. You should activate plan mode to work with it.</source>
			<translation>Caracteristica actuală este planificată. Trebuie să activați modul plan pentru a lucra cu ea.</translation>
		</message>
		<message>
			<source>Current node is not located over an arc. Please, select option &apos;DRAG-DROP&apos;</source>
			<translation>Nodul curent nu este situat deasupra unui arc. Vă rugăm, selectați opțiunea &quot;DRAG-DROP</translation>
		</message>
		<message>
			<source>Current psector</source>
			<translation>Sectorul actual</translation>
		</message>
		<message>
			<source>Current psector: {1}</source>
			<translation>Psector actual: {1}</translation>
		</message>
		<message>
			<source>Database connection error: {0}</source>
			<translation>Eroare de conectare la baza de date: {0}</translation>
		</message>
		<message>
			<source>Database Error</source>
			<translation>Eroare în baza de date</translation>
		</message>
		<message>
			<source>Database execution failed</source>
			<translation>Execuția bazei de date a eșuat</translation>
		</message>
		<message>
			<source>Database name contains special characters that are not supported</source>
			<translation>Numele bazei de date conține caractere speciale care nu sunt acceptate</translation>
		</message>
		<message>
			<source>Database returned null. Check postgres function &apos;{0}&apos;</source>
			<translation>Baza de date a returnat null. Verificați funcția postgres &quot;{0}</translation>
		</message>
		<message>
			<source>Database translation canceled.</source>
			<translation>Traducerea bazei de date a fost anulată.</translation>
		</message>
		<message>
			<source>Database translation failed.</source>
			<translation>Conversia bazei de date a eșuat.</translation>
		</message>
		<message>
			<source>Database translation successful to</source>
			<translation>Traducerea cu succes a bazei de date către</translation>
		</message>
		<message>
			<source>Data insertion completed: {0} successful, {1} errors.</source>
			<translation>Inserarea datelor finalizată: {0} reușit, {1} erori.</translation>
		</message>
		<message>
			<source>Data retrieved and displayed successfully.</source>
			<translation>Datele au fost preluate și afișate cu succes.</translation>
		</message>
		<message>
			<source>Date from:</source>
			<translation>Data de la:</translation>
		</message>
		<message>
			<source>Date of creation</source>
			<translation>Data creării</translation>
		</message>
		<message>
			<source>Date of last update</source>
			<translation>Data ultimei actualizări</translation>
		</message>
		<message>
			<source>Date to:</source>
			<translation>Data până la:</translation>
		</message>
		<message>
			<source>Delete mincut</source>
			<translation>Ștergeți mincut</translation>
		</message>
		<message>
			<source>Delete records</source>
			<translation>Ștergeți înregistrările</translation>
		</message>
		<message>
			<source>Delete records</source>
			<translation>Delete records</translation>
		</message>
		<message>
			<source>Description</source>
			<translation>Descriere</translation>
		</message>
		<message>
			<source>Detail</source>
			<translation>Detaliu</translation>
		</message>
		<message>
			<source>Disconnect elements</source>
			<translation>Elemente de deconectare</translation>
		</message>
		<message>
			<source>Document already exist</source>
			<translation>Documentul există deja</translation>
		</message>
		<message>
			<source>Document already exists</source>
			<translation>Documentul există deja</translation>
		</message>
		<message>
			<source>Document inserted successfully</source>
			<translation>Document introdus cu succes</translation>
		</message>
		<message>
			<source>Document name not found</source>
			<translation>Numele documentului nu a fost găsit</translation>
		</message>
		<message>
			<source>Document PDF created in</source>
			<translation>Document PDF creat în</translation>
		</message>
		<message>
			<source>Documents deleted successfully</source>
			<translation>Documente șterse cu succes</translation>
		</message>
		<message>
			<source>Downloading language files for ({0})...</source>
			<translation>Downloading language files for ({0})...</translation>
		</message>
		<message>
			<source>Do you want change it and continue?</source>
			<translation>Vreți să-l schimbați și să continuați?</translation>
		</message>
		<message>
			<source>Do you want to continue?</source>
			<translation>Do you want to continue?</translation>
		</message>
		<message>
			<source>Do you want to copy its values to the current node?</source>
			<translation>Doriți să copiați valorile sale în nodul curent?</translation>
		</message>
		<message>
			<source>Do you want to insert {0} selected features? (First 50: {1} ...)</source>
			<translation>Doriți să introduceți {0} caracteristici selectate? (Primele 50: {1} ...)</translation>
		</message>
		<message>
			<source>Do you want to insert the selected features?</source>
			<translation>Doriți să introduceți caracteristicile selectate?</translation>
		</message>
		<message>
			<source>Do you want to insert the selected features? {0}</source>
			<translation>Doriți să introduceți elementele selectate? {0}</translation>
		</message>
		<message>
			<source>Do you want to overwrite custom values?</source>
			<translation>Doriți să suprascrieți valorile personalizate?</translation>
		</message>
		<message>
			<source>Do you want to overwrite file?</source>
			<translation>Doriți să suprascrieți fișierul?</translation>
		</message>
		<message>
			<source>Do you want to proceed?</source>
			<translation>Doriți să continuați?</translation>
		</message>
		<message>
			<source>Do you want to set this psector as current?</source>
			<translation>Doriți să setați acest psector ca fiind curent?</translation>
		</message>
		<message>
			<source>Dscenario manager</source>
			<translation>Dscenario manager</translation>
		</message>
		<message>
			<source>DWF scenario manager</source>
			<translation>Manager de scenarii DWF</translation>
		</message>
		<message>
			<source>Empty coordinate list</source>
			<translation>Listă de coordonate goală</translation>
		</message>
		<message>
			<source>Epa2data execution failed. See logs for more details...</source>
			<translation>Execuția Epa2data a eșuat. Consultați jurnalele pentru mai multe detalii...</translation>
		</message>
		<message>
			<source>EPA model finished. </source>
			<translation>Model EPA terminat.</translation>
		</message>
		<message>
			<source>Error</source>
			<translation>Eroare</translation>
		</message>
		<message>
			<source>Error</source>
			<translation>Eroare</translation>
		</message>
		<message>
			<source>Error: &apos;{0}&apos; or &apos;{1}&apos; field is missing in the result.</source>
			<translation>Eroare: câmpul &quot;{0}&quot; sau &quot;{1}&quot; lipsește din rezultat.</translation>
		</message>
		<message>
			<source>Error connecting to i18n dataabse</source>
			<translation>Eroare de conectare la i18n dataabse</translation>
		</message>
		<message>
			<source>Error connecting to i18n database</source>
			<translation>Eroare de conectare la baza de date i18n</translation>
		</message>
		<message>
			<source>Error connecting to origin database</source>
			<translation>Eroare de conectare la baza de date de origine</translation>
		</message>
		<message>
			<source>Error: Could not extract message from line: {0}</source>
			<translation>Eroare: Nu s-a putut extrage mesajul din linia: {0}</translation>
		</message>
		<message>
			<source>Error creating auxiliary connection for vacuum</source>
			<translation>Eroare la crearea conexiunii auxiliare pentru vid</translation>
		</message>
		<message>
			<source>Error creating or updating team</source>
			<translation>Error creating or updating team</translation>
		</message>
		<message>
			<source>Error creating Workcat.</source>
			<translation>Eroare la crearea Workcat.</translation>
		</message>
		<message>
			<source>Error. Database returned null. Check postgres function &apos;{0}&apos;</source>
			<translation>Eroare. Baza de date a returnat null. Verificați funcția postgres &quot;{0}</translation>
		</message>
		<message>
			<source>Error deleting records</source>
			<translation>Eroare la ștergerea înregistrărilor</translation>
		</message>
		<message>
			<source>Error deleting row</source>
			<translation>Eroare la ștergerea rândului</translation>
		</message>
		<message>
			<source>Error deleting row: {0} - Query: {1}</source>
			<translation>Eroare la ștergerea rândului: {0} - Interogare: {1}</translation>
		</message>
		<message>
			<source>Error during point selection: {0}</source>
			<translation>Eroare în timpul selecției punctului: {0}</translation>
		</message>
		<message>
			<source>Error executing gw_fct_create_dscenario_empty</source>
			<translation>Eroare la execuția gw_fct_create_dscenario_empty</translation>
		</message>
		<message>
			<source>Error executing vacuum: {0}</source>
			<translation>Eroare în execuția vidului: {0}</translation>
		</message>
		<message>
			<source>Error fetching existing primary keys</source>
			<translation>Eroare la preluarea cheilor primare existente</translation>
		</message>
		<message>
			<source>Error fetching existing primary keys: {0}</source>
			<translation>Eroare la preluarea cheilor primare existente: {0}</translation>
		</message>
		<message>
			<source>Error finding string</source>
			<translation>Eroare la găsirea șirului</translation>
		</message>
		<message>
			<source>Error fusing arcs</source>
			<translation>Eroare de fuzionare a arcurilor</translation>
		</message>
		<message>
			<source>Error getting current psector</source>
			<translation>Eroare în obținerea psectorului curent</translation>
		</message>
		<message>
			<source>Error getting database parameters</source>
			<translation>Eroare în obținerea parametrilor bazei de date</translation>
		</message>
		<message>
			<source>Error getting exploitation</source>
			<translation>Eroare în obținerea exploatării</translation>
		</message>
		<message>
			<source>Error getting table values: {0}</source>
			<translation>Eroare în obținerea valorilor tabelului: {0}</translation>
		</message>
		<message>
			<source>Error importing IBERGIS project</source>
			<translation>Eroare la importul proiectului IBERGIS</translation>
		</message>
		<message>
			<source>Error inserting row: {0}</source>
			<translation>Eroare la inserarea rândului: {0}</translation>
		</message>
		<message>
			<source>Error near line</source>
			<translation>Eroare lângă linie</translation>
		</message>
		<message>
			<source>Error near line {0} -&gt; {1}</source>
			<translation>Eroare lângă linia {0} -&gt; {1}</translation>
		</message>
		<message>
			<source>Error on create auto mincut, you need to review data</source>
			<translation>Error on create auto mincut, you need to review data</translation>
		</message>
		<message>
			<source>Error parsing file: {0}</source>
			<translation>Eroare la analizarea fișierului: {0}</translation>
		</message>
		<message>
			<source>Error processing muni_id {0}: {1}</source>
			<translation>Eroare în procesarea muni_id {0}: {1}</translation>
		</message>
		<message>
			<source>Error reading configuration file: {0}</source>
			<translation>Eroare la citirea fișierului de configurare: {0}</translation>
		</message>
		<message>
			<source>Error reading file</source>
			<translation>Eroare la citirea fișierului</translation>
		</message>
		<message>
			<source>Error reading file {0}: {1}</source>
			<translation>Eroare la citirea fișierului {0}: {1}</translation>
		</message>
		<message>
			<source>Error replacing feature</source>
			<translation>Funcție de înlocuire a erorilor</translation>
		</message>
		<message>
			<source>Error replacing feature. Chose a valid catalog.</source>
			<translation>Eroare la înlocuirea funcției. Alegeți un catalog valid.</translation>
		</message>
		<message>
			<source>Error saving lot.</source>
			<translation>Error saving lot.</translation>
		</message>
		<message>
			<source>Error saving the configuration</source>
			<translation>Eroare la salvarea configurației</translation>
		</message>
		<message>
			<source>Error type</source>
			<translation>Tip eroare</translation>
		</message>
		<message>
			<source>Error updating element in table, you need to review data</source>
			<translation>Eroare la actualizarea elementului în tabel, trebuie să revizuiți datele</translation>
		</message>
		<message>
			<source>Error updating expl_id: {0}</source>
			<translation>Eroare la actualizarea expl_id: {0}</translation>
		</message>
		<message>
			<source>Error updating messages</source>
			<translation>Mesaje de actualizare a erorilor</translation>
		</message>
		<message>
			<source>Error updating table</source>
			<translation>Eroare la actualizarea tabelului</translation>
		</message>
		<message>
			<source>EXCEPTION</source>
			<translation>EXCEPȚIE</translation>
		</message>
		<message>
			<source>Exception: {0}</source>
			<translation>Excepție: {0}</translation>
		</message>
		<message>
			<source>Exception: {0}.</source>
			<translation>Excepție: {0}.</translation>
		</message>
		<message>
			<source>EXCEPTION: {0}, {1}</source>
			<translation>EXCEPȚIE: {0}, {1}</translation>
		</message>
		<message>
			<source>Exception error: {0}</source>
			<translation>Eroare de excepție: {0}</translation>
		</message>
		<message>
			<source>Exception in {0}</source>
			<translation>Excepție în {0}</translation>
		</message>
		<message>
			<source>Exception in {0} (executing {1} from {2}): {3}</source>
			<translation>Excepție în {0} (executând {1} din {2}): {3}</translation>
		</message>
		<message>
			<source>Exception in info</source>
			<translation>Excepție în informații</translation>
		</message>
		<message>
			<source>Exception in info (def _get_id)</source>
			<translation>Excepție în info (def _get_id)</translation>
		</message>
		<message>
			<source>Exception in unload when {0}</source>
			<translation>Excepție în descărcare când {0}</translation>
		</message>
		<message>
			<source>Exception in unload when deleting {0}</source>
			<translation>Excepție în descărcare la ștergerea {0}</translation>
		</message>
		<message>
			<source>Exception in unload when disconnecting {0} signal</source>
			<translation>Excepție în descărcare la deconectarea semnalului {0}</translation>
		</message>
		<message>
			<source>Exception in unload when reset values for {0}</source>
			<translation>Excepție în descărcare atunci când valorile resetate pentru {0}</translation>
		</message>
		<message>
			<source>Exception in unload when unset signals</source>
			<translation>Excepție în descărcare atunci când semnalele sunt dezactivate</translation>
		</message>
		<message>
			<source>Exception when replacing inp strings</source>
			<translation>Excepție la înlocuirea șirurilor inp</translation>
		</message>
		<message>
			<source>Exception while moving/deleting old user config files</source>
			<translation>Excepție în timpul mutării/ștergerii fișierelor de configurare vechi ale utilizatorului</translation>
		</message>
		<message>
			<source>Execute EPA software</source>
			<translation>Executarea software-ului APE</translation>
		</message>
		<message>
			<source>Execute failed.</source>
			<translation>Executarea a eșuat.</translation>
		</message>
		<message>
			<source>Executing vacuum</source>
			<translation>Executarea vidului</translation>
		</message>
		<message>
			<source>Execution of {0} failed.</source>
			<translation>Executarea lui {0} a eșuat.</translation>
		</message>
		<message>
			<source>Export done succesfully</source>
			<translation>Export efectuat cu succes</translation>
		</message>
		<message>
			<source>Export INP file into PostgreSQL</source>
			<translation>Exportați fișierul INP în PostgreSQL</translation>
		</message>
		<message>
			<source>Export INP finished. </source>
			<translation>Export INP finalizat.</translation>
		</message>
		<message>
			<source>Expression Error</source>
			<translation>Eroare de expresie</translation>
		</message>
		<message>
			<source>FAIL {0}</source>
			<translation>FAIL {0}</translation>
		</message>
		<message>
			<source>Failed to add feature</source>
			<translation>A eșuat adăugarea caracteristicii</translation>
		</message>
		<message>
			<source>Failed to configure layer &apos;{0}&apos;. Skipping...</source>
			<translation>A eșuat configurarea stratului &apos;{0}&apos;. Salt...</translation>
		</message>
		<message>
			<source>Failed to delete records from {0}.</source>
			<translation>Nu s-a reușit ștergerea înregistrărilor din {0}.</translation>
		</message>
		<message>
			<source>Failed to delete style group</source>
			<translation>Eșec la ștergerea grupului de stiluri</translation>
		</message>
		<message>
			<source>Failed to delete styles</source>
			<translation>A eșuat ștergerea stilurilor</translation>
		</message>
		<message>
			<source>Failed to drop database user &apos;{0}&apos;. It may need to be removed manually.</source>
			<translation>A eșuat renunțarea la utilizatorul bazei de date &apos;{0}&apos;. Este posibil să fie necesar să fie eliminat manual.</translation>
		</message>
		<message>
			<source>Failed to execute the mapzones analysis.</source>
			<translation>Nu s-a reușit executarea analizei mapzones.</translation>
		</message>
		<message>
			<source>Failed to fetch dialog configuration</source>
			<translation>A eșuat preluarea configurației dialogului</translation>
		</message>
		<message>
			<source>Failed to fetch dialog configuration</source>
			<translation>Failed to fetch dialog configuration</translation>
		</message>
		<message>
			<source>Failed to get a valid response from gw_fct_config_mapzones.</source>
			<translation>Nu a reușit să obțină un răspuns valid de la gw_fct_config_mapzones.</translation>
		</message>
		<message>
			<source>Failed to load campaign form.</source>
			<translation>Failed to load campaign form.</translation>
		</message>
		<message>
			<source>Failed to load layers</source>
			<translation>A eșuat încărcarea straturilor</translation>
		</message>
		<message>
			<source>Failed to load layers.</source>
			<translation>A eșuat încărcarea straturilor.</translation>
		</message>
		<message>
			<source>Failed to load lot form.</source>
			<translation>Failed to load lot form.</translation>
		</message>
		<message>
			<source>Failed to load workorder form.</source>
			<translation>A eșuat încărcarea formularului de comandă de lucru.</translation>
		</message>
		<message>
			<source>Failed to retrieve GeoJSON data.</source>
			<translation>A eșuat extragerea datelor GeoJSON.</translation>
		</message>
		<message>
			<source>Failed to retrieve sector features.</source>
			<translation>A eșuat extragerea caracteristicilor sectorului.</translation>
		</message>
		<message>
			<source>Failed to retrieve the temporal layer</source>
			<translation>A eșuat recuperarea stratului temporal</translation>
		</message>
		<message>
			<source>Failed to save campaign</source>
			<translation>Failed to save campaign</translation>
		</message>
		<message>
			<source>Failed to set {0} scenario</source>
			<translation>Nu s-a reușit stabilirea scenariului {0}</translation>
		</message>
		<message>
			<source>Failed to set netscenario</source>
			<translation>A eșuat să seteze netscenario</translation>
		</message>
		<message>
			<source>Failed to set ValueRelation for field &apos;{0}&apos;: {1}</source>
			<translation>Failed to set ValueRelation for field &apos;{0}&apos;: {1}</translation>
		</message>
		<message>
			<source>Failed to update category</source>
			<translation>A eșuat actualizarea categoriei</translation>
		</message>
		<message>
			<source>Failed to update styles</source>
			<translation>A eșuat actualizarea stilurilor</translation>
		</message>
		<message>
			<source>Failing data: {0}</source>
			<translation>Date greșite: {0}</translation>
		</message>
		<message>
			<source>Feature added successfully!</source>
			<translation>Funcție adăugată cu succes!</translation>
		</message>
		<message>
			<source>Feature already in the list</source>
			<translation>Funcție deja inclusă în listă</translation>
		</message>
		<message>
			<source>Feature has not been updated because no catalog has been selected</source>
			<translation>Caracteristica nu a fost actualizată deoarece nu a fost selectat niciun catalog</translation>
		</message>
		<message>
			<source>Feature ID and Idval cannot be empty.</source>
			<translation>Feature ID și Idval nu pot fi goale.</translation>
		</message>
		<message>
			<source>Feature_id is mandatory.</source>
			<translation>Feature_id este obligatoriu.</translation>
		</message>
		<message>
			<source>Feature replaced successfully</source>
			<translation>Caracteristică înlocuită cu succes</translation>
		</message>
		<message>
			<source>Field catalog_id required!</source>
			<translation>Câmpul catalog_id este obligatoriu!</translation>
		</message>
		<message>
			<source>Field child_layer of id: </source>
			<translation>Câmpul child_layer de id:</translation>
		</message>
		<message>
			<source>File cannot be created. Check if it is already opened</source>
			<translation>Fișierul nu poate fi creat. Verificați dacă este deja deschis</translation>
		</message>
		<message>
			<source>File extension not valid</source>
			<translation>Extensia fișierului nu este validă</translation>
		</message>
		<message>
			<source>File INP not found</source>
			<translation>Fișierul INP nu a fost găsit</translation>
		</message>
		<message>
			<source>File name</source>
			<translation>Numele fișierului</translation>
		</message>
		<message>
			<source>File name is required</source>
			<translation>Numele fișierului este necesar</translation>
		</message>
		<message>
			<source>File not found</source>
			<translation>Fișierul nu a fost găsit</translation>
		</message>
		<message>
			<source>File not found: {0}</source>
			<translation>Fișierul nu a fost găsit: {0}</translation>
		</message>
		<message>
			<source>File path doesn&apos;t exist or you dont have permission or file is opened</source>
			<translation>Calea fișierului nu există sau nu aveți permisiune sau fișierul este deschis</translation>
		</message>
		<message>
			<source>File path not found</source>
			<translation>Calea fișierului nu a fost găsită</translation>
		</message>
		<message>
			<source>File RPT not found</source>
			<translation>Fișierul RPT nu a fost găsit</translation>
		</message>
		<message>
			<source>Filter by code</source>
			<translation>Filtrați după cod</translation>
		</message>
		<message>
			<source>Filter by ext_code</source>
			<translation>Filtrează după ext_code</translation>
		</message>
		<message>
			<source>First node already selected with id: {0}. Select second one.</source>
			<translation>Primul nod este deja selectat cu id: {0}. Selectați-l pe al doilea.</translation>
		</message>
		<message>
			<source>Flood analysis will start from node ID</source>
			<translation>Analiza inundațiilor va începe de la ID-ul nodului</translation>
		</message>
		<message>
			<source>Folder not found</source>
			<translation>Folderul nu a fost găsit</translation>
		</message>
		<message>
			<source>Folder path</source>
			<translation>Calea dosarului</translation>
		</message>
		<message>
			<source>Force commit</source>
			<translation>Forțați comiterea</translation>
		</message>
		<message>
			<source>From {0}, updating {1}...</source>
			<translation>De la {0}, actualizând {1}...</translation>
		</message>
		<message>
			<source>Function {0} error: {1} from last function is invalid</source>
			<translation>Funcția {0} eroare: {1} din ultima funcție este invalidă</translation>
		</message>
		<message>
			<source>Function {0} error: {1} returned null</source>
			<translation>Funcția {0} eroare: {1} a returnat null</translation>
		</message>
		<message>
			<source>Function {0} error: missing key {1}</source>
			<translation>Eroare funcție {0}: lipsă cheie {1}</translation>
		</message>
		<message>
			<source>Function {0} failed</source>
			<translation>Funcția {0} a eșuat</translation>
		</message>
		<message>
			<source>Function {0} finished successfully</source>
			<translation>Funcția {0} s-a încheiat cu succes</translation>
		</message>
		<message>
			<source>Function {0} returned {1}</source>
			<translation>Funcția {0} a returnat {1}</translation>
		</message>
		<message>
			<source>Function error: {0}</source>
			<translation>Eroare funcțională: {0}</translation>
		</message>
		<message>
			<source>Function failed finished</source>
			<translation>Funcție eșuată finalizată</translation>
		</message>
		<message>
			<source>Function gw_fct_create_dscenario_empty returned no dscenario_id</source>
			<translation>Funcția gw_fct_create_dscenario_empty nu a returnat niciun dscenario_id</translation>
		</message>
		<message>
			<source>Function gw_fct_setfeaturedelete executed with no result </source>
			<translation>Funcția gw_fct_setfeaturedelete executată fără rezultat</translation>
		</message>
		<message>
			<source>Function name</source>
			<translation>Denumirea funcției</translation>
		</message>
		<message>
			<source>Function not found</source>
			<translation>Funcția nu a fost găsită</translation>
		</message>
		<message>
			<source>Function not found in database</source>
			<translation>Funcția nu se găsește în baza de date</translation>
		</message>
		<message>
			<source>Function not found in database: {0}</source>
			<translation>Funcția nu a fost găsită în baza de date: {0}</translation>
		</message>
		<message>
			<source>Generating markdown for {0}.</source>
			<translation>Generarea markdown pentru {0}.</translation>
		</message>
		<message>
			<source>Generating markdown from {0}...</source>
			<translation>Generarea markdown din {0}...</translation>
		</message>
		<message>
			<source>Generation of atlas uses ve_plan_psector as coverage layer ordered by atlas_id column. Please update the atlas&apos; coverage layer before continuing.</source>
			<translation>Generarea atlasului utilizează ve_plan_psector ca strat de acoperire ordonat după coloana atlas_id. Vă rugăm să actualizați stratul de acoperire al atlasului înainte de a continua.</translation>
		</message>
		<message>
			<source>Geometry has been added!</source>
			<translation>Geometria a fost adăugată!</translation>
		</message>
		<message>
			<source>Geometry set correctly.</source>
			<translation>Geometria setată corect.</translation>
		</message>
		<message>
			<source>GIS file generated successfully</source>
			<translation>Fișier GIS generat cu succes</translation>
		</message>
		<message>
			<source>GIS file name not set</source>
			<translation>Numele fișierului GIS nu este setat</translation>
		</message>
		<message>
			<source>GIS folder not set</source>
			<translation>Dosarul GIS nu este setat</translation>
		</message>
		<message>
			<source>Giswater plugin cannot be loaded</source>
			<translation>Plugin-ul Giswater nu poate fi încărcat</translation>
		</message>
		<message>
			<source>GitHub Issues</source>
			<translation>Probleme GitHub</translation>
		</message>
		<message>
			<source>Go2Epa</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>Go2Epa task is already active!</source>
			<translation>Sarcina Go2Epa este deja activă!</translation>
		</message>
		<message>
			<source>Go2Iber task is already active!</source>
			<translation>Sarcina Go2Iber este deja activă!</translation>
		</message>
		<message>
			<source>gw_fct_set_rpt_archived execution failed. See logs for more details...</source>
			<translation>Execuția gw_fct_set_rpt_archived a eșuat. Consultați jurnalele pentru mai multe detalii...</translation>
		</message>
		<message>
			<source>Hemisphere of the node has been updated. Value is</source>
			<translation>Hemisfera nodului a fost actualizată. Valoarea este</translation>
		</message>
		<message>
			<source>Here you can choose how the pumps and valves will be imported, either left as arcs (virual arcs) or converted to nodes.</source>
			<translation>Aici puteți alege modul în care pompele și supapele vor fi importate, fie lăsate ca arcuri (arcuri virale), fie convertite în noduri.</translation>
		</message>
		<message>
			<source>Here you can choose how the pumps, weirs, orifices, and outlets will be imported, either left as arcs (virual arcs) or converted to flwreg.</source>
			<translation>Aici puteți alege modul în care vor fi importate pompele, burlanele, orificiile și ieșirile, fie lăsate ca arce (arce viruale), fie convertite în flwreg.</translation>
		</message>
		<message>
			<source>Hydrology scenario manager</source>
			<translation>Manager de scenarii hidrologice</translation>
		</message>
		<message>
			<source>IBERGIS plugin not found</source>
			<translation>Pluginul IBERGIS nu a fost găsit</translation>
		</message>
		<message>
			<source>IBERGIS project imported successfully</source>
			<translation>Proiect IBERGIS importat cu succes</translation>
		</message>
		<message>
			<source>Id already selected</source>
			<translation>Id deja selectat</translation>
		</message>
		<message>
			<source>If not, you can ignore the tab.</source>
			<translation>Dacă nu, puteți ignora fila.</translation>
		</message>
		<message>
			<source>If you chose to import the flow regulators as flwreg objects, the sixth tab is where you can select the catalog for each flow regulator (pumps, weirs, orifices, outlets) on the network.</source>
			<translation>Dacă ați ales să importați regulatoarele de debit ca obiecte flwreg, fila a șasea este cea în care puteți selecta catalogul pentru fiecare regulator de debit (pompe, burlane, orificii, prize) din rețea.</translation>
		</message>
		<message>
			<source>If you have any questions, please contact the Giswater team via</source>
			<translation>Dacă aveți întrebări, vă rugăm să contactați echipa Giswater prin</translation>
		</message>
		<message>
			<source> If you have different addfields in your feature, they will be deleted.</source>
			<translation> Dacă aveți câmpuri de adăugare diferite în caracteristica dvs., acestea vor fi șterse.</translation>
		</message>
		<message>
			<source>IMPORT INP</source>
			<translation>IMPORT INP</translation>
		</message>
		<message>
			<source>Import INP is only available on Python 3.10 or higher. Please update your QGIS&apos;s Python version.</source>
			<translation>Import INP este disponibil numai pe Python 3.10 sau o versiune superioară. Vă rugăm să vă actualizați versiunea Python a QGIS.</translation>
		</message>
		<message>
			<source>Import INP is still in developement. It may not work as intended yet. Please report any unexpected behaviour to the Giswater team.</source>
			<translation>Import INP este încă în curs de dezvoltare. Este posibil să nu funcționeze încă așa cum se dorește. Vă rugăm să raportați orice comportament neașteptat echipei Giswater.</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis its only for WS projects</source>
			<translation>Importați OSM Streetaxis doar pentru proiectele WS</translation>
		</message>
		<message>
			<source>Import RPT file</source>
			<translation>Importați fișierul RPT</translation>
		</message>
		<message>
			<source>Import rpt file........: {0}</source>
			<translation>Import rpt file........: {0}</translation>
		</message>
		<message>
			<source>Import RPT file finished.</source>
			<translation>Importul fișierului RPT a fost finalizat.</translation>
		</message>
		<message>
			<source>Incompatible version of PostgreSQL</source>
			<translation>Versiune incompatibilă a PostgreSQL</translation>
		</message>
		<message>
			<source>Incorrect languages, make sure to have the giswater project in english</source>
			<translation>Limbi incorecte, asigurați-vă că aveți proiectul giswater în limba engleză</translation>
		</message>
		<message>
			<source>Incorrect user or password</source>
			<translation>Utilizator sau parolă incorectă</translation>
		</message>
		<message>
			<source>Info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>Info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>Info Message</source>
			<translation>Mesaj informativ</translation>
		</message>
		<message>
			<source>Information about exception</source>
			<translation>Informații despre excepție</translation>
		</message>
		<message>
			<source>Initialize plugin</source>
			<translation>Inițializarea pluginului</translation>
		</message>
		<message>
			<source>In order to create a qgis project you have to create a schema first.</source>
			<translation>Pentru a crea un proiect qgis trebuie să creați mai întâi o schemă.</translation>
		</message>
		<message>
			<source>INP file couldn&apos;t be imported:</source>
			<translation>Fișierul INP nu a putut fi importat:</translation>
		</message>
		<message>
			<source>INP file not found</source>
			<translation>Fișierul INP nu a fost găsit</translation>
		</message>
		<message>
			<source>Inp Options</source>
			<translation>Opțiuni Inp</translation>
		</message>
		<message>
			<source>In schema</source>
			<translation>În schemă</translation>
		</message>
		<message>
			<source>Integrate utils requires a WS or UD anchor.</source>
			<translation>Integrate utils requires a WS or UD anchor.</translation>
		</message>
		<message>
			<source>Interpolate tool.</source>
			<translation>Instrument de interpolare.</translation>
		</message>
		<message>
			<source>Invalid {0} &apos;{1}&apos; provided. No configuration performed.</source>
			<translation>Invalid {0} &apos;{1}&apos; furnizat. Nu se efectuează nicio configurare.</translation>
		</message>
		<message>
			<source>Invalid arccat_ids: {0}.</source>
			<translation>Invalid arccat_ids: {0}.</translation>
		</message>
		<message>
			<source>Invalid arccat_ids: {1}.</source>
			<translation>Invalid arccat_ids: {1}.</translation>
		</message>
		<message>
			<source>Invalid buffer value. Please enter an integer less than 1000.</source>
			<translation>Valoare tampon invalidă. Vă rugăm să introduceți un număr întreg mai mic de 1000.</translation>
		</message>
		<message>
			<source>Invalid buffer value. Please enter an valid integer.</source>
			<translation>Valoare tampon invalidă. Vă rugăm să introduceți un număr întreg valid.</translation>
		</message>
		<message>
			<source>Invalid campaign ID.</source>
			<translation>Invalid campaign ID.</translation>
		</message>
		<message>
			<source>Invalid diameters: {1}.</source>
			<translation>Diametre invalide: {1}.</translation>
		</message>
		<message>
			<source>Invalid lot ID.</source>
			<translation>Invalid lot ID.</translation>
		</message>
		<message>
			<source>Invalid materials: {3}.</source>
			<translation>Materiale invalide: {3}.</translation>
		</message>
		<message>
			<source>Invalid value for field</source>
			<translation>Valoare invalidă pentru câmp</translation>
		</message>
		<message>
			<source>Invalid value for scenario_results in [OPTIONS] section.</source>
			<translation>Valoare invalidă pentru scenario_results în secțiunea [OPTIONS].</translation>
		</message>
		<message>
			<source>Invalid WKT string</source>
			<translation>Șir WKT nevalid</translation>
		</message>
		<message>
			<source>Invalid workorder ID.</source>
			<translation>ID-ul comenzii de lucru invalid.</translation>
		</message>
		<message>
			<source>is not defined in table cat_feature</source>
			<translation>nu este definit în tabelul cat_feature</translation>
		</message>
		<message>
			<source>It will then show the log of the process in the last tab.</source>
			<translation>Acesta va afișa apoi jurnalul procesului în ultima filă.</translation>
		</message>
		<message>
			<source>Key</source>
			<translation>Cheie</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE columname=&apos;{0}&apos; AND widgetname=&apos;{1}&apos;</source>
			<translation>cheia &quot;comboIds&quot; sau/și comboNames nu sunt găsite WHERE columname=&apos;{0}&apos; AND widgetname=&apos;{1}&apos;</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE widgetname=&apos;{0}&apos; AND widgettype=&apos;{1}&apos;</source>
			<translation>cheia &quot;comboIds&quot; sau/și comboNames nu sunt găsite WHERE widgetname=&apos;{0}&apos; AND widgettype=&apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Key container</source>
			<translation>Container cheie</translation>
		</message>
		<message>
			<source>Key on returned json from ddbb is missed</source>
			<translation>Cheia de pe jsonul returnat de la ddbb este ratată</translation>
		</message>
		<message>
			<source>Key on returned json from ddbb is missed.</source>
			<translation>Cheia de pe jsonul returnat de la ddbb este ratată.</translation>
		</message>
		<message>
			<source>Language</source>
			<translation>Limba</translation>
		</message>
		<message>
			<source>Layer {0} does not found, therefore, not configured</source>
			<translation>Stratul {0} nu este găsit, prin urmare, nu este configurat</translation>
		</message>
		<message>
			<source>Layer &apos;{0}&apos; not found in QGIS.</source>
			<translation>Stratul &quot;{0}&quot; nu a fost găsit în QGIS.</translation>
		</message>
		<message>
			<source>Layer not found</source>
			<translation>Stratul nu a fost găsit</translation>
		</message>
		<message>
			<source>Layout not found</source>
			<translation>Layout-ul nu a fost găsit</translation>
		</message>
		<message>
			<source>layoutorder not found.</source>
			<translation>layoutorder nu a fost găsit.</translation>
		</message>
		<message>
			<source>LIDS</source>
			<translation>LIDS</translation>
		</message>
		<message>
			<source>Line number</source>
			<translation>Numărul liniei</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please, set a value</source>
			<translation>Lipsește un câmp obligatoriu. Vă rugăm să setați o valoare</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please, set a value for field</source>
			<translation>Lipsește un câmp obligatoriu. Vă rugăm să setați o valoare pentru câmp</translation>
		</message>
		<message>
			<source>Mapzones analysis completed successfully.</source>
			<translation>Analiza Mapzones a fost finalizată cu succes.</translation>
		</message>
		<message>
			<source>Markdown Generated from {0}.</source>
			<translation>Markdown Generat din {0}.</translation>
		</message>
		<message>
			<source>Marked values must be greater than 0</source>
			<translation>Valorile marcate trebuie să fie mai mari decât 0</translation>
		</message>
		<message>
			<source>Merge requires at least 2 psectors to be selected</source>
			<translation>nivele</translation>
		</message>
		<message>
			<source>Message</source>
			<translation>Mesaj</translation>
		</message>
		<message>
			<source>Message error</source>
			<translation>Eroare de mesaj</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict and overlaps with</source>
			<translation>Mincut realizat, dar are conflicte și se suprapune cu</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict and overlaps with other mincuts</source>
			<translation>Mincut done, but has conflict and overlaps with other mincuts</translation>
		</message>
		<message>
			<source>Mincut done successfully</source>
			<translation>Mincut efectuat cu succes</translation>
		</message>
		<message>
			<source>Mincut task is already active!</source>
			<translation>Sarcina Mincut este deja activă!</translation>
		</message>
		<message>
			<source>Missing required fields</source>
			<translation>Lipsa câmpurilor obligatorii</translation>
		</message>
		<message>
			<source>Move node: Error updating geometry</source>
			<translation>Mutare nod: Eroare la actualizarea geometriei</translation>
		</message>
		<message>
			<source>Multilang translations updated ({0}).</source>
			<translation>Multilang translations updated ({0}).</translation>
		</message>
		<message>
			<source>Multiple psectors selected. Please select only one.</source>
			<translation>Au fost selectate mai multe psectoare. Vă rugăm să selectați unul singur.</translation>
		</message>
		<message>
			<source>Municipality with ID: {0} deleted from selection</source>
			<translation>Municipalitatea cu ID: {0} eliminată din selecție</translation>
		</message>
		<message>
			<source>Municipality with id[{0}] is already imported on om_streetaxis.</source>
			<translation>Municipalitatea cu id[{0}] este deja importată pe om_streetaxis.</translation>
		</message>
		<message>
			<source>New feature type is null. Please, select a valid value</source>
			<translation>Noul tip de caracteristică este nul. Vă rugăm, selectați o valoare validă</translation>
		</message>
		<message>
			<source>New feature type is null. Please, select a valid value.</source>
			<translation>Noul tip de caracteristică este nul. Vă rugăm, selectați o valoare validă.</translation>
		</message>
		<message>
			<source>Next</source>
			<translation>Următorul</translation>
		</message>
		<message>
			<source>No action found</source>
			<translation>Nu s-a găsit nicio acțiune</translation>
		</message>
		<message>
			<source>No campaign selected.</source>
			<translation>Nu a fost selectată nicio campanie.</translation>
		</message>
		<message>
			<source>No composers found.</source>
			<translation>Nu s-au găsit compozitori.</translation>
		</message>
		<message>
			<source>No current psector selected</source>
			<translation>Niciun sector curent selectat</translation>
		</message>
		<message>
			<source>Node 1 selected</source>
			<translation>Nodul 1 selectat</translation>
		</message>
		<message>
			<source>Node id:</source>
			<translation>Nod id:</translation>
		</message>
		<message>
			<source>Node psector: {0}</source>
			<translation>Nod psector: {0}</translation>
		</message>
		<message>
			<source>No document selected.</source>
			<translation>Nu a fost selectat niciun document.</translation>
		</message>
		<message>
			<source>No event provided for point selection</source>
			<translation>Nu este prevăzut niciun eveniment pentru selectarea punctelor</translation>
		</message>
		<message>
			<source>No features found in the selection for {0}.</source>
			<translation>No features found in the selection for {0}.</translation>
		</message>
		<message>
			<source>No features found in the selection for the enabled tabs ({0}).</source>
			<translation>No features found in the selection for the enabled tabs ({0}).</translation>
		</message>
		<message>
			<source>NO FEATURE TYPE DEFINED</source>
			<translation>NICIUN TIP DE CARACTERISTICĂ DEFINIT</translation>
		</message>
		<message>
			<source>No help file found</source>
			<translation>Nu a fost găsit niciun fișier de ajutor</translation>
		</message>
		<message>
			<source>No listValues for</source>
			<translation>Nu există listValues pentru</translation>
		</message>
		<message>
			<source>No municipalities selected</source>
			<translation>Nicio municipalitate selectată</translation>
		</message>
		<message>
			<source>No new features to insert. All selected features already exist in the table.</source>
			<translation>No new features to insert. All selected features already exist in the table.</translation>
		</message>
		<message>
			<source>No node ID found at the snapped location.</source>
			<translation>Nu s-a găsit niciun ID de nod la locația fixată.</translation>
		</message>
		<message>
			<source>No pictures for this event.</source>
			<translation>Nu există fotografii pentru acest eveniment.</translation>
		</message>
		<message>
			<source>No primary key value set</source>
			<translation>Nu este setată nicio valoare a cheii primare</translation>
		</message>
		<message>
			<source>No psector selected. Please select at least one.</source>
			<translation>Nu a fost selectat niciun sector. Vă rugăm să selectați cel puțin unul.</translation>
		</message>
		<message>
			<source>No psector values</source>
			<translation>Nu există valori psectoriale</translation>
		</message>
		<message>
			<source>No records selected</source>
			<translation>No records selected</translation>
		</message>
		<message>
			<source>No results</source>
			<translation>Niciun rezultat</translation>
		</message>
		<message>
			<source>No results found. Please check values set on selector of state and exploitation</source>
			<translation>Nu s-au găsit rezultate. Vă rugăm să verificați valorile setate pe selectorul de stat și exploatare</translation>
		</message>
		<message>
			<source>No snapshots available. Please create a snapshot first or wait for tomorrow to travel since today.</source>
			<translation>Nu există instantanee disponibile. Vă rugăm să creați mai întâi un instantaneu sau să așteptați până mâine pentru a călători de astăzi.</translation>
		</message>
		<message>
			<source>Not &apos;{0}&apos;</source>
			<translation>Nu &quot;{0}</translation>
		</message>
		<message>
			<source>Note: You can force the import by activating the variable &apos;{0}&apos; on the {1} file. </source>
			<translation>Notă: Puteți forța importul prin activarea variabilei &quot;{0}&quot; pe fișierul {1}.</translation>
		</message>
		<message>
			<source>Not found: {0}</source>
			<translation>Nu a fost găsit: {0}</translation>
		</message>
		<message>
			<source>No valid data received from the SQL function.</source>
			<translation>Nu s-au primit date valide de la funcția SQL.</translation>
		</message>
		<message>
			<source>No valid psector IDs found</source>
			<translation>Nu s-au găsit ID-uri de sector valide</translation>
		</message>
		<message>
			<source>No valid snapping result. Please select a valid arc.</source>
			<translation>No valid snapping result. Please select a valid arc.</translation>
		</message>
		<message>
			<source>No valid snapping result. Please select a valid point.</source>
			<translation>Niciun rezultat valid. Vă rugăm să selectați un punct valid.</translation>
		</message>
		<message>
			<source>No visit values</source>
			<translation>Nicio valoare a vizitei</translation>
		</message>
		<message>
			<source>No workcat values</source>
			<translation>Nu există valori workcat</translation>
		</message>
		<message>
			<source>Object already associated with this feature</source>
			<translation>Obiect deja asociat cu această caracteristică</translation>
		</message>
		<message>
			<source>Object id not found</source>
			<translation>Id-ul obiectului nu a fost găsit</translation>
		</message>
		<message>
			<source>Once you have configured all the necessary catalogs, you can click on the &apos;Accept&apos; button to start the import process.</source>
			<translation>După ce ați configurat toate cataloagele necesare, puteți face clic pe butonul &quot;Accept&quot; pentru a începe procesul de import.</translation>
		</message>
		<message>
			<source>Only FRELEM can be added to dscenario</source>
			<translation>Numai FRELEM poate fi adăugat la dscenario</translation>
		</message>
		<message>
			<source>Only one record can be selected</source>
			<translation>Poate fi selectată o singură înregistrare</translation>
		</message>
		<message>
			<source>Only rows with values are allowed to be deleted.</source>
			<translation>Numai rândurile cu valori pot fi șterse.</translation>
		</message>
		<message>
			<source>On the other hand you must know that traceability table will storage precedent information.</source>
			<translation>Pe de altă parte, trebuie să știți că tabelul de trasabilitate va stoca informații precedente.</translation>
		</message>
		<message>
			<source>or</source>
			<translation>sau</translation>
		</message>
		<message>
			<source>or they were created by another user:</source>
			<translation>sau au fost create de un alt utilizator:</translation>
		</message>
		<message>
			<source>our website</source>
			<translation>site-ul nostru</translation>
		</message>
		<message>
			<source>Overwrite</source>
			<translation>Suprascriere</translation>
		</message>
		<message>
			<source>Overwrite file</source>
			<translation>Suprascrieți fișierul</translation>
		</message>
		<message>
			<source>Overwrite values</source>
			<translation>Suprascrieți valorile</translation>
		</message>
		<message>
			<source>Parameter &apos;{0}&apos; is None</source>
			<translation>Parametrul &quot;{0}&quot; este Niciunul</translation>
		</message>
		<message>
			<source>Parameter button_function is null for button</source>
			<translation>Parametrul button_function este nul pentru buton</translation>
		</message>
		<message>
			<source>Parameter functionName is null for button</source>
			<translation>Parametrul functionName este nul pentru buton</translation>
		</message>
		<message>
			<source>Parameter functionName is null for check</source>
			<translation>Parametrul functionName este nul pentru verificare</translation>
		</message>
		<message>
			<source>Parameter not found: {parameter}</source>
			<translation>Parametrul nu a fost găsit: {parametru}</translation>
		</message>
		<message>
			<source>Parameter &apos;Query text:&apos; is mandatory for &apos;combo&apos; widgets. Please set value.</source>
			<translation>Parametrul &quot;Query text:&quot; este obligatoriu pentru widget-urile &quot;combo&quot;. Vă rugăm să setați valoarea.</translation>
		</message>
		<message>
			<source>Parameter widgetfunction is null for widget hyperlink</source>
			<translation>Parametrul widgetfunction este nul pentru widget hyperlink</translation>
		</message>
		<message>
			<source>Parameter widgetfunction not found for widget type hyperlink</source>
			<translation>Parametrul widgetfunction nu a fost găsit pentru tipul de widget hyperlink</translation>
		</message>
		<message>
			<source>Parsing error fixed</source>
			<translation>Eroare de parsare corectată</translation>
		</message>
		<message>
			<source>PgRouting version</source>
			<translation>Versiunea PgRouting</translation>
		</message>
		<message>
			<source>pgRouting version is not compatible with Giswater. Please check wiki</source>
			<translation>Versiunea pgRouting nu este compatibilă cu Giswater. Vă rugăm să verificați wiki</translation>
		</message>
		<message>
			<source>Pipes with invalid arccat_ids: {0}.</source>
			<translation>Conducte cu arccat_ids invalide: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid diameters: {0}.</source>
			<translation>Țevi cu diametre invalide: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {0}.qtd</source>
			<translation>Țevi cu materiale invalide: {0}.qtd</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {2}.</source>
			<translation>Țevi cu materiale invalide: {2}.</translation>
		</message>
		<message>
			<source>Pipes with invalid pressures: {0}.</source>
			<translation>Conducte cu presiuni invalide: {0}.</translation>
		</message>
		<message>
			<source>Planified features cannot be replaced</source>
			<translation>Caracteristicile planificate nu pot fi înlocuite</translation>
		</message>
		<message>
			<source>Please choose a csv file</source>
			<translation>Vă rugăm să alegeți un fișier csv</translation>
		</message>
		<message>
			<source>Please choose a valid path</source>
			<translation>Vă rugăm să alegeți o cale validă</translation>
		</message>
		<message>
			<source>Please ensure that features has no undelete value on true.</source>
			<translation>Vă rugăm să vă asigurați că features nu are valoarea undelete pe true.</translation>
		</message>
		<message>
			<source>Please enter a demands dscenario name to proceed with this import.</source>
			<translation>Vă rugăm să introduceți un nume de cerere dscenario pentru a continua cu acest import.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the built date range.</source>
			<translation>Vă rugăm să introduceți un număr întreg valid pentru intervalul de date de construcție.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the cluster length.</source>
			<translation>Vă rugăm să introduceți un număr întreg valid pentru lungimea clusterului.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the maximum distance.</source>
			<translation>Vă rugăm să introduceți un număr întreg valid pentru distanța maximă.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the number of years.</source>
			<translation>Vă rugăm să introduceți un număr întreg valid pentru numărul de ani.</translation>
		</message>
		<message>
			<source>Please enter a valid number for the budget.</source>
			<translation>Vă rugăm să introduceți un număr valid pentru buget.</translation>
		</message>
		<message>
			<source>Please enter a valid target year.</source>
			<translation>Vă rugăm să introduceți un an țintă valid.</translation>
		</message>
		<message>
			<source>Please enter a Workcat_id to proceed with this import.</source>
			<translation>Vă rugăm să introduceți un Workcat_id pentru a continua cu acest import.</translation>
		</message>
		<message>
			<source>Please enter the diameter range in this format: [minimum factor]-[maximum factor]. For example, 0.75-1.5</source>
			<translation>Vă rugăm să introduceți intervalul de diametre în acest format: [factor minim]-[factor maxim]. De exemplu, 0,75-1,5</translation>
		</message>
		<message>
			<source>Please fill link catalog field in the dialog</source>
			<translation>Vă rugăm să completați câmpul catalog link în dialog</translation>
		</message>
		<message>
			<source>Please provide a result name.</source>
			<translation>Vă rugăm să furnizați un nume de rezultat.</translation>
		</message>
		<message>
			<source>Please select a catalog item for all elements in the tabs: Features, Nodes, Arcs, Materials.</source>
			<translation>Vă rugăm să selectați un articol de catalog pentru toate elementele din file: Caracteristici, Noduri, Arce, Materiale.</translation>
		</message>
		<message>
			<source>Please select a catalog item for all elements in the tabs: Nodes, Arcs, Materials, Features.</source>
			<translation>Vă rugăm să selectați un articol de catalog pentru toate elementele din file: Noduri, Arce, Materiale, Caracteristici.</translation>
		</message>
		<message>
			<source>Please select a category to update.</source>
			<translation>Vă rugăm să selectați o categorie pentru actualizare.</translation>
		</message>
		<message>
			<source>Please select a default raingage to proceed with this import.</source>
			<translation>Vă rugăm să selectați un raingaj implicit pentru a continua cu acest import.</translation>
		</message>
		<message>
			<source>Please, select a diferent project name than current.</source>
			<translation>Vă rugăm să selectați un alt nume de proiect decât cel actual.</translation>
		</message>
		<message>
			<source>Please select a feature to add</source>
			<translation>Vă rugăm să selectați o caracteristică de adăugat</translation>
		</message>
		<message>
			<source>Please select a lot to open.</source>
			<translation>Please select a lot to open.</translation>
		</message>
		<message>
			<source>Please select a municipality to proceed with this import.</source>
			<translation>Vă rugăm să selectați o municipalitate pentru a continua cu acest import.</translation>
		</message>
		<message>
			<source>Please select an exploitation to proceed with this import.</source>
			<translation>Vă rugăm să selectați o exploatare pentru a continua cu acest import.</translation>
		</message>
		<message>
			<source>Please, select a project to delete</source>
			<translation>Vă rugăm să selectați un proiect pentru ștergere</translation>
		</message>
		<message>
			<source>Please select a result and an export path.</source>
			<translation>Please select a result and an export path.</translation>
		</message>
		<message>
			<source>Please select a sector to proceed with this import.</source>
			<translation>Vă rugăm să selectați un sector pentru a continua cu acest import.</translation>
		</message>
		<message>
			<source>Please select a style group before adding a new style.</source>
			<translation>Vă rugăm să selectați un grup de stiluri înainte de a adăuga un stil nou.</translation>
		</message>
		<message>
			<source>Please select a style group to delete.</source>
			<translation>Vă rugăm să selectați un grup de stiluri pentru ștergere.</translation>
		</message>
		<message>
			<source>Please select a workorder to open.</source>
			<translation>Vă rugăm să selectați un ordin de lucru pentru deschidere.</translation>
		</message>
		<message>
			<source>Please select one or more styles to delete.</source>
			<translation>Vă rugăm să selectați unul sau mai multe stiluri pentru a le șterge.</translation>
		</message>
		<message>
			<source>Please select one or more styles to update.</source>
			<translation>Vă rugăm să selectați unul sau mai multe stiluri pentru actualizare.</translation>
		</message>
		<message>
			<source>Please select only one result before changing its status.</source>
			<translation>Vă rugăm să selectați un singur rezultat înainte de a-i schimba statutul.</translation>
		</message>
		<message>
			<source>Please select rows to remove from the table</source>
			<translation>Vă rugăm să selectați rândurile pe care doriți să le eliminați din tabel</translation>
		</message>
		<message>
			<source>PostGis version</source>
			<translation>Versiunea PostGis</translation>
		</message>
		<message>
			<source>PostgreSQL version</source>
			<translation>Versiunea PostgreSQL</translation>
		</message>
		<message>
			<source>PostgreSQL version is not compatible with Giswater. Please check wiki</source>
			<translation>Versiunea PostgreSQL nu este compatibilă cu Giswater. Vă rugăm să verificați wiki</translation>
		</message>
		<message>
			<source>prefer</source>
			<translation>preferă</translation>
		</message>
		<message>
			<source>Price list csv file name is required</source>
			<translation>Numele fișierului csv al listei de prețuri este necesar</translation>
		</message>
		<message>
			<source>Price list detail csv file name is required</source>
			<translation>Price list detail csv file name is required</translation>
		</message>
		<message>
			<source>Process completed</source>
			<translation>Proces finalizat</translation>
		</message>
		<message>
			<source>Process finished.</source>
			<translation>Proces finalizat.</translation>
		</message>
		<message>
			<source>Process finished successfully</source>
			<translation>Procesul s-a încheiat cu succes</translation>
		</message>
		<message>
			<source>Process finished successfully: Delete schema</source>
			<translation>Procesul s-a încheiat cu succes: Ștergerea schemei</translation>
		</message>
		<message>
			<source>Process finished with some errors</source>
			<translation>Procesul s-a încheiat cu unele erori</translation>
		</message>
		<message>
			<source>Processing folder</source>
			<translation>Dosar de procesare</translation>
		</message>
		<message>
			<source>Processing muni_id {0}</source>
			<translation>Procesare muni_id {0}</translation>
		</message>
		<message>
			<source>Profile name is mandatory.</source>
			<translation>Numele profilului este obligatoriu.</translation>
		</message>
		<message>
			<source>Project read finished</source>
			<translation>Proiect citit finalizat</translation>
		</message>
		<message>
			<source>Project read finished with different versions on plugin metadata ({0}) and PostgreSQL sys_version table ({1}).</source>
			<translation>Proiectul citit s-a încheiat cu versiuni diferite în metadatele pluginului ({0}) și în tabelul PostgreSQL sys_version ({1}).</translation>
		</message>
		<message>
			<source>Project read started</source>
			<translation>Proiectul citit a început</translation>
		</message>
		<message>
			<source>Psector &apos;{0}&apos; has no workcat_id value set. Do you want to continue with the default value?</source>
			<translation>Sectorul &quot;{0}&quot; nu are setată nicio valoare workcat_id. Doriți să continuați cu valoarea implicită?</translation>
		</message>
		<message>
			<source>Psector could not be updated because of the following errors: </source>
			<translation>Psector could not be updated because of the following errors: </translation>
		</message>
		<message>
			<source>Psector features loaded successfully on the map.</source>
			<translation>Caracteristicile Psector au fost încărcate cu succes pe hartă.</translation>
		</message>
		<message>
			<source>Psector ID not found</source>
			<translation>Psector ID not found</translation>
		</message>
		<message>
			<source>Psector is not archived</source>
			<translation>Psector nu este arhivat</translation>
		</message>
		<message>
			<source>Psector name not found</source>
			<translation>Numele sectorului nu a fost găsit</translation>
		</message>
		<message>
			<source>Psector values updated successfully</source>
			<translation>Valori Psector actualizate cu succes</translation>
		</message>
		<message>
			<source>Python file</source>
			<translation>Fișier Python</translation>
		</message>
		<message>
			<source>Python function</source>
			<translation>Funcția Python</translation>
		</message>
		<message>
			<source>Python translation canceled</source>
			<translation>Traducere Python anulată</translation>
		</message>
		<message>
			<source>Python translation failed</source>
			<translation>Traducerea Python a eșuat</translation>
		</message>
		<message>
			<source>Python translation successful</source>
			<translation>Traducere Python reușită</translation>
		</message>
		<message>
			<source>QGIS project has more than one {0} layer coming from different schemas. If you are looking to manage two schemas, it is mandatory to define which is the master and which isn&apos;t. To do this, you need to configure the QGIS project setting this project&apos;s variables: {1} and {2}.</source>
			<translation>Proiectul QGIS are mai mult de un strat {0} provenind din scheme diferite. Dacă doriți să gestionați două scheme, este obligatoriu să definiți care este master și care nu. Pentru a face acest lucru, trebuie să configurați proiectul QGIS stabilind variabilele acestui proiect: {1} și {2}.</translation>
		</message>
		<message>
			<source>\rDo you want to overwrite it?</source>
			<translation>\rDoriți să o suprascrieți?</translation>
		</message>
		<message>
			<source>Reading file</source>
			<translation>Citirea fișierului</translation>
		</message>
		<message>
			<source>Real location has been updated</source>
			<translation>Locația reală a fost actualizată</translation>
		</message>
		<message>
			<source>Records deleted</source>
			<translation>Înregistrări șterse</translation>
		</message>
		<message>
			<source>Reload failed</source>
			<translation>Reîncărcarea a eșuat</translation>
		</message>
		<message>
			<source>Remove layer from project?</source>
			<translation>Eliminați stratul din proiect?</translation>
		</message>
		<message>
			<source>Replace feature</source>
			<translation>Înlocuiți caracteristica</translation>
		</message>
		<message>
			<source>Replacing template text</source>
			<translation>Înlocuirea textului șablonului</translation>
		</message>
		<message>
			<source>Reports generated successfully</source>
			<translation>Reports generated successfully</translation>
		</message>
		<message>
			<source>Required fields are missing</source>
			<translation>Câmpurile obligatorii lipsesc</translation>
		</message>
		<message>
			<source>Reset position form done successfully.</source>
			<translation>Resetarea formularului de poziție s-a realizat cu succes.</translation>
		</message>
		<message>
			<source>Result name</source>
			<translation>Numele rezultatului</translation>
		</message>
		<message>
			<source>Result name already exists, do you want overwrite?</source>
			<translation>Numele rezultatului există deja, doriți să îl suprascrieți?</translation>
		</message>
		<message>
			<source>Result name not found. It&apos;s not possible to import RPT file into database</source>
			<translation>Numele rezultatului nu a fost găsit. Nu este posibil să importați fișierul RPT în baza de date</translation>
		</message>
		<message>
			<source>Retrieving process ({0}/{1})...</source>
			<translation>Procesul de recuperare ({0}/{1})...</translation>
		</message>
		<message>
			<source>Rpt fail</source>
			<translation>Rpt eșuează</translation>
		</message>
		<message>
			<source>\r(This decision will not cancel the other selections, the process will keep running)</source>
			<translation>\r(Această decizie nu va anula celelalte selecții, procesul va continua să funcționeze)</translation>
		</message>
		<message>
			<source>Schema audit not found, please create it first</source>
			<translation>Schema audit nu a fost găsită, vă rugăm să o creați mai întâi</translation>
		</message>
		<message>
			<source>Schema name</source>
			<translation>Numele schemei</translation>
		</message>
		<message>
			<source>Schema vacuum executed</source>
			<translation>Schema vacuum executată</translation>
		</message>
		<message>
			<source>Select a campaign to delete.</source>
			<translation>Selectați o campanie pentru a o șterge.</translation>
		</message>
		<message>
			<source>Select a workorder to delete.</source>
			<translation>Selectați un ordin de lucru pentru ștergere.</translation>
		</message>
		<message>
			<source>Select connecs or gullies with qgis tool and use right click to connect them with network. CTRL + SHIFT over selection to remove it</source>
			<translation>Selectați conexiunile sau rigolele cu instrumentul qgis și utilizați clic dreapta pentru a le conecta la rețea. CTRL + SHIFT peste selecție pentru a o elimina</translation>
		</message>
		<message>
			<source>Selected {0}</source>
			<translation>Selectat {0}</translation>
		</message>
		<message>
			<source>Selected date interval is not valid</source>
			<translation>Intervalul de date selectat nu este valabil</translation>
		</message>
		<message>
			<source>Selected element already in the list</source>
			<translation>Element selectat deja în listă</translation>
		</message>
		<message>
			<source>Selected hydrometer_id not found</source>
			<translation>Hydrometer_id selectat nu a fost găsit</translation>
		</message>
		<message>
			<source>Selected node</source>
			<translation>Nod selectat</translation>
		</message>
		<message>
			<source>Selected schema not found</source>
			<translation>Schema selectată nu a fost găsită</translation>
		</message>
		<message>
			<source>Selected snapped feature_id to copy values from</source>
			<translation>Id_caracteristică snappată selectată din care se copiază valorile</translation>
		</message>
		<message>
			<source>Selected styles updated successfully!</source>
			<translation>Stiluri selectate actualizate cu succes!</translation>
		</message>
		<message>
			<source>Selected styles were successfully deleted.</source>
			<translation>Stilurile selectate au fost șterse cu succes.</translation>
		</message>
		<message>
			<source>Select INP file</source>
			<translation>Selectați fișierul INP</translation>
		</message>
		<message>
			<source>Select just one document</source>
			<translation>Selectați un singur document</translation>
		</message>
		<message>
			<source>Select just one visit</source>
			<translation>Selectați o singură vizită</translation>
		</message>
		<message>
			<source>Select one</source>
			<translation>Selectați una</translation>
		</message>
		<message>
			<source>Selector help</source>
			<translation>Ajutor selector</translation>
		</message>
		<message>
			<source>Select RPT file</source>
			<translation>Selectați fișierul RPT</translation>
		</message>
		<message>
			<source>Select valid INP file</source>
			<translation>Selectați un fișier INP valid</translation>
		</message>
		<message>
			<source>Select valid RPT file</source>
			<translation>Selectați un fișier RPT valid</translation>
		</message>
		<message>
			<source>SERVER RESPONSE</source>
			<translation>RĂSPUNSUL SERVERULUI</translation>
		</message>
		<message>
			<source>Set rpt archived execution successful.</source>
			<translation>Set rpt archived execuție reușită.</translation>
		</message>
		<message>
			<source>Skipping muni_id {0}: Invalid geometry</source>
			<translation>Ignorarea muni_id {0}: Geometrie invalidă</translation>
		</message>
		<message>
			<source>Snapped feature is not in a valid layer</source>
			<translation>Elementul prins nu se află într-un strat valid</translation>
		</message>
		<message>
			<source>Some data is missing. Check gis_length for arc</source>
			<translation>Unele date lipsesc. Verificați gis_length pentru arc</translation>
		</message>
		<message>
			<source>Some events have documents</source>
			<translation>Unele evenimente au documente</translation>
		</message>
		<message>
			<source>Some mandatory fields are missing. Please fill the required fields (marked in red).</source>
			<translation>Some mandatory fields are missing. Please fill the required fields (marked in red).</translation>
		</message>
		<message>
			<source>Some mandatory values are missing. Please check the widgets marked in red.</source>
			<translation>Some mandatory values are missing. Please check the widgets marked in red.</translation>
		</message>
		<message>
			<source>Some mandatory values are missing. Please check the widgets marked in red.</source>
			<translation>Unele valori obligatorii lipsesc. Vă rugăm să verificați widget-urile marcate cu roșu.</translation>
		</message>
		<message>
			<source>SQL</source>
			<translation>SQL</translation>
		</message>
		<message>
			<source>SQL File</source>
			<translation>Fișiere SQL</translation>
		</message>
		<message>
			<source>SQL folder not found</source>
			<translation>Dosarul SQL nu a fost găsit</translation>
		</message>
		<message>
			<source>Started task &apos;{0}&apos;</source>
			<translation>A început sarcina &quot;{0}</translation>
		</message>
		<message>
			<source>Started task {0}</source>
			<translation>A început sarcina {0}</translation>
		</message>
		<message>
			<source>Starting execute_vacuum method</source>
			<translation>Pornirea metodei execute_vacuum</translation>
		</message>
		<message>
			<source>Starting process...</source>
			<translation>Procesul de pornire...</translation>
		</message>
		<message>
			<source>Style group &apos;{0}&apos; and related entries have been deleted.</source>
			<translation>Grupul de stiluri &quot;{0}&quot; și intrările aferente au fost șterse.</translation>
		</message>
		<message>
			<source>Successful connection to {0} database</source>
			<translation>Conexiune reușită la baza de date {0}</translation>
		</message>
		<message>
			<source>Table not found</source>
			<translation>Tabelul nu a fost găsit</translation>
		</message>
		<message>
			<source>Table not found: &apos;{0}&apos;</source>
			<translation>Tabelul nu a fost găsit: &quot;{0}</translation>
		</message>
		<message>
			<source>Table not found: {0}</source>
			<translation>Tabelul nu a fost găsit: {0}</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; completed</source>
			<translation>Sarcina &quot;{0}&quot; finalizată</translation>
		</message>
		<message>
			<source>Task {0} completed</source>
			<translation>Sarcina {0} finalizată</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; Exception: {1}</source>
			<translation>Sarcina &quot;{0}&quot; Excepție: {1}</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; execute procedure &apos;{1}&apos; with parameters: &apos;{2}&apos;, &apos;{3}&apos;, &apos;{4}&apos;</source>
			<translation>Sarcina &quot;{0}&quot; execută procedura &quot;{1}&quot; cu parametrii: &quot;{2}&quot;, &quot;{3}&quot;, &quot;{4}</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; manage json response with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Sarcina &quot;{0}&quot; gestionează răspunsul json cu parametrii: &quot;{1}&quot;, &quot;{2}&quot;, &quot;{3}</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; not successful but without exception</source>
			<translation>Sarcina &quot;{0}&quot; nu a reușit, dar fără excepție</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; was cancelled</source>
			<translation>Sarcina &quot;{0}&quot; a fost anulată</translation>
		</message>
		<message>
			<source>Task aborted - {0}</source>
			<translation>Sarcină întreruptă - {0}</translation>
		</message>
		<message>
			<source>Task aborted: {0}.</source>
			<translation>Sarcină întreruptă: {0}.</translation>
		</message>
		<message>
			<source>Task canceled - {0}</source>
			<translation>Sarcină anulată - {0}</translation>
		</message>
		<message>
			<source>Task &apos;Check project&apos; execute function &apos;{0}&apos;</source>
			<translation>Sarcina &quot;Verificarea proiectului&quot; execută funcția &quot;{0}</translation>
		</message>
		<message>
			<source>task_completed</source>
			<translation>task_completed</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute function &apos;{0}&apos; from &apos;{1}&apos; with parameters: &apos;{2}&apos;</source>
			<translation>Sarcina &quot;Connect link&quot; execută funcția &quot;{0}&quot; din &quot;{1}&quot; cu parametrii: &quot;{2}</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute function &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;</source>
			<translation>Sarcina &quot;Connect link&quot; execută funcția &quot;{0}&quot; cu parametrii: &quot;{1}&quot;, &quot;{2}</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute procedure &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Sarcina &quot;Connect link&quot; execută procedura &quot;{0}&quot; cu parametrii: &quot;{1}&quot;, &quot;{2}&quot;, &quot;{3}</translation>
		</message>
		<message>
			<source>Task failed: {0}. This is probably a DB error, check postgres function &apos;{1}&apos;.</source>
			<translation>Sarcina a eșuat: {0}. Aceasta este probabil o eroare a bazei de date, verificați funcția postgres &quot;{1}&quot;.</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;{0}&apos;</source>
			<translation>Sarcina &quot;Go2Epa&quot; execută funcția &quot;{0}</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;{0}&apos; from &apos;{1}&apos;</source>
			<translation>Sarcina &quot;Go2Epa&quot; execută funcția &quot;{0}&quot; din &quot;{1}</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;def _exec_import_function&apos;</source>
			<translation>Sarcina &quot;Go2Epa&quot; execută funcția &quot;def _exec_import_function</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{0}&apos; step {1}</source>
			<translation>Sarcina &quot;Go2Epa&quot; execută procedura &quot;{0}&quot; pasul {1}</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{1}&apos; step {2} with parameters: &apos;{1}&apos;, &apos;{3}&apos;, &apos;{4}&apos;, &apos;{5}&apos;, &apos;{6}&apos;</source>
			<translation>Sarcina &quot;Go2Epa&quot; execută procedura &quot;{1}&quot; pasul {2} cu parametrii: &quot;{1}&quot;, &quot;{3}&quot;, &quot;{4}&quot;, &quot;{5}&quot;, &quot;{6}</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; manage json response</source>
			<translation>Sarcina &quot;Go2Epa&quot; gestionează răspunsul json</translation>
		</message>
		<message>
			<source>Task &apos;Mincut execute&apos; execute procedure &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Sarcina &quot;Mincut execute&quot; execută procedura &quot;{0}&quot; cu parametrii: &quot;{1}&quot;, &quot;{2}&quot;, &quot;{3}</translation>
		</message>
		<message>
			<source>Task &apos;Mincut execute&apos; manage json response with parameters: &apos;{0}&apos;, &apos;{1}&apos;, &apos;{2}&apos;</source>
			<translation>Sarcina &quot;Mincut execute&quot; gestionează răspunsul json cu parametrii: &quot;{0}&quot;, &quot;{1}&quot;, &quot;{2}</translation>
		</message>
		<message>
			<source>Template not managed: {0}</source>
			<translation>Șablonul nu este gestionat: {0}</translation>
		</message>
		<message>
			<source>Temporal layer created successfully.</source>
			<translation>Stratul temporal creat cu succes.</translation>
		</message>
		<message>
			<source>The &apos;{0}&apos; field is required.</source>
			<translation>Câmpul &quot;{0}&quot; este obligatoriu.</translation>
		</message>
		<message>
			<source>The configuration file doesn&apos;t match the selected INP file. Some options may not be loaded or may be incorrect. Do you want to continue?</source>
			<translation>Fișierul de configurare nu corespunde cu fișierul INP selectat. Este posibil ca unele opțiuni să nu fie încărcate sau să fie incorecte. Doriți să continuați?</translation>
		</message>
		<message>
			<source>The connection to the database is broken: {0}</source>
			<translation>Conexiunea la baza de date este întreruptă: {0}</translation>
		</message>
		<message>
			<source>The csv file has been successfully exported</source>
			<translation>Fișierul csv a fost exportat cu succes</translation>
		</message>
		<message>
			<source>The &apos;Description&apos; field is required.</source>
			<translation>Câmpul &quot;Descriere&quot; este obligatoriu.</translation>
		</message>
		<message>
			<source>The field layoutname is not configured for</source>
			<translation>Câmpul layoutname nu este configurat pentru</translation>
		</message>
		<message>
			<source>The field layoutorder is not configured for</source>
			<translation>Câmpul layoutorder nu este configurat pentru</translation>
		</message>
		<message>
			<source>The field widgettype is not configured for</source>
			<translation>Widgettype-ul câmpului nu este configurat pentru</translation>
		</message>
		<message>
			<source>The fifth tab is the &apos;Arcs&apos; tab, where you can select the catalog for each type of arc on the network.</source>
			<translation>A cincea filă este fila &quot;Arcuri&quot;, unde puteți selecta catalogul pentru fiecare tip de arc de pe rețea.</translation>
		</message>
		<message>
			<source>The file {0} already exists. Do you want to overwrite it?</source>
			<translation>Fișierul {0} există deja. Doriți să îl suprascrieți?</translation>
		</message>
		<message>
			<source>The files {0} already exist. Do you want to overwrite them?</source>
			<translation>Fișierele {0} există deja. Doriți să le suprascrieți?</translation>
		</message>
		<message>
			<source>The file selected is not a GPKG file</source>
			<translation>Fișierul selectat nu este un fișier GPKG</translation>
		</message>
		<message>
			<source>The file selected is not an INP file</source>
			<translation>Fișierul selectat nu este un fișier INP</translation>
		</message>
		<message>
			<source>The first tab is the &apos;Basic&apos; tab, where you can select the exploitation, sector, municipality, and other basic information.</source>
			<translation>Prima filă este fila &quot;De bază&quot;, unde puteți selecta exploatarea, sectorul, municipalitatea și alte informații de bază.</translation>
		</message>
		<message>
			<source>The following fields differ between the selected arcs. You are about to merge them using the selected values.</source>
			<translation>The following fields differ between the selected arcs. You are about to merge them using the selected values.</translation>
		</message>
		<message>
			<source>The fourth tab is the &apos;Nodes&apos; tab, where you can select the catalog for each type of node on the network.</source>
			<translation>A patra filă este fila &quot;Noduri&quot;, unde puteți selecta catalogul pentru fiecare tip de nod din rețea.</translation>
		</message>
		<message>
			<source>The [JUNCTIONS] section of the configuration file is empty.</source>
			<translation>Secțiunea [JUNCTIONS] din fișierul de configurare este goală.</translation>
		</message>
		<message>
			<source>The name is current in use</source>
			<translation>Numele este utilizat în prezent</translation>
		</message>
		<message>
			<source>The node is obsolete, this tool doesn&apos;t work with obsolete nodes.</source>
			<translation>Nodul este depășit, acest instrument nu funcționează cu noduri depășite.</translation>
		</message>
		<message>
			<source>The procedure will delete features on database unless it is a node that doesn&apos;t divide arcs.</source>
			<translation>Procedura va șterge caracteristicile din baza de date, cu excepția cazului în care este vorba de un nod care nu împarte arce.</translation>
		</message>
		<message>
			<source>The process has been executed. Files generated:</source>
			<translation>Procesul a fost executat. Fișiere generate:</translation>
		</message>
		<message>
			<source>The project name can&apos;t be a PostgreSQL reserved keyword</source>
			<translation>Numele proiectului nu poate fi un cuvânt cheie rezervat PostgreSQL</translation>
		</message>
		<message>
			<source>The project name can&apos;t have any upper-case characters</source>
			<translation>Numele proiectului nu poate avea caractere majuscule</translation>
		</message>
		<message>
			<source>The project name has invalid character</source>
			<translation>Numele proiectului are un caracter invalid</translation>
		</message>
		<message>
			<source>The QGIS Projects templates was correctly created.</source>
			<translation>Șabloanele QGIS Projects au fost create corect.</translation>
		</message>
		<message>
			<source>The QML file is invalid</source>
			<translation>Fișierul QML este invalid</translation>
		</message>
		<message>
			<source>The QML file is invalid.</source>
			<translation>Fișierul QML este invalid.</translation>
		</message>
		<message>
			<source>There are missing values in these nodes:</source>
			<translation>Există valori lipsă în aceste noduri:</translation>
		</message>
		<message>
			<source>There are multiple queries configured. These are the lists that will be used. Do you want to continue?</source>
			<translation>Există mai multe interogări configurate. Acestea sunt listele care vor fi utilizate. Doriți să continuați?</translation>
		</message>
		<message>
			<source>There are multple tabs in order to configure all the necessary catalogs.</source>
			<translation>Există mai multe file pentru a configura toate cataloagele necesare.</translation>
		</message>
		<message>
			<source>There are no results available to display.</source>
			<translation>Nu există rezultate disponibile pentru afișare.</translation>
		</message>
		<message>
			<source>There are no visible mincuts in the table. Try a different filter or make one</source>
			<translation>În tabel nu există tăieturi minime vizibile. Încercați un filtru diferit sau creați unul</translation>
		</message>
		<message>
			<source>There have been errors translating:</source>
			<translation>Au existat erori de traducere:</translation>
		</message>
		<message>
			<source>There is an error in the configuration of the pgservice file, please check it or consult your administrator</source>
			<translation>Există o eroare în configurarea fișierului pgservice, vă rugăm să o verificați sau să consultați administratorul</translation>
		</message>
		<message>
			<source>There is a partially completed file for this folder/file name. Would you like to resume the process?</source>
			<translation>Există un fișier parțial finalizat pentru acest dosar/nume de fișier. Doriți să reluați procesul?</translation>
		</message>
		<message>
			<source>There is no data in table anl_arc for fid=491 and current user.</source>
			<translation>Nu există date în tabelul anl_arc pentru fid=491 și utilizatorul curent.</translation>
		</message>
		<message>
			<source>There is no data in table anl_arc for fid=493 and current user.</source>
			<translation>Nu există date în tabelul anl_arc pentru fid=493 și utilizatorul curent.</translation>
		</message>
		<message>
			<source>There is no project selected or it is not valid. Please check the first tab...</source>
			<translation>Nu există niciun proiect selectat sau acesta nu este valid. Vă rugăm să verificați prima filă...</translation>
		</message>
		<message>
			<source>There is no valid shape curve in the list</source>
			<translation>Nu există nicio curbă de formă validă în listă</translation>
		</message>
		<message>
			<source>The result cannot be deleted</source>
			<translation>Rezultatul nu poate fi șters</translation>
		</message>
		<message>
			<source>There was an error deleting object.</source>
			<translation>A existat o eroare la ștergerea obiectului.</translation>
		</message>
		<message>
			<source>There was an error deleting object values.</source>
			<translation>A existat o eroare la ștergerea valorilor obiectului.</translation>
		</message>
		<message>
			<source>There was an error deleting old curve values.</source>
			<translation>A existat o eroare la ștergerea valorilor vechi ale curbei.</translation>
		</message>
		<message>
			<source>There was an error deleting old lid values.</source>
			<translation>A existat o eroare la ștergerea valorilor vechi ale lidului.</translation>
		</message>
		<message>
			<source>There was an error deleting old pattern values.</source>
			<translation>A existat o eroare la ștergerea valorilor vechi ale modelului.</translation>
		</message>
		<message>
			<source>There was an error deleting old timeseries values.</source>
			<translation>A existat o eroare la ștergerea valorilor vechi ale seriilor cronologice.</translation>
		</message>
		<message>
			<source>There was an error inserting control.</source>
			<translation>A avut loc o eroare la inserarea controlului.</translation>
		</message>
		<message>
			<source>There was an error inserting curve.</source>
			<translation>A avut loc o eroare la inserarea curbei.</translation>
		</message>
		<message>
			<source>There was an error inserting curve value.</source>
			<translation>A avut loc o eroare la inserarea valorii curbei.</translation>
		</message>
		<message>
			<source>There was an error inserting lid.</source>
			<translation>A fost o eroare la introducerea capacului.</translation>
		</message>
		<message>
			<source>There was an error inserting pattern.</source>
			<translation>A fost o eroare la inserarea modelului.</translation>
		</message>
		<message>
			<source>There was an error inserting pattern value.</source>
			<translation>A avut loc o eroare la inserarea valorii modelului.</translation>
		</message>
		<message>
			<source>There was an error inserting timeseries.</source>
			<translation>A existat o eroare la inserarea seriilor de timp.</translation>
		</message>
		<message>
			<source>There were velocities &gt;50 in the rpt file. You have activated the option to force the import so they have been set to 50.</source>
			<translation>Au existat viteze &gt;50 în fișierul rpt. Ați activat opțiunea de a forța importul, astfel încât acestea au fost setate la 50.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlaped, it seems you need to improve your simulation. Please ckeck and fix it before continue. </source>
			<translation>Fișierul rpt nu este valid pentru import. Deoarece coloanele din fișierul rpt sunt suprapuse, se pare că trebuie să vă îmbunătățiți simularea. Vă rugăm să verificați și să reparați înainte de a continua.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlapped, it seems you need to improve your simulation. Please check and fix it before continuing.</source>
			<translation>Fișierul rpt nu este valid pentru import. Deoarece coloanele din fișierul rpt sunt suprapuse, se pare că trebuie să vă îmbunătățiți simularea. Vă rugăm să verificați și să remediați problema înainte de a continua.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. </source>
			<translation>Fișierul rpt nu este valid pentru import. Deoarece viteza nu are o valoare numerică (&gt;50), se pare că trebuie să vă îmbunătățiți simularea. Vă rugăm să verificați și să remediați problema înainte de a continua.</translation>
		</message>
		<message>
			<source>The [SCENARIOS] section of the configuration file is empty.</source>
			<translation>Secțiunea [SCENARIOS] din fișierul de configurare este goală.</translation>
		</message>
		<message>
			<source>The schema ({0}) does not exists</source>
			<translation>Schema ({0}) nu există</translation>
		</message>
		<message>
			<source>The schema &apos;{0}&apos; is being used in production! It can&apos;t be deleted.</source>
			<translation>Schema &quot;{0}&quot; este utilizată în producție! Aceasta nu poate fi ștearsă.</translation>
		</message>
		<message>
			<source>The schema version has to be updated to make rename</source>
			<translation>Versiunea schemei trebuie să fie actualizată pentru a face redenumirea</translation>
		</message>
		<message>
			<source>These are the lists that will be used. Do you want to continue?</source>
			<translation>Acestea sunt listele care vor fi utilizate. Doriți să continuați?</translation>
		</message>
		<message>
			<source>The second tab is the &apos;Features&apos; tab, where you can select the corresponding feature classes for each type of feature on the network.</source>
			<translation>A doua filă este fila &quot;Caracteristici&quot;, unde puteți selecta clasele de caracteristici corespunzătoare pentru fiecare tip de caracteristică din rețea.</translation>
		</message>
		<message>
			<source>The selected node is planified in another psector.</source>
			<translation>Nodul selectat este planificat în alt psector.</translation>
		</message>
		<message>
			<source>The selected node should have exactly two linked arcs.</source>
			<translation>Nodul selectat trebuie să aibă exact două arce legate.</translation>
		</message>
		<message>
			<source>These links could not be located within the network: </source>
			<translation>Aceste legături nu au putut fi localizate în cadrul rețelei:</translation>
		</message>
		<message>
			<source>These pipes have no pressure information for their nodes. This will result in them receiving the maximum longevity value for their material, which may affect the final priority value.</source>
			<translation>Aceste conducte nu au informații despre presiune pentru nodurile lor. Prin urmare, acestea vor primi valoarea maximă a longevității pentru materialul lor, ceea ce poate afecta valoarea finală a priorității.</translation>
		</message>
		<message>
			<source>These pipes will NOT be assigned a priority value as the configured unknown material, {1}, is not listed in the configuration tab for materials.</source>
			<translation>Acestor conducte NU li se va atribui o valoare de prioritate deoarece materialul necunoscut configurat, {1}, nu este listat în fila de configurare pentru materiale.</translation>
		</message>
		<message>
			<source>The start date must be before the end date</source>
			<translation>The start date must be before the end date</translation>
		</message>
		<message>
			<source>The start date real must be before the end date real</source>
			<translation>The start date real must be before the end date real</translation>
		</message>
		<message>
			<source>The sum of weights must equal 1. Please adjust the values accordingly.</source>
			<translation>Suma ponderilor trebuie să fie egală cu 1. Vă rugăm să ajustați valorile în consecință.</translation>
		</message>
		<message>
			<source>The table ({0}) does not exists</source>
			<translation>Tabelul ({0}) nu există</translation>
		</message>
		<message>
			<source>The table &apos;plan_psector&apos; contains NULL values in the column &apos;atlas_id&apos;. Please fix this before continuing.</source>
			<translation>Tabelul &quot;plan_psector&quot; conține valori NULL în coloana &quot;atlas_id&quot;. Vă rugăm să rezolvați această problemă înainte de a continua.</translation>
		</message>
		<message>
			<source>The target year must be between {0} and {1}.</source>
			<translation>Anul țintă trebuie să fie între {0} și {1}.</translation>
		</message>
		<message>
			<source>The team name already exists</source>
			<translation>The team name already exists</translation>
		</message>
		<message>
			<source>The third tab is the &apos;Materials&apos; tab, where you can select the corresponding material for each roughness value.</source>
			<translation>A treia filă este fila &quot;Materiale&quot;, unde puteți selecta materialul corespunzător pentru fiecare valoare a rugozității.</translation>
		</message>
		<message>
			<source>The third tab is the &apos;Materials&apos; tab, where you can select the corresponding roughness value for each material.</source>
			<translation>A treia filă este fila &quot;Materiale&quot;, unde puteți selecta valoarea rugozității corespunzătoare pentru fiecare material.</translation>
		</message>
		<message>
			<source>The user config files have been recreated. A backup of the broken ones have been created at</source>
			<translation>Fișierele de configurare ale utilizatorului au fost recreate. A fost creată o copie de rezervă a celor rupte la adresa</translation>
		</message>
		<message>
			<source>This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector</source>
			<translation>Acest comportament poate fi configurat în tabelul &quot;config_param_system&quot; (parametru = &quot;basic_selector</translation>
		</message>
		<message>
			<source>This dma doesn&apos;t exist</source>
			<translation>Acest dma nu există</translation>
		</message>
		<message>
			<source>This feature has no log changes, please update this feature before.</source>
			<translation>Această caracteristică nu are modificări ale jurnalului, vă rugăm să actualizați această caracteristică înainte.</translation>
		</message>
		<message>
			<source>This functionality is only allowed with the locality &apos;en_US&apos; and SRID 25831.</source>
			<translation>Această funcționalitate este permisă numai cu localitatea &quot;en_US&quot; și SRID 25831.</translation>
		</message>
		<message>
			<source>This parameter is mandatory. Please, set a value</source>
			<translation>Acest parametru este obligatoriu. Vă rugăm să stabiliți o valoare</translation>
		</message>
		<message>
			<source>This presszone doesn&apos;t exist</source>
			<translation>Această zonă de presă nu există</translation>
		</message>
		<message>
			<source>This process will active snapshot. Are you sure to continue?</source>
			<translation>Acest proces va activa instantaneul. Sunteți sigur că doriți să continuați?</translation>
		</message>
		<message>
			<source>This process will take a few seconds. Are you sure to continue?</source>
			<translation>Acest proces va dura câteva secunde. Sunteți sigur că doriți să continuați?</translation>
		</message>
		<message>
			<source>This process will take time (few minutes). Are you sure to continue?</source>
			<translation>Acest proces va dura ceva timp (câteva minute). Sunteți sigur că doriți să continuați?</translation>
		</message>
		<message>
			<source>This &apos;Project_name&apos; already exist. Do you want rename old schema to &apos;{0}&apos;</source>
			<translation>Acest &apos;Project_name&apos; există deja. Doriți să redenumiți schema veche în &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>This project name alredy exist.</source>
			<translation>Acest nume de proiect există deja.</translation>
		</message>
		<message>
			<source>This result name already exists</source>
			<translation>Acest nume de rezultat există deja</translation>
		</message>
		<message>
			<source>This SRID value does not exist on Postgres Database. Please select a diferent one.</source>
			<translation>Această valoare SRID nu există în baza de date Postgres. Vă rugăm să selectați una diferită.</translation>
		</message>
		<message>
			<source>This task may take some time to complete, do you want to proceed?</source>
			<translation>Această sarcină poate dura ceva timp până la finalizare, doriți să continuați?</translation>
		</message>
		<message>
			<source>This will also delete all related entries in the sys_style table.Confirm Cascade Delete</source>
			<translation>Aceasta va șterge, de asemenea, toate intrările aferente din tabelul sys_style.Confirmare ștergere în cascadă</translation>
		</message>
		<message>
			<source>This will also delete the database user(s):</source>
			<translation>Acest lucru va șterge și utilizatorul (utilizatorii) bazei de date:</translation>
		</message>
		<message>
			<source>This will also delete the database user(s):</source>
			<translation>This will also delete the database user(s):</translation>
		</message>
		<message>
			<source>!!!!! THIS WILL DELETE ALL DATA IN THE DATABASE !!!!!</source>
			<translation>!!!!! ACEST LUCRU VA ȘTERGE TOATE DATELE DIN BAZA DE DATE !!!!!</translation>
		</message>
		<message>
			<source>This will modify your inp file, so a backup will be created.</source>
			<translation>Acest lucru va modifica fișierul dvs. inp, astfel încât va fi creată o copie de rezervă.</translation>
		</message>
		<message>
			<source>This wizard will help with the process of importing a network from a {0} INP file into the Giswater database.</source>
			<translation>Acest asistent va ajuta la procesul de import al unei rețele dintr-un fișier {0} INP în baza de date Giswater.</translation>
		</message>
		<message>
			<source>This Workcat already exist</source>
			<translation>Acest Workcat există deja</translation>
		</message>
		<message>
			<source>This Workcat is already exist</source>
			<translation>Acest Workcat există deja</translation>
		</message>
		<message>
			<source>To make the result id {0} corporate, is necessary to make not corporate the following result ids: {1}. Do you want to proceed?</source>
			<translation>Pentru ca id-ul de rezultat {0} să fie corporativ, este necesar ca următoarele id-uri de rezultat să nu fie corporative: {1}. Doriți să continuați?</translation>
		</message>
		<message>
			<source>To modify columns (top_elev, ymax, elev among others) to be interpolated set variable edit_node_interpolate on table config_param_user</source>
			<translation>Pentru a modifica coloanele (top_elev, ymax, elev printre altele) care urmează să fie interpolate, setați variabila edit_node_interpolate pe tabelul config_param_user</translation>
		</message>
		<message>
			<source>Toolbox task is already active!</source>
			<translation>Sarcina Toolbox este deja activă!</translation>
		</message>
		<message>
			<source>Total municipalities processed: {0}</source>
			<translation>Total municipalități procesate: {0}</translation>
		</message>
		<message>
			<source>translation canceled</source>
			<translation>traducere anulată</translation>
		</message>
		<message>
			<source>translation failed in table</source>
			<translation>traducere eșuată în tabel</translation>
		</message>
		<message>
			<source>translation successful</source>
			<translation>traducere reușită</translation>
		</message>
		<message>
			<source>Tried to set {0} to &apos;{1}&apos; but it&apos;s not an integer. Defaulting to 4 threads.</source>
			<translation>Am încercat să setez {0} la &apos;{1}&apos;, dar nu este un număr întreg. Implicit 4 fire.</translation>
		</message>
		<message>
			<source>Triggers updated successfully</source>
			<translation>Declanșatoare actualizate cu succes</translation>
		</message>
		<message>
			<source>Try again</source>
			<translation>Încercați din nou</translation>
		</message>
		<message>
			<source>Typeahead &apos;{0}&apos; doesn&apos;t have neither a queryText nor comboIds/comboNames.</source>
			<translation>Typeahead &apos;{0}&apos; nu are nici queryText, nici comboIds/comboNames.</translation>
		</message>
		<message>
			<source>Unable to highlight the snapped node.</source>
			<translation>Nu se poate evidenția nodul fixat.</translation>
		</message>
		<message>
			<source>Unhandled Error</source>
			<translation>Eroare negestionată</translation>
		</message>
		<message>
			<source>Unrecognised form type</source>
			<translation>Tip de formular nerecunoscut</translation>
		</message>
		<message>
			<source>Unsuported geometry type</source>
			<translation>Tip de geometrie nesusținută</translation>
		</message>
		<message>
			<source>Update configuration</source>
			<translation>Actualizarea configurației</translation>
		</message>
		<message>
			<source>Update Confirmation</source>
			<translation>Confirmarea actualizării</translation>
		</message>
		<message>
			<source>Update records</source>
			<translation>Actualizarea înregistrărilor</translation>
		</message>
		<message>
			<source>Updating {0}...</source>
			<translation>Actualizarea {0}...</translation>
		</message>
		<message>
			<source>User not found</source>
			<translation>Utilizatorul nu a fost găsit</translation>
		</message>
		<message>
			<source>Vacuum executed: {0}.{1}</source>
			<translation>Vacuum executat: {0}.{1}</translation>
		</message>
		<message>
			<source>Value in addparam must be in a json format</source>
			<translation>Valoarea din addparam trebuie să fie în format json</translation>
		</message>
		<message>
			<source>Values has been updated</source>
			<translation>Valorile au fost actualizate</translation>
		</message>
		<message>
			<source>Values saved successfully.</source>
			<translation>Valori salvate cu succes.</translation>
		</message>
		<message>
			<source>Variable log_sql from user config file has been disabled.</source>
			<translation>Variabila log_sql din fișierul de configurare al utilizatorului a fost dezactivată.</translation>
		</message>
		<message>
			<source>Variable log_sql from user config file has been enabled.</source>
			<translation>Variabila log_sql din fișierul de configurare al utilizatorului a fost activată.</translation>
		</message>
		<message>
			<source>Version</source>
			<translation>Versiune</translation>
		</message>
		<message>
			<source>Warning</source>
			<translation>Avertisment</translation>
		</message>
		<message>
			<source>WARNING</source>
			<translation>AVERTISMENT</translation>
		</message>
		<message>
			<source>Warning: Are you sure to continue?. This button will update your plugin qgis templates file replacing all strings defined on the config/dev.config file. Be sure your config file is OK before continue</source>
			<translation>Avertisment: Sunteți sigur că doriți să continuați?. Acest buton va actualiza fișierul șabloanelor plugin qgis înlocuind toate șirurile definite în fișierul config/dev.config. Asigurați-vă că fișierul dvs. de configurare este OK înainte de a continua</translation>
		</message>
		<message>
			<source>WARNING: This will remove the &apos;utils_workspace_current&apos; variable for your user!</source>
			<translation>AVERTISMENT: Acest lucru va elimina variabila &quot;utils_workspace_current&quot; pentru utilizatorul dumneavoastră!</translation>
		</message>
		<message>
			<source>widget {0} has associated function {1}, but {2} not exist</source>
			<translation>widget {0} are asociată funcția {1}, dar {2} nu există</translation>
		</message>
		<message>
			<source>widget {0} has not columnname and can&apos;t be configured</source>
			<translation>widget {0} nu are nume de coloană și nu poate fi configurat</translation>
		</message>
		<message>
			<source>widget {0} has not columnname and cant be configured</source>
			<translation>widget {0} nu are nume de coloană și nu poate fi configurat</translation>
		</message>
		<message>
			<source>widget {0} have associated function {1}, but {2} not exist</source>
			<translation>widget {0} are asociată funcția {1}, dar {2} nu există</translation>
		</message>
		<message>
			<source>widget {0} in tab {1} has not columnname and can&apos;t be configured</source>
			<translation>widget {0} în fila {1} nu are nume de coloană și nu poate fi configurat</translation>
		</message>
		<message>
			<source>widget {0} in tab {1} has not columnname and cant be configured</source>
			<translation>widget {0} în fila {1} nu are nume de coloană și nu poate fi configurat</translation>
		</message>
		<message>
			<source>Widget {0} is not configured or have a bad config</source>
			<translation>Widgetul {0} nu este configurat sau are o configurare greșită</translation>
		</message>
		<message>
			<source>Widget: {0} not in form.</source>
			<translation>Widget: {0} nu este în formular.</translation>
		</message>
		<message>
			<source>Widget expl_id not found</source>
			<translation>Widget expl_id nu a fost găsit</translation>
		</message>
		<message>
			<source>Widget model is none: {0}</source>
			<translation>Modelul widgetului este niciunul: {0}</translation>
		</message>
		<message>
			<source>widgetname not found. </source>
			<translation>widgetname nu a fost găsit.</translation>
		</message>
		<message>
			<source>Widget not found</source>
			<translation>Widget-ul nu a fost găsit</translation>
		</message>
		<message>
			<source>widgettype is wrongly configured. Needs to be in </source>
			<translation>widgettype este configurat greșit. Trebuie să fie în</translation>
		</message>
		<message>
			<source>widgettype not found. </source>
			<translation>widgettype nu a fost găsit.</translation>
		</message>
		<message>
			<source>Workcat created successfully.</source>
			<translation>Workcat creat cu succes.</translation>
		</message>
		<message>
			<source>Work_id field is empty</source>
			<translation>Câmpul Work_id este gol</translation>
		</message>
		<message>
			<source>Write inp file........: {0}</source>
			<translation>Write inp file........: {0}</translation>
		</message>
		<message>
			<source>You are about to delete the result</source>
			<translation>Sunteți pe punctul de a șterge rezultatul</translation>
		</message>
		<message>
			<source>You are about to import the INP file in TESTING MODE. This will delete all the data in the database related to the network you are importing. Are you sure you want to proceed?</source>
			<translation>Sunteți pe cale să importați fișierul INP în modul de testare. Acest lucru va șterge toate datele din baza de date referitoare la rețeaua pe care o importați. Sunteți sigur că doriți să continuați?</translation>
		</message>
		<message>
			<source>You are about to perform this action aiming to the following schema: {0}</source>
			<translation>Sunteți pe cale să efectuați această acțiune vizând următoarea schemă: {0}</translation>
		</message>
		<message>
			<source>You are going to change the epa_type. With this operation you will lose information about current epa_type values of this object. Would you like to continue?</source>
			<translation>Aveți de gând să modificați epa_type. Prin această operațiune veți pierde informațiile despre valorile actuale epa_type ale acestui obiect. Doriți să continuați?</translation>
		</message>
		<message>
			<source>You are going to lose previous information!</source>
			<translation>Veți pierde informațiile anterioare!</translation>
		</message>
		<message>
			<source>You are going to make this result corporate. From now on the result values will appear on feature form. Do you want to continue?</source>
			<translation>Veți face acest rezultat corporativ. De acum înainte, valorile rezultatului vor apărea pe formularul feature. Doriți să continuați?</translation>
		</message>
		<message>
			<source>You are not enabled to modify this {0} widget</source>
			<translation>Nu sunteți autorizat să modificați acest widget {0}</translation>
		</message>
		<message>
			<source>You are trying to add/remove a record from the table, with changes to the current records. If you continue, the changes will be discarded without saving. Do you want to continue?</source>
			<translation>Încercați să adăugați/eliminați o înregistrare din tabel, cu modificări ale înregistrărilor curente. Dacă continuați, modificările vor fi eliminate fără a fi salvate. Doriți să continuați?</translation>
		</message>
		<message>
			<source>You are trying to add/remove a record from the table, with changes to the current records.If you continue, the changes will be discarded without saving. Do you want to continue?</source>
			<translation>Încercați să adăugați/eliminați o înregistrare din tabel, cu modificări ale înregistrărilor curente.Dacă continuați, modificările vor fi eliminate fără a fi salvate. Doriți să continuați?</translation>
		</message>
		<message>
			<source>You are trying to delete your current psector. Please, change your current psector before delete.</source>
			<translation>Încercați să vă ștergeți psectorul curent. Vă rugăm să vă schimbați psectorul curent înainte de a-l șterge.</translation>
		</message>
		<message>
			<source>You can change it and use &apos;Update Style&apos; to create a personalized version.</source>
			<translation>Puteți să-l modificați și să utilizați &quot;Actualizare stil&quot; pentru a crea o versiune personalizată.</translation>
		</message>
		<message>
			<source>You cannot change the status of a result with status &apos;FINISHED&apos;.</source>
			<translation>Nu puteți modifica starea unui rezultat cu starea &quot;FINISHED&quot;.</translation>
		</message>
		<message>
			<source>You cannot insert more than one feature at the same time, finish editing the previous feature</source>
			<translation>Nu puteți insera mai mult de o caracteristică în același timp, finalizați editarea caracteristicii anterioare</translation>
		</message>
		<message>
			<source>You can save the current configuration to a file and load it later, or load the last saved configuration.</source>
			<translation>Aveți posibilitatea să salvați configurația curentă într-un fișier și să o încărcați ulterior sau să încărcați ultima configurație salvată.</translation>
		</message>
		<message>
			<source>You can&apos;t delete these mincuts because they aren&apos;t planified </source>
			<translation>Nu puteți șterge aceste minutaje deoarece nu sunt planificate</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time.</source>
			<translation>Ați închis o supapă, acest lucru va modifica zonele actuale ale hărții și poate dura puțin timp.</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time. Would you like to continue?</source>
			<translation>Ați închis o supapă, acest lucru va modifica zonele actuale ale hărții și poate dura puțin timp. Doriți să continuați?</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time.Would you like to continue?</source>
			<translation>Ați închis o supapă, acest lucru va modifica zonele actuale ale hărții și poate dura un pic de timp.Doriți să continuați?</translation>
		</message>
		<message>
			<source>You do not have permission to execute this application</source>
			<translation>Nu aveți permisiunea de a executa această aplicație</translation>
		</message>
		<message>
			<source>You don&apos;t have any connection to PostGIS database configurated. Check your QGIS data source manager and create at least one</source>
			<translation>Nu aveți configurată nicio conexiune la baza de date PostGIS. Verificați managerul sursei de date QGIS și creați cel puțin o</translation>
		</message>
		<message>
			<source>You have selected multiple documents. In this case, name will be a sequential number for all selected documents and your name won&apos;t be used.</source>
			<translation>Ați selectat mai multe documente. În acest caz, numele va fi un număr secvențial pentru toate documentele selectate, iar numele dvs. nu va fi utilizat.</translation>
		</message>
		<message>
			<source>You have to fill in &apos;date&apos;, &apos;time&apos; and &apos;value&apos; fields!</source>
			<translation>Trebuie să completați câmpurile &quot;dată&quot;, &quot;oră&quot; și &quot;valoare&quot;!</translation>
		</message>
		<message>
			<source>You have to fill in &apos;time&apos; and &apos;value&apos; fields!</source>
			<translation>Trebuie să completați câmpurile &quot;timp&quot; și &quot;valoare&quot;!</translation>
		</message>
		<message>
			<source>You have to import a ibergis GPKG project first</source>
			<translation>Mai întâi trebuie să importați un proiect ibergis GPKG</translation>
		</message>
		<message>
			<source>You have to set this parameter</source>
			<translation>Trebuie să setați acest parametru</translation>
		</message>
		<message>
			<source>You have to set this parameter: INP file</source>
			<translation>You have to set this parameter: INP file</translation>
		</message>
		<message>
			<source>You must choose at least one action</source>
			<translation>You must choose at least one action</translation>
		</message>
		<message>
			<source>You must select two different points</source>
			<translation>Trebuie să selectați două puncte diferite</translation>
		</message>
		<message>
			<source>You need at least one row of values.</source>
			<translation>Aveți nevoie de cel puțin un rând de valori.</translation>
		</message>
		<message>
			<source>You need to enter a customer code</source>
			<translation>Trebuie să introduceți un cod client</translation>
		</message>
		<message>
			<source>You need to enter a feature id</source>
			<translation>Trebuie să introduceți un id al caracteristicii</translation>
		</message>
		<message>
			<source>You need to enter a psector name</source>
			<translation>Trebuie să introduceți un nume de sector</translation>
		</message>
		<message>
			<source>You need to enter a visit ID</source>
			<translation>Trebuie să introduceți un ID de vizită</translation>
		</message>
		<message>
			<source>You need to enter a workcat id</source>
			<translation>Trebuie să introduceți un id workcat</translation>
		</message>
		<message>
			<source>You need to enter hydrometer_id</source>
			<translation>Trebuie să introduceți hydrometer_id</translation>
		</message>
		<message>
			<source>You need to have a mesh</source>
			<translation>Trebuie să aveți o plasă</translation>
		</message>
		<message>
			<source>You need to insert a document name</source>
			<translation>Trebuie să introduceți un nume de document</translation>
		</message>
		<message>
			<source>You need to insert data</source>
			<translation>Trebuie să introduceți date</translation>
		</message>
		<message>
			<source>You need to insert psector_id</source>
			<translation>Trebuie să introduceți psector_id</translation>
		</message>
		<message>
			<source>You need to insert visit_id</source>
			<translation>Trebuie să introduceți visit_id</translation>
		</message>
		<message>
			<source>You need to select a template</source>
			<translation>Trebuie să selectați un șablon</translation>
		</message>
		<message>
			<source>You need to select at least one process</source>
			<translation>Trebuie să selectați cel puțin un proces</translation>
		</message>
		<message>
			<source>You need to select a valid parameter id</source>
			<translation>Trebuie să selectați un id de parametru valid</translation>
		</message>
		<message>
			<source>You need to select some sector</source>
			<translation>Trebuie să selectați un anumit sector</translation>
		</message>
		<message>
			<source>Your composer&apos;s path is bad configured. Please, modify it and try again.</source>
			<translation>Calea compozitorului dvs. este prost configurată. Vă rugăm, modificați-o și încercați din nou.</translation>
		</message>
		<message>
			<source>Your exploitation selector has been updated</source>
			<translation>Selectorul dvs. de exploatare a fost actualizat</translation>
		</message>
		<message>
			<source>You should inform a file name!</source>
			<translation>Ar trebui să informați un nume de fișier!</translation>
		</message>
		<message>
			<source>You should select a config file!</source>
			<translation>Ar trebui să selectați un fișier de configurare!</translation>
		</message>
		<message>
			<source>You should select an config file!</source>
			<translation>Ar trebui să selectați un fișier de configurare!</translation>
		</message>
		<message>
			<source>You should select an input INP file!</source>
			<translation>Trebuie să selectați un fișier INP de intrare!</translation>
		</message>
		<message>
			<source>You should select an output folder!</source>
			<translation>Trebuie să selectați un folder de ieșire!</translation>
		</message>
		<message>
			<source>You will need to restart QGIS or reload Giswater plugin to apply changes. Do you want continue?</source>
			<translation>Va trebui să reporniți QGIS sau să reîncărcați pluginul Giswater pentru a aplica modificările. Doriți să continuați?</translation>
		</message>
	</context>
<!-- UI TRANSLATION -->
	<context>
		<name>add_campaign_inventory</name>
		<message>
			<source>add_campaign</source>
			<translation>Campanie</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Campanie</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relații între elemente</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_review</name>
		<message>
			<source>add_campaign</source>
			<translation>Campanie</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Campanie</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relații între elemente</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_review_old</name>
		<message>
			<source>action_selector</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_action_selector</source>
			<translation>action_selector</translation>
		</message>
		<message>
			<source>active</source>
			<translation>Activ:</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Campanie</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_export_rel</source>
			<translation>Export la csv</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_export_rel</source>
			<translation>campaign_btn_export_rel</translation>
		</message>
		<message>
			<source>campaign_btn_path_rel</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_path_rel</source>
			<translation>campaign_btn_path_rel</translation>
		</message>
		<message>
			<source>CampaignTab</source>
			<translation>Campanie</translation>
		</message>
		<message>
			<source>tooltip_CampaignTab</source>
			<translation>CampaignTab</translation>
		</message>
		<message>
			<source>grb_campaign</source>
			<translation>Campanie:</translation>
		</message>
		<message>
			<source>tooltip_grb_campaign</source>
			<translation>grb_campaign</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Exercițiu:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Serie:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Inici real:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Fi real:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Organizație:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Durata:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Statutul:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Adresa:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Tip element:</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>label_feature_type</translation>
		</message>
		<message>
			<source>label_flexunion_code_5</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_label_flexunion_code_5</source>
			<translation>label_flexunion_code_5</translation>
		</message>
		<message>
			<source>label_node_type</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type</source>
			<translation>label_node_type</translation>
		</message>
		<message>
			<source>label_node_type_2</source>
			<translation>Sfârșit planificat:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_2</source>
			<translation>label_node_type_2</translation>
		</message>
		<message>
			<source>label_node_type_3</source>
			<translation>Start planificat:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_3</source>
			<translation>label_node_type_3</translation>
		</message>
		<message>
			<source>label_node_type_5</source>
			<translation>Rotație:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_5</source>
			<translation>label_node_type_5</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Relații între elemente</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>RelationsTab</translation>
		</message>
		<message>
			<source>reviewclass_id</source>
			<translation>Clasa de revizuire:</translation>
		</message>
		<message>
			<source>tooltip_reviewclass_id</source>
			<translation>reviewclass_id</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_visit</name>
		<message>
			<source>add_campaign</source>
			<translation>Vizită</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Campanie</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relații între elemente</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_visit_old</name>
		<message>
			<source>action_selector</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_action_selector</source>
			<translation>action_selector</translation>
		</message>
		<message>
			<source>active</source>
			<translation>Activ:</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_export_rel</source>
			<translation>Export la csv</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_export_rel</source>
			<translation>campaign_btn_export_rel</translation>
		</message>
		<message>
			<source>campaign_btn_path_rel</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_path_rel</source>
			<translation>campaign_btn_path_rel</translation>
		</message>
		<message>
			<source>CampaignTab</source>
			<translation>Campanie</translation>
		</message>
		<message>
			<source>tooltip_CampaignTab</source>
			<translation>CampaignTab</translation>
		</message>
		<message>
			<source>grb_campaign</source>
			<translation>Campanie:</translation>
		</message>
		<message>
			<source>tooltip_grb_campaign</source>
			<translation>grb_campaign</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Exercițiu:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Serie:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Început real:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Sfârșit real:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Organizație:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Durata:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Statutul:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Adresa:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Tip de element</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>label_feature_type</translation>
		</message>
		<message>
			<source>label_flexunion_code_5</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_label_flexunion_code_5</source>
			<translation>label_flexunion_code_5</translation>
		</message>
		<message>
			<source>label_node_type</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type</source>
			<translation>label_node_type</translation>
		</message>
		<message>
			<source>label_node_type_2</source>
			<translation>Sfârșit planificat:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_2</source>
			<translation>label_node_type_2</translation>
		</message>
		<message>
			<source>label_node_type_3</source>
			<translation>Start planificat:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_3</source>
			<translation>label_node_type_3</translation>
		</message>
		<message>
			<source>label_node_type_5</source>
			<translation>Rotație:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_5</source>
			<translation>label_node_type_5</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Relații între elemente</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>RelationsTab</translation>
		</message>
		<message>
			<source>visitclass_id</source>
			<translation>Clasa de vizitare:</translation>
		</message>
		<message>
			<source>tooltip_visitclass_id</source>
			<translation>visitclass_id</translation>
		</message>
	</context>
	<context>
		<name>add_lot</name>
		<message>
			<source>title</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_visit</source>
			<translation>Ștergeți vizita</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_visit</source>
			<translation>Ștergeți vizita</translation>
		</message>
		<message>
			<source>btn_export_visits</source>
			<translation>Export la csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_visits</source>
			<translation>Export la csv</translation>
		</message>
		<message>
			<source>btn_open_photo</source>
			<translation>Deschideți fotografia</translation>
		</message>
		<message>
			<source>tooltip_btn_open_photo</source>
			<translation>Deschideți fotografia</translation>
		</message>
		<message>
			<source>btn_open_visit</source>
			<translation>Vizită deschisă</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit</source>
			<translation>Vizită deschisă</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_validate_all</source>
			<translation>Validați toate</translation>
		</message>
		<message>
			<source>tooltip_btn_validate_all</source>
			<translation>Validați toate</translation>
		</message>
		<message>
			<source>dlg_add_lot</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_lot</source>
			<translation>dlg_add_lot</translation>
		</message>
		<message>
			<source>grb_lot</source>
			<translation>Lot:</translation>
		</message>
		<message>
			<source>tooltip_grb_lot</source>
			<translation>Lot:</translation>
		</message>
		<message>
			<source>label_data_event_from</source>
			<translation>De la:</translation>
		</message>
		<message>
			<source>tooltip_label_data_event_from</source>
			<translation>De la:</translation>
		</message>
		<message>
			<source>label_data_event_to</source>
			<translation>Până la:</translation>
		</message>
		<message>
			<source>tooltip_label_data_event_to</source>
			<translation>Pentru:</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtrați după id-ul elementului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>Filtrați după id-ul elementului:</translation>
		</message>
		<message>
			<source>LotTab</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>tooltip_LotTab</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Relații între elemente</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>Relația dintre elemente</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>VisitsTab</source>
			<translation>Vizite</translation>
		</message>
		<message>
			<source>tooltip_VisitsTab</source>
			<translation>Vizite</translation>
		</message>
	</context>
	<context>
		<name>add_workorder</name>
		<message>
			<source>title</source>
			<translation>Ordin de lucru</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_add_workorder</source>
			<translation>Ordin de lucru</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_workorder</source>
			<translation>dlg_add_workorder</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Ordin de lucru</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
	</context>
	<context>
		<name>admin</name>
		<message>
			<source>title</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>btn_activate_audit</source>
			<translation>Activarea mediului de audit</translation>
		</message>
		<message>
			<source>tooltip_btn_activate_audit</source>
			<translation>It will generate a copy of the network layers from your current schema into the audit schema</translation>
		</message>
		<message>
			<source>btn_adapt_cibs</source>
			<translation>Adapt schema to use cibs</translation>
		</message>
		<message>
			<source>tooltip_btn_adapt_cibs</source>
			<translation>btn_adapt_cibs</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_copy</source>
			<translation>Copiați</translation>
		</message>
		<message>
			<source>tooltip_btn_copy</source>
			<translation>btn_copy</translation>
		</message>
		<message>
			<source>btn_create_asset</source>
			<translation>Crearea schemei activelor BD</translation>
		</message>
		<message>
			<source>tooltip_btn_create_asset</source>
			<translation>btn_create_asset</translation>
		</message>
		<message>
			<source>btn_create_audit</source>
			<translation>Crearea schemei de audit a BD</translation>
		</message>
		<message>
			<source>tooltip_btn_create_audit</source>
			<translation>btn_create_audit</translation>
		</message>
		<message>
			<source>btn_create_cibs</source>
			<translation>Create cibs schema</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cibs</source>
			<translation>btn_create_cibs</translation>
		</message>
		<message>
			<source>btn_create_cm</source>
			<translation>Crearea schemei DB cm</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cm</source>
			<translation>btn_create_cm</translation>
		</message>
		<message>
			<source>btn_create_field</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create_field</source>
			<translation>btn_create_field</translation>
		</message>
		<message>
			<source>btn_create_qgis_template</source>
			<translation>Șabloane QGIS</translation>
		</message>
		<message>
			<source>tooltip_btn_create_qgis_template</source>
			<translation>btn_create_qgis_template</translation>
		</message>
		<message>
			<source>btn_create_utils</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create_utils</source>
			<translation>btn_create_utils</translation>
		</message>
		<message>
			<source>btn_custom_load_file</source>
			<translation>Încărcarea fișierelor SQL</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_load_file</source>
			<translation>btn_custom_load_file</translation>
		</message>
		<message>
			<source>btn_custom_select_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_select_file</source>
			<translation>btn_custom_select_file</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_delete_field</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_field</source>
			<translation>btn_delete_field</translation>
		</message>
		<message>
			<source>btn_gis_create</source>
			<translation>Crearea</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_create</source>
			<translation>btn_gis_create</translation>
		</message>
		<message>
			<source>btn_gis_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_folder</source>
			<translation>btn_gis_folder</translation>
		</message>
		<message>
			<source>btn_i18n</source>
			<translation>manager i18n</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n</source>
			<translation>btn_i18n</translation>
		</message>
		<message>
			<source>btn_import_osm_streetaxis</source>
			<translation>Import OSM Streetaxis</translation>
		</message>
		<message>
			<source>tooltip_btn_import_osm_streetaxis</source>
			<translation>btn_import_osm_streetaxis</translation>
		</message>
		<message>
			<source>btn_info</source>
			<translation>Actualizarea schemei de proiect</translation>
		</message>
		<message>
			<source>tooltip_btn_info</source>
			<translation>Actualizarea versiunii unei scheme de bază de date selectate</translation>
		</message>
		<message>
			<source>btn_manage_languages</source>
			<translation>Manage Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_languages</source>
			<translation>btn_manage_languages</translation>
		</message>
		<message>
			<source>btn_manage_schemas</source>
			<translation>Manage schemas</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_schemas</source>
			<translation>btn_manage_schemas</translation>
		</message>
		<message>
			<source>btn_markdown_generator</source>
			<translation>Generator Markdown</translation>
		</message>
		<message>
			<source>tooltip_btn_markdown_generator</source>
			<translation>btn_markdown_generator</translation>
		</message>
		<message>
			<source>btn_reload_audit_triggers</source>
			<translation>Actualizarea auditului</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_audit_triggers</source>
			<translation>Allow to start/end auditing tables updating the triggers</translation>
		</message>
		<message>
			<source>btn_reload_fct_ftrg</source>
			<translation>Executare</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_fct_ftrg</source>
			<translation>btn_reload_fct_ftrg</translation>
		</message>
		<message>
			<source>btn_schema_create</source>
			<translation>Crearea schemei proiectului DB</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_create</source>
			<translation>btn_schema_create</translation>
		</message>
		<message>
			<source>btn_schema_rename</source>
			<translation>Redenumire</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_rename</source>
			<translation>btn_schema_rename</translation>
		</message>
		<message>
			<source>btn_translation</source>
			<translation>Fișiere de traducere</translation>
		</message>
		<message>
			<source>tooltip_btn_translation</source>
			<translation>btn_translation</translation>
		</message>
		<message>
			<source>btn_update_asset</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_asset</source>
			<translation>btn_update_asset</translation>
		</message>
		<message>
			<source>btn_update_cm</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_cm</source>
			<translation>btn_update_cm</translation>
		</message>
		<message>
			<source>btn_update_field</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_update_field</source>
			<translation>btn_update_field</translation>
		</message>
		<message>
			<source>btn_update_utils</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_update_utils</source>
			<translation>btn_update_utils</translation>
		</message>
		<message>
			<source>btn_vacuum</source>
			<translation>Executare</translation>
		</message>
		<message>
			<source>tooltip_btn_vacuum</source>
			<translation>btn_vacuum</translation>
		</message>
		<message>
			<source>chk_add_fields_multi</source>
			<translation>Addfield multicreate</translation>
		</message>
		<message>
			<source>tooltip_chk_add_fields_multi</source>
			<translation>chk_add_fields_multi</translation>
		</message>
		<message>
			<source>dlg_admin</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin</source>
			<translation>dlg_admin</translation>
		</message>
		<message>
			<source>grb_conection</source>
			<translation>Conexiune</translation>
		</message>
		<message>
			<source>tooltip_grb_conection</source>
			<translation>grb_conection</translation>
		</message>
		<message>
			<source>grb_files_generator</source>
			<translation>Generator de fișiere plugin</translation>
		</message>
		<message>
			<source>tooltip_grb_files_generator</source>
			<translation>grb_files_generator</translation>
		</message>
		<message>
			<source>grb_i18n</source>
			<translation>i18n</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n</source>
			<translation>grb_i18n</translation>
		</message>
		<message>
			<source>grb_load_cf</source>
			<translation>Încărcați fișierul personalizat</translation>
		</message>
		<message>
			<source>tooltip_grb_load_cf</source>
			<translation>grb_load_cf</translation>
		</message>
		<message>
			<source>grb_manage_addfields</source>
			<translation>Gestionați câmpurile de adăugare</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_addfields</source>
			<translation>grb_manage_addfields</translation>
		</message>
		<message>
			<source>grb_manage_schemas</source>
			<translation>Additional schema management</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_schemas</source>
			<translation>grb_manage_schemas</translation>
		</message>
		<message>
			<source>grb_project_scin</source>
			<translation>Informații privind schema proiectului</translation>
		</message>
		<message>
			<source>tooltip_grb_project_scin</source>
			<translation>grb_project_scin</translation>
		</message>
		<message>
			<source>grb_schema_manager</source>
			<translation>Gestionarea schemelor</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_manager</source>
			<translation>grb_schema_manager</translation>
		</message>
		<message>
			<source>grb_schema_reload</source>
			<translation>Gestionarea schemelor</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_reload</source>
			<translation>grb_schema_reload</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Scheme Utils</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Gestionarea suplimentară a schemelor</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_cibs</source>
			<translation>Schema cibs</translation>
		</message>
		<message>
			<source>tooltip_groupBox_cibs</source>
			<translation>groupBox_cibs</translation>
		</message>
		<message>
			<source>grp_i18n_update</source>
			<translation>Actualizarea schemei i18n</translation>
		</message>
		<message>
			<source>tooltip_grp_i18n_update</source>
			<translation>grp_i18n_update</translation>
		</message>
		<message>
			<source>grp_import_osm</source>
			<translation>Import OSM Streetaxis</translation>
		</message>
		<message>
			<source>tooltip_grp_import_osm</source>
			<translation>grp_import_osm</translation>
		</message>
		<message>
			<source>label</source>
			<translation>WS:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>UD:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_cibs_schema</source>
			<translation>Schema:</translation>
		</message>
		<message>
			<source>tooltip_label_cibs_schema</source>
			<translation>label_cibs_schema</translation>
		</message>
		<message>
			<source>lbl_add_fields_feature</source>
			<translation>Numele funcției:</translation>
		</message>
		<message>
			<source>tooltip_lbl_add_fields_feature</source>
			<translation>lbl_add_fields_feature</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Numele conexiunii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_export_user_pass</source>
			<translation>Export user password:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_user_pass</source>
			<translation>lbl_export_user_pass</translation>
		</message>
		<message>
			<source>lbl_gis_file</source>
			<translation>GIS file name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_file</source>
			<translation>lbl_gis_file</translation>
		</message>
		<message>
			<source>lbl_gis_folder</source>
			<translation>GIS folder:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_folder</source>
			<translation>lbl_gis_folder</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Nume:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_reload_fct_ftrg</source>
			<translation>Funcții de reîncărcare &amp;amp; declanșatoare de funcții</translation>
		</message>
		<message>
			<source>tooltip_lbl_reload_fct_ftrg</source>
			<translation>lbl_reload_fct_ftrg</translation>
		</message>
		<message>
			<source>lbl_vacuum</source>
			<translation>Executarea vidului pe schema selectată</translation>
		</message>
		<message>
			<source>tooltip_lbl_vacuum</source>
			<translation>lbl_vacuum</translation>
		</message>
		<message>
			<source>tab_advanced</source>
			<translation>Avansat</translation>
		</message>
		<message>
			<source>tooltip_tab_advanced</source>
			<translation>tab_advanced</translation>
		</message>
		<message>
			<source>tab_dev</source>
			<translation>Dev</translation>
		</message>
		<message>
			<source>tooltip_tab_dev</source>
			<translation>tab_dev</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Generalități</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>txt_roletype</source>
			<translation>inventory</translation>
		</message>
		<message>
			<source>tooltip_txt_roletype</source>
			<translation>txt_roletype</translation>
		</message>
	</context>
	<context>
		<name>admin_addfields</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Deschis</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_admin_addfields</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_addfields</source>
			<translation>dlg_admin_addfields</translation>
		</message>
		<message>
			<source>grb_additional</source>
			<translation>Configurație suplimentară</translation>
		</message>
		<message>
			<source>tooltip_grb_additional</source>
			<translation>grb_additional</translation>
		</message>
		<message>
			<source>grb_mandatory</source>
			<translation>Configurarea obligatorie a câmpurilor suplimentare</translation>
		</message>
		<message>
			<source>tooltip_grb_mandatory</source>
			<translation>grb_mandatory</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Activ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_columnname</source>
			<translation>Numele coloanei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_columnname</source>
			<translation>lbl_columnname</translation>
		</message>
		<message>
			<source>lbl_datatype</source>
			<translation>Tip de date:</translation>
		</message>
		<message>
			<source>tooltip_lbl_datatype</source>
			<translation>lbl_datatype</translation>
		</message>
		<message>
			<source>lbl_dv_orderby</source>
			<translation>Comanda după id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_orderby</source>
			<translation>lbl_dv_orderby</translation>
		</message>
		<message>
			<source>lbl_dv_querynullvalue</source>
			<translation>Interogare valoare nulă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_querynullvalue</source>
			<translation>lbl_dv_querynullvalue</translation>
		</message>
		<message>
			<source>lbl_dv_querytext</source>
			<translation>Text de interogare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_querytext</source>
			<translation>lbl_dv_querytext</translation>
		</message>
		<message>
			<source>lbl_field_name</source>
			<translation>Numele câmpului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_name</source>
			<translation>lbl_field_name</translation>
		</message>
		<message>
			<source>lbl_formtype</source>
			<translation>Tip de formular:</translation>
		</message>
		<message>
			<source>tooltip_lbl_formtype</source>
			<translation>lbl_formtype</translation>
		</message>
		<message>
			<source>lbl_hidden</source>
			<translation>Ascunse:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hidden</source>
			<translation>lbl_hidden</translation>
		</message>
		<message>
			<source>lbl_iseditable</source>
			<translation>Editabil:</translation>
		</message>
		<message>
			<source>tooltip_lbl_iseditable</source>
			<translation>lbl_iseditable</translation>
		</message>
		<message>
			<source>lbl_ismandatory</source>
			<translation>Obligatoriu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ismandatory</source>
			<translation>lbl_ismandatory</translation>
		</message>
		<message>
			<source>lbl_label</source>
			<translation>Etichetă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_label</source>
			<translation>lbl_label</translation>
		</message>
		<message>
			<source>lbl_layoutname</source>
			<translation>Numele machetei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_layoutname</source>
			<translation>lbl_layoutname</translation>
		</message>
		<message>
			<source>lbl_linkedobject</source>
			<translation>Linkedobject:</translation>
		</message>
		<message>
			<source>tooltip_lbl_linkedobject</source>
			<translation>lbl_linkedobject</translation>
		</message>
		<message>
			<source>lbl_multifeaturetype</source>
			<translation>Funcție de creare multiplă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multifeaturetype</source>
			<translation>lbl_multifeaturetype</translation>
		</message>
		<message>
			<source>lbl_placeholder</source>
			<translation>Placeholder:</translation>
		</message>
		<message>
			<source>tooltip_lbl_placeholder</source>
			<translation>lbl_placeholder</translation>
		</message>
		<message>
			<source>lbl_stylesheet</source>
			<translation>Foaie de stil:</translation>
		</message>
		<message>
			<source>tooltip_lbl_stylesheet</source>
			<translation>lbl_stylesheet</translation>
		</message>
		<message>
			<source>lbl_tooltip</source>
			<translation>Tooltip:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tooltip</source>
			<translation>lbl_tooltip</translation>
		</message>
		<message>
			<source>lbl_widgetcontrols</source>
			<translation>Widgetcontrols</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgetcontrols</source>
			<translation>Exemple de chei de configurare {&quot;widgetdim&quot;: 150,&quot;setMultiline&quot;:true,&quot;vdefault&quot;: &quot;01-01-2014&quot;,&quot;filterSign&quot;: &quot;&gt;}</translation>
		</message>
		<message>
			<source>lbl_widgettype</source>
			<translation>Tip widget:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgettype</source>
			<translation>lbl_widgettype</translation>
		</message>
		<message>
			<source>stylesheet</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;{&amp;amp;quot;label&amp;amp;quot;:&amp;amp;quot;color:green; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;widget&amp;amp;quot;:{&amp;amp;quot;enabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;disabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;}}&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_stylesheet</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;{&amp;amp;quot;label&amp;amp;quot;:&amp;amp;quot;color:green; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;widget&amp;amp;quot;:{&amp;amp;quot;enabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;disabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;}}&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tab_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_tab_create</source>
			<translation>tab_create</translation>
		</message>
		<message>
			<source>tab_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_tab_delete</source>
			<translation>tab_delete</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_update</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_tab_update</source>
			<translation>tab_update</translation>
		</message>
	</context>
	<context>
		<name>admin_cm_create</name>
		<message>
			<source>title</source>
			<translation>Creați un proiect</translation>
		</message>
		<message>
			<source>btn_base_schema</source>
			<translation>Crearea schemei cm</translation>
		</message>
		<message>
			<source>tooltip_btn_base_schema</source>
			<translation>btn_base_schema</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Anulează sarcina</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_example</source>
			<translation>Creați un exemplu</translation>
		</message>
		<message>
			<source>tooltip_btn_example</source>
			<translation>btn_example</translation>
		</message>
		<message>
			<source>btn_parent_schema</source>
			<translation>Legătură la schema părinte</translation>
		</message>
		<message>
			<source>tooltip_btn_parent_schema</source>
			<translation>btn_parent_schema</translation>
		</message>
		<message>
			<source>btn_pschema_qgis_file</source>
			<translation>Crearea fișierului pschema qgis</translation>
		</message>
		<message>
			<source>tooltip_btn_pschema_qgis_file</source>
			<translation>btn_pschema_qgis_file</translation>
		</message>
		<message>
			<source>dlg_admin_cm_create</source>
			<translation>Creați un proiect</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_cm_create</source>
			<translation>dlg_admin_cm_create</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>Opțiuni pentru schema CM</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
	</context>
	<context>
		<name>admin_credentials</name>
		<message>
			<source>title</source>
			<translation>Credențiale de conectare</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>dlg_admin_credentials</source>
			<translation>Credențiale de conectare</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_credentials</source>
			<translation>dlg_admin_credentials</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Modul SSL:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_connec</source>
			<translation>Conexiune:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connec</source>
			<translation>lbl_connec</translation>
		</message>
		<message>
			<source>lbl_connection_message</source>
			<translation>Nu s-au putut prelua parametrii de conectare pentru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection_message</source>
			<translation>lbl_connection_message</translation>
		</message>
		<message>
			<source>lbl_password</source>
			<translation>Parolă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_password</source>
			<translation>lbl_password</translation>
		</message>
		<message>
			<source>lbl_user_name</source>
			<translation>Nume utilizator:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user_name</source>
			<translation>lbl_user_name</translation>
		</message>
	</context>
	<context>
		<name>admin_dbproject</name>
		<message>
			<source>title</source>
			<translation>Creați un proiect</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Anulează sarcina</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>dlg_admin_dbproject</source>
			<translation>Creați un proiect</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_dbproject</source>
			<translation>dlg_admin_dbproject</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>Schema proiectului Setări</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtru SRID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>Identificator de referință spațială. Sunt permise numai valorile indicate în tabelul de mai jos.</translation>
		</message>
		<message>
			<source>lbl_locale</source>
			<translation>Locale:</translation>
		</message>
		<message>
			<source>tooltip_lbl_locale</source>
			<translation>Limbajul schemei</translation>
		</message>
		<message>
			<source>lbl_project_name</source>
			<translation>Numele proiectului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_name</source>
			<translation>Numele unei scheme noi. Numele trebuie să fie scris cu litere mici, folosind numai literele alfabetului englez și fără spații sau liniuțe</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Tip proiect:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_source</source>
			<translation>Sursa datelor:</translation>
		</message>
		<message>
			<source>tooltip_lbl_source</source>
			<translation>lbl_source</translation>
		</message>
		<message>
			<source>rdb_empty</source>
			<translation>Date goale</translation>
		</message>
		<message>
			<source>tooltip_rdb_empty</source>
			<translation>rdb_empty</translation>
		</message>
		<message>
			<source>rdb_sample_full</source>
			<translation>Exemplu complet</translation>
		</message>
		<message>
			<source>tooltip_rdb_sample_full</source>
			<translation>rdb_sample_full</translation>
		</message>
		<message>
			<source>rdb_sample_inv</source>
			<translation>Exemplu de inventar</translation>
		</message>
		<message>
			<source>tooltip_rdb_sample_inv</source>
			<translation>rdb_sample_inv</translation>
		</message>
	</context>
	<context>
		<name>admin_gisproject</name>
		<message>
			<source>title</source>
			<translation>Crearea proiectului GIS</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>btn_gis_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_folder</source>
			<translation>btn_gis_folder</translation>
		</message>
		<message>
			<source>dlg_admin_gisproject</source>
			<translation>Crearea proiectului GIS</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_gisproject</source>
			<translation>dlg_admin_gisproject</translation>
		</message>
		<message>
			<source>lbl_export_user_pass</source>
			<translation>Parola utilizatorului de export:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_user_pass</source>
			<translation>lbl_export_user_pass</translation>
		</message>
		<message>
			<source>lbl_gis_file</source>
			<translation>Numele fișierului GIS:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_file</source>
			<translation>lbl_gis_file</translation>
		</message>
		<message>
			<source>lbl_gis_folder</source>
			<translation>Dosar GIS:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_folder</source>
			<translation>lbl_gis_folder</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Tip proiect:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>txt_roletype</source>
			<translation>inventar</translation>
		</message>
		<message>
			<source>tooltip_txt_roletype</source>
			<translation>txt_roletype</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_hot_update</name>
		<message>
			<source>title</source>
			<translation>Manage languages</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Apply</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>btn_apply</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Close</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_manage_language_hot_update</source>
			<translation>Manage language</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_language_hot_update</source>
			<translation>btn_manage_language_hot_update</translation>
		</message>
		<message>
			<source>btn_manage_language_multilang</source>
			<translation>Manage Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_language_multilang</source>
			<translation>btn_manage_language_multilang</translation>
		</message>
		<message>
			<source>btn_refresh</source>
			<translation>Refresh</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh</source>
			<translation>btn_refresh</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>chk_add_tab_data</source>
			<translation>Translate tab_data</translation>
		</message>
		<message>
			<source>tooltip_chk_add_tab_data</source>
			<translation>chk_add_tab_data</translation>
		</message>
		<message>
			<source>chk_use_selected_tables</source>
			<translation>Use selected tables only</translation>
		</message>
		<message>
			<source>tooltip_chk_use_selected_tables</source>
			<translation>chk_use_selected_tables</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_hot_update</source>
			<translation>Manage languages</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_hot_update</source>
			<translation>dlg_admin_i18n_hot_update</translation>
		</message>
		<message>
			<source>grb_connection</source>
			<translation>Connection</translation>
		</message>
		<message>
			<source>tooltip_grb_connection</source>
			<translation>grb_connection</translation>
		</message>
		<message>
			<source>grb_params</source>
			<translation>Parameters</translation>
		</message>
		<message>
			<source>tooltip_grb_params</source>
			<translation>grb_params</translation>
		</message>
		<message>
			<source>grb_schemas</source>
			<translation>Schemas</translation>
		</message>
		<message>
			<source>tooltip_grb_schemas</source>
			<translation>grb_schemas</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Language:</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Language</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Connection name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_schema_selection</source>
			<translation>Schema: select a row below</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_selection</source>
			<translation>lbl_schema_selection</translation>
		</message>
		<message>
			<source>lbl_tables</source>
			<translation>Tables filter:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tables</source>
			<translation>lbl_tables</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Hot Update</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_2</source>
			<translation>Multilang</translation>
		</message>
		<message>
			<source>tooltip_tab_2</source>
			<translation>tab_2</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_languages</name>
		<message>
			<source>title</source>
			<translation>Manage language</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Close</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_download</source>
			<translation>Download</translation>
		</message>
		<message>
			<source>tooltip_btn_download</source>
			<translation>btn_download</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>chk_download_latest</source>
			<translation>Download latest translation version</translation>
		</message>
		<message>
			<source>tooltip_chk_download_latest</source>
			<translation>Download translations from the latest published version instead of the version matched to this plugin. For advanced users only.</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_languages</source>
			<translation>Manage language</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_languages</source>
			<translation>dlg_admin_i18n_languages</translation>
		</message>
		<message>
			<source>grb_locales</source>
			<translation>Available Languages</translation>
		</message>
		<message>
			<source>tooltip_grb_locales</source>
			<translation>grb_locales</translation>
		</message>
		<message>
			<source>lbl_language</source>
			<translation>Select a language to manage</translation>
		</message>
		<message>
			<source>tooltip_lbl_language</source>
			<translation>lbl_language</translation>
		</message>
		<message>
			<source>txt_filter</source>
			<translation>Filter locales...</translation>
		</message>
		<message>
			<source>tooltip_txt_filter</source>
			<translation>txt_filter</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_manager</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_connection</source>
			<translation>Conexiune de testare</translation>
		</message>
		<message>
			<source>tooltip_btn_connection</source>
			<translation>btn_connection</translation>
		</message>
		<message>
			<source>btn_search</source>
			<translation>Căutare</translation>
		</message>
		<message>
			<source>tooltip_btn_search</source>
			<translation>btn_search</translation>
		</message>
		<message>
			<source>chk_all</source>
			<translation>Verificați toate</translation>
		</message>
		<message>
			<source>tooltip_chk_all</source>
			<translation>chk_all</translation>
		</message>
		<message>
			<source>chk_am_dialogs</source>
			<translation>Verificarea tabelelor am</translation>
		</message>
		<message>
			<source>tooltip_chk_am_dialogs</source>
			<translation>chk_am_dialogs</translation>
		</message>
		<message>
			<source>chk_cm_dialogs</source>
			<translation>Verificarea tabelelor cm</translation>
		</message>
		<message>
			<source>tooltip_chk_cm_dialogs</source>
			<translation>chk_cm_dialogs</translation>
		</message>
		<message>
			<source>chk_db_dialogs</source>
			<translation>Dialoguri de verificare pentru tabelele DB</translation>
		</message>
		<message>
			<source>tooltip_chk_db_dialogs</source>
			<translation>chk_db_dialogs</translation>
		</message>
		<message>
			<source>chk_for_su_tables</source>
			<translation>Verificarea tabelelor DB de bază (cat_feature...)</translation>
		</message>
		<message>
			<source>tooltip_chk_for_su_tables</source>
			<translation>chk_for_su_tables</translation>
		</message>
		<message>
			<source>chk_py_dialogs</source>
			<translation>Verificare pentru dialogurile PY</translation>
		</message>
		<message>
			<source>tooltip_chk_py_dialogs</source>
			<translation>chk_py_dialogs</translation>
		</message>
		<message>
			<source>chk_py_messages</source>
			<translation>Verificarea mesajelor PY</translation>
		</message>
		<message>
			<source>tooltip_chk_py_messages</source>
			<translation>chk_py_messages</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_manager</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_manager</source>
			<translation>dlg_admin_i18n_manager</translation>
		</message>
		<message>
			<source>grb_i18n_conn</source>
			<translation>Conecția i18n</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n_conn</source>
			<translation>grb_i18n_conn</translation>
		</message>
		<message>
			<source>grp_search_options</source>
			<translation>Opțiuni de căutare</translation>
		</message>
		<message>
			<source>tooltip_grp_search_options</source>
			<translation>grp_search_options</translation>
		</message>
		<message>
			<source>lbl_database</source>
			<translation>Baza de date:</translation>
		</message>
		<message>
			<source>tooltip_lbl_database</source>
			<translation>lbl_database</translation>
		</message>
		<message>
			<source>lbl_host</source>
			<translation>Invitat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_host</source>
			<translation>lbl_host</translation>
		</message>
		<message>
			<source>lbl_pass</source>
			<translation>Parolă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pass</source>
			<translation>lbl_pass</translation>
		</message>
		<message>
			<source>lbl_port</source>
			<translation>Port:</translation>
		</message>
		<message>
			<source>tooltip_lbl_port</source>
			<translation>lbl_port</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Utilizator:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
	</context>
	<context>
		<name>admin_import_osm</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Executare</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_admin_import_osm</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_import_osm</source>
			<translation>dlg_admin_import_osm</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Municipalități</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Jurnale</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>admin_manage_schemas</name>
		<message>
			<source>title</source>
			<translation>Manage schemas</translation>
		</message>
		<message>
			<source>btn_activate_audit</source>
			<translation>Activate</translation>
		</message>
		<message>
			<source>tooltip_btn_activate_audit</source>
			<translation>Generate a copy of network layers from the anchor schema into audit</translation>
		</message>
		<message>
			<source>btn_cibs_copy</source>
			<translation>Copy data</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_copy</source>
			<translation>btn_cibs_copy</translation>
		</message>
		<message>
			<source>btn_cibs_create</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_create</source>
			<translation>btn_cibs_create</translation>
		</message>
		<message>
			<source>btn_cibs_integrate</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_integrate</source>
			<translation>Link cibs to the selected network schema</translation>
		</message>
		<message>
			<source>btn_cibs_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_cibs_update</source>
			<translation>btn_cibs_update</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Close</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_cm_integrate</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_integrate</source>
			<translation>Link CM to the selected network schema</translation>
		</message>
		<message>
			<source>btn_cm_qgis</source>
			<translation>btn_cm_qgis</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_qgis</source>
			<translation>Create pschema qgis file</translation>
		</message>
		<message>
			<source>btn_cm_sample</source>
			<translation>Sample</translation>
		</message>
		<message>
			<source>tooltip_btn_cm_sample</source>
			<translation>Load CM example data for the selected network schema</translation>
		</message>
		<message>
			<source>btn_create_am</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_create_am</source>
			<translation>btn_create_am</translation>
		</message>
		<message>
			<source>btn_create_audit</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_create_audit</source>
			<translation>btn_create_audit</translation>
		</message>
		<message>
			<source>btn_create_cm</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cm</source>
			<translation>btn_create_cm</translation>
		</message>
		<message>
			<source>btn_delete_am</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_am</source>
			<translation>btn_delete_am</translation>
		</message>
		<message>
			<source>btn_delete_audit</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_audit</source>
			<translation>btn_delete_audit</translation>
		</message>
		<message>
			<source>btn_delete_cm</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_cm</source>
			<translation>btn_delete_cm</translation>
		</message>
		<message>
			<source>btn_i18n_create</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_create</source>
			<translation>btn_i18n_create</translation>
		</message>
		<message>
			<source>btn_i18n_delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_delete</source>
			<translation>btn_i18n_delete</translation>
		</message>
		<message>
			<source>btn_i18n_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n_update</source>
			<translation>btn_i18n_update</translation>
		</message>
		<message>
			<source>btn_integrate_am</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_integrate_am</source>
			<translation>Wire am into the selected WS network schema</translation>
		</message>
		<message>
			<source>btn_integrate_am_sample</source>
			<translation>Int. + Sample</translation>
		</message>
		<message>
			<source>tooltip_btn_integrate_am_sample</source>
			<translation>Integrate am and seed config from parent WS catalogs</translation>
		</message>
		<message>
			<source>btn_languages</source>
			<translation>Languages</translation>
		</message>
		<message>
			<source>tooltip_btn_languages</source>
			<translation>btn_languages</translation>
		</message>
		<message>
			<source>btn_network_delete</source>
			<translation>Delete</translation>
		</message>
		<message>
			<source>tooltip_btn_network_delete</source>
			<translation>btn_network_delete</translation>
		</message>
		<message>
			<source>btn_network_rename</source>
			<translation>Rename</translation>
		</message>
		<message>
			<source>tooltip_btn_network_rename</source>
			<translation>btn_network_rename</translation>
		</message>
		<message>
			<source>btn_refresh</source>
			<translation>Refresh</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh</source>
			<translation>btn_refresh</translation>
		</message>
		<message>
			<source>btn_reload_audit_triggers</source>
			<translation>Triggers</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_audit_triggers</source>
			<translation>Refresh audit triggers on the anchor schema</translation>
		</message>
		<message>
			<source>btn_update_am</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_am</source>
			<translation>btn_update_am</translation>
		</message>
		<message>
			<source>btn_update_audit</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_audit</source>
			<translation>btn_update_audit</translation>
		</message>
		<message>
			<source>btn_update_cm</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_update_cm</source>
			<translation>btn_update_cm</translation>
		</message>
		<message>
			<source>btn_update_network</source>
			<translation>Update network</translation>
		</message>
		<message>
			<source>tooltip_btn_update_network</source>
			<translation>Update anchor WS/UD and linked satellites to the plugin version</translation>
		</message>
		<message>
			<source>btn_utils_create</source>
			<translation>Create</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_create</source>
			<translation>btn_utils_create</translation>
		</message>
		<message>
			<source>btn_utils_integrate</source>
			<translation>Integrate</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_integrate</source>
			<translation>Link utils to the selected network schema</translation>
		</message>
		<message>
			<source>btn_utils_update</source>
			<translation>Update</translation>
		</message>
		<message>
			<source>tooltip_btn_utils_update</source>
			<translation>btn_utils_update</translation>
		</message>
		<message>
			<source>dlg_admin_manage_schemas</source>
			<translation>Manage schemas</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_manage_schemas</source>
			<translation>dlg_admin_manage_schemas</translation>
		</message>
		<message>
			<source>grb_am</source>
			<translation>AM</translation>
		</message>
		<message>
			<source>tooltip_grb_am</source>
			<translation>grb_am</translation>
		</message>
		<message>
			<source>grb_audit</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>tooltip_grb_audit</source>
			<translation>grb_audit</translation>
		</message>
		<message>
			<source>grb_cibs</source>
			<translation>Cibs</translation>
		</message>
		<message>
			<source>tooltip_grb_cibs</source>
			<translation>grb_cibs</translation>
		</message>
		<message>
			<source>grb_cm</source>
			<translation>CM</translation>
		</message>
		<message>
			<source>tooltip_grb_cm</source>
			<translation>grb_cm</translation>
		</message>
		<message>
			<source>grb_connection</source>
			<translation>Connection</translation>
		</message>
		<message>
			<source>tooltip_grb_connection</source>
			<translation>grb_connection</translation>
		</message>
		<message>
			<source>grb_i18n</source>
			<translation>Multilang</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n</source>
			<translation>grb_i18n</translation>
		</message>
		<message>
			<source>grb_network</source>
			<translation>Network (WS / UD)</translation>
		</message>
		<message>
			<source>tooltip_grb_network</source>
			<translation>grb_network</translation>
		</message>
		<message>
			<source>grb_utils</source>
			<translation>Utils</translation>
		</message>
		<message>
			<source>tooltip_grb_utils</source>
			<translation>grb_utils</translation>
		</message>
		<message>
			<source>lbl_am_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_am_info</source>
			<translation>lbl_am_info</translation>
		</message>
		<message>
			<source>lbl_audit_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_audit_info</source>
			<translation>lbl_audit_info</translation>
		</message>
		<message>
			<source>lbl_cibs_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_cibs_info</source>
			<translation>lbl_cibs_info</translation>
		</message>
		<message>
			<source>lbl_cm_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_cm_info</source>
			<translation>lbl_cm_info</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Connection name:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_i18n_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_i18n_info</source>
			<translation>lbl_i18n_info</translation>
		</message>
		<message>
			<source>lbl_network_selection</source>
			<translation>Anchor: select a row below</translation>
		</message>
		<message>
			<source>tooltip_lbl_network_selection</source>
			<translation>lbl_network_selection</translation>
		</message>
		<message>
			<source>lbl_utils_info</source>
			<translation>Not installed</translation>
		</message>
		<message>
			<source>tooltip_lbl_utils_info</source>
			<translation>lbl_utils_info</translation>
		</message>
	</context>
	<context>
		<name>admin_markdown</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_generate</source>
			<translation>Generați</translation>
		</message>
		<message>
			<source>tooltip_btn_generate</source>
			<translation>btn_generate</translation>
		</message>
		<message>
			<source>dlg_admin_markdown</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_markdown</source>
			<translation>dlg_admin_markdown</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Tip proiect:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Numele schemei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lb_path</source>
			<translation>Calea fișierului:</translation>
		</message>
		<message>
			<source>tooltip_lb_path</source>
			<translation>lb_path</translation>
		</message>
		<message>
			<source>pushButton_2</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_pushButton_2</source>
			<translation>pushButton_2</translation>
		</message>
	</context>
	<context>
		<name>admin_markdown_generator</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_generate</source>
			<translation>Generați</translation>
		</message>
		<message>
			<source>tooltip_btn_generate</source>
			<translation>btn_generate</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>cmb_projecttype</source>
			<translation>ud</translation>
		</message>
		<message>
			<source>tooltip_cmb_projecttype</source>
			<translation>cmb_projecttype</translation>
		</message>
		<message>
			<source>dlg_admin_markdown_generator</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_markdown_generator</source>
			<translation>dlg_admin_markdown_generator</translation>
		</message>
		<message>
			<source>grp_markdown_destination</source>
			<translation>Destizare Markdown</translation>
		</message>
		<message>
			<source>tooltip_grp_markdown_destination</source>
			<translation>grp_markdown_destination</translation>
		</message>
		<message>
			<source>grp_origin_schema</source>
			<translation>Schema de origine</translation>
		</message>
		<message>
			<source>tooltip_grp_origin_schema</source>
			<translation>grp_origin_schema</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Tip proiect:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Numele schemei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lb_path</source>
			<translation>Calea fișierului:</translation>
		</message>
		<message>
			<source>tooltip_lb_path</source>
			<translation>lb_path</translation>
		</message>
	</context>
	<context>
		<name>admin_projectinfo</name>
		<message>
			<source>title</source>
			<translation>Actualizare SQL</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>dlg_admin_projectinfo</source>
			<translation>Actualizare SQL</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_projectinfo</source>
			<translation>dlg_admin_projectinfo</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Informații despre noile actualizări</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Jurnal</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>tab_main</source>
			<translation>Principală</translation>
		</message>
		<message>
			<source>tooltip_tab_main</source>
			<translation>tab_main</translation>
		</message>
	</context>
	<context>
		<name>admin_renameproj</name>
		<message>
			<source>title</source>
			<translation>Redenumire</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>dlg_admin_renameproj</source>
			<translation>Redenumire</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_renameproj</source>
			<translation>dlg_admin_renameproj</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Vă rugăm să stabiliți un nume de proiect nou:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>lbl_rename_copy</translation>
		</message>
	</context>
	<context>
		<name>admin_translation</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_connection</source>
			<translation>Conexiune de testare</translation>
		</message>
		<message>
			<source>tooltip_btn_connection</source>
			<translation>btn_connection</translation>
		</message>
		<message>
			<source>btn_translate</source>
			<translation>Tradu</translation>
		</message>
		<message>
			<source>tooltip_btn_translate</source>
			<translation>btn_translate</translation>
		</message>
		<message>
			<source>chk_am_files</source>
			<translation>Traduceți fișierele am</translation>
		</message>
		<message>
			<source>tooltip_chk_am_files</source>
			<translation>chk_am_files</translation>
		</message>
		<message>
			<source>chk_audit_files</source>
			<translation>Traducerea fișierelor de audit</translation>
		</message>
		<message>
			<source>tooltip_chk_audit_files</source>
			<translation>chk_audit_files</translation>
		</message>
		<message>
			<source>chk_cm_files</source>
			<translation>Traducere fișiere cm</translation>
		</message>
		<message>
			<source>tooltip_chk_cm_files</source>
			<translation>chk_cm_files</translation>
		</message>
		<message>
			<source>chk_i18n_files</source>
			<translation>Traduceți traducerile i18n</translation>
		</message>
		<message>
			<source>tooltip_chk_i18n_files</source>
			<translation>chk_i18n_files</translation>
		</message>
		<message>
			<source>chk_py_msg</source>
			<translation>Traduceți mesajele ui și py</translation>
		</message>
		<message>
			<source>tooltip_chk_py_msg</source>
			<translation>chk_py_msg</translation>
		</message>
		<message>
			<source>chk_relative_langs</source>
			<translation>Enable fallback to similar locales. </translation>
		</message>
		<message>
			<source>tooltip_chk_relative_langs</source>
			<translation>chk_relative_langs</translation>
		</message>
		<message>
			<source>dlg_admin_translation</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_translation</source>
			<translation>dlg_admin_translation</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Informații de conectare</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Traduceți fișiere</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_3</source>
			<translation>Parameters</translation>
		</message>
		<message>
			<source>tooltip_groupBox_3</source>
			<translation>groupBox_3</translation>
		</message>
		<message>
			<source>label</source>
			<translation>If a translation is missing in the specific target dialect (e.g., es_ES), the system searches other regional variants (e.g., es_CR, es_AR). If a match is found, that translation is applied.</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_database</source>
			<translation>Baza de date:</translation>
		</message>
		<message>
			<source>tooltip_lbl_database</source>
			<translation>lbl_database</translation>
		</message>
		<message>
			<source>lbl_host</source>
			<translation>Invitat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_host</source>
			<translation>lbl_host</translation>
		</message>
		<message>
			<source>lbl_language</source>
			<translation>Limba:</translation>
		</message>
		<message>
			<source>tooltip_lbl_language</source>
			<translation>lbl_language</translation>
		</message>
		<message>
			<source>lbl_pass</source>
			<translation>Parolă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pass</source>
			<translation>lbl_pass</translation>
		</message>
		<message>
			<source>lbl_port</source>
			<translation>Port:</translation>
		</message>
		<message>
			<source>tooltip_lbl_port</source>
			<translation>lbl_port</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Utilizator:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
	</context>
	<context>
		<name>admin_update_translation</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_connection</source>
			<translation>Conexiune de testare</translation>
		</message>
		<message>
			<source>tooltip_btn_connection</source>
			<translation>btn_connection</translation>
		</message>
		<message>
			<source>btn_translate</source>
			<translation>Tradu</translation>
		</message>
		<message>
			<source>tooltip_btn_translate</source>
			<translation>btn_translate</translation>
		</message>
		<message>
			<source>chk_add_tab_data</source>
			<translation>Traducere tab_data</translation>
		</message>
		<message>
			<source>tooltip_chk_add_tab_data</source>
			<translation>chk_add_tab_data</translation>
		</message>
		<message>
			<source>dlg_admin_update_translation</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_update_translation</source>
			<translation>dlg_admin_update_translation</translation>
		</message>
		<message>
			<source>grb_dest_conn</source>
			<translation>Conexiunea cu destinul</translation>
		</message>
		<message>
			<source>tooltip_grb_dest_conn</source>
			<translation>grb_dest_conn</translation>
		</message>
		<message>
			<source>grb_i18n_conn</source>
			<translation>Conecția i18n</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n_conn</source>
			<translation>grb_i18n_conn</translation>
		</message>
		<message>
			<source>grb_parameters</source>
			<translation>Parametrii</translation>
		</message>
		<message>
			<source>tooltip_grb_parameters</source>
			<translation>grb_parameters</translation>
		</message>
		<message>
			<source>lbl_database</source>
			<translation>Baza de date:</translation>
		</message>
		<message>
			<source>tooltip_lbl_database</source>
			<translation>lbl_database</translation>
		</message>
		<message>
			<source>lbl_host</source>
			<translation>Invitat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_host</source>
			<translation>lbl_host</translation>
		</message>
		<message>
			<source>lbl_language</source>
			<translation>Limba:</translation>
		</message>
		<message>
			<source>tooltip_lbl_language</source>
			<translation>lbl_language</translation>
		</message>
		<message>
			<source>lbl_pass</source>
			<translation>Parolă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pass</source>
			<translation>lbl_pass</translation>
		</message>
		<message>
			<source>lbl_port</source>
			<translation>Port:</translation>
		</message>
		<message>
			<source>tooltip_lbl_port</source>
			<translation>lbl_port</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Tip proiect:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Numele schemei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Utilizator:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
	</context>
	<context>
		<name>admin_visitclass</name>
		<message>
			<source>title</source>
			<translation>Gestionați clasa de vizite</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_class_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_class_cancel</source>
			<translation>btn_class_cancel</translation>
		</message>
		<message>
			<source>btn_class_ok</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_class_ok</source>
			<translation>btn_class_ok</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_param_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_param_create</source>
			<translation>btn_param_create</translation>
		</message>
		<message>
			<source>btn_param_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_param_delete</source>
			<translation>btn_param_delete</translation>
		</message>
		<message>
			<source>btn_param_update</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_param_update</source>
			<translation>btn_param_update</translation>
		</message>
		<message>
			<source>dlg_admin_visitclass</source>
			<translation>Gestionați clasa de vizite</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_visitclass</source>
			<translation>dlg_admin_visitclass</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Clasa</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Parametru</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Activ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_class_id</source>
			<translation>Clasa id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_class_id</source>
			<translation>lbl_class_id</translation>
		</message>
		<message>
			<source>lbl_class_name</source>
			<translation>Numele clasei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_class_name</source>
			<translation>lbl_class_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descript:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_feat_type</source>
			<translation>Tip caracteristică:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_type</source>
			<translation>lbl_feat_type</translation>
		</message>
		<message>
			<source>lbl_multi_event</source>
			<translation>Eveniment multiplu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multi_event</source>
			<translation>lbl_multi_event</translation>
		</message>
		<message>
			<source>lbl_multi_feat</source>
			<translation>Caracteristici multiple:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multi_feat</source>
			<translation>lbl_multi_feat</translation>
		</message>
		<message>
			<source>lbl_param_opt</source>
			<translation>Opțiuni param:</translation>
		</message>
		<message>
			<source>tooltip_lbl_param_opt</source>
			<translation>lbl_param_opt</translation>
		</message>
		<message>
			<source>lbl_viewname</source>
			<translation>Vezi numele:</translation>
		</message>
		<message>
			<source>tooltip_lbl_viewname</source>
			<translation>lbl_viewname</translation>
		</message>
		<message>
			<source>lbl_visit_type</source>
			<translation>Tipul vizitei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_type</source>
			<translation>lbl_visit_type</translation>
		</message>
	</context>
	<context>
		<name>admin_visitparam</name>
		<message>
			<source>title</source>
			<translation>Gestionați parametrii vizitei</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_admin_visitparam</source>
			<translation>Gestionați parametrii vizitei</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_visitparam</source>
			<translation>dlg_admin_visitparam</translation>
		</message>
		<message>
			<source>grb_params</source>
			<translation>Parametru</translation>
		</message>
		<message>
			<source>tooltip_grb_params</source>
			<translation>grb_params</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation>Cod:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_data_type</source>
			<translation>Tip de date:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_type</source>
			<translation>lbl_data_type</translation>
		</message>
		<message>
			<source>lbl_default_value</source>
			<translation>Valoarea implicită:</translation>
		</message>
		<message>
			<source>tooltip_lbl_default_value</source>
			<translation>lbl_default_value</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descript:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_editable</source>
			<translation>Editabil:</translation>
		</message>
		<message>
			<source>tooltip_lbl_editable</source>
			<translation>lbl_editable</translation>
		</message>
		<message>
			<source>lbl_enabled</source>
			<translation>Activat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enabled</source>
			<translation>lbl_enabled</translation>
		</message>
		<message>
			<source>lbl_form_type</source>
			<translation>Tip de formular:</translation>
		</message>
		<message>
			<source>tooltip_lbl_form_type</source>
			<translation>lbl_form_type</translation>
		</message>
		<message>
			<source>lbl_mandatory</source>
			<translation>Obligatoriu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mandatory</source>
			<translation>lbl_mandatory</translation>
		</message>
		<message>
			<source>lbl_parameter_name</source>
			<translation>Denumirea parametrului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_name</source>
			<translation>lbl_parameter_name</translation>
		</message>
		<message>
			<source>lbl_parameter_type</source>
			<translation>Tipul parametrului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_type</source>
			<translation>lbl_parameter_type</translation>
		</message>
		<message>
			<source>lbl_query_text</source>
			<translation>Text de interogare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_query_text</source>
			<translation>lbl_query_text</translation>
		</message>
		<message>
			<source>lbl_short_descript</source>
			<translation>Descript pe scurt:</translation>
		</message>
		<message>
			<source>tooltip_lbl_short_descript</source>
			<translation>lbl_short_descript</translation>
		</message>
		<message>
			<source>lbl_widgettype</source>
			<translation>Tip widget:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgettype</source>
			<translation>lbl_widgettype</translation>
		</message>
	</context>
	<context>
		<name>arc_fusion</name>
		<message>
			<source>title</source>
			<translation>Fuziunea arcului</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_arc_fusion</source>
			<translation>Fuziunea arcului</translation>
		</message>
		<message>
			<source>tooltip_dlg_arc_fusion</source>
			<translation>dlg_arc_fusion</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>lbl_arc1asset</source>
			<translation>Arc 1 asset:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc1asset</source>
			<translation>lbl_arc1asset</translation>
		</message>
		<message>
			<source>lbl_arc1cat</source>
			<translation>Catalog Arc 1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc1cat</source>
			<translation>lbl_arc1cat</translation>
		</message>
		<message>
			<source>lbl_arc2asset</source>
			<translation>Arc 2 asset:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc2asset</source>
			<translation>lbl_arc2asset</translation>
		</message>
		<message>
			<source>lbl_arc2cat</source>
			<translation>Catalog Arc 2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc2cat</source>
			<translation>lbl_arc2cat</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Data de încheiere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_new_asset</source>
			<translation>New asset:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_asset</source>
			<translation>lbl_new_asset</translation>
		</message>
		<message>
			<source>lbl_new_cat</source>
			<translation>Catalog nou:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_cat</source>
			<translation>lbl_new_cat</translation>
		</message>
		<message>
			<source>lbl_nodeaction</source>
			<translation>Acțiunea nodului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodeaction</source>
			<translation>lbl_nodeaction</translation>
		</message>
		<message>
			<source>lbl_statetype</source>
			<translation>Tipul de stat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_statetype</source>
			<translation>lbl_statetype</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Workcat id end:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Fuziunea arcului</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>assignation</name>
		<message>
			<source>title</source>
			<translation>Repartizarea repartizării</translation>
		</message>
		<message>
			<source>chk_all_leaks</source>
			<translation>Utilizați toate scurgerile</translation>
		</message>
		<message>
			<source>tooltip_chk_all_leaks</source>
			<translation>Calculates leaks per kilometer per year using all available data, regardless of the &apos;years to calculate&apos; parameter.</translation>
		</message>
		<message>
			<source>dlg_assignation</source>
			<translation>Repartizarea repartizării</translation>
		</message>
		<message>
			<source>tooltip_dlg_assignation</source>
			<translation>dlg_assignation</translation>
		</message>
		<message>
			<source>lbl_buffer</source>
			<translation>Distanța tampon (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_buffer</source>
			<translation>Distance from a leak at which pipes are selected to be assigned that leak.</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Filtrați în funcție de data construirii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>Uses only pipes that match the builtdate range of the initial one.</translation>
		</message>
		<message>
			<source>lbl_builtdate_range</source>
			<translation>Intervalul de date construit (ani):</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate_range</source>
			<translation>Built date range, in years before and after the initial pipe.</translation>
		</message>
		<message>
			<source>lbl_cluster_length</source>
			<translation>Lungimea clusterelor (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_cluster_length</source>
			<translation>Maximum sum of pipe lengths within a cluster, in meters.</translation>
		</message>
		<message>
			<source>lbl_diameter</source>
			<translation>Filtrați după diametru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_diameter</source>
			<translation>Uses only pipes that match the diameter range of the initial one.</translation>
		</message>
		<message>
			<source>lbl_diameter_range</source>
			<translation>Gama de diametre:</translation>
		</message>
		<message>
			<source>tooltip_lbl_diameter_range</source>
			<translation>Diameter range based on factors of the initial pipe.</translation>
		</message>
		<message>
			<source>lbl_leaks</source>
			<translation>Scurgeri</translation>
		</message>
		<message>
			<source>tooltip_lbl_leaks</source>
			<translation>lbl_leaks</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Filtrați după material:</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>Uses only pipes of the same material as the initial one.</translation>
		</message>
		<message>
			<source>lbl_max_distance</source>
			<translation>Distanța maximă (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_max_distance</source>
			<translation>Maximum distance, in meters, between the initial pipe and other pipes included in the cluster.</translation>
		</message>
		<message>
			<source>lbl_pipes</source>
			<translation>Țevi</translation>
		</message>
		<message>
			<source>tooltip_lbl_pipes</source>
			<translation>lbl_pipes</translation>
		</message>
		<message>
			<source>lbl_years</source>
			<translation>Ani de calculat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_years</source>
			<translation>Number of years of leak data to consider, based on recency.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>audit</name>
		<message>
			<source>title</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>dlg_audit</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>tooltip_dlg_audit</source>
			<translation>dlg_audit</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Valori actualizate</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
	</context>
	<context>
		<name>audit_manager</name>
		<message>
			<source>title</source>
			<translation>Manager de audit</translation>
		</message>
		<message>
			<source>dlg_audit_manager</source>
			<translation>Manager de audit</translation>
		</message>
		<message>
			<source>tooltip_dlg_audit_manager</source>
			<translation>Manager de audit</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Jurnale</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Jurnale</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Data până la</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Data până la</translation>
		</message>
	</context>
	<context>
		<name>auxcircle</name>
		<message>
			<source>title</source>
			<translation>CAD Desenați un cerc</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_delete_prev</source>
			<translation>Ștergeți cercurile anterioare</translation>
		</message>
		<message>
			<source>tooltip_chk_delete_prev</source>
			<translation>chk_delete_prev</translation>
		</message>
		<message>
			<source>dlg_auxcircle</source>
			<translation>CAD Desenați un cerc</translation>
		</message>
		<message>
			<source>tooltip_dlg_auxcircle</source>
			<translation>dlg_auxcircle</translation>
		</message>
		<message>
			<source>lbl_ins_radius</source>
			<translation>Raza de inserție:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ins_radius</source>
			<translation>lbl_ins_radius</translation>
		</message>
		<message>
			<source>radius</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_radius</source>
			<translation>radius</translation>
		</message>
	</context>
	<context>
		<name>auxpoint</name>
		<message>
			<source>title</source>
			<translation>CAD Punct de adăugare</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_delete_prev</source>
			<translation>Ștergeți punctele anterioare</translation>
		</message>
		<message>
			<source>tooltip_chk_delete_prev</source>
			<translation>chk_delete_prev</translation>
		</message>
		<message>
			<source>dist_x</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_dist_x</source>
			<translation>dist_x</translation>
		</message>
		<message>
			<source>dist_y</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_dist_y</source>
			<translation>dist_y</translation>
		</message>
		<message>
			<source>dlg_auxpoint</source>
			<translation>CAD Punct de adăugare</translation>
		</message>
		<message>
			<source>tooltip_dlg_auxpoint</source>
			<translation>dlg_auxpoint</translation>
		</message>
		<message>
			<source>grb_from</source>
			<translation>De la:</translation>
		</message>
		<message>
			<source>tooltip_grb_from</source>
			<translation>grb_from</translation>
		</message>
		<message>
			<source>lbl_distx</source>
			<translation>Distanța (X):</translation>
		</message>
		<message>
			<source>tooltip_lbl_distx</source>
			<translation>lbl_distx</translation>
		</message>
		<message>
			<source>lbl_disty</source>
			<translation>Distanța (Y):</translation>
		</message>
		<message>
			<source>tooltip_lbl_disty</source>
			<translation>lbl_disty</translation>
		</message>
		<message>
			<source>rb_left</source>
			<translation>Punct init</translation>
		</message>
		<message>
			<source>tooltip_rb_left</source>
			<translation>rb_left</translation>
		</message>
		<message>
			<source>rb_right</source>
			<translation>Punct final</translation>
		</message>
		<message>
			<source>tooltip_rb_right</source>
			<translation>rb_right</translation>
		</message>
	</context>
	<context>
		<name>campaign_management</name>
		<message>
			<source>title</source>
			<translation>Managementul campaniei</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_delete</source>
			<translation>Ștergeți campania</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_delete</source>
			<translation>Ștergeți campania</translation>
		</message>
		<message>
			<source>campaign_btn_open</source>
			<translation>Campanie deschisă</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_open</source>
			<translation>Campanie deschisă</translation>
		</message>
		<message>
			<source>campaign_chk_show_nulls</source>
			<translation>Afișați valorile nule</translation>
		</message>
		<message>
			<source>tooltip_campaign_chk_show_nulls</source>
			<translation>Afișați valorile goale</translation>
		</message>
		<message>
			<source>dlg_campaign_management</source>
			<translation>Managementul campaniei</translation>
		</message>
		<message>
			<source>tooltip_dlg_campaign_management</source>
			<translation>Gestionarea campaniilor</translation>
		</message>
		<message>
			<source>lbl_column_filter_dates</source>
			<translation>Filtrați coloana de date</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter_dates</source>
			<translation>Filtrați coloana de date:</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>De la:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>De la:</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Până la:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>Pentru:</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Stat</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Stat:</translation>
		</message>
	</context>
	<context>
		<name>check_project</name>
		<message>
			<source>title</source>
			<translation>Verificați proiectul</translation>
		</message>
		<message>
			<source>brb_database_check</source>
			<translation>Verificarea stării bazei de date:</translation>
		</message>
		<message>
			<source>tooltip_brb_database_check</source>
			<translation>brb_database_check</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_check_project</source>
			<translation>Verificați proiectul</translation>
		</message>
		<message>
			<source>tooltip_dlg_check_project</source>
			<translation>dlg_check_project</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_system_check</source>
			<translation>Verificarea stării sistemului:</translation>
		</message>
		<message>
			<source>tooltip_grb_system_check</source>
			<translation>grb_system_check</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Jurnalul bazei de date</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Jurnale</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>check_project_cm</name>
		<message>
			<source>title</source>
			<translation>Verificați proiectul</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>chk_manage_config</source>
			<translation>Verificarea configurațiilor de gestionare</translation>
		</message>
		<message>
			<source>tooltip_chk_manage_config</source>
			<translation>chk_manage_config</translation>
		</message>
		<message>
			<source>dlg_check_project_cm</source>
			<translation>Verificați proiectul</translation>
		</message>
		<message>
			<source>tooltip_dlg_check_project_cm</source>
			<translation>dlg_check_project_cm</translation>
		</message>
		<message>
			<source>grb_database_health_check</source>
			<translation>Verificarea stării bazei de date</translation>
		</message>
		<message>
			<source>tooltip_grb_database_health_check</source>
			<translation>grb_database_health_check</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_system_health_check</source>
			<translation>Verificarea stării sistemului</translation>
		</message>
		<message>
			<source>tooltip_grb_system_health_check</source>
			<translation>grb_system_health_check</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Jurnalul bazei de date</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Jurnale</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>common</name>
		<message>
			<source>btn_help</source>
			<translation>Ajutor</translation>
		</message>
		<message>
			<source>tooltip_btn_help</source>
			<translation>Ajutor</translation>
		</message>
	</context>
	<context>
		<name>config</name>
		<message>
			<source>title</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_dlg_config</source>
			<translation>dlg_config</translation>
		</message>
		<message>
			<source>grb_addfields</source>
			<translation>Câmpuri adăugate</translation>
		</message>
		<message>
			<source>tooltip_grb_addfields</source>
			<translation>grb_addfields</translation>
		</message>
		<message>
			<source>grb_admin_om</source>
			<translation>O&amp;&amp;M</translation>
		</message>
		<message>
			<source>tooltip_grb_admin_om</source>
			<translation>grb_admin_om</translation>
		</message>
		<message>
			<source>grb_admin_other</source>
			<translation>Altele</translation>
		</message>
		<message>
			<source>tooltip_grb_admin_other</source>
			<translation>grb_admin_other</translation>
		</message>
		<message>
			<source>grb_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_grb_arc</source>
			<translation>grb_arc</translation>
		</message>
		<message>
			<source>grb_basic</source>
			<translation>De bază</translation>
		</message>
		<message>
			<source>tooltip_grb_basic</source>
			<translation>grb_basic</translation>
		</message>
		<message>
			<source>grb_category_type</source>
			<translation>Tip de categorie</translation>
		</message>
		<message>
			<source>tooltip_grb_category_type</source>
			<translation>grb_category_type</translation>
		</message>
		<message>
			<source>grb_connec</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>tooltip_grb_connec</source>
			<translation>grb_connec</translation>
		</message>
		<message>
			<source>grb_epa</source>
			<translation>Epa</translation>
		</message>
		<message>
			<source>tooltip_grb_epa</source>
			<translation>grb_epa</translation>
		</message>
		<message>
			<source>grb_fluid_type</source>
			<translation>Tipul de lichid</translation>
		</message>
		<message>
			<source>tooltip_grb_fluid_type</source>
			<translation>grb_fluid_type</translation>
		</message>
		<message>
			<source>grb_function_type</source>
			<translation>Tip de funcție</translation>
		</message>
		<message>
			<source>tooltip_grb_function_type</source>
			<translation>grb_function_type</translation>
		</message>
		<message>
			<source>grb_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_grb_gully</source>
			<translation>grb_gully</translation>
		</message>
		<message>
			<source>grb_inventory</source>
			<translation>Inventar</translation>
		</message>
		<message>
			<source>tooltip_grb_inventory</source>
			<translation>grb_inventory</translation>
		</message>
		<message>
			<source>grb_link</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>tooltip_grb_link</source>
			<translation>grb_link</translation>
		</message>
		<message>
			<source>grb_location_type</source>
			<translation>Tip locație</translation>
		</message>
		<message>
			<source>tooltip_grb_location_type</source>
			<translation>grb_location_type</translation>
		</message>
		<message>
			<source>grb_masterplan</source>
			<translation>MasterPlan</translation>
		</message>
		<message>
			<source>tooltip_grb_masterplan</source>
			<translation>grb_masterplan</translation>
		</message>
		<message>
			<source>grb_node</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>tooltip_grb_node</source>
			<translation>grb_node</translation>
		</message>
		<message>
			<source>grb_om</source>
			<translation>O&amp;&amp;M</translation>
		</message>
		<message>
			<source>tooltip_grb_om</source>
			<translation>grb_om</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Altele</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_system</source>
			<translation>Sistemul</translation>
		</message>
		<message>
			<source>tooltip_grb_system</source>
			<translation>grb_system</translation>
		</message>
		<message>
			<source>grb_topology</source>
			<translation>Topologie</translation>
		</message>
		<message>
			<source>tooltip_grb_topology</source>
			<translation>grb_topology</translation>
		</message>
		<message>
			<source>grb_utils</source>
			<translation>Utilități</translation>
		</message>
		<message>
			<source>tooltip_grb_utils</source>
			<translation>grb_utils</translation>
		</message>
		<message>
			<source>tab_addfields</source>
			<translation>Câmpuri adăugate</translation>
		</message>
		<message>
			<source>tooltip_tab_addfields</source>
			<translation>tab_addfields</translation>
		</message>
		<message>
			<source>tab_admin</source>
			<translation>Administrator</translation>
		</message>
		<message>
			<source>tooltip_tab_admin</source>
			<translation>tab_admin</translation>
		</message>
		<message>
			<source>tab_basic</source>
			<translation>De bază</translation>
		</message>
		<message>
			<source>tooltip_tab_basic</source>
			<translation>tab_basic</translation>
		</message>
		<message>
			<source>tab_featurecat</source>
			<translation>Featurecat</translation>
		</message>
		<message>
			<source>tooltip_tab_featurecat</source>
			<translation>tab_featurecat</translation>
		</message>
		<message>
			<source>tab_mantype</source>
			<translation>Tipul de om</translation>
		</message>
		<message>
			<source>tooltip_tab_mantype</source>
			<translation>tab_mantype</translation>
		</message>
	</context>
	<context>
		<name>connect_link</name>
		<message>
			<source>title</source>
			<translation>Conectare la rețea</translation>
		</message>
		<message>
			<source>dlg_connect_link</source>
			<translation>Conectare la rețea</translation>
		</message>
		<message>
			<source>tooltip_dlg_connect_link</source>
			<translation>dlg_connect_link</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Configurarea legăturii</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Conexiuni</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_3</source>
			<translation>Arce</translation>
		</message>
		<message>
			<source>tooltip_groupBox_3</source>
			<translation>groupBox_3</translation>
		</message>
		<message>
			<source>tab_connect</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>tooltip_tab_connect</source>
			<translation>tab_connect</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>csv</name>
		<message>
			<source>title</source>
			<translation>Import CSV</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>btn_file_csv</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_csv</source>
			<translation>btn_file_csv</translation>
		</message>
		<message>
			<source>dlg_csv</source>
			<translation>Import CSV</translation>
		</message>
		<message>
			<source>tooltip_dlg_csv</source>
			<translation>dlg_csv</translation>
		</message>
		<message>
			<source>lbl_decimal</source>
			<translation>Separator zecimal:</translation>
		</message>
		<message>
			<source>tooltip_lbl_decimal</source>
			<translation>lbl_decimal</translation>
		</message>
		<message>
			<source>lbl_delimiter</source>
			<translation>Delimitator:</translation>
		</message>
		<message>
			<source>tooltip_lbl_delimiter</source>
			<translation>lbl_delimiter</translation>
		</message>
		<message>
			<source>lbl_file</source>
			<translation>Fișier:</translation>
		</message>
		<message>
			<source>tooltip_lbl_file</source>
			<translation>lbl_file</translation>
		</message>
		<message>
			<source>lbl_ignore_header</source>
			<translation>Ignorați anteturile:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ignore_header</source>
			<translation>lbl_ignore_header</translation>
		</message>
		<message>
			<source>lbl_import_label</source>
			<translation>Etichetă de import:</translation>
		</message>
		<message>
			<source>tooltip_lbl_import_label</source>
			<translation>lbl_import_label</translation>
		</message>
		<message>
			<source>lbl_import_type</source>
			<translation>Tip de import:</translation>
		</message>
		<message>
			<source>tooltip_lbl_import_type</source>
			<translation>lbl_import_type</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_set_of_charac</source>
			<translation>Set de caractere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_set_of_charac</source>
			<translation>lbl_set_of_charac</translation>
		</message>
		<message>
			<source>rb_comma</source>
			<translation>,</translation>
		</message>
		<message>
			<source>tooltip_rb_comma</source>
			<translation>rb_comma</translation>
		</message>
		<message>
			<source>rb_dec_comma</source>
			<translation>,</translation>
		</message>
		<message>
			<source>tooltip_rb_dec_comma</source>
			<translation>rb_dec_comma</translation>
		</message>
		<message>
			<source>rb_dec_period</source>
			<translation>.</translation>
		</message>
		<message>
			<source>tooltip_rb_dec_period</source>
			<translation>rb_dec_period</translation>
		</message>
		<message>
			<source>rb_semicolon</source>
			<translation>;</translation>
		</message>
		<message>
			<source>tooltip_rb_semicolon</source>
			<translation>rb_semicolon</translation>
		</message>
		<message>
			<source>rb_space</source>
			<translation>Spațiu</translation>
		</message>
		<message>
			<source>tooltip_rb_space</source>
			<translation>rb_space</translation>
		</message>
		<message>
			<source>tab_info</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_info</source>
			<translation>tab_info</translation>
		</message>
		<message>
			<source>tab_preview</source>
			<translation>Previzualizare</translation>
		</message>
		<message>
			<source>tooltip_tab_preview</source>
			<translation>tab_preview</translation>
		</message>
	</context>
	<context>
		<name>dimensioning</name>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>grb_depth</source>
			<translation>Măsurători</translation>
		</message>
		<message>
			<source>tooltip_grb_depth</source>
			<translation>grb_depth</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Altele</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_symbology</source>
			<translation>Simbologia cercului</translation>
		</message>
		<message>
			<source>tooltip_grb_symbology</source>
			<translation>grb_symbology</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>bara de instrumente</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>doc</name>
		<message>
			<source>title</source>
			<translation>Document</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Adăugați geom</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>Adăugați geom</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Aplicați</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>Aplicați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_path_doc</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path_doc</source>
			<translation>btn_path_doc</translation>
		</message>
		<message>
			<source>btn_path_url</source>
			<translation>web</translation>
		</message>
		<message>
			<source>tooltip_btn_path_url</source>
			<translation>Deschideți Explorer pentru a permite selectarea căii web. De asemenea, este posibil să lipiți pur și simplu calea în caseta de text Link</translation>
		</message>
		<message>
			<source>date</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date</source>
			<translation>date</translation>
		</message>
		<message>
			<source>dlg_doc</source>
			<translation>Document</translation>
		</message>
		<message>
			<source>tooltip_dlg_doc</source>
			<translation>dlg_doc</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Data:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_doc_name</source>
			<translation>Nume doc:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_name</source>
			<translation>lbl_doc_name</translation>
		</message>
		<message>
			<source>lbl_doc_type</source>
			<translation>Tip doc:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_type</source>
			<translation>lbl_doc_type</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Link:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observații:</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Vizită</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_doc</source>
			<translation>Document</translation>
		</message>
		<message>
			<source>tooltip_tab_doc</source>
			<translation>tab_doc</translation>
		</message>
		<message>
			<source>tab_elem</source>
			<translation>Element</translation>
		</message>
		<message>
			<source>tooltip_tab_elem</source>
			<translation>tab_elem</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_psector</source>
			<translation>Psector</translation>
		</message>
		<message>
			<source>tooltip_tab_psector</source>
			<translation>tab_psector</translation>
		</message>
		<message>
			<source>tab_rel</source>
			<translation>Relații</translation>
		</message>
		<message>
			<source>tooltip_tab_rel</source>
			<translation>tab_rel</translation>
		</message>
		<message>
			<source>tab_workcat</source>
			<translation>Pisica de lucru</translation>
		</message>
		<message>
			<source>tooltip_tab_workcat</source>
			<translation>tab_workcat</translation>
		</message>
	</context>
	<context>
		<name>doc_manager</name>
		<message>
			<source>title</source>
			<translation>Gestionarea documentelor</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_doc_manager</source>
			<translation>Gestionarea documentelor</translation>
		</message>
		<message>
			<source>tooltip_dlg_doc_manager</source>
			<translation>dlg_doc_manager</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtrați după: Numele medicului</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>dscenario</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_properties</source>
			<translation>Proprietăți</translation>
		</message>
		<message>
			<source>tooltip_btn_properties</source>
			<translation>btn_properties</translation>
		</message>
		<message>
			<source>dlg_dscenario</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_dscenario</source>
			<translation>dlg_dscenario</translation>
		</message>
	</context>
	<context>
		<name>dscenario_manager</name>
		<message>
			<source>title</source>
			<translation>Dscenario manager</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>     Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplicat</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Comutare activă</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Comutare activă</translation>
		</message>
		<message>
			<source>btn_toolbox</source>
			<translation>Acțiuni</translation>
		</message>
		<message>
			<source>tooltip_btn_toolbox</source>
			<translation>btn_toolbox</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>btn_update_dscenario</source>
			<translation>Scenariul actual</translation>
		</message>
		<message>
			<source>tooltip_btn_update_dscenario</source>
			<translation>btn_update_dscenario</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Arată inactiv</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Arată inactiv</translation>
		</message>
		<message>
			<source>dlg_dscenario_manager</source>
			<translation>Dscenario manager</translation>
		</message>
		<message>
			<source>tooltip_dlg_dscenario_manager</source>
			<translation>dlg_dscenario_manager</translation>
		</message>
		<message>
			<source>lbl_dscenario_name</source>
			<translation>Filtrare prin: Numele Dscenario</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario_name</source>
			<translation>lbl_dscenario_name</translation>
		</message>
	</context>
	<context>
		<name>element_manager</name>
		<message>
			<source>title</source>
			<translation>Gestionarea elementelor</translation>
		</message>
		<message>
			<source>dlg_element_manager</source>
			<translation>Gestionarea elementelor</translation>
		</message>
		<message>
			<source>tooltip_dlg_element_manager</source>
			<translation>dlg_element_manager</translation>
		</message>
	</context>
	<context>
		<name>epa_export</name>
		<message>
			<source>title</source>
			<translation>Export EPA Result Families</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Accept</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_browse</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_browse</source>
			<translation>btn_browse</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Cancel</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_format_json</source>
			<translation>Format Json</translation>
		</message>
		<message>
			<source>tooltip_chk_format_json</source>
			<translation>chk_format_json</translation>
		</message>
		<message>
			<source>dlg_epa_export</source>
			<translation>Export EPA Result Families</translation>
		</message>
		<message>
			<source>tooltip_dlg_epa_export</source>
			<translation>dlg_epa_export</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Export path:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Result ID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
	</context>
	<context>
		<name>epatools_add_demand_check</name>
		<message>
			<source>title</source>
			<translation>Verificarea cererii suplimentare</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_add_demand_check</source>
			<translation>Verificarea cererii suplimentare</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_add_demand_check</source>
			<translation>dlg_epatools_add_demand_check</translation>
		</message>
		<message>
			<source>lbl_config</source>
			<translation>Fișier de configurare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config</source>
			<translation>lbl_config</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Numele fișierului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Fișier INP de intrare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Utilizați noduri de la:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Dosar de ieșire:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>rdb_nodes_config</source>
			<translation>Fișier de configurare</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_config</source>
			<translation>Retrieve node data from the &amp;quot;nodes&amp;quot; property within the configuration file.</translation>
		</message>
		<message>
			<source>rdb_nodes_database</source>
			<translation>Baza de date</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_database</source>
			<translation>Retrieve node data with fid=491 from the anl_node table.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_emitter_calibration</name>
		<message>
			<source>title</source>
			<translation>Calibrarea emițătorului</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_emitter_calibration</source>
			<translation>Calibrarea emițătorului</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_emitter_calibration</source>
			<translation>dlg_epatools_emitter_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Fișier de configurare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Numele fișierului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Fișier INP de intrare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_filename</source>
			<translation>Numele fișierelor de ieșire:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_filename</source>
			<translation>lbl_output_filename</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>epatools_quantized_demands</name>
		<message>
			<source>title</source>
			<translation>Cereri cuantificate</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_quantized_demands</source>
			<translation>Cereri cuantificate</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_quantized_demands</source>
			<translation>dlg_epatools_quantized_demands</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Fișier de configurare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Numele fișierului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Fișier INP de intrare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Dosar de ieșire:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_recursive_go2epa</name>
		<message>
			<source>title</source>
			<translation>Epa Apeluri multiple</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_recursive_go2epa</source>
			<translation>Epa Apeluri multiple</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_recursive_go2epa</source>
			<translation>dlg_epatools_recursive_go2epa</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Fișier de configurare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Numele fișierului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Dosar de ieșire:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_static_calibration</name>
		<message>
			<source>title</source>
			<translation>Calibrare statică</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>btn_save_dscenario</source>
			<translation>Salvați modificările în dscenario</translation>
		</message>
		<message>
			<source>tooltip_btn_save_dscenario</source>
			<translation>btn_save_dscenario</translation>
		</message>
		<message>
			<source>dlg_epatools_static_calibration</source>
			<translation>Calibrare statică</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_static_calibration</source>
			<translation>dlg_epatools_static_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Fișier de configurare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>The .ini file with the calibrations to make</translation>
		</message>
		<message>
			<source>lbl_dscenario</source>
			<translation>Scenariu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario</source>
			<translation>lbl_dscenario</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Numele fișierului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_inp_input_file</source>
			<translation>Fișier INP de intrare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_input_file</source>
			<translation>The EPANET file to calibrate</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Dosar de ieșire:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_valve_operation_check</name>
		<message>
			<source>title</source>
			<translation>Verificarea funcționării supapei</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_valve_operation_check</source>
			<translation>Verificarea funcționării supapei</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_valve_operation_check</source>
			<translation>dlg_epatools_valve_operation_check</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Fișier de configurare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Numele fișierului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Fișier INP de intrare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Dosar de ieșire:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>lbl_scenarios</source>
			<translation>Utilizați scenarii din:</translation>
		</message>
		<message>
			<source>tooltip_lbl_scenarios</source>
			<translation>lbl_scenarios</translation>
		</message>
		<message>
			<source>rdb_scenarios_config</source>
			<translation>Fișier de configurare</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_config</source>
			<translation>Retrieve scenarios data from the [SCENARIOS] section within the configuration file.</translation>
		</message>
		<message>
			<source>rdb_scenarios_database</source>
			<translation>Baza de date</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_database</source>
			<translation>Retrieve scenarios data with fid=493 from the anl_arc table.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>feature_delete</name>
		<message>
			<source>title</source>
			<translation>Ștergeți caracteristica</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>       Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți caracteristica selectată</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>btn_delete_another</source>
			<translation>Ștergeți o altă caracteristică</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_another</source>
			<translation>btn_delete_another</translation>
		</message>
		<message>
			<source>btn_relations</source>
			<translation>Afișați relațiile dintre caracteristici</translation>
		</message>
		<message>
			<source>tooltip_btn_relations</source>
			<translation>btn_relations</translation>
		</message>
		<message>
			<source>dlg_feature_delete</source>
			<translation>Ștergeți caracteristica</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_delete</source>
			<translation>dlg_feature_delete</translation>
		</message>
		<message>
			<source>lbl_feature_id</source>
			<translation>Caracteristică id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_id</source>
			<translation>lbl_feature_id</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Tip caracteristică:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>tab_del_feature</source>
			<translation>Ștergeți caracteristica</translation>
		</message>
		<message>
			<source>tooltip_tab_del_feature</source>
			<translation>tab_del_feature</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>feature_end</name>
		<message>
			<source>title</source>
			<translation>Caracteristică finală</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>btn_new_workcat</source>
			<translation>btn_new_workcat</translation>
		</message>
		<message>
			<source>tooltip_btn_new_workcat</source>
			<translation>btn_new_workcat</translation>
		</message>
		<message>
			<source>builtdate</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_builtdate</source>
			<translation>builtdate</translation>
		</message>
		<message>
			<source>dlg_feature_end</source>
			<translation>Caracteristică finală</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_end</source>
			<translation>dlg_feature_end</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Data de încheiere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_state_type</source>
			<translation>Sfârșit de tip stat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state_type</source>
			<translation>lbl_state_type</translation>
		</message>
		<message>
			<source>lbl_workcat_date</source>
			<translation>Data Workcat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_date</source>
			<translation>lbl_workcat_date</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Workcat id end:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_elem</source>
			<translation>Elem</translation>
		</message>
		<message>
			<source>tooltip_tab_elem</source>
			<translation>tab_elem</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relații</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Relații</translation>
		</message>
		<message>
			<source>tab_workcat</source>
			<translation>Pisica de lucru</translation>
		</message>
		<message>
			<source>tooltip_tab_workcat</source>
			<translation>tab_workcat</translation>
		</message>
	</context>
	<context>
		<name>feature_end_connec</name>
		<message>
			<source>title</source>
			<translation>Lista finală Workcat</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>dlg_feature_end_connec</source>
			<translation>Lista finală Workcat</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_end_connec</source>
			<translation>dlg_feature_end_connec</translation>
		</message>
		<message>
			<source>lbl_filter_by</source>
			<translation>Filtrați după arc_id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_by</source>
			<translation>lbl_filter_by</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Aceste conexiuni sau rigole vor fi deconectate atunci când arcele selectate sunt șterse</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
	</context>
	<context>
		<name>feature_replace</name>
		<message>
			<source>title</source>
			<translation>Înlocuiți caracteristica</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Bine</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_config</source>
			<translation>config</translation>
		</message>
		<message>
			<source>dlg_feature_replace</source>
			<translation>Înlocuiți caracteristica</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_replace</source>
			<translation>dlg_feature_replace</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>grb_end_parameters</source>
			<translation>Parametrii finali</translation>
		</message>
		<message>
			<source>tooltip_grb_end_parameters</source>
			<translation>grb_end_parameters</translation>
		</message>
		<message>
			<source>grb_feature_parameters</source>
			<translation>Parametrii caracteristicilor</translation>
		</message>
		<message>
			<source>tooltip_grb_feature_parameters</source>
			<translation>grb_feature_parameters</translation>
		</message>
		<message>
			<source>lbl_current_catalog_id</source>
			<translation>ID catalog curent:</translation>
		</message>
		<message>
			<source>tooltip_lbl_current_catalog_id</source>
			<translation>lbl_current_catalog_id</translation>
		</message>
		<message>
			<source>lbl_description</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_description</source>
			<translation>lbl_description</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Data înlocuirii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Tipul curent de caracteristică:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>lbl_keep_asset_id</source>
			<translation>Păstrați id-ul activului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_asset_id</source>
			<translation>lbl_keep_asset_id</translation>
		</message>
		<message>
			<source>lbl_keep_customer_code</source>
			<translation>Keep customer code:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_customer_code</source>
			<translation>lbl_keep_customer_code</translation>
		</message>
		<message>
			<source>lbl_keep_elements</source>
			<translation>Păstrați elementele:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_elements</source>
			<translation>lbl_keep_elements</translation>
		</message>
		<message>
			<source>lbl_keep_epa_values</source>
			<translation>Păstrați valorile EPA:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_epa_values</source>
			<translation>lbl_keep_epa_values</translation>
		</message>
		<message>
			<source>lbl_keep_sys_code</source>
			<translation>Keep sys code:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_sys_code</source>
			<translation>lbl_keep_sys_code</translation>
		</message>
		<message>
			<source>lbl_new_catalog_id</source>
			<translation>Id catalog nou:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_catalog_id</source>
			<translation>lbl_new_catalog_id</translation>
		</message>
		<message>
			<source>lbl_new_feature_type</source>
			<translation>Tip de caracteristică nouă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_feature_type</source>
			<translation>lbl_new_feature_type</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Workcat id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>featuretype_change</name>
		<message>
			<source>title</source>
			<translation>Modificarea tipului de caracteristică</translation>
		</message>
		<message>
			<source>dlg_featuretype_change</source>
			<translation>Modificarea tipului de caracteristică</translation>
		</message>
		<message>
			<source>tooltip_dlg_featuretype_change</source>
			<translation>dlg_featuretype_change</translation>
		</message>
	</context>
	<context>
		<name>go2epa</name>
		<message>
			<source>title</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>btn_file_inp</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_inp</source>
			<translation>btn_file_inp</translation>
		</message>
		<message>
			<source>btn_file_rpt</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_rpt</source>
			<translation>btn_file_rpt</translation>
		</message>
		<message>
			<source>btn_hs_ds</source>
			<translation>Selector</translation>
		</message>
		<message>
			<source>tooltip_btn_hs_ds</source>
			<translation>btn_hs_ds</translation>
		</message>
		<message>
			<source>btn_options</source>
			<translation>Opțiuni</translation>
		</message>
		<message>
			<source>tooltip_btn_options</source>
			<translation>btn_options</translation>
		</message>
		<message>
			<source>chk_exec</source>
			<translation>Executarea software-ului APE</translation>
		</message>
		<message>
			<source>tooltip_chk_exec</source>
			<translation>chk_exec</translation>
		</message>
		<message>
			<source>chk_export</source>
			<translation>Export INP</translation>
		</message>
		<message>
			<source>tooltip_chk_export</source>
			<translation>chk_export</translation>
		</message>
		<message>
			<source>chk_export_subcatch</source>
			<translation>Export subtraversări UD</translation>
		</message>
		<message>
			<source>tooltip_chk_export_subcatch</source>
			<translation>chk_export_subcatch</translation>
		</message>
		<message>
			<source>chk_import_result</source>
			<translation>Rezultatul importului</translation>
		</message>
		<message>
			<source>tooltip_chk_import_result</source>
			<translation>chk_import_result</translation>
		</message>
		<message>
			<source>dlg_go2epa</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa</source>
			<translation>dlg_go2epa</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Opțiuni de preprocesare</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Manager de fișiere</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_inp_file</source>
			<translation>Fișier INP:            </translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_file</source>
			<translation>lbl_inp_file</translation>
		</message>
		<message>
			<source>lbl_result_name</source>
			<translation>Numele rezultatului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name</source>
			<translation>lbl_result_name</translation>
		</message>
		<message>
			<source>lbl_rpt_file</source>
			<translation>RPT file:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rpt_file</source>
			<translation>lbl_rpt_file</translation>
		</message>
		<message>
			<source>tab_file_manager</source>
			<translation>Manager de fișiere</translation>
		</message>
		<message>
			<source>tooltip_tab_file_manager</source>
			<translation>tab_file_manager</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>go2epa_manager</name>
		<message>
			<source>title</source>
			<translation>Manager de rezultate APE</translation>
		</message>
		<message>
			<source>btn_archive</source>
			<translation>Schimbă arhiva</translation>
		</message>
		<message>
			<source>tooltip_btn_archive</source>
			<translation>Schimbă arhiva</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>btn_edit</source>
			<translation>Editare</translation>
		</message>
		<message>
			<source>tooltip_btn_edit</source>
			<translation>Editare</translation>
		</message>
		<message>
			<source>btn_show_inp_data</source>
			<translation>Afișați datele inp</translation>
		</message>
		<message>
			<source>tooltip_btn_show_inp_data</source>
			<translation>Afișați datele inp</translation>
		</message>
		<message>
			<source>btn_toggle_corporate</source>
			<translation>Toggle corporate</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_corporate</source>
			<translation>btn_toggle_corporate</translation>
		</message>
		<message>
			<source>dlg_go2epa_manager</source>
			<translation>Manager de rezultate APE</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_manager</source>
			<translation>dlg_go2epa_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Filtrați după: Id rezultat</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
	</context>
	<context>
		<name>go2epa_options</name>
		<message>
			<source>title</source>
			<translation>Go2Epa - opțiuni</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_go2epa_options</source>
			<translation>Go2Epa - opțiuni</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_options</source>
			<translation>dlg_go2epa_options</translation>
		</message>
		<message>
			<source>grb_energy</source>
			<translation>Energie</translation>
		</message>
		<message>
			<source>tooltip_grb_energy</source>
			<translation>grb_energy</translation>
		</message>
		<message>
			<source>grb_general</source>
			<translation>Generalități</translation>
		</message>
		<message>
			<source>tooltip_grb_general</source>
			<translation>grb_general</translation>
		</message>
		<message>
			<source>grb_hydraulics</source>
			<translation>Hidraulică</translation>
		</message>
		<message>
			<source>tooltip_grb_hydraulics</source>
			<translation>grb_hydraulics</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Altele</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_reactions</source>
			<translation>Reacții</translation>
		</message>
		<message>
			<source>tooltip_grb_reactions</source>
			<translation>grb_reactions</translation>
		</message>
		<message>
			<source>grb_reports</source>
			<translation>Rapoarte</translation>
		</message>
		<message>
			<source>tooltip_grb_reports</source>
			<translation>grb_reports</translation>
		</message>
		<message>
			<source>grb_time_steps</source>
			<translation>Data &amp;amp; pași de timp</translation>
		</message>
		<message>
			<source>tooltip_grb_time_steps</source>
			<translation>grb_time_steps</translation>
		</message>
		<message>
			<source>tab_inp</source>
			<translation>Inp</translation>
		</message>
		<message>
			<source>tooltip_tab_inp</source>
			<translation>tab_inp</translation>
		</message>
		<message>
			<source>tab_other</source>
			<translation>Altele</translation>
		</message>
		<message>
			<source>tooltip_tab_other</source>
			<translation>tab_other</translation>
		</message>
	</context>
	<context>
		<name>go2epa_selector</name>
		<message>
			<source>title</source>
			<translation>Selector de comparare a rezultatelor</translation>
		</message>
		<message>
			<source>dlg_go2epa_selector</source>
			<translation>Selector de comparare a rezultatelor</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_selector</source>
			<translation>dlg_go2epa_selector</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Rezultat</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
		<message>
			<source>tab_time</source>
			<translation>Data și ora</translation>
		</message>
		<message>
			<source>tooltip_tab_time</source>
			<translation>tab_time</translation>
		</message>
	</context>
	<context>
		<name>go2iber</name>
		<message>
			<source>title</source>
			<translation>Go2Iber</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_iber_options</source>
			<translation>Opțiuni Iber</translation>
		</message>
		<message>
			<source>tooltip_btn_iber_options</source>
			<translation>Opțiuni Iber</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_swmm_options</source>
			<translation>Opțiuni SWMM</translation>
		</message>
		<message>
			<source>tooltip_btn_swmm_options</source>
			<translation>Opțiuni SWMM</translation>
		</message>
		<message>
			<source>dlg_go2iber</source>
			<translation>Go2Iber</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2iber</source>
			<translation>dlg_go2iber</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Opțiuni</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>lbl_mesh</source>
			<translation>Plasă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mesh</source>
			<translation>lbl_mesh</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Calea dosarului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
		<message>
			<source>lbl_result_name</source>
			<translation>Numele rezultatului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name</source>
			<translation>lbl_result_name</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>info_catalog</name>
		<message>
			<source>title</source>
			<translation>Catalog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_info_catalog</source>
			<translation>Catalog</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_catalog</source>
			<translation>dlg_info_catalog</translation>
		</message>
	</context>
	<context>
		<name>info_crossect</name>
		<message>
			<source>title</source>
			<translation>Secțiunea</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>dlg_info_crossect</source>
			<translation>Secțiunea</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_crossect</source>
			<translation>dlg_info_crossect</translation>
		</message>
		<message>
			<source>lbl_cost_area</source>
			<translation>Conduit area:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_area</source>
			<translation>lbl_cost_area</translation>
		</message>
		<message>
			<source>lbl_cost_bulk</source>
			<translation>Conducte în vrac:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_bulk</source>
			<translation>lbl_cost_bulk</translation>
		</message>
		<message>
			<source>lbl_cost_exc</source>
			<translation>m3/ml Exces:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_exc</source>
			<translation>lbl_cost_exc</translation>
		</message>
		<message>
			<source>lbl_cost_excav</source>
			<translation>m3/ml Excav:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_excav</source>
			<translation>lbl_cost_excav</translation>
		</message>
		<message>
			<source>lbl_cost_fill</source>
			<translation>m3/ml Umplere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_fill</source>
			<translation>lbl_cost_fill</translation>
		</message>
		<message>
			<source>lbl_cost_trench</source>
			<translation>% Șanțuri:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_trench</source>
			<translation>lbl_cost_trench</translation>
		</message>
	</context>
	<context>
		<name>info_epa</name>
		<message>
			<source>title</source>
			<translation>InfoEpa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_info_epa</source>
			<translation>InfoEpa</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_epa</source>
			<translation>dlg_info_epa</translation>
		</message>
		<message>
			<source>page_base</source>
			<translation>Baza</translation>
		</message>
		<message>
			<source>tooltip_page_base</source>
			<translation>page_base</translation>
		</message>
		<message>
			<source>page_dscenario</source>
			<translation>Dscenario</translation>
		</message>
		<message>
			<source>tooltip_page_dscenario</source>
			<translation>page_dscenario</translation>
		</message>
		<message>
			<source>page_dwf</source>
			<translation>DWF</translation>
		</message>
		<message>
			<source>tooltip_page_dwf</source>
			<translation>page_dwf</translation>
		</message>
		<message>
			<source>page_inflows</source>
			<translation>INFLUXURI</translation>
		</message>
		<message>
			<source>tooltip_page_inflows</source>
			<translation>page_inflows</translation>
		</message>
	</context>
	<context>
		<name>info_feature</name>
		<message>
			<source>title</source>
			<translation>Joncțiune</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Aplicați</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>Aplicați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>btn_link</source>
			<translation>btn_link</translation>
		</message>
		<message>
			<source>tooltip_btn_link</source>
			<translation>btn_link</translation>
		</message>
		<message>
			<source>btn_new_element</source>
			<translation>btn_new_element</translation>
		</message>
		<message>
			<source>tooltip_btn_new_element</source>
			<translation>btn_new_element</translation>
		</message>
		<message>
			<source>btn_new_visit</source>
			<translation>btn_new_visit</translation>
		</message>
		<message>
			<source>tooltip_btn_new_visit</source>
			<translation>btn_new_visit</translation>
		</message>
		<message>
			<source>btn_open_element</source>
			<translation>btn_open_element</translation>
		</message>
		<message>
			<source>tooltip_btn_open_element</source>
			<translation>btn_open_element</translation>
		</message>
		<message>
			<source>btn_open_gallery</source>
			<translation>btn_open_gallery</translation>
		</message>
		<message>
			<source>tooltip_btn_open_gallery</source>
			<translation>btn_open_gallery</translation>
		</message>
		<message>
			<source>btn_open_visit</source>
			<translation>btn_open_visit</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit</source>
			<translation>btn_open_visit</translation>
		</message>
		<message>
			<source>btn_open_visit_doc</source>
			<translation>btn_open_visit_doc</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit_doc</source>
			<translation>btn_open_visit_doc</translation>
		</message>
		<message>
			<source>btn_open_visit_event</source>
			<translation>btn_open_visit_event</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit_event</source>
			<translation>btn_open_visit_event</translation>
		</message>
		<message>
			<source>dlg_info_feature</source>
			<translation>Joncțiune</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_feature</source>
			<translation>dlg_info_feature</translation>
		</message>
		<message>
			<source>grb_frelem_dscenario</source>
			<translation>Dscenario</translation>
		</message>
		<message>
			<source>tooltip_grb_frelem_dscenario</source>
			<translation>grb_frelem_dscenario</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>INP</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>RPT</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>page</source>
			<translation>Date</translation>
		</message>
		<message>
			<source>tooltip_page</source>
			<translation>page</translation>
		</message>
		<message>
			<source>page_2</source>
			<translation>Dscenario</translation>
		</message>
		<message>
			<source>tooltip_page_2</source>
			<translation>page_2</translation>
		</message>
		<message>
			<source>page_add</source>
			<translation>Date suplimentare</translation>
		</message>
		<message>
			<source>tooltip_page_add</source>
			<translation>page_add</translation>
		</message>
		<message>
			<source>page_main</source>
			<translation>Date principale</translation>
		</message>
		<message>
			<source>tooltip_page_main</source>
			<translation>page_main</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_connections</source>
			<translation>Conecții</translation>
		</message>
		<message>
			<source>tooltip_tab_connections</source>
			<translation>tab_connections</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Date</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_documents</source>
			<translation>Document</translation>
		</message>
		<message>
			<source>tooltip_tab_documents</source>
			<translation>tab_documents</translation>
		</message>
		<message>
			<source>tab_elements</source>
			<translation>Elemente</translation>
		</message>
		<message>
			<source>tooltip_tab_elements</source>
			<translation>tab_elements</translation>
		</message>
		<message>
			<source>tab_epa</source>
			<translation>APE</translation>
		</message>
		<message>
			<source>tooltip_tab_epa</source>
			<translation>tab_epa</translation>
		</message>
		<message>
			<source>tab_event</source>
			<translation>Eveniment</translation>
		</message>
		<message>
			<source>tooltip_tab_event</source>
			<translation>tab_event</translation>
		</message>
		<message>
			<source>tab_features</source>
			<translation>Caracteristici</translation>
		</message>
		<message>
			<source>tooltip_tab_features</source>
			<translation>tab_features</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_hydrometer</source>
			<translation>Hidrometru</translation>
		</message>
		<message>
			<source>tooltip_tab_hydrometer</source>
			<translation>tab_hydrometer</translation>
		</message>
		<message>
			<source>tab_hydrometer_val</source>
			<translation>Valorile hidrometrului</translation>
		</message>
		<message>
			<source>tooltip_tab_hydrometer_val</source>
			<translation>tab_hydrometer_val</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_orifice</source>
			<translation>Orificiu</translation>
		</message>
		<message>
			<source>tooltip_tab_orifice</source>
			<translation>tab_orifice</translation>
		</message>
		<message>
			<source>tab_outlet</source>
			<translation>Ieșire</translation>
		</message>
		<message>
			<source>tooltip_tab_outlet</source>
			<translation>tab_outlet</translation>
		</message>
		<message>
			<source>tab_plan</source>
			<translation>Plan</translation>
		</message>
		<message>
			<source>tooltip_tab_plan</source>
			<translation>tab_plan</translation>
		</message>
		<message>
			<source>tab_pump</source>
			<translation>Pompă</translation>
		</message>
		<message>
			<source>tooltip_tab_pump</source>
			<translation>tab_pump</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relații</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Relații</translation>
		</message>
		<message>
			<source>tab_rpt</source>
			<translation>Rpt</translation>
		</message>
		<message>
			<source>tooltip_tab_rpt</source>
			<translation>tab_rpt</translation>
		</message>
		<message>
			<source>tab_shortpipe</source>
			<translation>Țeava scurtă</translation>
		</message>
		<message>
			<source>tooltip_tab_shortpipe</source>
			<translation>tab_shortpipe</translation>
		</message>
		<message>
			<source>tab_valve</source>
			<translation>Supapă</translation>
		</message>
		<message>
			<source>tooltip_tab_valve</source>
			<translation>tab_valve</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Vizită</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
		<message>
			<source>tab_weir</source>
			<translation>Weir</translation>
		</message>
		<message>
			<source>tooltip_tab_weir</source>
			<translation>tab_weir</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>bara de instrumente</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>info_generic</name>
		<message>
			<source>title</source>
			<translation>Informații de bază</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_info_generic</source>
			<translation>Informații de bază</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_generic</source>
			<translation>dlg_info_generic</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>bara de instrumente</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>info_workcat</name>
		<message>
			<source>title</source>
			<translation>Nou workcat</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>builtdate</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_builtdate</source>
			<translation>builtdate</translation>
		</message>
		<message>
			<source>dlg_info_workcat</source>
			<translation>Nou workcat</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_workcat</source>
			<translation>dlg_info_workcat</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Data construirii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>lbl_builtdate</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Link:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>lbl_link</translation>
		</message>
		<message>
			<source>lbl_work_id</source>
			<translation>ID de lucru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_id</source>
			<translation>lbl_work_id</translation>
		</message>
		<message>
			<source>lbl_workid_key_1</source>
			<translation>Cheia Workid 1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workid_key_1</source>
			<translation>lbl_workid_key_1</translation>
		</message>
		<message>
			<source>lbl_workid_key_2</source>
			<translation>Cheia Workid 2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workid_key_2</source>
			<translation>lbl_workid_key_2</translation>
		</message>
	</context>
	<context>
		<name>inp_config_import</name>
		<message>
			<source>title</source>
			<translation>Configurare import INP</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_load</source>
			<translation>Încărcați...</translation>
		</message>
		<message>
			<source>tooltip_btn_load</source>
			<translation>btn_load</translation>
		</message>
		<message>
			<source>btn_reload</source>
			<translation>Opțiuni de reîncărcare</translation>
		</message>
		<message>
			<source>tooltip_btn_reload</source>
			<translation>btn_reload</translation>
		</message>
		<message>
			<source>btn_save</source>
			<translation>Salvați...</translation>
		</message>
		<message>
			<source>tooltip_btn_save</source>
			<translation>btn_save</translation>
		</message>
		<message>
			<source>chk_force_commit</source>
			<translation>Forțați comiterea</translation>
		</message>
		<message>
			<source>tooltip_chk_force_commit</source>
			<translation>chk_force_commit</translation>
		</message>
		<message>
			<source>dlg_inp_config_import</source>
			<translation>Configurare import INP</translation>
		</message>
		<message>
			<source>tooltip_dlg_inp_config_import</source>
			<translation>dlg_inp_config_import</translation>
		</message>
		<message>
			<source>grb_basic</source>
			<translation>De bază</translation>
		</message>
		<message>
			<source>tooltip_grb_basic</source>
			<translation>grb_basic</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_mapzones</source>
			<translation>Hărți</translation>
		</message>
		<message>
			<source>tooltip_grb_mapzones</source>
			<translation>grb_mapzones</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Psector:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Funcționare:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Municipalitate:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Sector:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>lbl_arcs</source>
			<translation>Selectați arccat_id corespunzător pentru fiecare combinație de arcuri din opțiunile de mai jos. Dacă alegeți &amp;quot;Create new&amp;quot;, introduceți noul nume în coloana &amp;quot;New catalog name&amp;quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_arcs</source>
			<translation>lbl_arcs</translation>
		</message>
		<message>
			<source>lbl_dscenario</source>
			<translation>Solicită numele dscenario:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario</source>
			<translation>lbl_dscenario</translation>
		</message>
		<message>
			<source>lbl_feature</source>
			<translation>Selectați din opțiunile de mai jos ID-ul caracteristicii adecvate pentru fiecare tip EPA. Dacă este necesar, puteți adăuga un nou tip de caracteristică în catalogul Giswater și faceți clic pe butonul &amp;quot;Reload Options&amp;quot; de mai jos.</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature</source>
			<translation>lbl_feature</translation>
		</message>
		<message>
			<source>lbl_flwreg</source>
			<translation>Selectați id-ul de catalog corespunzător pentru fiecare regulator de debit din opțiunile de mai jos. Dacă alegeți &amp;quot;Create new&amp;quot;, introduceți noul nume în coloana &amp;quot;New catalog name&amp;quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_flwreg</source>
			<translation>lbl_flwreg</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Selectați materialul adecvat pentru fiecare rugozitate din opțiunile de mai jos. Dacă este necesar, puteți adăuga un material nou în catalogul Giswater și faceți clic pe butonul &amp;quot;Reload Options&amp;quot; de mai jos.</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>lbl_material</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Selectați nodecat_id corespunzător pentru fiecare tip de EPA din opțiunile de mai jos. Dacă alegeți &amp;quot;Create new&amp;quot;, introduceți noul nume în coloana &amp;quot;New catalog name&amp;quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_raingage</source>
			<translation>Raingage implicit:</translation>
		</message>
		<message>
			<source>tooltip_lbl_raingage</source>
			<translation>lbl_raingage</translation>
		</message>
		<message>
			<source>lbl_workcat</source>
			<translation>Workcat_id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat</source>
			<translation>lbl_workcat</translation>
		</message>
		<message>
			<source>tab_arccat</source>
			<translation>Arce</translation>
		</message>
		<message>
			<source>tooltip_tab_arccat</source>
			<translation>tab_arccat</translation>
		</message>
		<message>
			<source>tab_basic</source>
			<translation>De bază</translation>
		</message>
		<message>
			<source>tooltip_tab_basic</source>
			<translation>tab_basic</translation>
		</message>
		<message>
			<source>tab_feature</source>
			<translation>Caracteristici</translation>
		</message>
		<message>
			<source>tooltip_tab_feature</source>
			<translation>tab_feature</translation>
		</message>
		<message>
			<source>tab_flwreg</source>
			<translation>Regulatoare de debit</translation>
		</message>
		<message>
			<source>tooltip_tab_flwreg</source>
			<translation>tab_flwreg</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>tooltip_tab_material</source>
			<translation>tab_material</translation>
		</message>
		<message>
			<source>tab_nodecat</source>
			<translation>Noduri</translation>
		</message>
		<message>
			<source>tooltip_tab_nodecat</source>
			<translation>tab_nodecat</translation>
		</message>
		<message>
			<source>tbl_arcs</source>
			<translation>Nume catalog nou</translation>
		</message>
		<message>
			<source>tooltip_tbl_arcs</source>
			<translation>tbl_arcs</translation>
		</message>
		<message>
			<source>tbl_feature</source>
			<translation>Caracteristică</translation>
		</message>
		<message>
			<source>tooltip_tbl_feature</source>
			<translation>tbl_feature</translation>
		</message>
		<message>
			<source>tbl_flwreg</source>
			<translation>Nume catalog nou</translation>
		</message>
		<message>
			<source>tooltip_tbl_flwreg</source>
			<translation>tbl_flwreg</translation>
		</message>
		<message>
			<source>tbl_material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>tooltip_tbl_material</source>
			<translation>tbl_material</translation>
		</message>
		<message>
			<source>tbl_nodes</source>
			<translation>Nume catalog nou</translation>
		</message>
		<message>
			<source>tooltip_tbl_nodes</source>
			<translation>tbl_nodes</translation>
		</message>
	</context>
	<context>
		<name>inp_parsing</name>
		<message>
			<source>title</source>
			<translation>Parsarea fișierului INP</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>dlg_inp_parsing</source>
			<translation>Parsarea fișierului INP</translation>
		</message>
		<message>
			<source>tooltip_dlg_inp_parsing</source>
			<translation>dlg_inp_parsing</translation>
		</message>
		<message>
			<source>tab_databaselog</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_databaselog</source>
			<translation>tab_databaselog</translation>
		</message>
	</context>
	<context>
		<name>interpolate</name>
		<message>
			<source>title</source>
			<translation>Interpolare</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_interpolate</source>
			<translation>Interpolare</translation>
		</message>
		<message>
			<source>tooltip_dlg_interpolate</source>
			<translation>dlg_interpolate</translation>
		</message>
		<message>
			<source>rb_extrapolate</source>
			<translation>Extrapolare</translation>
		</message>
		<message>
			<source>tooltip_rb_extrapolate</source>
			<translation>rb_extrapolate</translation>
		</message>
		<message>
			<source>rb_interpolate</source>
			<translation>Interpolare</translation>
		</message>
		<message>
			<source>tooltip_rb_interpolate</source>
			<translation>rb_interpolate</translation>
		</message>
	</context>
	<context>
		<name>load_menu</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_load_menu</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_load_menu</source>
			<translation>dlg_load_menu</translation>
		</message>
	</context>
	<context>
		<name>lot_management</name>
		<message>
			<source>title</source>
			<translation>Gestionarea loturilor</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți lotul</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Ștergeți lotul</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Lot deschis</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>Lot deschis</translation>
		</message>
		<message>
			<source>chk_show_nulls</source>
			<translation>Afișați valorile nule</translation>
		</message>
		<message>
			<source>tooltip_chk_show_nulls</source>
			<translation>Afișați valorile goale</translation>
		</message>
		<message>
			<source>dlg_lot_management</source>
			<translation>Gestionarea loturilor</translation>
		</message>
		<message>
			<source>tooltip_dlg_lot_management</source>
			<translation>dlg_lot_management</translation>
		</message>
		<message>
			<source>lbl_column_filter</source>
			<translation>Filtrați coloana de date:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter</source>
			<translation>Filtru coloană de date:</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>De la:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>De la:</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Până la:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>Pentru:</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Nume:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Stat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Stat:</translation>
		</message>
	</context>
	<context>
		<name>mapzone_config</name>
		<message>
			<source>title</source>
			<translation>Mapzone Config</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_forceClosed</source>
			<translation>ADD</translation>
		</message>
		<message>
			<source>tooltip_btn_add_forceClosed</source>
			<translation>btn_add_forceClosed</translation>
		</message>
		<message>
			<source>btn_add_ignore</source>
			<translation>ADD</translation>
		</message>
		<message>
			<source>tooltip_btn_add_ignore</source>
			<translation>btn_add_ignore</translation>
		</message>
		<message>
			<source>btn_add_nodeParent</source>
			<translation>ADD</translation>
		</message>
		<message>
			<source>tooltip_btn_add_nodeParent</source>
			<translation>btn_add_nodeParent</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_clear_preview</source>
			<translation>Previzualizare clară</translation>
		</message>
		<message>
			<source>tooltip_btn_clear_preview</source>
			<translation>btn_clear_preview</translation>
		</message>
		<message>
			<source>btn_remove_forceClosed</source>
			<translation>ELIMINAȚI</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_forceClosed</source>
			<translation>btn_remove_forceClosed</translation>
		</message>
		<message>
			<source>btn_remove_ignore</source>
			<translation>ELIMINAȚI</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_ignore</source>
			<translation>btn_remove_ignore</translation>
		</message>
		<message>
			<source>btn_remove_nodeParent</source>
			<translation>ELIMINAȚI</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_nodeParent</source>
			<translation>btn_remove_nodeParent</translation>
		</message>
		<message>
			<source>dlg_mapzone_config</source>
			<translation>Mapzone Config</translation>
		</message>
		<message>
			<source>tooltip_dlg_mapzone_config</source>
			<translation>dlg_mapzone_config</translation>
		</message>
		<message>
			<source>lbl_forceClosed</source>
			<translation>forceClosed:</translation>
		</message>
		<message>
			<source>tooltip_lbl_forceClosed</source>
			<translation>lbl_forceClosed</translation>
		</message>
		<message>
			<source>lbl_ignore</source>
			<translation>ignorați</translation>
		</message>
		<message>
			<source>tooltip_lbl_ignore</source>
			<translation>lbl_ignore</translation>
		</message>
		<message>
			<source>lbl_nodeParent</source>
			<translation>nodeParent:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodeParent</source>
			<translation>lbl_nodeParent</translation>
		</message>
		<message>
			<source>lbl_preview</source>
			<translation>Previzualizare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_preview</source>
			<translation>lbl_preview</translation>
		</message>
		<message>
			<source>lbl_toArc</source>
			<translation>toArc:</translation>
		</message>
		<message>
			<source>tooltip_lbl_toArc</source>
			<translation>lbl_toArc</translation>
		</message>
	</context>
	<context>
		<name>mapzone_manager</name>
		<message>
			<source>title</source>
			<translation>Mapzones manager</translation>
		</message>
		<message>
			<source>dlg_mapzone_manager</source>
			<translation>Mapzones manager</translation>
		</message>
		<message>
			<source>tooltip_dlg_mapzone_manager</source>
			<translation>dlg_mapzone_manager</translation>
		</message>
	</context>
	<context>
		<name>massive_composer</name>
		<message>
			<source>title</source>
			<translation>Imprimarea automată a paginilor compozitorului</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>dlg_massive_composer</source>
			<translation>Imprimarea automată a paginilor compozitorului</translation>
		</message>
		<message>
			<source>tooltip_dlg_massive_composer</source>
			<translation>dlg_massive_composer</translation>
		</message>
		<message>
			<source>grb_comp</source>
			<translation>Lista compozitorilor</translation>
		</message>
		<message>
			<source>tooltip_grb_comp</source>
			<translation>grb_comp</translation>
		</message>
		<message>
			<source>lbl_composers</source>
			<translation>Selectați compozitorul:</translation>
		</message>
		<message>
			<source>tooltip_lbl_composers</source>
			<translation>lbl_composers</translation>
		</message>
		<message>
			<source>lbl_folder</source>
			<translation>Selectați folderul:</translation>
		</message>
		<message>
			<source>tooltip_lbl_folder</source>
			<translation>lbl_folder</translation>
		</message>
		<message>
			<source>lbl_prefix</source>
			<translation>Fișier prefix:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prefix</source>
			<translation>lbl_prefix</translation>
		</message>
		<message>
			<source>lbl_single</source>
			<translation>Fișier unic:</translation>
		</message>
		<message>
			<source>tooltip_lbl_single</source>
			<translation>lbl_single</translation>
		</message>
		<message>
			<source>lbl_sleep</source>
			<translation>Timpul de somn:</translation>
		</message>
		<message>
			<source>tooltip_lbl_sleep</source>
			<translation>lbl_sleep</translation>
		</message>
	</context>
	<context>
		<name>mincut</name>
		<message>
			<source>title</source>
			<translation>Mincut</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Anulează sarcina</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_end</source>
			<translation>Sfârșit</translation>
		</message>
		<message>
			<source>tooltip_btn_end</source>
			<translation>btn_end</translation>
		</message>
		<message>
			<source>btn_start</source>
			<translation>Start</translation>
		</message>
		<message>
			<source>tooltip_btn_start</source>
			<translation>btn_start</translation>
		</message>
		<message>
			<source>cbx_date_end</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end</source>
			<translation>cbx_date_end</translation>
		</message>
		<message>
			<source>cbx_date_end_predict</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end_predict</source>
			<translation>cbx_date_end_predict</translation>
		</message>
		<message>
			<source>cbx_date_start</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start</source>
			<translation>cbx_date_start</translation>
		</message>
		<message>
			<source>cbx_date_start_predict</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start_predict</source>
			<translation>cbx_date_start_predict</translation>
		</message>
		<message>
			<source>cbx_recieved_day</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_recieved_day</source>
			<translation>cbx_recieved_day</translation>
		</message>
		<message>
			<source>chk_use_planified</source>
			<translation>Utilizați rețeaua planificată</translation>
		</message>
		<message>
			<source>tooltip_chk_use_planified</source>
			<translation>chk_use_planified</translation>
		</message>
		<message>
			<source>dlg_mincut</source>
			<translation>Mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut</source>
			<translation>dlg_mincut</translation>
		</message>
		<message>
			<source>grb_adress</source>
			<translation>Adress</translation>
		</message>
		<message>
			<source>tooltip_grb_adress</source>
			<translation>grb_adress</translation>
		</message>
		<message>
			<source>grb_exec_realdates</source>
			<translation>Date reale</translation>
		</message>
		<message>
			<source>tooltip_grb_exec_realdates</source>
			<translation>grb_exec_realdates</translation>
		</message>
		<message>
			<source>grb_plan_details</source>
			<translation>Detalii</translation>
		</message>
		<message>
			<source>tooltip_grb_plan_details</source>
			<translation>grb_plan_details</translation>
		</message>
		<message>
			<source>grb_plan_forecasted_dates</source>
			<translation>Date previzionate</translation>
		</message>
		<message>
			<source>tooltip_grb_plan_forecasted_dates</source>
			<translation>grb_plan_forecasted_dates</translation>
		</message>
		<message>
			<source>lbl_assigned_to</source>
			<translation>Atribuit către:</translation>
		</message>
		<message>
			<source>tooltip_lbl_assigned_to</source>
			<translation>lbl_assigned_to</translation>
		</message>
		<message>
			<source>lbl_cause</source>
			<translation>Cauza:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cause</source>
			<translation>lbl_cause</translation>
		</message>
		<message>
			<source>lbl_chlorine</source>
			<translation>Clor:</translation>
		</message>
		<message>
			<source>tooltip_lbl_chlorine</source>
			<translation>lbl_chlorine</translation>
		</message>
		<message>
			<source>lbl_depth</source>
			<translation>Adâncime:</translation>
		</message>
		<message>
			<source>tooltip_lbl_depth</source>
			<translation>lbl_depth</translation>
		</message>
		<message>
			<source>lbl_descript_pd</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_pd</source>
			<translation>lbl_descript_pd</translation>
		</message>
		<message>
			<source>lbl_descript_rd</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_rd</source>
			<translation>lbl_descript_rd</translation>
		</message>
		<message>
			<source>lbl_dist_from_plot</source>
			<translation>Distanța de la parcelă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dist_from_plot</source>
			<translation>lbl_dist_from_plot</translation>
		</message>
		<message>
			<source>lbl_end</source>
			<translation>Pentru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end</source>
			<translation>lbl_end</translation>
		</message>
		<message>
			<source>lbl_equipment_code</source>
			<translation>Chlorine measurement equipment:</translation>
		</message>
		<message>
			<source>tooltip_lbl_equipment_code</source>
			<translation>lbl_equipment_code</translation>
		</message>
		<message>
			<source>lbl_exec_appropriate</source>
			<translation>Apropiat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_appropriate</source>
			<translation>Dacă este adevărat, locația reală corespunde informațiilor programate pentru mincut</translation>
		</message>
		<message>
			<source>lbl_exec_enddate</source>
			<translation>Data de încheiere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_enddate</source>
			<translation>lbl_exec_enddate</translation>
		</message>
		<message>
			<source>lbl_exec_startdate</source>
			<translation>Data de începere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_startdate</source>
			<translation>Vizită ID</translation>
		</message>
		<message>
			<source>lbl_exec_user</source>
			<translation>Exec utilizator:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_user</source>
			<translation>lbl_exec_user</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_msg</source>
			<translation>Nu s-au găsit rezultate</translation>
		</message>
		<message>
			<source>tooltip_lbl_msg</source>
			<translation>lbl_msg</translation>
		</message>
		<message>
			<source>lbl_municiplity</source>
			<translation>Municipality</translation>
		</message>
		<message>
			<source>tooltip_lbl_municiplity</source>
			<translation>lbl_municiplity</translation>
		</message>
		<message>
			<source>lbl_postnumber</source>
			<translation>Number</translation>
		</message>
		<message>
			<source>tooltip_lbl_postnumber</source>
			<translation>lbl_postnumber</translation>
		</message>
		<message>
			<source>lbl_reagent_lot</source>
			<translation>Chlorine reagent lot:</translation>
		</message>
		<message>
			<source>tooltip_lbl_reagent_lot</source>
			<translation>lbl_reagent_lot</translation>
		</message>
		<message>
			<source>lbl_received_date</source>
			<translation>Data primirii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_received_date</source>
			<translation>lbl_received_date</translation>
		</message>
		<message>
			<source>lbl_start</source>
			<translation>De la:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start</source>
			<translation>lbl_start</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Stat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
		<message>
			<source>lbl_street</source>
			<translation>Street</translation>
		</message>
		<message>
			<source>tooltip_lbl_street</source>
			<translation>lbl_street</translation>
		</message>
		<message>
			<source>lbl_turbidity</source>
			<translation>Turbiditate:</translation>
		</message>
		<message>
			<source>tooltip_lbl_turbidity</source>
			<translation>lbl_turbidity</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Tip:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
		<message>
			<source>lbl_work_order</source>
			<translation>Ordin de lucru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_order</source>
			<translation>lbl_work_order</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Executare</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Plan</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_hydro</source>
			<translation>Hidro</translation>
		</message>
		<message>
			<source>tooltip_tab_hydro</source>
			<translation>tab_hydro</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Jurnal</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>bara de instrumente</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>mincut_composer</name>
		<message>
			<source>title</source>
			<translation>Compozitor Mincut</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Deschis</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_mincut_composer</source>
			<translation>Compozitor Mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_composer</source>
			<translation>dlg_mincut_composer</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Compozitor Mincut</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_rotation</source>
			<translation>Rotație:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rotation</source>
			<translation>lbl_rotation</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Șablon:</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Titlu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
	</context>
	<context>
		<name>mincut_connec</name>
		<message>
			<source>title</source>
			<translation>Conectare Mincut</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>dlg_mincut_connec</source>
			<translation>Conectare Mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_connec</source>
			<translation>dlg_mincut_connec</translation>
		</message>
		<message>
			<source>lbl_search</source>
			<translation>Căutați după codul clientului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_search</source>
			<translation>lbl_search</translation>
		</message>
	</context>
	<context>
		<name>mincut_end</name>
		<message>
			<source>title</source>
			<translation>Sfârșit mincut</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_set_real_location</source>
			<translation>Setați locația reală</translation>
		</message>
		<message>
			<source>tooltip_btn_set_real_location</source>
			<translation>btn_set_real_location</translation>
		</message>
		<message>
			<source>cbx_date_end_fin</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end_fin</source>
			<translation>cbx_date_end_fin</translation>
		</message>
		<message>
			<source>cbx_date_start_fin</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start_fin</source>
			<translation>cbx_date_start_fin</translation>
		</message>
		<message>
			<source>cbx_hours_start_fin</source>
			<translation>H:mm:ss</translation>
		</message>
		<message>
			<source>tooltip_cbx_hours_start_fin</source>
			<translation>cbx_hours_start_fin</translation>
		</message>
		<message>
			<source>dlg_mincut_end</source>
			<translation>Sfârșit mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_end</source>
			<translation>dlg_mincut_end</translation>
		</message>
		<message>
			<source>grb_adress</source>
			<translation>Adress</translation>
		</message>
		<message>
			<source>tooltip_grb_adress</source>
			<translation>grb_adress</translation>
		</message>
		<message>
			<source>grb_close_mincut</source>
			<translation>Închide mincut</translation>
		</message>
		<message>
			<source>tooltip_grb_close_mincut</source>
			<translation>grb_close_mincut</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Date</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>lbl_end_date</source>
			<translation>Pentru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_date</source>
			<translation>lbl_end_date</translation>
		</message>
		<message>
			<source>lbl_end_hour</source>
			<translation>Ora finală:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_hour</source>
			<translation>lbl_end_hour</translation>
		</message>
		<message>
			<source>lbl_executed</source>
			<translation>Executat de:</translation>
		</message>
		<message>
			<source>tooltip_lbl_executed</source>
			<translation>lbl_executed</translation>
		</message>
		<message>
			<source>lbl_mincut</source>
			<translation>Mincut:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mincut</source>
			<translation>lbl_mincut</translation>
		</message>
		<message>
			<source>lbl_msg</source>
			<translation>Nu s-au găsit rezultate</translation>
		</message>
		<message>
			<source>tooltip_lbl_msg</source>
			<translation>lbl_msg</translation>
		</message>
		<message>
			<source>lbl_municiplity</source>
			<translation>Municipality</translation>
		</message>
		<message>
			<source>tooltip_lbl_municiplity</source>
			<translation>lbl_municiplity</translation>
		</message>
		<message>
			<source>lbl_postnumber</source>
			<translation>Number</translation>
		</message>
		<message>
			<source>tooltip_lbl_postnumber</source>
			<translation>lbl_postnumber</translation>
		</message>
		<message>
			<source>lbl_start_date</source>
			<translation>De la:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_date</source>
			<translation>lbl_start_date</translation>
		</message>
		<message>
			<source>lbl_start_hour</source>
			<translation>Ora de începere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_hour</source>
			<translation>lbl_start_hour</translation>
		</message>
		<message>
			<source>lbl_street</source>
			<translation>Strada:</translation>
		</message>
		<message>
			<source>tooltip_lbl_street</source>
			<translation>lbl_street</translation>
		</message>
		<message>
			<source>lbl_work_order</source>
			<translation>Ordin de lucru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_order</source>
			<translation>lbl_work_order</translation>
		</message>
	</context>
	<context>
		<name>mincut_hydrometer</name>
		<message>
			<source>title</source>
			<translation>Hidrometru Mincut</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>dlg_mincut_hydrometer</source>
			<translation>Hidrometru Mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_hydrometer</source>
			<translation>dlg_mincut_hydrometer</translation>
		</message>
		<message>
			<source>lbl_ccc</source>
			<translation>Cod client Connec:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ccc</source>
			<translation>lbl_ccc</translation>
		</message>
		<message>
			<source>lbl_hcc</source>
			<translation>Cod client hidrometru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hcc</source>
			<translation>lbl_hcc</translation>
		</message>
	</context>
	<context>
		<name>mincut_manager</name>
		<message>
			<source>title</source>
			<translation>Managementul mincut</translation>
		</message>
		<message>
			<source>btn_selector_mincut</source>
			<translation>btn_selector_mincut</translation>
		</message>
		<message>
			<source>tooltip_btn_selector_mincut</source>
			<translation>btn_selector_mincut</translation>
		</message>
		<message>
			<source>dlg_mincut_manager</source>
			<translation>Managementul mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_manager</source>
			<translation>dlg_mincut_manager</translation>
		</message>
	</context>
	<context>
		<name>netscenario</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_btn_config</source>
			<translation>btn_config</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Comutare activă</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>btn_toggle_closed</source>
			<translation>Toggle închis</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_closed</source>
			<translation>btn_toggle_closed</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>dlg_netscenario</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_netscenario</source>
			<translation>dlg_netscenario</translation>
		</message>
		<message>
			<source>lbl_mapzone_id</source>
			<translation>Mapzone id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mapzone_id</source>
			<translation>lbl_mapzone_id</translation>
		</message>
	</context>
	<context>
		<name>netscenario_manager</name>
		<message>
			<source>title</source>
			<translation>Manager Netscenario</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>     Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplicat</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>Duplicat</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Comutare activă</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Comutare activă</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>btn_update_netscenario</source>
			<translation>Scenariu net curent</translation>
		</message>
		<message>
			<source>tooltip_btn_update_netscenario</source>
			<translation>Scenariu net curent</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Arată inactiv</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Arată inactiv</translation>
		</message>
		<message>
			<source>dlg_netscenario_manager</source>
			<translation>Manager Netscenario</translation>
		</message>
		<message>
			<source>tooltip_dlg_netscenario_manager</source>
			<translation>dlg_netscenario_manager</translation>
		</message>
		<message>
			<source>lbl_netscenario_name</source>
			<translation>Filtrați după: Numele Netscenarului</translation>
		</message>
		<message>
			<source>tooltip_lbl_netscenario_name</source>
			<translation>Filtrați după: Numele Netscenarului</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_controls</name>
		<message>
			<source>title</source>
			<translation>Editor de comenzi simple</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Activ</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_controls</source>
			<translation>Editor de comenzi simple</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_controls</source>
			<translation>dlg_nonvisual_controls</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observ</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_sector_id</source>
			<translation>ID sector</translation>
		</message>
		<message>
			<source>tooltip_lbl_sector_id</source>
			<translation>lbl_sector_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_curve</name>
		<message>
			<source>title</source>
			<translation>Editor de curbe</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_curve</source>
			<translation>Editor de curbe</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_curve</source>
			<translation>dlg_nonvisual_curve</translation>
		</message>
		<message>
			<source>lbl_curve_id</source>
			<translation>Curbă ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_id</source>
			<translation>lbl_curve_id</translation>
		</message>
		<message>
			<source>lbl_curve_type</source>
			<translation>Tip de curbă</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_type</source>
			<translation>lbl_curve_type</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descriere</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>ID operațiune</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>tbl_curve_value</source>
			<translation>Y</translation>
		</message>
		<message>
			<source>tooltip_tbl_curve_value</source>
			<translation>tbl_curve_value</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_lids</name>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_help</source>
			<translation>Ajutor</translation>
		</message>
		<message>
			<source>tooltip_btn_help</source>
			<translation>btn_help</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>Dialog</source>
			<translation>LIDS</translation>
		</message>
		<message>
			<source>tooltip_Dialog</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>drain</source>
			<translation>Drenaj</translation>
		</message>
		<message>
			<source>tooltip_drain</source>
			<translation>drain</translation>
		</message>
		<message>
			<source>drainmat</source>
			<translation>Drenaj mat</translation>
		</message>
		<message>
			<source>tooltip_drainmat</source>
			<translation>drainmat</translation>
		</message>
		<message>
			<source>label_source_img</source>
			<translation>Sursa: SWMM 5.1</translation>
		</message>
		<message>
			<source>tooltip_label_source_img</source>
			<translation>label_source_img</translation>
		</message>
		<message>
			<source>lbl_berm_height</source>
			<translation>Înălțimea bermului (in. sau mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_berm_height</source>
			<translation>lbl_berm_height</translation>
		</message>
		<message>
			<source>lbl_clogging_factor_pavement</source>
			<translation>Factor de înfundare</translation>
		</message>
		<message>
			<source>tooltip_lbl_clogging_factor_pavement</source>
			<translation>lbl_clogging_factor_pavement</translation>
		</message>
		<message>
			<source>lbl_clogging_factor_storage</source>
			<translation>Factor de înfundare</translation>
		</message>
		<message>
			<source>tooltip_lbl_clogging_factor_storage</source>
			<translation>lbl_clogging_factor_storage</translation>
		</message>
		<message>
			<source>lbl_closed_level</source>
			<translation>Nivel închis (în sau mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_closed_level</source>
			<translation>lbl_closed_level</translation>
		</message>
		<message>
			<source>lbl_conducticity_slope</source>
			<translation>Panta conductivității</translation>
		</message>
		<message>
			<source>tooltip_lbl_conducticity_slope</source>
			<translation>lbl_conducticity_slope</translation>
		</message>
		<message>
			<source>lbl_conductivity</source>
			<translation>Conductivitate (in/hr sau mm/hr)</translation>
		</message>
		<message>
			<source>tooltip_lbl_conductivity</source>
			<translation>lbl_conductivity</translation>
		</message>
		<message>
			<source>lbl_control_curve</source>
			<translation>Curba de control</translation>
		</message>
		<message>
			<source>tooltip_lbl_control_curve</source>
			<translation>lbl_control_curve</translation>
		</message>
		<message>
			<source>lbl_control_name</source>
			<translation>Nume control:</translation>
		</message>
		<message>
			<source>tooltip_lbl_control_name</source>
			<translation>lbl_control_name</translation>
		</message>
		<message>
			<source>lbl_drain_delay</source>
			<translation>Întârziere scurgere (ore)</translation>
		</message>
		<message>
			<source>tooltip_lbl_drain_delay</source>
			<translation>lbl_drain_delay</translation>
		</message>
		<message>
			<source>lbl_field_capacity</source>
			<translation>Capacitatea câmpului (fracție de volum)</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_capacity</source>
			<translation>lbl_field_capacity</translation>
		</message>
		<message>
			<source>lbl_flow_capacity</source>
			<translation>Capacitate de debit (in/h sau mm/h)</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_capacity</source>
			<translation>lbl_flow_capacity</translation>
		</message>
		<message>
			<source>lbl__flow_coefficient</source>
			<translation>Coeficient de curgere*</translation>
		</message>
		<message>
			<source>tooltip_lbl__flow_coefficient</source>
			<translation>lbl__flow_coefficient</translation>
		</message>
		<message>
			<source>lbl_flow_description</source>
			<translation>*Debitul este în in/h sau mm/h; utilizați 0 dacă nu există scurgere.</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_description</source>
			<translation>lbl_flow_description</translation>
		</message>
		<message>
			<source>lbl_flow_exponent</source>
			<translation>Exponentul debitului</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_exponent</source>
			<translation>lbl_flow_exponent</translation>
		</message>
		<message>
			<source>lbl_imprevious_surface</source>
			<translation>Fracția suprafeței impermeabile</translation>
		</message>
		<message>
			<source>tooltip_lbl_imprevious_surface</source>
			<translation>lbl_imprevious_surface</translation>
		</message>
		<message>
			<source>lbl_lid_type</source>
			<translation>Tip LID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_lid_type</source>
			<translation>lbl_lid_type</translation>
		</message>
		<message>
			<source>lbl_offset</source>
			<translation>Deplasare (în sau mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_offset</source>
			<translation>lbl_offset</translation>
		</message>
		<message>
			<source>lbl_open_level</source>
			<translation>Nivel deschis (în sau mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_open_level</source>
			<translation>lbl_open_level</translation>
		</message>
		<message>
			<source>lbl__permeability</source>
			<translation>Permeabilitate (in/h sau mm/h)</translation>
		</message>
		<message>
			<source>tooltip_lbl__permeability</source>
			<translation>lbl__permeability</translation>
		</message>
		<message>
			<source>lbl_porosity</source>
			<translation>Porozitate (fracție de volum)</translation>
		</message>
		<message>
			<source>tooltip_lbl_porosity</source>
			<translation>lbl_porosity</translation>
		</message>
		<message>
			<source>lbl_regeneration_fraction</source>
			<translation>Fracția de regenerare</translation>
		</message>
		<message>
			<source>tooltip_lbl_regeneration_fraction</source>
			<translation>lbl_regeneration_fraction</translation>
		</message>
		<message>
			<source>lbl_regeneration_interval</source>
			<translation>Interval de regenerare (zile)</translation>
		</message>
		<message>
			<source>tooltip_lbl_regeneration_interval</source>
			<translation>lbl_regeneration_interval</translation>
		</message>
		<message>
			<source>lbl_roughness</source>
			<translation>Rugozitate (Mannings n)</translation>
		</message>
		<message>
			<source>tooltip_lbl_roughness</source>
			<translation>lbl_roughness</translation>
		</message>
		<message>
			<source>lbl_seepage_rate</source>
			<translation>Rata de scurgere (in/h sau mm/h)</translation>
		</message>
		<message>
			<source>tooltip_lbl_seepage_rate</source>
			<translation>lbl_seepage_rate</translation>
		</message>
		<message>
			<source>lbl_suction_head</source>
			<translation>Cap de aspirație (in. sau mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_suction_head</source>
			<translation>lbl_suction_head</translation>
		</message>
		<message>
			<source>lbl_surface_roughness</source>
			<translation>Rugozitatea suprafeței (Mannings n)</translation>
		</message>
		<message>
			<source>tooltip_lbl_surface_roughness</source>
			<translation>lbl_surface_roughness</translation>
		</message>
		<message>
			<source>lbl_surface_slope</source>
			<translation>Panta suprafeței (procente)</translation>
		</message>
		<message>
			<source>tooltip_lbl_surface_slope</source>
			<translation>lbl_surface_slope</translation>
		</message>
		<message>
			<source>lbl_swale_side_slope</source>
			<translation>Panta laterală a șanțului (curgere / creștere)</translation>
		</message>
		<message>
			<source>tooltip_lbl_swale_side_slope</source>
			<translation>lbl_swale_side_slope</translation>
		</message>
		<message>
			<source>lbl_thickness</source>
			<translation>Grosime (in. sau mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness</source>
			<translation>lbl_thickness</translation>
		</message>
		<message>
			<source>lbl_thickness_drainage</source>
			<translation>Grosime (in. sau mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness_drainage</source>
			<translation>lbl_thickness_drainage</translation>
		</message>
		<message>
			<source>lbl_thickness_storage</source>
			<translation>Grosime (in. sau mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness_storage</source>
			<translation>lbl_thickness_storage</translation>
		</message>
		<message>
			<source>lbl_thinkness_pavement</source>
			<translation>Grosime (in. sau mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thinkness_pavement</source>
			<translation>lbl_thinkness_pavement</translation>
		</message>
		<message>
			<source>lbl_vegetation_volume</source>
			<translation>Fracția volumului de vegetație</translation>
		</message>
		<message>
			<source>tooltip_lbl_vegetation_volume</source>
			<translation>lbl_vegetation_volume</translation>
		</message>
		<message>
			<source>lbl_void_fraction</source>
			<translation>Fracția vidului</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_fraction</source>
			<translation>lbl_void_fraction</translation>
		</message>
		<message>
			<source>lbl_void_ratio_pavement</source>
			<translation>Raportul golurilor (goluri / solide)</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_ratio_pavement</source>
			<translation>lbl_void_ratio_pavement</translation>
		</message>
		<message>
			<source>lbl_void_ratio_storage</source>
			<translation>Raportul golurilor (Goluri / Solide)</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_ratio_storage</source>
			<translation>lbl_void_ratio_storage</translation>
		</message>
		<message>
			<source>lbl_wilting_point</source>
			<translation>Punct de ofilire (fracție de volum)</translation>
		</message>
		<message>
			<source>tooltip_lbl_wilting_point</source>
			<translation>lbl_wilting_point</translation>
		</message>
		<message>
			<source>pavement</source>
			<translation>Paviment</translation>
		</message>
		<message>
			<source>tooltip_pavement</source>
			<translation>pavement</translation>
		</message>
		<message>
			<source>rooftop</source>
			<translation>Drenaj pentru acoperiș</translation>
		</message>
		<message>
			<source>tooltip_rooftop</source>
			<translation>rooftop</translation>
		</message>
		<message>
			<source>soil</source>
			<translation>Solul</translation>
		</message>
		<message>
			<source>tooltip_soil</source>
			<translation>soil</translation>
		</message>
		<message>
			<source>storage</source>
			<translation>Depozitare</translation>
		</message>
		<message>
			<source>tooltip_storage</source>
			<translation>storage</translation>
		</message>
		<message>
			<source>surface</source>
			<translation>Suprafață</translation>
		</message>
		<message>
			<source>tooltip_surface</source>
			<translation>surface</translation>
		</message>
		<message>
			<source>txt_1_berm_height</source>
			<translation>0.0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_berm_height</source>
			<translation>txt_1_berm_height</translation>
		</message>
		<message>
			<source>txt_1_flow_coefficient</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_flow_coefficient</source>
			<translation>txt_1_flow_coefficient</translation>
		</message>
		<message>
			<source>txt_1_thickness</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness</source>
			<translation>txt_1_thickness</translation>
		</message>
		<message>
			<source>txt_1_thickness_drainage</source>
			<translation>3</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_drainage</source>
			<translation>txt_1_thickness_drainage</translation>
		</message>
		<message>
			<source>txt_1_thickness_pavement</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_pavement</source>
			<translation>txt_1_thickness_pavement</translation>
		</message>
		<message>
			<source>txt_1_thickness_storage</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_storage</source>
			<translation>txt_1_thickness_storage</translation>
		</message>
		<message>
			<source>txt_2_flow_exponent</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_flow_exponent</source>
			<translation>txt_2_flow_exponent</translation>
		</message>
		<message>
			<source>txt_2_porosity</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_porosity</source>
			<translation>txt_2_porosity</translation>
		</message>
		<message>
			<source>txt_2_vegetation_volume</source>
			<translation>0.0</translation>
		</message>
		<message>
			<source>tooltip_txt_2_vegetation_volume</source>
			<translation>txt_2_vegetation_volume</translation>
		</message>
		<message>
			<source>txt_2_void_fraction</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_fraction</source>
			<translation>txt_2_void_fraction</translation>
		</message>
		<message>
			<source>txt_2_void_ratio_pavement</source>
			<translation>0.15</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_ratio_pavement</source>
			<translation>txt_2_void_ratio_pavement</translation>
		</message>
		<message>
			<source>txt_2_void_ratio_storage</source>
			<translation>0.75</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_ratio_storage</source>
			<translation>txt_2_void_ratio_storage</translation>
		</message>
		<message>
			<source>txt_3_field_capacity</source>
			<translation>0.2</translation>
		</message>
		<message>
			<source>tooltip_txt_3_field_capacity</source>
			<translation>txt_3_field_capacity</translation>
		</message>
		<message>
			<source>txt_3_imprevious_surface</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_3_imprevious_surface</source>
			<translation>txt_3_imprevious_surface</translation>
		</message>
		<message>
			<source>txt_3_offset</source>
			<translation>6</translation>
		</message>
		<message>
			<source>tooltip_txt_3_offset</source>
			<translation>txt_3_offset</translation>
		</message>
		<message>
			<source>txt_3_roughness</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_3_roughness</source>
			<translation>txt_3_roughness</translation>
		</message>
		<message>
			<source>txt_3_seepage_rate</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_3_seepage_rate</source>
			<translation>txt_3_seepage_rate</translation>
		</message>
		<message>
			<source>txt_3_surface_roughness</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_3_surface_roughness</source>
			<translation>txt_3_surface_roughness</translation>
		</message>
		<message>
			<source>txt_4_clogging_factor_storage</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_4_clogging_factor_storage</source>
			<translation>txt_4_clogging_factor_storage</translation>
		</message>
		<message>
			<source>txt_4_drain_delay</source>
			<translation>6</translation>
		</message>
		<message>
			<source>tooltip_txt_4_drain_delay</source>
			<translation>txt_4_drain_delay</translation>
		</message>
		<message>
			<source>txt_4_permeability</source>
			<translation>100</translation>
		</message>
		<message>
			<source>tooltip_txt_4_permeability</source>
			<translation>txt_4_permeability</translation>
		</message>
		<message>
			<source>txt_4_surface_slope</source>
			<translation>1.0</translation>
		</message>
		<message>
			<source>tooltip_txt_4_surface_slope</source>
			<translation>txt_4_surface_slope</translation>
		</message>
		<message>
			<source>txt_4_wilting_point</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_4_wilting_point</source>
			<translation>txt_4_wilting_point</translation>
		</message>
		<message>
			<source>txt_5_clogging_factor_pavement</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_5_clogging_factor_pavement</source>
			<translation>txt_5_clogging_factor_pavement</translation>
		</message>
		<message>
			<source>txt_5_conductivity</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_5_conductivity</source>
			<translation>txt_5_conductivity</translation>
		</message>
		<message>
			<source>txt_5_open_level</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_5_open_level</source>
			<translation>txt_5_open_level</translation>
		</message>
		<message>
			<source>txt_5_swale_side_slope</source>
			<translation>5</translation>
		</message>
		<message>
			<source>tooltip_txt_5_swale_side_slope</source>
			<translation>txt_5_swale_side_slope</translation>
		</message>
		<message>
			<source>txt_6_closed_level</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_closed_level</source>
			<translation>txt_6_closed_level</translation>
		</message>
		<message>
			<source>txt_6_conducticity_slope</source>
			<translation>10.0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_conducticity_slope</source>
			<translation>txt_6_conducticity_slope</translation>
		</message>
		<message>
			<source>txt_6_regeneration_interval</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_regeneration_interval</source>
			<translation>txt_6_regeneration_interval</translation>
		</message>
		<message>
			<source>txt_7_regeneration_fraction</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_7_regeneration_fraction</source>
			<translation>txt_7_regeneration_fraction</translation>
		</message>
		<message>
			<source>txt_7_suction_head</source>
			<translation>3.5</translation>
		</message>
		<message>
			<source>tooltip_txt_7_suction_head</source>
			<translation>txt_7_suction_head</translation>
		</message>
		<message>
			<source>txt_flow_capacity</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_flow_capacity</source>
			<translation>txt_flow_capacity</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_manager</name>
		<message>
			<source>title</source>
			<translation>Manager de obiecte non-vizuale</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplicat</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>Duplicat</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Forma în PNG</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>btn_print</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Comutare activă</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Arată inactiv</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Arată inactiv</translation>
		</message>
		<message>
			<source>dlg_nonvisual_manager</source>
			<translation>Manager de obiecte non-vizuale</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_manager</source>
			<translation>dlg_nonvisual_manager</translation>
		</message>
		<message>
			<source>lbl_curve_type</source>
			<translation>Tip de curbă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_type</source>
			<translation>Tip de curbă</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtrați prin:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Tip model:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>Tip model</translation>
		</message>
		<message>
			<source>lbl_timser_type</source>
			<translation>Tip Timeseries:</translation>
		</message>
		<message>
			<source>tooltip_lbl_timser_type</source>
			<translation>Tipul de serie cronologică</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_pattern_ud</name>
		<message>
			<source>title</source>
			<translation>Editor de modele</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_pattern_ud</source>
			<translation>Editor de modele</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_pattern_ud</source>
			<translation>dlg_nonvisual_pattern_ud</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>ID operațiune</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observație</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_pattern_id</source>
			<translation>ID model</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_id</source>
			<translation>lbl_pattern_id</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Tip model</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>lbl_pattern_type</translation>
		</message>
		<message>
			<source>tbl_daily</source>
			<translation>SUN</translation>
		</message>
		<message>
			<source>tooltip_tbl_daily</source>
			<translation>tbl_daily</translation>
		</message>
		<message>
			<source>tbl_hourly</source>
			<translation>11PM</translation>
		</message>
		<message>
			<source>tooltip_tbl_hourly</source>
			<translation>tbl_hourly</translation>
		</message>
		<message>
			<source>tbl_monthly</source>
			<translation>DEC</translation>
		</message>
		<message>
			<source>tooltip_tbl_monthly</source>
			<translation>tbl_monthly</translation>
		</message>
		<message>
			<source>tbl_weekend</source>
			<translation>11PM</translation>
		</message>
		<message>
			<source>tooltip_tbl_weekend</source>
			<translation>tbl_weekend</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_pattern_ws</name>
		<message>
			<source>title</source>
			<translation>Editor de modele</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_pattern_ws</source>
			<translation>Editor de modele</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_pattern_ws</source>
			<translation>dlg_nonvisual_pattern_ws</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observație</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_pattern_id</source>
			<translation>ID model</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_id</source>
			<translation>lbl_pattern_id</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>ID operațiune</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>lbl_pattern_type</translation>
		</message>
		<message>
			<source>tbl_pattern_value</source>
			<translation>18</translation>
		</message>
		<message>
			<source>tooltip_tbl_pattern_value</source>
			<translation>tbl_pattern_value</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_print</name>
		<message>
			<source>title</source>
			<translation>Obiect non-vizual Imprimare</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>chk_cross_arccat</source>
			<translation>Cruce cu arccat</translation>
		</message>
		<message>
			<source>tooltip_chk_cross_arccat</source>
			<translation>chk_cross_arccat</translation>
		</message>
		<message>
			<source>dlg_nonvisual_print</source>
			<translation>Obiect non-vizual Imprimare</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_print</source>
			<translation>dlg_nonvisual_print</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_roughness</name>
		<message>
			<source>title</source>
			<translation>Editor de controale bazate pe reguli</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Activ</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_roughness</source>
			<translation>Editor de controale bazate pe reguli</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_roughness</source>
			<translation>dlg_nonvisual_roughness</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Perioada ID</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Vârsta init</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Vârsta finală</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Rugozitatea</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Descript</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>lbl_matcat_id</source>
			<translation>Matcat ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_matcat_id</source>
			<translation>lbl_matcat_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_rules</name>
		<message>
			<source>title</source>
			<translation>Editor de controale bazate pe reguli</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Activ</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_rules</source>
			<translation>Editor de controale bazate pe reguli</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_rules</source>
			<translation>dlg_nonvisual_rules</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Observ</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_sector_id</source>
			<translation>ID sector</translation>
		</message>
		<message>
			<source>tooltip_lbl_sector_id</source>
			<translation>lbl_sector_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_timeseries</name>
		<message>
			<source>title</source>
			<translation>Editor de serii de timp</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_timeseries</source>
			<translation>Editor de serii de timp</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_timeseries</source>
			<translation>dlg_nonvisual_timeseries</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Timp Tip</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Descriere</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>ID operațiune</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Activ</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_addparam</source>
			<translation>Addparam (json)</translation>
		</message>
		<message>
			<source>tooltip_lbl_addparam</source>
			<translation>lbl_addparam</translation>
		</message>
		<message>
			<source>lbl_curve_id</source>
			<translation>ID serie cronologică</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_id</source>
			<translation>lbl_curve_id</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Tipul seriei de timp</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_fname</source>
			<translation>Numele fișierului</translation>
		</message>
		<message>
			<source>tooltip_lbl_fname</source>
			<translation>lbl_fname</translation>
		</message>
		<message>
			<source>tbl_timeseries_value</source>
			<translation>Valoare</translation>
		</message>
		<message>
			<source>tooltip_tbl_timeseries_value</source>
			<translation>tbl_timeseries_value</translation>
		</message>
	</context>
	<context>
		<name>print</name>
		<message>
			<source>title</source>
			<translation>Imprimare rapidă</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_preview</source>
			<translation>Previzualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_preview</source>
			<translation>btn_preview</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Imprimare</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>btn_print</translation>
		</message>
		<message>
			<source>dlg_print</source>
			<translation>Imprimare rapidă</translation>
		</message>
		<message>
			<source>tooltip_dlg_print</source>
			<translation>dlg_print</translation>
		</message>
		<message>
			<source>grb_map_options</source>
			<translation>Opțiunile hărții:</translation>
		</message>
		<message>
			<source>tooltip_grb_map_options</source>
			<translation>grb_map_options</translation>
		</message>
		<message>
			<source>grb_option_values</source>
			<translation>Valori opționale:</translation>
		</message>
		<message>
			<source>tooltip_grb_option_values</source>
			<translation>grb_option_values</translation>
		</message>
	</context>
	<context>
		<name>priority</name>
		<message>
			<source>title</source>
			<translation>Calcularea priorității</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Aleargă</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_again</source>
			<translation>Următorul</translation>
		</message>
		<message>
			<source>tooltip_btn_again</source>
			<translation>btn_again</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_save2file</source>
			<translation>Salvați rezultatele într-un fișier Excel...</translation>
		</message>
		<message>
			<source>tooltip_btn_save2file</source>
			<translation>btn_save2file</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>Selectați caracteristicile pe pânză</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Select features on canvas</translation>
		</message>
		<message>
			<source>dlg_priority</source>
			<translation>Calcularea priorității</translation>
		</message>
		<message>
			<source>tooltip_dlg_priority</source>
			<translation>dlg_priority</translation>
		</message>
		<message>
			<source>grb_engine_1</source>
			<translation>grb_engine_1</translation>
		</message>
		<message>
			<source>tooltip_grb_engine_1</source>
			<translation>grb_engine_1</translation>
		</message>
		<message>
			<source>grb_engine_2</source>
			<translation>grb_engine_2</translation>
		</message>
		<message>
			<source>tooltip_grb_engine_2</source>
			<translation>grb_engine_2</translation>
		</message>
		<message>
			<source>grb_global</source>
			<translation>Parametrii de calcul</translation>
		</message>
		<message>
			<source>tooltip_grb_global</source>
			<translation>grb_global</translation>
		</message>
		<message>
			<source>grb_selection</source>
			<translation>Selectarea caracteristicilor</translation>
		</message>
		<message>
			<source>tooltip_grb_selection</source>
			<translation>grb_selection</translation>
		</message>
		<message>
			<source>lbl_budget</source>
			<translation>Buget anual:</translation>
		</message>
		<message>
			<source>tooltip_lbl_budget</source>
			<translation>lbl_budget</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_dnom</source>
			<translation>Diametru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dnom</source>
			<translation>lbl_dnom</translation>
		</message>
		<message>
			<source>lbl_expl_selection</source>
			<translation>Funcționare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_selection</source>
			<translation>lbl_expl_selection</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Material:</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>lbl_material</translation>
		</message>
		<message>
			<source>lbl_presszone</source>
			<translation>Zona de presă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_presszone</source>
			<translation>lbl_presszone</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Numele rezultatului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Statutul:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_year</source>
			<translation>Anul de orizont:</translation>
		</message>
		<message>
			<source>tooltip_lbl_year</source>
			<translation>lbl_year</translation>
		</message>
		<message>
			<source>tab_calc</source>
			<translation>Calculul</translation>
		</message>
		<message>
			<source>tooltip_tab_calc</source>
			<translation>tab_calc</translation>
		</message>
		<message>
			<source>tab_catalog</source>
			<translation>Catalog</translation>
		</message>
		<message>
			<source>tooltip_tab_catalog</source>
			<translation>tab_catalog</translation>
		</message>
		<message>
			<source>tab_engine</source>
			<translation>Motor</translation>
		</message>
		<message>
			<source>tooltip_tab_engine</source>
			<translation>tab_engine</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_material</source>
			<translation>Material</translation>
		</message>
		<message>
			<source>tooltip_tab_material</source>
			<translation>tab_material</translation>
		</message>
	</context>
	<context>
		<name>priority_manager</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_corporate</source>
			<translation>Set Corporate</translation>
		</message>
		<message>
			<source>tooltip_btn_corporate</source>
			<translation>btn_corporate</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplicat</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_edit</source>
			<translation>Editare</translation>
		</message>
		<message>
			<source>tooltip_btn_edit</source>
			<translation>btn_edit</translation>
		</message>
		<message>
			<source>btn_status</source>
			<translation>Modificarea statutului</translation>
		</message>
		<message>
			<source>tooltip_btn_status</source>
			<translation>btn_status</translation>
		</message>
		<message>
			<source>dlg_priority_manager</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_priority_manager</source>
			<translation>dlg_priority_manager</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Funcționare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtrați după: Numele rezultatului</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Statutul:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Tip:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
	</context>
	<context>
		<name>profile</name>
		<message>
			<source>title</source>
			<translation>Profil de desen</translation>
		</message>
		<message>
			<source>btn_clear_profile</source>
			<translation>Profil clar</translation>
		</message>
		<message>
			<source>tooltip_btn_clear_profile</source>
			<translation>btn_clear_profile</translation>
		</message>
		<message>
			<source>btn_delete_additional_point</source>
			<translation>btn_delete_additional_point</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_additional_point</source>
			<translation>btn_delete_additional_point</translation>
		</message>
		<message>
			<source>btn_draw_profile</source>
			<translation>Profil de tragere</translation>
		</message>
		<message>
			<source>tooltip_btn_draw_profile</source>
			<translation>btn_draw_profile</translation>
		</message>
		<message>
			<source>btn_load_profile</source>
			<translation>Load profiile</translation>
		</message>
		<message>
			<source>tooltip_btn_load_profile</source>
			<translation>btn_load_profile</translation>
		</message>
		<message>
			<source>btn_save_profile</source>
			<translation>Salvare profil</translation>
		</message>
		<message>
			<source>tooltip_btn_save_profile</source>
			<translation>btn_save_profile</translation>
		</message>
		<message>
			<source>date</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date</source>
			<translation>date</translation>
		</message>
		<message>
			<source>dlg_profile</source>
			<translation>Profil de desen</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile</source>
			<translation>dlg_profile</translation>
		</message>
		<message>
			<source>grb_composer</source>
			<translation>Parametrii</translation>
		</message>
		<message>
			<source>tooltip_grb_composer</source>
			<translation>grb_composer</translation>
		</message>
		<message>
			<source>grb_profile</source>
			<translation>Profil</translation>
		</message>
		<message>
			<source>tooltip_grb_profile</source>
			<translation>grb_profile</translation>
		</message>
		<message>
			<source>lbl_date</source>
			<translation>Data:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date</source>
			<translation>Date to be displayed</translation>
		</message>
		<message>
			<source>lbl_min_distance</source>
			<translation>Vnode Min Dist:</translation>
		</message>
		<message>
			<source>tooltip_lbl_min_distance</source>
			<translation>Minimum distance between vnodes to be displayed</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Titlu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>Profile title to be displayed</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>bara de instrumente</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>txt_profile_id</source>
			<translation>ID profil opțional</translation>
		</message>
		<message>
			<source>tooltip_txt_profile_id</source>
			<translation>Optional profile ID</translation>
		</message>
	</context>
	<context>
		<name>profile_interpolation</name>
		<message>
			<source>title</source>
			<translation>Profile interpolation</translation>
		</message>
		<message>
			<source>dlg_profile_interpolation</source>
			<translation>Profile interpolation</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile_interpolation</source>
			<translation>dlg_profile_interpolation</translation>
		</message>
	</context>
	<context>
		<name>profile_list</name>
		<message>
			<source>title</source>
			<translation>Profiluri de încărcare</translation>
		</message>
		<message>
			<source>btn_delete_profile</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_profile</source>
			<translation>btn_delete_profile</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Deschis</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_profile_list</source>
			<translation>Profiluri de încărcare</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile_list</source>
			<translation>dlg_profile_list</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Lista de profiluri</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
	</context>
	<context>
		<name>project_check</name>
		<message>
			<source>title</source>
			<translation>Verificați proiectul</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>dlg_project_check</source>
			<translation>Verificați proiectul</translation>
		</message>
		<message>
			<source>tooltip_dlg_project_check</source>
			<translation>dlg_project_check</translation>
		</message>
		<message>
			<source>tab_databaselog</source>
			<translation>Jurnalul bazei de date</translation>
		</message>
		<message>
			<source>tooltip_tab_databaselog</source>
			<translation>tab_databaselog</translation>
		</message>
	</context>
	<context>
		<name>psector</name>
		<message>
			<source>title</source>
			<translation>Plan psector</translation>
		</message>
		<message>
			<source>btn_remove</source>
			<translation>Eliminați</translation>
		</message>
		<message>
			<source>tooltip_btn_remove</source>
			<translation>btn_remove</translation>
		</message>
		<message>
			<source>btn_reports</source>
			<translation>Generarea raportului</translation>
		</message>
		<message>
			<source>tooltip_btn_reports</source>
			<translation>btn_reports</translation>
		</message>
		<message>
			<source>btn_select</source>
			<translation>Adaugă</translation>
		</message>
		<message>
			<source>tooltip_btn_select</source>
			<translation>btn_select</translation>
		</message>
		<message>
			<source>btn_set_geom</source>
			<translation>Setați geometria</translation>
		</message>
		<message>
			<source>tooltip_btn_set_geom</source>
			<translation>btn_set_geom</translation>
		</message>
		<message>
			<source>dlg_psector</source>
			<translation>Plan psector</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector</source>
			<translation>dlg_psector</translation>
		</message>
		<message>
			<source>gexpenses_label</source>
			<translation>Cheltuieli generale</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label</source>
			<translation>gexpenses_label</translation>
		</message>
		<message>
			<source>gexpenses_label_10</source>
			<translation>Total arcuri:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_10</source>
			<translation>gexpenses_label_10</translation>
		</message>
		<message>
			<source>gexpenses_label_3</source>
			<translation>Noduri totale:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_3</source>
			<translation>gexpenses_label_3</translation>
		</message>
		<message>
			<source>gexpenses_label_4</source>
			<translation>Total alte prețuri:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_4</source>
			<translation>gexpenses_label_4</translation>
		</message>
		<message>
			<source>gexpenses_label_5</source>
			<translation>Total:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_5</source>
			<translation>gexpenses_label_5</translation>
		</message>
		<message>
			<source>gexpenses_label_6</source>
			<translation>Total:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_6</source>
			<translation>gexpenses_label_6</translation>
		</message>
		<message>
			<source>gexpenses_label_7</source>
			<translation>Total:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_7</source>
			<translation>gexpenses_label_7</translation>
		</message>
		<message>
			<source>gexpenses_label_8</source>
			<translation>Total:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_8</source>
			<translation>gexpenses_label_8</translation>
		</message>
		<message>
			<source>lbl_num_value</source>
			<translation>Valoarea numerică:</translation>
		</message>
		<message>
			<source>tooltip_lbl_num_value</source>
			<translation>lbl_num_value</translation>
		</message>
		<message>
			<source>lbl_text3</source>
			<translation>Textul 3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text3</source>
			<translation>lbl_text3</translation>
		</message>
		<message>
			<source>lbl_text4</source>
			<translation>Textul 4:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text4</source>
			<translation>lbl_text4</translation>
		</message>
		<message>
			<source>lbl_text5</source>
			<translation>Textul 5:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text5</source>
			<translation>lbl_text5</translation>
		</message>
		<message>
			<source>lbl_text6</source>
			<translation>Textul 6:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text6</source>
			<translation>lbl_text6</translation>
		</message>
		<message>
			<source>lbl_total</source>
			<translation>Total :</translation>
		</message>
		<message>
			<source>tooltip_lbl_total</source>
			<translation>lbl_total</translation>
		</message>
		<message>
			<source>lbl_total_count</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_lbl_total_count</source>
			<translation>lbl_total_count</translation>
		</message>
		<message>
			<source>other_label</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label</source>
			<translation>other_label</translation>
		</message>
		<message>
			<source>other_label_2</source>
			<translation>Alte cheltuieli</translation>
		</message>
		<message>
			<source>tooltip_other_label_2</source>
			<translation>other_label_2</translation>
		</message>
		<message>
			<source>other_label_3</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_3</source>
			<translation>other_label_3</translation>
		</message>
		<message>
			<source>other_label_4</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_4</source>
			<translation>other_label_4</translation>
		</message>
		<message>
			<source>tab_additional_info</source>
			<translation>Informații suplimentare</translation>
		</message>
		<message>
			<source>tooltip_tab_additional_info</source>
			<translation>tab_additional_info</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_budget</source>
			<translation>Buget</translation>
		</message>
		<message>
			<source>tooltip_tab_budget</source>
			<translation>tab_budget</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Document</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>tab_document</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Generalități</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_other_prices</source>
			<translation>Alte prețuri</translation>
		</message>
		<message>
			<source>tooltip_tab_other_prices</source>
			<translation>tab_other_prices</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relații</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
		<message>
			<source>vat_label</source>
			<translation>TVA:</translation>
		</message>
		<message>
			<source>tooltip_vat_label</source>
			<translation>vat_label</translation>
		</message>
	</context>
	<context>
		<name>psector_duplicate</name>
		<message>
			<source>title</source>
			<translation>Psector duplicat</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_psector_duplicate</source>
			<translation>Psector duplicat</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_duplicate</source>
			<translation>dlg_psector_duplicate</translation>
		</message>
		<message>
			<source>lbl_duplicate_psector</source>
			<translation>Duplicate psector:</translation>
		</message>
		<message>
			<source>tooltip_lbl_duplicate_psector</source>
			<translation>lbl_duplicate_psector</translation>
		</message>
		<message>
			<source>lbl_new_psector</source>
			<translation>Noua denumire a sectorului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_psector</source>
			<translation>lbl_new_psector</translation>
		</message>
		<message>
			<source>tab_duplicate_psector</source>
			<translation>Psector duplicat</translation>
		</message>
		<message>
			<source>tooltip_tab_duplicate_psector</source>
			<translation>tab_duplicate_psector</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>psector_manager</name>
		<message>
			<source>title</source>
			<translation>Managementul sectorului</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplicat</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_merge</source>
			<translation>Unire</translation>
		</message>
		<message>
			<source>tooltip_btn_merge</source>
			<translation>Pentru a uni mai mulți psectori într-unul singur, trebuie să îi selectați anterior folosind Ctrl și apoi să faceți clic pe acest buton</translation>
		</message>
		<message>
			<source>btn_restore</source>
			<translation>Restaurare</translation>
		</message>
		<message>
			<source>tooltip_btn_restore</source>
			<translation>btn_restore</translation>
		</message>
		<message>
			<source>btn_show</source>
			<translation>Spectacol</translation>
		</message>
		<message>
			<source>tooltip_btn_show</source>
			<translation>btn_show</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Comutare activă</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>btn_update_psector</source>
			<translation>Comutare curent</translation>
		</message>
		<message>
			<source>tooltip_btn_update_psector</source>
			<translation>btn_update_psector</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Arată inactiv</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Arată inactiv</translation>
		</message>
		<message>
			<source>chk_archived</source>
			<translation>Afișare arhivată</translation>
		</message>
		<message>
			<source>tooltip_chk_archived</source>
			<translation>chk_archived</translation>
		</message>
		<message>
			<source>chk_filter_canvas</source>
			<translation>Filtru din pânză</translation>
		</message>
		<message>
			<source>tooltip_chk_filter_canvas</source>
			<translation>Afișați numai psectoarele vizibile în pânză</translation>
		</message>
		<message>
			<source>dlg_psector_manager</source>
			<translation>Managementul sectorului</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_manager</source>
			<translation>dlg_psector_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_psector_name</source>
			<translation>Filtrați după: Numele sectorului</translation>
		</message>
		<message>
			<source>tooltip_lbl_psector_name</source>
			<translation>lbl_psector_name</translation>
		</message>
	</context>
	<context>
		<name>psector_rapport</name>
		<message>
			<source>title</source>
			<translation>Raport sectorial</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>chk_composer</source>
			<translation>Compozitor fișier pdf</translation>
		</message>
		<message>
			<source>tooltip_chk_composer</source>
			<translation>chk_composer</translation>
		</message>
		<message>
			<source>dlg_psector_rapport</source>
			<translation>Raport sectorial</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_rapport</source>
			<translation>dlg_psector_rapport</translation>
		</message>
		<message>
			<source>grb_rapport</source>
			<translation>Raport</translation>
		</message>
		<message>
			<source>tooltip_grb_rapport</source>
			<translation>grb_rapport</translation>
		</message>
		<message>
			<source>lbl_detail_csv</source>
			<translation>Detaliu fișier csv:</translation>
		</message>
		<message>
			<source>tooltip_lbl_detail_csv</source>
			<translation>lbl_detail_csv</translation>
		</message>
		<message>
			<source>lbl_prices_list</source>
			<translation>Fișier csv cu lista de prețuri:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prices_list</source>
			<translation>lbl_prices_list</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Șablon</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
	</context>
	<context>
		<name>psector_repair</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_repair</source>
			<translation>Reparare</translation>
		</message>
		<message>
			<source>tooltip_btn_repair</source>
			<translation>btn_repair</translation>
		</message>
		<message>
			<source>dlg_psector_repair</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_repair</source>
			<translation>dlg_psector_repair</translation>
		</message>
	</context>
	<context>
		<name>replace_in_file</name>
		<message>
			<source>title</source>
			<translation>Înlocuiți textul din fișier</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_replace_in_file</source>
			<translation>Înlocuiți textul din fișier</translation>
		</message>
		<message>
			<source>tooltip_dlg_replace_in_file</source>
			<translation>dlg_replace_in_file</translation>
		</message>
		<message>
			<source>lbl_subtitle</source>
			<translation>Există obiecte cu mai mult de 16 caractere în numele lor</translation>
		</message>
		<message>
			<source>tooltip_lbl_subtitle</source>
			<translation>lbl_subtitle</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Înlocuiți aceste nume cu altele noi:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
	</context>
	<context>
		<name>resources_management</name>
		<message>
			<source>btn_assign_team</source>
			<translation>Atribuiți echipa</translation>
		</message>
		<message>
			<source>tooltip_btn_assign_team</source>
			<translation>btn_assign_team</translation>
		</message>
		<message>
			<source>btn_campaign_save</source>
			<translation>Save</translation>
		</message>
		<message>
			<source>tooltip_btn_campaign_save</source>
			<translation>btn_campaign_save</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>btn_remove_team</source>
			<translation>Eliminați echipa</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_team</source>
			<translation>btn_remove_team</translation>
		</message>
		<message>
			<source>btn_team_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_team_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>btn_team_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_team_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>btn_team_toggle_active</source>
			<translation>Comutare activă</translation>
		</message>
		<message>
			<source>tooltip_btn_team_toggle_active</source>
			<translation>btn_team_toggle_active</translation>
		</message>
		<message>
			<source>btn_team_update</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_team_update</source>
			<translation>Modificați</translation>
		</message>
		<message>
			<source>btn_user_toggle_active</source>
			<translation>Comutare activă</translation>
		</message>
		<message>
			<source>tooltip_btn_user_toggle_active</source>
			<translation>btn_user_toggle_active</translation>
		</message>
		<message>
			<source>cmb_team</source>
			<translation>Selectați echipa</translation>
		</message>
		<message>
			<source>tooltip_cmb_team</source>
			<translation>cmb_team</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Filtrați după nume:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Filtrați după numele echipei:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Filtrați după echipă:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>resource_management</source>
			<translation>Gestionarea resurselor</translation>
		</message>
		<message>
			<source>tooltip_resource_management</source>
			<translation>resource_management</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Campaign revision</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_organizations</source>
			<translation>Organizații</translation>
		</message>
		<message>
			<source>tooltip_tab_organizations</source>
			<translation>tab_organizations</translation>
		</message>
		<message>
			<source>tab_teams</source>
			<translation>Echipe</translation>
		</message>
		<message>
			<source>tooltip_tab_teams</source>
			<translation>tab_teams</translation>
		</message>
		<message>
			<source>tab_users</source>
			<translation>Utilizatori</translation>
		</message>
		<message>
			<source>tooltip_tab_users</source>
			<translation>tab_users</translation>
		</message>
	</context>
	<context>
		<name>result_selector</name>
		<message>
			<source>title</source>
			<translation>Selector de rezultate</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_result_selector</source>
			<translation>Selector de rezultate</translation>
		</message>
		<message>
			<source>tooltip_dlg_result_selector</source>
			<translation>dlg_result_selector</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_descript_compare</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_compare</source>
			<translation>lbl_descript_compare</translation>
		</message>
		<message>
			<source>lbl_result_compare</source>
			<translation>Rezultat de comparat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_compare</source>
			<translation>lbl_result_compare</translation>
		</message>
		<message>
			<source>lbl_result_main</source>
			<translation>Rezultat pentru a arăta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_main</source>
			<translation>lbl_result_main</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Rezultat</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
	</context>
	<context>
		<name>scada_graph</name>
		<message>
			<source>title</source>
			<translation>Scada graph</translation>
		</message>
		<message>
			<source>dlg_scada_graph</source>
			<translation>Scada graph</translation>
		</message>
		<message>
			<source>tooltip_dlg_scada_graph</source>
			<translation>dlg_scada_graph</translation>
		</message>
	</context>
	<context>
		<name>search_workcat</name>
		<message>
			<source>title</source>
			<translation>Căutare Workcat</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_export_to_csv</source>
			<translation>Export la csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_to_csv</source>
			<translation>btn_export_to_csv</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_state0</source>
			<translation>Activați</translation>
		</message>
		<message>
			<source>tooltip_btn_state0</source>
			<translation>btn_state0</translation>
		</message>
		<message>
			<source>btn_state1</source>
			<translation>Activați</translation>
		</message>
		<message>
			<source>tooltip_btn_state1</source>
			<translation>btn_state1</translation>
		</message>
		<message>
			<source>dlg_search_workcat</source>
			<translation>Căutare Workcat</translation>
		</message>
		<message>
			<source>tooltip_dlg_search_workcat</source>
			<translation>dlg_search_workcat</translation>
		</message>
		<message>
			<source>lbl_destination_path</source>
			<translation>Calea de destinație:</translation>
		</message>
		<message>
			<source>tooltip_lbl_destination_path</source>
			<translation>lbl_destination_path</translation>
		</message>
		<message>
			<source>lbl_end</source>
			<translation>Filtrare după: cod</translation>
		</message>
		<message>
			<source>tooltip_lbl_end</source>
			<translation>lbl_end</translation>
		</message>
		<message>
			<source>lbl_feat_end</source>
			<translation>Caracteristici eliminate cu pisica de lucru selectată</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_end</source>
			<translation>lbl_feat_end</translation>
		</message>
		<message>
			<source>lbl_feat_ini</source>
			<translation>Caracteristici instalate cu workcat-ul selectat</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_ini</source>
			<translation>lbl_feat_ini</translation>
		</message>
		<message>
			<source>lbl_init</source>
			<translation>Filtrare după: cod</translation>
		</message>
		<message>
			<source>tooltip_lbl_init</source>
			<translation>lbl_init</translation>
		</message>
		<message>
			<source>lbl_total1</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;&amp;lt;span style=&amp;quot; font-weight:600;&amp;quot;&amp;gt;Total numere:&amp;lt;/span&amp;gt;&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_lbl_total1</source>
			<translation>lbl_total1</translation>
		</message>
		<message>
			<source>lbl_total2</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;&amp;lt;span style=&amp;quot; font-weight:600;&amp;quot;&amp;gt;Total numere:&amp;lt;/span&amp;gt;&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_lbl_total2</source>
			<translation>lbl_total2</translation>
		</message>
		<message>
			<source>tab_doc</source>
			<translation>Documente</translation>
		</message>
		<message>
			<source>tooltip_tab_doc</source>
			<translation>tab_doc</translation>
		</message>
		<message>
			<source>tab_ended</source>
			<translation>Eliminat</translation>
		</message>
		<message>
			<source>tooltip_tab_ended</source>
			<translation>tab_ended</translation>
		</message>
		<message>
			<source>tab_init</source>
			<translation>Instalat</translation>
		</message>
		<message>
			<source>tooltip_tab_init</source>
			<translation>tab_init</translation>
		</message>
	</context>
	<context>
		<name>selector</name>
		<message>
			<source>title</source>
			<translation>Selector</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_selector</source>
			<translation>Selector</translation>
		</message>
		<message>
			<source>tooltip_dlg_selector</source>
			<translation>dlg_selector</translation>
		</message>
	</context>
	<context>
		<name>selector_date</name>
		<message>
			<source>title</source>
			<translation>Selector de dată</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>date_from</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date_from</source>
			<translation>date_from</translation>
		</message>
		<message>
			<source>date_to</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date_to</source>
			<translation>date_to</translation>
		</message>
		<message>
			<source>dlg_selector_date</source>
			<translation>Selector de dată</translation>
		</message>
		<message>
			<source>tooltip_dlg_selector_date</source>
			<translation>dlg_selector_date</translation>
		</message>
		<message>
			<source>lbl_date_from</source>
			<translation>Data de la:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_from</source>
			<translation>lbl_date_from</translation>
		</message>
		<message>
			<source>lbl_date_to</source>
			<translation>Data până la:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_to</source>
			<translation>lbl_date_to</translation>
		</message>
	</context>
	<context>
		<name>snapshot_view</name>
		<message>
			<source>Audit</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>tooltip_Audit</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Caracteristici de recuperat</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Caracteristici de recuperat</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Selecția temporală și spațială</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Selecția temporală și spațială</translation>
		</message>
	</context>
	<context>
		<name>status_selector</name>
		<message>
			<source>title</source>
			<translation>Selector de stare</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_status_selector</source>
			<translation>Selector de stare</translation>
		</message>
		<message>
			<source>tooltip_dlg_status_selector</source>
			<translation>dlg_status_selector</translation>
		</message>
		<message>
			<source>lbl_new_status</source>
			<translation>Stare nouă:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_status</source>
			<translation>lbl_new_status</translation>
		</message>
		<message>
			<source>lbl_result</source>
			<translation>result_id: result_name</translation>
		</message>
		<message>
			<source>tooltip_lbl_result</source>
			<translation>lbl_result</translation>
		</message>
		<message>
			<source>lbl_result_main</source>
			<translation>Modificați starea următorului rezultat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_main</source>
			<translation>lbl_result_main</translation>
		</message>
	</context>
	<context>
		<name>style</name>
		<message>
			<source>title</source>
			<translation>Adaugă categorie</translation>
		</message>
		<message>
			<source>btn_add</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_add</source>
			<translation>btn_add</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_style</source>
			<translation>Adaugă categorie</translation>
		</message>
		<message>
			<source>tooltip_dlg_style</source>
			<translation>dlg_style</translation>
		</message>
		<message>
			<source>lbl_cat_id</source>
			<translation>Categorie ID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_id</source>
			<translation>lbl_cat_id</translation>
		</message>
		<message>
			<source>lbl_cat_name</source>
			<translation>Numele categoriei:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_name</source>
			<translation>lbl_cat_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_role</source>
			<translation>Role:</translation>
		</message>
		<message>
			<source>tooltip_lbl_role</source>
			<translation>lbl_role</translation>
		</message>
		<message>
			<source>tab_del_feature</source>
			<translation>Date</translation>
		</message>
		<message>
			<source>tooltip_tab_del_feature</source>
			<translation>tab_del_feature</translation>
		</message>
	</context>
	<context>
		<name>style_manager</name>
		<message>
			<source>title</source>
			<translation>Gestionarea stilului</translation>
		</message>
		<message>
			<source>btn_add_style</source>
			<translation>Adaugă stil</translation>
		</message>
		<message>
			<source>tooltip_btn_add_style</source>
			<translation>Adaugă stil</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>btn_delete_style</source>
			<translation>Ștergeți stilul</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_style</source>
			<translation>btn_delete_style</translation>
		</message>
		<message>
			<source>btn_refresh_all</source>
			<translation>Actualizați toate</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh_all</source>
			<translation>Actualizați toate</translation>
		</message>
		<message>
			<source>btn_update_group</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_update_group</source>
			<translation>Actualizarea categoriei selectate</translation>
		</message>
		<message>
			<source>btn_update_style</source>
			<translation>Actualizare stil</translation>
		</message>
		<message>
			<source>tooltip_btn_update_style</source>
			<translation>Actualizare stil</translation>
		</message>
		<message>
			<source>dlg_style_manager</source>
			<translation>Gestionarea stilului</translation>
		</message>
		<message>
			<source>tooltip_dlg_style_manager</source>
			<translation>dlg_style_manager</translation>
		</message>
		<message>
			<source>lbl_filter_category</source>
			<translation>Filtrați după: Categorie</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_category</source>
			<translation>lbl_filter_category</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtrare după: layername</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>style_update_category</name>
		<message>
			<source>title</source>
			<translation>Redenumiți categoria</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_style_update_category</source>
			<translation>Redenumiți categoria</translation>
		</message>
		<message>
			<source>tooltip_dlg_style_update_category</source>
			<translation>dlg_style_update_category</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Vă rugăm să selectați un nou nume de categorie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>lbl_rename_copy</translation>
		</message>
	</context>
	<context>
		<name>team_create</name>
		<message>
			<source>title</source>
			<translation>Creați o echipă</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>dlg_team_create</source>
			<translation>Creați o echipă</translation>
		</message>
		<message>
			<source>tooltip_dlg_team_create</source>
			<translation>dlg_team_create</translation>
		</message>
		<message>
			<source>grb_team</source>
			<translation>Echipa:</translation>
		</message>
		<message>
			<source>tooltip_grb_team</source>
			<translation>grb_team</translation>
		</message>
		<message>
			<source>TeamTab</source>
			<translation>Echipa</translation>
		</message>
		<message>
			<source>tooltip_TeamTab</source>
			<translation>TeamTab</translation>
		</message>
	</context>
	<context>
		<name>team_management</name>
		<message>
			<source>title</source>
			<translation>Managementul echipei</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_user_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_user_select</source>
			<translation>btn_user_select</translation>
		</message>
		<message>
			<source>btn_user_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_user_unselect</source>
			<translation>btn_user_unselect</translation>
		</message>
		<message>
			<source>btn_vehicle_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_vehicle_select</source>
			<translation>btn_vehicle_select</translation>
		</message>
		<message>
			<source>btn_vehicle_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_vehicle_unselect</source>
			<translation>btn_vehicle_unselect</translation>
		</message>
		<message>
			<source>btn_visitclass_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_visitclass_select</source>
			<translation>btn_visitclass_select</translation>
		</message>
		<message>
			<source>btn_visitclass_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_visitclass_unselect</source>
			<translation>btn_visitclass_unselect</translation>
		</message>
		<message>
			<source>dlg_team_management</source>
			<translation>Managementul echipei</translation>
		</message>
		<message>
			<source>tooltip_dlg_team_management</source>
			<translation>dlg_team_management</translation>
		</message>
		<message>
			<source>tab_user</source>
			<translation>Utilizatori</translation>
		</message>
		<message>
			<source>tooltip_tab_user</source>
			<translation>Utilizatori</translation>
		</message>
		<message>
			<source>tab_vehicles</source>
			<translation>Vehicule</translation>
		</message>
		<message>
			<source>tooltip_tab_vehicles</source>
			<translation>Vehicule</translation>
		</message>
		<message>
			<source>tab_visit_class</source>
			<translation>Vizitați clasa</translation>
		</message>
		<message>
			<source>tooltip_tab_visit_class</source>
			<translation>Vizitați clasa</translation>
		</message>
	</context>
	<context>
		<name>toolbox</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>dlg_toolbox</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_toolbox</source>
			<translation>dlg_toolbox</translation>
		</message>
	</context>
	<context>
		<name>toolbox_reports</name>
		<message>
			<source>title</source>
			<translation>Rapoarte</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_export</source>
			<translation>Export</translation>
		</message>
		<message>
			<source>tooltip_btn_export</source>
			<translation>btn_export</translation>
		</message>
		<message>
			<source>btn_export_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_export_path</source>
			<translation>btn_export_path</translation>
		</message>
		<message>
			<source>dlg_toolbox_reports</source>
			<translation>Rapoarte</translation>
		</message>
		<message>
			<source>tooltip_dlg_toolbox_reports</source>
			<translation>dlg_toolbox_reports</translation>
		</message>
		<message>
			<source>grb_filters</source>
			<translation>Filtre</translation>
		</message>
		<message>
			<source>tooltip_grb_filters</source>
			<translation>grb_filters</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Întrebare:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>lbl_export_path</source>
			<translation>Calea:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_path</source>
			<translation>lbl_export_path</translation>
		</message>
	</context>
	<context>
		<name>toolbox_tool</name>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_run</source>
			<translation>Aleargă</translation>
		</message>
		<message>
			<source>tooltip_btn_run</source>
			<translation>btn_run</translation>
		</message>
		<message>
			<source>grb_input_layer</source>
			<translation>Stratul de intrare:</translation>
		</message>
		<message>
			<source>tooltip_grb_input_layer</source>
			<translation>grb_input_layer</translation>
		</message>
		<message>
			<source>grb_parameters</source>
			<translation>Parametrii opțiunii:</translation>
		</message>
		<message>
			<source>tooltip_grb_parameters</source>
			<translation>grb_parameters</translation>
		</message>
		<message>
			<source>grb_selection_type</source>
			<translation>Tip de selecție:</translation>
		</message>
		<message>
			<source>tooltip_grb_selection_type</source>
			<translation>grb_selection_type</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>progressBar</source>
			<translation>%p%</translation>
		</message>
		<message>
			<source>tooltip_progressBar</source>
			<translation>progressBar</translation>
		</message>
		<message>
			<source>rbt_layer</source>
			<translation>Toate caracteristicile</translation>
		</message>
		<message>
			<source>tooltip_rbt_layer</source>
			<translation>rbt_layer</translation>
		</message>
		<message>
			<source>rbt_previous</source>
			<translation>Numai caracteristici selectate</translation>
		</message>
		<message>
			<source>tooltip_rbt_previous</source>
			<translation>rbt_previous</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Configurare</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>visit</name>
		<message>
			<source>title</source>
			<translation>Vizită</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Adăugați geom</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>btn_add_geom</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_event_delete</source>
			<translation>ȘTERGE EVENIMENTUL</translation>
		</message>
		<message>
			<source>tooltip_btn_event_delete</source>
			<translation>btn_event_delete</translation>
		</message>
		<message>
			<source>btn_event_insert</source>
			<translation>INSERAȚI EVENIMENTUL</translation>
		</message>
		<message>
			<source>tooltip_btn_event_insert</source>
			<translation>btn_event_insert</translation>
		</message>
		<message>
			<source>btn_event_update</source>
			<translation>UPDATE EVENIMENT</translation>
		</message>
		<message>
			<source>tooltip_btn_event_update</source>
			<translation>btn_event_update</translation>
		</message>
		<message>
			<source>btn_feature_delete</source>
			<translation>btn_feature_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_delete</source>
			<translation>btn_feature_delete</translation>
		</message>
		<message>
			<source>btn_feature_insert</source>
			<translation>btn_feature_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_insert</source>
			<translation>btn_feature_insert</translation>
		</message>
		<message>
			<source>btn_feature_snapping</source>
			<translation>btn_feature_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_snapping</source>
			<translation>btn_feature_snapping</translation>
		</message>
		<message>
			<source>dlg_visit</source>
			<translation>Vizită</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit</source>
			<translation>dlg_visit</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Tip caracteristică:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation>Cod:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_end_date</source>
			<translation>Data de încheiere:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_date</source>
			<translation>lbl_end_date</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Operațiuni:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Din bara de instrumente sunt activate doar EVENIMENTELE STANDARD.</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_start_date</source>
			<translation>Data de începere:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_date</source>
			<translation>lbl_start_date</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Statutul:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_user_name</source>
			<translation>Nume utilizator:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user_name</source>
			<translation>lbl_user_name</translation>
		</message>
		<message>
			<source>lbl_visitcat_id</source>
			<translation>Visitcat id:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_visitcat_id</source>
			<translation>lbl_visitcat_id</translation>
		</message>
		<message>
			<source>startdate</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_startdate</source>
			<translation>startdate</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Arc</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Conectare</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Document</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>tab_document</translation>
		</message>
		<message>
			<source>tab_event</source>
			<translation>Eveniment</translation>
		</message>
		<message>
			<source>tooltip_tab_event</source>
			<translation>tab_event</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Gully</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link către</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Nod</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relații</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Vizită</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
	</context>
	<context>
		<name>visit_document</name>
		<message>
			<source>title</source>
			<translation>Încărcați documentele</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Deschis</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_visit_document</source>
			<translation>Încărcați documentele</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_document</source>
			<translation>dlg_visit_document</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Lista de documente</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Vizitați id</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_event</name>
		<message>
			<source>title</source>
			<translation>Eveniment standard</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_file</source>
			<translation>Adăugați fișier</translation>
		</message>
		<message>
			<source>tooltip_btn_add_file</source>
			<translation>btn_add_file</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_file</source>
			<translation>Ștergeți fișierul</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_file</source>
			<translation>btn_delete_file</translation>
		</message>
		<message>
			<source>dlg_visit_event</source>
			<translation>Eveniment standard</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event</source>
			<translation>dlg_visit_event</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Event_code:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Fișiere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Parametru id:      </translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Poziția id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Valoarea poziției:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Text:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_value</source>
			<translation>Valoare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value</source>
			<translation>lbl_value</translation>
		</message>
	</context>
	<context>
		<name>visit_event_full</name>
		<message>
			<source>title</source>
			<translation>Eveniment</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_visit_event_full</source>
			<translation>Eveniment</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event_full</source>
			<translation>dlg_visit_event_full</translation>
		</message>
		<message>
			<source>lbl_compass</source>
			<translation>Compas:</translation>
		</message>
		<message>
			<source>tooltip_lbl_compass</source>
			<translation>lbl_compass</translation>
		</message>
		<message>
			<source>lbl_event_code</source>
			<translation>Codul evenimentului:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_code</source>
			<translation>lbl_event_code</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Fișiere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_geom1</source>
			<translation>Geom1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom1</source>
			<translation>lbl_geom1</translation>
		</message>
		<message>
			<source>lbl_geom2</source>
			<translation>Geom2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom2</source>
			<translation>lbl_geom2</translation>
		</message>
		<message>
			<source>lbl_geom3</source>
			<translation>Geom3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom3</source>
			<translation>lbl_geom3</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_index_val</source>
			<translation>Index trap:</translation>
		</message>
		<message>
			<source>tooltip_lbl_index_val</source>
			<translation>lbl_index_val</translation>
		</message>
		<message>
			<source>lbl_is_last</source>
			<translation>Este ultima:</translation>
		</message>
		<message>
			<source>tooltip_lbl_is_last</source>
			<translation>lbl_is_last</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Parametru id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Poziția id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Valoarea poziției:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Text:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_tstamp</source>
			<translation>Tstamp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tstamp</source>
			<translation>lbl_tstamp</translation>
		</message>
		<message>
			<source>lbl_value</source>
			<translation>Valoare:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value</source>
			<translation>lbl_value</translation>
		</message>
		<message>
			<source>lbl_value1</source>
			<translation>Valoare1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value1</source>
			<translation>lbl_value1</translation>
		</message>
		<message>
			<source>lbl_value2</source>
			<translation>Valoare2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value2</source>
			<translation>lbl_value2</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Vizitați id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
		<message>
			<source>lbl_xcoord</source>
			<translation>Xcoord:</translation>
		</message>
		<message>
			<source>tooltip_lbl_xcoord</source>
			<translation>lbl_xcoord</translation>
		</message>
		<message>
			<source>lbl_ycoord</source>
			<translation>Ycoord:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ycoord</source>
			<translation>lbl_ycoord</translation>
		</message>
		<message>
			<source>tab_files</source>
			<translation>Fișiere</translation>
		</message>
		<message>
			<source>tooltip_tab_files</source>
			<translation>tab_files</translation>
		</message>
		<message>
			<source>tab_info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>tooltip_tab_info</source>
			<translation>tab_info</translation>
		</message>
	</context>
	<context>
		<name>visit_event_rehab</name>
		<message>
			<source>title</source>
			<translation>Reabilitare arc eveniment</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_file</source>
			<translation>Adăugați fișier</translation>
		</message>
		<message>
			<source>tooltip_btn_add_file</source>
			<translation>btn_add_file</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_file</source>
			<translation>Ștergeți fișierul</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_file</source>
			<translation>btn_delete_file</translation>
		</message>
		<message>
			<source>dlg_visit_event_rehab</source>
			<translation>Reabilitare arc eveniment</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event_rehab</source>
			<translation>dlg_visit_event_rehab</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Fișiere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_geom1</source>
			<translation>Geom1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom1</source>
			<translation>lbl_geom1</translation>
		</message>
		<message>
			<source>lbl_geom2</source>
			<translation>Geom2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom2</source>
			<translation>lbl_geom2</translation>
		</message>
		<message>
			<source>lbl_geom3</source>
			<translation>Geom3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom3</source>
			<translation>lbl_geom3</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Parametru id:      </translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Poziția id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Valoarea poziției:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Text:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_value1</source>
			<translation>Valoare1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value1</source>
			<translation>lbl_value1</translation>
		</message>
		<message>
			<source>lbl_value2</source>
			<translation>Valoare2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value2</source>
			<translation>lbl_value2</translation>
		</message>
	</context>
	<context>
		<name>visit_gallery</name>
		<message>
			<source>title</source>
			<translation>Galerie</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_next</source>
			<translation>btn_next</translation>
		</message>
		<message>
			<source>tooltip_btn_next</source>
			<translation>btn_next</translation>
		</message>
		<message>
			<source>btn_previous</source>
			<translation>btn_previous</translation>
		</message>
		<message>
			<source>tooltip_btn_previous</source>
			<translation>btn_previous</translation>
		</message>
		<message>
			<source>dlg_visit_gallery</source>
			<translation>Galerie</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_gallery</source>
			<translation>dlg_visit_gallery</translation>
		</message>
		<message>
			<source>lbl_event_id</source>
			<translation>Eveniment id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_id</source>
			<translation>lbl_event_id</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Vizitați id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_gallery_zoom</name>
		<message>
			<source>title</source>
			<translation>Galerie zoom</translation>
		</message>
		<message>
			<source>btn_slideNext</source>
			<translation>btn_slideNext</translation>
		</message>
		<message>
			<source>tooltip_btn_slideNext</source>
			<translation>btn_slideNext</translation>
		</message>
		<message>
			<source>btn_slidePrevious</source>
			<translation>btn_slidePrevious</translation>
		</message>
		<message>
			<source>tooltip_btn_slidePrevious</source>
			<translation>btn_slidePrevious</translation>
		</message>
		<message>
			<source>dlg_visit_gallery_zoom</source>
			<translation>Galerie zoom</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_gallery_zoom</source>
			<translation>dlg_visit_gallery_zoom</translation>
		</message>
		<message>
			<source>lbl_event_id</source>
			<translation>Eveniment id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_id</source>
			<translation>lbl_event_id</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Vizitați id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>lbl_visit_id</translation>
		</message>
	</context>
	<context>
		<name>visit_manager</name>
		<message>
			<source>title</source>
			<translation>Vizitați managementul</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți vizita</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Vizită deschisă</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>date_event_from</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date_event_from</source>
			<translation>date_event_from</translation>
		</message>
		<message>
			<source>date_event_to</source>
			<translation>zz/MM/aaaa</translation>
		</message>
		<message>
			<source>tooltip_date_event_to</source>
			<translation>date_event_to</translation>
		</message>
		<message>
			<source>dlg_visit_manager</source>
			<translation>Vizitați managementul</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_manager</source>
			<translation>dlg_visit_manager</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>De la:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>lbl_data_event_from</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Pentru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>lbl_data_event_to</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtrați după cod:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
	</context>
	<context>
		<name>workcat_manager</name>
		<message>
			<source>title</source>
			<translation>Managementul Workcat</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_workcat_manager</source>
			<translation>Managementul Workcat</translation>
		</message>
		<message>
			<source>tooltip_dlg_workcat_manager</source>
			<translation>dlg_workcat_manager</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtrați după: Numele pisicii de lucru</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>workorder_management</name>
		<message>
			<source>title</source>
			<translation>Gestionarea comenzilor de lucru</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Crearea comenzii de lucru</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_create_wclass</source>
			<translation>Crearea clasei</translation>
		</message>
		<message>
			<source>tooltip_btn_create_wclass</source>
			<translation>btn_create_wclass</translation>
		</message>
		<message>
			<source>btn_create_wtype</source>
			<translation>Creare tip</translation>
		</message>
		<message>
			<source>tooltip_btn_create_wtype</source>
			<translation>btn_create_wtype</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți comanda de lucru</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_workorder_management</source>
			<translation>Gestionarea comenzilor de lucru</translation>
		</message>
		<message>
			<source>tooltip_dlg_workorder_management</source>
			<translation>dlg_workorder_management</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Filtrați după nume:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_column_filter_dates</source>
			<translation>Tip comandă de lucru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter_dates</source>
			<translation>lbl_column_filter_dates</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Clasa comenzii de lucru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
	</context>
	<context>
		<name>workspace_create</name>
		<message>
			<source>title</source>
			<translation>Creați un nou spațiu de lucru</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Acceptați</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anulează</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_workspace_create</source>
			<translation>Creați un nou spațiu de lucru</translation>
		</message>
		<message>
			<source>tooltip_dlg_workspace_create</source>
			<translation>dlg_workspace_create</translation>
		</message>
		<message>
			<source>lbl_new_workspace</source>
			<translation>Numele spațiului de lucru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace</source>
			<translation>Numele spațiului de lucru</translation>
		</message>
		<message>
			<source>lbl_new_workspace_chk</source>
			<translation>Spațiu de lucru privat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace_chk</source>
			<translation>lbl_new_workspace_chk</translation>
		</message>
		<message>
			<source>lbl_new_workspace_descript</source>
			<translation>Descriere:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace_descript</source>
			<translation>Descrierea spațiului de lucru</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Jurnal de informații</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
		<message>
			<source>tab_new_workspace</source>
			<translation>Creați un nou spațiu de lucru</translation>
		</message>
		<message>
			<source>tooltip_tab_new_workspace</source>
			<translation>tab_new_workspace</translation>
		</message>
	</context>
	<context>
		<name>workspace_manager</name>
		<message>
			<source>title</source>
			<translation>Manager de spațiu de lucru</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Închidere</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Creați</translation>
		</message>
		<message>
			<source>btn_current</source>
			<translation>Setați curentul</translation>
		</message>
		<message>
			<source>tooltip_btn_current</source>
			<translation>Setați spațiul de lucru curent</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Ștergeți</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Ștergeți spațiul de lucru selectat</translation>
		</message>
		<message>
			<source>btn_toggle_privacy</source>
			<translation>Modificarea confidențialității</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_privacy</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Actualizare</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Modificarea confidențialității</translation>
		</message>
		<message>
			<source>dlg_workspace_manager</source>
			<translation>Manager de spațiu de lucru</translation>
		</message>
		<message>
			<source>tooltip_dlg_workspace_manager</source>
			<translation>dlg_workspace_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_workspace_name</source>
			<translation>Filtrați după: Numele spațiului de lucru</translation>
		</message>
		<message>
			<source>tooltip_lbl_workspace_name</source>
			<translation>lbl_workspace_name</translation>
		</message>
	</context>
</TS>
