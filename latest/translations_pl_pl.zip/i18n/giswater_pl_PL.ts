<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl_pl">
<!-- TOOLBARS AND ACTIONS -->
	<context>
		<name>giswater</name>
		<message>
			<source>18_text</source>
			<translation>Połączenie komercyjne</translation>
		</message>
		<message>
			<source>19_text</source>
			<translation>Narzędzia topograficzne</translation>
		</message>
		<message>
			<source>24_text</source>
			<translation>Go2EPA express</translation>
		</message>
		<message>
			<source>301_text</source>
			<translation>Planer roczny</translation>
		</message>
		<message>
			<source>302_text</source>
			<translation>Miesięczny planer</translation>
		</message>
		<message>
			<source>303_text</source>
			<translation>Generator cen</translation>
		</message>
		<message>
			<source>304_text</source>
			<translation>Dodaj wizytę</translation>
		</message>
		<message>
			<source>305_text</source>
			<translation>Planista jednostki</translation>
		</message>
		<message>
			<source>309_text</source>
			<translation>Menedżer incydentów</translation>
		</message>
		<message>
			<source>36_text</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>38_text</source>
			<translation>Nowy koszt sieci</translation>
		</message>
		<message>
			<source>47_text</source>
			<translation>Selektor sektora</translation>
		</message>
		<message>
			<source>74_text</source>
			<translation>Dodaj nową partię</translation>
		</message>
		<message>
			<source>75_text</source>
			<translation>Menedżer partii</translation>
		</message>
		<message>
			<source>76_text</source>
			<translation>Filtr partii</translation>
		</message>
		<message>
			<source>81_text</source>
			<translation>Nowy sektor</translation>
		</message>
		<message>
			<source>82_text</source>
			<translation>Menedżer sektora</translation>
		</message>
		<message>
			<source>98_text</source>
			<translation>Edytor konfiguracji</translation>
		</message>
		<message>
			<source>Actions</source>
			<translation>Działania</translation>
		</message>
		<message>
			<source>Add drain GPKG project</source>
			<translation>Dodaj projekt drenażu GPKG</translation>
		</message>
		<message>
			<source>Additional demand check</source>
			<translation>Dodatkowa kontrola popytu</translation>
		</message>
		<message>
			<source>Advanced</source>
			<translation>Zaawansowany</translation>
		</message>
		<message>
			<source>AmBreakage</source>
			<translation>Narzędzie administracyjne</translation>
		</message>
		<message>
			<source>AmPriority</source>
			<translation>Wybór i obliczanie priorytetów</translation>
		</message>
		<message>
			<source>Analytics</source>
			<translation>Analityka</translation>
		</message>
		<message>
			<source>ARC</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>Breakdown Assignation</source>
			<translation>Przypisanie podziału</translation>
		</message>
		<message>
			<source>Calibration</source>
			<translation>Kalibracja</translation>
		</message>
		<message>
			<source>Closest arcs</source>
			<translation>Najbliższe łuki</translation>
		</message>
		<message>
			<source>CONNEC</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>DRAG-DROP</source>
			<translation>Przeciągnij-i-upuść</translation>
		</message>
		<message>
			<source>Dscenario</source>
			<translation>Scenariusz</translation>
		</message>
		<message>
			<source>DWF scenario</source>
			<translation>Scenariusz DWF</translation>
		</message>
		<message>
			<source>Emitter calibration</source>
			<translation>Emitter calibration</translation>
		</message>
		<message>
			<source>EPA multi calls</source>
			<translation>Połączenia wielokrotne EPA</translation>
		</message>
		<message>
			<source>Export</source>
			<translation>Eksport</translation>
		</message>
		<message>
			<source>Fast print</source>
			<translation>Szybkie drukowanie</translation>
		</message>
		<message>
			<source>Forced arcs</source>
			<translation>Wymuszone łuki</translation>
		</message>
		<message>
			<source>Forced arcs (selecting only arcs)</source>
			<translation>Wymuszone łuki (wybieranie tylko łuków)</translation>
		</message>
		<message>
			<source>Get help</source>
			<translation>Uzyskaj pomoc</translation>
		</message>
		<message>
			<source>Go2IBER</source>
			<translation>Go2IBER</translation>
		</message>
		<message>
			<source>GULLY</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>GwAddCampaignButton</source>
			<translation>Dodaj kampanię</translation>
		</message>
		<message>
			<source>GwAddChildLayerButton</source>
			<translation>Załaduj warstwę Giswater</translation>
		</message>
		<message>
			<source>GwAddLotButton</source>
			<translation>Dodaj działkę</translation>
		</message>
		<message>
			<source>GwAmBreakageButton</source>
			<translation>Narzędzie administracyjne</translation>
		</message>
		<message>
			<source>GwAmPriorityButton</source>
			<translation>Wybór i obliczanie priorytetów</translation>
		</message>
		<message>
			<source>GwArcAddButton</source>
			<translation>Wkładka łukowa</translation>
		</message>
		<message>
			<source>GwArcDivideButton</source>
			<translation>Podział łuku</translation>
		</message>
		<message>
			<source>GwArcFusionButton</source>
			<translation>Fuzja łukowa</translation>
		</message>
		<message>
			<source>GwAuxCircleAddButton</source>
			<translation>Utwórz okrąg</translation>
		</message>
		<message>
			<source>GwAuxPointAddButton</source>
			<translation>Utwórz punkt</translation>
		</message>
		<message>
			<source>GwConfigButton</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>GwConnectLinkButton</source>
			<translation>Połączenie z siecią</translation>
		</message>
		<message>
			<source>GwCSVButton</source>
			<translation>Import CSV</translation>
		</message>
		<message>
			<source>GwDateSelectorButton</source>
			<translation>Selektor daty</translation>
		</message>
		<message>
			<source>GwDimensioningButton</source>
			<translation>Wymiarowanie</translation>
		</message>
		<message>
			<source>GwDocumentButton</source>
			<translation>Dodaj dokument</translation>
		</message>
		<message>
			<source>GwDocumentManagerButton</source>
			<translation>Menedżer dokumentów</translation>
		</message>
		<message>
			<source>GwDscenarioManagerButton</source>
			<translation>Menedżer scenariusza</translation>
		</message>
		<message>
			<source>GwElementButton</source>
			<translation>Dodaj element</translation>
		</message>
		<message>
			<source>GwElementManagerButton</source>
			<translation>Menedżer elementów</translation>
		</message>
		<message>
			<source>GwEpaTools</source>
			<translation>Narzędzia EPA</translation>
		</message>
		<message>
			<source>GwFeatureDeleteButton</source>
			<translation>Usuń funkcję</translation>
		</message>
		<message>
			<source>GwFeatureEndButton</source>
			<translation>Funkcja końcowa</translation>
		</message>
		<message>
			<source>GwFeatureReplaceButton</source>
			<translation>Zastąp funkcję</translation>
		</message>
		<message>
			<source>GwFeatureTypeChangeButton</source>
			<translation>Zmień klasę funkcji</translation>
		</message>
		<message>
			<source>GwFlowExitButton</source>
			<translation>Wyjście przepływu</translation>
		</message>
		<message>
			<source>GwFlowTraceButton</source>
			<translation>Śledzenie przepływu</translation>
		</message>
		<message>
			<source>GwGo2EpaButton</source>
			<translation>Go2EPA</translation>
		</message>
		<message>
			<source>GwGo2EpaManagerButton</source>
			<translation>Menedżer wyników EPA</translation>
		</message>
		<message>
			<source>GwGo2EpaSelectorButton</source>
			<translation>EPA result selector</translation>
		</message>
		<message>
			<source>GwInfoButton</source>
			<translation>Info Giswater</translation>
		</message>
		<message>
			<source>GwLayerStyleChangeButton</source>
			<translation>Style Giswater</translation>
		</message>
		<message>
			<source>GwLotResourceManagementButton</source>
			<translation>Zarządzanie zasobami partii</translation>
		</message>
		<message>
			<source>GwManageCampaignLotButton</source>
			<translation>Zarządzanie partią kampanii</translation>
		</message>
		<message>
			<source>GwMincutButton</source>
			<translation>Nowy mincut</translation>
		</message>
		<message>
			<source>GwMincutManagerButton</source>
			<translation>Zarządzanie Mincut</translation>
		</message>
		<message>
			<source>GwNetscenarioManagerButton</source>
			<translation>Menedżer scenariusza sieciowego</translation>
		</message>
		<message>
			<source>GwNonVisualManagerButton</source>
			<translation>Menedżer obiektów niewizualnych</translation>
		</message>
		<message>
			<source>GwPointAddButton</source>
			<translation>Wstaw punkt</translation>
		</message>
		<message>
			<source>GwPriceManagerButton</source>
			<translation>Menedżer kosztów sieci</translation>
		</message>
		<message>
			<source>GwPrintButton</source>
			<translation>Drukuj</translation>
		</message>
		<message>
			<source>GwProfileButton</source>
			<translation>Profile tool</translation>
		</message>
		<message>
			<source>GwProjectCheckButton</source>
			<translation>Sprawdź projekt</translation>
		</message>
		<message>
			<source>GwPsectorButton</source>
			<translation>Nowy sektor</translation>
		</message>
		<message>
			<source>GwPsectorManagerButton</source>
			<translation>Menedżer sektora</translation>
		</message>
		<message>
			<source>GwResultManagerButton</source>
			<translation>Result manager</translation>
		</message>
		<message>
			<source>GwResultSelectorButton</source>
			<translation>Selektor wyników</translation>
		</message>
		<message>
			<source>GwSearchButton</source>
			<translation>Wyszukiwanie plus</translation>
		</message>
		<message>
			<source>GwSelectorButton</source>
			<translation>Selektory</translation>
		</message>
		<message>
			<source>GwSnapshotViewButton</source>
			<translation>Widok migawki</translation>
		</message>
		<message>
			<source>GwToolBoxButton</source>
			<translation>Zestaw narzędzi</translation>
		</message>
		<message>
			<source>GwUtilsManagerButton</source>
			<translation>Menedżer narzędzi</translation>
		</message>
		<message>
			<source>GwVisitButton</source>
			<translation>Dodaj wizytę</translation>
		</message>
		<message>
			<source>GwVisitManagerButton</source>
			<translation>Odwiedź menedżera</translation>
		</message>
		<message>
			<source>GwWorkspaceManagerButton</source>
			<translation>Menedżer przestrzeni roboczej</translation>
		</message>
		<message>
			<source>Hydrology scenario</source>
			<translation>Scenariusz hydrologiczny</translation>
		</message>
		<message>
			<source>Import</source>
			<translation>Import</translation>
		</message>
		<message>
			<source>Import CSV</source>
			<translation>Import CSV</translation>
		</message>
		<message>
			<source>Import INP file</source>
			<translation>Import pliku INP</translation>
		</message>
		<message>
			<source>Manage Campaign</source>
			<translation>Zarządzaj kampanią</translation>
		</message>
		<message>
			<source>Manage Campaign</source>
			<translation>Zarządzaj kampanią</translation>
		</message>
		<message>
			<source>Manage Lot</source>
			<translation>Zarządzanie partiami</translation>
		</message>
		<message>
			<source>Manage Lot</source>
			<translation>Zarządzanie partiami</translation>
		</message>
		<message>
			<source>Manage Workorder</source>
			<translation>Zarządzaj zleceniem pracy</translation>
		</message>
		<message>
			<source>Mapzones manager</source>
			<translation>Menedżer Mapzones</translation>
		</message>
		<message>
			<source>Massive composer</source>
			<translation>Kompozytor Massive</translation>
		</message>
		<message>
			<source>menu_name</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>Multi psector print</source>
			<translation>Druk wielobranżowy</translation>
		</message>
		<message>
			<source>NODE</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>Open plugin folder</source>
			<translation>Otwórz folder wtyczek</translation>
		</message>
		<message>
			<source>Open user folder</source>
			<translation>Otwórz folder użytkownika</translation>
		</message>
		<message>
			<source>Priority Calculation (Global)</source>
			<translation>Obliczanie priorytetu (globalne)</translation>
		</message>
		<message>
			<source>Quantized demands</source>
			<translation>Skwantyzowane wymagania</translation>
		</message>
		<message>
			<source>Reset dialogs</source>
			<translation>Resetowanie okien dialogowych</translation>
		</message>
		<message>
			<source>Reset plugin</source>
			<translation>Reset wtyczki</translation>
		</message>
		<message>
			<source>ResultManager</source>
			<translation>Menedżer wyników</translation>
		</message>
		<message>
			<source>ResultSelector</source>
			<translation>Selektor wyników</translation>
		</message>
		<message>
			<source>Review</source>
			<translation>Recenzja</translation>
		</message>
		<message>
			<source>SELECT</source>
			<translation>Wybierz</translation>
		</message>
		<message>
			<source>Show current selectors</source>
			<translation>Pokaż bieżące selektory</translation>
		</message>
		<message>
			<source>Static calibration</source>
			<translation>Kalibracja statyczna</translation>
		</message>
		<message>
			<source>Style manager</source>
			<translation>Menedżer stylu</translation>
		</message>
		<message>
			<source>Toggle Log DB</source>
			<translation>Toggle Log DB</translation>
		</message>
		<message>
			<source>toolbar_am_name</source>
			<translation>Giswater - Asset Manager</translation>
		</message>
		<message>
			<source>toolbar_basic_name</source>
			<translation>Giswater - Podstawowy</translation>
		</message>
		<message>
			<source>toolbar_cm_name</source>
			<translation>Giswater - Menedżer kampanii</translation>
		</message>
		<message>
			<source>toolbar_custom_name</source>
			<translation>Giswater - Custom</translation>
		</message>
		<message>
			<source>toolbar_edit_name</source>
			<translation>Giswater - Edytuj</translation>
		</message>
		<message>
			<source>toolbar_epa_name</source>
			<translation>Giswater - Epa</translation>
		</message>
		<message>
			<source>toolbar_om_name</source>
			<translation>Giswater - O&amp;M</translation>
		</message>
		<message>
			<source>toolbar_plan_name</source>
			<translation>Giswater - Plan główny</translation>
		</message>
		<message>
			<source>toolbar_utilities_name</source>
			<translation>Giswater - Narzędzia</translation>
		</message>
		<message>
			<source>Valve operation check</source>
			<translation>Kontrola działania zaworu</translation>
		</message>
		<message>
			<source>Visit</source>
			<translation>Odwiedź</translation>
		</message>
		<message>
			<source>Workcat manager</source>
			<translation>Menedżer Workcat</translation>
		</message>
	</context>
<!-- PYTHON MESSAGES -->
	<context>
		<name>giswater</name>
		<message>
			<source></source>
			<translation></translation>
		</message>
		<message>
			<source> </source>
			<translation> </translation>
		</message>
		<message>
			<source>}</source>
			<translation>}</translation>
		</message>
		<message>
			<source>{0}</source>
			<translation>{0}</translation>
		</message>
		<message>
			<source>{0} --&gt; {1}</source>
			<translation>{0} --&gt; {1}</translation>
		</message>
		<message>
			<source>{0}: {1}</source>
			<translation>{0}: {1}</translation>
		</message>
		<message>
			<source>{0} --&gt; {1} --&gt; {2}</source>
			<translation>{0} --&gt; {1} --&gt; {2}</translation>
		</message>
		<message>
			<source>{0} ({1}) - {2} - Updating {3}...</source>
			<translation>{0} ({1}) - {2} - Aktualizacja {3}...</translation>
		</message>
		<message>
			<source>{0}: {1} Python function: tools_gw.set_widgets. WHERE columname=&apos;{2}&apos; AND widgetname=&apos;{3}&apos; AND widgettype=&apos;{4}&apos;</source>
			<translation>{0}: {1} Funkcja Python: tools_gw.set_widgets. WHERE columname=&apos;{2}&apos; AND widgetname=&apos;{3}&apos; AND widgettype=&apos;{4}&apos;</translation>
		</message>
		<message>
			<source>{0} ({1}) - python - Updating python files...</source>
			<translation>{0} ({1}) - python - Aktualizacja plików python...</translation>
		</message>
		<message>
			<source>{0}: {1}. widgetname=&apos;{2}&apos; AND widgettype=&apos;{3}&apos;</source>
			<translation>{0}: {1}. widgetname=&apos;{2}&apos; AND widgettype=&apos;{3}&apos;</translation>
		</message>
		<message>
			<source>{0} campaign(s) deleted.</source>
			<translation>{0} campaign(s) deleted.</translation>
		</message>
		<message>
			<source>{0} campaign(s) deleted.</source>
			<translation>Usunięto {0} kampanii.</translation>
		</message>
		<message>
			<source>{0}: Config file is not set</source>
			<translation>{0}: Plik konfiguracyjny nie jest ustawiony</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; does not exist. Please select a valid config file.</source>
			<translation>&quot;{0}&quot; nie istnieje. Wybierz prawidłowy plik konfiguracyjny.</translation>
		</message>
		<message>
			<source>&quot;{0}&quot; does not exist. Please select a valid folder.</source>
			<translation>&quot;{0}&quot; nie istnieje. Wybierz prawidłowy folder.</translation>
		</message>
		<message>
			<source>{0} error {1}</source>
			<translation>{0} błąd {1}</translation>
		</message>
		<message>
			<source>{0} error: {1}</source>
			<translation>{0} błąd: {1}</translation>
		</message>
		<message>
			<source>{0} exception: {1}</source>
			<translation>{0} wyjątek: {1}</translation>
		</message>
		<message>
			<source>{0} Exception: {1}</source>
			<translation>{0} Wyjątek: {1}</translation>
		</message>
		<message>
			<source>{0} exception [{1}]: {2}</source>
			<translation>{0} wyjątek [{1}]: {2}</translation>
		</message>
		<message>
			<source>{0} folder not found</source>
			<translation>{0} folder nie został znaleziony</translation>
		</message>
		<message>
			<source>{0} folder not found, executing en_US folder</source>
			<translation>{0} folder not found, executing en_US folder</translation>
		</message>
		<message>
			<source>{0} id:</source>
			<translation>{0} id:</translation>
		</message>
		<message>
			<source>{0} is not a table name or {1}</source>
			<translation>{0} nie jest nazwą tabeli lub {1}</translation>
		</message>
		<message>
			<source>{0} is not defined in table cat_feature</source>
			<translation>{0} nie jest zdefiniowane w tabeli cat_feature</translation>
		</message>
		<message>
			<source>{0} lot(s) deleted.</source>
			<translation>Usunięto {0} partii.</translation>
		</message>
		<message>
			<source>{0} lot(s) deleted.</source>
			<translation>{0} lot(s) deleted.</translation>
		</message>
		<message>
			<source>{0}: project type &apos;{1}&apos; not supported</source>
			<translation>{0}: typ projektu &quot;{1}&quot; nie jest obsługiwany</translation>
		</message>
		<message>
			<source>{0}: Reference {1} = &apos;{2}&apos; it is not managed</source>
			<translation>{0}: Odniesienie {1} = &apos;{2}&apos; nie jest zarządzane</translation>
		</message>
		<message>
			<source>{0} successfully saved.</source>
			<translation>{0} został pomyślnie zapisany.</translation>
		</message>
		<message>
			<source>{0} task is already active!</source>
			<translation>{0} zadanie jest już aktywne!</translation>
		</message>
		<message>
			<source>{0}: widget not found</source>
			<translation>{0}: nie znaleziono widżetu</translation>
		</message>
		<message>
			<source>{0} workorder(s) deleted.</source>
			<translation>Usunięto {0} zleceń roboczych.</translation>
		</message>
		<message>
			<source>{0} workorder(s) deleted.</source>
			<translation>{0} workorder(s) deleted.</translation>
		</message>
		<message>
			<source>{1}</source>
			<translation>{1}</translation>
		</message>
		<message>
			<source>{2}</source>
			<translation>{2}</translation>
		</message>
		<message>
			<source>Action has no function!!</source>
			<translation>Akcja nie ma żadnej funkcji!!!</translation>
		</message>
		<message>
			<source>Activate water netowrk snapshot</source>
			<translation>Aktywacja migawki sieci wodnej</translation>
		</message>
		<message>
			<source>Add document</source>
			<translation>Dodaj dokument</translation>
		</message>
		<message>
			<source>Added elevation data from raster to all nodes</source>
			<translation>Dodano dane wysokości z rastra do wszystkich węzłów</translation>
		</message>
		<message>
			<source>Added grade attributes to all edges</source>
			<translation>Dodano atrybuty stopni do wszystkich krawędzi</translation>
		</message>
		<message>
			<source>Added length attributes to graph edges</source>
			<translation>Dodano atrybuty długości do krawędzi wykresu</translation>
		</message>
		<message>
			<source>Add layers to schema</source>
			<translation>Dodawanie warstw do schematu</translation>
		</message>
		<message>
			<source>ADDRESS</source>
			<translation>ADRES</translation>
		</message>
		<message>
			<source>Add translator</source>
			<translation>Dodaj tłumacza</translation>
		</message>
		<message>
			<source>Add translator ({0})</source>
			<translation>Dodaj tłumacza ({0})</translation>
		</message>
		<message>
			<source>A diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.</source>
			<translation>Wartość średnicy jest uznawana za nieprawidłową, jeśli jest równa zero, ujemna, NULL lub większa niż maksymalna średnica w tabeli konfiguracji. W rezultacie tym rurom NIE zostanie przypisana wartość priorytetu.</translation>
		</message>
		<message>
			<source>Administrative tools</source>
			<translation>Narzędzia administracyjne</translation>
		</message>
		<message>
			<source>Adress configuration. Field not found</source>
			<translation>Konfiguracja adresu. Nie znaleziono pola</translation>
		</message>
		<message>
			<source>Advanced Menu</source>
			<translation>Menu zaawansowane</translation>
		</message>
		<message>
			<source>Alert</source>
			<translation>Alarm</translation>
		</message>
		<message>
			<source>All dialogs updated correctly</source>
			<translation>Wszystkie okna dialogowe zostały poprawnie zaktualizowane</translation>
		</message>
		<message>
			<source>All edges must have &apos;length&apos; and &apos;speed_kph&apos; attributes.</source>
			<translation>Wszystkie krawędzie muszą mieć atrybuty &quot;length&quot; i &quot;speed_kph&quot;.</translation>
		</message>
		<message>
			<source>All layers have been successfully refreshed.</source>
			<translation>Wszystkie warstwy zostały pomyślnie odświeżone.</translation>
		</message>
		<message>
			<source>All messages updated correctly</source>
			<translation>Wszystkie wiadomości zostały poprawnie zaktualizowane</translation>
		</message>
		<message>
			<source>All the values in the column &apos;atlas_id&apos; from the table &apos;plan_psector&apos; have to be INTEGER. This is not the case for your table, please fix this before continuing.</source>
			<translation>Wszystkie wartości w kolumnie &quot;atlas_id&quot; z tabeli &quot;plan_psector&quot; muszą być typu INTEGER. Nie jest tak w przypadku Twojej tabeli, napraw to przed kontynuowaniem.</translation>
		</message>
		<message>
			<source>A material is considered invalid if it is not listed in the material configuration table.</source>
			<translation>Materiał jest uznawany za nieważny, jeśli nie jest wymieniony w tabeli konfiguracji materiałów.</translation>
		</message>
		<message>
			<source>ANALYTICS</source>
			<translation>ANALITYKA</translation>
		</message>
		<message>
			<source>An arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.</source>
			<translation>Identyfikator arccat_id jest uznawany za nieprawidłowy, jeśli nie znajduje się na liście w tabeli konfiguracji katalogu. W związku z tym do tych potoków NIE zostanie przypisana wartość priorytetu.</translation>
		</message>
		<message>
			<source>An error occurred saving the workorder.</source>
			<translation>Wystąpił błąd podczas zapisywania zlecenia.</translation>
		</message>
		<message>
			<source>An error occurred while adding the style for layer &apos;{0}&apos;:</source>
			<translation>Wystąpił błąd podczas dodawania stylu dla warstwy &quot;{0}&quot;:</translation>
		</message>
		<message>
			<source>An error occurred while adding the style for layer &apos;{0}&apos;:\n{1}</source>
			<translation>Wystąpił błąd podczas dodawania stylu dla warstwy &apos;{0}&apos;:\n{1}.</translation>
		</message>
		<message>
			<source>A new style has been added to &apos;{0}&apos; for the layer &apos;{1}&apos; using the &apos;GwBasic&apos; style information.</source>
			<translation>Nowy styl został dodany do &quot;{0}&quot; dla warstwy &quot;{1}&quot; przy użyciu informacji o stylu &quot;GwBasic&quot;.</translation>
		</message>
		<message>
			<source>A new style has been added to &apos;{0}&apos; for the layer &apos;{1}&apos; using the &apos;GwBasic&apos; style information.\nYou can change it and use &apos;Update Style&apos; to create a personalized version.</source>
			<translation>Nowy styl został dodany do warstwy &quot;{0}&quot; dla warstwy &quot;{1}&quot; przy użyciu informacji o stylu &quot;GwBasic&quot;. Możesz go zmienić i użyć opcji &quot;Aktualizuj styl&quot;, aby utworzyć spersonalizowaną wersję.</translation>
		</message>
		<message>
			<source>Any connec_id found with this customer_code</source>
			<translation>Każdy identyfikator connec_id znaleziony z tym kodem customer_code</translation>
		</message>
		<message>
			<source>Any document selected</source>
			<translation>Dowolny wybrany dokument</translation>
		</message>
		<message>
			<source>Any of the snapped features belong to selected layer</source>
			<translation>Dowolny z przyciągniętych elementów należy do wybranej warstwy</translation>
		</message>
		<message>
			<source>Any record found</source>
			<translation>Każdy znaleziony rekord</translation>
		</message>
		<message>
			<source>Any record found for current user in table</source>
			<translation>Znaleziono dowolny rekord dla bieżącego użytkownika w tabeli</translation>
		</message>
		<message>
			<source>Any record found in table &apos;cat_node&apos; related with selected &apos;node_type.type&apos;</source>
			<translation>Dowolny rekord znaleziony w tabeli &apos;cat_node&apos; powiązany z wybranym &apos;node_type.type&apos;</translation>
		</message>
		<message>
			<source>Any record found in table &apos;node_type&apos; related with selected &apos;node_type.type&apos;</source>
			<translation>Dowolny rekord znaleziony w tabeli &apos;node_type&apos; powiązany z wybranym &apos;node_type.type&apos;</translation>
		</message>
		<message>
			<source>Any record selected</source>
			<translation>Dowolny wybrany rekord</translation>
		</message>
		<message>
			<source>Any table has been selected</source>
			<translation>Wybrano dowolną tabelę</translation>
		</message>
		<message>
			<source>Applied styles for context</source>
			<translation>Zastosowane style dla kontekstu</translation>
		</message>
		<message>
			<source>Arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>ARC</source>
			<translation>ARC</translation>
		</message>
		<message>
			<source>Arc fusion</source>
			<translation>Fuzja łukowa</translation>
		</message>
		<message>
			<source>Are you sure to execute vacuum on selected schema?</source>
			<translation>Czy na pewno chcesz wykonać próżnię na wybranym schemacie?</translation>
		</message>
		<message>
			<source>Are you sure to save this feature?</source>
			<translation>Czy na pewno chcesz zapisać tę funkcję?</translation>
		</message>
		<message>
			<source>Are you sure to update the project schema to last version?</source>
			<translation>Czy na pewno zaktualizowałeś schemat projektu do ostatniej wersji?</translation>
		</message>
		<message>
			<source>Are you sure you want delete schema &apos;{0}&apos;?</source>
			<translation>Czy na pewno chcesz usunąć schemat &apos;{0}&apos;?</translation>
		</message>
		<message>
			<source>Are you sure you want to assign team &apos;{0}&apos; to {1} selected user(s)?</source>
			<translation>Are you sure you want to assign team &apos;{0}&apos; to {1} selected user(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to cancel these mincuts?</source>
			<translation>Czy na pewno chcesz zrezygnować z tych przycięć?</translation>
		</message>
		<message>
			<source>Are you sure you want to continue?</source>
			<translation>Czy na pewno chcesz kontynuować?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} campaign(s)?</source>
			<translation>Are you sure you want to delete {0} campaign(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} campaign(s)?</source>
			<translation>Czy na pewno chcesz usunąć {0} kampanii?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} lot(s)?</source>
			<translation>Are you sure you want to delete {0} lot(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} lot(s)?</source>
			<translation>Czy na pewno chcesz usunąć {0} partii?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} workorder(s)?</source>
			<translation>Are you sure you want to delete {0} workorder(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete {0} workorder(s)?</source>
			<translation>Czy na pewno chcesz usunąć {0} zleceń?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the selected styles?</source>
			<translation>Czy na pewno chcesz usunąć wybrane style?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these mincuts?</source>
			<translation>Czy na pewno chcesz usunąć te skróty?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these profile?</source>
			<translation>Czy na pewno chcesz usunąć ten profil?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records:</source>
			<translation>Are you sure you want to delete these records:</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records:</source>
			<translation>Czy na pewno chcesz usunąć te rekordy?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records?</source>
			<translation>Czy na pewno chcesz usunąć te rekordy?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete these records?\nSome events have documents</source>
			<translation>Czy na pewno chcesz usunąć te rekordy? Niektóre zdarzenia mają dokumenty</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the style group &apos;{0}&apos;?</source>
			<translation>Czy na pewno chcesz usunąć grupę stylów &quot;{0}&quot;?</translation>
		</message>
		<message>
			<source>Are you sure you want to delete the style group &apos;{0}&apos;?\n\nThis will also delete all related entries in the sys_style table.Confirm Cascade Delete</source>
			<translation>Czy na pewno chcesz usunąć grupę stylów &quot;{0}&quot;? Spowoduje to również usunięcie wszystkich powiązanych wpisów w tabeli sys_style.</translation>
		</message>
		<message>
			<source>Are you sure you want to disconnect this elements?</source>
			<translation>Czy na pewno chcesz odłączyć te elementy?</translation>
		</message>
		<message>
			<source>Are you sure you want to override the configuration of this workspace?</source>
			<translation>Czy na pewno chcesz zmienić konfigurację tego obszaru roboczego?</translation>
		</message>
		<message>
			<source>Are you sure you want to overwrite this file?</source>
			<translation>Czy na pewno chcesz nadpisać ten plik?</translation>
		</message>
		<message>
			<source>Are you sure you want to overwrite this folder?</source>
			<translation>Are you sure you want to overwrite this folder?</translation>
		</message>
		<message>
			<source>ARE YOU SURE YOU WANT TO PROCEED?</source>
			<translation>CZY NA PEWNO CHCESZ KONTYNUOWAĆ?</translation>
		</message>
		<message>
			<source>Are you sure you want to remove team assignment from {0} selected user(s)?</source>
			<translation>Are you sure you want to remove team assignment from {0} selected user(s)?</translation>
		</message>
		<message>
			<source>Are you sure you want to replace selected feature with a new one?</source>
			<translation>Czy na pewno chcesz zastąpić wybraną funkcję nową?</translation>
		</message>
		<message>
			<source>Are you sure you want to replace selected feature with a new one?\n If you have different addfields in your feature, they will be deleted.</source>
			<translation>Czy na pewno chcesz zastąpić wybraną funkcję nową? Jeśli w funkcji znajdują się różne pola dodatkowe, zostaną one usunięte.</translation>
		</message>
		<message>
			<source>Are you sure you want to update the data?</source>
			<translation>Czy na pewno chcesz zaktualizować dane?</translation>
		</message>
		<message>
			<source>Are you sure you want to update the style of {0} ({1}) with the symbology of the layer in the project? </source>
			<translation>Czy na pewno chcesz zaktualizować styl {0} ({1}) z symboliką warstwy w projekcie?</translation>
		</message>
		<message>
			<source>Are you sure you want to update the style of {0} ({1}) with the symbology of the layer in the project? \nYou are going to lose previous information!</source>
			<translation>Czy na pewno chcesz zaktualizować styl {0} ({1}) z symboliką warstwy w projekcie? \Utracisz poprzednie informacje!</translation>
		</message>
		<message>
			<source>A rollback on schema will be done.</source>
			<translation>Zostanie wykonane wycofanie schematu.</translation>
		</message>
		<message>
			<source>As a result, the material of these pipes will be treated as the configured unknown material, {0}.</source>
			<translation>As a result, the material of these pipes will be treated as the configured unknown material, {0}.</translation>
		</message>
		<message>
			<source>As a result, the material of these pipes will be treated as the configured unknown material, {unknown_material}.</source>
			<translation>W rezultacie materiał tych rur będzie traktowany jako skonfigurowany nieznany materiał {unknown_material}.</translation>
		</message>
		<message>
			<source>Assigning leaks to pipes</source>
			<translation>Przypisywanie wycieków do rur</translation>
		</message>
		<message>
			<source>Assign Team</source>
			<translation>Assign Team</translation>
		</message>
		<message>
			<source>A style already exists for the layer &apos;{0}&apos; in the selected style group.</source>
			<translation>Istnieje już styl dla warstwy &quot;{0}&quot; w wybranej grupie stylów.</translation>
		</message>
		<message>
			<source>Atlas ID must be an integer.</source>
			<translation>Atlas ID must be an integer.</translation>
		</message>
		<message>
			<source>    author = {Boeing, Geoff},</source>
			<translation>    author = {Boeing, Geoff},</translation>
		</message>
		<message>
			<source>AUXILIAR</source>
			<translation>ASYSTENT</translation>
		</message>
		<message>
			<source>BASEMAP</source>
			<translation>BASEMAP</translation>
		</message>
		<message>
			<source>Begin plotting the graph...</source>
			<translation>Rozpocznij kreślenie wykresu...</translation>
		</message>
		<message>
			<source>Begin topologically simplifying the graph...</source>
			<translation>Rozpocznij topologiczne upraszczanie grafu...</translation>
		</message>
		<message>
			<source>Boeing, G. (2024). Modeling and Analyzing Urban Networks and Amenities with OSMnx. Working paper. https://geoffboeing.com/publications/osmnx-paper/</source>
			<translation>Boeing, G. (2024). Modelowanie i analiza sieci miejskich i udogodnień za pomocą OSMnx. Dokument roboczy. https://geoffboeing.com/publications/osmnx-paper/</translation>
		</message>
		<message>
			<source>Boundaries must be a Polygon or MultiPolygon. If you requested `features_from_place`, ensure your query geocodes to a Polygon or MultiPolygon. See the documentation for details.</source>
			<translation>Granice muszą być wielokątem lub wielokątem. Jeśli zażądałeś `features_from_place`, upewnij się, że zapytanie geokoduje do Polygon lub MultiPolygon. Szczegółowe informacje można znaleźć w dokumentacji.</translation>
		</message>
		<message>
			<source>Calculate Priority</source>
			<translation>Oblicz priorytet</translation>
		</message>
		<message>
			<source>Calculating values</source>
			<translation>Obliczanie wartości</translation>
		</message>
		<message>
			<source>Campaign ID is missing.</source>
			<translation>Brak identyfikatora kampanii.</translation>
		</message>
		<message>
			<source>Campaign ID not found.</source>
			<translation>Nie znaleziono identyfikatora kampanii.</translation>
		</message>
		<message>
			<source>Campaign saved successfully.</source>
			<translation>Kampania została pomyślnie zapisana.</translation>
		</message>
		<message>
			<source>Campaign saved successfully.</source>
			<translation>Campaign saved successfully.</translation>
		</message>
		<message>
			<source>Canceling task...</source>
			<translation>Anulowanie zadania...</translation>
		</message>
		<message>
			<source>Cancel mincut</source>
			<translation>Cancel mincut</translation>
		</message>
		<message>
			<source>Cancel mincuts</source>
			<translation>Anuluj mincięcia</translation>
		</message>
		<message>
			<source>Cannot create file</source>
			<translation>Nie można utworzyć pliku, sprawdź, czy jest otwarty</translation>
		</message>
		<message>
			<source>Cannot create file, check if its open</source>
			<translation>Nie można utworzyć pliku, sprawdź, czy jest otwarty</translation>
		</message>
		<message>
			<source>Cannot create file, check if selected composer is the correct composer</source>
			<translation>Nie można utworzyć pliku, sprawdź, czy wybrany kompozytor jest prawidłowym kompozytorem</translation>
		</message>
		<message>
			<source>Cannot create file, check if selected giswater_advancedtools is the correct giswater_advancedtools</source>
			<translation>Nie można utworzyć pliku, sprawdź, czy wybrane giswater_advancedtools to poprawne giswater_advancedtools</translation>
		</message>
		<message>
			<source>Cannot get current Java version from windows registry</source>
			<translation>Nie można pobrać bieżącej wersji Java z rejestru Windows</translation>
		</message>
		<message>
			<source>Cannot get giswater build version from windows registry</source>
			<translation>Nie można pobrać wersji kompilacji giswater z rejestru Windows</translation>
		</message>
		<message>
			<source>Cannot get giswater folder from windows registry</source>
			<translation>Nie można pobrać folderu giswater z rejestru systemu Windows</translation>
		</message>
		<message>
			<source>Cannot get giswater major version from windows registry</source>
			<translation>Nie można pobrać głównej wersji giswater z rejestru systemu Windows</translation>
		</message>
		<message>
			<source>Cannot get giswater minor version from windows registry</source>
			<translation>Nie można pobrać podrzędnej wersji giswater z rejestru systemu Windows</translation>
		</message>
		<message>
			<source>Cannot get Java folder from windows registry</source>
			<translation>Nie można pobrać folderu Java z rejestru systemu Windows</translation>
		</message>
		<message>
			<source>Cannot set inactive a current scenario. Please update current first.</source>
			<translation>Cannot set inactive a current scenario. Please update current first.</translation>
		</message>
		<message>
			<source>Cannot set the current {0} scenario of an inactive scenario. Please activate it first.</source>
			<translation>Nie można ustawić bieżącego {0} scenariusza nieaktywnego scenariusza. Należy go najpierw aktywować.</translation>
		</message>
		<message>
			<source>Cannot set the current netscenario of an inactive scenario. Please activate it first.</source>
			<translation>Nie można ustawić bieżącego scenariusza sieciowego nieaktywnego scenariusza. Należy go najpierw aktywować.</translation>
		</message>
		<message>
			<source>Cannot set the current psector of an inactive scenario. Please activate it first.</source>
			<translation>Nie można ustawić bieżącego sektora nieaktywnego scenariusza. Należy go najpierw aktywować.</translation>
		</message>
		<message>
			<source>Can&apos;t create curve with only one value if flow is 0. Add more values or change the flow value.</source>
			<translation>Nie można utworzyć krzywej z tylko jedną wartością, jeśli przepływ wynosi 0. Dodaj więcej wartości lub zmień wartość przepływu.</translation>
		</message>
		<message>
			<source>CATALOGS</source>
			<translation>KATALOGI</translation>
		</message>
		<message>
			<source>Category name already exists</source>
			<translation>Nazwa kategorii już istnieje</translation>
		</message>
		<message>
			<source>Category name cannot be empty.</source>
			<translation>Nazwa kategorii nie może być pusta.</translation>
		</message>
		<message>
			<source>Category updated successfully!</source>
			<translation>Kategoria została pomyślnie zaktualizowana!</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a dscenario will delete data from features related to the dscenario.</source>
			<translation>UWAGA! Usunięcie scenariusza ds spowoduje usunięcie danych z funkcji powiązanych ze scenariuszem ds.</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a dscenario will delete data from features related to the dscenario.\nAre you sure you want to delete these records?</source>
			<translation>UWAGA! Usunięcie scenariusza ds spowoduje usunięcie danych z funkcji powiązanych ze scenariuszem ds. Czy na pewno chcesz usunąć te rekordy?</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a netscenario will delete data from features related to the netscenario.</source>
			<translation>UWAGA! Usunięcie scenariusza sieciowego spowoduje usunięcie danych z funkcji powiązanych ze scenariuszem sieciowym.</translation>
		</message>
		<message>
			<source>CAUTION! Deleting a netscenario will delete data from features related to the netscenario.\nAre you sure you want to delete these records?</source>
			<translation>UWAGA! Usunięcie scenariusza sieciowego spowoduje usunięcie danych z funkcji powiązanych ze scenariuszem sieciowym.\nCzy na pewno chcesz usunąć te rekordy?</translation>
		</message>
		<message>
			<source>Change epa_type</source>
			<translation>Zmień epa_type</translation>
		</message>
		<message>
			<source>Changes applied to &quot;{0}&quot; successfully.</source>
			<translation>Pomyślnie zastosowano zmiany do &quot;{0}&quot;.</translation>
		</message>
		<message>
			<source>Changes on this page are dangerous and can break Giswater plugin in various ways. </source>
			<translation>Zmiany na tej stronie są niebezpieczne i mogą uszkodzić wtyczkę Giswater na różne sposoby.</translation>
		</message>
		<message>
			<source>Changes on this page are dangerous and can break Giswater plugin in various ways. \nYou will need to restart QGIS or reload Giswater plugin to apply changes. Do you want continue?</source>
			<translation>Zmiany na tej stronie są niebezpieczne i mogą uszkodzić wtyczkę Giswater na różne sposoby. \Aby zastosować zmiany, konieczne będzie ponowne uruchomienie QGIS. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>Check fields from table or view</source>
			<translation>Sprawdzanie pól z tabeli lub widoku</translation>
		</message>
		<message>
			<source>Checking any item will not uncheck any other item.</source>
			<translation>Zaznaczenie dowolnego elementu nie spowoduje odznaczenia żadnego innego elementu.</translation>
		</message>
		<message>
			<source>Checking any item will uncheck all other items.</source>
			<translation>Zaznaczenie dowolnego elementu spowoduje odznaczenie wszystkich innych elementów.</translation>
		</message>
		<message>
			<source>Checking any item will uncheck all other items unless Shift is pressed.</source>
			<translation>Zaznaczenie dowolnego elementu spowoduje odznaczenie wszystkich innych elementów, chyba że zostanie naciśnięty klawisz Shift.</translation>
		</message>
		<message>
			<source>Choose dscenario</source>
			<translation>Wybierz scenariusz</translation>
		</message>
		<message>
			<source>Clicking an item will check/uncheck it. </source>
			<translation>Kliknięcie elementu spowoduje jego zaznaczenie/odznaczenie.</translation>
		</message>
		<message>
			<source>Click on 2 places on the map</source>
			<translation>Kliknij 2 miejsca na mapie, tworząc linię, a następnie ustaw lokalizację punktu</translation>
		</message>
		<message>
			<source>Click on 2 places on the map, creating a line, then set a location of a point</source>
			<translation>Kliknij 2 miejsca na mapie, tworząc linię, a następnie ustaw lokalizację punktu</translation>
		</message>
		<message>
			<source>Click on 2 places on the map, creating a line, then set the location of a point</source>
			<translation>Kliknij 2 miejsca na mapie, tworząc linię, a następnie ustaw lokalizację punktu</translation>
		</message>
		<message>
			<source>Click on a feature to set mincut location and start the process</source>
			<translation>Kliknij funkcję, aby ustawić lokalizację minimalnego cięcia i rozpocząć proces.</translation>
		</message>
		<message>
			<source>Click on arcs to select them. Use Alt+click to unselect selected arcs.</source>
			<translation>Kliknij łuki, aby je zaznaczyć. Użyj kombinacji klawiszy Alt+kliknięcie, aby odznaczyć wybrane łuki.</translation>
		</message>
		<message>
			<source>Click on disconnected node</source>
			<translation>Kliknij odłączony węzeł, przesuń wskaźnik do żądanej lokalizacji na rurze, aby go przerwać.</translation>
		</message>
		<message>
			<source>Click on disconnected node, move the pointer to the desired location on pipe to break it</source>
			<translation>Kliknij odłączony węzeł, przesuń wskaźnik do żądanej lokalizacji na rurze, aby go przerwać.</translation>
		</message>
		<message>
			<source>Click on feature or any place on the map and set a radius of a circle</source>
			<translation>Kliknij element lub dowolne miejsce na mapie i ustaw promień okręgu.</translation>
		</message>
		<message>
			<source>Click on feature or any place on the map and set radius of a circle</source>
			<translation>Kliknij element lub dowolne miejsce na mapie i ustaw promień okręgu.</translation>
		</message>
		<message>
			<source>Click on feature to replace it with a new one. You can select other layer to snapp diferent feature type.</source>
			<translation>Kliknij element, aby zastąpić go nowym. Możesz wybrać inną warstwę, aby przyciągnąć ją do innego typu elementu.</translation>
		</message>
		<message>
			<source>Click on node</source>
			<translation>Kliknij węzeł łączący dwie rury, aby go usunąć i połączyć rury.</translation>
		</message>
		<message>
			<source>Click on node, that joins two pipes, in order to remove it</source>
			<translation>Kliknij węzeł łączący dwie rury, aby go usunąć</translation>
		</message>
		<message>
			<source>Click on node, that joins two pipes, in order to remove it and merge pipes</source>
			<translation>Kliknij węzeł łączący dwie rury, aby go usunąć i połączyć rury.</translation>
		</message>
		<message>
			<source>Click on node to change it&apos;s type</source>
			<translation>Kliknij węzeł, aby zmienić jego typ</translation>
		</message>
		<message>
			<source>Click on node to computed its downstream network</source>
			<translation>Kliknij węzeł, aby wyliczyć jego dalszą sieć</translation>
		</message>
		<message>
			<source>Click on node to computed its upstream network</source>
			<translation>Kliknij węzeł, aby obliczyć jego sieć nadrzędną</translation>
		</message>
		<message>
			<source>Click on the object to change its class</source>
			<translation>Kliknij obiekt, aby zmienić jego klasę</translation>
		</message>
		<message>
			<source>Close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>Column name already exists.</source>
			<translation>Nazwa kolumny już istnieje.</translation>
		</message>
		<message>
			<source>Column name and Label fields are mandatory. Please set correct value.</source>
			<translation>Pola Nazwa kolumny i Etykieta są obowiązkowe. Ustaw prawidłową wartość.</translation>
		</message>
		<message>
			<source>Column not found</source>
			<translation>Nie znaleziono kolumny</translation>
		</message>
		<message>
			<source>_compare failed in ControlBase because </source>
			<translation>_compare nie powiodło się w ControlBase, ponieważ</translation>
		</message>
		<message>
			<source>Completed with no exception and no result</source>
			<translation>Ukończono bez wyjątku i bez wyniku</translation>
		</message>
		<message>
			<source>Compliance Grade</source>
			<translation>Stopień zgodności</translation>
		</message>
		<message>
			<source>Compliance value must be between 0 and 10 inclusive.</source>
			<translation>Wartość zgodności musi zawierać się w przedziale od 0 do 10 włącznie.</translation>
		</message>
		<message>
			<source>Composer template not found. Name should be</source>
			<translation>Nie znaleziono szablonu Composer. Nazwa powinna brzmieć</translation>
		</message>
		<message>
			<source>Composer &apos;ud_profile&apos; created</source>
			<translation>Utworzono kompozytor &apos;ud_profile&apos;</translation>
		</message>
		<message>
			<source>Conexión</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>Config database file not found</source>
			<translation>Nie znaleziono pliku bazy danych konfiguracji</translation>
		</message>
		<message>
			<source>Config file not found at</source>
			<translation>Nie znaleziono pliku konfiguracyjnego pod adresem</translation>
		</message>
		<message>
			<source>ConfigLayerFields task is already active!</source>
			<translation>Zadanie ConfigLayerFields jest już aktywne!</translation>
		</message>
		<message>
			<source>Configuration file couldn&apos;t be imported:</source>
			<translation>Nie można zaimportować pliku konfiguracyjnego:</translation>
		</message>
		<message>
			<source>Configuration file couldn&apos;t be imported:\n{0}</source>
			<translation>Nie można zaimportować pliku konfiguracji:\n{0}</translation>
		</message>
		<message>
			<source>Configuration file not found, please make sure it is located in the correct directory and try again</source>
			<translation>Nie znaleziono pliku konfiguracyjnego, upewnij się, że znajduje się on we właściwym katalogu i spróbuj ponownie</translation>
		</message>
		<message>
			<source>Configuration loaded successfully</source>
			<translation>Konfiguracja została załadowana pomyślnie</translation>
		</message>
		<message>
			<source>Configuration saved to {0}</source>
			<translation>Konfiguracja zapisana w {0}</translation>
		</message>
		<message>
			<source>Confirm Deletion</source>
			<translation>Potwierdź usunięcie</translation>
		</message>
		<message>
			<source>CONNEC</source>
			<translation>CONNEC</translation>
		</message>
		<message>
			<source>Connected to {0}</source>
			<translation>Połączony z {0}</translation>
		</message>
		<message>
			<source>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;</source>
			<translation>Nie znaleziono połączenia &apos;{0}&apos; w pliku &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Connection &apos;{0}&apos; not found in the file &apos;{1}&apos;. Trying in &apos;{2}&apos;...</source>
			<translation>Nie znaleziono połączenia &apos;{0}&apos; w pliku &apos;{1}&apos;. Próba w &apos;{2}&apos;...</translation>
		</message>
		<message>
			<source>Connection Failed. Please</source>
			<translation>Połączenie nie powiodło się. Sprawdź parametry połączenia</translation>
		</message>
		<message>
			<source>Connection Failed. Please, check connection parameters</source>
			<translation>Połączenie nie powiodło się. Sprawdź parametry połączenia</translation>
		</message>
		<message>
			<source>Connect link task is already active!</source>
			<translation>Zadanie Połącz link jest już aktywne!</translation>
		</message>
		<message>
			<source>Constructed place geometry polygon(s) to query Overpass</source>
			<translation>Skonstruowany wielokąt(y) geometrii miejsca do zapytania Overpass</translation>
		</message>
		<message>
			<source>Context</source>
			<translation>Kontekst</translation>
		</message>
		<message>
			<source>Converted MultiDiGraph to DiGraph</source>
			<translation>Konwersja MultiDiGraph do DiGraph</translation>
		</message>
		<message>
			<source>Converted MultiDiGraph to undirected MultiGraph</source>
			<translation>Konwersja MultiDiGraph do nieukierunkowanego MultiGraph</translation>
		</message>
		<message>
			<source>Converting node, edge, and graph-level attribute data types</source>
			<translation>Konwersja typów danych węzłów, krawędzi i atrybutów na poziomie wykresu</translation>
		</message>
		<message>
			<source>Could not determine a valid role for team &apos;{0}&apos;.</source>
			<translation>Nie można określić prawidłowej roli dla zespołu &quot;{0}&quot;.</translation>
		</message>
		<message>
			<source>Could not determine event point coordinates</source>
			<translation>Could not determine event point coordinates</translation>
		</message>
		<message>
			<source>Could not find an ID for the style group &apos;{0}&apos;.</source>
			<translation>Nie można znaleźć identyfikatora dla grupy stylów &quot;{0}&quot;.</translation>
		</message>
		<message>
			<source>Could not find config_style ID for idval &apos;{0}&apos;.</source>
			<translation>Nie można znaleźć identyfikatora config_style dla idval &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Could not find the corresponding ID for the selected style {0}.</source>
			<translation>Nie można znaleźć odpowiedniego identyfikatora dla wybranego stylu {0}.</translation>
		</message>
		<message>
			<source>Could not find the original user to update.</source>
			<translation>Nie można znaleźć oryginalnego użytkownika do aktualizacji.</translation>
		</message>
		<message>
			<source>Could not get feature ID from snapped point</source>
			<translation>Could not get feature ID from snapped point</translation>
		</message>
		<message>
			<source>Could not load EPA Results layers</source>
			<translation>Could not load EPA Results layers</translation>
		</message>
		<message>
			<source>Could not retrieve feature from layer</source>
			<translation>Could not retrieve feature from layer</translation>
		</message>
		<message>
			<source>Couldn&apos;t add group.</source>
			<translation>Nie można dodać grupy.</translation>
		</message>
		<message>
			<source>Couldn&apos;t draw profile. You may need to select another exploitation.</source>
			<translation>Nie można narysować profilu. Może być konieczne wybranie innej eksploatacji.</translation>
		</message>
		<message>
			<source>Couldn&apos;t find layer to zoom to</source>
			<translation>Nie można znaleźć warstwy do powiększenia</translation>
		</message>
		<message>
			<source>Couldn&apos;t import scipy/numpy so the graph can&apos;t be shown. Please install it manually or try with another QGIS version</source>
			<translation>Nie można zaimportować scipy/numpy, więc wykres nie może zostać wyświetlony. Zainstaluj go ręcznie lub spróbuj z inną wersją QGIS</translation>
		</message>
		<message>
			<source>Couldn&apos;t import swmm_api package. Try to reload the Giswater plugin. If the issue persists restart QGIS.</source>
			<translation>Nie można zaimportować pakietu swmm_api. Spróbuj ponownie załadować wtyczkę Giswater. Jeśli problem nadal występuje, uruchom ponownie QGIS.</translation>
		</message>
		<message>
			<source>Counted undirected street segments incident on each node</source>
			<translation>Zliczone nieukierunkowane segmenty ulic przypadające na każdy węzeł</translation>
		</message>
		<message>
			<source>Create {0} schema</source>
			<translation>Utwórz {0} schemat</translation>
		</message>
		<message>
			<source>Create base schema</source>
			<translation>Tworzenie schematu bazowego</translation>
		</message>
		<message>
			<source>Created edges GeoDataFrame from graph</source>
			<translation>Utworzone krawędzie GeoDataFrame z wykresu</translation>
		</message>
		<message>
			<source>Created graph from node/edge GeoDataFrames</source>
			<translation>Utworzony wykres z węzłów/krawędzi GeoDataFrames</translation>
		</message>
		<message>
			<source>Created nodes GeoDataFrame from graph</source>
			<translation>Utworzone węzły GeoDataFrame z wykresu</translation>
		</message>
		<message>
			<source>Create example</source>
			<translation>Utwórz przykład</translation>
		</message>
		<message>
			<source>Create parent schema</source>
			<translation>Tworzenie schematu nadrzędnego</translation>
		</message>
		<message>
			<source>Create {project} schema</source>
			<translation>Utwórz schemat {project}</translation>
		</message>
		<message>
			<source>Create schema of type &apos;{0}&apos;: &apos;{1}&apos;</source>
			<translation>Utwórz schemat typu &apos;{0}&apos;: &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Creating GIS file... {0}</source>
			<translation>Tworzenie pliku GIS... {0}</translation>
		</message>
		<message>
			<source>Creating parser for file: {0}</source>
			<translation>Tworzenie parsera dla pliku: {0}</translation>
		</message>
		<message>
			<source>Creating user config folder</source>
			<translation>Tworzenie folderu konfiguracji użytkownika</translation>
		</message>
		<message>
			<source>Creating user config folder: {0}</source>
			<translation>Tworzenie folderu konfiguracji użytkownika: {0}</translation>
		</message>
		<message>
			<source>Credentials will be stored in GIS project file</source>
			<translation>Poświadczenia będą przechowywane w pliku projektu GIS</translation>
		</message>
		<message>
			<source>Credentials will be stored in GIS project file. Do you want to continue?</source>
			<translation>Dane uwierzytelniające zostaną zapisane w pliku projektu GIS. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>Credentials will be stored in the GIS project file as plain text, and will apply to both existing and future layers. Do you want to proceed?</source>
			<translation>Poświadczenia będą przechowywane w pliku projektu GIS jako zwykły tekst i będą miały zastosowanie zarówno do istniejących, jak i przyszłych warstw. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>CRITICAL ERROR in update_expl_sector_combos</source>
			<translation>CRITICAL ERROR in update_expl_sector_combos</translation>
		</message>
		<message>
			<source>CSV not generated. Check fields from table or view</source>
			<translation>CSV nie został wygenerowany. Sprawdź pola z tabeli lub widoku</translation>
		</message>
		<message>
			<source>Current feature has state &apos;{0}&apos;. Therefore it is not fusionable</source>
			<translation>Bieżąca funkcja ma stan &quot;{0}&quot;. Dlatego nie można jej połączyć</translation>
		</message>
		<message>
			<source>Current feature has state &apos;{0}&apos;. Therefore it is not replaceable</source>
			<translation>Bieżąca funkcja ma stan &quot;{0}&quot;. Dlatego nie można jej zastąpić</translation>
		</message>
		<message>
			<source>Current feature is planified. You should activate plan mode to work with it.</source>
			<translation>Obecna funkcja jest planowana. Aby z niej korzystać, należy aktywować tryb planowania.</translation>
		</message>
		<message>
			<source>Current layer not valid</source>
			<translation>Bieżąca warstwa jest nieprawidłowa</translation>
		</message>
		<message>
			<source>Current node is not located over an arc. Please</source>
			<translation>Bieżący węzeł nie znajduje się nad łukiem. Wybierz opcję &quot;DRAG-DROP&quot; (przeciągnij i upuść).</translation>
		</message>
		<message>
			<source>Current node is not located over an arc. Please, select option &apos;DRAG-DROP&apos;</source>
			<translation>Bieżący węzeł nie znajduje się nad łukiem. Wybierz opcję &quot;DRAG-DROP&quot; (przeciągnij i upuść).</translation>
		</message>
		<message>
			<source>Current psector</source>
			<translation>Obecny sektor</translation>
		</message>
		<message>
			<source>Current psector: {1}</source>
			<translation>Current psector: {1}</translation>
		</message>
		<message>
			<source>Current user does not have &apos;plan_psector_current&apos;. Value of current psector will be inserted.</source>
			<translation>Bieżący użytkownik nie posiada &apos;plan_psector_current&apos;. Wstawiona zostanie wartość bieżącego sektora.</translation>
		</message>
		<message>
			<source>Custom mincut executed successfully</source>
			<translation>Pomyślne wykonanie niestandardowego mincut</translation>
		</message>
		<message>
			<source>Database connection error: {0}</source>
			<translation>Błąd połączenia z bazą danych: {0}</translation>
		</message>
		<message>
			<source>Database connection error ({0    }): {1}</source>
			<translation>Błąd połączenia z bazą danych ({0 }): {1}</translation>
		</message>
		<message>
			<source>Database connection error (PgDao). Please open plugin log file to get more details</source>
			<translation>Błąd połączenia z bazą danych (PgDao). Otwórz plik dziennika wtyczki, aby uzyskać więcej szczegółów</translation>
		</message>
		<message>
			<source>Database connection error. Please check your connection parameters.</source>
			<translation>Błąd połączenia z bazą danych. Sprawdź parametry połączenia.</translation>
		</message>
		<message>
			<source>Database connection error. Please open plugin log file to get more details</source>
			<translation>Błąd połączenia z bazą danych. Otwórz plik dziennika wtyczki, aby uzyskać więcej szczegółów</translation>
		</message>
		<message>
			<source>Database connection error (psycopg2). Please open plugin log file to get more details</source>
			<translation>Błąd połączenia z bazą danych (psycopg2). Otwórz plik dziennika wtyczki, aby uzyskać więcej szczegółów</translation>
		</message>
		<message>
			<source>Database connection error (QSqlDatabase). Please open plugin log file to get more details</source>
			<translation>Błąd połączenia z bazą danych (QSqlDatabase). Otwórz plik dziennika wtyczki, aby uzyskać więcej szczegółów</translation>
		</message>
		<message>
			<source>Database connection reset, please try again</source>
			<translation>Połączenie z bazą danych zostało zresetowane, spróbuj ponownie</translation>
		</message>
		<message>
			<source>Database connection was closed and reconnected</source>
			<translation>Połączenie z bazą danych zostało zamknięte i nawiązane ponownie</translation>
		</message>
		<message>
			<source>Database error</source>
			<translation>Błąd bazy danych</translation>
		</message>
		<message>
			<source>Database Error</source>
			<translation>Błąd bazy danych</translation>
		</message>
		<message>
			<source>Database execution failed</source>
			<translation>Wykonanie bazy danych nie powiodło się</translation>
		</message>
		<message>
			<source>Database name contains special characters that are not supported</source>
			<translation>Nazwa bazy danych zawiera znaki specjalne, które nie są obsługiwane</translation>
		</message>
		<message>
			<source>Database returned null. Check postgres function &apos;{0}&apos;</source>
			<translation>Baza danych zwróciła wartość null. Sprawdź funkcję postgres &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Database translation canceled.</source>
			<translation>Tłumaczenie bazy danych anulowane.</translation>
		</message>
		<message>
			<source>Database translation failed.</source>
			<translation>Tłumaczenie bazy danych nie powiodło się.</translation>
		</message>
		<message>
			<source>Database translation successful to</source>
			<translation>Tłumaczenie bazy danych powiodło się do</translation>
		</message>
		<message>
			<source>Data insertion completed: {0} successful, {1} errors.</source>
			<translation>Wstawianie danych zakończone: {0} powiodło się, {1} błędów.</translation>
		</message>
		<message>
			<source>Data is ok. You can try to generate the INP file</source>
			<translation>Dane są w porządku. Możesz spróbować wygenerować plik INP</translation>
		</message>
		<message>
			<source>Data retrieved and displayed successfully.</source>
			<translation>Dane pobrane i wyświetlone pomyślnie.</translation>
		</message>
		<message>
			<source>Date</source>
			<translation>Date</translation>
		</message>
		<message>
			<source>Date from:</source>
			<translation>Data od:</translation>
		</message>
		<message>
			<source>Date interval not valid!</source>
			<translation>Przedział daty jest nieprawidłowy!</translation>
		</message>
		<message>
			<source>Date of creation</source>
			<translation>Data utworzenia</translation>
		</message>
		<message>
			<source>Date of creation: {project_date_create}</source>
			<translation>Data utworzenia: {project_date_create}</translation>
		</message>
		<message>
			<source>Date of last update</source>
			<translation>Data ostatniej aktualizacji</translation>
		</message>
		<message>
			<source>Date of last update: {project_date_update}</source>
			<translation>Data ostatniej aktualizacji: {project_date_update}</translation>
		</message>
		<message>
			<source>Date to:</source>
			<translation>Data do:</translation>
		</message>
		<message>
			<source>Decode error reading inp file</source>
			<translation>Błąd dekodowania przy odczycie pliku inp</translation>
		</message>
		<message>
			<source>Default Built Date</source>
			<translation>Domyślna data utworzenia</translation>
		</message>
		<message>
			<source>Delete Lot(s)</source>
			<translation>Delete Lot(s)</translation>
		</message>
		<message>
			<source>Delete mincut</source>
			<translation>Usuń mincut</translation>
		</message>
		<message>
			<source>Delete profile</source>
			<translation>Usuń profil</translation>
		</message>
		<message>
			<source>Delete records</source>
			<translation>Usuwanie rekordów</translation>
		</message>
		<message>
			<source>Delete records</source>
			<translation>Delete records</translation>
		</message>
		<message>
			<source>Delete Workorder(s)</source>
			<translation>Delete Workorder(s)</translation>
		</message>
		<message>
			<source>Description</source>
			<translation>Opis</translation>
		</message>
		<message>
			<source>Detail</source>
			<translation>Szczegóły</translation>
		</message>
		<message>
			<source>Diameter</source>
			<translation>Średnica</translation>
		</message>
		<message>
			<source>Did not save to cache because HTTP status code is not OK</source>
			<translation>Nie zapisano w pamięci podręcznej, ponieważ kod statusu HTTP nie jest OK.</translation>
		</message>
		<message>
			<source>Discarding the `gdf_nodes` &apos;geometry&apos; column, though its values differ from the coordinates in the &apos;x&apos; and &apos;y&apos; columns.</source>
			<translation>Odrzucenie kolumny &quot;geometria&quot; `gdf_nodes`, mimo że jej wartości różnią się od współrzędnych w kolumnach &quot;x&quot; i &quot;y&quot;.</translation>
		</message>
		<message>
			<source>Disconnect elements</source>
			<translation>Elementy rozłączające</translation>
		</message>
		<message>
			<source>`dist_type` must be &apos;bbox&apos; or &apos;network&apos;.</source>
			<translation>`dist_type` musi mieć wartość &apos;bbox&apos; lub &apos;network&apos;.</translation>
		</message>
		<message>
			<source>Document already exist</source>
			<translation>Dokument już istnieje</translation>
		</message>
		<message>
			<source>Document already exists</source>
			<translation>Dokument już istnieje</translation>
		</message>
		<message>
			<source>Document deleted</source>
			<translation>Dokument usunięty</translation>
		</message>
		<message>
			<source>Document inserted successfully</source>
			<translation>Dokument wstawiony pomyślnie</translation>
		</message>
		<message>
			<source>Document name not found</source>
			<translation>Nie znaleziono nazwy dokumentu</translation>
		</message>
		<message>
			<source>Document PDF created in</source>
			<translation>Dokument PDF utworzony w</translation>
		</message>
		<message>
			<source>Documents deleted successfully</source>
			<translation>Dokumenty zostały pomyślnie usunięte</translation>
		</message>
		<message>
			<source>DOWNGRADE NODE</source>
			<translation>WĘZEŁ DOWNGRADE</translation>
		</message>
		<message>
			<source>Do you want change it and continue?</source>
			<translation>Czy chcesz to zmienić i kontynuować?</translation>
		</message>
		<message>
			<source>Do you want to continue?</source>
			<translation>Do you want to continue?</translation>
		</message>
		<message>
			<source>Do you want to copy its values to the current node?</source>
			<translation>Czy chcesz skopiować jego wartości do bieżącego węzła?</translation>
		</message>
		<message>
			<source>Do you want to insert {0} selected features? (First 50: {1} ...)</source>
			<translation>Do you want to insert {0} selected features? (First 50: {1} ...)</translation>
		</message>
		<message>
			<source>Do you want to insert the selected features?</source>
			<translation>Do you want to insert the selected features?</translation>
		</message>
		<message>
			<source>Do you want to insert the selected features? {0}</source>
			<translation>Czy chcesz wstawić wybrane funkcje? {0}</translation>
		</message>
		<message>
			<source>Do you want to open GIS project?</source>
			<translation>Czy chcesz otworzyć projekt GIS?</translation>
		</message>
		<message>
			<source>Do you want to overwrite custom values?</source>
			<translation>Czy chcesz nadpisać wartości niestandardowe?</translation>
		</message>
		<message>
			<source>Do you want to overwrite file?</source>
			<translation>Czy chcesz nadpisać plik?</translation>
		</message>
		<message>
			<source>Do you want to proceed?</source>
			<translation>Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>Do you want to save changes to dscenario </source>
			<translation>Czy chcesz zapisać zmiany w dscenario?</translation>
		</message>
		<message>
			<source>Do you want to set this psector as current?</source>
			<translation>Czy chcesz ustawić ten sektor jako bieżący?</translation>
		</message>
		<message>
			<source>DRAIN plugin not found</source>
			<translation>Nie znaleziono wtyczki DRAIN</translation>
		</message>
		<message>
			<source>Draw a pipe connected to two nodes</source>
			<translation>Narysuj rurę połączoną z dwoma węzłami</translation>
		</message>
		<message>
			<source>Draw a point on the map inside created map zones</source>
			<translation>Narysuj punkt na mapie wewnątrz utworzonych stref mapy</translation>
		</message>
		<message>
			<source>Draw Profile</source>
			<translation>Draw Profile</translation>
		</message>
		<message>
			<source>Dscenario manager</source>
			<translation>Menedżer scenariusza</translation>
		</message>
		<message>
			<source>During task &apos;{0}, function {1} returned False</source>
			<translation>Podczas zadania &apos;{0}, funkcja {1} zwróciła wartość False</translation>
		</message>
		<message>
			<source>DWF scenario manager</source>
			<translation>Menedżer scenariuszy DWF</translation>
		</message>
		<message>
			<source>Each query must be a dict or a string.</source>
			<translation>Każde zapytanie musi być dyktą lub ciągiem znaków.</translation>
		</message>
		<message>
			<source>Edge &apos;length&apos; and &apos;speed_kph&apos; values must be non-null.</source>
			<translation>Wartości krawędzi &quot;length&quot; i &quot;speed_kph&quot; muszą być różne od zera.</translation>
		</message>
		<message>
			<source>Either `node_size` or `edge_linewidth` must be &gt; 0 to plot something.</source>
			<translation>Albo `node_size` albo `edge_linewidth` musi być &gt; 0 by coś wykreślić.</translation>
		</message>
		<message>
			<source>Element</source>
			<translation>Element</translation>
		</message>
		<message>
			<source>ELEMENT</source>
			<translation>ELEMENT</translation>
		</message>
		<message>
			<source>Element does not exist</source>
			<translation>Element nie istnieje</translation>
		</message>
		<message>
			<source>Elevation API did not return a dict of results.</source>
			<translation>Interfejs API Elevation nie zwrócił listy wyników.</translation>
		</message>
		<message>
			<source>Empty coordinate list</source>
			<translation>Pusta lista współrzędnych</translation>
		</message>
		<message>
			<source>Empty data</source>
			<translation>Empty data</translation>
		</message>
		<message>
			<source>Empty value detected in &apos;Diameter&apos; tab. Please enter a value for diameter.</source>
			<translation>Wykryto pustą wartość w zakładce &quot;Średnica&quot;. Wprowadź wartość dla średnicy.</translation>
		</message>
		<message>
			<source>Encode error reading inp file</source>
			<translation>Błąd kodowania przy odczycie pliku inp</translation>
		</message>
		<message>
			<source>End date</source>
			<translation>Wystąpił błąd podczas zapisywania zlecenia.</translation>
		</message>
		<message>
			<source>English locale not found</source>
			<translation>Nie znaleziono angielskich ustawień regionalnych</translation>
		</message>
		<message>
			<source>Epa2data execution failed. See logs for more details...</source>
			<translation>Wykonanie Epa2data nie powiodło się. Więcej szczegółów w logach...</translation>
		</message>
		<message>
			<source>Epa2data execution successful.</source>
			<translation>Wykonanie Epa2data powiodło się.</translation>
		</message>
		<message>
			<source>EPA model finished. </source>
			<translation>Model EPA zakończony.</translation>
		</message>
		<message>
			<source>Epatools Plugin</source>
			<translation>Wtyczka Epatools</translation>
		</message>
		<message>
			<source>EPSG: {self.project_epsg}</source>
			<translation>EPSG: {self.project_epsg}</translation>
		</message>
		<message>
			<source>(Error {}) </source>
			<translation>(Błąd {})</translation>
		</message>
		<message>
			<source>Error</source>
			<translation>Błąd</translation>
		</message>
		<message>
			<source>Error</source>
			<translation>Błąd</translation>
		</message>
		<message>
			<source>Error: &apos;{0}&apos; or &apos;{1}&apos; field is missing in the result.</source>
			<translation>Błąd: W wyniku brakuje pola &apos;{0}&apos; lub &apos;{1}&apos;.</translation>
		</message>
		<message>
			<source>Error assigning team: {0}</source>
			<translation>Error assigning team: {0}</translation>
		</message>
		<message>
			<source>Error connecting to database (layer)</source>
			<translation>Błąd połączenia z bazą danych (warstwa)</translation>
		</message>
		<message>
			<source>Error connecting to database (settings)</source>
			<translation>Błąd połączenia z bazą danych (ustawienia)</translation>
		</message>
		<message>
			<source>Error connecting to i18n dataabse</source>
			<translation>Błąd połączenia z i18n dataabse</translation>
		</message>
		<message>
			<source>Error connecting to i18n database</source>
			<translation>Błąd połączenia z bazą danych i18n</translation>
		</message>
		<message>
			<source>Error connecting to origin database</source>
			<translation>Błąd połączenia z bazą danych origin</translation>
		</message>
		<message>
			<source>Error: Could not extract message from line: {0}</source>
			<translation>Błąd: Nie można wyodrębnić wiadomości z linii: {0}</translation>
		</message>
		<message>
			<source>Error creating auxiliary connection for vacuum</source>
			<translation>Błąd podczas tworzenia połączenia pomocniczego dla podciśnienia</translation>
		</message>
		<message>
			<source>Error creating composer</source>
			<translation>Błąd podczas tworzenia kompozytora</translation>
		</message>
		<message>
			<source>Error creating dynamic dialog: {0}</source>
			<translation>Error creating dynamic dialog: {0}</translation>
		</message>
		<message>
			<source>Error creating or updating organization</source>
			<translation>Błąd podczas tworzenia lub aktualizacji organizacji</translation>
		</message>
		<message>
			<source>Error creating or updating team</source>
			<translation>Error creating or updating team</translation>
		</message>
		<message>
			<source>Error creating or updating team</source>
			<translation>Błąd podczas tworzenia lub aktualizacji zespołu</translation>
		</message>
		<message>
			<source>Error creating or updating user in cat_user table.</source>
			<translation>Błąd tworzenia lub aktualizacji użytkownika w tabeli cat_user.</translation>
		</message>
		<message>
			<source>Error creating Workcat.</source>
			<translation>Błąd podczas tworzenia Workcat.</translation>
		</message>
		<message>
			<source>Error. Database returned null. Check postgres function &apos;{0}&apos;</source>
			<translation>Błąd. Baza danych zwróciła wartość null. Sprawdź funkcję postgres &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Error deleting data</source>
			<translation>Błąd usuwania danych</translation>
		</message>
		<message>
			<source>Error deleting profile</source>
			<translation>Błąd usuwania profilu</translation>
		</message>
		<message>
			<source>Error deleting records</source>
			<translation>Błąd usuwania rekordów</translation>
		</message>
		<message>
			<source>Error deleting row</source>
			<translation>Błąd usuwania wiersza</translation>
		</message>
		<message>
			<source>Error deleting row: {0} - Query: {1}</source>
			<translation>Błąd usuwania wiersza: {0} - Zapytanie: {1}</translation>
		</message>
		<message>
			<source>Error during point selection: {0}</source>
			<translation>Error during point selection: {0}</translation>
		</message>
		<message>
			<source>Error executing gw_fct_create_dscenario_empty</source>
			<translation>Błąd wykonania gw_fct_create_dscenario_empty</translation>
		</message>
		<message>
			<source>Error executing gw_fct_import_swmm_flwreg</source>
			<translation>Błąd wykonania gw_fct_import_swmm_flwreg</translation>
		</message>
		<message>
			<source>Error executing vacuum: {0}</source>
			<translation>Błąd wykonania próżni: {0}</translation>
		</message>
		<message>
			<source>Error fetching existing primary keys</source>
			<translation>Błąd pobierania istniejących kluczy głównych</translation>
		</message>
		<message>
			<source>Error fetching existing primary keys: {0}</source>
			<translation>Błąd pobierania istniejących kluczy głównych: {0}</translation>
		</message>
		<message>
			<source>Error finding string</source>
			<translation>Błąd wyszukiwania ciągu znaków</translation>
		</message>
		<message>
			<source>Error fusing arcs</source>
			<translation>Error fusing arcs</translation>
		</message>
		<message>
			<source>Error getting current psector</source>
			<translation>Błąd pobierania bieżącego sektora</translation>
		</message>
		<message>
			<source>Error getting database parameters</source>
			<translation>Błąd pobierania parametrów bazy danych</translation>
		</message>
		<message>
			<source>Error getting default connection (settings)</source>
			<translation>Błąd podczas uzyskiwania domyślnego połączenia (ustawienia)</translation>
		</message>
		<message>
			<source>Error getting exploitation</source>
			<translation>Błąd pobierania exploitów</translation>
		</message>
		<message>
			<source>Error getting locale from schema: {0}</source>
			<translation>Błąd pobierania ustawień regionalnych ze schematu: {0}</translation>
		</message>
		<message>
			<source>Error getting pgRouting version</source>
			<translation>Błąd pobierania wersji pgRouting</translation>
		</message>
		<message>
			<source>Error getting table name from selected layer</source>
			<translation>Błąd pobierania nazwy tabeli z wybranej warstwy</translation>
		</message>
		<message>
			<source>Error getting table values: {0}</source>
			<translation>Błąd pobierania wartości tabeli: {0}</translation>
		</message>
		<message>
			<source>Error importing IBERGIS project</source>
			<translation>Błąd importowania projektu IBERGIS</translation>
		</message>
		<message>
			<source>Error inserting element in table, you need to review data</source>
			<translation>Błąd wstawiania elementu do tabeli, należy przejrzeć dane</translation>
		</message>
		<message>
			<source>Error inserting node</source>
			<translation>Błąd wstawiania węzła</translation>
		</message>
		<message>
			<source>Error inserting profile table, you need to review data</source>
			<translation>Błąd wstawiania tabeli profili, należy przejrzeć dane</translation>
		</message>
		<message>
			<source>Error inserting row: {0}</source>
			<translation>Błąd wstawiania wiersza: {0}</translation>
		</message>
		<message>
			<source>Error logging</source>
			<translation>Rejestrowanie błędów</translation>
		</message>
		<message>
			<source>Error near line</source>
			<translation>Błąd w pobliżu linii</translation>
		</message>
		<message>
			<source>Error near line {0} -&gt; {1}</source>
			<translation>Błąd w pobliżu linii {0} -&gt; {1}</translation>
		</message>
		<message>
			<source>Error on create auto mincut</source>
			<translation>Błąd podczas tworzenia automatycznego cięcia minimalnego, należy przejrzeć dane</translation>
		</message>
		<message>
			<source>Error on create auto mincut, you need to review data</source>
			<translation>Błąd podczas tworzenia automatycznego cięcia minimalnego, należy przejrzeć dane</translation>
		</message>
		<message>
			<source>Error parsing file: {0}</source>
			<translation>Błąd parsowania pliku: {0}</translation>
		</message>
		<message>
			<source>Error processing muni_id {0}: {1}</source>
			<translation>Błąd przetwarzania muni_id {0}: {1}</translation>
		</message>
		<message>
			<source>Error reading configuration file: {0}</source>
			<translation>Błąd odczytu pliku konfiguracyjnego: {0}</translation>
		</message>
		<message>
			<source>Error reading file</source>
			<translation>Błąd odczytu pliku</translation>
		</message>
		<message>
			<source>Error reading file &apos;{0}&apos;: {1}</source>
			<translation>Błąd odczytu pliku &apos;{0}&apos;: {1}</translation>
		</message>
		<message>
			<source>Error reading file {0}: {1}</source>
			<translation>Błąd odczytu pliku {0}: {1}</translation>
		</message>
		<message>
			<source>Error removing team assignment: {0}</source>
			<translation>Error removing team assignment: {0}</translation>
		</message>
		<message>
			<source>Error replacing feature</source>
			<translation>Funkcja zastępowania błędów</translation>
		</message>
		<message>
			<source>Error replacing feature. Chose a valid catalog.</source>
			<translation>Funkcja zastępowania błędów. Wybierz prawidłowy katalog.</translation>
		</message>
		<message>
			<source>Error saving lot.</source>
			<translation>Błąd zapisu partii.</translation>
		</message>
		<message>
			<source>Error saving lot.</source>
			<translation>Error saving lot.</translation>
		</message>
		<message>
			<source>Error saving the configuration</source>
			<translation>Błąd podczas zapisywania konfiguracji</translation>
		</message>
		<message>
			<source>Error setting node</source>
			<translation>Error setting node</translation>
		</message>
		<message>
			<source>Error toggling state: {0}</source>
			<translation>Error toggling state: {0}</translation>
		</message>
		<message>
			<source>Error translating: {0}</source>
			<translation>Błąd tłumaczenia: {0}</translation>
		</message>
		<message>
			<source>Error type</source>
			<translation>Typ błędu</translation>
		</message>
		<message>
			<source>Error updating: {0}.</source>
			<translation>Błąd aktualizacji: {0}.</translation>
		</message>
		<message>
			<source>Error updating: {0}.\n</source>
			<translation>Błąd aktualizacji: {0}.\n</translation>
		</message>
		<message>
			<source>Error updating element in table</source>
			<translation>Błąd aktualizacji elementu w tabeli, należy przejrzeć dane</translation>
		</message>
		<message>
			<source>Error updating element in table, you need to review data</source>
			<translation>Błąd aktualizacji elementu w tabeli, należy przejrzeć dane</translation>
		</message>
		<message>
			<source>Error updating expl_id: {0}</source>
			<translation>Błąd aktualizacji expl_id: {0}</translation>
		</message>
		<message>
			<source>Error updating message</source>
			<translation>Komunikat o błędzie aktualizacji</translation>
		</message>
		<message>
			<source>Error updating messages</source>
			<translation>Komunikaty o błędach aktualizacji</translation>
		</message>
		<message>
			<source>Error updating table</source>
			<translation>Błąd aktualizacji tabeli</translation>
		</message>
		<message>
			<source>Event deleted</source>
			<translation>Zdarzenie usunięte</translation>
		</message>
		<message>
			<source>EXCEPTION</source>
			<translation>WYJĄTEK</translation>
		</message>
		<message>
			<source>Exception: {0}</source>
			<translation>Wyjątek: {0}</translation>
		</message>
		<message>
			<source>Exception: {0}.</source>
			<translation>Wyjątek: {0}.</translation>
		</message>
		<message>
			<source>EXCEPTION: {0}, {1}</source>
			<translation>WYJĄTEK: {0}, {1}</translation>
		</message>
		<message>
			<source>Exception error: {0}</source>
			<translation>Błąd wyjątku: {0}</translation>
		</message>
		<message>
			<source>Exception in {0}</source>
			<translation>Wyjątek w {0}</translation>
		</message>
		<message>
			<source>Exception in {0} (executing {1} from {2}): {3}</source>
			<translation>Wyjątek w {0} (wykonanie {1} z {2}): {3}</translation>
		</message>
		<message>
			<source>Exception in info</source>
			<translation>Wyjątek w informacjach</translation>
		</message>
		<message>
			<source>Exception in info (def _get_id)</source>
			<translation>Wyjątek w info (def _get_id)</translation>
		</message>
		<message>
			<source>Exception in unload when {0}</source>
			<translation>Wyjątek podczas rozładowywania, gdy {0}</translation>
		</message>
		<message>
			<source>Exception in unload when deleting {0}</source>
			<translation>Wyjątek podczas rozładowywania przy usuwaniu {0}</translation>
		</message>
		<message>
			<source>Exception in unload when disconnecting {0} signal</source>
			<translation>Wyjątek podczas rozładowywania po odłączeniu sygnału {0}</translation>
		</message>
		<message>
			<source>Exception in unload when reset values for {0}</source>
			<translation>Wyjątek podczas rozładowywania, gdy resetowane są wartości dla {0}</translation>
		</message>
		<message>
			<source>Exception in unload when unset signals</source>
			<translation>Wyjątek podczas rozładowywania po odłączeniu sygnałów</translation>
		</message>
		<message>
			<source>Exception message not shown to user</source>
			<translation>Komunikat o wyjątku nie jest wyświetlany użytkownikowi</translation>
		</message>
		<message>
			<source>Exception when replacing inp strings</source>
			<translation>Wyjątek podczas zastępowania ciągów inp</translation>
		</message>
		<message>
			<source>Exception while moving/deleting old user config files</source>
			<translation>Wyjątek podczas przenoszenia/usuwania starych plików konfiguracyjnych użytkownika</translation>
		</message>
		<message>
			<source>Execute &apos;{0}&apos;</source>
			<translation>Execute &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Execute epa model</source>
			<translation>Uruchom model epa</translation>
		</message>
		<message>
			<source>Execute EPA software</source>
			<translation>Wykonywanie oprogramowania EPA</translation>
		</message>
		<message>
			<source>Execute failed.</source>
			<translation>Wykonanie nie powiodło się.</translation>
		</message>
		<message>
			<source>Execute function &apos;{0}&apos;</source>
			<translation>Wykonaj funkcję &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Executing</source>
			<translation>Wykonanie</translation>
		</message>
		<message>
			<source>Executing vacuum</source>
			<translation>Wykonywanie próżni</translation>
		</message>
		<message>
			<source>Execution of {0} failed.</source>
			<translation>Wykonanie {0} nie powiodło się.</translation>
		</message>
		<message>
			<source>Export done succesfully</source>
			<translation>Eksport zakończony sukcesem</translation>
		</message>
		<message>
			<source>Export INP file into PostgreSQL</source>
			<translation>Eksport pliku INP do PostgreSQL</translation>
		</message>
		<message>
			<source>Export INP finished. </source>
			<translation>Eksport INP zakończony.</translation>
		</message>
		<message>
			<source>Expression Error</source>
			<translation>Błąd wyrażenia</translation>
		</message>
		<message>
			<source>FAIL {0}</source>
			<translation>FAIL {0}</translation>
		</message>
		<message>
			<source>Failed to add feature</source>
			<translation>Nie udało się dodać funkcji</translation>
		</message>
		<message>
			<source>Failed to configure layer &apos;{0}&apos;. Skipping...</source>
			<translation>Nie udało się skonfigurować warstwy &apos;{0}&apos;. Pomijanie...</translation>
		</message>
		<message>
			<source>Failed to create database user &apos;{0}&apos;. The user might already exist in the database.</source>
			<translation>Nie udało się utworzyć użytkownika bazy danych &apos;{0}&apos;. Użytkownik może już istnieć w bazie danych.</translation>
		</message>
		<message>
			<source>Failed to delete records from {0}.</source>
			<translation>Nie udało się usunąć rekordów z {0}.</translation>
		</message>
		<message>
			<source>Failed to delete style group</source>
			<translation>Nie udało się usunąć grupy stylów</translation>
		</message>
		<message>
			<source>Failed to delete styles</source>
			<translation>Nie udało się usunąć stylów</translation>
		</message>
		<message>
			<source>Failed to drop database user &apos;{0}&apos;. It may need to be removed manually.</source>
			<translation>Nie udało się usunąć użytkownika bazy danych &apos;{0}&apos;. Może być konieczne jego ręczne usunięcie.</translation>
		</message>
		<message>
			<source>Failed to execute the mapzones analysis.</source>
			<translation>Nie udało się wykonać analizy mapzones.</translation>
		</message>
		<message>
			<source>Failed to fetch dialog configuration</source>
			<translation>Failed to fetch dialog configuration</translation>
		</message>
		<message>
			<source>Failed to fetch dialog configuration</source>
			<translation>Nie udało się pobrać konfiguracji okna dialogowego</translation>
		</message>
		<message>
			<source>Failed to get a valid response from gw_fct_config_mapzones.</source>
			<translation>Nie udało się uzyskać prawidłowej odpowiedzi od gw_fct_config_mapzones.</translation>
		</message>
		<message>
			<source>Failed to load campaign form.</source>
			<translation>Failed to load campaign form.</translation>
		</message>
		<message>
			<source>Failed to load campaign form.</source>
			<translation>Nie udało się załadować formularza kampanii.</translation>
		</message>
		<message>
			<source>Failed to load layers</source>
			<translation>Nie udało się załadować warstw</translation>
		</message>
		<message>
			<source>Failed to load layers.</source>
			<translation>Nie udało się załadować warstw.</translation>
		</message>
		<message>
			<source>Failed to load lot form.</source>
			<translation>Failed to load lot form.</translation>
		</message>
		<message>
			<source>Failed to load lot form.</source>
			<translation>Nie udało się załadować formularza partii.</translation>
		</message>
		<message>
			<source>Failed to load team creation dialog configuration. Please check database configuration.</source>
			<translation>Failed to load team creation dialog configuration. Please check database configuration.</translation>
		</message>
		<message>
			<source>Failed to load workorder form.</source>
			<translation>Nie udało się załadować formularza zlecenia.</translation>
		</message>
		<message>
			<source>Failed to load workorder form.</source>
			<translation>Failed to load workorder form.</translation>
		</message>
		<message>
			<source>Failed to rename user from &apos;{0}&apos; to &apos;{1}&apos;. The new name might already be in use in the database.</source>
			<translation>Nie udało się zmienić nazwy użytkownika z &apos;{0}&apos; na &apos;{1}&apos;. Nowa nazwa może być już używana w bazie danych.</translation>
		</message>
		<message>
			<source>Failed to retrieve GeoJSON data.</source>
			<translation>Nie udało się pobrać danych GeoJSON.</translation>
		</message>
		<message>
			<source>Failed to retrieve graph configuration.</source>
			<translation>Nie udało się pobrać konfiguracji wykresu.</translation>
		</message>
		<message>
			<source>Failed to retrieve mapzone styles.</source>
			<translation>Nie udało się pobrać stylów mapzone.</translation>
		</message>
		<message>
			<source>Failed to retrieve sector features.</source>
			<translation>Nie udało się pobrać właściwości sektora.</translation>
		</message>
		<message>
			<source>Failed to retrieve the temporal layer</source>
			<translation>Nie udało się pobrać warstwy czasowej</translation>
		</message>
		<message>
			<source>Failed to save campaign</source>
			<translation>Nie udało się zapisać kampanii</translation>
		</message>
		<message>
			<source>Failed to save campaign</source>
			<translation>Failed to save campaign</translation>
		</message>
		<message>
			<source>Failed to set {0} scenario</source>
			<translation>Nie udało się ustawić scenariusza {0}</translation>
		</message>
		<message>
			<source>Failed to set netscenario</source>
			<translation>Nie udało się ustawić scenariusza sieciowego</translation>
		</message>
		<message>
			<source>Failed to set psector</source>
			<translation>Nie udało się ustawić psector</translation>
		</message>
		<message>
			<source>Failed to set ValueRelation for field &apos;{0}&apos;: {1}</source>
			<translation>Failed to set ValueRelation for field &apos;{0}&apos;: {1}</translation>
		</message>
		<message>
			<source>Failed to update category</source>
			<translation>Nie udało się zaktualizować kategorii</translation>
		</message>
		<message>
			<source>Failed to update category:</source>
			<translation>Nie udało się zaktualizować kategorii:</translation>
		</message>
		<message>
			<source>Failed to update password for user &apos;{0}&apos;.</source>
			<translation>Nie udało się zaktualizować hasła dla użytkownika &apos;{0}&apos;.</translation>
		</message>
		<message>
			<source>Failed to update styles</source>
			<translation>Nie udało się zaktualizować stylów</translation>
		</message>
		<message>
			<source>Failing data: {0}</source>
			<translation>Nieprawidłowe dane: {0}</translation>
		</message>
		<message>
			<source>Feature added successfully!</source>
			<translation>Funkcja została pomyślnie dodana!</translation>
		</message>
		<message>
			<source>Feature already in the list</source>
			<translation>Funkcja już znajdująca się na liście</translation>
		</message>
		<message>
			<source>Feature has not been updated because no catalog has been selected</source>
			<translation>Funkcja nie została zaktualizowana, ponieważ nie wybrano żadnego katalogu</translation>
		</message>
		<message>
			<source>Feature ID and Idval cannot be empty.</source>
			<translation>Identyfikator funkcji i Idval nie mogą być puste.</translation>
		</message>
		<message>
			<source>Feature_id is mandatory.</source>
			<translation>Feature_id jest obowiązkowy.</translation>
		</message>
		<message>
			<source>Feature not upserted</source>
			<translation>Funkcja nie została dodana</translation>
		</message>
		<message>
			<source>Feature replaced successfully</source>
			<translation>Funkcja została pomyślnie zastąpiona</translation>
		</message>
		<message>
			<source>Feature upserted</source>
			<translation>Funkcja dodana</translation>
		</message>
		<message>
			<source>Field catalog_id required!</source>
			<translation>Pole catalog_id jest wymagane!</translation>
		</message>
		<message>
			<source>Field child_layer of id: </source>
			<translation>Pole child_layer o identyfikatorze id:</translation>
		</message>
		<message>
			<source>File &apos;{0}&apos; not found in: {1}</source>
			<translation>Nie znaleziono pliku &apos;{0}&apos; w: {1}</translation>
		</message>
		<message>
			<source>File cannot be created. Check if it is already opened</source>
			<translation>Nie można utworzyć pliku. Sprawdź, czy jest już otwarty</translation>
		</message>
		<message>
			<source>File created successfully</source>
			<translation>Plik utworzony pomyślnie</translation>
		</message>
		<message>
			<source>File extension not valid</source>
			<translation>Nieprawidłowe rozszerzenie pliku</translation>
		</message>
		<message>
			<source>File INP not found</source>
			<translation>Nie znaleziono pliku INP</translation>
		</message>
		<message>
			<source>File name</source>
			<translation>Nazwa pliku</translation>
		</message>
		<message>
			<source>File name is required</source>
			<translation>Nazwa pliku jest wymagana</translation>
		</message>
		<message>
			<source>File not found</source>
			<translation>Nie znaleziono pliku</translation>
		</message>
		<message>
			<source>File not found: {0}</source>
			<translation>Nie znaleziono pliku: {0}</translation>
		</message>
		<message>
			<source>File path doesn&apos;t exist</source>
			<translation>Ścieżka pliku nie istnieje</translation>
		</message>
		<message>
			<source>File path doesn&apos;t exist or you dont have permission or file is opened</source>
			<translation>Ścieżka do pliku nie istnieje, nie masz uprawnień lub plik jest otwarty.</translation>
		</message>
		<message>
			<source>File path not found</source>
			<translation>Nie znaleziono ścieżki pliku</translation>
		</message>
		<message>
			<source>File RPT not found</source>
			<translation>Nie znaleziono pliku RPT</translation>
		</message>
		<message>
			<source>Files defined in environment variables &apos;{0}&apos; and &apos;{1}&apos; not found.</source>
			<translation>Nie znaleziono plików zdefiniowanych w zmiennych środowiskowych &apos;{0}&apos; i &apos;{1}&apos;.</translation>
		</message>
		<message>
			<source>Fill table</source>
			<translation>Tabela wypełnienia</translation>
		</message>
		<message>
			<source>Filter</source>
			<translation>Filter</translation>
		</message>
		<message>
			<source>Filter by code</source>
			<translation>Filtruj według kodu</translation>
		</message>
		<message>
			<source>Filter by ext_code</source>
			<translation>Filtruj według kodu ext_code</translation>
		</message>
		<message>
			<source>Finished plotting the graph</source>
			<translation>Zakończono wykreślanie wykresu</translation>
		</message>
		<message>
			<source>First iteration</source>
			<translation>Pierwsza iteracja</translation>
		</message>
		<message>
			<source>First node already selected with id: {0}. Select second one.</source>
			<translation>Pierwszy węzeł został już wybrany z identyfikatorem: {0}. Wybierz drugi węzeł.</translation>
		</message>
		<message>
			<source>Flood analysis will start from node ID</source>
			<translation>Analiza powodzi rozpocznie się od węzła ID</translation>
		</message>
		<message>
			<source>FLOW REGULATORS</source>
			<translation>REGULATORY PRZEPŁYWU</translation>
		</message>
		<message>
			<source>FLOWTRACE</source>
			<translation>FLOWTRACE</translation>
		</message>
		<message>
			<source>Folder not found</source>
			<translation>Nie znaleziono folderu</translation>
		</message>
		<message>
			<source>Folder path</source>
			<translation>Ścieżka folderu</translation>
		</message>
		<message>
			<source>Force commit</source>
			<translation>Wymuś zatwierdzenie</translation>
		</message>
		<message>
			<source>For select on canvas is mandatory to load v_asset_arc_input layer</source>
			<translation>For select on canvas is mandatory to load v_asset_arc_input layer</translation>
		</message>
		<message>
			<source>Found no graph nodes within the requested polygon.</source>
			<translation>Nie znaleziono węzłów wykresu w żądanym wielokącie.</translation>
		</message>
		<message>
			<source>Fragility curve</source>
			<translation>Krzywa kruchości</translation>
		</message>
		<message>
			<source>From {0}, updating {1}...</source>
			<translation>Od {0}, aktualizując {1}...</translation>
		</message>
		<message>
			<source>Full Example</source>
			<translation>Full Example</translation>
		</message>
		<message>
			<source>Function {0} error: {1} from last function is invalid</source>
			<translation>Błąd funkcji {0}: {1} z ostatniej funkcji jest nieprawidłowe</translation>
		</message>
		<message>
			<source>Function {0} error: {1} returned null</source>
			<translation>Błąd funkcji {0}: {1} zwrócił wartość null</translation>
		</message>
		<message>
			<source>Function {0} error: missing key {1}</source>
			<translation>Błąd funkcji {0}: brak klucza {1}</translation>
		</message>
		<message>
			<source>Function {0} failed</source>
			<translation>Funkcja {0} nie powiodła się</translation>
		</message>
		<message>
			<source>Function {0} finished successfully</source>
			<translation>Funkcja {0} zakończyła się pomyślnie</translation>
		</message>
		<message>
			<source>Function {0} returned {1}</source>
			<translation>Funkcja {0} zwróciła {1}.</translation>
		</message>
		<message>
			<source>Function &apos;{0}&apos; returned False</source>
			<translation>Funkcja &quot;{0}&quot; zwróciła wartość False</translation>
		</message>
		<message>
			<source>Function {0} returned False</source>
			<translation>Funkcja {0} zwróciła wartość False</translation>
		</message>
		<message>
			<source>Function error: {0}</source>
			<translation>Błąd funkcji: {0}</translation>
		</message>
		<message>
			<source>Function failed finished</source>
			<translation>Funkcja zakończona niepowodzeniem</translation>
		</message>
		<message>
			<source>Function gw_fct_create_dscenario_empty returned no dscenario_id</source>
			<translation>Funkcja gw_fct_create_dscenario_empty nie zwróciła żadnego dscenario_id</translation>
		</message>
		<message>
			<source>Function gw_fct_duplicate_psector executed with no result</source>
			<translation>Funkcja gw_fct_duplicate_psector wykonana bez rezultatu</translation>
		</message>
		<message>
			<source>Function gw_fct_psector_duplicate executed with no result</source>
			<translation>Funkcja gw_fct_psector_duplicate wykonana bez rezultatu</translation>
		</message>
		<message>
			<source>Function gw_fct_setfeaturedelete executed with no result </source>
			<translation>Funkcja gw_fct_setfeaturedelete została wykonana bez rezultatu</translation>
		</message>
		<message>
			<source>Function name</source>
			<translation>Nazwa funkcji</translation>
		</message>
		<message>
			<source>Function not found</source>
			<translation>Nie znaleziono funkcji</translation>
		</message>
		<message>
			<source>Function not found in database</source>
			<translation>Funkcja nie została znaleziona w bazie danych</translation>
		</message>
		<message>
			<source>Function not found in database: {0}</source>
			<translation>Funkcja nie została znaleziona w bazie danych: {0}</translation>
		</message>
		<message>
			<source>G. Boeing, </source>
			<translation>G. Boeing,</translation>
		</message>
		<message>
			<source>`gdf_edges` must be multi-indexed by `(u, v, key)`.</source>
			<translation>`gdf_edges` musi być indeksowane przez `(u, v, key)`.</translation>
		</message>
		<message>
			<source>`gdf` must have a valid CRS and cannot be empty.</source>
			<translation>`gdf` musi mieć poprawny CRS i nie może być pusty.</translation>
		</message>
		<message>
			<source>`gdf_nodes` and `gdf_edges` must each be uniquely indexed.</source>
			<translation>`gdf_nodes` i `gdf_edges` muszą być unikalnie indeksowane.</translation>
		</message>
		<message>
			<source>`gdf_nodes` must contain &apos;x&apos; and &apos;y&apos; columns.</source>
			<translation>`gdf_nodes` musi zawierać kolumny &apos;x&apos; i &apos;y&apos;.</translation>
		</message>
		<message>
			<source>Generating markdown for {0}.</source>
			<translation>Generowanie markdown dla {0}.</translation>
		</message>
		<message>
			<source>Generating markdown from {0}...</source>
			<translation>Generowanie markdown z {0}...</translation>
		</message>
		<message>
			<source>Generating result stats</source>
			<translation>Generowanie statystyk wyników</translation>
		</message>
		<message>
			<source>Generation of atlas uses v_edit_plan_psector as coverage layer ordered by atlas_id column. Please update the atlas&apos; coverage layer before continuing.</source>
			<translation>Generowanie atlasu wykorzystuje v_edit_plan_psector jako warstwę pokrycia uporządkowaną według kolumny atlas_id. Przed kontynuowaniem należy zaktualizować warstwę pokrycia atlasu.</translation>
		</message>
		<message>
			<source>Generation of atlas uses ve_plan_psector as coverage layer ordered by atlas_id column. Please update the atlas&apos; coverage layer before continuing.</source>
			<translation>Generowanie atlasu wykorzystuje ve_plan_psector jako warstwę pokrycia uporządkowaną według kolumny atlas_id. Przed kontynuowaniem należy zaktualizować warstwę pokrycia atlasu.</translation>
		</message>
		<message>
			<source>Geometry has been added!</source>
			<translation>Geometria została dodana!</translation>
		</message>
		<message>
			<source>Geometry must be a shapely Polygon or MultiPolygon.</source>
			<translation>Geometria musi być kształtem Polygon lub MultiPolygon.</translation>
		</message>
		<message>
			<source>Geometry must be a shapely Polygon or MultiPolygon. If you requested graph from place name, make sure your query resolves to a Polygon or MultiPolygon, and not some other geometry, like a Point. See OSMnx documentation for details.</source>
			<translation>Geometria musi być kształtem Polygon lub MultiPolygon. Jeśli zażądałeś wykresu z nazwy miejsca, upewnij się, że zapytanie rozwiązuje do Polygon lub MultiPolygon, a nie innej geometrii, takiej jak Point. Szczegółowe informacje można znaleźć w dokumentacji OSMnx.</translation>
		</message>
		<message>
			<source>Geometry set correctly.</source>
			<translation>Geometria ustawiona prawidłowo.</translation>
		</message>
		<message>
			<source>Geometry type ({0}) not found in layer: {1}</source>
			<translation>Nie znaleziono typu geometrii ({0}) w warstwie: {1}</translation>
		</message>
		<message>
			<source>`geom` must be a LineString.</source>
			<translation>`geom` musi być ciągiem LineString.</translation>
		</message>
		<message>
			<source>Getting {0} from .{1} file</source>
			<translation>Pobieranie {0} z pliku .{1}</translation>
		</message>
		<message>
			<source>Getting auxiliary data from DB</source>
			<translation>Pobieranie danych pomocniczych z bazy danych</translation>
		</message>
		<message>
			<source>Getting leak data from DB</source>
			<translation>Pobieranie danych o wyciekach z bazy danych</translation>
		</message>
		<message>
			<source>Getting pipe data from DB</source>
			<translation>Pobieranie danych potoku z bazy danych</translation>
		</message>
		<message>
			<source>`G` is a MultiDiGraph, so edge bearings will be directional (one per edge). If you want bidirectional edge bearings (two reciprocal bearings per edge), pass a MultiGraph instead. Use `convert.to_undirected`.</source>
			<translation>`G` jest MultiDiGraph, więc łożyska krawędzi będą kierunkowe (jedno na krawędź). Jeśli chcesz dwukierunkowych łożysk krawędzi (dwa wzajemne łożyska na krawędź), przekaż zamiast tego MultiGraph. Użyj `convert.to_undirected`.</translation>
		</message>
		<message>
			<source>GIS file generated successfully</source>
			<translation>Plik GIS wygenerowany pomyślnie</translation>
		</message>
		<message>
			<source>GIS file name not set</source>
			<translation>Nazwa pliku GIS nie została ustawiona</translation>
		</message>
		<message>
			<source>GIS folder not set</source>
			<translation>Folder GIS nie został ustawiony</translation>
		</message>
		<message>
			<source>Giswater executable file not found</source>
			<translation>Nie znaleziono pliku wykonywalnego Giswater</translation>
		</message>
		<message>
			<source>Giswater folder not found</source>
			<translation>Nie znaleziono folderu Giswater</translation>
		</message>
		<message>
			<source>Giswater plugin cannot be loaded</source>
			<translation>Nie można załadować wtyczki Giswater</translation>
		</message>
		<message>
			<source>GitHub Issues</source>
			<translation>Problemy GitHub</translation>
		</message>
		<message>
			<source>GLOBAL</source>
			<translation>GLOBALNY</translation>
		</message>
		<message>
			<source>Go2Epa</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>Go2Epa task is already active!</source>
			<translation>Zadanie Go2Epa jest już aktywne!</translation>
		</message>
		<message>
			<source>Go2Iber task is already active!</source>
			<translation>Zadanie Go2Iber jest już aktywne!</translation>
		</message>
		<message>
			<source>Graph contains no edges.</source>
			<translation>Graf nie zawiera krawędzi.</translation>
		</message>
		<message>
			<source>Graph contains no nodes.</source>
			<translation>Graf nie zawiera węzłów.</translation>
		</message>
		<message>
			<source>Graph must be unprojected to add edge bearings.</source>
			<translation>Wykres musi być nieprojektowany, aby dodać łożyska krawędzi.</translation>
		</message>
		<message>
			<source>Graph must be unprojected to analyze edge bearings.</source>
			<translation>Wykres musi być nieprojektowany, aby można było analizować położenie krawędzi.</translation>
		</message>
		<message>
			<source>Graph must be unsimplified to save as OSM XML.</source>
			<translation>Wykres musi być nieuproszczony, aby zapisać go jako OSM XML.</translation>
		</message>
		<message>
			<source>Graph nodes changed since `street_count`s were calculated</source>
			<translation>Węzły wykresu zmieniły się od czasu obliczenia `street_count`.</translation>
		</message>
		<message>
			<source>Graph should be unprojected to save as OSM XML: the existing projected x-y coordinates will be saved as lat-lon node attributes. Project your graph back to lat-lon to avoid this.</source>
			<translation>Aby zapisać wykres jako OSM XML, nie należy go rzutować: istniejące rzutowane współrzędne x-y zostaną zapisane jako atrybuty węzła lat-lon. Aby tego uniknąć, wyświetl wykres z powrotem w formacie lat-lon.</translation>
		</message>
		<message>
			<source>Group &apos;{0}&apos; not found in layer tree.</source>
			<translation>Grupa &apos;{0}&apos; nie została znaleziona w drzewie warstw.</translation>
		</message>
		<message>
			<source>`G` should be undirected to avoid oversampling bidirectional edges.</source>
			<translation>`G` powinno być nieukierunkowane, aby uniknąć nadpróbkowania dwukierunkowych krawędzi.</translation>
		</message>
		<message>
			<source>GSW file not found</source>
			<translation>Nie znaleziono pliku GSW</translation>
		</message>
		<message>
			<source>Gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>GULLY</source>
			<translation>GULLY</translation>
		</message>
		<message>
			<source>`Gu` must be undirected.</source>
			<translation>`Gu` musi być nieukierunkowana.</translation>
		</message>
		<message>
			<source>gw_fct_setlinktonetwork (Check log messages)</source>
			<translation>gw_fct_setlinktonetwork (Sprawdź komunikaty dziennika)</translation>
		</message>
		<message>
			<source>gw_fct_set_rpt_archived execution failed. See logs for more details...</source>
			<translation>Wykonanie gw_fct_set_rpt_archived nie powiodło się. Więcej informacji można znaleźć w dziennikach...</translation>
		</message>
		<message>
			<source>Gw Selectors: </source>
			<translation>Selekcjonerzy Gw:</translation>
		</message>
		<message>
			<source>Hemisphere of the node has been updated. Value is</source>
			<translation>Półkula węzła została zaktualizowana. Wartość to</translation>
		</message>
		<message>
			<source>Here you can choose how the pumps and valves will be imported, either left as arcs (virual arcs) or converted to nodes.</source>
			<translation>W tym miejscu można wybrać sposób importowania pomp i zaworów, pozostawiając je jako łuki (łuki wirtualne) lub konwertując na węzły.</translation>
		</message>
		<message>
			<source>Here you can choose how the pumps, weirs, orifices, and outlets will be imported, either left as arcs (virual arcs) or converted to flwreg.</source>
			<translation>W tym miejscu można wybrać sposób importowania pomp, jazów, kryz i wylotów, pozostawiając je jako łuki (łuki wirtualne) lub konwertując na flwreg.</translation>
		</message>
		<message>
			<source>{hostname!r} responded {response.status_code} {response.reason}: we&apos;ll retry in {error_pause} secs</source>
			<translation>{hostname!r} odpowiedział {response.status_code} {response.reason}: ponowimy próbę za {error_pause} sekund</translation>
		</message>
		<message>
			<source>{hostname!r} responded {response.status_code} {response.reason}: we&apos;ll retry in {this_pause} secs</source>
			<translation>{hostname!r} odpowiedział {response.status_code} {response.reason}: ponowimy próbę za {this_pause} sekund</translation>
		</message>
		<message>
			<source>Hydrology scenario manager</source>
			<translation>Menedżer scenariuszy hydrologicznych</translation>
		</message>
		<message>
			<source>IBERGIS plugin not found</source>
			<translation>Nie znaleziono wtyczki IBERGIS</translation>
		</message>
		<message>
			<source>IBERGIS project imported successfully</source>
			<translation>Projekt IBERGIS został pomyślnie zaimportowany</translation>
		</message>
		<message>
			<source>Id already selected</source>
			<translation>Identyfikator już wybrany</translation>
		</message>
		<message>
			<source>Identify all</source>
			<translation>Identify all</translation>
		</message>
		<message>
			<source>Identifying all nodes that lie outside the polygon...</source>
			<translation>Identyfikacja wszystkich węzłów leżących poza wielokątem...</translation>
		</message>
		<message>
			<source>If not, you can ignore the tab.</source>
			<translation>Jeśli nie, możesz zignorować zakładkę.</translation>
		</message>
		<message>
			<source>If you chose to import the flow regulators as flwreg objects, the sixth tab is where you can select the catalog for each flow regulator (pumps, weirs, orifices, outlets) on the network.</source>
			<translation>Jeśli wybrano importowanie regulatorów przepływu jako obiektów flwreg, w szóstej zakładce można wybrać katalog dla każdego regulatora przepływu (pompy, jazy, kryzy, wyloty) w sieci.</translation>
		</message>
		<message>
			<source>If you have any questions, please contact the Giswater team via</source>
			<translation>W razie jakichkolwiek pytań prosimy o kontakt z zespołem Giswater poprzez</translation>
		</message>
		<message>
			<source> If you have different addfields in your feature, they will be deleted.</source>
			<translation> Jeśli w funkcji znajdują się różne pola dodatkowe, zostaną one usunięte.</translation>
		</message>
		<message>
			<source>Ignoring cache file {str(cache_filepath)!r} because it contains a remark: {response_json[&apos;remark&apos;]!r}</source>
			<translation>Ignorowanie pliku pamięci podręcznej {str(cache_filepath)!r}, ponieważ zawiera uwagę: {response_json[&apos;remark&apos;]!r}</translation>
		</message>
		<message>
			<source>Import failed</source>
			<translation>Import nie powiódł się</translation>
		</message>
		<message>
			<source>IMPORT INP</source>
			<translation>IMPORT INP</translation>
		</message>
		<message>
			<source>Import INP is only available on Python 3.10 or higher. Please update your QGIS&apos;s Python version.</source>
			<translation>Import INP jest dostępny tylko w wersji Python 3.10 lub nowszej. Zaktualizuj wersję Pythona w QGIS.</translation>
		</message>
		<message>
			<source>Import INP is still in developement. It may not work as intended yet. Please report any unexpected behaviour to the Giswater team.</source>
			<translation>Import INP jest wciąż w fazie rozwoju. Może jeszcze nie działać zgodnie z przeznaczeniem. Prosimy o zgłaszanie wszelkich nieoczekiwanych zachowań do zespołu Giswater.</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis is only available on Python 3.10 or higher. </source>
			<translation>Import OSM Streetaxis jest dostępny tylko w Pythonie 3.10 lub nowszym.</translation>
		</message>
		<message>
			<source>Import OSM Streetaxis its only for WS projects</source>
			<translation>Importuj OSM Streetaxis tylko dla projektów WS</translation>
		</message>
		<message>
			<source>Import RPT file</source>
			<translation>Import pliku RPT</translation>
		</message>
		<message>
			<source>Import rpt file........: {0}</source>
			<translation>Importuj plik rpt........: {0}</translation>
		</message>
		<message>
			<source>Import RPT file finished.</source>
			<translation>Import pliku RPT zakończony.</translation>
		</message>
		<message>
			<source>Incompatible version of PostgreSQL</source>
			<translation>Niekompatybilna wersja PostgreSQL</translation>
		</message>
		<message>
			<source>Incorrect languages, make sure to have the giswater project in english</source>
			<translation>Nieprawidłowe języki, upewnij się, że projekt giswater jest w języku angielskim</translation>
		</message>
		<message>
			<source>Incorrect user or password</source>
			<translation>Nieprawidłowy użytkownik lub hasło</translation>
		</message>
		<message>
			<source>Info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>Info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>Info Message</source>
			<translation>Komunikat informacyjny</translation>
		</message>
		<message>
			<source>Information about exception</source>
			<translation>Informacje o wyjątku</translation>
		</message>
		<message>
			<source>Initialize plugin</source>
			<translation>Inicjalizacja wtyczki</translation>
		</message>
		<message>
			<source>In order to create a qgis project you have to create a schema first .</source>
			<translation>Aby utworzyć projekt qgis, należy najpierw utworzyć schemat.</translation>
		</message>
		<message>
			<source>In order to create a qgis project you have to create a schema first.</source>
			<translation>Aby utworzyć projekt qgis, należy najpierw utworzyć schemat.</translation>
		</message>
		<message>
			<source>INP file couldn&apos;t be imported:</source>
			<translation>Plik INP nie mógł zostać zaimportowany:</translation>
		</message>
		<message>
			<source>INP file couldn&apos;t be imported:\n{0}</source>
			<translation>Plik INP nie mógł zostać zaimportowany: \n{0}</translation>
		</message>
		<message>
			<source>INP file not found</source>
			<translation>Nie znaleziono pliku INP</translation>
		</message>
		<message>
			<source>Inp Options</source>
			<translation>Opcje Inp</translation>
		</message>
		<message>
			<source>In schema</source>
			<translation>W schemacie</translation>
		</message>
		<message>
			<source>Interpolate tool.</source>
			<translation>Narzędzie interpolacji.</translation>
		</message>
		<message>
			<source>Interpolate tool.\nTo modify columns (top_elev, ymax, elev among others) to be interpolated set variable edit_node_interpolate on table config_param_user</source>
			<translation>Interpolate tool.\nAby zmodyfikować kolumny (m.in. top_elev, ymax, elev), które mają być interpolowane, ustaw zmienną edit_node_interpolate w tabeli config_param_user.</translation>
		</message>
		<message>
			<source>Interrupted because `settings.cache_only_mode=True`.</source>
			<translation>Przerwano, ponieważ `settings.cache_only_mode=True`.</translation>
		</message>
		<message>
			<source>Invalid {0} &apos;{1}&apos; provided. No configuration performed.</source>
			<translation>Podano nieprawidłowe {0} &apos;{1}&apos;. Nie przeprowadzono konfiguracji.</translation>
		</message>
		<message>
			<source>Invalid arccat_ids: {0}.</source>
			<translation>Nieprawidłowy arccat_ids: {0}.</translation>
		</message>
		<message>
			<source>Invalid arccat_ids: {1}.</source>
			<translation>Nieprawidłowy arccat_ids: {1}.</translation>
		</message>
		<message>
			<source>Invalid arccat_ids: {list}.</source>
			<translation>Nieprawidłowy arccat_ids: {list}.</translation>
		</message>
		<message>
			<source>Invalid buffer value. Please enter an integer less than 1000.</source>
			<translation>Nieprawidłowa wartość bufora. Wprowadź liczbę całkowitą mniejszą niż 1000.</translation>
		</message>
		<message>
			<source>Invalid buffer value. Please enter an valid integer.</source>
			<translation>Nieprawidłowa wartość bufora. Wprowadź prawidłową liczbę całkowitą.</translation>
		</message>
		<message>
			<source>Invalid campaign ID.</source>
			<translation>Nieprawidłowy identyfikator kampanii.</translation>
		</message>
		<message>
			<source>Invalid campaign ID.</source>
			<translation>Invalid campaign ID.</translation>
		</message>
		<message>
			<source>Invalid campaign mode</source>
			<translation>Invalid campaign mode</translation>
		</message>
		<message>
			<source>Invalid compliance value for diameter</source>
			<translation>Nieprawidłowa wartość zgodności dla średnicy</translation>
		</message>
		<message>
			<source>Invalid compliance value for material</source>
			<translation>Nieprawidłowa wartość zgodności dla materiału</translation>
		</message>
		<message>
			<source>Invalid diameters: {1}.</source>
			<translation>Nieprawidłowe średnice: {1}.</translation>
		</message>
		<message>
			<source>Invalid diameters: {list}.</source>
			<translation>Nieprawidłowe średnice: {list}.</translation>
		</message>
		<message>
			<source>Invalid lot ID.</source>
			<translation>Nieprawidłowy identyfikator partii.</translation>
		</message>
		<message>
			<source>Invalid lot ID.</source>
			<translation>Invalid lot ID.</translation>
		</message>
		<message>
			<source>Invalid materials: {3}.</source>
			<translation>Nieprawidłowe materiały: {3}.</translation>
		</message>
		<message>
			<source>Invalid materials: {list}.</source>
			<translation>Nieprawidłowe materiały: {list}.</translation>
		</message>
		<message>
			<source>Invalid value for field</source>
			<translation>Nieprawidłowa wartość dla pola</translation>
		</message>
		<message>
			<source>Invalid value for scenario_results in [OPTIONS] section.</source>
			<translation>Nieprawidłowa wartość dla scenario_results w sekcji [OPTIONS].</translation>
		</message>
		<message>
			<source>Invalid value for type of priority dialog. Please pass either &apos;GLOBAL&apos; or &apos;SELECTION&apos;. Value passed:</source>
			<translation>Nieprawidłowa wartość dla typu okna dialogowego priorytetu. Podaj wartość &quot;GLOBAL&quot; lub &quot;SELECTION&quot;. Przekazana wartość:</translation>
		</message>
		<message>
			<source>Invalid WKT string</source>
			<translation>Nieprawidłowy ciąg WKT</translation>
		</message>
		<message>
			<source>Invalid workorder ID.</source>
			<translation>Invalid workorder ID.</translation>
		</message>
		<message>
			<source>Invalid workorder ID.</source>
			<translation>Nieprawidłowy identyfikator zlecenia.</translation>
		</message>
		<message>
			<source>INVENTORY</source>
			<translation>INWENTARYZACJA</translation>
		</message>
		<message>
			<source>Inventory Example</source>
			<translation>Inventory Example</translation>
		</message>
		<message>
			<source>is not defined in table cat_feature</source>
			<translation>nie jest zdefiniowana w tabeli cat_feature</translation>
		</message>
		<message>
			<source>It will then show the log of the process in the last tab.</source>
			<translation>Następnie wyświetli dziennik procesu w ostatniej zakładce.</translation>
		</message>
		<message>
			<source>IVI</source>
			<translation>IVI</translation>
		</message>
		<message>
			<source>Java executable file not found</source>
			<translation>Nie znaleziono pliku wykonywalnego Java</translation>
		</message>
		<message>
			<source>Java folder not found</source>
			<translation>Nie znaleziono folderu Java</translation>
		</message>
		<message>
			<source>Java Runtime executable file not found</source>
			<translation>Nie znaleziono pliku wykonywalnego środowiska Java Runtime</translation>
		</message>
		<message>
			<source>KEEP OPERATIVE</source>
			<translation>ZACHOWAJ FUNKCJONALNOŚĆ</translation>
		</message>
		<message>
			<source>Key</source>
			<translation>Klucz</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE columname=&apos;{0}&apos; AND </source>
			<translation>key &apos;comboIds&apos; or/and comboNames not found WHERE columname=&apos;{0}&apos; AND</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE columname=&apos;{0}&apos; AND widgetname=&apos;{1}&apos;</source>
			<translation>key &apos;comboIds&apos; or/and comboNames not found WHERE columname=&apos;{0}&apos; AND widgetname=&apos;{1}&apos;</translation>
		</message>
		<message>
			<source>key &apos;comboIds&apos; or/and comboNames not found WHERE widgetname=&apos;{0}&apos; AND widgettype=&apos;{1}&apos;</source>
			<translation>key &apos;comboIds&apos; or/and comboNames not found WHERE widgetname=&apos;{0}&apos; AND widgettype=&apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Key container</source>
			<translation>Kluczowy pojemnik</translation>
		</message>
		<message>
			<source>Key not found</source>
			<translation>Nie znaleziono klucza</translation>
		</message>
		<message>
			<source>Key not found: &apos;{0}&apos;</source>
			<translation>Nie znaleziono klucza: &quot;{0}</translation>
		</message>
		<message>
			<source>Key on returned json from ddbb is missed</source>
			<translation>Brak klucza w pliku json zwróconym z ddbb</translation>
		</message>
		<message>
			<source>Key on returned json from ddbb is missed.</source>
			<translation>Brak klucza w zwróconym pliku json z ddbb.</translation>
		</message>
		<message>
			<source>Language</source>
			<translation>Język</translation>
		</message>
		<message>
			<source>Language: {self.project_language}</source>
			<translation>Język: {self.project_language}</translation>
		</message>
		<message>
			<source>Layer {0} does not found, therefore, not configured</source>
			<translation>Warstwa {0} nie została znaleziona, dlatego nie została skonfigurowana.</translation>
		</message>
		<message>
			<source>Layer &apos;{0}&apos; is None and settings is None</source>
			<translation>Warstwa &apos;{0}&apos; to Brak, a ustawienia to Brak</translation>
		</message>
		<message>
			<source>Layer &apos;{0}&apos; not found in QGIS.</source>
			<translation>Warstwa &apos;{0}&apos; nie została znaleziona w QGIS.</translation>
		</message>
		<message>
			<source>Layer failed to load!</source>
			<translation>Nie udało się załadować warstwy!</translation>
		</message>
		<message>
			<source>Layer is broken</source>
			<translation>Warstwa jest uszkodzona</translation>
		</message>
		<message>
			<source>Layer not found</source>
			<translation>Nie znaleziono warstwy</translation>
		</message>
		<message>
			<source>Layer of CM project will be added to the project when create</source>
			<translation>Layer of CM project will be added to the project when create</translation>
		</message>
		<message>
			<source>Layers of your role not found</source>
			<translation>Nie znaleziono warstw roli użytkownika</translation>
		</message>
		<message>
			<source>Layout not found</source>
			<translation>Nie znaleziono układu</translation>
		</message>
		<message>
			<source>layoutorder not found.</source>
			<translation>Nie znaleziono układu.</translation>
		</message>
		<message>
			<source>Leak Assignation</source>
			<translation>Przypisanie wycieku</translation>
		</message>
		<message>
			<source>Leaks assigned by diameter only: {leaks}.</source>
			<translation>Nieszczelności przypisane tylko według średnicy: {nieszczelności}.</translation>
		</message>
		<message>
			<source>Leaks assigned by material and diameter: {leaks}.</source>
			<translation>Nieszczelności przypisane według materiału i średnicy: {nieszczelności}.</translation>
		</message>
		<message>
			<source>Leaks assigned by material only: {leaks}.</source>
			<translation>Wycieki przypisane tylko według materiału: {wycieki}.</translation>
		</message>
		<message>
			<source>Leaks assigned to any nearby pipes: {leaks}.</source>
			<translation>Wycieki przypisane do pobliskich rur: {przecieki}.</translation>
		</message>
		<message>
			<source>Leaks within the indicated period: {leaks}.</source>
			<translation>Wycieki we wskazanym okresie: {leaks}.</translation>
		</message>
		<message>
			<source>Leaks without pipes intersecting its buffer: {leaks}.</source>
			<translation>Wycieki bez rur przecinających jego bufor: {przecieki}.</translation>
		</message>
		<message>
			<source>levels</source>
			<translation>levels</translation>
		</message>
		<message>
			<source>LIDS</source>
			<translation>LIDS</translation>
		</message>
		<message>
			<source>Line number</source>
			<translation>Numer linii</translation>
		</message>
		<message>
			<source>Link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>LINK</source>
			<translation>LINK</translation>
		</message>
		<message>
			<source>Load all</source>
			<translation>Load all</translation>
		</message>
		<message>
			<source>.*loadtxt: input contained no data*</source>
			<translation>.*loadtxt: wejście nie zawierało danych*</translation>
		</message>
		<message>
			<source>Locale gis folder not found</source>
			<translation>Nie znaleziono lokalnego folderu gis</translation>
		</message>
		<message>
			<source>Locale not found</source>
			<translation>Nie znaleziono lokalizacji</translation>
		</message>
		<message>
			<source>Locale not found ({0})</source>
			<translation>Nie znaleziono ustawień regionalnych ({0})</translation>
		</message>
		<message>
			<source>Log file</source>
			<translation>Plik dziennika</translation>
		</message>
		<message>
			<source>Lot ID is missing.</source>
			<translation>Brak identyfikatora partii.</translation>
		</message>
		<message>
			<source>Make sure graph was created with `ox.settings.all_oneway=True` to save as OSM XML.</source>
			<translation>Upewnij się, że wykres został utworzony z `ox.settings.all_oneway=True`, aby zapisać go jako OSM XML.</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please</source>
			<translation>Brakuje pola obowiązkowego. Ustaw wartość</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please, set a value</source>
			<translation>Brakuje pola obowiązkowego. Proszę, ustaw wartość</translation>
		</message>
		<message>
			<source>Mandatory field is missing. Please, set a value for field</source>
			<translation>Brakuje pola obowiązkowego. Proszę, ustaw wartość dla pola</translation>
		</message>
		<message>
			<source>MAP ZONES</source>
			<translation>STREFY NA MAPIE</translation>
		</message>
		<message>
			<source>Mapzones analysis completed successfully.</source>
			<translation>Analiza Mapzones zakończona pomyślnie.</translation>
		</message>
		<message>
			<source>Markdown Generated from {0}.</source>
			<translation>Markdown wygenerowany z {0}.</translation>
		</message>
		<message>
			<source>Marked values must be greater than 0</source>
			<translation>Zaznaczone wartości muszą być większe niż 0</translation>
		</message>
		<message>
			<source>MASTERPLAN</source>
			<translation>MASTERPLAN</translation>
		</message>
		<message>
			<source>Material</source>
			<translation>Materiał</translation>
		</message>
		<message>
			<source>Matplotlib cannot be installed automatically. Please install Matplotlib manually.</source>
			<translation>Matplotlib nie może zostać zainstalowany automatycznie. Należy zainstalować Matplotlib ręcznie.</translation>
		</message>
		<message>
			<source>Matplotlib installed successfully. Please restart QGIS.</source>
			<translation>Matplotlib został pomyślnie zainstalowany. Uruchom ponownie QGIS.</translation>
		</message>
		<message>
			<source>matplotlib must be installed as an optional dependency for visualization.</source>
			<translation>matplotlib musi być zainstalowany jako opcjonalna zależność do wizualizacji.</translation>
		</message>
		<message>
			<source>Matplotlib Python package not found. Do you want to install Matplotlib?</source>
			<translation>Nie znaleziono pakietu Matplotlib Python. Czy chcesz zainstalować Matplotlib?</translation>
		</message>
		<message>
			<source>Max. Longevity</source>
			<translation>Maks. Długowieczność</translation>
		</message>
		<message>
			<source>Max rleak: {rleak} leaks/km.year.</source>
			<translation>Maksymalny wyciek: {rleak} wycieków/km.rok.</translation>
		</message>
		<message>
			<source>Med. Longevity</source>
			<translation>Med. Długowieczność</translation>
		</message>
		<message>
			<source>Merge requires at least 2 psectors to be selected</source>
			<translation>Merge requires at least 2 psectors to be selected</translation>
		</message>
		<message>
			<source>Message</source>
			<translation>Wiadomość</translation>
		</message>
		<message>
			<source>Message error</source>
			<translation>Błąd komunikatu</translation>
		</message>
		<message>
			<source>Metadata file not found</source>
			<translation>Nie znaleziono pliku metadanych</translation>
		</message>
		<message>
			<source>Method of calculation not defined in configuration file. Please check config file.</source>
			<translation>Metoda obliczeń nie została zdefiniowana w pliku konfiguracyjnym. Sprawdź plik konfiguracyjny.</translation>
		</message>
		<message>
			<source>MINCUT</source>
			<translation>MINCUT</translation>
		</message>
		<message>
			<source>Mincut canceled!</source>
			<translation>Mincut canceled!</translation>
		</message>
		<message>
			<source>Mincut done</source>
			<translation>Mincut wykonany, ale ma konflikt i pokrywa się z</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict and overlaps with</source>
			<translation>Mincut wykonany, ale ma konflikt i pokrywa się z</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict and overlaps with other mincuts</source>
			<translation>Mincut done, but has conflict and overlaps with other mincuts</translation>
		</message>
		<message>
			<source>Mincut done, but has conflict. Take a look on the anl_arc and anl_node to see the details of the conflict</source>
			<translation>Mincut wykonany, ale ma konflikt. Spójrz na anl_arc i anl_node, aby zobaczyć szczegóły konfliktu</translation>
		</message>
		<message>
			<source>Mincut done successfully</source>
			<translation>Mincut wykonany pomyślnie</translation>
		</message>
		<message>
			<source>Mincut task is already active!</source>
			<translation>Zadanie Mincut jest już aktywne!</translation>
		</message>
		<message>
			<source>Min. Longevity</source>
			<translation>Min. Długowieczność</translation>
		</message>
		<message>
			<source>...min_message_level</source>
			<translation>...min_message_level</translation>
		</message>
		<message>
			<source>Min non-zero rleak: {rleak} leaks/km.year.</source>
			<translation>Min. niezerowy wyciek: {rleak} wycieków/km.rok.</translation>
		</message>
		<message>
			<source>Missing Data</source>
			<translation>Brakujące dane</translation>
		</message>
		<message>
			<source>Missing required fields</source>
			<translation>Brakujące wymagane pola</translation>
		</message>
		<message>
			<source>Missing required fields</source>
			<translation>Missing required fields</translation>
		</message>
		<message>
			<source> ... (more hidden) ...</source>
			<translation> ... (więcej ukrytych) ...</translation>
		</message>
		<message>
			<source>More than one feature selected. Only the first one will be processed!</source>
			<translation>Wybrano więcej niż jedną funkcję. Przetworzona zostanie tylko pierwsza z nich!</translation>
		</message>
		<message>
			<source>More then one document selected. Select just one document.</source>
			<translation>Wybrano więcej niż jeden dokument. Wybierz tylko jeden dokument.</translation>
		</message>
		<message>
			<source>More then one event selected. Select just one</source>
			<translation>Wybrano więcej niż jedno wydarzenie. Wybierz tylko jedno</translation>
		</message>
		<message>
			<source>Move node: Error updating geometry</source>
			<translation>Przenieś węzeł: Błąd aktualizacji geometrii</translation>
		</message>
		<message>
			<source>Multiple psectors selected. Please select only one.</source>
			<translation>Wybrano wiele sektorów. Wybierz tylko jeden.</translation>
		</message>
		<message>
			<source>Municipality with ID: {0} deleted from selection</source>
			<translation>Gmina o ID: {0} usunięta z wyboru</translation>
		</message>
		<message>
			<source>Municipality with id[{0}] is already imported on om_streetaxis.</source>
			<translation>Gmina o id[{0}] jest już zaimportowana w om_streetaxis.</translation>
		</message>
		<message>
			<source>Municipality with id[{0}] is already imported on om_streetaxis.\n\rDo you want to overwrite it?\n\r(This decision will not cancel the other selections, the process will keep running)</source>
			<translation>Gmina o id[{0}] jest już zaimportowana do om_streetaxis.\n\r Czy chcesz ją nadpisać? \n\r (ta decyzja nie anuluje innych wyborów, proces będzie kontynuowany).</translation>
		</message>
		<message>
			<source>\n</source>
			<translation>\n</translation>
		</message>
		<message>
			<source>Name</source>
			<translation>Name</translation>
		</message>
		<message>
			<source>Name, description and code are required fields</source>
			<translation>Nazwa, opis i kod są polami wymaganymi</translation>
		</message>
		<message>
			<source>NETSCENARIO</source>
			<translation>NETSCENARIO</translation>
		</message>
		<message>
			<source>NETWORK</source>
			<translation>SIEĆ</translation>
		</message>
		<message>
			<source>Newest leak</source>
			<translation>Najnowszy wyciek</translation>
		</message>
		<message>
			<source>New feature type is null. Please</source>
			<translation>Nowy typ funkcji ma wartość null. Wybierz prawidłową wartość</translation>
		</message>
		<message>
			<source>New feature type is null. Please, select a valid value</source>
			<translation>Nowy typ funkcji ma wartość null. Wybierz prawidłową wartość</translation>
		</message>
		<message>
			<source>New feature type is null. Please, select a valid value.</source>
			<translation>Nowy typ funkcji ma wartość null. Wybierz prawidłową wartość.</translation>
		</message>
		<message>
			<source>New value</source>
			<translation>Nowa wartość</translation>
		</message>
		<message>
			<source>Next</source>
			<translation>Następny</translation>
		</message>
		<message>
			<source>No action found</source>
			<translation>Nie znaleziono żadnych działań</translation>
		</message>
		<message>
			<source>No campaign selected.</source>
			<translation>No campaign selected.</translation>
		</message>
		<message>
			<source>No campaign selected.</source>
			<translation>Nie wybrano żadnej kampanii.</translation>
		</message>
		<message>
			<source>No composers found.</source>
			<translation>Nie znaleziono kompozytorów.</translation>
		</message>
		<message>
			<source>No current netscenario</source>
			<translation>Brak aktualnego scenariusza sieciowego</translation>
		</message>
		<message>
			<source>No current psector selected</source>
			<translation>Nie wybrano aktualnego sektora</translation>
		</message>
		<message>
			<source>No data elements in server response. Check query location/filters and log.</source>
			<translation>Brak elementów danych w odpowiedzi serwera. Sprawdź lokalizację zapytania/filtry i dziennik.</translation>
		</message>
		<message>
			<source>Node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>NODE</source>
			<translation>NODE</translation>
		</message>
		<message>
			<source>Node 1 selected</source>
			<translation>Wybrano węzeł 1</translation>
		</message>
		<message>
			<source>Node already selected</source>
			<translation>Węzeł już wybrany</translation>
		</message>
		<message>
			<source>Node deleted successfully</source>
			<translation>Węzeł usunięty pomyślnie</translation>
		</message>
		<message>
			<source>Node id:</source>
			<translation>Identyfikator węzła:</translation>
		</message>
		<message>
			<source>Node psector: {0}</source>
			<translation>Node psector: {0}</translation>
		</message>
		<message>
			<source>Node replaced successfully</source>
			<translation>Węzeł zastąpiony pomyślnie</translation>
		</message>
		<message>
			<source>Node set correctly</source>
			<translation>Node set correctly</translation>
		</message>
		<message>
			<source>Node type has been updated!</source>
			<translation>Typ węzła został zaktualizowany!</translation>
		</message>
		<message>
			<source>No document selected.</source>
			<translation>Nie wybrano żadnego dokumentu.</translation>
		</message>
		<message>
			<source>No event provided for point selection</source>
			<translation>No event provided for point selection</translation>
		</message>
		<message>
			<source>No features found in the selection for {0}.</source>
			<translation>No features found in the selection for {0}.</translation>
		</message>
		<message>
			<source>No features found in the selection for the enabled tabs ({0}).</source>
			<translation>No features found in the selection for the enabled tabs ({0}).</translation>
		</message>
		<message>
			<source>NO FEATURE TYPE DEFINED</source>
			<translation>NIE ZDEFINIOWANO TYPU FUNKCJI</translation>
		</message>
		<message>
			<source>No function associated to</source>
			<translation>Brak funkcji powiązanej z</translation>
		</message>
		<message>
			<source>No help file found</source>
			<translation>Nie znaleziono pliku pomocy</translation>
		</message>
		<message>
			<source>No listValues for</source>
			<translation>Brak listValues dla</translation>
		</message>
		<message>
			<source>No matching features. Check query location, tags, and log.</source>
			<translation>Brak pasujących funkcji. Sprawdź lokalizację zapytania, tagi i dziennik.</translation>
		</message>
		<message>
			<source>Nominatim API did not return a list of results.</source>
			<translation>Interfejs API Nominatim nie zwrócił listy wyników.</translation>
		</message>
		<message>
			<source>Nominatim `request_type` must be &apos;search&apos;, &apos;reverse&apos;, or &apos;lookup&apos;.</source>
			<translation>Nominatim `request_type` musi być &apos;search&apos;, &apos;reverse&apos; lub &apos;lookup&apos;.</translation>
		</message>
		<message>
			<source>No municipalities selected</source>
			<translation>Nie wybrano żadnych gmin</translation>
		</message>
		<message>
			<source>None</source>
			<translation>None</translation>
		</message>
		<message>
			<source>No new features to insert. All selected features already exist in the table.</source>
			<translation>No new features to insert. All selected features already exist in the table.</translation>
		</message>
		<message>
			<source>No node ID found at the snapped location.</source>
			<translation>Nie znaleziono identyfikatora węzła w przyciągniętej lokalizacji.</translation>
		</message>
		<message>
			<source>No parameters found in section {0}</source>
			<translation>Nie znaleziono parametrów w sekcji {0}</translation>
		</message>
		<message>
			<source>No pictures for this event.</source>
			<translation>Brak zdjęć z tego wydarzenia.</translation>
		</message>
		<message>
			<source>No pipes found matching your budget.</source>
			<translation>Nie znaleziono rur pasujących do budżetu.</translation>
		</message>
		<message>
			<source>No pipes found matching your selected filters.</source>
			<translation>Nie znaleziono rur pasujących do wybranych filtrów.</translation>
		</message>
		<message>
			<source>No primary key value set</source>
			<translation>Nie ustawiono wartości klucza głównego</translation>
		</message>
		<message>
			<source>No psector selected. Please select at least one.</source>
			<translation>Nie wybrano sektora. Wybierz co najmniej jeden.</translation>
		</message>
		<message>
			<source>No psector values</source>
			<translation>Brak wartości sektorowych</translation>
		</message>
		<message>
			<source>No records found with selected &apos;result_id&apos;</source>
			<translation>Nie znaleziono rekordów z wybranym &apos;result_id&apos;</translation>
		</message>
		<message>
			<source>No records selected</source>
			<translation>No records selected</translation>
		</message>
		<message>
			<source>No records selected</source>
			<translation>Nie wybrano żadnych rekordów</translation>
		</message>
		<message>
			<source>No results</source>
			<translation>Brak wyników</translation>
		</message>
		<message>
			<source>No results found. Please check values set on selector of state and exploitation</source>
			<translation>Nie znaleziono wyników. Sprawdź wartości ustawione w selektorze stanu i eksploatacji</translation>
		</message>
		<message>
			<source>No sector selected. Please select at least one.</source>
			<translation>Nie wybrano żadnego sektora. Wybierz co najmniej jeden.</translation>
		</message>
		<message>
			<source>No snapshots available. Please create a snapshot first or wait for tomorrow to travel since today.</source>
			<translation>Migawki nie są dostępne. Utwórz najpierw migawkę lub poczekaj do jutra, aby podróżować od dzisiaj.</translation>
		</message>
		<message>
			<source>No SQL context available.</source>
			<translation>Brak dostępnego kontekstu SQL.</translation>
		</message>
		<message>
			<source>Not &apos;{0}&apos;</source>
			<translation>Nie &quot;{0}</translation>
		</message>
		<message>
			<source>Note: You can force the import by activating the variable &apos;{0}&apos; on the {1} file. </source>
			<translation>Uwaga: Import można wymusić aktywując zmienną &quot;{0}&quot; w pliku {1}.</translation>
		</message>
		<message>
			<source>Not found: {0}</source>
			<translation>Nie znaleziono: {0}</translation>
		</message>
		<message>
			<source>No valid data received from the SQL function.</source>
			<translation>Brak prawidłowych danych odebranych z funkcji SQL.</translation>
		</message>
		<message>
			<source>No valid mapzones with values were found to apply styles.</source>
			<translation>Nie znaleziono prawidłowych stref map z wartościami do zastosowania stylów.</translation>
		</message>
		<message>
			<source>No valid psector IDs found</source>
			<translation>Nie znaleziono prawidłowych identyfikatorów sektorów</translation>
		</message>
		<message>
			<source>No valid snapping result. Please select a valid point.</source>
			<translation>Brak prawidłowego wyniku przyciągania. Wybierz prawidłowy punkt.</translation>
		</message>
		<message>
			<source>No visit values</source>
			<translation>Brak wartości wizyt</translation>
		</message>
		<message>
			<source>No workcat values</source>
			<translation>Brak wartości workcat</translation>
		</message>
		<message>
			<source>Number of features selected in the group of</source>
			<translation>Liczba funkcji wybranych w grupie</translation>
		</message>
		<message>
			<source>Number of SQL files &apos;{0}&apos;: {1}</source>
			<translation>Liczba plików SQL &quot;{0}&quot;: {1}</translation>
		</message>
		<message>
			<source>Number of SQL files &apos;TOTAL&apos;: {0}</source>
			<translation>Liczba plików SQL &quot;TOTAL&quot;: {0}</translation>
		</message>
		<message>
			<source>Object already associated with this feature</source>
			<translation>Obiekt już powiązany z tą funkcją</translation>
		</message>
		<message>
			<source>Object id not found</source>
			<translation>Nie znaleziono identyfikatora obiektu</translation>
		</message>
		<message>
			<source>Oldest leak</source>
			<translation>Najstarszy wyciek</translation>
		</message>
		<message>
			<source>Old value</source>
			<translation>Stara wartość</translation>
		</message>
		<message>
			<source>OM</source>
			<translation>OM</translation>
		</message>
		<message>
			<source>Once you have configured all the necessary catalogs, you can click on the &apos;Accept&apos; button to start the import process.</source>
			<translation>Po skonfigurowaniu wszystkich niezbędnych katalogów można kliknąć przycisk &quot;Akceptuj&quot;, aby rozpocząć proces importu.</translation>
		</message>
		<message>
			<source>Only FRELEM can be added to dscenario</source>
			<translation>Tylko FRELEM może być dodany do dscenario</translation>
		</message>
		<message>
			<source>Only one record can be selected</source>
			<translation>Można wybrać tylko jeden rekord</translation>
		</message>
		<message>
			<source>Only rows with values are allowed to be deleted.</source>
			<translation>Tylko wiersze z wartościami mogą zostać usunięte.</translation>
		</message>
		<message>
			<source>On tab workcat set details of changing features to obsolete, on tab relations select affected features</source>
			<translation>W zakładce workcat ustaw szczegóły zmiany cech na przestarzałe, w zakładce relacje wybierz cechy, których to dotyczy.</translation>
		</message>
		<message>
			<source>On the other hand you must know that traceability table will storage precedent information.</source>
			<translation>Z drugiej strony musisz wiedzieć, że tabela identyfikowalności będzie przechowywać precedensowe informacje.</translation>
		</message>
		<message>
			<source>or</source>
			<translation>lub</translation>
		</message>
		<message>
			<source>`orig` and `dest` must be of equal length.</source>
			<translation>`orig` i `dest` muszą być równej długości.</translation>
		</message>
		<message>
			<source>`orig` and `dest` must either both be iterable or neither must be iterable.</source>
			<translation>`orig` i `dest` muszą być albo iterowalne, albo żadne z nich nie może być iterowalne.</translation>
		</message>
		<message>
			<source>or they were created by another user:</source>
			<translation>lub zostały utworzone przez innego użytkownika:</translation>
		</message>
		<message>
			<source>OTHER</source>
			<translation>INNE</translation>
		</message>
		<message>
			<source>our website</source>
			<translation>nasza strona internetowa</translation>
		</message>
		<message>
			<source>Overpass API did not return a dict of results.</source>
			<translation>Interfejs API Overpass nie zwrócił listy wyników.</translation>
		</message>
		<message>
			<source>Overwrite</source>
			<translation>Nadpisywanie</translation>
		</message>
		<message>
			<source>Overwrite file</source>
			<translation>Nadpisywanie pliku</translation>
		</message>
		<message>
			<source>Overwrite values</source>
			<translation>Nadpisywanie wartości</translation>
		</message>
		<message>
			<source>Overwriting cache for %s %s</source>
			<translation>Nadpisywanie pamięci podręcznej dla %s %s</translation>
		</message>
		<message>
			<source>Page not found.</source>
			<translation>Nie znaleziono strony.</translation>
		</message>
		<message>
			<source>Parameter &apos;{0}&apos; is None</source>
			<translation>Parametr &quot;{0}&quot; ma wartość Brak</translation>
		</message>
		<message>
			<source>Parameter button_function is null for button</source>
			<translation>Parametr button_function ma wartość null dla przycisku</translation>
		</message>
		<message>
			<source>Parameter functionName is null for button</source>
			<translation>Parametr functionName ma wartość null dla przycisku</translation>
		</message>
		<message>
			<source>Parameter functionName is null for check</source>
			<translation>Parametr functionName ma wartość null dla sprawdzenia</translation>
		</message>
		<message>
			<source>Parameter not found</source>
			<translation>Nie znaleziono parametru</translation>
		</message>
		<message>
			<source>Parameter not found: {parameter}</source>
			<translation>Nie znaleziono parametru: {parameter}</translation>
		</message>
		<message>
			<source>Parameter &apos;Query text:&apos; is mandatory for &apos;combo&apos; widgets. Please set value.</source>
			<translation>Parametr &quot;Query text:&quot; jest obowiązkowy dla widżetów &quot;combo&quot;. Należy ustawić wartość.</translation>
		</message>
		<message>
			<source>Parameters related with &apos;searchplus&apos; not set in table &apos;config_param_system&apos;</source>
			<translation>Parametry związane z &apos;searchplus&apos; nie zostały ustawione w tabeli &apos;config_param_system&apos;</translation>
		</message>
		<message>
			<source>Parameter widgetfunction is null for widget</source>
			<translation>Parametr widgetfunction ma wartość null dla widgetu</translation>
		</message>
		<message>
			<source>Parameter widgetfunction is null for widget hyperlink</source>
			<translation>Parametr widgetfunction ma wartość null dla hiperłącza widżetu</translation>
		</message>
		<message>
			<source>Parameter widgetfunction not found for widget type hyperlink</source>
			<translation>Nie znaleziono parametru widgetfunction dla widżetu typu hiperłącze</translation>
		</message>
		<message>
			<source>Parent ID does not exist.</source>
			<translation>Parent ID does not exist.</translation>
		</message>
		<message>
			<source>Parent ID must be an integer.</source>
			<translation>Parent ID must be an integer.</translation>
		</message>
		<message>
			<source>Parsing error fixed</source>
			<translation>Naprawiono błąd parsowania</translation>
		</message>
		<message>
			<source>Period of leaks: {years:.4g} years.</source>
			<translation>Okres nieszczelności: {years:.4g} lat.</translation>
		</message>
		<message>
			<source>PgRouting version</source>
			<translation>Wersja PgRouting</translation>
		</message>
		<message>
			<source>pgRouting version is not compatible with Giswater. Please check wiki</source>
			<translation>Wersja pgRouting nie jest kompatybilna z Giswater. Sprawdź wiki</translation>
		</message>
		<message>
			<source>pgRouting version: {self.pgrouting_version}</source>
			<translation>pgRouting version: {self.pgrouting_version}</translation>
		</message>
		<message>
			<source>PgRouting version: {self.pgrouting_version}</source>
			<translation>Wersja PgRouting: {self.pgrouting_version}</translation>
		</message>
		<message>
			<source>Pipes with invalid arccat_ids: {0}.</source>
			<translation>Potoki z nieprawidłowymi identyfikatorami arccat_ids: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid arccat_ids: {0}.\nInvalid arccat_ids: {1}.\n\nAn arccat_id is considered invalid if it is not listed in the catalog configuration table. As a result, these pipes will NOT be assigned a priority value.\n\nDo you want to proceed?</source>
			<translation>Potoki z nieprawidłowymi identyfikatorami arccat_ids: {0}.\nInvalid arccat_ids: {1}.\n\nArccat_id jest uważany za nieprawidłowy, jeśli nie jest wymieniony w tabeli konfiguracji katalogu. W rezultacie tym potokom NIE zostanie przypisana wartość priorytetu.\n\nCzy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>Pipes with invalid arccat_ids: {qtd}.</source>
			<translation>Potoki z nieprawidłowymi identyfikatorami arccat_ids: {qtd}.</translation>
		</message>
		<message>
			<source>Pipes with invalid diameters: {0}.</source>
			<translation>Rury o nieprawidłowych średnicach: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid diameters: {0}.\nInvalid diameters: {1}.\n\nA diameter value is considered invalid if it is zero, negative, NULL or greater than the maximum diameter in the configuration table. As a result, these pipes will NOT be assigned a priority value.\n\nDo you want to proceed?</source>
			<translation>Rury o nieprawidłowych średnicach: {0}.\nNieprawidłowe średnice: {1}.\n\n Wartość średnicy jest uznawana za nieprawidłową, jeśli jest równa zero, ujemna, NULL lub większa niż maksymalna średnica w tabeli konfiguracji. W rezultacie tym rurom NIE zostanie przypisana wartość priorytetu.\n\nCzy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>Pipes with invalid diameters: {qtd}.</source>
			<translation>Rury o nieprawidłowych średnicach: {qtd}.</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {0}.qtd</source>
			<translation>Rury z nieprawidłowymi materiałami: {0}.qtd</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {2}.</source>
			<translation>Rury wykonane z nieprawidłowych materiałów: {2}.</translation>
		</message>
		<message>
			<source>Pipes with invalid materials: {qtd}.</source>
			<translation>Rury wykonane z nieprawidłowych materiałów: {qtd}.</translation>
		</message>
		<message>
			<source>Pipes with invalid pressures: {0}.</source>
			<translation>Rury z nieprawidłowymi ciśnieniami: {0}.</translation>
		</message>
		<message>
			<source>Pipes with invalid pressures: {0}.\nThese pipes have no pressure information for their nodes. This will result in them receiving the maximum longevity value for their material, which may affect the final priority value.\n\nDo you want to proceed?</source>
			<translation>Rury z nieprawidłowymi ciśnieniami: {0}.\nPrzewody te nie mają informacji o ciśnieniu dla swoich węzłów. Spowoduje to, że otrzymają one maksymalną wartość żywotności dla ich materiału, co może wpłynąć na ostateczną wartość priorytetu.\n\nCzy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>Pipes with invalid pressures: {qtd}.</source>
			<translation>Rury z nieprawidłowym ciśnieniem: {qtd}.</translation>
		</message>
		<message>
			<source>Pipes with zero leaks per km per year: {pipes}.</source>
			<translation>Rury z zerową liczbą wycieków na km rocznie: {rury}.</translation>
		</message>
		<message>
			<source>Planified features cannot be replaced</source>
			<translation>Planowanych funkcji nie można zastąpić</translation>
		</message>
		<message>
			<source>Planned end date</source>
			<translation>Planowana data zakończenia</translation>
		</message>
		<message>
			<source>Planned start date</source>
			<translation>Planowana data rozpoczęcia</translation>
		</message>
		<message>
			<source>Please</source>
			<translation>Wybierz projekt do usunięcia</translation>
		</message>
		<message>
			<source>Please choose a csv file</source>
			<translation>Wybierz plik csv</translation>
		</message>
		<message>
			<source>Please choose a different name.</source>
			<translation>Wybierz inną nazwę.</translation>
		</message>
		<message>
			<source>Please choose a valid path</source>
			<translation>Wybierz prawidłową ścieżkę</translation>
		</message>
		<message>
			<source>Please ensure that features has no undelete value on true.</source>
			<translation>Upewnij się, że funkcje nie mają wartości undelete na true.</translation>
		</message>
		<message>
			<source>Please enter a demands dscenario name to proceed with this import.</source>
			<translation>Wprowadź żądaną nazwę scenariusza, aby kontynuować import.</translation>
		</message>
		<message>
			<source>Please enter a new catalog name when the &quot;{0}&quot; option is selected.</source>
			<translation>Wprowadź nową nazwę katalogu po wybraniu opcji &quot;{0}&quot;.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the built date range.</source>
			<translation>Wprowadź prawidłową liczbę całkowitą dla zakresu daty budowy.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the cluster length.</source>
			<translation>Wprowadź prawidłową liczbę całkowitą dla długości klastra.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the maximum distance.</source>
			<translation>Wprowadź prawidłową liczbę całkowitą dla maksymalnej odległości.</translation>
		</message>
		<message>
			<source>Please enter a valid integer for the number of years.</source>
			<translation>Wprowadź prawidłową liczbę całkowitą dla liczby lat.</translation>
		</message>
		<message>
			<source>Please enter a valid number.</source>
			<translation>Wprowadź prawidłowy numer.</translation>
		</message>
		<message>
			<source>Please enter a valid number for the budget.</source>
			<translation>Wprowadź prawidłowy numer budżetu.</translation>
		</message>
		<message>
			<source>Please enter a valid target year.</source>
			<translation>Wprowadź prawidłowy rok docelowy.</translation>
		</message>
		<message>
			<source>Please enter a Workcat_id to proceed with this import.</source>
			<translation>Wprowadź Workcat_id, aby kontynuować import.</translation>
		</message>
		<message>
			<source>Please enter the diameter range in this format: [minimum factor]-[maximum factor]. For example, 0.75-1.5</source>
			<translation>Wprowadź zakres średnic w tym formacie: [współczynnik minimalny]-[współczynnik maksymalny]. Na przykład 0,75-1,5</translation>
		</message>
		<message>
			<source>Please fill all fields in the dialog</source>
			<translation>Wypełnij wszystkie pola w oknie dialogowym</translation>
		</message>
		<message>
			<source>Please fill all mandatory fields (highlighted in red).</source>
			<translation>Wypełnij wszystkie obowiązkowe pola (zaznaczone na czerwono).</translation>
		</message>
		<message>
			<source>Please fill link catalog field in the dialog</source>
			<translation>Wypełnij pole katalogu linków w oknie dialogowym</translation>
		</message>
		<message>
			<source>Please, introduce a result name</source>
			<translation>Proszę, wprowadź nazwę wyniku</translation>
		</message>
		<message>
			<source>Please provide a result name.</source>
			<translation>Podaj nazwę wyniku.</translation>
		</message>
		<message>
			<source>Please provide the repairing cost for diameter</source>
			<translation>Podaj koszt naprawy dla średnicy</translation>
		</message>
		<message>
			<source>Please provide the replacing cost for diameter</source>
			<translation>Podaj koszt wymiany dla średnicy</translation>
		</message>
		<message>
			<source>Please select a catalog item for all elements in the tabs: Features, Nodes, Arcs, Materials.</source>
			<translation>Wybierz pozycję katalogową dla wszystkich elementów w zakładkach: Cechy, Węzły, Łuki, Materiały.</translation>
		</message>
		<message>
			<source>Please select a catalog item for all elements in the tabs: Nodes, Arcs, Materials, Features.</source>
			<translation>Wybierz pozycję katalogową dla wszystkich elementów w zakładkach: Węzły, Łuki, Materiały, Cechy.</translation>
		</message>
		<message>
			<source>Please select a category to update.</source>
			<translation>Wybierz kategorię do aktualizacji.</translation>
		</message>
		<message>
			<source>Please select a default raingage to proceed with this import.</source>
			<translation>Wybierz domyślną taryfę, aby kontynuować import.</translation>
		</message>
		<message>
			<source>Please, select a diferent project name than current.</source>
			<translation>Wybierz inną nazwę projektu niż obecna.</translation>
		</message>
		<message>
			<source>Please select a feature to add</source>
			<translation>Wybierz funkcję do dodania</translation>
		</message>
		<message>
			<source>Please select a feature to remove</source>
			<translation>Wybierz funkcję do usunięcia</translation>
		</message>
		<message>
			<source>Please select a lot to open.</source>
			<translation>Wybierz partię do otwarcia.</translation>
		</message>
		<message>
			<source>Please select a lot to open.</source>
			<translation>Please select a lot to open.</translation>
		</message>
		<message>
			<source>Please select a municipality to proceed with this import.</source>
			<translation>Wybierz gminę, aby kontynuować import.</translation>
		</message>
		<message>
			<source>Please select an exploitation to proceed with this import.</source>
			<translation>Wybierz eksploatację, aby kontynuować import.</translation>
		</message>
		<message>
			<source>Please, select a project to delete</source>
			<translation>Wybierz projekt do usunięcia</translation>
		</message>
		<message>
			<source>Please select a result with not empty type</source>
			<translation>Please select a result with not empty type</translation>
		</message>
		<message>
			<source>Please select a sector to proceed with this import.</source>
			<translation>Wybierz sektor, aby kontynuować import.</translation>
		</message>
		<message>
			<source>Please select a style group before adding a new style.</source>
			<translation>Przed dodaniem nowego stylu należy wybrać grupę stylów.</translation>
		</message>
		<message>
			<source>Please select a style group to delete.</source>
			<translation>Wybierz grupę stylów do usunięcia.</translation>
		</message>
		<message>
			<source>Please select a target year.</source>
			<translation>Wybierz rok docelowy.</translation>
		</message>
		<message>
			<source>Please select a team to assign.</source>
			<translation>Please select a team to assign.</translation>
		</message>
		<message>
			<source>Please select at least one user to assign a team.</source>
			<translation>Please select at least one user to assign a team.</translation>
		</message>
		<message>
			<source>Please select at least one user to remove team assignment.</source>
			<translation>Please select at least one user to remove team assignment.</translation>
		</message>
		<message>
			<source>Please select a valid team to assign.</source>
			<translation>Please select a valid team to assign.</translation>
		</message>
		<message>
			<source>Please select a workcat id end</source>
			<translation>Wybierz identyfikator workcat na końcu</translation>
		</message>
		<message>
			<source>Please select a workorder to open.</source>
			<translation>Please select a workorder to open.</translation>
		</message>
		<message>
			<source>Please select a workorder to open.</source>
			<translation>Wybierz zlecenie do otwarcia.</translation>
		</message>
		<message>
			<source>Please select one or more styles to delete.</source>
			<translation>Wybierz jeden lub więcej stylów do usunięcia.</translation>
		</message>
		<message>
			<source>Please select one or more styles to update.</source>
			<translation>Wybierz jeden lub więcej stylów do aktualizacji.</translation>
		</message>
		<message>
			<source>Please select only one result before changing its status.</source>
			<translation>Wybierz tylko jeden wynik przed zmianą jego statusu.</translation>
		</message>
		<message>
			<source>Please select rows to remove from the table</source>
			<translation>Wybierz wiersze do usunięcia z tabeli</translation>
		</message>
		<message>
			<source>Plugin version not found</source>
			<translation>Nie znaleziono wersji wtyczki</translation>
		</message>
		<message>
			<source>POLYGON</source>
			<translation>POLYGON</translation>
		</message>
		<message>
			<source>PostGis version</source>
			<translation>Wersja PostGis</translation>
		</message>
		<message>
			<source>PostGis version: {self.postgis_version}</source>
			<translation>Wersja PostGis: {self.postgis_version}</translation>
		</message>
		<message>
			<source>PostgreSQL PID: {0}</source>
			<translation>PostgreSQL PID: {0}</translation>
		</message>
		<message>
			<source>PostgreSQL version</source>
			<translation>Wersja PostgreSQL</translation>
		</message>
		<message>
			<source>PostgreSQL version is not compatible with Giswater. Please check wiki</source>
			<translation>Wersja PostgreSQL nie jest kompatybilna z Giswater. Sprawdź wiki</translation>
		</message>
		<message>
			<source>PostgreSQL version: {self.postgresql_version}</source>
			<translation>Wersja PostgreSQL: {self.postgresql_version}</translation>
		</message>
		<message>
			<source>PostgreSQL version: {self.postgresql_version}\nPostGis version: {self.postgis_version}\npgRouting version: {self.pgrouting_version}\n \n</source>
			<translation>Wersja PostgreSQL: {self.postgresql_version}\nPostGis version: {self.postgis_version}\npgRouting version: {self.pgrouting_version}\n \n</translation>
		</message>
		<message>
			<source>PostgreSQL version: {self.postgresql_version}\nPostGis version: {self.postgis_version}\nPgRouting version: {self.pgrouting_version}\n \nSchema name: {schema_name}\nVersion: {self.project_version}\nEPSG: {self.project_epsg}\nLanguage: {self.project_language}\nDate of creation: {project_date_create}\nDate of last update: {project_date_update}\n</source>
			<translation>Wersja PostgreSQL: {self.postgresql_version}\nPostGis version: {self.postgis_version}\nPgRouting version: {self.pgrouting_version}\n \nNazwa schematu: {schema_name}\nWersja: {self.project_version}\nEPSG: {self.project_epsg}\nLanguage: {self.project_language}\nData utworzenia: {project_date_create}\nData ostatniej aktualizacji: {project_date_update}\n</translation>
		</message>
		<message>
			<source>prefer</source>
			<translation>preferować</translation>
		</message>
		<message>
			<source>Price list csv file name is required</source>
			<translation>Wymagana jest nazwa pliku csv z cennikiem</translation>
		</message>
		<message>
			<source>Price list detail csv file name is required</source>
			<translation>Price list detail csv file name is required</translation>
		</message>
		<message>
			<source>PRICES</source>
			<translation>CENY</translation>
		</message>
		<message>
			<source>Print</source>
			<translation>Drukuj</translation>
		</message>
		<message>
			<source>Priority Calculation (Selection)</source>
			<translation>Obliczanie priorytetu (wybór)</translation>
		</message>
		<message>
			<source>Prob. of Failure</source>
			<translation>Prawdopodobieństwo niepowodzenia</translation>
		</message>
		<message>
			<source>Process completed</source>
			<translation>Proces zakończony</translation>
		</message>
		<message>
			<source>Process finished.</source>
			<translation>Proces zakończony.</translation>
		</message>
		<message>
			<source>Process finished.\n\n</source>
			<translation>Proces zakończony.pl</translation>
		</message>
		<message>
			<source>Process finished successfully</source>
			<translation>Proces zakończył się pomyślnie</translation>
		</message>
		<message>
			<source>Process finished successfully: Delete schema</source>
			<translation>Proces zakończył się pomyślnie: Usuń schemat</translation>
		</message>
		<message>
			<source>Process finished with some errors</source>
			<translation>Proces zakończył się z pewnymi błędami</translation>
		</message>
		<message>
			<source>Processing folder</source>
			<translation>Folder przetwarzania</translation>
		</message>
		<message>
			<source>Processing muni_id {0}</source>
			<translation>Przetwarzanie muni_id {0}</translation>
		</message>
		<message>
			<source>Profile</source>
			<translation>Profile</translation>
		</message>
		<message>
			<source>Profile deleted</source>
			<translation>Profil usunięty</translation>
		</message>
		<message>
			<source>Profile name is mandatory.</source>
			<translation>Nazwa profilu jest obowiązkowa.</translation>
		</message>
		<message>
			<source>Project read finished</source>
			<translation>Projekt zakończony</translation>
		</message>
		<message>
			<source>Project read finished with different versions on plugin metadata ({0}) and PostgreSQL sys_version table ({1}).</source>
			<translation>Odczyt projektu zakończył się z różnymi wersjami metadanych wtyczki ({0}) i tabeli sys_version PostgreSQL ({1}).</translation>
		</message>
		<message>
			<source>Project read started</source>
			<translation>Rozpoczął się odczyt projektu</translation>
		</message>
		<message>
			<source>Project read successfully</source>
			<translation>Projekt został pomyślnie odczytany</translation>
		</message>
		<message>
			<source>Project type</source>
			<translation>Project type</translation>
		</message>
		<message>
			<source>PSECTOR</source>
			<translation>PSECTOR</translation>
		</message>
		<message>
			<source>Psector &apos;{0}&apos; has no workcat_id value set. Do you want to continue with the default value?</source>
			<translation>Sektor &apos;{0}&apos; nie ma ustawionej wartości workcat_id. Czy chcesz kontynuować z wartością domyślną?</translation>
		</message>
		<message>
			<source>Psector could not be updated because of the following errors: </source>
			<translation>Psector could not be updated because of the following errors: </translation>
		</message>
		<message>
			<source>Psector features loaded successfully on the map.</source>
			<translation>Funkcje sektora zostały pomyślnie załadowane na mapę.</translation>
		</message>
		<message>
			<source>Psector ID</source>
			<translation>Psector ID</translation>
		</message>
		<message>
			<source>Psector ID not found</source>
			<translation>Psector ID not found</translation>
		</message>
		<message>
			<source>Psector is not archived</source>
			<translation>Psector nie jest zarchiwizowany</translation>
		</message>
		<message>
			<source>Psector name not found</source>
			<translation>Nie znaleziono nazwy sektora</translation>
		</message>
		<message>
			<source>Psector removed from selector</source>
			<translation>Sektor P usunięty z selektora</translation>
		</message>
		<message>
			<source>Psector values updated successfully</source>
			<translation>Pomyślnie zaktualizowano wartości sektora</translation>
		</message>
		<message>
			<source>Python file</source>
			<translation>Plik Python</translation>
		</message>
		<message>
			<source>Python function</source>
			<translation>Funkcja Pythona</translation>
		</message>
		<message>
			<source>Python translation canceled</source>
			<translation>Tłumaczenie Pythona anulowane</translation>
		</message>
		<message>
			<source>Python translation failed</source>
			<translation>Tłumaczenie Pythona nie powiodło się</translation>
		</message>
		<message>
			<source>Python translation successful</source>
			<translation>Tłumaczenie Pythona zakończone sukcesem</translation>
		</message>
		<message>
			<source>QGIS project has more than one {0} layer coming from different schemas. If you are looking to manage two schemas, it is mandatory to define which is the master and which isn&apos;t. To do this, you need to configure the QGIS project setting this project&apos;s variables: {1} and {2}.</source>
			<translation>Projekt QGIS ma więcej niż jedną warstwę {0} pochodzącą z różnych schematów. Jeśli chcesz zarządzać dwoma schematami, obowiązkowe jest określenie, który z nich jest główny, a który nie. Aby to zrobić, należy skonfigurować projekt QGIS, ustawiając zmienne tego projektu: {1} i {2}.</translation>
		</message>
		<message>
			<source>QGIS project has more than one v_edit_node layer coming from different schemas.  </source>
			<translation>Projekt QGIS ma więcej niż jedną warstwę v_edit_node pochodzącą z różnych schematów.  </translation>
		</message>
		<message>
			<source>QGIS project has more than one v_edit_node layer coming from different schemas. If you are looking to manage two schemas, it is mandatory to define which is the master and which isn&apos;t. To do this, you need to configure the QGIS project setting this project&apos;s variables: gwMainSchema and gwAddSchema.</source>
			<translation>Projekt QGIS ma więcej niż jedną warstwę v_edit_node pochodzącą z różnych schematów. Jeśli chcesz zarządzać dwoma schematami, obowiązkowe jest zdefiniowanie, który jest główny, a który nie. Aby to zrobić, należy skonfigurować projekt QGIS, ustawiając zmienne tego projektu: gwMainSchema i gwAddSchema.</translation>
		</message>
		<message>
			<source>QGIS version is not compatible with Giswater. Please check wiki</source>
			<translation>Wersja QGIS nie jest kompatybilna z Giswater. Sprawdź wiki</translation>
		</message>
		<message>
			<source>QgsLayerTree not found for project.</source>
			<translation>Nie znaleziono QgsLayerTree dla projektu.</translation>
		</message>
		<message>
			<source>`query` must be a string if `by_osmid` is True.</source>
			<translation>`query` musi być ciągiem znaków, jeśli `by_osmid` ma wartość True.</translation>
		</message>
		<message>
			<source>rasterio must be installed as an optional dependency to query rasters.</source>
			<translation>rasterio musi być zainstalowany jako opcjonalna zależność do zapytań o rastry.</translation>
		</message>
		<message>
			<source>\rDo you want to overwrite it?</source>
			<translation>\Czy chcesz ją nadpisać?</translation>
		</message>
		<message>
			<source>Reading file</source>
			<translation>Odczyt pliku</translation>
		</message>
		<message>
			<source>Real end date</source>
			<translation>Real end date</translation>
		</message>
		<message>
			<source>Real location has been updated</source>
			<translation>Rzeczywista lokalizacja została zaktualizowana</translation>
		</message>
		<message>
			<source>Real start date</source>
			<translation>Real start date</translation>
		</message>
		<message>
			<source>Record deleted</source>
			<translation>Rekord usunięty</translation>
		</message>
		<message>
			<source>Records deleted</source>
			<translation>Usunięte rekordy</translation>
		</message>
		<message>
			<source>Reload failed</source>
			<translation>Przeładowanie nie powiodło się</translation>
		</message>
		<message>
			<source>Remove layer from project?</source>
			<translation>Usunąć warstwę z projektu?</translation>
		</message>
		<message>
			<source>REMOVE NODE</source>
			<translation>USUŃ WĘZEŁ</translation>
		</message>
		<message>
			<source>Remove Team Assignment</source>
			<translation>Remove Team Assignment</translation>
		</message>
		<message>
			<source>Repair cost</source>
			<translation>Koszt naprawy</translation>
		</message>
		<message>
			<source>Replace feature</source>
			<translation>Zastąp funkcję</translation>
		</message>
		<message>
			<source>Replace feature done successfully</source>
			<translation>Funkcja wymiany została wykonana pomyślnie</translation>
		</message>
		<message>
			<source>Replacement cost</source>
			<translation>Koszt wymiany</translation>
		</message>
		<message>
			<source>Replacing template text</source>
			<translation>Zastępowanie tekstu szablonu</translation>
		</message>
		<message>
			<source>Reports generated successfully</source>
			<translation>Reports generated successfully</translation>
		</message>
		<message>
			<source>Required fields are missing</source>
			<translation>Brakuje wymaganych pól</translation>
		</message>
		<message>
			<source>Reset position form done successfully.</source>
			<translation>Resetowanie formularza pozycji zakończyło się pomyślnie.</translation>
		</message>
		<message>
			<source>Result Manager</source>
			<translation>Menedżer wyników</translation>
		</message>
		<message>
			<source>Result name</source>
			<translation>Nazwa wyniku</translation>
		</message>
		<message>
			<source>Result name already exists</source>
			<translation>Nazwa wyniku już istnieje, czy chcesz ją nadpisać?</translation>
		</message>
		<message>
			<source>Result name already exists, do you want overwrite?</source>
			<translation>Nazwa wyniku już istnieje, czy chcesz ją nadpisać?</translation>
		</message>
		<message>
			<source>Result name already in use, please choose a different name.</source>
			<translation>Nazwa wyniku jest już używana, wybierz inną nazwę.</translation>
		</message>
		<message>
			<source>Result name not found. It&apos;s not possible to import RPT file into database</source>
			<translation>Nie znaleziono nazwy wyniku. Nie można zaimportować pliku RPT do bazy danych</translation>
		</message>
		<message>
			<source>Result Selector</source>
			<translation>Selektor wyników</translation>
		</message>
		<message>
			<source>Retrieving process ({0}/{1})...</source>
			<translation>Proces pobierania ({0}/{1})...</translation>
		</message>
		<message>
			<source>rio-vrt must be installed as an optional dependency to build VRTs.</source>
			<translation>rio-vrt musi być zainstalowany jako opcjonalna zależność do budowania VRT.</translation>
		</message>
		<message>
			<source>Rotation must be a number.</source>
			<translation>Rotation must be a number.</translation>
		</message>
		<message>
			<source>`route_colors` and `route_linewidths` must have same lengths as `routes`.</source>
			<translation>`route_colors` i `route_linewidths` muszą mieć takie same długości jak `routes`.</translation>
		</message>
		<message>
			<source>`routes` must be an iterable of route lists.</source>
			<translation>`routes` musi być iterowalną listą tras.</translation>
		</message>
		<message>
			<source>Rpt fail</source>
			<translation>Błąd raportu</translation>
		</message>
		<message>
			<source>RPT file path is required when importing results or executing EPA</source>
			<translation>RPT file path is required when importing results or executing EPA</translation>
		</message>
		<message>
			<source>\r(This decision will not cancel the other selections, the process will keep running)</source>
			<translation>\r (ta decyzja nie anuluje innych wyborów, proces będzie kontynuowany)</translation>
		</message>
		<message>
			<source>Satellite schemas</source>
			<translation>Satellite schemas</translation>
		</message>
		<message>
			<source>Save as</source>
			<translation>Zapisz jako</translation>
		</message>
		<message>
			<source>Save feature</source>
			<translation>Funkcja zapisywania</translation>
		</message>
		<message>
			<source>Saving results to DB</source>
			<translation>Zapisywanie wyników do bazy danych</translation>
		</message>
		<message>
			<source>Scale must be a number.</source>
			<translation>Scale must be a number.</translation>
		</message>
		<message>
			<source>Schema audit not found, please create it first</source>
			<translation>Nie znaleziono audytu schematu, utwórz go najpierw</translation>
		</message>
		<message>
			<source>Schema name</source>
			<translation>Nazwa schematu</translation>
		</message>
		<message>
			<source>Schema name: {schema_name}</source>
			<translation>Nazwa schematu: {schema_name}</translation>
		</message>
		<message>
			<source>Schema Utils already exist.</source>
			<translation>Schema Utils już istnieje.</translation>
		</message>
		<message>
			<source>Schema vacuum executed</source>
			<translation>Wykonana próżnia schematu</translation>
		</message>
		<message>
			<source>(Schema version is higher than plugin version. Please contact your administrator to update the plugin)</source>
			<translation>(Schema version is higher than plugin version. Please contact your administrator to update the plugin)</translation>
		</message>
		<message>
			<source>(Schema version is higher than plugin version, please update plugin)</source>
			<translation>(Wersja schematu jest wyższa niż wersja wtyczki, zaktualizuj wtyczkę)</translation>
		</message>
		<message>
			<source>(Schema version is lower than plugin version. Please contact your administrator to update the schema)</source>
			<translation>(Schema version is lower than plugin version. Please contact your administrator to update the schema)</translation>
		</message>
		<message>
			<source>(Schema version is lower than plugin version, please update schema)</source>
			<translation>(Wersja schematu jest niższa niż wersja wtyczki, zaktualizuj schemat)</translation>
		</message>
		<message>
			<source>scikit-learn must be installed as an optional dependency to search an unprojected graph.</source>
			<translation>scikit-learn musi być zainstalowany jako opcjonalna zależność, aby przeszukiwać nieprojektowany wykres.</translation>
		</message>
		<message>
			<source>scipy must be installed as an optional dependency to calculate entropy.</source>
			<translation>scipy musi być zainstalowany jako opcjonalna zależność do obliczania entropii.</translation>
		</message>
		<message>
			<source>scipy must be installed as an optional dependency to search a projected graph.</source>
			<translation>scipy musi być zainstalowany jako opcjonalna zależność do przeszukiwania projektowanego wykresu.</translation>
		</message>
		<message>
			<source>Second iteration</source>
			<translation>Druga iteracja</translation>
		</message>
		<message>
			<source>Select a campaign to delete.</source>
			<translation>Wybierz kampanię do usunięcia.</translation>
		</message>
		<message>
			<source>Select a campaign to delete.</source>
			<translation>Select a campaign to delete.</translation>
		</message>
		<message>
			<source>Select a Custom node Type</source>
			<translation>Wybierz niestandardowy typ węzła</translation>
		</message>
		<message>
			<source>Select a lot to delete.</source>
			<translation>Select a lot to delete.</translation>
		</message>
		<message>
			<source>Select a valid date column to filter.</source>
			<translation>Wybierz prawidłową kolumnę daty do filtrowania.</translation>
		</message>
		<message>
			<source>Select a valid path.</source>
			<translation>Wybierz prawidłową ścieżkę</translation>
		</message>
		<message>
			<source>Select a workcat id end</source>
			<translation>Wybierz identyfikator workcat end</translation>
		</message>
		<message>
			<source>Select a workorder to delete.</source>
			<translation>Wybierz zlecenie do usunięcia.</translation>
		</message>
		<message>
			<source>Select a workorder to delete.</source>
			<translation>Select a workorder to delete.</translation>
		</message>
		<message>
			<source>Select connecs or gullies with qgis tool and use right click to connect them with network</source>
			<translation>Wybierz połączenia lub wpusty za pomocą narzędzia qgis i kliknij prawym przyciskiem myszy, aby połączyć je z siecią.</translation>
		</message>
		<message>
			<source>Select connecs or gullies with qgis tool and use right click to connect them with network. CTRL + SHIFT over selection to remove it</source>
			<translation>Wybierz połączenia lub wpusty za pomocą narzędzia qgis i kliknij prawym przyciskiem myszy, aby połączyć je z siecią. CTRL + SHIFT nad zaznaczeniem, aby je usunąć</translation>
		</message>
		<message>
			<source>Select CSV file</source>
			<translation>Wybierz plik CSV</translation>
		</message>
		<message>
			<source>Selected {0}</source>
			<translation>Wybrano {0}</translation>
		</message>
		<message>
			<source>Selected CSV has been imported successfully</source>
			<translation>Wybrany plik CSV został pomyślnie zaimportowany</translation>
		</message>
		<message>
			<source>Selected date interval is not valid</source>
			<translation>Wybrany przedział dat jest nieprawidłowy</translation>
		</message>
		<message>
			<source>Selected element already in the list</source>
			<translation>Wybrany element znajduje się już na liście</translation>
		</message>
		<message>
			<source>Selected functions have been executed</source>
			<translation>Wybrane funkcje zostały wykonane</translation>
		</message>
		<message>
			<source>Selected hydrometer_id not found</source>
			<translation>Nie znaleziono wybranego identyfikatora hydrometer_id</translation>
		</message>
		<message>
			<source>Selected node</source>
			<translation>Wybrany węzeł</translation>
		</message>
		<message>
			<source>Selected &apos;profile_id&apos; already exist in database</source>
			<translation>Wybrany &apos;profile_id&apos; już istnieje w bazie danych</translation>
		</message>
		<message>
			<source>Selected schema not found</source>
			<translation>Wybrany schemat nie został znaleziony</translation>
		</message>
		<message>
			<source>Selected snapped feature_id to copy values from</source>
			<translation>Wybrany snapped feature_id do skopiowania wartości z</translation>
		</message>
		<message>
			<source>Selected styles updated successfully!</source>
			<translation>Wybrane style zostały pomyślnie zaktualizowane!</translation>
		</message>
		<message>
			<source>Selected styles were successfully deleted.</source>
			<translation>Wybrane style zostały pomyślnie usunięte.</translation>
		</message>
		<message>
			<source>Selected team not found.</source>
			<translation>Wybrany zespół nie został znaleziony.</translation>
		</message>
		<message>
			<source>Select feature type and id and check if it&apos;&apos;s related to any other features. click delete to remove it completely</source>
			<translation>Wybierz typ i identyfikator funkcji i sprawdź, czy jest ona powiązana z innymi funkcjami. Kliknij usuń, aby całkowicie ją usunąć</translation>
		</message>
		<message>
			<source>Select file</source>
			<translation>Wybierz plik</translation>
		</message>
		<message>
			<source>Select folder</source>
			<translation>Wybierz folder</translation>
		</message>
		<message>
			<source>Select INP file</source>
			<translation>Wybierz plik INP</translation>
		</message>
		<message>
			<source>SELECTION</source>
			<translation>SELEKCJA</translation>
		</message>
		<message>
			<source>Select just one document</source>
			<translation>Wybierz tylko jeden dokument</translation>
		</message>
		<message>
			<source>Select just one visit</source>
			<translation>Wybierz tylko jedną wizytę</translation>
		</message>
		<message>
			<source>Select one</source>
			<translation>Wybierz jedną</translation>
		</message>
		<message>
			<source>Selector help</source>
			<translation>Pomoc selektora</translation>
		</message>
		<message>
			<source>Select RPT file</source>
			<translation>Wybierz plik RPT</translation>
		</message>
		<message>
			<source>Select UI file</source>
			<translation>Wybierz plik interfejsu użytkownika</translation>
		</message>
		<message>
			<source>Select valid INP file</source>
			<translation>Wybierz ważny plik INP</translation>
		</message>
		<message>
			<source>Select valid RPT file</source>
			<translation>Wybierz prawidłowy plik RPT</translation>
		</message>
		<message>
			<source>Select visit to open</source>
			<translation>Wybierz wizytę do otwarcia</translation>
		</message>
		<message>
			<source>SERVER RESPONSE</source>
			<translation>ODPOWIEDŹ SERWERA</translation>
		</message>
		<message>
			<source>Service database connection error (psycopg2). Please open plugin log file to get more details</source>
			<translation>Błąd połączenia z bazą danych usługi (psycopg2). Otwórz plik dziennika wtyczki, aby uzyskać więcej szczegółów</translation>
		</message>
		<message>
			<source>Service database connection error (QSqlDatabase). Please open plugin log file to get more details</source>
			<translation>Błąd połączenia z serwisową bazą danych (QSqlDatabase). Otwórz plik dziennika wtyczki, aby uzyskać więcej szczegółów</translation>
		</message>
		<message>
			<source>Set rpt archived execution successful.</source>
			<translation>Pomyślne wykonanie zarchiwizowanego set rpt.</translation>
		</message>
		<message>
			<source>Shamir-Howard parameters</source>
			<translation>Parametry Shamir-Howard</translation>
		</message>
		<message>
			<source>Simplified graph: {initial_node_count:,} to {len(G):,} nodes, {initial_edge_count:,} to {len(G.edges):,} edges</source>
			<translation>Graf uproszczony: {initial_node_count:,} to {len(G):,} nodes, {initial_edge_count:,} to {len(G.edges):,} edges</translation>
		</message>
		<message>
			<source>Skipping muni_id {0}: Invalid geometry</source>
			<translation>Pominięto muni_id {0}: Nieprawidłowa geometria</translation>
		</message>
		<message>
			<source>Snapped feature is not in a valid layer</source>
			<translation>Snapped feature is not in a valid layer</translation>
		</message>
		<message>
			<source>Some data is missing</source>
			<translation>Brakuje niektórych danych</translation>
		</message>
		<message>
			<source>Some data is missing. Check gis_length for arc</source>
			<translation>Brakuje niektórych danych. Sprawdź gis_length dla łuku</translation>
		</message>
		<message>
			<source>Some edges missing nodes, possibly due to input data clipping issue.</source>
			<translation>W niektórych krawędziach brakuje węzłów, prawdopodobnie z powodu przycinania danych wejściowych.</translation>
		</message>
		<message>
			<source>Some events have documents</source>
			<translation>Niektóre wydarzenia mają dokumenty</translation>
		</message>
		<message>
			<source>Some layers of your role not found. Do you want to view them?</source>
			<translation>Nie znaleziono niektórych warstw Twojej roli. Czy chcesz je wyświetlić?</translation>
		</message>
		<message>
			<source>Some mandatory fields are missing. Please fill the required fields (marked in red).</source>
			<translation>Some mandatory fields are missing. Please fill the required fields (marked in red).</translation>
		</message>
		<message>
			<source>Some mandatory fields are missing. Please fill the required fields (marked in red).</source>
			<translation>Brakuje niektórych obowiązkowych pól. Wypełnij wymagane pola (zaznaczone na czerwono).</translation>
		</message>
		<message>
			<source>Some mandatory values are missing. Please check the widgets marked in red.</source>
			<translation>Some mandatory values are missing. Please check the widgets marked in red.</translation>
		</message>
		<message>
			<source>Some mandatory values are missing. Please check the widgets marked in red.</source>
			<translation>Brakuje niektórych obowiązkowych wartości. Sprawdź widżety zaznaczone na czerwono.</translation>
		</message>
		<message>
			<source>Some parameters are missing for node</source>
			<translation>Brakuje niektórych parametrów dla węzła</translation>
		</message>
		<message>
			<source>Some parameters are missing (Values Defaults used for)</source>
			<translation>Brakuje niektórych parametrów (wartości domyślne)</translation>
		</message>
		<message>
			<source>SQL</source>
			<translation>SQL</translation>
		</message>
		<message>
			<source>SQL Context</source>
			<translation>Kontekst SQL</translation>
		</message>
		<message>
			<source>SQL File</source>
			<translation>Pliki SQL</translation>
		</message>
		<message>
			<source>SQL folder not found</source>
			<translation>Nie znaleziono folderu SQL</translation>
		</message>
		<message>
			<source>%ss cannot be directly connected to a reservoir.  Add a pipe to separate the valve from the reservoir.</source>
			<translation>%ss nie może być bezpośrednio podłączony do zbiornika.  Należy dodać rurę oddzielającą zawór od zbiornika.</translation>
		</message>
		<message>
			<source>%ss cannot be directly connected to a tank.  Add a pipe to separate the valve from the tank.</source>
			<translation>%ss nie może być bezpośrednio podłączony do zbiornika.  Należy dodać rurę oddzielającą zawór od zbiornika.</translation>
		</message>
		<message>
			<source>Start date</source>
			<translation>Data rozpoczęcia</translation>
		</message>
		<message>
			<source>Started task &apos;{0}&apos;</source>
			<translation>Rozpoczęte zadanie &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Started task {0}</source>
			<translation>Uruchomiono zadanie {0}</translation>
		</message>
		<message>
			<source>Starting execute_vacuum method</source>
			<translation>Uruchamianie metody execute_vacuum</translation>
		</message>
		<message>
			<source>Starting process...</source>
			<translation>Rozpoczęcie procesu...</translation>
		</message>
		<message>
			<source>Style group &apos;{0}&apos; and related entries have been deleted.</source>
			<translation>Grupa stylów &quot;{0}&quot; i powiązane wpisy zostały usunięte.</translation>
		</message>
		<message>
			<source>Succesfully connected to {0}</source>
			<translation>Udane połączenie z {0}</translation>
		</message>
		<message>
			<source>Successful connection to {0} database</source>
			<translation>Udane połączenie z {0} bazą danych</translation>
		</message>
		<message>
			<source>Successfully assigned team &apos;{0}&apos; to {1} user(s).</source>
			<translation>Successfully assigned team &apos;{0}&apos; to {1} user(s).</translation>
		</message>
		<message>
			<source>Successfully removed team assignment from {0} user(s).</source>
			<translation>Successfully removed team assignment from {0} user(s).</translation>
		</message>
		<message>
			<source>SWMM Model</source>
			<translation>Model SWMM</translation>
		</message>
		<message>
			<source>Table not found</source>
			<translation>Nie znaleziono tabeli</translation>
		</message>
		<message>
			<source>Table not found: &apos;{0}&apos;</source>
			<translation>Nie znaleziono tabeli: &quot;{0}</translation>
		</message>
		<message>
			<source>Table not found: {0}</source>
			<translation>Nie znaleziono tabeli: {0}</translation>
		</message>
		<message>
			<source>Table_object is not a table name or QTableView</source>
			<translation>Table_object nie jest nazwą tabeli lub QTableView</translation>
		</message>
		<message>
			<source>Tab not found.</source>
			<translation>Nie znaleziono karty.</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; completed</source>
			<translation>Zadanie &quot;{0}&quot; zakończone</translation>
		</message>
		<message>
			<source>Task {0} completed</source>
			<translation>Zadanie {0} zakończone</translation>
		</message>
		<message>
			<source>Task {0} completed\n</source>
			<translation>Zadanie {0} zakończone</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; Exception: {1}</source>
			<translation>Zadanie &apos;{0}&apos; Wyjątek: {1}</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; execute function &apos;{1}&apos;</source>
			<translation>Zadanie &apos;{0}&apos; wykonuje funkcję &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; execute procedure &apos;{1}&apos; with parameters: &apos;{2}&apos;, &apos;{3}&apos;, &apos;{4}&apos;</source>
			<translation>Zadanie &apos;{0}&apos; wykonuje procedurę &apos;{1}&apos; z parametrami: &apos;{2}&apos;, &apos;{3}&apos;, &apos;{4}&apos;.</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; execute sql: &apos;{1}&apos;</source>
			<translation>Zadanie &apos;{0}&apos; wykonaj sql: &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; manage json response with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Zadanie &apos;{0}&apos; zarządza odpowiedzią json z parametrami: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;.</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; not successful but without exception</source>
			<translation>Zadanie &quot;{0}&quot; nie powiodło się, ale bez wyjątku</translation>
		</message>
		<message>
			<source>Task &apos;{0}&apos; was cancelled</source>
			<translation>Zadanie &quot;{0}&quot; zostało anulowane</translation>
		</message>
		<message>
			<source>Task aborted - {0}</source>
			<translation>Zadanie przerwane - {0}</translation>
		</message>
		<message>
			<source>Task aborted: {0}.</source>
			<translation>Zadanie przerwane: {0}.</translation>
		</message>
		<message>
			<source>Task canceled.</source>
			<translation>Zadanie anulowane.</translation>
		</message>
		<message>
			<source>Task canceled:</source>
			<translation>Zadanie anulowane:</translation>
		</message>
		<message>
			<source>Task canceled - {0}</source>
			<translation>Zadanie anulowane - {0}</translation>
		</message>
		<message>
			<source>Task canceled: The number of years is greater than the interval disponible.</source>
			<translation>Zadanie anulowane: Liczba lat jest większa niż dostępny interwał.</translation>
		</message>
		<message>
			<source>Task &apos;Check project&apos; execute function &apos;{0}&apos;</source>
			<translation>Zadanie &quot;Sprawdź projekt&quot; wykonaj funkcję &quot;{0}</translation>
		</message>
		<message>
			<source>task_completed</source>
			<translation>task_completed</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute function &apos;{0}&apos; from &apos;{1}&apos; with parameters: &apos;{2}&apos;</source>
			<translation>Zadanie &apos;Connect link&apos; wykonaj funkcję &apos;{0}&apos; z &apos;{1}&apos; z parametrami: &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute function &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;</source>
			<translation>Zadanie &apos;Connect link&apos; wykonaj funkcję &apos;{0}&apos; z parametrami: &apos;{1}&apos;, &apos;{2}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Connect link&apos; execute procedure &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Zadanie &quot;Połącz łącze&quot; wykonuje procedurę &quot;{0}&quot; z parametrami: &quot;{1}&quot;, &quot;{2}&quot;, &quot;{3}&quot;.</translation>
		</message>
		<message>
			<source>Task failed: {0}. This is probably a DB error, check postgres function &apos;{1}&apos;.</source>
			<translation>Zadanie nie powiodło się: {0}. Prawdopodobnie jest to błąd DB, sprawdź funkcję postgres &apos;{1}&apos;.</translation>
		</message>
		<message>
			<source>Task finished!</source>
			<translation>Zadanie zakończone!</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;{0}&apos;</source>
			<translation>Zadanie &apos;Go2Epa&apos; wykonaj funkcję &apos;{0}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;{0}&apos; from &apos;{1}&apos;</source>
			<translation>Zadanie &apos;Go2Epa&apos; wykonaj funkcję &apos;{0}&apos; z &apos;{1}&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute function &apos;def _exec_import_function&apos;</source>
			<translation>Zadanie &apos;Go2Epa&apos; wykonać funkcję &apos;def _exec_import_function&apos;</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{0}&apos; step {1}</source>
			<translation>Zadanie &apos;Go2Epa&apos; wykonaj procedurę &apos;{0}&apos; krok {1}</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{0}&apos; step {1}}</source>
			<translation>Zadanie &apos;Go2Epa&apos; wykonaj procedurę &apos;{0}&apos; krok {1}}</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; execute procedure &apos;{1}&apos; step {2} with parameters: &apos;{1}&apos;, &apos;{3}&apos;, &apos;{4}&apos;, &apos;{5}&apos;, &apos;{6}&apos;</source>
			<translation>Zadanie &apos;Go2Epa&apos; wykonuje procedurę &apos;{1}&apos; krok {2} z parametrami: &apos;{1}&apos;, &apos;{3}&apos;, &apos;{4}&apos;, &apos;{5}&apos;, &apos;{6}&apos;.</translation>
		</message>
		<message>
			<source>Task &apos;Go2Epa&apos; manage json response</source>
			<translation>Zadanie &quot;Go2Epa&quot; zarządza odpowiedzią json</translation>
		</message>
		<message>
			<source>Task &apos;Mincut execute&apos; execute procedure &apos;{0}&apos; with parameters: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;</source>
			<translation>Zadanie &apos;Mincut execute&apos; wykonuje procedurę &apos;{0}&apos; z parametrami: &apos;{1}&apos;, &apos;{2}&apos;, &apos;{3}&apos;.</translation>
		</message>
		<message>
			<source>Task &apos;Mincut execute&apos; manage json response with parameters: &apos;{0}&apos;, &apos;{1}&apos;, &apos;{2}&apos;</source>
			<translation>Zadanie &quot;Mincut execute&quot; zarządza odpowiedzią json z parametrami: &quot;{0}&quot;, &quot;{1}&quot;, &quot;{2}&quot;.</translation>
		</message>
		<message>
			<source>@techreport{boeing_osmnx_2024,</source>
			<translation>@techreport{boeing_osmnx_2024,</translation>
		</message>
		<message>
			<source>@techreport{boeing_osmnx_2024,\n    author = {Boeing, Geoff},\n    title = {{Modeling and Analyzing Urban Networks and Amenities with OSMnx}},\n    type = {Working paper},\n    url = {https://geoffboeing.com/publications/osmnx-paper/},\n    year = {2024}\n}</source>
			<translation>@techreport{boeing_osmnx_2024,\n author = {Boeing, Geoff}, \n title = {{Modeling and Analyzing Urban Networks and Amenities with OSMnx}}, \n type = {Working paper}, \n url = {https://geoffboeing.com/publications/osmnx-paper/}, \n year = {2024}\n}.</translation>
		</message>
		<message>
			<source>Template GIS file not found</source>
			<translation>Nie znaleziono pliku szablonu GIS</translation>
		</message>
		<message>
			<source>Template not managed: {0}</source>
			<translation>Szablon nie jest zarządzany: {0}</translation>
		</message>
		<message>
			<source>Temporal layer created successfully.</source>
			<translation>Warstwa czasowa została utworzona pomyślnie.</translation>
		</message>
		<message>
			<source>The &apos;{0}&apos; field is required.</source>
			<translation>Pole &quot;{0}&quot; jest wymagane.</translation>
		</message>
		<message>
			<source>The active state of the current psector cannot be changed. Current psector: {0}</source>
			<translation>Aktywny stan bieżącego sektora nie może zostać zmieniony. Bieżący sektor: {0}</translation>
		</message>
		<message>
			<source>The configuration file doesn&apos;t match the selected INP file. Some options may not be loaded.</source>
			<translation>Plik konfiguracyjny nie pasuje do wybranego pliku INP. Niektóre opcje mogą nie zostać załadowane.</translation>
		</message>
		<message>
			<source>The configuration file doesn&apos;t match the selected INP file. Some options may not be loaded or may be incorrect. Do you want to continue?</source>
			<translation>Plik konfiguracyjny nie pasuje do wybranego pliku INP. Niektóre opcje mogą nie zostać załadowane lub mogą być nieprawidłowe. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>The connection to the database is broken.</source>
			<translation>Połączenie z bazą danych zostało przerwane.</translation>
		</message>
		<message>
			<source>The connection to the database is broken: {0}</source>
			<translation>Połączenie z bazą danych zostało przerwane: {0}</translation>
		</message>
		<message>
			<source>The csv file has been successfully exported</source>
			<translation>Plik csv został pomyślnie wyeksportowany</translation>
		</message>
		<message>
			<source>The &apos;Description&apos; field is required.</source>
			<translation>Pole &quot;Opis&quot; jest wymagane.</translation>
		</message>
		<message>
			<source>The field layoutname is not configured for</source>
			<translation>Nazwa układu pola nie jest skonfigurowana dla</translation>
		</message>
		<message>
			<source>The field layoutorder is not configured for</source>
			<translation>Układ pola nie jest skonfigurowany dla</translation>
		</message>
		<message>
			<source>The field widgettype is not configured for</source>
			<translation>Typ widżetu pola nie jest skonfigurowany dla</translation>
		</message>
		<message>
			<source>The fifth tab is the &apos;Arcs&apos; tab, where you can select the catalog for each type of arc on the network.</source>
			<translation>Piąta zakładka to zakładka &quot;Łuki&quot;, w której można wybrać katalog dla każdego typu łuku w sieci.</translation>
		</message>
		<message>
			<source>The file {0} already exists. Do you want to overwrite it?</source>
			<translation>Plik {0} już istnieje. Czy chcesz go nadpisać?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.csv&quot; already exists. Do you want to overwrite it?</source>
			<translation>Plik &quot;{0}.csv&quot; już istnieje. Czy chcesz go nadpisać?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.in&quot; already exists. Do you want to overwrite it?</source>
			<translation>Plik &quot;{0}.in&quot; już istnieje. Czy chcesz go nadpisać?</translation>
		</message>
		<message>
			<source>The file &quot;{0}.inp&quot; already exists. Do you want to overwrite it?</source>
			<translation>Plik &quot;{0}.inp&quot; już istnieje. Czy chcesz go nadpisać?</translation>
		</message>
		<message>
			<source>The files {0} already exist. Do you want to overwrite them?</source>
			<translation>Pliki {0} już istnieją. Czy chcesz je nadpisać?</translation>
		</message>
		<message>
			<source>The files &quot;{0}.in&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</source>
			<translation>Pliki &quot;{0}.in&quot; i &quot;{1}.csv&quot; już istnieją. Czy chcesz je nadpisać?</translation>
		</message>
		<message>
			<source>The files &quot;{0}.inp&quot; and &quot;{1}.csv&quot; already exist. Do you want to overwrite them?</source>
			<translation>Pliki &quot;{0}.inp&quot; i &quot;{1}.csv&quot; już istnieją. Czy chcesz je nadpisać?</translation>
		</message>
		<message>
			<source>The file selected is not a GPKG file</source>
			<translation>Wybrany plik nie jest plikiem GPKG</translation>
		</message>
		<message>
			<source>The file selected is not an INP file</source>
			<translation>Wybrany plik nie jest plikiem INP</translation>
		</message>
		<message>
			<source>The first tab is the &apos;Basic&apos; tab, where you can select the exploitation, sector, municipality, and other basic information.</source>
			<translation>Pierwsza zakładka to zakładka &quot;Podstawowe&quot;, w której można wybrać eksploatację, sektor, gminę i inne podstawowe informacje.</translation>
		</message>
		<message>
			<source>The following fields differ between the selected arcs. You are about to merge them using the selected values.</source>
			<translation>The following fields differ between the selected arcs. You are about to merge them using the selected values.</translation>
		</message>
		<message>
			<source>The fourth tab is the &apos;Nodes&apos; tab, where you can select the catalog for each type of node on the network.</source>
			<translation>Czwarta zakładka to zakładka &quot;Węzły&quot;, w której można wybrać katalog dla każdego typu węzła w sieci.</translation>
		</message>
		<message>
			<source>The geometry of `polygon` is invalid.</source>
			<translation>Geometria `polygon` jest nieprawidłowa.</translation>
		</message>
		<message>
			<source>The [JUNCTIONS] section of the configuration file is empty.</source>
			<translation>Sekcja [JUNCTIONS] pliku konfiguracyjnego jest pusta.</translation>
		</message>
		<message>
			<source>The name is current in use</source>
			<translation>Nazwa jest obecnie używana</translation>
		</message>
		<message>
			<source>The name is currently in use</source>
			<translation>Nazwa jest obecnie używana</translation>
		</message>
		<message>
			<source>The node has not been updated because no catalog has been selected</source>
			<translation>Węzeł nie został zaktualizowany, ponieważ nie wybrano żadnego katalogu</translation>
		</message>
		<message>
			<source>The node is obsolete</source>
			<translation>Węzeł jest przestarzały, to narzędzie nie działa z przestarzałymi węzłami.</translation>
		</message>
		<message>
			<source>The node is obsolete, this tool doesn&apos;t work with obsolete nodes.</source>
			<translation>Węzeł jest przestarzały, to narzędzie nie działa z przestarzałymi węzłami.</translation>
		</message>
		<message>
			<source>The number of pages in your composition does not match the number of psectors</source>
			<translation>Liczba stron w kompozycji nie odpowiada liczbie sektorów</translation>
		</message>
		<message>
			<source>The organization name already exists</source>
			<translation>Nazwa organizacji już istnieje</translation>
		</message>
		<message>
			<source>The &apos;Path&apos; field is required for Import INP data.</source>
			<translation>Pole &quot;Ścieżka&quot; jest wymagane w przypadku importu danych INP.</translation>
		</message>
		<message>
			<source>The procedure will delete features on database unless it is a node that doesn&apos;t divide arc.\n
 Please ensure that features has no undelete value on true.\n
 On the other hand you must know that traceability table will storage precedent information.</source>
			<translation>Procedura usunie cechy w bazie danych, chyba że jest to węzeł, który nie dzieli łuku.
 Upewnij się, że cechy nie mają wartości undelete na true.\n
 Z drugiej strony musisz wiedzieć, że tabela identyfikowalności będzie przechowywać informacje poprzedzające.</translation>
		</message>
		<message>
			<source>The procedure will delete features on database unless it is a node that doesn&apos;t divide arcs.</source>
			<translation>Procedura usunie elementy z bazy danych, chyba że jest to węzeł, który nie dzieli łuków.</translation>
		</message>
		<message>
			<source>The procedure will delete features on database unless it is a node that doesn&apos;t divide arcs.\nPlease ensure that features has no undelete value on true.\nOn the other hand you must know that traceability table will storage precedent information.</source>
			<translation>Procedura usunie cechy w bazie danych, chyba że jest to węzeł, który nie dzieli łuków. Upewnij się, że cechy nie mają wartości undelete na true. Z drugiej strony musisz wiedzieć, że tabela identyfikowalności będzie przechowywać informacje poprzedzające.</translation>
		</message>
		<message>
			<source>The process has been executed. Files generated:</source>
			<translation>Proces został wykonany. Wygenerowane pliki:</translation>
		</message>
		<message>
			<source>The project name can&apos;t be a PostgreSQL reserved keyword</source>
			<translation>Nazwa projektu nie może być zastrzeżonym słowem kluczowym PostgreSQL</translation>
		</message>
		<message>
			<source>The project name can&apos;t have any upper-case characters</source>
			<translation>Nazwa projektu nie może zawierać żadnych wielkich liter</translation>
		</message>
		<message>
			<source>The &apos;Project_name&apos; field is required.</source>
			<translation>Pole &quot;Project_name&quot; jest wymagane.</translation>
		</message>
		<message>
			<source>The project name has invalid character</source>
			<translation>Nazwa projektu zawiera nieprawidłowy znak</translation>
		</message>
		<message>
			<source>The QGIS Projects templates was correctly created.</source>
			<translation>Szablony QGIS Projects zostały poprawnie utworzone.</translation>
		</message>
		<message>
			<source>The QML file is invalid</source>
			<translation>Plik QML jest nieprawidłowy</translation>
		</message>
		<message>
			<source>The QML file is invalid.</source>
			<translation>Plik QML jest nieprawidłowy.</translation>
		</message>
		<message>
			<source>There are missing values in these nodes:</source>
			<translation>W tych węzłach brakuje wartości:</translation>
		</message>
		<message>
			<source>There are multiple queries configured. These are the lists that will be used. Do you want to continue?</source>
			<translation>Skonfigurowano wiele zapytań. Są to listy, które będą używane. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>There are multple tabs in order to configure all the necessary catalogs.</source>
			<translation>Dostępnych jest wiele zakładek w celu skonfigurowania wszystkich niezbędnych katalogów.</translation>
		</message>
		<message>
			<source>There are no attribute values.</source>
			<translation>Nie ma żadnych wartości atrybutów.</translation>
		</message>
		<message>
			<source>There are no results available to display.</source>
			<translation>Nie ma dostępnych wyników do wyświetlenia.</translation>
		</message>
		<message>
			<source>There are no visible mincuts in the table. Try a different filter</source>
			<translation>W tabeli nie ma widocznych wycięć minimalnych. Wypróbuj inny filtr lub utwórz filtr</translation>
		</message>
		<message>
			<source>There are no visible mincuts in the table. Try a different filter or make one</source>
			<translation>W tabeli nie ma widocznych wycięć minimalnych. Wypróbuj inny filtr lub utwórz filtr</translation>
		</message>
		<message>
			<source>There are some error in the records with id</source>
			<translation>Występuje błąd w rekordach o id</translation>
		</message>
		<message>
			<source>There have been errors translating:</source>
			<translation>Wystąpiły błędy w tłumaczeniu:</translation>
		</message>
		<message>
			<source>There is an error in the configuration of the pgservice file, please check it or consult your administrator</source>
			<translation>Wystąpił błąd w konfiguracji pliku pgservice, sprawdź go lub skonsultuj się z administratorem.</translation>
		</message>
		<message>
			<source>There is a partially completed file for this folder/file name. Would you like to resume the process?</source>
			<translation>Istnieje częściowo ukończony plik dla tego folderu/nazwy pliku. Czy chcesz wznowić proces?</translation>
		</message>
		<message>
			<source>There is no data in table anl_arc for fid=491 and current user.</source>
			<translation>Brak danych w tabeli anl_arc dla fid=491 i bieżącego użytkownika.</translation>
		</message>
		<message>
			<source>There is no data in table anl_arc for fid=493 and current user.</source>
			<translation>Brak danych w tabeli anl_arc dla fid=493 i bieżącego użytkownika.</translation>
		</message>
		<message>
			<source>There is no project selected or it is not valid. Please check the first tab...</source>
			<translation>Nie wybrano żadnego projektu lub jest on nieprawidłowy. Sprawdź pierwszą kartę...</translation>
		</message>
		<message>
			<source>There is no valid shape curve in the list</source>
			<translation>Na liście nie ma prawidłowej krzywej kształtu</translation>
		</message>
		<message>
			<source>The report timestep must be an integer multiple of the hydraulic timestep. Reducing the hydraulic timestep from {0} seconds to {1} seconds for this simulation.</source>
			<translation>Krok czasowy raportu musi być całkowitą wielokrotnością hydraulicznego kroku czasowego. Zmniejszenie hydraulicznego kroku czasowego z {0} sekund do {1} sekund dla tej symulacji.</translation>
		</message>
		<message>
			<source>The report timestep must be an integer multiple of the hydraulic timestep. Reducing the report timestep from {0} seconds to {1} seconds for this simulation.</source>
			<translation>Krok czasowy raportu musi być całkowitą wielokrotnością hydraulicznego kroku czasowego. Zmniejszenie kroku czasowego raportu z {0} sekund do {1} sekund dla tej symulacji.</translation>
		</message>
		<message>
			<source>The result cannot be deleted</source>
			<translation>Wyniku nie można usunąć</translation>
		</message>
		<message>
			<source>There was an error deleting object.</source>
			<translation>Wystąpił błąd podczas usuwania obiektu.</translation>
		</message>
		<message>
			<source>There was an error deleting object values.</source>
			<translation>Wystąpił błąd podczas usuwania wartości obiektu.</translation>
		</message>
		<message>
			<source>There was an error deleting old curve values.</source>
			<translation>Wystąpił błąd podczas usuwania starych wartości krzywej.</translation>
		</message>
		<message>
			<source>There was an error deleting old lid values.</source>
			<translation>Wystąpił błąd podczas usuwania starych wartości pokrywy.</translation>
		</message>
		<message>
			<source>There was an error deleting old pattern values.</source>
			<translation>Wystąpił błąd podczas usuwania starych wartości wzorca.</translation>
		</message>
		<message>
			<source>There was an error deleting old timeseries values.</source>
			<translation>Wystąpił błąd podczas usuwania starych wartości timeseries.</translation>
		</message>
		<message>
			<source>There was an error inserting control.</source>
			<translation>Wystąpił błąd podczas wstawiania kontroli.</translation>
		</message>
		<message>
			<source>There was an error inserting curve.</source>
			<translation>Wystąpił błąd podczas wstawiania krzywej.</translation>
		</message>
		<message>
			<source>There was an error inserting curve value.</source>
			<translation>Wystąpił błąd podczas wstawiania wartości krzywej.</translation>
		</message>
		<message>
			<source>There was an error inserting lid.</source>
			<translation>Wystąpił błąd podczas wstawiania pokrywy.</translation>
		</message>
		<message>
			<source>There was an error inserting pattern.</source>
			<translation>Wystąpił błąd podczas wstawiania wzorca.</translation>
		</message>
		<message>
			<source>There was an error inserting pattern value.</source>
			<translation>Wystąpił błąd podczas wstawiania wartości wzorca.</translation>
		</message>
		<message>
			<source>There was an error inserting timeseries.</source>
			<translation>Wystąpił błąd podczas wstawiania szeregów czasowych.</translation>
		</message>
		<message>
			<source>There were velocities &gt;50 in the rpt file. You have activated the option to force the import  </source>
			<translation>There were velocities &gt;50 in the rpt file. You have activated the option to force the import  </translation>
		</message>
		<message>
			<source>There were velocities &gt;50 in the rpt file. You have activated the option to force the import so they have been set to 50.</source>
			<translation>W pliku rpt znajdowały się prędkości &gt;50. Aktywowałeś opcję wymuszenia importu, więc zostały one ustawione na 50.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlaped, it seems you need to improve your simulation. Please ckeck and fix it before continue. </source>
			<translation>Plik rpt nie jest prawidłowy do zaimportowania. Ponieważ kolumny w pliku rpt nakładają się na siebie, wygląda na to, że należy poprawić symulację. Sprawdź i popraw to przed kontynuowaniem.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlaped, it seems you need to improve your simulation. Please ckeck and fix it before continue. \n{0}</source>
			<translation>Plik rpt nie jest prawidłowy do zaimportowania. Ponieważ kolumny w pliku rpt nakładają się na siebie, wygląda na to, że należy poprawić symulację. Sprawdź i popraw to przed kontynuowaniem. \n{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlapped, it seems you need to improve your simulation. Please check and fix it before continuing.</source>
			<translation>Plik rpt nie jest prawidłowy do zaimportowania. Ponieważ kolumny w pliku rpt nakładają się na siebie, wygląda na to, że należy poprawić symulację. Sprawdź i popraw to przed kontynuowaniem.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because columns on rpt file are overlapped, it seems you need to improve your simulation. Please check and fix it before continuing.\n{0}</source>
			<translation>Plik rpt nie jest prawidłowy do zaimportowania. Ponieważ kolumny w pliku rpt nakładają się na siebie, wygląda na to, że należy poprawić symulację. Sprawdź i popraw to przed kontynuowaniem.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. </source>
			<translation>Plik rpt nie jest prawidłowy do zaimportowania. Ponieważ prędkość nie ma wartości liczbowej (&gt;50), wygląda na to, że należy poprawić symulację. Sprawdź i popraw to przed kontynuowaniem.</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. \n{0}</source>
			<translation>Plik rpt nie jest prawidłowy do zaimportowania. Ponieważ prędkość nie ma wartości liczbowej (&gt;50), wygląda na to, że należy poprawić symulację. Sprawdź i popraw to przed kontynuowaniem. \n{0}</translation>
		</message>
		<message>
			<source>The rpt file is not valid to import. Because velocity has not numeric value (&gt;50), it seems you need to improve your simulation. Please ckeck and fix it before continue. \nNote: You can force the import by activating the variable &apos;{0}&apos; on the {1} file. \n{2}</source>
			<translation>Plik rpt nie jest prawidłowy do zaimportowania. Ponieważ prędkość nie ma wartości liczbowej (&gt;50), wygląda na to, że należy poprawić symulację. Sprawdź i popraw to przed kontynuowaniem. \Uwaga: Import można wymusić, aktywując zmienną &quot;{0}&quot; w pliku {1}. \n{2}</translation>
		</message>
		<message>
			<source>The [SCENARIOS] section of the configuration file is empty.</source>
			<translation>Sekcja [SCENARIUSZE] pliku konfiguracyjnego jest pusta.</translation>
		</message>
		<message>
			<source>The schema ({0}) does not exists</source>
			<translation>Schemat ({0}) nie istnieje</translation>
		</message>
		<message>
			<source>The schema &apos;{0}&apos; is being used in production! It can&apos;t be deleted.</source>
			<translation>Schemat &apos;{0}&apos; jest używany w produkcji! Nie można go usunąć.</translation>
		</message>
		<message>
			<source>The schema version has to be updated to make rename</source>
			<translation>The schema version has to be updated to make rename</translation>
		</message>
		<message>
			<source>These are the lists that will be used. Do you want to continue?</source>
			<translation>To są listy, które będą używane. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>The second tab is the &apos;Features&apos; tab, where you can select the corresponding feature classes for each type of feature on the network.</source>
			<translation>Druga zakładka to zakładka &quot;Funkcje&quot;, w której można wybrać odpowiednie klasy funkcji dla każdego typu funkcji w sieci.</translation>
		</message>
		<message>
			<source>These items could not be downgrade to state 0</source>
			<translation>Pozycje te nie mogły zostać obniżone do stanu 0</translation>
		</message>
		<message>
			<source>The selected INP file does not match with a &apos;UD&apos; project.n </source>
			<translation>Wybrany plik INP nie pasuje do projektu &quot;UD&quot;.n</translation>
		</message>
		<message>
			<source>The selected INP file does not match with a &apos;UD&apos; project. Please check it before continuing...</source>
			<translation>The selected INP file does not match with a &apos;UD&apos; project. Please check it before continuing...</translation>
		</message>
		<message>
			<source>The selected INP file does not match with a &apos;WS&apos; project.n </source>
			<translation>Wybrany plik INP nie pasuje do projektu &quot;WS&quot;.n</translation>
		</message>
		<message>
			<source>The selected INP file does not match with a &apos;WS&apos; project. Please check it before continuing...</source>
			<translation>Wybrany plik INP nie pasuje do projektu &quot;WS&quot;. Sprawdź to przed kontynuowaniem...</translation>
		</message>
		<message>
			<source>The selected node is planified in another psector.</source>
			<translation>The selected node is planified in another psector.</translation>
		</message>
		<message>
			<source>The selected node should have exactly two linked arcs.</source>
			<translation>Wybrany węzeł powinien mieć dokładnie dwa połączone łuki.</translation>
		</message>
		<message>
			<source>These links could not be located within the network: </source>
			<translation>Łącza te nie mogły zostać zlokalizowane w sieci:</translation>
		</message>
		<message>
			<source>These pipes have been assigned as compliant by default, which may affect their priority value.</source>
			<translation>Rury te zostały domyślnie przypisane jako zgodne, co może mieć wpływ na ich wartość priorytetu.</translation>
		</message>
		<message>
			<source>These pipes have been identified as the configured unknown material, {unknown_material}.</source>
			<translation>Rury te zostały zidentyfikowane jako skonfigurowany nieznany materiał, {unknown_material}.</translation>
		</message>
		<message>
			<source>These pipes have no pressure information for their nodes. This will result in them receiving the maximum longevity value for their material, which may affect the final priority value.</source>
			<translation>Rury te nie mają informacji o ciśnieniu dla swoich węzłów. Spowoduje to, że otrzymają maksymalną wartość żywotności dla ich materiału, co może wpłynąć na ostateczną wartość priorytetu.</translation>
		</message>
		<message>
			<source>These pipes have NOT been assigned a priority value.</source>
			<translation>Przewodom tym NIE przypisano wartości priorytetu.</translation>
		</message>
		<message>
			<source>These pipes have NOT been assigned a priority value as the configured unknown material, {unknown_material}, is not listed in the configuration tab for materials.</source>
			<translation>Rury te NIE mają przypisanej wartości priorytetu, ponieważ skonfigurowany nieznany materiał, {unknown_material}, nie jest wymieniony w zakładce konfiguracji materiałów.</translation>
		</message>
		<message>
			<source>These pipes received the maximum longevity value for their material.</source>
			<translation>Rury te uzyskały maksymalną wartość trwałości dla materiału, z którego zostały wykonane.</translation>
		</message>
		<message>
			<source>These pipes will NOT be assigned a priority value as the configured unknown material, {1}, is not listed in the configuration tab for materials.</source>
			<translation>Rury te NIE będą miały przypisanej wartości priorytetu, ponieważ skonfigurowany nieznany materiał {1} nie jest wymieniony w zakładce konfiguracji materiałów.</translation>
		</message>
		<message>
			<source>These pipes will NOT be assigned a priority value as the configured unknown material, {unknown_material}, is not listed in the configuration tab for materials.</source>
			<translation>Rury te NIE będą miały przypisanej wartości priorytetu, ponieważ skonfigurowany nieznany materiał {unknown_material} nie jest wymieniony w zakładce konfiguracji materiałów.</translation>
		</message>
		<message>
			<source>The start date must be before the end date</source>
			<translation>The start date must be before the end date</translation>
		</message>
		<message>
			<source>The start date real must be before the end date real</source>
			<translation>The start date real must be before the end date real</translation>
		</message>
		<message>
			<source>The state selector is empty</source>
			<translation>Selektor stanu jest pusty</translation>
		</message>
		<message>
			<source>The sum of weights must equal 1. Please adjust the values accordingly.</source>
			<translation>Suma wag musi być równa 1. Należy odpowiednio dostosować wartości.</translation>
		</message>
		<message>
			<source>The table ({0}) does not exists</source>
			<translation>Tabela ({0}) nie istnieje</translation>
		</message>
		<message>
			<source>The table &apos;plan_psector&apos; contains NULL values in the column &apos;atlas_id&apos;. Please fix this before continuing.</source>
			<translation>Tabela &apos;plan_psector&apos; zawiera wartości NULL w kolumnie &apos;atlas_id&apos;. Popraw to przed kontynuowaniem.</translation>
		</message>
		<message>
			<source>The target year must be between {0} and {1}.</source>
			<translation>Rok docelowy musi zawierać się w przedziale od {0} do {1}.</translation>
		</message>
		<message>
			<source>The team name already exists</source>
			<translation>The team name already exists</translation>
		</message>
		<message>
			<source>The team name already exists</source>
			<translation>Nazwa zespołu już istnieje</translation>
		</message>
		<message>
			<source>The third tab is the &apos;Materials&apos; tab, where you can select the corresponding material for each roughness value.</source>
			<translation>Trzecia zakładka to zakładka &quot;Materiały&quot;, w której można wybrać odpowiedni materiał dla każdej wartości chropowatości.</translation>
		</message>
		<message>
			<source>The third tab is the &apos;Materials&apos; tab, where you can select the corresponding roughness value for each material.</source>
			<translation>Trzecia zakładka to zakładka &quot;Materiały&quot;, w której można wybrać odpowiednią wartość chropowatości dla każdego materiału.</translation>
		</message>
		<message>
			<source>The update folder was not found in sql folder</source>
			<translation>Folder aktualizacji nie został znaleziony w folderze sql</translation>
		</message>
		<message>
			<source>The user config files have been recreated. A backup of the broken ones have been created at</source>
			<translation>Pliki konfiguracyjne użytkownika zostały odtworzone. Kopia zapasowa uszkodzonych plików została utworzona pod adresem</translation>
		</message>
		<message>
			<source>The user name already exists</source>
			<translation>Nazwa użytkownika już istnieje</translation>
		</message>
		<message>
			<source>The WNTR numerical solution for flow rate has R2</source>
			<translation>Rozwiązanie numeryczne WNTR dla natężenia przepływu ma wartość R2</translation>
		</message>
		<message>
			<source>The WNTR numerical solution for tank head has R2</source>
			<translation>Rozwiązanie numeryczne WNTR dla głowicy zbiornika ma wartość R2</translation>
		</message>
		<message>
			<source>The Workcat_id &quot;{0}&quot; is already in use. Please enter a different ID.</source>
			<translation>Identyfikator Workcat_id &quot;{0}&quot; jest już używany. Wprowadź inny identyfikator.</translation>
		</message>
		<message>
			<source>The XML file you are loading appears to have been generated by OSMnx: this use case is not supported and may not behave as expected. To save/load graphs to/from disk for later use in OSMnx, use the `io.save_graphml` and `io.load_graphml` functions instead. Refer to the documentation for details.</source>
			<translation>Wczytywany plik XML został wygenerowany przez OSMnx: ten przypadek użycia nie jest obsługiwany i może zachowywać się niezgodnie z oczekiwaniami. Aby zapisać/załadować wykresy na/z dysku do późniejszego użycia w OSMnx, należy użyć funkcji `io.save_graphml` i `io.load_graphml`. Szczegółowe informacje można znaleźć w dokumentacji.</translation>
		</message>
		<message>
			<source>This arc has redundant data on both (elev &amp; y) values. Review it and use only one.</source>
			<translation>Ten łuk ma nadmiarowe dane dotyczące obu wartości (wysokości i y). Przejrzyj go i użyj tylko jednej z nich.</translation>
		</message>
		<message>
			<source>This area is {ratio:,} times your configured Overpass max query area size. It will automatically be divided up into multiple sub-queries accordingly. This may take a long time.</source>
			<translation>Obszar ten jest {ratio:,} razy większy od skonfigurowanego maksymalnego rozmiaru obszaru zapytania Overpass. Zostanie on automatycznie podzielony na wiele podzapytań. Może to zająć dużo czasu.</translation>
		</message>
		<message>
			<source>This behaviour can be configured in the table &apos;config_param_system&apos; (parameter = &apos;basic_selector</source>
			<translation>Zachowanie to można skonfigurować w tabeli &apos;config_param_system&apos; (parametr = &apos;basic_selector</translation>
		</message>
		<message>
			<source>This dma doesn&apos;t exist</source>
			<translation>Ten dma nie istnieje</translation>
		</message>
		<message>
			<source>This feature already has ELEV &amp; TOP_ELEV values! Review it and use at most two</source>
			<translation>Ta funkcja ma już wartości ELEV i TOP_ELEV! Przejrzyj ją i użyj co najwyżej dwóch</translation>
		</message>
		<message>
			<source>This feature already has ELEV values! Review it and use only one</source>
			<translation>Ta funkcja ma już wartości ELEV! Przejrzyj ją i użyj tylko jednej</translation>
		</message>
		<message>
			<source>This feature already has Y &amp; ELEV values! Review it and use at most two</source>
			<translation>Ta funkcja ma już wartości Y i ELEV! Przejrzyj ją i użyj co najwyżej dwóch</translation>
		</message>
		<message>
			<source>This feature already has Y &amp; TOP_ELEV values! Review it and use at most two</source>
			<translation>Ta funkcja ma już wartości Y i TOP_ELEV! Przejrzyj ją i użyj co najwyżej dwóch</translation>
		</message>
		<message>
			<source>This feature already has Y values! Review it and use only one</source>
			<translation>Ta funkcja ma już wartości Y! Przejrzyj ją i użyj tylko jednej</translation>
		</message>
		<message>
			<source>This feature has no log changes, please update this feature before.</source>
			<translation>Ta funkcja nie ma zmian w dzienniku, prosimy o jej wcześniejszą aktualizację.</translation>
		</message>
		<message>
			<source>This functionality is only allowed with the locality &apos;en_US&apos; and SRID 25831.</source>
			<translation>Ta funkcja jest dozwolona tylko w przypadku lokalizacji &quot;en_US&quot; i SRID 25831.</translation>
		</message>
		<message>
			<source>This functionality is only allowed with the locality &apos;en_US&apos; and SRID 25831.\nDo you want change it and continue?</source>
			<translation>Ta funkcja jest dozwolona tylko w przypadku lokalizacji &quot;en_US&quot; i SRID 25831.\nCzy chcesz to zmienić i kontynuować?</translation>
		</message>
		<message>
			<source>This graph has already been simplified, cannot simplify it again.</source>
			<translation>Ten wykres został już uproszczony, nie można go ponownie uprościć.</translation>
		</message>
		<message>
			<source>This graph&apos;s edges have no preexisting &apos;maxspeed&apos; attribute values so you must pass `hwy_speeds` or `fallback` arguments.</source>
			<translation>Krawędzie tego wykresu nie mają wcześniej istniejących wartości atrybutu &quot;maxspeed&quot;, więc musisz przekazać argumenty `hwy_speeds` lub `fallback`.</translation>
		</message>
		<message>
			<source>This id already exists</source>
			<translation>Ten identyfikator już istnieje</translation>
		</message>
		<message>
			<source>This is not a valid Giswater project</source>
			<translation>To nie jest prawidłowy projekt Giswater</translation>
		</message>
		<message>
			<source>This is not a valid Giswater project. Do you want to view problem details?</source>
			<translation>To nie jest prawidłowy projekt Giswater. Czy chcesz zobaczyć szczegóły problemu?</translation>
		</message>
		<message>
			<source>This node has redundant data on (top_elev, ymax &amp; elev) values. Review it and use at most two.</source>
			<translation>Ten węzeł zawiera nadmiarowe dane dotyczące wartości (top_elev, ymax i elev). Przejrzyj go i użyj co najwyżej dwóch.</translation>
		</message>
		<message>
			<source>This parameter is mandatory. Please</source>
			<translation>Ten parametr jest obowiązkowy. Należy ustawić wartość</translation>
		</message>
		<message>
			<source>This parameter is mandatory. Please, set a value</source>
			<translation>Ten parametr jest obowiązkowy. Należy ustawić wartość</translation>
		</message>
		<message>
			<source>This param is mandatory. Please</source>
			<translation>Ten parametr jest obowiązkowy. Proszę, ustaw wartość</translation>
		</message>
		<message>
			<source>This param is mandatory. Please, set a value</source>
			<translation>Ten parametr jest obowiązkowy. Należy ustawić wartość</translation>
		</message>
		<message>
			<source>This presszone doesn&apos;t exist</source>
			<translation>Ta strefa prasowa nie istnieje</translation>
		</message>
		<message>
			<source>This process will active snapshot. Are you sure to continue?</source>
			<translation>Ten proces spowoduje aktywację migawki. Czy na pewno chcesz kontynuować?</translation>
		</message>
		<message>
			<source>This process will take a few seconds. Are you sure to continue?</source>
			<translation>Proces ten zajmie kilka sekund. Czy na pewno chcesz kontynuować?</translation>
		</message>
		<message>
			<source>This process will take time (few minutes). Are you sure to continue?</source>
			<translation>Proces ten zajmie trochę czasu (kilka minut). Czy na pewno chcesz kontynuować?</translation>
		</message>
		<message>
			<source>This &apos;Project_name&apos; already exist. Do you want rename old schema to &apos;{0}&apos;</source>
			<translation>Ten &apos;Project_name&apos; już istnieje. Czy chcesz zmienić nazwę starego schematu na &apos;{0}&apos;?</translation>
		</message>
		<message>
			<source>This project name alredy exist.</source>
			<translation>Ta nazwa projektu już istnieje.</translation>
		</message>
		<message>
			<source>This psector does not match the current one. Value of current psector will be updated.</source>
			<translation>Ten sektor nie pasuje do bieżącego. Wartość bieżącego sektora zostanie zaktualizowana.</translation>
		</message>
		<message>
			<source>This result name already exists</source>
			<translation>Ta nazwa wyniku już istnieje</translation>
		</message>
		<message>
			<source>This SRID value does not exist on Postgres Database. Please select a diferent one.</source>
			<translation>Ta wartość SRID nie istnieje w bazie danych Postgres. Wybierz inną wartość.</translation>
		</message>
		<message>
			<source>This task may take some time to complete, do you want to proceed?</source>
			<translation>Wykonanie tego zadania może zająć trochę czasu, czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>This tool is still in developement, it might not work as intended.</source>
			<translation>To narzędzie jest wciąż w fazie rozwoju i może nie działać zgodnie z przeznaczeniem.</translation>
		</message>
		<message>
			<source>This will also delete all related entries in the sys_style table.Confirm Cascade Delete</source>
			<translation>Spowoduje to również usunięcie wszystkich powiązanych wpisów w tabeli sys_style.Confirm Cascade Delete</translation>
		</message>
		<message>
			<source>This will also delete the database user(s):</source>
			<translation>This will also delete the database user(s):</translation>
		</message>
		<message>
			<source>This will also delete the database user(s):</source>
			<translation>Spowoduje to również usunięcie użytkowników bazy danych:</translation>
		</message>
		<message>
			<source>!!!!! THIS WILL DELETE ALL DATA IN THE DATABASE !!!!!</source>
			<translation>!!!!! SPOWODUJE TO USUNIĘCIE WSZYSTKICH DANYCH Z BAZY DANYCH !!!!!</translation>
		</message>
		<message>
			<source>!!!!! THIS WILL DELETE ALL DATA IN THE DATABASE !!!!!\nARE YOU SURE YOU WANT TO PROCEED?</source>
			<translation>!!!!! TO USUNIE WSZYSTKIE DANE Z BAZY DANYCH !!!!!\czy na pewno chcesz kontynuować?</translation>
		</message>
		<message>
			<source>This will modify your inp file</source>
			<translation>Spowoduje to modyfikację pliku inp, dzięki czemu zostanie utworzona kopia zapasowa.</translation>
		</message>
		<message>
			<source>This will modify your inp file, so a backup will be created.</source>
			<translation>Spowoduje to modyfikację pliku inp, dzięki czemu zostanie utworzona kopia zapasowa.</translation>
		</message>
		<message>
			<source>This will modify your inp file, so a backup will be created.\nDo you want to proceed?</source>
			<translation>Spowoduje to modyfikację pliku inp, więc zostanie utworzona kopia zapasowa.\nCzy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>This wizard will help with the process of importing a network from a {0} INP file into the Giswater database.</source>
			<translation>Ten kreator pomoże w procesie importowania sieci z pliku {0} INP do bazy danych Giswater.</translation>
		</message>
		<message>
			<source>This Workcat already exist</source>
			<translation>Ten Workcat już istnieje</translation>
		</message>
		<message>
			<source>This Workcat is already exist</source>
			<translation>Ten Workcat już istnieje</translation>
		</message>
		<message>
			<source>    title = {{Modeling and Analyzing Urban Networks and Amenities with OSMnx}},</source>
			<translation>    title = {{Modelowanie i analiza sieci miejskich i udogodnień za pomocą OSMnx}},</translation>
		</message>
		<message>
			<source>To make the result id {0} corporate, is necessary to make not corporate the following result ids: {1}. Do you want to proceed?</source>
			<translation>Aby identyfikator wyniku {0} był korporacyjny, konieczne jest, aby następujące identyfikatory wyników nie były korporacyjne: {1}. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>To modify columns (top_elev, ymax, elev among others) to be interpolated set variable edit_node_interpolate on table config_param_user</source>
			<translation>Aby zmodyfikować kolumny (m.in. top_elev, ymax, elev), które mają być interpolowane, ustaw zmienną edit_node_interpolate w tabeli config_param_user.</translation>
		</message>
		<message>
			<source>Toolbox task is already active!</source>
			<translation>Zadanie Toolbox jest już aktywne!</translation>
		</message>
		<message>
			<source>{tools_qt.tr(</source>
			<translation>{tools_qt.tr(</translation>
		</message>
		<message>
			<source>{tools_qt.tr()}</source>
			<translation>{tools_qt.tr()}</translation>
		</message>
		<message>
			<source>{tools_qt.tr()}: {snapped_feature_attr[0]}</source>
			<translation>{tools_qt.tr()}: {snapped_feature_attr[0]}.</translation>
		</message>
		<message>
			<source>{tools_qt.tr()}: {snapped_feature_attr[0]}\n{tools_qt.tr()}\n\n</source>
			<translation>{tools_qt.tr()}: {snapped_feature_attr[0]} {tools_qt.tr()}.</translation>
		</message>
		<message>
			<source>To open psector {0}, it must be activated before.</source>
			<translation>Aby otworzyć sektor {0}, musi on zostać wcześniej aktywowany.</translation>
		</message>
		<message>
			<source>To see the conflicts load the views</source>
			<translation>Aby zobaczyć konflikty, załaduj widoki</translation>
		</message>
		<message>
			<source>Total</source>
			<translation>Łącznie</translation>
		</message>
		<message>
			<source>Total municipalities processed: {0}</source>
			<translation>Łączna liczba przetworzonych gmin: {0}</translation>
		</message>
		<message>
			<source>Total of pipes: {pipes}.</source>
			<translation>Łączna liczba rur: {pipes}.</translation>
		</message>
		<message>
			<source>TRACEABILITY</source>
			<translation>TRACEABILITY</translation>
		</message>
		<message>
			<source>translation canceled</source>
			<translation>tłumaczenie anulowane</translation>
		</message>
		<message>
			<source>translation failed in table</source>
			<translation>tłumaczenie w tabeli nie powiodło się</translation>
		</message>
		<message>
			<source>translation successful</source>
			<translation>tłumaczenie zakończone sukcesem</translation>
		</message>
		<message>
			<source>Tried to set {0} to &apos;{1}&apos; but it&apos;s not an integer. Defaulting to 4 threads.</source>
			<translation>Próbowałem ustawić {0} na &apos;{1}&apos;, ale nie jest to liczba całkowita. Domyślnie 4 wątki.</translation>
		</message>
		<message>
			<source>Triggers updated successfully</source>
			<translation>Wyzwalacze zostały pomyślnie zaktualizowane</translation>
		</message>
		<message>
			<source>Truncated graph by bounding box</source>
			<translation>Wykres obcięty przez obwiednię</translation>
		</message>
		<message>
			<source>Truncated graph by polygon</source>
			<translation>Wykres obcięty przez wielokąt</translation>
		</message>
		<message>
			<source>Try again</source>
			<translation>Spróbuj ponownie</translation>
		</message>
		<message>
			<source>Typeahead &apos;{0}&apos; doesn&apos;t have neither a queryText nor comboIds/comboNames.</source>
			<translation>Typeahead &quot;{0}&quot; nie ma ani queryText, ani comboIds/comboNames.</translation>
		</message>
		<message>
			<source>    type = {Working paper},</source>
			<translation>    type = {Working paper},</translation>
		</message>
		<message>
			<source>Uknown</source>
			<translation>Uknown</translation>
		</message>
		<message>
			<source>Unable to create &apos;{extension}&apos; extension. Packages must be installed, consult your administrator.</source>
			<translation>Nie można utworzyć rozszerzenia &apos;{extension}&apos;. Pakiety muszą być zainstalowane, skonsultuj się z administratorem.</translation>
		</message>
		<message>
			<source>Unable to create fuzzystrmatch extension. Packages must be installed</source>
			<translation>Nie można utworzyć rozszerzenia fuzzystrmatch. Pakiety muszą być zainstalowane, skonsultuj się z administratorem</translation>
		</message>
		<message>
			<source>(Unable to create one extension. Packages must be installed, consult your administrator)</source>
			<translation>(Nie można utworzyć jednego rozszerzenia. Pakiety muszą być zainstalowane, skonsultuj się z administratorem)</translation>
		</message>
		<message>
			<source>Unable to create Postgis extension. Packages must be installed</source>
			<translation>Nie można utworzyć rozszerzenia Postgis. Pakiety muszą być zainstalowane, skonsultuj się z administratorem</translation>
		</message>
		<message>
			<source>Unable to highlight the snapped node.</source>
			<translation>Nie można podświetlić przyciągniętego węzła.</translation>
		</message>
		<message>
			<source>Undefined error</source>
			<translation>Niezdefiniowany błąd</translation>
		</message>
		<message>
			<source>Unexpected json_data structure!</source>
			<translation>Nieoczekiwana struktura json_data!</translation>
		</message>
		<message>
			<source>Unhandled Error</source>
			<translation>Nieobsługiwany błąd</translation>
		</message>
		<message>
			<source>Unknown context: {0}, skipping.</source>
			<translation>Nieznany kontekst: {0}, pomijanie.</translation>
		</message>
		<message>
			<source>Unrecognised form type</source>
			<translation>Nierozpoznany typ formularza</translation>
		</message>
		<message>
			<source>Unsuported geometry type</source>
			<translation>Nieobsługiwany typ geometrii</translation>
		</message>
		<message>
			<source>Update configuration</source>
			<translation>Konfiguracja aktualizacji</translation>
		</message>
		<message>
			<source>Update Confirmation</source>
			<translation>Potwierdzenie aktualizacji</translation>
		</message>
		<message>
			<source>Update records</source>
			<translation>Aktualizacja rekordów</translation>
		</message>
		<message>
			<source>Updating {0}...</source>
			<translation>Aktualizacja {0}...</translation>
		</message>
		<message>
			<source>Updating tables</source>
			<translation>Aktualizacja tabel</translation>
		</message>
		<message>
			<source>    url = {https://geoffboeing.com/publications/osmnx-paper/},</source>
			<translation>    url = {https://geoffboeing.com/publications/osmnx-paper/},</translation>
		</message>
		<message>
			<source>User</source>
			<translation>User</translation>
		</message>
		<message>
			<source>User &apos;{0}&apos; was created, but failed to grant roles (&apos;{1}&apos;, &apos;role_basic&apos;).</source>
			<translation>Użytkownik &apos;{0}&apos; został utworzony, ale nie udało się przyznać ról (&apos;{1}&apos;, &apos;role_basic&apos;).</translation>
		</message>
		<message>
			<source>User not found</source>
			<translation>Nie znaleziono użytkownika</translation>
		</message>
		<message>
			<source>User set `doh_url_template=None`, requesting host by name</source>
			<translation>Użytkownik ustawił `doh_url_template=None`, żądając hosta według nazwy</translation>
		</message>
		<message>
			<source>User settings file: {0}</source>
			<translation>Plik ustawień użytkownika: {0}</translation>
		</message>
		<message>
			<source>Vacuum executed: {0}.{1}</source>
			<translation>Wykonano próżnię: {0}.{1}</translation>
		</message>
		<message>
			<source>VALUE DOMAIN</source>
			<translation>DOMENA WARTOŚCI</translation>
		</message>
		<message>
			<source>Value in addparam must be in a json format</source>
			<translation>Wartość w addparam musi być w formacie json</translation>
		</message>
		<message>
			<source>Values has been updated</source>
			<translation>Wartości zostały zaktualizowane</translation>
		</message>
		<message>
			<source>Values saved successfully.</source>
			<translation>Wartości zapisane pomyślnie.</translation>
		</message>
		<message>
			<source>Valve analytics executed successfully</source>
			<translation>Analityka zaworów wykonana pomyślnie</translation>
		</message>
		<message>
			<source>Variable log_sql from user config file has been disabled.</source>
			<translation>Zmienna log_sql z pliku konfiguracyjnego użytkownika została wyłączona.</translation>
		</message>
		<message>
			<source>Variable log_sql from user config file has been enabled.</source>
			<translation>Zmienna log_sql z pliku konfiguracyjnego użytkownika została włączona.</translation>
		</message>
		<message>
			<source>Version</source>
			<translation>Wersja</translation>
		</message>
		<message>
			<source>Version: {self.project_version}</source>
			<translation>Wersja: {self.project_version}</translation>
		</message>
		<message>
			<source>VISIT</source>
			<translation>WIZYTA</translation>
		</message>
		<message>
			<source>Warning</source>
			<translation>Ostrzeżenie</translation>
		</message>
		<message>
			<source>WARNING</source>
			<translation>OSTRZEŻENIE</translation>
		</message>
		<message>
			<source>Warning: Are you sure to continue?. This button will update your plugin qgis templates file replacing all strings defined on the config/dev.config file. Be sure your config file is OK before continue</source>
			<translation>Ostrzeżenie: Czy na pewno kontynuować? Ten przycisk zaktualizuje plik szablonów wtyczki qgis, zastępując wszystkie ciągi zdefiniowane w pliku config/dev.config. Przed kontynuowaniem upewnij się, że plik konfiguracyjny jest w porządku</translation>
		</message>
		<message>
			<source>Warnings:</source>
			<translation>Ostrzeżenia:</translation>
		</message>
		<message>
			<source>WARNING: This will remove the &apos;utils_workspace_current&apos; variable for your user!</source>
			<translation>OSTRZEŻENIE: Spowoduje to usunięcie zmiennej &quot;utils_workspace_current&quot; dla użytkownika!</translation>
		</message>
		<message>
			<source>WARNING: This will remove the &apos;utils_workspace_current&apos; variable for your user!\nAre you sure you want to delete these records?</source>
			<translation>OSTRZEŻENIE: Spowoduje to usunięcie zmiennej &quot;utils_workspace_current&quot; dla użytkownika! Czy na pewno chcesz usunąć te rekordy?</translation>
		</message>
		<message>
			<source>WARNING: You have updated the status value to CANCELED (Save Trace). If you click &apos;Accept&apos; on  </source>
			<translation>OSTRZEŻENIE: Zaktualizowałeś wartość statusu do CANCELED (Save Trace). Jeśli klikniesz &quot;Akceptuj&quot; na</translation>
		</message>
		<message>
			<source>WARNING: You have updated the status value to EXECUTED (Save Trace). If you click &apos;Accept&apos; on  </source>
			<translation>OSTRZEŻENIE: Wartość statusu została zaktualizowana do EXECUTED (Save Trace). Jeśli klikniesz &quot;Akceptuj&quot; na</translation>
		</message>
		<message>
			<source>WARNING: You have updated the status value to EXECUTED (Set OPERATIVE and Save Trace). If you  </source>
			<translation>OSTRZEŻENIE: Wartość statusu została zaktualizowana do EXECUTED (Ustaw OPERATIVE i Save Trace). Jeśli</translation>
		</message>
		<message>
			<source>Weights</source>
			<translation>Wagi</translation>
		</message>
		<message>
			<source>`which_result` length must equal `query` length.</source>
			<translation>Długość `which_result` musi być równa długości `query`.</translation>
		</message>
		<message>
			<source>widget {0} has associated function {1}, but {2} not exist</source>
			<translation>widget {0} ma powiązaną funkcję {1}, ale {2} nie istnieje</translation>
		</message>
		<message>
			<source>widget {0} has not columnname and can&apos;t be configured</source>
			<translation>widget {0} nie ma nazwy kolumny i nie może zostać skonfigurowany</translation>
		</message>
		<message>
			<source>widget {0} has not columnname and cant be configured</source>
			<translation>widget {0} nie ma nazwy kolumny i nie może zostać skonfigurowany</translation>
		</message>
		<message>
			<source>widget {0} have associated function {1}, but {2} not exist</source>
			<translation>widget {0} ma powiązaną funkcję {1}, ale {2} nie istnieje</translation>
		</message>
		<message>
			<source>widget {0} in tab {1} has not columnname and can&apos;t be configured</source>
			<translation>widżet {0} w zakładce {1} nie ma nazwy kolumny i nie można go skonfigurować</translation>
		</message>
		<message>
			<source>widget {0} in tab {1} has not columnname and cant be configured</source>
			<translation>widżet {0} w zakładce {1} nie ma nazwy kolumny i nie może zostać skonfigurowany</translation>
		</message>
		<message>
			<source>Widget {0} is not configured or have a bad config</source>
			<translation>Widżet {0} nie jest skonfigurowany lub ma nieprawidłową konfigurację</translation>
		</message>
		<message>
			<source>Widget: {0} not in form.</source>
			<translation>Widget: {0} nie w formularzu.</translation>
		</message>
		<message>
			<source>Widget expl_id not found</source>
			<translation>Nie znaleziono widgetu expl_id</translation>
		</message>
		<message>
			<source>Widget is not a QTableView</source>
			<translation>Widget nie jest QTableView</translation>
		</message>
		<message>
			<source>Widget model is none: {0}</source>
			<translation>Brak modelu widżetu: {0}</translation>
		</message>
		<message>
			<source>widgetname not found. </source>
			<translation>widgetname nie został znaleziony.</translation>
		</message>
		<message>
			<source>Widget not found</source>
			<translation>Nie znaleziono widżetu</translation>
		</message>
		<message>
			<source>widgettype is wrongly configured. Needs to be in </source>
			<translation>widgettype jest nieprawidłowo skonfigurowany. Musi być w</translation>
		</message>
		<message>
			<source>widgettype not found. </source>
			<translation>widgettype nie został znaleziony.</translation>
		</message>
		<message>
			<source>Without replacements</source>
			<translation>Bez zamienników</translation>
		</message>
		<message>
			<source>With replacements</source>
			<translation>With replacements</translation>
		</message>
		<message>
			<source>Workcat created successfully.</source>
			<translation>Aplikacja Workcat została utworzona pomyślnie.</translation>
		</message>
		<message>
			<source>Work_id field is empty</source>
			<translation>Pole Work_id jest puste</translation>
		</message>
		<message>
			<source>Write inp file........: {0}</source>
			<translation>Write inp file........: {0}</translation>
		</message>
		<message>
			<source>`X` and `Y` cannot contain nulls.</source>
			<translation>`X` i `Y` nie mogą zawierać zer.</translation>
		</message>
		<message>
			<source>Year</source>
			<translation>Rok</translation>
		</message>
		<message>
			<source>    year = {2024}</source>
			<translation>    year = {2024}</translation>
		</message>
		<message>
			<source>You are about to delete the result</source>
			<translation>Zamierzasz usunąć wynik</translation>
		</message>
		<message>
			<source>You are about to delete the result </source>
			<translation>Zamierzasz usunąć wynik</translation>
		</message>
		<message>
			<source>You are about to import the INP file in TESTING MODE. This will delete all the data in the database related to the network you are importing. Are you sure you want to proceed?</source>
			<translation>Zamierzasz zaimportować plik INP w TRYBIE TESTOWYM. Spowoduje to usunięcie wszystkich danych z bazy danych związanych z importowaną siecią. Czy na pewno chcesz kontynuować?</translation>
		</message>
		<message>
			<source>You are about to load some CM layers to the following file: {0}</source>
			<translation>Zamierzasz załadować kilka warstw CM do następującego pliku: {0}</translation>
		</message>
		<message>
			<source>You are about to load some CM layers to the following file: {0}\n\nAre you sure you want to continue?</source>
			<translation>Zamierzasz załadować kilka warstw CM do następującego pliku: {0}\n\nCzy na pewno chcesz kontynuować?</translation>
		</message>
		<message>
			<source>You are about to perform this action aiming to the following file: {0}</source>
			<translation>Masz zamiar wykonać tę akcję, kierując się do następującego pliku: {0}</translation>
		</message>
		<message>
			<source>You are about to perform this action aiming to the following file: {0}\n\nAre you sure you want to continue?</source>
			<translation>Masz zamiar wykonać tę akcję, kierując się do następującego pliku: {0}\n\nCzy na pewno chcesz kontynuować?</translation>
		</message>
		<message>
			<source>You are about to perform this action aiming to the following schema: {0}</source>
			<translation>Masz zamiar wykonać tę akcję, dążąc do następującego schematu: {0}</translation>
		</message>
		<message>
			<source>You are going to change the epa_type. With this operation you will lose information about current epa_type values of this object. Would you like to continue?</source>
			<translation>Zamierzasz zmienić typ epa_type. Ta operacja spowoduje utratę informacji o bieżących wartościach epa_type tego obiektu. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>You are going to lose previous information!</source>
			<translation>Utracisz poprzednie informacje!</translation>
		</message>
		<message>
			<source>You are going to make this result corporate. From now on the result values will appear on feature form. Do you want to continue?</source>
			<translation>Zamierzasz uczynić ten wynik korporacyjnym. Od teraz wartości wyników będą wyświetlane na formularzu funkcji. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>You are not enabled to modify this {0} widget</source>
			<translation>Nie możesz modyfikować tego widżetu {0}</translation>
		</message>
		<message>
			<source>You are not enabled to modify this epa_type widget</source>
			<translation>Nie możesz modyfikować tego widżetu epa_type</translation>
		</message>
		<message>
			<source>You are trying to add/remove a record from the table, with changes to the current records. If you continue, the changes will be discarded without saving. Do you want to continue?</source>
			<translation>Próbujesz dodać/usunąć rekord z tabeli, wprowadzając zmiany w bieżących rekordach. Jeśli będziesz kontynuować, zmiany zostaną odrzucone bez zapisania. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>You are trying to add/remove a record from the table, with changes to the current records.If you continue, the changes will be discarded without saving. Do you want to continue?</source>
			<translation>Próbujesz dodać/usunąć rekord z tabeli, ze zmianami w bieżących rekordach. Jeśli będziesz kontynuować, zmiany zostaną odrzucone bez zapisania. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>You are trying to delete your current psector. Please, change your current psector before delete.</source>
			<translation>Próbujesz usunąć bieżący sektor. Przed usunięciem zmień bieżący sektor.</translation>
		</message>
		<message>
			<source>You are trying to enter different types</source>
			<translation>Próbujesz wprowadzić różne typy</translation>
		</message>
		<message>
			<source>You can change it and use &apos;Update Style&apos; to create a personalized version.</source>
			<translation>Możesz go zmienić i użyć opcji &quot;Aktualizuj styl&quot;, aby utworzyć spersonalizowaną wersję.</translation>
		</message>
		<message>
			<source>You cannot change the status of a result with status &apos;FINISHED&apos;.</source>
			<translation>Nie można zmienić statusu wyniku o statusie &quot;ZAKOŃCZONY&quot;.</translation>
		</message>
		<message>
			<source>You cannot insert more than one feature at the same time</source>
			<translation>Nie możesz wstawić więcej niż jednego elementu w tym samym czasie, zakończ edycję poprzedniego elementu</translation>
		</message>
		<message>
			<source>You cannot insert more than one feature at the same time, finish editing the previous feature</source>
			<translation>Nie możesz wstawić więcej niż jednego elementu w tym samym czasie, zakończ edycję poprzedniego elementu</translation>
		</message>
		<message>
			<source>You can only delete results with the status &apos;CANCELED&apos;.</source>
			<translation>Usunąć można tylko wyniki o statusie &quot;ANULOWANE&quot;.</translation>
		</message>
		<message>
			<source>You can save the current configuration to a file and load it later, or load the last saved configuration.</source>
			<translation>Można zapisać bieżącą konfigurację do pliku i wczytać ją później lub wczytać ostatnio zapisaną konfigurację.</translation>
		</message>
		<message>
			<source>You can&apos;t delete these mincuts because they aren&apos;t planified </source>
			<translation>Nie można usunąć tych wycinków, ponieważ nie są zaplanowane</translation>
		</message>
		<message>
			<source>You can&apos;t delete these mincuts because they aren&apos;t planified \nor they were created by another user:</source>
			<translation>Nie możesz usunąć tych wycinków, ponieważ nie zostały one zaplanowane ani utworzone przez innego użytkownika:</translation>
		</message>
		<message>
			<source>You closed a valve</source>
			<translation>Zamknięcie zaworu spowoduje modyfikację bieżących stref mapy i może zająć trochę czasu.</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time.</source>
			<translation>Zamknięcie zaworu spowoduje modyfikację bieżących stref mapy i może zająć trochę czasu.</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time. Would you like to continue?</source>
			<translation>Zamknąłeś zawór, co spowoduje modyfikację bieżących stref mapy i może zająć trochę czasu. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>You closed a valve, this will modify the current mapzones and it may take a little bit of time.Would you like to continue?</source>
			<translation>Zamknąłeś zawór, zmodyfikuje to bieżące strefy mapy i może zająć trochę czasu. Chcesz kontynuować?</translation>
		</message>
		<message>
			<source>You do not have any connection to PostGIS database configurated.</source>
			<translation>You do not have any connection to PostGIS database configurated.</translation>
		</message>
		<message>
			<source>You do not have any connection to PostGIS database configurated. Check your QGIS data source manager and create at least one</source>
			<translation>You do not have any connection to PostGIS database configurated. Check your QGIS data source manager and create at least one</translation>
		</message>
		<message>
			<source>You do not have permissions to administrate project schemas on this connection</source>
			<translation>You do not have permissions to administrate project schemas on this connection</translation>
		</message>
		<message>
			<source>(You do not have permissions to administrate project schemas. Please contact your administrator)</source>
			<translation>(You do not have permissions to administrate project schemas. Please contact your administrator)</translation>
		</message>
		<message>
			<source>You do not have permission to execute this application</source>
			<translation>Nie masz uprawnień do uruchomienia tej aplikacji</translation>
		</message>
		<message>
			<source>You don&apos;t have any connection to PostGIS database configurated.  </source>
			<translation>Nie skonfigurowano żadnego połączenia z bazą danych PostGIS.  </translation>
		</message>
		<message>
			<source>You don&apos;t have any connection to PostGIS database configurated. Check your QGIS data source manager and create at least one</source>
			<translation>Nie skonfigurowano żadnego połączenia z bazą danych PostGIS. Sprawdź menedżera źródeł danych QGIS i utwórz co najmniej jedno połączenie z bazą danych PostGIS.</translation>
		</message>
		<message>
			<source>You don&apos;t have permissions to administrate project schemas on this connection</source>
			<translation>Nie masz uprawnień do administrowania schematami projektów w tym połączeniu</translation>
		</message>
		<message>
			<source>You have selected multiple documents. In this case, name will be a sequential number for all selected documents and your name won&apos;t be used.</source>
			<translation>Wybrano wiele dokumentów. W takim przypadku nazwa będzie kolejnym numerem dla wszystkich wybranych dokumentów, a nazwa użytkownika nie zostanie użyta.</translation>
		</message>
		<message>
			<source>You have to fill in &apos;date&apos;</source>
			<translation>Musisz wypełnić pola &quot;czas&quot; i &quot;wartość&quot;!</translation>
		</message>
		<message>
			<source>You have to fill in &apos;date&apos;, &apos;time&apos; and &apos;value&apos; fields!</source>
			<translation>Musisz wypełnić pola &quot;data&quot;, &quot;godzina&quot; i &quot;wartość&quot;!</translation>
		</message>
		<message>
			<source>You have to fill in &apos;time&apos; and &apos;value&apos; fields!</source>
			<translation>Musisz wypełnić pola &quot;czas&quot; i &quot;wartość&quot;!</translation>
		</message>
		<message>
			<source>You have to import a ibergis GPKG project first</source>
			<translation>Najpierw należy zaimportować projekt ibergis GPKG</translation>
		</message>
		<message>
			<source>You have to select at least one feature!</source>
			<translation>Musisz wybrać co najmniej jedną funkcję!</translation>
		</message>
		<message>
			<source>You have to set this parameter</source>
			<translation>Należy ustawić ten parametr</translation>
		</message>
		<message>
			<source>You have to set this parameter: INP file</source>
			<translation>You have to set this parameter: INP file</translation>
		</message>
		<message>
			<source>You have to set this parameter: RPT file</source>
			<translation>You have to set this parameter: RPT file</translation>
		</message>
		<message>
			<source>You must choose at least one action</source>
			<translation>You must choose at least one action</translation>
		</message>
		<message>
			<source>You must pass at least 1 route.</source>
			<translation>Musisz przejść co najmniej 1 trasę.</translation>
		</message>
		<message>
			<source>You must pass one and only one of `filepath` or `graphml_str`.</source>
			<translation>Musisz przekazać jedną i tylko jedną z `filepath` lub `graphml_str`.</translation>
		</message>
		<message>
			<source>You must request nodes or edges or both.</source>
			<translation>Musisz poprosić o węzły lub krawędzie, lub jedno i drugie.</translation>
		</message>
		<message>
			<source>You must select two different points</source>
			<translation>Musisz wybrać dwa różne punkty</translation>
		</message>
		<message>
			<source>You need at least one row of values.</source>
			<translation>Potrzebny jest co najmniej jeden wiersz wartości.</translation>
		</message>
		<message>
			<source>You need to enter a customer code</source>
			<translation>Należy wprowadzić kod klienta</translation>
		</message>
		<message>
			<source>You need to enter a feature id</source>
			<translation>Należy wprowadzić identyfikator funkcji</translation>
		</message>
		<message>
			<source>You need to enter a psector name</source>
			<translation>Należy wprowadzić nazwę sektora</translation>
		</message>
		<message>
			<source>You need to enter a visit ID</source>
			<translation>Należy wprowadzić identyfikator wizyty</translation>
		</message>
		<message>
			<source>You need to enter a workcat id</source>
			<translation>Należy wprowadzić identyfikator workcat</translation>
		</message>
		<message>
			<source>You need to enter hydrometer_id</source>
			<translation>Należy wprowadzić hydrometer_id</translation>
		</message>
		<message>
			<source>You need to have a mesh</source>
			<translation>Musisz mieć siatkę</translation>
		</message>
		<message>
			<source>You need to have a ws and ud schema created to create a utils schema</source>
			<translation>Musisz mieć utworzony schemat ws i ud, aby utworzyć schemat utils</translation>
		</message>
		<message>
			<source>You need to insert a document name</source>
			<translation>Należy wstawić nazwę dokumentu</translation>
		</message>
		<message>
			<source>You need to insert data</source>
			<translation>Musisz wstawić dane</translation>
		</message>
		<message>
			<source>You need to insert doc_id</source>
			<translation>Należy wstawić doc_id</translation>
		</message>
		<message>
			<source>You need to insert doc_type</source>
			<translation>Należy wstawić doc_type</translation>
		</message>
		<message>
			<source>You need to insert psector_id</source>
			<translation>Należy wstawić psector_id</translation>
		</message>
		<message>
			<source>You need to insert value for field</source>
			<translation>Należy wstawić wartość dla pola</translation>
		</message>
		<message>
			<source>You need to insert visit_id</source>
			<translation>Musisz wstawić visit_id</translation>
		</message>
		<message>
			<source>You need to select a template</source>
			<translation>Należy wybrać szablon</translation>
		</message>
		<message>
			<source>You need to select at least one process</source>
			<translation>Należy wybrać co najmniej jeden proces</translation>
		</message>
		<message>
			<source>You need to select a valid parameter id</source>
			<translation>Należy wybrać prawidłowy identyfikator parametru</translation>
		</message>
		<message>
			<source>You need to select same version for ws and ud projects. Versions: WS - {} ; UD - {}</source>
			<translation>Należy wybrać tę samą wersję dla projektów ws i ud. Wersje: WS - {} ; UD - {}</translation>
		</message>
		<message>
			<source>You need to select some sector</source>
			<translation>Musisz wybrać jakiś sektor</translation>
		</message>
		<message>
			<source>You need to upgrade your version of pg_routing!</source>
			<translation>Musisz zaktualizować swoją wersję pg_routing!</translation>
		</message>
		<message>
			<source>You need to upgrade your version of pgRouting</source>
			<translation>Musisz zaktualizować swoją wersję pgRouting</translation>
		</message>
		<message>
			<source>Your composer&apos;s path is bad configured. Please</source>
			<translation>Ścieżka kompozytora jest źle skonfigurowana. Zmodyfikuj ją i spróbuj ponownie.</translation>
		</message>
		<message>
			<source>Your composer&apos;s path is bad configured. Please, modify it and try again.</source>
			<translation>Ścieżka kompozytora jest źle skonfigurowana. Zmodyfikuj ją i spróbuj ponownie.</translation>
		</message>
		<message>
			<source>Your exploitation selector has been updated</source>
			<translation>Selektor eksploatacji został zaktualizowany</translation>
		</message>
		<message>
			<source>You should inform a file name!</source>
			<translation>Powinieneś podać nazwę pliku!</translation>
		</message>
		<message>
			<source>You should select a config file!</source>
			<translation>Powinieneś wybrać plik konfiguracyjny!</translation>
		</message>
		<message>
			<source>You should select an config file!</source>
			<translation>Powinieneś wybrać plik konfiguracyjny!</translation>
		</message>
		<message>
			<source>You should select an input INP file!</source>
			<translation>Należy wybrać wejściowy plik INP!</translation>
		</message>
		<message>
			<source>You should select an output folder!</source>
			<translation>Należy wybrać folder wyjściowy!</translation>
		</message>
		<message>
			<source>You will need to restart QGIS or reload Giswater plugin to apply changes. Do you want continue?</source>
			<translation>You will need to restart QGIS or reload Giswater plugin to apply changes. Do you want continue?</translation>
		</message>
		<message>
			<source>You will need to restart QGIS to apply changes. Do you want continue?</source>
			<translation>Aby zastosować zmiany, konieczne będzie ponowne uruchomienie QGIS. Czy chcesz kontynuować?</translation>
		</message>
		<message>
			<source>Zoom unavailable. Doesn&apos;t exist the geometry for the street</source>
			<translation>Powiększenie niedostępne. Nie istnieje geometria dla ulicy</translation>
		</message>
	</context>
<!-- UI TRANSLATION -->
	<context>
		<name>add_campaign</name>
		<message>
			<source>title</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>dlg_add_campaign</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_campaign</source>
			<translation>dlg_add_campaign</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relacja elementów</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Relacja elementów</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_inventory</name>
		<message>
			<source>add_campaign</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relacje między elementami</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_review</name>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relacje między elementami</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_review_old</name>
		<message>
			<source>action_selector</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_action_selector</source>
			<translation>action_selector</translation>
		</message>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>active</source>
			<translation>Aktywny:</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_export_rel</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_export_rel</source>
			<translation>campaign_btn_export_rel</translation>
		</message>
		<message>
			<source>campaign_btn_path_rel</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_path_rel</source>
			<translation>campaign_btn_path_rel</translation>
		</message>
		<message>
			<source>CampaignTab</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tooltip_CampaignTab</source>
			<translation>CampaignTab</translation>
		</message>
		<message>
			<source>grb_campaign</source>
			<translation>Kampania:</translation>
		</message>
		<message>
			<source>tooltip_grb_campaign</source>
			<translation>grb_campaign</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Ćwiczenie:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Seria:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Inici real:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Fi real:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Organizacja:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Czas trwania:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Adres:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Typ elementu:</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>label_feature_type</translation>
		</message>
		<message>
			<source>label_flexunion_code_5</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_label_flexunion_code_5</source>
			<translation>label_flexunion_code_5</translation>
		</message>
		<message>
			<source>label_node_type</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type</source>
			<translation>label_node_type</translation>
		</message>
		<message>
			<source>label_node_type_2</source>
			<translation>Planowany koniec:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_2</source>
			<translation>label_node_type_2</translation>
		</message>
		<message>
			<source>label_node_type_3</source>
			<translation>Planowany start:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_3</source>
			<translation>label_node_type_3</translation>
		</message>
		<message>
			<source>label_node_type_5</source>
			<translation>Rotacja:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_5</source>
			<translation>label_node_type_5</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Relacje między elementami</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>RelationsTab</translation>
		</message>
		<message>
			<source>reviewclass_id</source>
			<translation>Klasa recenzji:</translation>
		</message>
		<message>
			<source>tooltip_reviewclass_id</source>
			<translation>reviewclass_id</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_visit</name>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Odwiedź</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relacje między elementami</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
	</context>
	<context>
		<name>add_campaign_visit_old</name>
		<message>
			<source>action_selector</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_action_selector</source>
			<translation>action_selector</translation>
		</message>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>active</source>
			<translation>Aktywny:</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>add_campaign</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>tooltip_add_campaign</source>
			<translation>add_campaign</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_export_rel</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_export_rel</source>
			<translation>campaign_btn_export_rel</translation>
		</message>
		<message>
			<source>campaign_btn_path_rel</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_path_rel</source>
			<translation>campaign_btn_path_rel</translation>
		</message>
		<message>
			<source>CampaignTab</source>
			<translation>Kampania</translation>
		</message>
		<message>
			<source>tooltip_CampaignTab</source>
			<translation>CampaignTab</translation>
		</message>
		<message>
			<source>grb_campaign</source>
			<translation>Kampania:</translation>
		</message>
		<message>
			<source>tooltip_grb_campaign</source>
			<translation>grb_campaign</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Ćwiczenie:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Seria:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Prawdziwy początek:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Prawdziwy koniec:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Organizacja:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Czas trwania:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Adres:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Typ elementu</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>label_feature_type</translation>
		</message>
		<message>
			<source>label_flexunion_code_5</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_label_flexunion_code_5</source>
			<translation>label_flexunion_code_5</translation>
		</message>
		<message>
			<source>label_node_type</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type</source>
			<translation>label_node_type</translation>
		</message>
		<message>
			<source>label_node_type_2</source>
			<translation>Planowany koniec:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_2</source>
			<translation>label_node_type_2</translation>
		</message>
		<message>
			<source>label_node_type_3</source>
			<translation>Planowany start:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_3</source>
			<translation>label_node_type_3</translation>
		</message>
		<message>
			<source>label_node_type_5</source>
			<translation>Rotacja:</translation>
		</message>
		<message>
			<source>tooltip_label_node_type_5</source>
			<translation>label_node_type_5</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Relacje między elementami</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>RelationsTab</translation>
		</message>
		<message>
			<source>visitclass_id</source>
			<translation>Klasa odwiedzin:</translation>
		</message>
		<message>
			<source>tooltip_visitclass_id</source>
			<translation>visitclass_id</translation>
		</message>
	</context>
	<context>
		<name>add_demand_check</name>
		<message>
			<source>title</source>
			<translation>Dodatkowa kontrola popytu</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_add_demand_check</source>
			<translation>Dodatkowa kontrola popytu</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_demand_check</source>
			<translation>dlg_add_demand_check</translation>
		</message>
		<message>
			<source>lbl_config</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config</source>
			<translation>lbl_config</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Plik wejściowy INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Użyj węzłów z:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Folder wyjściowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>rdb_nodes_config</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_config</source>
			<translation>rdb_nodes_config</translation>
		</message>
		<message>
			<source>rdb_nodes_database</source>
			<translation>Baza danych</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_database</source>
			<translation>rdb_nodes_database</translation>
		</message>
	</context>
	<context>
		<name>add_lot</name>
		<message>
			<source>title</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>add_lot</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>tooltip_add_lot</source>
			<translation>add_lot</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_visit</source>
			<translation>Usuń wizytę</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_visit</source>
			<translation>Usuń wizytę</translation>
		</message>
		<message>
			<source>btn_export_rel</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_rel</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>btn_export_visits</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_visits</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>btn_open_photo</source>
			<translation>Zdjęcie otwarte</translation>
		</message>
		<message>
			<source>tooltip_btn_open_photo</source>
			<translation>Zdjęcie otwarte</translation>
		</message>
		<message>
			<source>btn_open_visit</source>
			<translation>Wizyta otwarta</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit</source>
			<translation>Wizyta otwarta</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_validate_all</source>
			<translation>Zatwierdź wszystko</translation>
		</message>
		<message>
			<source>tooltip_btn_validate_all</source>
			<translation>Zatwierdź wszystko</translation>
		</message>
		<message>
			<source>dlg_add_lot</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_lot</source>
			<translation>dlg_add_lot</translation>
		</message>
		<message>
			<source>grb_lot</source>
			<translation>Lot:</translation>
		</message>
		<message>
			<source>tooltip_grb_lot</source>
			<translation>Lot:</translation>
		</message>
		<message>
			<source>grb_ot</source>
			<translation>Zlecenie pracy</translation>
		</message>
		<message>
			<source>tooltip_grb_ot</source>
			<translation>Zlecenie pracy</translation>
		</message>
		<message>
			<source>label_data_event_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_label_data_event_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>label_data_event_to</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>tooltip_label_data_event_to</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>label_feature_type</source>
			<translation>Typ elementu:</translation>
		</message>
		<message>
			<source>tooltip_label_feature_type</source>
			<translation>Typ elementu:</translation>
		</message>
		<message>
			<source>lbl_address</source>
			<translation>Adres:</translation>
		</message>
		<message>
			<source>tooltip_lbl_address</source>
			<translation>Adres:</translation>
		</message>
		<message>
			<source>lbl_description</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_description</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtruj według identyfikatora elementu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>Filtruj według identyfikatora elementu:</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>lbl_observations</source>
			<translation>Obserwacje:</translation>
		</message>
		<message>
			<source>tooltip_lbl_observations</source>
			<translation>Obserwacje:</translation>
		</message>
		<message>
			<source>lbl_ot</source>
			<translation>Ot:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ot</source>
			<translation>Ot:</translation>
		</message>
		<message>
			<source>lbl_ot_type</source>
			<translation>Typ Ot:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ot_type</source>
			<translation>Typ Ot:</translation>
		</message>
		<message>
			<source>lbl_performance_type</source>
			<translation>Typ wydajności:</translation>
		</message>
		<message>
			<source>tooltip_lbl_performance_type</source>
			<translation>Typ wydajności:</translation>
		</message>
		<message>
			<source>lbl_plan_end</source>
			<translation>Planowane zakończenie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_plan_end</source>
			<translation>Planowane zakończenie:</translation>
		</message>
		<message>
			<source>lbl_plan_start</source>
			<translation>Planowany start:</translation>
		</message>
		<message>
			<source>tooltip_lbl_plan_start</source>
			<translation>Planowany start:</translation>
		</message>
		<message>
			<source>lbl_real_end</source>
			<translation>Prawdziwy koniec:</translation>
		</message>
		<message>
			<source>tooltip_lbl_real_end</source>
			<translation>Prawdziwy koniec:</translation>
		</message>
		<message>
			<source>lbl_real_start</source>
			<translation>Prawdziwy początek:</translation>
		</message>
		<message>
			<source>tooltip_lbl_real_start</source>
			<translation>Prawdziwy początek:</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Stan:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Stan:</translation>
		</message>
		<message>
			<source>lbl_team</source>
			<translation>Zespół:</translation>
		</message>
		<message>
			<source>tooltip_lbl_team</source>
			<translation>Zespół:</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Użytkownik:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>Użytkownik:</translation>
		</message>
		<message>
			<source>LotTab</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>tooltip_LotTab</source>
			<translation>Lot</translation>
		</message>
		<message>
			<source>RelationsTab</source>
			<translation>Relacje między elementami</translation>
		</message>
		<message>
			<source>tooltip_RelationsTab</source>
			<translation>Relacja elementów</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>VisitsTab</source>
			<translation>Wizyty</translation>
		</message>
		<message>
			<source>tooltip_VisitsTab</source>
			<translation>Wizyty</translation>
		</message>
	</context>
	<context>
		<name>add_workorder</name>
		<message>
			<source>title</source>
			<translation>Zlecenie pracy</translation>
		</message>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>add_workorder</source>
			<translation>Zlecenie pracy</translation>
		</message>
		<message>
			<source>tooltip_add_workorder</source>
			<translation>add_workorder</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_add_workorder</source>
			<translation>Zlecenie pracy</translation>
		</message>
		<message>
			<source>tooltip_dlg_add_workorder</source>
			<translation>dlg_add_workorder</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Zlecenie pracy</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
	</context>
	<context>
		<name>admin</name>
		<message>
			<source>title</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>action_create_sample</source>
			<translation>Utwórz próbkę</translation>
		</message>
		<message>
			<source>tooltip_action_create_sample</source>
			<translation>action_create_sample</translation>
		</message>
		<message>
			<source>action_create_sample_dev</source>
			<translation>Create Sample Dev</translation>
		</message>
		<message>
			<source>tooltip_action_create_sample_dev</source>
			<translation>action_create_sample_dev</translation>
		</message>
		<message>
			<source>btn_activate_audit</source>
			<translation>Aktywacja środowiska audytu</translation>
		</message>
		<message>
			<source>tooltip_btn_activate_audit</source>
			<translation>btn_activate_audit</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_copy</source>
			<translation>Kopia</translation>
		</message>
		<message>
			<source>tooltip_btn_copy</source>
			<translation>btn_copy</translation>
		</message>
		<message>
			<source>btn_create_asset</source>
			<translation>Tworzenie schematu zasobów DB</translation>
		</message>
		<message>
			<source>tooltip_btn_create_asset</source>
			<translation>btn_create_asset</translation>
		</message>
		<message>
			<source>btn_create_audit</source>
			<translation>Tworzenie schematu audytu bazy danych</translation>
		</message>
		<message>
			<source>tooltip_btn_create_audit</source>
			<translation>btn_create_audit</translation>
		</message>
		<message>
			<source>btn_create_cm</source>
			<translation>Tworzenie schematu DB cm</translation>
		</message>
		<message>
			<source>tooltip_btn_create_cm</source>
			<translation>btn_create_cm</translation>
		</message>
		<message>
			<source>btn_create_field</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create_field</source>
			<translation>btn_create_field</translation>
		</message>
		<message>
			<source>btn_create_qgis_template</source>
			<translation>Szablony QGIS</translation>
		</message>
		<message>
			<source>tooltip_btn_create_qgis_template</source>
			<translation>btn_create_qgis_template</translation>
		</message>
		<message>
			<source>btn_create_utils</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create_utils</source>
			<translation>btn_create_utils</translation>
		</message>
		<message>
			<source>btn_custom_load_file</source>
			<translation>Ładowanie plików SQL</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_load_file</source>
			<translation>btn_custom_load_file</translation>
		</message>
		<message>
			<source>btn_custom_select_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_select_file</source>
			<translation>btn_custom_select_file</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_delete_field</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_field</source>
			<translation>btn_delete_field</translation>
		</message>
		<message>
			<source>btn_gis_create</source>
			<translation>Tworzenie</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_create</source>
			<translation>btn_gis_create</translation>
		</message>
		<message>
			<source>btn_i18n</source>
			<translation>Menedżer i18n</translation>
		</message>
		<message>
			<source>tooltip_btn_i18n</source>
			<translation>btn_i18n</translation>
		</message>
		<message>
			<source>btn_import_osm_streetaxis</source>
			<translation>Import OSM Streetaxis</translation>
		</message>
		<message>
			<source>tooltip_btn_import_osm_streetaxis</source>
			<translation>btn_import_osm_streetaxis</translation>
		</message>
		<message>
			<source>btn_info</source>
			<translation>Aktualizacja schematu projektu</translation>
		</message>
		<message>
			<source>tooltip_btn_info</source>
			<translation>Aktualizacja wersji wybranego schematu bazy danych</translation>
		</message>
		<message>
			<source>btn_markdown_generator</source>
			<translation>Generator Markdown</translation>
		</message>
		<message>
			<source>tooltip_btn_markdown_generator</source>
			<translation>btn_markdown_generator</translation>
		</message>
		<message>
			<source>btn_reload_audit_triggers</source>
			<translation>Audyt odświeżający</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_audit_triggers</source>
			<translation>btn_reload_audit_triggers</translation>
		</message>
		<message>
			<source>btn_reload_fct_ftrg</source>
			<translation>Wykonanie</translation>
		</message>
		<message>
			<source>tooltip_btn_reload_fct_ftrg</source>
			<translation>btn_reload_fct_ftrg</translation>
		</message>
		<message>
			<source>btn_schema_create</source>
			<translation>Tworzenie schematu projektu DB</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_create</source>
			<translation>btn_schema_create</translation>
		</message>
		<message>
			<source>btn_schema_rename</source>
			<translation>Zmiana nazwy</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_rename</source>
			<translation>btn_schema_rename</translation>
		</message>
		<message>
			<source>btn_translation</source>
			<translation>Pliki tłumaczeń</translation>
		</message>
		<message>
			<source>tooltip_btn_translation</source>
			<translation>btn_translation</translation>
		</message>
		<message>
			<source>btn_update_field</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update_field</source>
			<translation>btn_update_field</translation>
		</message>
		<message>
			<source>btn_update_translation</source>
			<translation>Natychmiastowa aktualizacja i18n</translation>
		</message>
		<message>
			<source>tooltip_btn_update_translation</source>
			<translation>btn_update_translation</translation>
		</message>
		<message>
			<source>btn_update_utils</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update_utils</source>
			<translation>btn_update_utils</translation>
		</message>
		<message>
			<source>btn_vacuum</source>
			<translation>Wykonanie</translation>
		</message>
		<message>
			<source>tooltip_btn_vacuum</source>
			<translation>btn_vacuum</translation>
		</message>
		<message>
			<source>chk_add_fields_multi</source>
			<translation>Addfield multicreate</translation>
		</message>
		<message>
			<source>tooltip_chk_add_fields_multi</source>
			<translation>chk_add_fields_multi</translation>
		</message>
		<message>
			<source>dlg_admin</source>
			<translation>Giswater</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin</source>
			<translation>dlg_admin</translation>
		</message>
		<message>
			<source>grb_conection</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_grb_conection</source>
			<translation>grb_conection</translation>
		</message>
		<message>
			<source>grb_files_generator</source>
			<translation>Generator plików wtyczek</translation>
		</message>
		<message>
			<source>tooltip_grb_files_generator</source>
			<translation>grb_files_generator</translation>
		</message>
		<message>
			<source>grb_i18n</source>
			<translation>i18n</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n</source>
			<translation>grb_i18n</translation>
		</message>
		<message>
			<source>grb_load_cf</source>
			<translation>Załaduj plik niestandardowy</translation>
		</message>
		<message>
			<source>tooltip_grb_load_cf</source>
			<translation>grb_load_cf</translation>
		</message>
		<message>
			<source>grb_manage_addfields</source>
			<translation>Zarządzanie polami dodawania</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_addfields</source>
			<translation>grb_manage_addfields</translation>
		</message>
		<message>
			<source>grb_project_scin</source>
			<translation>Informacje o schemacie projektu</translation>
		</message>
		<message>
			<source>tooltip_grb_project_scin</source>
			<translation>grb_project_scin</translation>
		</message>
		<message>
			<source>grb_schema_manager</source>
			<translation>Zarządzanie schematami</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_manager</source>
			<translation>grb_schema_manager</translation>
		</message>
		<message>
			<source>grb_schema_reload</source>
			<translation>Zarządzanie schematami</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_reload</source>
			<translation>grb_schema_reload</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Scheme Utils</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Dodatkowe zarządzanie schematami</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>grp_i18n_update</source>
			<translation>Aktualizacja schematu i18n</translation>
		</message>
		<message>
			<source>tooltip_grp_i18n_update</source>
			<translation>grp_i18n_update</translation>
		</message>
		<message>
			<source>grp_import_osm</source>
			<translation>Import OSM Streetaxis</translation>
		</message>
		<message>
			<source>tooltip_grp_import_osm</source>
			<translation>grp_import_osm</translation>
		</message>
		<message>
			<source>label</source>
			<translation>WS:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>UD:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>lbl_add_fields_feature</source>
			<translation>Nazwa funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_add_fields_feature</source>
			<translation>lbl_add_fields_feature</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Nazwa połączenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>lbl_connection</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Imię i nazwisko:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Typ projektu:       </translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_reload_fct_ftrg</source>
			<translation>Przeładowanie funkcji &amp;amp; wyzwalacze funkcji</translation>
		</message>
		<message>
			<source>tooltip_lbl_reload_fct_ftrg</source>
			<translation>lbl_reload_fct_ftrg</translation>
		</message>
		<message>
			<source>lbl_vacuum</source>
			<translation>Wykonanie próżni na wybranym schemacie</translation>
		</message>
		<message>
			<source>tooltip_lbl_vacuum</source>
			<translation>lbl_vacuum</translation>
		</message>
		<message>
			<source>tab_advanced</source>
			<translation>Zaawansowany</translation>
		</message>
		<message>
			<source>tooltip_tab_advanced</source>
			<translation>tab_advanced</translation>
		</message>
		<message>
			<source>tab_dev</source>
			<translation>Dev</translation>
		</message>
		<message>
			<source>tooltip_tab_dev</source>
			<translation>tab_dev</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Ogólne</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
	</context>
	<context>
		<name>admin_addfields</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Otwarty</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_admin_addfields</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_addfields</source>
			<translation>dlg_admin_addfields</translation>
		</message>
		<message>
			<source>dlg_main_addfields</source>
			<translation>Dodaj pola</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_addfields</source>
			<translation>dlg_main_addfields</translation>
		</message>
		<message>
			<source>grb_additional</source>
			<translation>Dodatkowa konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_grb_additional</source>
			<translation>grb_additional</translation>
		</message>
		<message>
			<source>grb_mandatory</source>
			<translation>Obowiązkowa konfiguracja pól dodatkowych</translation>
		</message>
		<message>
			<source>tooltip_grb_mandatory</source>
			<translation>grb_mandatory</translation>
		</message>
		<message>
			<source>lbl_action_function</source>
			<translation>Funkcja działania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_action_function</source>
			<translation>lbl_action_function</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Aktywny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_auto_update</source>
			<translation>Automatyczna aktualizacja:</translation>
		</message>
		<message>
			<source>tooltip_lbl_auto_update</source>
			<translation>lbl_auto_update</translation>
		</message>
		<message>
			<source>lbl_column_id</source>
			<translation>Nazwa kolumny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_id</source>
			<translation>lbl_column_id</translation>
		</message>
		<message>
			<source>lbl_columnname</source>
			<translation>Nazwa kolumny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_columnname</source>
			<translation>lbl_columnname</translation>
		</message>
		<message>
			<source>lbl_data_type</source>
			<translation>Typ danych:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_type</source>
			<translation>lbl_data_type</translation>
		</message>
		<message>
			<source>lbl_datatype</source>
			<translation>Typ danych:</translation>
		</message>
		<message>
			<source>tooltip_lbl_datatype</source>
			<translation>lbl_datatype</translation>
		</message>
		<message>
			<source>lbl_dv_orderby</source>
			<translation>Zamówienie według identyfikatora:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_orderby</source>
			<translation>lbl_dv_orderby</translation>
		</message>
		<message>
			<source>lbl_dv_querynullvalue</source>
			<translation>Wartość null zapytania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_querynullvalue</source>
			<translation>lbl_dv_querynullvalue</translation>
		</message>
		<message>
			<source>lbl_dv_querytext</source>
			<translation>Tekst zapytania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dv_querytext</source>
			<translation>lbl_dv_querytext</translation>
		</message>
		<message>
			<source>lbl_editability</source>
			<translation>Możliwość edycji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_editability</source>
			<translation>lbl_editability</translation>
		</message>
		<message>
			<source>lbl_editable</source>
			<translation>Możliwość edycji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_editable</source>
			<translation>lbl_editable</translation>
		</message>
		<message>
			<source>lbl_enabled</source>
			<translation>Włączone:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enabled</source>
			<translation>lbl_enabled</translation>
		</message>
		<message>
			<source>lbl_field_length</source>
			<translation>Długość pola:</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_length</source>
			<translation>lbl_field_length</translation>
		</message>
		<message>
			<source>lbl_field_name</source>
			<translation>Nazwa pola:</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_name</source>
			<translation>lbl_field_name</translation>
		</message>
		<message>
			<source>lbl_form_type</source>
			<translation>Typ formularza:</translation>
		</message>
		<message>
			<source>tooltip_lbl_form_type</source>
			<translation>lbl_form_type</translation>
		</message>
		<message>
			<source>lbl_formtype</source>
			<translation>Typ formularza:</translation>
		</message>
		<message>
			<source>tooltip_lbl_formtype</source>
			<translation>lbl_formtype</translation>
		</message>
		<message>
			<source>lbl_hidden</source>
			<translation>Ukryte:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hidden</source>
			<translation>lbl_hidden</translation>
		</message>
		<message>
			<source>lbl_iseditable</source>
			<translation>Możliwość edycji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_iseditable</source>
			<translation>lbl_iseditable</translation>
		</message>
		<message>
			<source>lbl_ismandatory</source>
			<translation>Obowiązkowe:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ismandatory</source>
			<translation>lbl_ismandatory</translation>
		</message>
		<message>
			<source>lbl_label</source>
			<translation>Etykieta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_label</source>
			<translation>lbl_label</translation>
		</message>
		<message>
			<source>lbl_layoutname</source>
			<translation>Nazwa układu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_layoutname</source>
			<translation>lbl_layoutname</translation>
		</message>
		<message>
			<source>lbl_linkedobject</source>
			<translation>Linkedobject:</translation>
		</message>
		<message>
			<source>tooltip_lbl_linkedobject</source>
			<translation>lbl_linkedobject</translation>
		</message>
		<message>
			<source>lbl_mandatory</source>
			<translation>Obowiązkowe:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mandatory</source>
			<translation>lbl_mandatory</translation>
		</message>
		<message>
			<source>lbl_multifeaturetype</source>
			<translation>Funkcja wielokrotnego tworzenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multifeaturetype</source>
			<translation>lbl_multifeaturetype</translation>
		</message>
		<message>
			<source>lbl_not_update</source>
			<translation>Brak aktualizacji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_not_update</source>
			<translation>lbl_not_update</translation>
		</message>
		<message>
			<source>lbl_null_value</source>
			<translation>Wartość zerowa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_null_value</source>
			<translation>lbl_null_value</translation>
		</message>
		<message>
			<source>lbl_num_dec</source>
			<translation>Liczba miejsc po przecinku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_num_dec</source>
			<translation>lbl_num_dec</translation>
		</message>
		<message>
			<source>lbl_parent</source>
			<translation>Rodzic:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parent</source>
			<translation>lbl_parent</translation>
		</message>
		<message>
			<source>lbl_parent_id</source>
			<translation>Identyfikator rodzica:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parent_id</source>
			<translation>lbl_parent_id</translation>
		</message>
		<message>
			<source>lbl_placeholder</source>
			<translation>Symbol zastępczy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_placeholder</source>
			<translation>lbl_placeholder</translation>
		</message>
		<message>
			<source>lbl_query_filter</source>
			<translation>Filtr tekstu zapytania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_query_filter</source>
			<translation>lbl_query_filter</translation>
		</message>
		<message>
			<source>lbl_query_text</source>
			<translation>Tekst zapytania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_query_text</source>
			<translation>lbl_query_text</translation>
		</message>
		<message>
			<source>lbl_reload_field</source>
			<translation>Przeładuj pole:</translation>
		</message>
		<message>
			<source>tooltip_lbl_reload_field</source>
			<translation>lbl_reload_field</translation>
		</message>
		<message>
			<source>lbl_stylesheet</source>
			<translation>Arkusz stylów:</translation>
		</message>
		<message>
			<source>tooltip_lbl_stylesheet</source>
			<translation>lbl_stylesheet</translation>
		</message>
		<message>
			<source>lbl_tooltip</source>
			<translation>Podpowiedź:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tooltip</source>
			<translation>lbl_tooltip</translation>
		</message>
		<message>
			<source>lbl_typeahead</source>
			<translation>Typeahead:</translation>
		</message>
		<message>
			<source>tooltip_lbl_typeahead</source>
			<translation>lbl_typeahead</translation>
		</message>
		<message>
			<source>lbl_widgetcontrols</source>
			<translation>Widgetcontrols</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgetcontrols</source>
			<translation>Przykładowe klucze konfiguracyjne {&quot;widgetdim&quot;: 150, &quot;setMultiline&quot;:true, &quot;vdefault&quot;: &quot;01-01-2014&quot;, &quot;filterSign&quot;: &quot;&gt;}</translation>
		</message>
		<message>
			<source>lbl_widget_function</source>
			<translation>Funkcja widgetu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widget_function</source>
			<translation>lbl_widget_function</translation>
		</message>
		<message>
			<source>lbl_widget_type</source>
			<translation>Typ widżetu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widget_type</source>
			<translation>lbl_widget_type</translation>
		</message>
		<message>
			<source>lbl_widgettype</source>
			<translation>Typ widżetu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgettype</source>
			<translation>lbl_widgettype</translation>
		</message>
		<message>
			<source>stylesheet</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;{&amp;amp;quot;label&amp;amp;quot;:&amp;amp;quot;color:green; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;widget&amp;amp;quot;:{&amp;amp;quot;enabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;,&amp;amp;quot;disabled&amp;amp;quot;:&amp;amp;quot;color:black; font-weight:bold;&amp;amp;quot;}}&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_stylesheet</source>
			<translation>stylesheet</translation>
		</message>
		<message>
			<source>tab_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_tab_create</source>
			<translation>tab_create</translation>
		</message>
		<message>
			<source>tab_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_tab_delete</source>
			<translation>tab_delete</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_tab_update</source>
			<translation>tab_update</translation>
		</message>
	</context>
	<context>
		<name>admin_cm_base</name>
		<message>
			<source>title</source>
			<translation>Tworzenie schematu bazowego</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Anuluj zadanie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_admin_cm_base</source>
			<translation>Tworzenie schematu bazowego</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_cm_base</source>
			<translation>dlg_admin_cm_base</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>Ustawienia schematu projektu</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_project_name</source>
			<translation>Nazwa projektu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_name</source>
			<translation>lbl_project_name</translation>
		</message>
	</context>
	<context>
		<name>admin_cm_create</name>
		<message>
			<source>title</source>
			<translation>Utwórz projekt</translation>
		</message>
		<message>
			<source>actionCreate_Sample</source>
			<translation>Utwórz próbkę</translation>
		</message>
		<message>
			<source>tooltip_actionCreate_Sample</source>
			<translation>actionCreate_Sample</translation>
		</message>
		<message>
			<source>actionCreate_Sample_Dev</source>
			<translation>Create Sample Dev</translation>
		</message>
		<message>
			<source>tooltip_actionCreate_Sample_Dev</source>
			<translation>actionCreate_Sample_Dev</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_base_schema</source>
			<translation>Tworzenie schematu cm</translation>
		</message>
		<message>
			<source>tooltip_btn_base_schema</source>
			<translation>btn_base_schema</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Anuluj zadanie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_example</source>
			<translation>Utwórz przykład</translation>
		</message>
		<message>
			<source>tooltip_btn_example</source>
			<translation>btn_example</translation>
		</message>
		<message>
			<source>btn_parent_schema</source>
			<translation>Link do schematu nadrzędnego</translation>
		</message>
		<message>
			<source>tooltip_btn_parent_schema</source>
			<translation>btn_parent_schema</translation>
		</message>
		<message>
			<source>btn_pschema_qgis_file</source>
			<translation>Tworzenie pliku pschema qgis</translation>
		</message>
		<message>
			<source>tooltip_btn_pschema_qgis_file</source>
			<translation>btn_pschema_qgis_file</translation>
		</message>
		<message>
			<source>dlg_admin_cm_create</source>
			<translation>Utwórz projekt</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_cm_create</source>
			<translation>dlg_admin_cm_create</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>Opcje schematu CM</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Utwórz bazę wzoru cm:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
	</context>
	<context>
		<name>admin_credentials</name>
		<message>
			<source>title</source>
			<translation>Poświadczenia połączenia</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>dlg_admin_credentials</source>
			<translation>Poświadczenia połączenia</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_credentials</source>
			<translation>dlg_admin_credentials</translation>
		</message>
		<message>
			<source>dlg_main_credentials</source>
			<translation>Główne dane uwierzytelniające</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_credentials</source>
			<translation>dlg_main_credentials</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Tryb SSL:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_connec</source>
			<translation>Połączenie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connec</source>
			<translation>lbl_connec</translation>
		</message>
		<message>
			<source>lbl_connection_message</source>
			<translation>Nie można pobrać parametrów połączenia dla:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection_message</source>
			<translation>lbl_connection_message</translation>
		</message>
		<message>
			<source>lbl_password</source>
			<translation>Hasło:</translation>
		</message>
		<message>
			<source>tooltip_lbl_password</source>
			<translation>lbl_password</translation>
		</message>
		<message>
			<source>lbl_user_name</source>
			<translation>Nazwa użytkownika:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user_name</source>
			<translation>lbl_user_name</translation>
		</message>
	</context>
	<context>
		<name>admin_dbproject</name>
		<message>
			<source>title</source>
			<translation>Utwórz projekt</translation>
		</message>
		<message>
			<source>actionCreate_Sample</source>
			<translation>Utwórz próbkę</translation>
		</message>
		<message>
			<source>tooltip_actionCreate_Sample</source>
			<translation>actionCreate_Sample</translation>
		</message>
		<message>
			<source>actionCreate_Sample_Dev</source>
			<translation>Create Sample Dev</translation>
		</message>
		<message>
			<source>tooltip_actionCreate_Sample_Dev</source>
			<translation>actionCreate_Sample_Dev</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Anuluj zadanie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_push_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_file</source>
			<translation>btn_push_file</translation>
		</message>
		<message>
			<source>dlg_admin_dbproject</source>
			<translation>Utwórz projekt</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_dbproject</source>
			<translation>dlg_admin_dbproject</translation>
		</message>
		<message>
			<source>dlg_main_dbproject</source>
			<translation>Utwórz projekt</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_dbproject</source>
			<translation>dlg_main_dbproject</translation>
		</message>
		<message>
			<source>grb_projectschema</source>
			<translation>Ustawienia schematu projektu</translation>
		</message>
		<message>
			<source>tooltip_grb_projectschema</source>
			<translation>grb_projectschema</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtr SRID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>Identyfikator odniesienia przestrzennego. Dozwolone są tylko wartości przedstawione w poniższej tabeli.</translation>
		</message>
		<message>
			<source>lbl_locale</source>
			<translation>Lokalny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_locale</source>
			<translation>Język schematów</translation>
		</message>
		<message>
			<source>lbl_project_name</source>
			<translation>Nazwa projektu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_name</source>
			<translation>Nazwa nowego schematu. Nazwa musi być zapisana małymi literami, używając tylko liter używanych w alfabecie angielskim i bez spacji lub myślników</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Typ projektu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_source</source>
			<translation>Źródło danych:</translation>
		</message>
		<message>
			<source>tooltip_lbl_source</source>
			<translation>lbl_source</translation>
		</message>
		<message>
			<source>rdb_empty</source>
			<translation>Puste dane</translation>
		</message>
		<message>
			<source>tooltip_rdb_empty</source>
			<translation>rdb_empty</translation>
		</message>
		<message>
			<source>rdb_inp</source>
			<translation>Import danych INP</translation>
		</message>
		<message>
			<source>tooltip_rdb_inp</source>
			<translation>rdb_inp</translation>
		</message>
		<message>
			<source>rdb_sample_full</source>
			<translation>Pełny przykład</translation>
		</message>
		<message>
			<source>tooltip_rdb_sample_full</source>
			<translation>rdb_sample_full</translation>
		</message>
		<message>
			<source>rdb_sample_inv</source>
			<translation>Przykład inwentaryzacji</translation>
		</message>
		<message>
			<source>tooltip_rdb_sample_inv</source>
			<translation>rdb_sample_inv</translation>
		</message>
	</context>
	<context>
		<name>admin_gisproject</name>
		<message>
			<source>title</source>
			<translation>Tworzenie projektu GIS</translation>
		</message>
		<message>
			<source>actionCreate_Sample</source>
			<translation>Utwórz próbkę</translation>
		</message>
		<message>
			<source>tooltip_actionCreate_Sample</source>
			<translation>actionCreate_Sample</translation>
		</message>
		<message>
			<source>actionCreate_Sample_Dev</source>
			<translation>Create Sample Dev</translation>
		</message>
		<message>
			<source>tooltip_actionCreate_Sample_Dev</source>
			<translation>actionCreate_Sample_Dev</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_gis_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_folder</source>
			<translation>btn_gis_folder</translation>
		</message>
		<message>
			<source>dlg_admin_gisproject</source>
			<translation>Tworzenie projektu GIS</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_gisproject</source>
			<translation>dlg_admin_gisproject</translation>
		</message>
		<message>
			<source>dlg_main_gisproject</source>
			<translation>Tworzenie projektu QGIS</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_gisproject</source>
			<translation>dlg_main_gisproject</translation>
		</message>
		<message>
			<source>lbl_export_user_pass</source>
			<translation>Eksportuj hasło użytkownika:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_user_pass</source>
			<translation>lbl_export_user_pass</translation>
		</message>
		<message>
			<source>lbl_gis_file</source>
			<translation>Nazwa pliku GIS:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_file</source>
			<translation>lbl_gis_file</translation>
		</message>
		<message>
			<source>lbl_gis_folder</source>
			<translation>Folder GIS:</translation>
		</message>
		<message>
			<source>tooltip_lbl_gis_folder</source>
			<translation>lbl_gis_folder</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Typ projektu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_role</source>
			<translation>Typ roli:</translation>
		</message>
		<message>
			<source>tooltip_lbl_role</source>
			<translation>lbl_role</translation>
		</message>
		<message>
			<source>statusbar</source>
			<translation>Create Sample Dev</translation>
		</message>
		<message>
			<source>tooltip_statusbar</source>
			<translation>statusbar</translation>
		</message>
		<message>
			<source>txt_roletype</source>
			<translation>inwentaryzacja</translation>
		</message>
		<message>
			<source>tooltip_txt_roletype</source>
			<translation>txt_roletype</translation>
		</message>
	</context>
	<context>
		<name>admin_i18n_manager</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_connection</source>
			<translation>Połączenie testowe</translation>
		</message>
		<message>
			<source>tooltip_btn_connection</source>
			<translation>btn_connection</translation>
		</message>
		<message>
			<source>btn_search</source>
			<translation>Wyszukiwanie</translation>
		</message>
		<message>
			<source>tooltip_btn_search</source>
			<translation>btn_search</translation>
		</message>
		<message>
			<source>chk_all</source>
			<translation>Sprawdź wszystko</translation>
		</message>
		<message>
			<source>tooltip_chk_all</source>
			<translation>chk_all</translation>
		</message>
		<message>
			<source>chk_am_dialogs</source>
			<translation>Sprawdź tabele am</translation>
		</message>
		<message>
			<source>tooltip_chk_am_dialogs</source>
			<translation>chk_am_dialogs</translation>
		</message>
		<message>
			<source>chk_cm_dialogs</source>
			<translation>Sprawdź tabele cm</translation>
		</message>
		<message>
			<source>tooltip_chk_cm_dialogs</source>
			<translation>chk_cm_dialogs</translation>
		</message>
		<message>
			<source>chk_db_dialogs</source>
			<translation>Okna dialogowe sprawdzania tabel DB</translation>
		</message>
		<message>
			<source>tooltip_chk_db_dialogs</source>
			<translation>chk_db_dialogs</translation>
		</message>
		<message>
			<source>chk_for_su_tables</source>
			<translation>Sprawdzenie podstawowych tabel DB (cat_feature...)</translation>
		</message>
		<message>
			<source>tooltip_chk_for_su_tables</source>
			<translation>chk_for_su_tables</translation>
		</message>
		<message>
			<source>chk_py_dialogs</source>
			<translation>Sprawdź okna dialogowe PY</translation>
		</message>
		<message>
			<source>tooltip_chk_py_dialogs</source>
			<translation>chk_py_dialogs</translation>
		</message>
		<message>
			<source>chk_py_messages</source>
			<translation>Sprawdzanie komunikatów PY</translation>
		</message>
		<message>
			<source>tooltip_chk_py_messages</source>
			<translation>chk_py_messages</translation>
		</message>
		<message>
			<source>dlg_admin_i18n_manager</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_i18n_manager</source>
			<translation>dlg_admin_i18n_manager</translation>
		</message>
		<message>
			<source>grb_i18n_conn</source>
			<translation>i18n Conection</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n_conn</source>
			<translation>grb_i18n_conn</translation>
		</message>
		<message>
			<source>grp_search_options</source>
			<translation>Opcje wyszukiwania</translation>
		</message>
		<message>
			<source>tooltip_grp_search_options</source>
			<translation>grp_search_options</translation>
		</message>
		<message>
			<source>lbl_database</source>
			<translation>Baza danych:</translation>
		</message>
		<message>
			<source>tooltip_lbl_database</source>
			<translation>lbl_database</translation>
		</message>
		<message>
			<source>lbl_host</source>
			<translation>Gość:</translation>
		</message>
		<message>
			<source>tooltip_lbl_host</source>
			<translation>lbl_host</translation>
		</message>
		<message>
			<source>lbl_pass</source>
			<translation>Hasło:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pass</source>
			<translation>lbl_pass</translation>
		</message>
		<message>
			<source>lbl_port</source>
			<translation>Port:</translation>
		</message>
		<message>
			<source>tooltip_lbl_port</source>
			<translation>lbl_port</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Użytkownik:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
	</context>
	<context>
		<name>admin_importinp</name>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_run</source>
			<translation>Bieg</translation>
		</message>
		<message>
			<source>tooltip_btn_run</source>
			<translation>btn_run</translation>
		</message>
		<message>
			<source>dlg_main_importinp</source>
			<translation>Parametry konfiguracji</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_importinp</source>
			<translation>dlg_main_importinp</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>admin_import_osm</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Wykonanie</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_admin_import_osm</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_import_osm</source>
			<translation>dlg_admin_import_osm</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Gminy</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Dzienniki</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>admin_markdown</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_generate</source>
			<translation>Generowanie</translation>
		</message>
		<message>
			<source>tooltip_btn_generate</source>
			<translation>btn_generate</translation>
		</message>
		<message>
			<source>dlg_admin_markdown</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_markdown</source>
			<translation>dlg_admin_markdown</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Typ projektu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Nazwa schematu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lb_path</source>
			<translation>Ścieżka pliku:</translation>
		</message>
		<message>
			<source>tooltip_lb_path</source>
			<translation>lb_path</translation>
		</message>
		<message>
			<source>pushButton_2</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_pushButton_2</source>
			<translation>pushButton_2</translation>
		</message>
	</context>
	<context>
		<name>admin_markdown_generator</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_generate</source>
			<translation>Generowanie</translation>
		</message>
		<message>
			<source>tooltip_btn_generate</source>
			<translation>btn_generate</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>cmb_projecttype</source>
			<translation>ud</translation>
		</message>
		<message>
			<source>tooltip_cmb_projecttype</source>
			<translation>cmb_projecttype</translation>
		</message>
		<message>
			<source>dlg_admin_markdown_generator</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_markdown_generator</source>
			<translation>dlg_admin_markdown_generator</translation>
		</message>
		<message>
			<source>grp_markdown_destination</source>
			<translation>Przeznaczenie Markdown</translation>
		</message>
		<message>
			<source>tooltip_grp_markdown_destination</source>
			<translation>grp_markdown_destination</translation>
		</message>
		<message>
			<source>grp_origin_schema</source>
			<translation>Schemat pochodzenia</translation>
		</message>
		<message>
			<source>tooltip_grp_origin_schema</source>
			<translation>grp_origin_schema</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Typ projektu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Nazwa schematu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lb_path</source>
			<translation>Ścieżka pliku:</translation>
		</message>
		<message>
			<source>tooltip_lb_path</source>
			<translation>lb_path</translation>
		</message>
	</context>
	<context>
		<name>admin_projectinfo</name>
		<message>
			<source>title</source>
			<translation>Aktualizacja SQL</translation>
		</message>
		<message>
			<source>actionCreate_Sample</source>
			<translation>Utwórz próbkę</translation>
		</message>
		<message>
			<source>tooltip_actionCreate_Sample</source>
			<translation>actionCreate_Sample</translation>
		</message>
		<message>
			<source>actionCreate_Sample_Dev</source>
			<translation>Create Sample Dev</translation>
		</message>
		<message>
			<source>tooltip_actionCreate_Sample_Dev</source>
			<translation>actionCreate_Sample_Dev</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>dlg_admin_projectinfo</source>
			<translation>Aktualizacja SQL</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_projectinfo</source>
			<translation>dlg_admin_projectinfo</translation>
		</message>
		<message>
			<source>dlg_main_projectinfo</source>
			<translation>Aktualizacja SQL</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_projectinfo</source>
			<translation>dlg_main_projectinfo</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Informacje o nowych aktualizacjach</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>statusbar</source>
			<translation>Create Sample Dev</translation>
		</message>
		<message>
			<source>tooltip_statusbar</source>
			<translation>statusbar</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Dziennik</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>tab_main</source>
			<translation>Główny</translation>
		</message>
		<message>
			<source>tooltip_tab_main</source>
			<translation>tab_main</translation>
		</message>
	</context>
	<context>
		<name>admin_qtdialog</name>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>dlg_main_qtdialog</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_qtdialog</source>
			<translation>dlg_main_qtdialog</translation>
		</message>
		<message>
			<source>lbl_formname</source>
			<translation>Nazwa formularza:</translation>
		</message>
		<message>
			<source>tooltip_lbl_formname</source>
			<translation>lbl_formname</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Ścieżka interfejsu użytkownika:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
	</context>
	<context>
		<name>admin_renameproj</name>
		<message>
			<source>title</source>
			<translation>Zmiana nazwy</translation>
		</message>
		<message>
			<source>actionCreate_Sample</source>
			<translation>Utwórz próbkę</translation>
		</message>
		<message>
			<source>tooltip_actionCreate_Sample</source>
			<translation>actionCreate_Sample</translation>
		</message>
		<message>
			<source>actionCreate_Sample_Dev</source>
			<translation>Create Sample Dev</translation>
		</message>
		<message>
			<source>tooltip_actionCreate_Sample_Dev</source>
			<translation>actionCreate_Sample_Dev</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>dlg_admin_renameproj</source>
			<translation>Zmiana nazwy</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_renameproj</source>
			<translation>dlg_admin_renameproj</translation>
		</message>
		<message>
			<source>dlg_readsq_rename</source>
			<translation>Zmiana nazwy projektu</translation>
		</message>
		<message>
			<source>tooltip_dlg_readsq_rename</source>
			<translation>dlg_readsq_rename</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Ustaw nową nazwę projektu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>lbl_rename_copy</translation>
		</message>
		<message>
			<source>statusbar</source>
			<translation>Create Sample Dev</translation>
		</message>
		<message>
			<source>tooltip_statusbar</source>
			<translation>statusbar</translation>
		</message>
	</context>
	<context>
		<name>admin_sysfields</name>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Otwarty</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_main_sysfields</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_sysfields</source>
			<translation>dlg_main_sysfields</translation>
		</message>
		<message>
			<source>grb_additional_conf</source>
			<translation>Dodatkowa konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_grb_additional_conf</source>
			<translation>grb_additional_conf</translation>
		</message>
		<message>
			<source>grb_basic_conf</source>
			<translation>Podstawowa konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_grb_basic_conf</source>
			<translation>grb_basic_conf</translation>
		</message>
		<message>
			<source>lbl_column_id</source>
			<translation>Identyfikator kolumny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_id</source>
			<translation>lbl_column_id</translation>
		</message>
		<message>
			<source>lbl_editability</source>
			<translation>Możliwość edycji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_editability</source>
			<translation>lbl_editability</translation>
		</message>
		<message>
			<source>lbl_editable</source>
			<translation>Możliwość edycji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_editable</source>
			<translation>lbl_editable</translation>
		</message>
		<message>
			<source>lbl_enabled</source>
			<translation>Włączone:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enabled</source>
			<translation>lbl_enabled</translation>
		</message>
		<message>
			<source>lbl_form_name</source>
			<translation>Nazwa formularza:</translation>
		</message>
		<message>
			<source>tooltip_lbl_form_name</source>
			<translation>lbl_form_name</translation>
		</message>
		<message>
			<source>lbl_hidden</source>
			<translation>Ukryte:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hidden</source>
			<translation>lbl_hidden</translation>
		</message>
		<message>
			<source>lbl_label</source>
			<translation>Etykieta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_label</source>
			<translation>lbl_label</translation>
		</message>
		<message>
			<source>lbl_layout_name</source>
			<translation>Nazwa układu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_layout_name</source>
			<translation>lbl_layout_name</translation>
		</message>
		<message>
			<source>lbl_layout_order</source>
			<translation>Kolejność układu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_layout_order</source>
			<translation>lbl_layout_order</translation>
		</message>
		<message>
			<source>lbl_mandatory</source>
			<translation>Obowiązkowe:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mandatory</source>
			<translation>lbl_mandatory</translation>
		</message>
		<message>
			<source>lbl_placeholder</source>
			<translation>Symbol zastępczy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_placeholder</source>
			<translation>lbl_placeholder</translation>
		</message>
		<message>
			<source>lbl_stylesheet</source>
			<translation>Arkusz stylów:</translation>
		</message>
		<message>
			<source>tooltip_lbl_stylesheet</source>
			<translation>lbl_stylesheet</translation>
		</message>
		<message>
			<source>lbl_tooltip</source>
			<translation>Podpowiedź:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tooltip</source>
			<translation>lbl_tooltip</translation>
		</message>
		<message>
			<source>lbl_widgetcontrols</source>
			<translation>Elementy sterujące widżetem:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgetcontrols</source>
			<translation>Przykładowe klucze konfiguracyjne {&quot;widgetdim&quot;: 150, &quot;setMultiline&quot;:true, &quot;vdefault&quot;: &quot;01-01-2014&quot;, &quot;filterSign&quot;: &quot;&gt;}</translation>
		</message>
		<message>
			<source>tab_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_tab_create</source>
			<translation>tab_create</translation>
		</message>
		<message>
			<source>tab_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_tab_update</source>
			<translation>tab_update</translation>
		</message>
	</context>
	<context>
		<name>admin_translation</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_connection</source>
			<translation>Połączenie testowe</translation>
		</message>
		<message>
			<source>tooltip_btn_connection</source>
			<translation>btn_connection</translation>
		</message>
		<message>
			<source>btn_translate</source>
			<translation>Tłumaczenie</translation>
		</message>
		<message>
			<source>tooltip_btn_translate</source>
			<translation>btn_translate</translation>
		</message>
		<message>
			<source>chk_am_files</source>
			<translation>Tłumaczenie plików am</translation>
		</message>
		<message>
			<source>tooltip_chk_am_files</source>
			<translation>chk_am_files</translation>
		</message>
		<message>
			<source>chk_audit_files</source>
			<translation>Tłumaczenie plików audytu</translation>
		</message>
		<message>
			<source>tooltip_chk_audit_files</source>
			<translation>chk_audit_files</translation>
		</message>
		<message>
			<source>chk_cm_files</source>
			<translation>Tłumaczenie plików cm</translation>
		</message>
		<message>
			<source>tooltip_chk_cm_files</source>
			<translation>chk_cm_files</translation>
		</message>
		<message>
			<source>chk_db_msg</source>
			<translation>Tłumaczenie wiadomości db</translation>
		</message>
		<message>
			<source>tooltip_chk_db_msg</source>
			<translation>chk_db_msg</translation>
		</message>
		<message>
			<source>chk_i18n_files</source>
			<translation>Tłumaczenia i18n</translation>
		</message>
		<message>
			<source>tooltip_chk_i18n_files</source>
			<translation>chk_i18n_files</translation>
		</message>
		<message>
			<source>chk_py_msg</source>
			<translation>Tłumaczenie komunikatów ui i py</translation>
		</message>
		<message>
			<source>tooltip_chk_py_msg</source>
			<translation>chk_py_msg</translation>
		</message>
		<message>
			<source>chk_relative_langs</source>
			<translation>Enable fallback to similar locales. </translation>
		</message>
		<message>
			<source>tooltip_chk_relative_langs</source>
			<translation>chk_relative_langs</translation>
		</message>
		<message>
			<source>dlg_admin_translation</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_translation</source>
			<translation>dlg_admin_translation</translation>
		</message>
		<message>
			<source>grb_info_connection</source>
			<translation>Informacje o połączeniu</translation>
		</message>
		<message>
			<source>tooltip_grb_info_connection</source>
			<translation>grb_info_connection</translation>
		</message>
		<message>
			<source>grb_translate_files</source>
			<translation>Tłumaczenie plików</translation>
		</message>
		<message>
			<source>tooltip_grb_translate_files</source>
			<translation>grb_translate_files</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Informacje o połączeniu</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Tłumaczenie plików</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_3</source>
			<translation>Parameters</translation>
		</message>
		<message>
			<source>tooltip_groupBox_3</source>
			<translation>groupBox_3</translation>
		</message>
		<message>
			<source>label</source>
			<translation>If a translation is missing in the specific target dialect (e.g., es_ES), the system searches other regional variants (e.g., es_CR, es_AR). If a match is found, that translation is applied.</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_database</source>
			<translation>Baza danych:</translation>
		</message>
		<message>
			<source>tooltip_lbl_database</source>
			<translation>lbl_database</translation>
		</message>
		<message>
			<source>lbl_host</source>
			<translation>Gość:</translation>
		</message>
		<message>
			<source>tooltip_lbl_host</source>
			<translation>lbl_host</translation>
		</message>
		<message>
			<source>lbl_language</source>
			<translation>Język:</translation>
		</message>
		<message>
			<source>tooltip_lbl_language</source>
			<translation>lbl_language</translation>
		</message>
		<message>
			<source>lbl_pass</source>
			<translation>Hasło:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pass</source>
			<translation>lbl_pass</translation>
		</message>
		<message>
			<source>lbl_port</source>
			<translation>Port:</translation>
		</message>
		<message>
			<source>tooltip_lbl_port</source>
			<translation>lbl_port</translation>
		</message>
		<message>
			<source>lbl_scode</source>
			<translation>Kod źródłowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_scode</source>
			<translation>lbl_scode</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Użytkownik:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
	</context>
	<context>
		<name>admin_ui</name>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_constrains</source>
			<translation>Ograniczenia</translation>
		</message>
		<message>
			<source>tooltip_btn_constrains</source>
			<translation>btn_constrains</translation>
		</message>
		<message>
			<source>btn_copy</source>
			<translation>Kopia</translation>
		</message>
		<message>
			<source>tooltip_btn_copy</source>
			<translation>Kopiowanie wybranego schematu bazy danych</translation>
		</message>
		<message>
			<source>btn_create_field</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create_field</source>
			<translation>btn_create_field</translation>
		</message>
		<message>
			<source>btn_create_qgis_template</source>
			<translation>Szablony QGIS</translation>
		</message>
		<message>
			<source>tooltip_btn_create_qgis_template</source>
			<translation>btn_create_qgis_template</translation>
		</message>
		<message>
			<source>btn_create_view</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create_view</source>
			<translation>btn_create_view</translation>
		</message>
		<message>
			<source>btn_custom_load_file</source>
			<translation>Załaduj plik</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_load_file</source>
			<translation>btn_custom_load_file</translation>
		</message>
		<message>
			<source>btn_custom_select_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_custom_select_file</source>
			<translation>btn_custom_select_file</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń wybrany schemat bazy danych</translation>
		</message>
		<message>
			<source>btn_delete_field</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_field</source>
			<translation>btn_delete_field</translation>
		</message>
		<message>
			<source>btn_export_ui</source>
			<translation>Eksport</translation>
		</message>
		<message>
			<source>tooltip_btn_export_ui</source>
			<translation>btn_export_ui</translation>
		</message>
		<message>
			<source>btn_gis_create</source>
			<translation>Tworzenie</translation>
		</message>
		<message>
			<source>tooltip_btn_gis_create</source>
			<translation>btn_gis_create</translation>
		</message>
		<message>
			<source>btn_import_ui</source>
			<translation>Import</translation>
		</message>
		<message>
			<source>tooltip_btn_import_ui</source>
			<translation>btn_import_ui</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_schema_create</source>
			<translation>Tworzenie schematu projektu DB</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_create</source>
			<translation>btn_schema_create</translation>
		</message>
		<message>
			<source>btn_schema_file_to_db</source>
			<translation>Plik do DB</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_file_to_db</source>
			<translation>btn_schema_file_to_db</translation>
		</message>
		<message>
			<source>btn_schema_rename</source>
			<translation>Zmiana nazwy</translation>
		</message>
		<message>
			<source>tooltip_btn_schema_rename</source>
			<translation>Zmiana nazwy wybranego schematu bazy danych</translation>
		</message>
		<message>
			<source>btn_translation</source>
			<translation>Pliki tłumaczeń</translation>
		</message>
		<message>
			<source>tooltip_btn_translation</source>
			<translation>btn_translation</translation>
		</message>
		<message>
			<source>btn_update_field</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update_field</source>
			<translation>btn_update_field</translation>
		</message>
		<message>
			<source>btn_update_schema</source>
			<translation>Wykonanie</translation>
		</message>
		<message>
			<source>tooltip_btn_update_schema</source>
			<translation>btn_update_schema</translation>
		</message>
		<message>
			<source>btn_update_sys_field</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update_sys_field</source>
			<translation>btn_update_sys_field</translation>
		</message>
		<message>
			<source>btn_visit_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_visit_create</source>
			<translation>btn_visit_create</translation>
		</message>
		<message>
			<source>btn_visit_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_visit_delete</source>
			<translation>btn_visit_delete</translation>
		</message>
		<message>
			<source>btn_visit_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_visit_update</source>
			<translation>btn_visit_update</translation>
		</message>
		<message>
			<source>grb_conection</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_grb_conection</source>
			<translation>grb_conection</translation>
		</message>
		<message>
			<source>grb_files_generator</source>
			<translation>Generator plików wtyczek</translation>
		</message>
		<message>
			<source>tooltip_grb_files_generator</source>
			<translation>grb_files_generator</translation>
		</message>
		<message>
			<source>grb_load_cf</source>
			<translation>Załaduj plik niestandardowy</translation>
		</message>
		<message>
			<source>tooltip_grb_load_cf</source>
			<translation>Wybierz folder z plikami .sql, które chcesz wykonać na wybranym schemacie</translation>
		</message>
		<message>
			<source>grb_manage_addfields</source>
			<translation>Zarządzanie polami dodawania</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_addfields</source>
			<translation>Utwórz, skonfiguruj lub usuń dodatkowe pole związane z wybranym typem funkcji lub dla wszystkich typów funkcji zdefiniowanych w projekcie.</translation>
		</message>
		<message>
			<source>grb_manage_childviews</source>
			<translation>Zarządzanie widokami podrzędnymi</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_childviews</source>
			<translation>Odtwarzanie widoków podrzędnych dla wybranego typu funkcji lub dla wszystkich typów funkcji zdefiniowanych w projekcie.</translation>
		</message>
		<message>
			<source>grb_manage_sys_fields</source>
			<translation>Zarządzanie polami systemowymi</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_sys_fields</source>
			<translation>Konfiguracja właściwości pól systemowych dla wybranego typu funkcji, zdefiniowanego w config_form_fields</translation>
		</message>
		<message>
			<source>grb_manage_ui</source>
			<translation>Zarządzanie interfejsem użytkownika</translation>
		</message>
		<message>
			<source>tooltip_grb_manage_ui</source>
			<translation>grb_manage_ui</translation>
		</message>
		<message>
			<source>grb_project_scin</source>
			<translation>Informacje o schemacie projektu</translation>
		</message>
		<message>
			<source>tooltip_grb_project_scin</source>
			<translation>grb_project_scin</translation>
		</message>
		<message>
			<source>grb_schema_manager</source>
			<translation>Zarządzanie schematami</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_manager</source>
			<translation>grb_schema_manager</translation>
		</message>
		<message>
			<source>grb_schema_reload</source>
			<translation>Przeładowanie</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_reload</source>
			<translation>grb_schema_reload</translation>
		</message>
		<message>
			<source>grb_schema_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_grb_schema_update</source>
			<translation>grb_schema_update</translation>
		</message>
		<message>
			<source>grb_visit</source>
			<translation>Odwiedź</translation>
		</message>
		<message>
			<source>tooltip_grb_visit</source>
			<translation>Tworzenie, konfigurowanie lub usuwanie definicji wizyt związanych z wybranym typem funkcji lub dla wszystkich typów funkcji zdefiniowanych w projekcie.</translation>
		</message>
		<message>
			<source>lbl_add_fields_feature</source>
			<translation>Nazwa funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_add_fields_feature</source>
			<translation>lbl_add_fields_feature</translation>
		</message>
		<message>
			<source>lbl_child_feature</source>
			<translation>Nazwa funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_child_feature</source>
			<translation>lbl_child_feature</translation>
		</message>
		<message>
			<source>lbl_connection</source>
			<translation>Nazwa połączenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_connection</source>
			<translation>Nazwa połączenia z bazą danych zdefiniowanego w QGIS</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Imię i nazwisko:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>Nazwa schematu bazy danych</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Typ projektu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>Typ projektu giswater</translation>
		</message>
		<message>
			<source>lbl_reload_func_sch</source>
			<translation>Funkcje przeładowania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_reload_func_sch</source>
			<translation>lbl_reload_func_sch</translation>
		</message>
		<message>
			<source>lbl_system_feature</source>
			<translation>Nazwa funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_system_feature</source>
			<translation>lbl_system_feature</translation>
		</message>
		<message>
			<source>lbl_ui_form_name</source>
			<translation>Nazwa formularza:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ui_form_name</source>
			<translation>lbl_ui_form_name</translation>
		</message>
		<message>
			<source>lbl_ui_path</source>
			<translation>Ścieżka interfejsu użytkownika:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ui_path</source>
			<translation>lbl_ui_path</translation>
		</message>
		<message>
			<source>lbl_update_all_sch</source>
			<translation>Zaktualizuj wszystko:</translation>
		</message>
		<message>
			<source>tooltip_lbl_update_all_sch</source>
			<translation>lbl_update_all_sch</translation>
		</message>
		<message>
			<source>lbl_use_constrains</source>
			<translation>Ograniczenia użytkowania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_use_constrains</source>
			<translation>lbl_use_constrains</translation>
		</message>
		<message>
			<source>tab_advanced</source>
			<translation>Zaawansowany</translation>
		</message>
		<message>
			<source>tooltip_tab_advanced</source>
			<translation>tab_advanced</translation>
		</message>
		<message>
			<source>tab_api_manager</source>
			<translation>Kierownik ds. pożarów</translation>
		</message>
		<message>
			<source>tooltip_tab_api_manager</source>
			<translation>tab_api_manager</translation>
		</message>
		<message>
			<source>tab_fields_manager</source>
			<translation>Menedżer pól</translation>
		</message>
		<message>
			<source>tooltip_tab_fields_manager</source>
			<translation>tab_fields_manager</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Ogólne</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>tab_schema_manager</source>
			<translation>Menedżer schematów</translation>
		</message>
		<message>
			<source>tooltip_tab_schema_manager</source>
			<translation>tab_schema_manager</translation>
		</message>
	</context>
	<context>
		<name>admin_update_translation</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_connection</source>
			<translation>Połączenie testowe</translation>
		</message>
		<message>
			<source>tooltip_btn_connection</source>
			<translation>btn_connection</translation>
		</message>
		<message>
			<source>btn_translate</source>
			<translation>Tłumaczenie</translation>
		</message>
		<message>
			<source>tooltip_btn_translate</source>
			<translation>btn_translate</translation>
		</message>
		<message>
			<source>chk_add_tab_data</source>
			<translation>Translate tab_data</translation>
		</message>
		<message>
			<source>tooltip_chk_add_tab_data</source>
			<translation>chk_add_tab_data</translation>
		</message>
		<message>
			<source>dlg_admin_update_translation</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_update_translation</source>
			<translation>dlg_admin_update_translation</translation>
		</message>
		<message>
			<source>grb_dest_conn</source>
			<translation>Połączenie przeznaczenia</translation>
		</message>
		<message>
			<source>tooltip_grb_dest_conn</source>
			<translation>grb_dest_conn</translation>
		</message>
		<message>
			<source>grb_i18n_conn</source>
			<translation>i18n Conection</translation>
		</message>
		<message>
			<source>tooltip_grb_i18n_conn</source>
			<translation>grb_i18n_conn</translation>
		</message>
		<message>
			<source>grb_parameters</source>
			<translation>Parameters</translation>
		</message>
		<message>
			<source>tooltip_grb_parameters</source>
			<translation>grb_parameters</translation>
		</message>
		<message>
			<source>lbl_database</source>
			<translation>Baza danych:</translation>
		</message>
		<message>
			<source>tooltip_lbl_database</source>
			<translation>lbl_database</translation>
		</message>
		<message>
			<source>lbl_host</source>
			<translation>Gość:</translation>
		</message>
		<message>
			<source>tooltip_lbl_host</source>
			<translation>lbl_host</translation>
		</message>
		<message>
			<source>lbl_language</source>
			<translation>Język:</translation>
		</message>
		<message>
			<source>tooltip_lbl_language</source>
			<translation>lbl_language</translation>
		</message>
		<message>
			<source>lbl_pass</source>
			<translation>Hasło:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pass</source>
			<translation>lbl_pass</translation>
		</message>
		<message>
			<source>lbl_port</source>
			<translation>Port:</translation>
		</message>
		<message>
			<source>tooltip_lbl_port</source>
			<translation>lbl_port</translation>
		</message>
		<message>
			<source>lbl_project_type</source>
			<translation>Typ projektu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_project_type</source>
			<translation>lbl_project_type</translation>
		</message>
		<message>
			<source>lbl_schema_update</source>
			<translation>Nazwa schematu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_schema_update</source>
			<translation>lbl_schema_update</translation>
		</message>
		<message>
			<source>lbl_user</source>
			<translation>Użytkownik:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user</source>
			<translation>lbl_user</translation>
		</message>
	</context>
	<context>
		<name>admin_visitclass</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie klasą wizyt</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_class_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_class_cancel</source>
			<translation>btn_class_cancel</translation>
		</message>
		<message>
			<source>btn_class_ok</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_class_ok</source>
			<translation>btn_class_ok</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_param_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_param_create</source>
			<translation>btn_param_create</translation>
		</message>
		<message>
			<source>btn_param_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_param_delete</source>
			<translation>btn_param_delete</translation>
		</message>
		<message>
			<source>btn_param_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_param_update</source>
			<translation>btn_param_update</translation>
		</message>
		<message>
			<source>dlg_admin_visitclass</source>
			<translation>Zarządzanie klasą wizyt</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_visitclass</source>
			<translation>dlg_admin_visitclass</translation>
		</message>
		<message>
			<source>dlg_main_visitclass</source>
			<translation>Zarządzanie klasą wizyt</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_visitclass</source>
			<translation>dlg_main_visitclass</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Klasa</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Parametr</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Aktywny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_class_id</source>
			<translation>Identyfikator klasy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_class_id</source>
			<translation>lbl_class_id</translation>
		</message>
		<message>
			<source>lbl_class_name</source>
			<translation>Nazwa klasy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_class_name</source>
			<translation>lbl_class_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_feat_type</source>
			<translation>Typ funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_type</source>
			<translation>lbl_feat_type</translation>
		</message>
		<message>
			<source>lbl_multi_event</source>
			<translation>Wiele wydarzeń:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multi_event</source>
			<translation>lbl_multi_event</translation>
		</message>
		<message>
			<source>lbl_multi_feat</source>
			<translation>Wiele funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_multi_feat</source>
			<translation>lbl_multi_feat</translation>
		</message>
		<message>
			<source>lbl_param_opt</source>
			<translation>Opcje parametrów:</translation>
		</message>
		<message>
			<source>tooltip_lbl_param_opt</source>
			<translation>lbl_param_opt</translation>
		</message>
		<message>
			<source>lbl_viewname</source>
			<translation>Nazwa widoku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_viewname</source>
			<translation>lbl_viewname</translation>
		</message>
		<message>
			<source>lbl_visit_type</source>
			<translation>Typ wizyty:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_type</source>
			<translation>lbl_visit_type</translation>
		</message>
	</context>
	<context>
		<name>admin_visitparam</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie parametrem wizyty</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_admin_visitparam</source>
			<translation>Zarządzanie parametrem wizyty</translation>
		</message>
		<message>
			<source>tooltip_dlg_admin_visitparam</source>
			<translation>dlg_admin_visitparam</translation>
		</message>
		<message>
			<source>dlg_main_visitparam</source>
			<translation>Zarządzanie parametrem wizyty</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_visitparam</source>
			<translation>dlg_main_visitparam</translation>
		</message>
		<message>
			<source>grb_params</source>
			<translation>Parametr</translation>
		</message>
		<message>
			<source>tooltip_grb_params</source>
			<translation>grb_params</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation>Kod:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_data_type</source>
			<translation>Typ danych:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_type</source>
			<translation>lbl_data_type</translation>
		</message>
		<message>
			<source>lbl_default_value</source>
			<translation>Wartość domyślna:</translation>
		</message>
		<message>
			<source>tooltip_lbl_default_value</source>
			<translation>lbl_default_value</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_editable</source>
			<translation>Możliwość edycji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_editable</source>
			<translation>lbl_editable</translation>
		</message>
		<message>
			<source>lbl_enabled</source>
			<translation>Włączone:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enabled</source>
			<translation>lbl_enabled</translation>
		</message>
		<message>
			<source>lbl_form_type</source>
			<translation>Typ formularza:</translation>
		</message>
		<message>
			<source>tooltip_lbl_form_type</source>
			<translation>lbl_form_type</translation>
		</message>
		<message>
			<source>lbl_mandatory</source>
			<translation>Obowiązkowe:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mandatory</source>
			<translation>lbl_mandatory</translation>
		</message>
		<message>
			<source>lbl_parameter_name</source>
			<translation>Nazwa parametru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_name</source>
			<translation>lbl_parameter_name</translation>
		</message>
		<message>
			<source>lbl_parameter_type</source>
			<translation>Typ parametru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_type</source>
			<translation>lbl_parameter_type</translation>
		</message>
		<message>
			<source>lbl_query_text</source>
			<translation>Tekst zapytania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_query_text</source>
			<translation>lbl_query_text</translation>
		</message>
		<message>
			<source>lbl_short_descript</source>
			<translation>Krótki opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_short_descript</source>
			<translation>lbl_short_descript</translation>
		</message>
		<message>
			<source>lbl_widgettype</source>
			<translation>Typ widżetu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_widgettype</source>
			<translation>lbl_widgettype</translation>
		</message>
	</context>
	<context>
		<name>arc_divide</name>
		<message>
			<source>title</source>
			<translation>Arc divide</translation>
		</message>
		<message>
			<source>dlg_arc_divide</source>
			<translation>Arc divide</translation>
		</message>
		<message>
			<source>tooltip_dlg_arc_divide</source>
			<translation>dlg_arc_divide</translation>
		</message>
	</context>
	<context>
		<name>arc_fusion</name>
		<message>
			<source>title</source>
			<translation>Fuzja łukowa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_arc_fusion</source>
			<translation>Fuzja łukowa</translation>
		</message>
		<message>
			<source>tooltip_dlg_arc_fusion</source>
			<translation>dlg_arc_fusion</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>lbl_arc1asset</source>
			<translation>Arc 1 asset:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc1asset</source>
			<translation>lbl_arc1asset</translation>
		</message>
		<message>
			<source>lbl_arc1cat</source>
			<translation>Katalog Arc 1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc1cat</source>
			<translation>lbl_arc1cat</translation>
		</message>
		<message>
			<source>lbl_arc2asset</source>
			<translation>Arc 2 asset:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc2asset</source>
			<translation>lbl_arc2asset</translation>
		</message>
		<message>
			<source>lbl_arc2cat</source>
			<translation>Katalog Arc 2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arc2cat</source>
			<translation>lbl_arc2cat</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Data zakończenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_new_asset</source>
			<translation>New asset:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_asset</source>
			<translation>lbl_new_asset</translation>
		</message>
		<message>
			<source>lbl_new_cat</source>
			<translation>Nowy katalog:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_cat</source>
			<translation>lbl_new_cat</translation>
		</message>
		<message>
			<source>lbl_nodeaction</source>
			<translation>Działanie węzła:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodeaction</source>
			<translation>lbl_nodeaction</translation>
		</message>
		<message>
			<source>lbl_statetype</source>
			<translation>Typ państwa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_statetype</source>
			<translation>lbl_statetype</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Koniec identyfikatora Workcat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Fuzja łukowa</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>assignation</name>
		<message>
			<source>title</source>
			<translation>Przypisanie wycieku</translation>
		</message>
		<message>
			<source>chk_all_leaks</source>
			<translation>Wykorzystaj wszystkie nieszczelności</translation>
		</message>
		<message>
			<source>tooltip_chk_all_leaks</source>
			<translation>Oblicza wycieki na kilometr rocznie przy użyciu wszystkich dostępnych danych, niezależnie od parametru &quot;lata do obliczenia&quot;.</translation>
		</message>
		<message>
			<source>dlg_assignation</source>
			<translation>Przypisanie wycieku</translation>
		</message>
		<message>
			<source>tooltip_dlg_assignation</source>
			<translation>dlg_assignation</translation>
		</message>
		<message>
			<source>lbl_buffer</source>
			<translation>Odległość buforowa (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_buffer</source>
			<translation>Odległość od wycieku, w której rury są wybierane do przypisania do tego wycieku.</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Filtruj według daty utworzenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>Używa tylko rur, które pasują do zakresu daty początkowej.</translation>
		</message>
		<message>
			<source>lbl_builtdate_range</source>
			<translation>Zakres dat budowy (lata):</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate_range</source>
			<translation>Zakres dat budowy, w latach przed i po początkowej rurze.</translation>
		</message>
		<message>
			<source>lbl_cluster_length</source>
			<translation>Długość klastra (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_cluster_length</source>
			<translation>Maksymalna suma długości rur w klastrze, w metrach.</translation>
		</message>
		<message>
			<source>lbl_diameter</source>
			<translation>Filtruj według średnicy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_diameter</source>
			<translation>Używa tylko rur, które pasują do zakresu średnicy rury początkowej.</translation>
		</message>
		<message>
			<source>lbl_diameter_range</source>
			<translation>Zakres średnic:</translation>
		</message>
		<message>
			<source>tooltip_lbl_diameter_range</source>
			<translation>Zakres średnic oparty na czynnikach początkowej rury.</translation>
		</message>
		<message>
			<source>lbl_leaks</source>
			<translation>Wycieki</translation>
		</message>
		<message>
			<source>tooltip_lbl_leaks</source>
			<translation>lbl_leaks</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Filtruj według materiału:</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>Używa tylko rur z tego samego materiału, co rura początkowa.</translation>
		</message>
		<message>
			<source>lbl_max_distance</source>
			<translation>Maksymalna odległość (m):</translation>
		</message>
		<message>
			<source>tooltip_lbl_max_distance</source>
			<translation>Maksymalna odległość w metrach między przewodem początkowym a innymi przewodami wchodzącymi w skład klastra.</translation>
		</message>
		<message>
			<source>lbl_pipes</source>
			<translation>Rury</translation>
		</message>
		<message>
			<source>tooltip_lbl_pipes</source>
			<translation>lbl_pipes</translation>
		</message>
		<message>
			<source>lbl_years</source>
			<translation>Lata do obliczenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_years</source>
			<translation>Liczba lat danych o wyciekach do uwzględnienia, w oparciu o aktualność.</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>audit</name>
		<message>
			<source>title</source>
			<translation>Audyt</translation>
		</message>
		<message>
			<source>dlg_audit</source>
			<translation>Audyt</translation>
		</message>
		<message>
			<source>tooltip_dlg_audit</source>
			<translation>dlg_audit</translation>
		</message>
		<message>
			<source>dlg_info_audit</source>
			<translation>Dziennik</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_audit</source>
			<translation>Dziennik</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Zaktualizowane wartości</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
	</context>
	<context>
		<name>audit_manager</name>
		<message>
			<source>title</source>
			<translation>Kierownik ds. audytu</translation>
		</message>
		<message>
			<source>dlg_audit_manager</source>
			<translation>Kierownik ds. audytu</translation>
		</message>
		<message>
			<source>tooltip_dlg_audit_manager</source>
			<translation>Kierownik ds. audytu</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Dzienniki</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Dzienniki</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Data do</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Data do</translation>
		</message>
	</context>
	<context>
		<name>auxcircle</name>
		<message>
			<source>title</source>
			<translation>CAD Rysuj okrąg</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_delete_prev</source>
			<translation>Usuń poprzednie okręgi</translation>
		</message>
		<message>
			<source>tooltip_chk_delete_prev</source>
			<translation>chk_delete_prev</translation>
		</message>
		<message>
			<source>dlg_auxcircle</source>
			<translation>CAD Rysuj okrąg</translation>
		</message>
		<message>
			<source>tooltip_dlg_auxcircle</source>
			<translation>dlg_auxcircle</translation>
		</message>
		<message>
			<source>lbl_ins_radius</source>
			<translation>Promień wstawiania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ins_radius</source>
			<translation>lbl_ins_radius</translation>
		</message>
		<message>
			<source>radius</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_radius</source>
			<translation>radius</translation>
		</message>
	</context>
	<context>
		<name>auxpoint</name>
		<message>
			<source>title</source>
			<translation>CAD Dodaj punkt</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_delete_prev</source>
			<translation>Usuń poprzednie punkty</translation>
		</message>
		<message>
			<source>tooltip_chk_delete_prev</source>
			<translation>chk_delete_prev</translation>
		</message>
		<message>
			<source>dist_x</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_dist_x</source>
			<translation>dist_x</translation>
		</message>
		<message>
			<source>dist_y</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_dist_y</source>
			<translation>dist_y</translation>
		</message>
		<message>
			<source>dlg_auxpoint</source>
			<translation>CAD Dodaj punkt</translation>
		</message>
		<message>
			<source>tooltip_dlg_auxpoint</source>
			<translation>dlg_auxpoint</translation>
		</message>
		<message>
			<source>grb_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_grb_from</source>
			<translation>grb_from</translation>
		</message>
		<message>
			<source>lbl_distx</source>
			<translation>Odległość (X):</translation>
		</message>
		<message>
			<source>tooltip_lbl_distx</source>
			<translation>lbl_distx</translation>
		</message>
		<message>
			<source>lbl_disty</source>
			<translation>Odległość (Y):</translation>
		</message>
		<message>
			<source>tooltip_lbl_disty</source>
			<translation>lbl_disty</translation>
		</message>
		<message>
			<source>rb_left</source>
			<translation>Punkt początkowy</translation>
		</message>
		<message>
			<source>tooltip_rb_left</source>
			<translation>rb_left</translation>
		</message>
		<message>
			<source>rb_right</source>
			<translation>Punkt końcowy</translation>
		</message>
		<message>
			<source>tooltip_rb_right</source>
			<translation>rb_right</translation>
		</message>
	</context>
	<context>
		<name>campaign_management</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie kampaniami</translation>
		</message>
		<message>
			<source>btn_campaign_selector</source>
			<translation>Selektor kampanii</translation>
		</message>
		<message>
			<source>tooltip_btn_campaign_selector</source>
			<translation>Selektor kampanii</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>campaign_btn_delete</source>
			<translation>Usuń kampanię</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_delete</source>
			<translation>Usuń kampanię</translation>
		</message>
		<message>
			<source>campaign_btn_open</source>
			<translation>Kampania otwarta</translation>
		</message>
		<message>
			<source>tooltip_campaign_btn_open</source>
			<translation>Kampania otwarta</translation>
		</message>
		<message>
			<source>campaign_chk_show_nulls</source>
			<translation>Pokaż wartości null</translation>
		</message>
		<message>
			<source>tooltip_campaign_chk_show_nulls</source>
			<translation>Pokaż puste wartości</translation>
		</message>
		<message>
			<source>campaign_management</source>
			<translation>Zarządzanie kampaniami</translation>
		</message>
		<message>
			<source>tooltip_campaign_management</source>
			<translation>campaign_management</translation>
		</message>
		<message>
			<source>dlg_campaign_management</source>
			<translation>Zarządzanie kampaniami</translation>
		</message>
		<message>
			<source>tooltip_dlg_campaign_management</source>
			<translation>Zarządzanie kampaniami</translation>
		</message>
		<message>
			<source>lbl_column_filter_dates</source>
			<translation>Filtruj kolumnę dat</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter_dates</source>
			<translation>Filtruj kolumnę dat:</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Stan</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Stan:</translation>
		</message>
	</context>
	<context>
		<name>check_project</name>
		<message>
			<source>title</source>
			<translation>Sprawdź projekt</translation>
		</message>
		<message>
			<source>brb_database_check</source>
			<translation>Kontrola stanu bazy danych:</translation>
		</message>
		<message>
			<source>tooltip_brb_database_check</source>
			<translation>brb_database_check</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_check_project</source>
			<translation>Sprawdź projekt</translation>
		</message>
		<message>
			<source>tooltip_dlg_check_project</source>
			<translation>dlg_check_project</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_system_check</source>
			<translation>Kontrola stanu systemu:</translation>
		</message>
		<message>
			<source>tooltip_grb_system_check</source>
			<translation>grb_system_check</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Dziennik bazy danych</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Dzienniki</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>check_project_cm</name>
		<message>
			<source>title</source>
			<translation>Sprawdź projekt</translation>
		</message>
		<message>
			<source>brb_database_check</source>
			<translation>Kontrola stanu bazy danych:</translation>
		</message>
		<message>
			<source>tooltip_brb_database_check</source>
			<translation>brb_database_check</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>chk_manage_config</source>
			<translation>Sprawdź konfigurację zarządzania</translation>
		</message>
		<message>
			<source>tooltip_chk_manage_config</source>
			<translation>chk_manage_config</translation>
		</message>
		<message>
			<source>dlg_check_project_cm</source>
			<translation>Sprawdź projekt</translation>
		</message>
		<message>
			<source>tooltip_dlg_check_project_cm</source>
			<translation>dlg_check_project_cm</translation>
		</message>
		<message>
			<source>grb_database_health_check</source>
			<translation>Kontrola kondycji bazy danych</translation>
		</message>
		<message>
			<source>tooltip_grb_database_health_check</source>
			<translation>grb_database_health_check</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_system_check</source>
			<translation>Kontrola stanu systemu:</translation>
		</message>
		<message>
			<source>tooltip_grb_system_check</source>
			<translation>grb_system_check</translation>
		</message>
		<message>
			<source>grb_system_health_check</source>
			<translation>Kontrola stanu systemu</translation>
		</message>
		<message>
			<source>tooltip_grb_system_health_check</source>
			<translation>grb_system_health_check</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Dziennik bazy danych</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_log</source>
			<translation>Dzienniki</translation>
		</message>
		<message>
			<source>tooltip_tab_log</source>
			<translation>tab_log</translation>
		</message>
	</context>
	<context>
		<name>common</name>
		<message>
			<source>btn_help</source>
			<translation>Pomoc</translation>
		</message>
		<message>
			<source>tooltip_btn_help</source>
			<translation>Pomoc</translation>
		</message>
	</context>
	<context>
		<name>comp_x_pages</name>
		<message>
			<source>title</source>
			<translation>Automatyczne drukowanie stron kompozytora</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_comp_x_pages</source>
			<translation>Automatyczne drukowanie stron kompozytora</translation>
		</message>
		<message>
			<source>tooltip_dlg_comp_x_pages</source>
			<translation>dlg_comp_x_pages</translation>
		</message>
		<message>
			<source>grb_comp</source>
			<translation>Lista kompozytorów</translation>
		</message>
		<message>
			<source>tooltip_grb_comp</source>
			<translation>grb_comp</translation>
		</message>
		<message>
			<source>lbl_composers</source>
			<translation>Wybierz kompozytora:</translation>
		</message>
		<message>
			<source>tooltip_lbl_composers</source>
			<translation>lbl_composers</translation>
		</message>
		<message>
			<source>lbl_folder</source>
			<translation>Wybierz folder:</translation>
		</message>
		<message>
			<source>tooltip_lbl_folder</source>
			<translation>lbl_folder</translation>
		</message>
		<message>
			<source>lbl_prefix</source>
			<translation>Plik prefiksu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prefix</source>
			<translation>lbl_prefix</translation>
		</message>
		<message>
			<source>lbl_single</source>
			<translation>Pojedynczy plik:</translation>
		</message>
		<message>
			<source>tooltip_lbl_single</source>
			<translation>lbl_single</translation>
		</message>
		<message>
			<source>lbl_sleep</source>
			<translation>Czas snu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_sleep</source>
			<translation>lbl_sleep</translation>
		</message>
	</context>
	<context>
		<name>config</name>
		<message>
			<source>title</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_dlg_config</source>
			<translation>dlg_config</translation>
		</message>
		<message>
			<source>grb_addfields</source>
			<translation>Pola dodatkowe</translation>
		</message>
		<message>
			<source>tooltip_grb_addfields</source>
			<translation>grb_addfields</translation>
		</message>
		<message>
			<source>grb_admin_om</source>
			<translation>O&amp;&amp;M</translation>
		</message>
		<message>
			<source>tooltip_grb_admin_om</source>
			<translation>grb_admin_om</translation>
		</message>
		<message>
			<source>grb_admin_other</source>
			<translation>Inne</translation>
		</message>
		<message>
			<source>tooltip_grb_admin_other</source>
			<translation>grb_admin_other</translation>
		</message>
		<message>
			<source>grb_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_grb_arc</source>
			<translation>grb_arc</translation>
		</message>
		<message>
			<source>grb_basic</source>
			<translation>Podstawowy</translation>
		</message>
		<message>
			<source>tooltip_grb_basic</source>
			<translation>grb_basic</translation>
		</message>
		<message>
			<source>grb_category_type</source>
			<translation>Typ kategorii</translation>
		</message>
		<message>
			<source>tooltip_grb_category_type</source>
			<translation>grb_category_type</translation>
		</message>
		<message>
			<source>grb_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_grb_connec</source>
			<translation>grb_connec</translation>
		</message>
		<message>
			<source>grb_epa</source>
			<translation>Epa</translation>
		</message>
		<message>
			<source>tooltip_grb_epa</source>
			<translation>grb_epa</translation>
		</message>
		<message>
			<source>grb_fluid_type</source>
			<translation>Typ płynu</translation>
		</message>
		<message>
			<source>tooltip_grb_fluid_type</source>
			<translation>grb_fluid_type</translation>
		</message>
		<message>
			<source>grb_function_type</source>
			<translation>Typ funkcji</translation>
		</message>
		<message>
			<source>tooltip_grb_function_type</source>
			<translation>grb_function_type</translation>
		</message>
		<message>
			<source>grb_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_grb_gully</source>
			<translation>grb_gully</translation>
		</message>
		<message>
			<source>grb_inventory</source>
			<translation>Inwentaryzacja</translation>
		</message>
		<message>
			<source>tooltip_grb_inventory</source>
			<translation>grb_inventory</translation>
		</message>
		<message>
			<source>grb_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_grb_link</source>
			<translation>grb_link</translation>
		</message>
		<message>
			<source>grb_location_type</source>
			<translation>Typ lokalizacji</translation>
		</message>
		<message>
			<source>tooltip_grb_location_type</source>
			<translation>grb_location_type</translation>
		</message>
		<message>
			<source>grb_masterplan</source>
			<translation>MasterPlan</translation>
		</message>
		<message>
			<source>tooltip_grb_masterplan</source>
			<translation>grb_masterplan</translation>
		</message>
		<message>
			<source>grb_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_grb_node</source>
			<translation>grb_node</translation>
		</message>
		<message>
			<source>grb_om</source>
			<translation>O&amp;&amp;M</translation>
		</message>
		<message>
			<source>tooltip_grb_om</source>
			<translation>grb_om</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Inne</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_system</source>
			<translation>System</translation>
		</message>
		<message>
			<source>tooltip_grb_system</source>
			<translation>grb_system</translation>
		</message>
		<message>
			<source>grb_topology</source>
			<translation>Topologia</translation>
		</message>
		<message>
			<source>tooltip_grb_topology</source>
			<translation>grb_topology</translation>
		</message>
		<message>
			<source>grb_utils</source>
			<translation>Narzędzia</translation>
		</message>
		<message>
			<source>tooltip_grb_utils</source>
			<translation>grb_utils</translation>
		</message>
		<message>
			<source>tab_addfields</source>
			<translation>Pola dodatkowe</translation>
		</message>
		<message>
			<source>tooltip_tab_addfields</source>
			<translation>tab_addfields</translation>
		</message>
		<message>
			<source>tab_admin</source>
			<translation>Administrator</translation>
		</message>
		<message>
			<source>tooltip_tab_admin</source>
			<translation>tab_admin</translation>
		</message>
		<message>
			<source>tab_basic</source>
			<translation>Podstawowy</translation>
		</message>
		<message>
			<source>tooltip_tab_basic</source>
			<translation>tab_basic</translation>
		</message>
		<message>
			<source>tab_featurecat</source>
			<translation>Featurecat</translation>
		</message>
		<message>
			<source>tooltip_tab_featurecat</source>
			<translation>tab_featurecat</translation>
		</message>
		<message>
			<source>tab_mantype</source>
			<translation>Typ człowieka</translation>
		</message>
		<message>
			<source>tooltip_tab_mantype</source>
			<translation>tab_mantype</translation>
		</message>
	</context>
	<context>
		<name>connect_link</name>
		<message>
			<source>title</source>
			<translation>Połączenie z siecią</translation>
		</message>
		<message>
			<source>dlg_connect_link</source>
			<translation>Połączenie z siecią</translation>
		</message>
		<message>
			<source>tooltip_dlg_connect_link</source>
			<translation>dlg_connect_link</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Konfiguracja łącza</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Połączenia</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>groupBox_3</source>
			<translation>Łuki</translation>
		</message>
		<message>
			<source>tooltip_groupBox_3</source>
			<translation>groupBox_3</translation>
		</message>
		<message>
			<source>tab_connect</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_connect</source>
			<translation>tab_connect</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>create_style_group</name>
		<message>
			<source>btn_add</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_add</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>descript</source>
			<translation>descript</translation>
		</message>
		<message>
			<source>tooltip_descript</source>
			<translation>Opis</translation>
		</message>
		<message>
			<source>feature_id</source>
			<translation>feature_id</translation>
		</message>
		<message>
			<source>tooltip_feature_id</source>
			<translation>Identyfikator kategorii</translation>
		</message>
		<message>
			<source>idval</source>
			<translation>idval</translation>
		</message>
		<message>
			<source>tooltip_idval</source>
			<translation>Nazwa kategorii</translation>
		</message>
		<message>
			<source>lbl_cat_id</source>
			<translation>Identyfikator kategorii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_id</source>
			<translation>lbl_cat_id</translation>
		</message>
		<message>
			<source>lbl_cat_name</source>
			<translation>Nazwa kategorii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_name</source>
			<translation>lbl_cat_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_role</source>
			<translation>Rola:</translation>
		</message>
		<message>
			<source>tooltip_lbl_role</source>
			<translation>lbl_role</translation>
		</message>
		<message>
			<source>sys_role</source>
			<translation>sys_role</translation>
		</message>
		<message>
			<source>tooltip_sys_role</source>
			<translation>Rola, która będzie mogła używać tego stylu</translation>
		</message>
	</context>
	<context>
		<name>crm_trace</name>
		<message>
			<source>lbl_inst</source>
			<translation>Instrukcje:</translation>
		</message>
		<message>
			<source>tooltip_lbl_inst</source>
			<translation>lbl_inst</translation>
		</message>
	</context>
	<context>
		<name>csv</name>
		<message>
			<source>title</source>
			<translation>Import CSV</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>btn_file_csv</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_csv</source>
			<translation>btn_file_csv</translation>
		</message>
		<message>
			<source>dlg_csv</source>
			<translation>Import CSV</translation>
		</message>
		<message>
			<source>tooltip_dlg_csv</source>
			<translation>dlg_csv</translation>
		</message>
		<message>
			<source>lbl_decimal</source>
			<translation>Separator dziesiętny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_decimal</source>
			<translation>lbl_decimal</translation>
		</message>
		<message>
			<source>lbl_delimiter</source>
			<translation>Ogranicznik:</translation>
		</message>
		<message>
			<source>tooltip_lbl_delimiter</source>
			<translation>lbl_delimiter</translation>
		</message>
		<message>
			<source>lbl_file</source>
			<translation>Plik:</translation>
		</message>
		<message>
			<source>tooltip_lbl_file</source>
			<translation>lbl_file</translation>
		</message>
		<message>
			<source>lbl_ignore_header</source>
			<translation>Ignorowanie nagłówków:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ignore_header</source>
			<translation>lbl_ignore_header</translation>
		</message>
		<message>
			<source>lbl_import_label</source>
			<translation>Etykieta importowa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_import_label</source>
			<translation>lbl_import_label</translation>
		</message>
		<message>
			<source>lbl_import_type</source>
			<translation>Typ importu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_import_type</source>
			<translation>lbl_import_type</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_set_of_charac</source>
			<translation>Zestaw znaków:</translation>
		</message>
		<message>
			<source>tooltip_lbl_set_of_charac</source>
			<translation>lbl_set_of_charac</translation>
		</message>
		<message>
			<source>rb_comma</source>
			<translation>,</translation>
		</message>
		<message>
			<source>tooltip_rb_comma</source>
			<translation>rb_comma</translation>
		</message>
		<message>
			<source>rb_dec_comma</source>
			<translation>,</translation>
		</message>
		<message>
			<source>tooltip_rb_dec_comma</source>
			<translation>rb_dec_comma</translation>
		</message>
		<message>
			<source>rb_dec_period</source>
			<translation>.</translation>
		</message>
		<message>
			<source>tooltip_rb_dec_period</source>
			<translation>rb_dec_period</translation>
		</message>
		<message>
			<source>rb_semicolon</source>
			<translation>;</translation>
		</message>
		<message>
			<source>tooltip_rb_semicolon</source>
			<translation>rb_semicolon</translation>
		</message>
		<message>
			<source>rb_space</source>
			<translation>Przestrzeń</translation>
		</message>
		<message>
			<source>tooltip_rb_space</source>
			<translation>rb_space</translation>
		</message>
		<message>
			<source>tab_info</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_info</source>
			<translation>tab_info</translation>
		</message>
		<message>
			<source>tab_preview</source>
			<translation>Podgląd</translation>
		</message>
		<message>
			<source>tooltip_tab_preview</source>
			<translation>tab_preview</translation>
		</message>
	</context>
	<context>
		<name>dialog_table</name>
		<message>
			<source>title</source>
			<translation>Tabela</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_add_row</source>
			<translation>Add row</translation>
		</message>
		<message>
			<source>tooltip_btn_add_row</source>
			<translation>btn_add_row</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_dialog_table</source>
			<translation>Tabela</translation>
		</message>
		<message>
			<source>tooltip_dlg_dialog_table</source>
			<translation>dlg_dialog_table</translation>
		</message>
	</context>
	<context>
		<name>dialog_text</name>
		<message>
			<source>title</source>
			<translation>Tekst</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_dialog_text</source>
			<translation>Tekst</translation>
		</message>
		<message>
			<source>tooltip_dlg_dialog_text</source>
			<translation>dlg_dialog_text</translation>
		</message>
	</context>
	<context>
		<name>dimensioning</name>
		<message>
			<source>title</source>
			<translation>Wymiarowanie</translation>
		</message>
		<message>
			<source>actionEdit</source>
			<translation>Edytuj</translation>
		</message>
		<message>
			<source>tooltip_actionEdit</source>
			<translation>actionEdit</translation>
		</message>
		<message>
			<source>actionOrientation</source>
			<translation>Orientacja</translation>
		</message>
		<message>
			<source>tooltip_actionOrientation</source>
			<translation>actionOrientation</translation>
		</message>
		<message>
			<source>actionSnapping</source>
			<translation>Snapping</translation>
		</message>
		<message>
			<source>tooltip_actionSnapping</source>
			<translation>actionSnapping</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_dimensioning</source>
			<translation>Wymiarowanie</translation>
		</message>
		<message>
			<source>tooltip_dlg_dimensioning</source>
			<translation>dlg_dimensioning</translation>
		</message>
		<message>
			<source>grb_depth</source>
			<translation>Pomiary</translation>
		</message>
		<message>
			<source>tooltip_grb_depth</source>
			<translation>grb_depth</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Inne</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_symbology</source>
			<translation>Symbolika okręgu</translation>
		</message>
		<message>
			<source>tooltip_grb_symbology</source>
			<translation>grb_symbology</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>doc</name>
		<message>
			<source>title</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Dodaj geom</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>Dodaj geom</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Zastosuj</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>Zastosuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_insert</source>
			<translation>btn_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_insert</source>
			<translation>Wstawka</translation>
		</message>
		<message>
			<source>btn_path_doc</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path_doc</source>
			<translation>btn_path_doc</translation>
		</message>
		<message>
			<source>btn_path_url</source>
			<translation>sieć</translation>
		</message>
		<message>
			<source>tooltip_btn_path_url</source>
			<translation>Otwórz eksplorator, aby umożliwić wybór ścieżki internetowej. Możliwe jest również wklejenie ścieżki do pola tekstowego Link</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>btn_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Snapping</translation>
		</message>
		<message>
			<source>date</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_date</source>
			<translation>date</translation>
		</message>
		<message>
			<source>_dlg_doc</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip__dlg_doc</source>
			<translation>_dlg_doc</translation>
		</message>
		<message>
			<source>dlg_doc</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_dlg_doc</source>
			<translation>dlg_doc</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Data:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_doc_name</source>
			<translation>Nazwa dokumentu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_name</source>
			<translation>lbl_doc_name</translation>
		</message>
		<message>
			<source>lbl_doc_type</source>
			<translation>Typ dokumentu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_type</source>
			<translation>lbl_doc_type</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Nazwa dokumentu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Link:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Obserwacje:</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>path</source>
			<translation>ścieżka</translation>
		</message>
		<message>
			<source>tooltip_path</source>
			<translation>Wypełnij go dostępną ścieżką folderu lub ścieżką internetową.</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Odwiedź</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_doc</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_tab_doc</source>
			<translation>tab_doc</translation>
		</message>
		<message>
			<source>tab_elem</source>
			<translation>Element</translation>
		</message>
		<message>
			<source>tooltip_tab_elem</source>
			<translation>tab_elem</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_psector</source>
			<translation>Sektor</translation>
		</message>
		<message>
			<source>tooltip_tab_psector</source>
			<translation>tab_psector</translation>
		</message>
		<message>
			<source>tab_rel</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>tooltip_tab_rel</source>
			<translation>tab_rel</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Odwiedź</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
		<message>
			<source>tab_workcat</source>
			<translation>Workcat</translation>
		</message>
		<message>
			<source>tooltip_tab_workcat</source>
			<translation>tab_workcat</translation>
		</message>
	</context>
	<context>
		<name>doc_manager</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie dokumentami</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>dlg_doc_manager</source>
			<translation>Zarządzanie dokumentami</translation>
		</message>
		<message>
			<source>tooltip_dlg_doc_manager</source>
			<translation>dlg_doc_manager</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtruj według: Nazwa dokumentu</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>dscenario</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_properties</source>
			<translation>Właściwości</translation>
		</message>
		<message>
			<source>tooltip_btn_properties</source>
			<translation>btn_properties</translation>
		</message>
		<message>
			<source>dlg_dscenario</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_dscenario</source>
			<translation>dlg_dscenario</translation>
		</message>
	</context>
	<context>
		<name>dscenario_manager</name>
		<message>
			<source>title</source>
			<translation>Menedżer scenariusza</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>     Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplikat</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>btn_toolbox</source>
			<translation>Działania</translation>
		</message>
		<message>
			<source>tooltip_btn_toolbox</source>
			<translation>btn_toolbox</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>btn_update_dscenario</source>
			<translation>Bieżący scenariusz</translation>
		</message>
		<message>
			<source>tooltip_btn_update_dscenario</source>
			<translation>btn_update_dscenario</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Pokaż nieaktywne</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Pokaż nieaktywne</translation>
		</message>
		<message>
			<source>dlg_dscenario_manager</source>
			<translation>Menedżer scenariusza</translation>
		</message>
		<message>
			<source>tooltip_dlg_dscenario_manager</source>
			<translation>dlg_dscenario_manager</translation>
		</message>
		<message>
			<source>lbl_dscenario_name</source>
			<translation>Filtruj według: Nazwa scenariusza</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario_name</source>
			<translation>lbl_dscenario_name</translation>
		</message>
	</context>
	<context>
		<name>element</name>
		<message>
			<source>title</source>
			<translation>Element</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Dodaj geom</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>Dodaj geometrię</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_insert</source>
			<translation>btn_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_insert</source>
			<translation>Wstawka</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>btn_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Snapping</translation>
		</message>
		<message>
			<source>dlg_element</source>
			<translation>Element</translation>
		</message>
		<message>
			<source>tooltip_dlg_element</source>
			<translation>dlg_element</translation>
		</message>
		<message>
			<source>lbl_buildercat_id</source>
			<translation>Identyfikator Buildercat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_buildercat_id</source>
			<translation>lbl_buildercat_id</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Data budowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>lbl_builtdate</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation> Kod:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_comment</source>
			<translation>Jak mogę pomóc?</translation>
		</message>
		<message>
			<source>tooltip_lbl_comment</source>
			<translation>lbl_comment</translation>
		</message>
		<message>
			<source>lbl_elementcat_id</source>
			<translation>Elementcat id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_elementcat_id</source>
			<translation>lbl_elementcat_id</translation>
		</message>
		<message>
			<source>lbl_element_id</source>
			<translation>Identyfikator elementu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_element_id</source>
			<translation>lbl_element_id</translation>
		</message>
		<message>
			<source>lbl_element_type</source>
			<translation>Element_type:</translation>
		</message>
		<message>
			<source>tooltip_lbl_element_type</source>
			<translation>lbl_element_type</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Data zakończenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>Działanie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Link:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>lbl_location_type</source>
			<translation>Typ lokalizacji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_location_type</source>
			<translation>lbl_location_type</translation>
		</message>
		<message>
			<source>lbl_lock_level</source>
			<translation>TextLabel</translation>
		</message>
		<message>
			<source>tooltip_lbl_lock_level</source>
			<translation>lbl_lock_level</translation>
		</message>
		<message>
			<source>lbl_num_element</source>
			<translation>Numer elementu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_num_element</source>
			<translation>lbl_num_element</translation>
		</message>
		<message>
			<source>lbl_num_elements</source>
			<translation>Liczba elementów:</translation>
		</message>
		<message>
			<source>tooltip_lbl_num_elements</source>
			<translation>lbl_num_elements</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Obserwacje:</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_ownercat_id</source>
			<translation>Właściciel:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ownercat_id</source>
			<translation>lbl_ownercat_id</translation>
		</message>
		<message>
			<source>lbl_rotation</source>
			<translation>Rotacja:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rotation</source>
			<translation>lbl_rotation</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Stan:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
		<message>
			<source>lbl_state_type</source>
			<translation>Typ państwa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state_type</source>
			<translation>lbl_state_type</translation>
		</message>
		<message>
			<source>lbl_verified</source>
			<translation>Zweryfikowano:</translation>
		</message>
		<message>
			<source>tooltip_lbl_verified</source>
			<translation>lbl_verified</translation>
		</message>
		<message>
			<source>lbl_workcat_id</source>
			<translation>Identyfikator Workcat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id</source>
			<translation>Identyfikator Workcat</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Koniec identyfikatora Workcat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>Koniec identyfikatora Workcat</translation>
		</message>
		<message>
			<source>rotation</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_rotation</source>
			<translation>rotation</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_element</source>
			<translation>Element</translation>
		</message>
		<message>
			<source>tooltip_tab_element</source>
			<translation>tab_element</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>undelete</source>
			<translation>Cofnij usunięcie</translation>
		</message>
		<message>
			<source>tooltip_undelete</source>
			<translation>undelete</translation>
		</message>
	</context>
	<context>
		<name>element_manager</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie elementami</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>dlg_element_manager</source>
			<translation>Zarządzanie elementami</translation>
		</message>
		<message>
			<source>tooltip_dlg_element_manager</source>
			<translation>dlg_element_manager</translation>
		</message>
		<message>
			<source>lbl_element_id</source>
			<translation>Filtruj według: Id elementu</translation>
		</message>
		<message>
			<source>tooltip_lbl_element_id</source>
			<translation>lbl_element_id</translation>
		</message>
	</context>
	<context>
		<name>emitter_calibration</name>
		<message>
			<source>title</source>
			<translation>Kalibracja Emmitera</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_emitter_calibration</source>
			<translation>Kalibracja Emmitera</translation>
		</message>
		<message>
			<source>tooltip_dlg_emitter_calibration</source>
			<translation>dlg_emitter_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Plik wejściowy INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_filename</source>
			<translation>Nazwa plików wyjściowych:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_filename</source>
			<translation>lbl_output_filename</translation>
		</message>
	</context>
	<context>
		<name>epatools_add_demand_check</name>
		<message>
			<source>title</source>
			<translation>Dodatkowa kontrola popytu</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_add_demand_check</source>
			<translation>Dodatkowa kontrola popytu</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_add_demand_check</source>
			<translation>dlg_epatools_add_demand_check</translation>
		</message>
		<message>
			<source>lbl_config</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config</source>
			<translation>lbl_config</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Plik wejściowy INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Użyj węzłów z:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Folder wyjściowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>rdb_nodes_config</source>
			<translation>Plik konfiguracyjny</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_config</source>
			<translation>rdb_nodes_config</translation>
		</message>
		<message>
			<source>rdb_nodes_database</source>
			<translation>Baza danych</translation>
		</message>
		<message>
			<source>tooltip_rdb_nodes_database</source>
			<translation>rdb_nodes_database</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_emitter_calibration</name>
		<message>
			<source>title</source>
			<translation>Kalibracja emitera</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_emitter_calibration</source>
			<translation>Kalibracja emitera</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_emitter_calibration</source>
			<translation>dlg_epatools_emitter_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Plik wejściowy INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_filename</source>
			<translation>Nazwa plików wyjściowych:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_filename</source>
			<translation>lbl_output_filename</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>epatools_quantized_demands</name>
		<message>
			<source>title</source>
			<translation>Skwantyzowane wymagania</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_quantized_demands</source>
			<translation>Skwantyzowane wymagania</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_quantized_demands</source>
			<translation>dlg_epatools_quantized_demands</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Plik wejściowy INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Folder wyjściowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_recursive_go2epa</name>
		<message>
			<source>title</source>
			<translation>Połączenia wielokrotne Epa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_recursive_go2epa</source>
			<translation>Połączenia wielokrotne Epa</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_recursive_go2epa</source>
			<translation>dlg_epatools_recursive_go2epa</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Folder wyjściowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_static_calibration</name>
		<message>
			<source>title</source>
			<translation>Kalibracja statyczna</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>btn_save_dscenario</source>
			<translation>Zapisz zmiany w dscenario</translation>
		</message>
		<message>
			<source>tooltip_btn_save_dscenario</source>
			<translation>btn_save_dscenario</translation>
		</message>
		<message>
			<source>dlg_epatools_static_calibration</source>
			<translation>Kalibracja statyczna</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_static_calibration</source>
			<translation>dlg_epatools_static_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_dscenario</source>
			<translation>Scenariusz:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario</source>
			<translation>lbl_dscenario</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_inp_input_file</source>
			<translation>Plik wejściowy INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_input_file</source>
			<translation>lbl_inp_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Folder wyjściowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>epatools_valve_operation_check</name>
		<message>
			<source>title</source>
			<translation>Kontrola działania zaworu</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_push_config_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_config_file</source>
			<translation>btn_push_config_file</translation>
		</message>
		<message>
			<source>btn_push_inp_input_file</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_inp_input_file</source>
			<translation>btn_push_inp_input_file</translation>
		</message>
		<message>
			<source>btn_push_output_folder</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_push_output_folder</source>
			<translation>btn_push_output_folder</translation>
		</message>
		<message>
			<source>dlg_epatools_valve_operation_check</source>
			<translation>Kontrola działania zaworu</translation>
		</message>
		<message>
			<source>tooltip_dlg_epatools_valve_operation_check</source>
			<translation>dlg_epatools_valve_operation_check</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Plik wejściowy INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Folder wyjściowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>lbl_scenarios</source>
			<translation>Użyj scenariuszy z:</translation>
		</message>
		<message>
			<source>tooltip_lbl_scenarios</source>
			<translation>lbl_scenarios</translation>
		</message>
		<message>
			<source>rdb_scenarios_config</source>
			<translation>Plik konfiguracyjny</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_config</source>
			<translation>rdb_scenarios_config</translation>
		</message>
		<message>
			<source>rdb_scenarios_database</source>
			<translation>Baza danych</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_database</source>
			<translation>rdb_scenarios_database</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>fastprint</name>
		<message>
			<source>title</source>
			<translation>Drukuj</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_preview</source>
			<translation>Podgląd</translation>
		</message>
		<message>
			<source>tooltip_btn_preview</source>
			<translation>btn_preview</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Drukuj</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>btn_print</translation>
		</message>
		<message>
			<source>dlg_fastprint</source>
			<translation>Drukuj</translation>
		</message>
		<message>
			<source>tooltip_dlg_fastprint</source>
			<translation>dlg_fastprint</translation>
		</message>
		<message>
			<source>grb_map_options</source>
			<translation>Opcje mapy:</translation>
		</message>
		<message>
			<source>tooltip_grb_map_options</source>
			<translation>grb_map_options</translation>
		</message>
		<message>
			<source>grb_option_values</source>
			<translation>Wartości opcjonalne:</translation>
		</message>
		<message>
			<source>tooltip_grb_option_values</source>
			<translation>grb_option_values</translation>
		</message>
	</context>
	<context>
		<name>feature_delete</name>
		<message>
			<source>title</source>
			<translation>Usuń funkcję</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>       Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń wybraną funkcję</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_delete_another</source>
			<translation>Usuń inną funkcję</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_another</source>
			<translation>btn_delete_another</translation>
		</message>
		<message>
			<source>btn_relations</source>
			<translation>Pokaż relacje funkcji</translation>
		</message>
		<message>
			<source>tooltip_btn_relations</source>
			<translation>btn_relations</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>btn_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Snapping</translation>
		</message>
		<message>
			<source>dlg_feature_delete</source>
			<translation>Usuń funkcję</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_delete</source>
			<translation>dlg_feature_delete</translation>
		</message>
		<message>
			<source>lbl_feature_id</source>
			<translation>Identyfikator funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_id</source>
			<translation>lbl_feature_id</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Typ funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>tab_del_feature</source>
			<translation>Usuń funkcję</translation>
		</message>
		<message>
			<source>tooltip_tab_del_feature</source>
			<translation>tab_del_feature</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>feature_end</name>
		<message>
			<source>title</source>
			<translation>Funkcja końcowa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_insert</source>
			<translation>btn_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_insert</source>
			<translation>Wstawka</translation>
		</message>
		<message>
			<source>btn_new_workcat</source>
			<translation>btn_new_workcat</translation>
		</message>
		<message>
			<source>tooltip_btn_new_workcat</source>
			<translation>btn_new_workcat</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>btn_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Snapping</translation>
		</message>
		<message>
			<source>builtdate</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_builtdate</source>
			<translation>builtdate</translation>
		</message>
		<message>
			<source>dlg_feature_end</source>
			<translation>Funkcja końcowa</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_end</source>
			<translation>dlg_feature_end</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>lbl_description</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_description</source>
			<translation>lbl_description</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Data zakończenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_state_type</source>
			<translation>Koniec typu stanu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state_type</source>
			<translation>lbl_state_type</translation>
		</message>
		<message>
			<source>lbl_workcat_date</source>
			<translation>Data rozpoczęcia pracy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_date</source>
			<translation>lbl_workcat_date</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Koniec identyfikatora Workcat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_elem</source>
			<translation>Elem</translation>
		</message>
		<message>
			<source>tooltip_tab_elem</source>
			<translation>tab_elem</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>tab_workcat</source>
			<translation>Workcat</translation>
		</message>
		<message>
			<source>tooltip_tab_workcat</source>
			<translation>tab_workcat</translation>
		</message>
	</context>
	<context>
		<name>feature_end_connec</name>
		<message>
			<source>title</source>
			<translation>Lista końcowa Workcat</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>dlg_feature_end_connec</source>
			<translation>Lista końcowa Workcat</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_end_connec</source>
			<translation>dlg_feature_end_connec</translation>
		</message>
		<message>
			<source>lbl_filter_by</source>
			<translation>Filtruj według arc_id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_by</source>
			<translation>lbl_filter_by</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Te połączenia lub wpusty zostaną rozłączone po usunięciu wybranych łuków</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
	</context>
	<context>
		<name>feature_replace</name>
		<message>
			<source>title</source>
			<translation>Zastąp funkcję</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Ok</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_config</source>
			<translation>config</translation>
		</message>
		<message>
			<source>dlg_feature_replace</source>
			<translation>Zastąp funkcję</translation>
		</message>
		<message>
			<source>tooltip_dlg_feature_replace</source>
			<translation>dlg_feature_replace</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>grb_end_parameters</source>
			<translation>Parametry końcowe</translation>
		</message>
		<message>
			<source>tooltip_grb_end_parameters</source>
			<translation>grb_end_parameters</translation>
		</message>
		<message>
			<source>grb_feature_parameters</source>
			<translation>Parametry funkcji</translation>
		</message>
		<message>
			<source>tooltip_grb_feature_parameters</source>
			<translation>grb_feature_parameters</translation>
		</message>
		<message>
			<source>lbl_catalog_id</source>
			<translation>Katalog:</translation>
		</message>
		<message>
			<source>tooltip_lbl_catalog_id</source>
			<translation>lbl_catalog_id</translation>
		</message>
		<message>
			<source>lbl_current_catalog_id</source>
			<translation>Aktualny identyfikator katalogu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_current_catalog_id</source>
			<translation>lbl_current_catalog_id</translation>
		</message>
		<message>
			<source>lbl_description</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_description</source>
			<translation>lbl_description</translation>
		</message>
		<message>
			<source>lbl_enddate</source>
			<translation>Data wymiany:</translation>
		</message>
		<message>
			<source>tooltip_lbl_enddate</source>
			<translation>lbl_enddate</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Bieżący typ funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>lbl_keep_asset_id</source>
			<translation>Zachowaj identyfikator zasobu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_asset_id</source>
			<translation>lbl_keep_asset_id</translation>
		</message>
		<message>
			<source>lbl_keep_elements</source>
			<translation>Zachowaj elementy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_elements</source>
			<translation>lbl_keep_elements</translation>
		</message>
		<message>
			<source>lbl_keep_epa_values</source>
			<translation>Zachowaj wartości EPA:</translation>
		</message>
		<message>
			<source>tooltip_lbl_keep_epa_values</source>
			<translation>lbl_keep_epa_values</translation>
		</message>
		<message>
			<source>lbl_new_catalog_id</source>
			<translation>Nowy identyfikator katalogowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_catalog_id</source>
			<translation>lbl_new_catalog_id</translation>
		</message>
		<message>
			<source>lbl_new_feature_type</source>
			<translation>Nowy typ funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_feature_type</source>
			<translation>lbl_new_feature_type</translation>
		</message>
		<message>
			<source>lbl_workcat_id_end</source>
			<translation>Identyfikator Workcat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id_end</source>
			<translation>lbl_workcat_id_end</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>featuretype_change</name>
		<message>
			<source>title</source>
			<translation>Zmiana typu funkcji</translation>
		</message>
		<message>
			<source>dlg_featuretype_change</source>
			<translation>Zmiana typu funkcji</translation>
		</message>
		<message>
			<source>tooltip_dlg_featuretype_change</source>
			<translation>dlg_featuretype_change</translation>
		</message>
	</context>
	<context>
		<name>go2epa</name>
		<message>
			<source>title</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_file_inp</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_inp</source>
			<translation>btn_file_inp</translation>
		</message>
		<message>
			<source>btn_file_rpt</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_file_rpt</source>
			<translation>btn_file_rpt</translation>
		</message>
		<message>
			<source>btn_hs_ds</source>
			<translation>Selektor</translation>
		</message>
		<message>
			<source>tooltip_btn_hs_ds</source>
			<translation>btn_hs_ds</translation>
		</message>
		<message>
			<source>btn_options</source>
			<translation>Opcje</translation>
		</message>
		<message>
			<source>tooltip_btn_options</source>
			<translation>btn_options</translation>
		</message>
		<message>
			<source>chk_exec</source>
			<translation>Wykonywanie oprogramowania EPA</translation>
		</message>
		<message>
			<source>tooltip_chk_exec</source>
			<translation>chk_exec</translation>
		</message>
		<message>
			<source>chk_export</source>
			<translation>Eksport INP</translation>
		</message>
		<message>
			<source>tooltip_chk_export</source>
			<translation>chk_export</translation>
		</message>
		<message>
			<source>chk_export_subcatch</source>
			<translation>Eksport zlewni UD</translation>
		</message>
		<message>
			<source>tooltip_chk_export_subcatch</source>
			<translation>chk_export_subcatch</translation>
		</message>
		<message>
			<source>chk_import_result</source>
			<translation>Wynik importu</translation>
		</message>
		<message>
			<source>tooltip_chk_import_result</source>
			<translation>chk_import_result</translation>
		</message>
		<message>
			<source>chk_only_check</source>
			<translation>Użyj geometrii sieci wyników</translation>
		</message>
		<message>
			<source>tooltip_chk_only_check</source>
			<translation>chk_only_check</translation>
		</message>
		<message>
			<source>chk_recurrent</source>
			<translation>Używanie wywołań iteracyjnych</translation>
		</message>
		<message>
			<source>tooltip_chk_recurrent</source>
			<translation>chk_recurrent</translation>
		</message>
		<message>
			<source>dlg_go2epa</source>
			<translation>Go2Epa</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa</source>
			<translation>dlg_go2epa</translation>
		</message>
		<message>
			<source>grb_file_manager</source>
			<translation>Menedżer plików</translation>
		</message>
		<message>
			<source>tooltip_grb_file_manager</source>
			<translation>grb_file_manager</translation>
		</message>
		<message>
			<source>grb_process_options</source>
			<translation>Opcje przetwarzania wstępnego</translation>
		</message>
		<message>
			<source>tooltip_grb_process_options</source>
			<translation>grb_process_options</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Opcje przetwarzania wstępnego</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Menedżer plików</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_counter</source>
			<translation>Licznik</translation>
		</message>
		<message>
			<source>tooltip_lbl_counter</source>
			<translation>lbl_counter</translation>
		</message>
		<message>
			<source>lbl_inp_file</source>
			<translation>Plik INP:            </translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_file</source>
			<translation>lbl_inp_file</translation>
		</message>
		<message>
			<source>lbl_result_name</source>
			<translation>Nazwa wyniku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name</source>
			<translation>lbl_result_name</translation>
		</message>
		<message>
			<source>lbl_rpt_file</source>
			<translation>Plik RPT:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rpt_file</source>
			<translation>lbl_rpt_file</translation>
		</message>
		<message>
			<source>tab_file_manager</source>
			<translation>Menedżer plików</translation>
		</message>
		<message>
			<source>tooltip_tab_file_manager</source>
			<translation>tab_file_manager</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>go2epa_manager</name>
		<message>
			<source>title</source>
			<translation>Menedżer wyników EPA</translation>
		</message>
		<message>
			<source>btn_archive</source>
			<translation>Przełącz archiwum</translation>
		</message>
		<message>
			<source>tooltip_btn_archive</source>
			<translation>Przełącz archiwum</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_edit</source>
			<translation>Edytuj</translation>
		</message>
		<message>
			<source>tooltip_btn_edit</source>
			<translation>Edytuj</translation>
		</message>
		<message>
			<source>btn_show_inp_data</source>
			<translation>Pokaż dane wejściowe</translation>
		</message>
		<message>
			<source>tooltip_btn_show_inp_data</source>
			<translation>Pokaż dane wejściowe</translation>
		</message>
		<message>
			<source>btn_toggle_corporate</source>
			<translation>Przełączanie korporacyjne</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_corporate</source>
			<translation>btn_toggle_corporate</translation>
		</message>
		<message>
			<source>dlg_go2epa_manager</source>
			<translation>Menedżer wyników EPA</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_manager</source>
			<translation>dlg_go2epa_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Filtruj według: Identyfikator wyniku</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
	</context>
	<context>
		<name>go2epa_options</name>
		<message>
			<source>title</source>
			<translation>Go2Epa - opcje</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_go2epa_options</source>
			<translation>Go2Epa - opcje</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_options</source>
			<translation>dlg_go2epa_options</translation>
		</message>
		<message>
			<source>grb_energy</source>
			<translation>Energia</translation>
		</message>
		<message>
			<source>tooltip_grb_energy</source>
			<translation>grb_energy</translation>
		</message>
		<message>
			<source>grb_general</source>
			<translation>Ogólne</translation>
		</message>
		<message>
			<source>tooltip_grb_general</source>
			<translation>grb_general</translation>
		</message>
		<message>
			<source>grb_hydraulics</source>
			<translation>Hydraulika</translation>
		</message>
		<message>
			<source>tooltip_grb_hydraulics</source>
			<translation>grb_hydraulics</translation>
		</message>
		<message>
			<source>grb_other</source>
			<translation>Inne</translation>
		</message>
		<message>
			<source>tooltip_grb_other</source>
			<translation>grb_other</translation>
		</message>
		<message>
			<source>grb_reactions</source>
			<translation>Reakcje</translation>
		</message>
		<message>
			<source>tooltip_grb_reactions</source>
			<translation>grb_reactions</translation>
		</message>
		<message>
			<source>grb_reports</source>
			<translation>Raporty</translation>
		</message>
		<message>
			<source>tooltip_grb_reports</source>
			<translation>grb_reports</translation>
		</message>
		<message>
			<source>grb_time_steps</source>
			<translation>Data &amp;amp; kroki czasowe</translation>
		</message>
		<message>
			<source>tooltip_grb_time_steps</source>
			<translation>grb_time_steps</translation>
		</message>
		<message>
			<source>tab_inp</source>
			<translation>Inp</translation>
		</message>
		<message>
			<source>tooltip_tab_inp</source>
			<translation>tab_inp</translation>
		</message>
		<message>
			<source>tab_other</source>
			<translation>Inne</translation>
		</message>
		<message>
			<source>tooltip_tab_other</source>
			<translation>tab_other</translation>
		</message>
	</context>
	<context>
		<name>go2epa_result</name>
		<message>
			<source>title</source>
			<translation>Selektor wyników EPA</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>dlg_go2epa_result</source>
			<translation>Selektor wyników EPA</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_result</source>
			<translation>dlg_go2epa_result</translation>
		</message>
		<message>
			<source>lbl_compare_date</source>
			<translation>Daty pojawienia się:</translation>
		</message>
		<message>
			<source>tooltip_lbl_compare_date</source>
			<translation>lbl_compare_date</translation>
		</message>
		<message>
			<source>lbl_compare_time</source>
			<translation>Porównaj czas:</translation>
		</message>
		<message>
			<source>tooltip_lbl_compare_time</source>
			<translation>lbl_compare_time</translation>
		</message>
		<message>
			<source>lbl_result_name_to_compare</source>
			<translation>Nazwa wyniku (do porównania):</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name_to_compare</source>
			<translation>lbl_result_name_to_compare</translation>
		</message>
		<message>
			<source>lbl_result_name_to_show</source>
			<translation>Nazwa wyniku (do wyświetlenia):</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name_to_show</source>
			<translation>lbl_result_name_to_show</translation>
		</message>
		<message>
			<source>lbl_selector_date</source>
			<translation>Data wyboru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_selector_date</source>
			<translation>lbl_selector_date</translation>
		</message>
		<message>
			<source>lbl_selector_time</source>
			<translation>Czas wyboru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_selector_time</source>
			<translation>lbl_selector_time</translation>
		</message>
		<message>
			<source>lbl_time_to_compare</source>
			<translation>Czas (do porównania):</translation>
		</message>
		<message>
			<source>tooltip_lbl_time_to_compare</source>
			<translation>lbl_time_to_compare</translation>
		</message>
		<message>
			<source>lbl_time_to_show</source>
			<translation>Czas (do wyświetlenia):</translation>
		</message>
		<message>
			<source>tooltip_lbl_time_to_show</source>
			<translation>lbl_time_to_show</translation>
		</message>
		<message>
			<source>tab_datetime</source>
			<translation>Data i godzina</translation>
		</message>
		<message>
			<source>tooltip_tab_datetime</source>
			<translation>tab_datetime</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Wynik</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
		<message>
			<source>tab_time</source>
			<translation>Czas</translation>
		</message>
		<message>
			<source>tooltip_tab_time</source>
			<translation>tab_time</translation>
		</message>
	</context>
	<context>
		<name>go2epa_selector</name>
		<message>
			<source>title</source>
			<translation>Selektor porównania wyników</translation>
		</message>
		<message>
			<source>dlg_go2epa_selector</source>
			<translation>Selektor porównania wyników</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2epa_selector</source>
			<translation>dlg_go2epa_selector</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Wynik</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
		<message>
			<source>tab_time</source>
			<translation>Data i godzina</translation>
		</message>
		<message>
			<source>tooltip_tab_time</source>
			<translation>tab_time</translation>
		</message>
	</context>
	<context>
		<name>go2iber</name>
		<message>
			<source>title</source>
			<translation>Go2Iber</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_iber_options</source>
			<translation>Opcje Iber</translation>
		</message>
		<message>
			<source>tooltip_btn_iber_options</source>
			<translation>Opcje Iber</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_swmm_options</source>
			<translation>Opcje SWMM</translation>
		</message>
		<message>
			<source>tooltip_btn_swmm_options</source>
			<translation>Opcje SWMM</translation>
		</message>
		<message>
			<source>dlg_go2iber</source>
			<translation>Go2Iber</translation>
		</message>
		<message>
			<source>tooltip_dlg_go2iber</source>
			<translation>dlg_go2iber</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Opcje</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>lbl_mesh</source>
			<translation>Siatka:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mesh</source>
			<translation>lbl_mesh</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Ścieżka folderu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
		<message>
			<source>lbl_result_name</source>
			<translation>Nazwa wyniku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_name</source>
			<translation>lbl_result_name</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
	</context>
	<context>
		<name>info_catalog</name>
		<message>
			<source>title</source>
			<translation>Katalog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_info_catalog</source>
			<translation>Katalog</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_catalog</source>
			<translation>dlg_info_catalog</translation>
		</message>
	</context>
	<context>
		<name>info_crmvalue</name>
		<message>
			<source>title</source>
			<translation>Hydrometr</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_info_crmvalue</source>
			<translation>Hydrometr</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_crmvalue</source>
			<translation>dlg_info_crmvalue</translation>
		</message>
		<message>
			<source>lbl_hydrometer_id</source>
			<translation>Identyfikator hydrometru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hydrometer_id</source>
			<translation>lbl_hydrometer_id</translation>
		</message>
	</context>
	<context>
		<name>info_crossect</name>
		<message>
			<source>title</source>
			<translation>Sekcja</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>dlg_info_crossect</source>
			<translation>Sekcja</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_crossect</source>
			<translation>dlg_info_crossect</translation>
		</message>
		<message>
			<source>lbl_cost_area</source>
			<translation>Obszar przewodu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_area</source>
			<translation>lbl_cost_area</translation>
		</message>
		<message>
			<source>lbl_cost_b_left</source>
			<translation>Koszt B lewy</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_b_left</source>
			<translation>lbl_cost_b_left</translation>
		</message>
		<message>
			<source>lbl_cost_b_right</source>
			<translation>Koszt B w prawo</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_b_right</source>
			<translation>lbl_cost_b_right</translation>
		</message>
		<message>
			<source>lbl_cost_bulk</source>
			<translation>Przewód luzem:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_bulk</source>
			<translation>lbl_cost_bulk</translation>
		</message>
		<message>
			<source>lbl_cost_exc</source>
			<translation>m3/ml Nadmiar:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_exc</source>
			<translation>lbl_cost_exc</translation>
		</message>
		<message>
			<source>lbl_cost_excav</source>
			<translation>m3/ml Wykop:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_excav</source>
			<translation>lbl_cost_excav</translation>
		</message>
		<message>
			<source>lbl_cost_fill</source>
			<translation>m3/ml Napełnianie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_fill</source>
			<translation>lbl_cost_fill</translation>
		</message>
		<message>
			<source>lbl_cost_trench</source>
			<translation>% Trenchlinning:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_trench</source>
			<translation>lbl_cost_trench</translation>
		</message>
		<message>
			<source>lbl_cost_width</source>
			<translation>Szerokość kosztów</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_width</source>
			<translation>lbl_cost_width</translation>
		</message>
		<message>
			<source>lbl_cost_y_param</source>
			<translation>Koszt i parametry</translation>
		</message>
		<message>
			<source>tooltip_lbl_cost_y_param</source>
			<translation>lbl_cost_y_param</translation>
		</message>
		<message>
			<source>lbl_section_image</source>
			<translation>Obraz sekcji</translation>
		</message>
		<message>
			<source>tooltip_lbl_section_image</source>
			<translation>lbl_section_image</translation>
		</message>
	</context>
	<context>
		<name>info_epa</name>
		<message>
			<source>title</source>
			<translation>InfoEpa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_info_epa</source>
			<translation>InfoEpa</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_epa</source>
			<translation>dlg_info_epa</translation>
		</message>
		<message>
			<source>info_epa</source>
			<translation>InfoEpa</translation>
		</message>
		<message>
			<source>tooltip_info_epa</source>
			<translation>info_epa</translation>
		</message>
		<message>
			<source>page_base</source>
			<translation>Podstawa</translation>
		</message>
		<message>
			<source>tooltip_page_base</source>
			<translation>page_base</translation>
		</message>
		<message>
			<source>page_dscenario</source>
			<translation>Scenariusz</translation>
		</message>
		<message>
			<source>tooltip_page_dscenario</source>
			<translation>page_dscenario</translation>
		</message>
		<message>
			<source>page_dwf</source>
			<translation>DWF</translation>
		</message>
		<message>
			<source>tooltip_page_dwf</source>
			<translation>page_dwf</translation>
		</message>
		<message>
			<source>page_inflows</source>
			<translation>PRZYPŁYWY</translation>
		</message>
		<message>
			<source>tooltip_page_inflows</source>
			<translation>page_inflows</translation>
		</message>
	</context>
	<context>
		<name>info_feature</name>
		<message>
			<source>title</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>actionAudit</source>
			<translation>Audyt</translation>
		</message>
		<message>
			<source>tooltip_actionAudit</source>
			<translation>actionAudit</translation>
		</message>
		<message>
			<source>actionCatalog</source>
			<translation>Katalog</translation>
		</message>
		<message>
			<source>tooltip_actionCatalog</source>
			<translation>actionCatalog</translation>
		</message>
		<message>
			<source>actionCentered</source>
			<translation>Wyśrodkowany</translation>
		</message>
		<message>
			<source>tooltip_actionCentered</source>
			<translation>actionCentered</translation>
		</message>
		<message>
			<source>actionCopyPaste</source>
			<translation>Kopiuj&amp;amp;Wklej</translation>
		</message>
		<message>
			<source>tooltip_actionCopyPaste</source>
			<translation>actionCopyPaste</translation>
		</message>
		<message>
			<source>actionDemand</source>
			<translation>Zapotrzebowanie</translation>
		</message>
		<message>
			<source>tooltip_actionDemand</source>
			<translation>actionDemand</translation>
		</message>
		<message>
			<source>actionEdit</source>
			<translation>Edytuj</translation>
		</message>
		<message>
			<source>tooltip_actionEdit</source>
			<translation>actionEdit</translation>
		</message>
		<message>
			<source>actionGetArcId</source>
			<translation>Uzyskaj nowy identyfikator łuku</translation>
		</message>
		<message>
			<source>tooltip_actionGetArcId</source>
			<translation>actionGetArcId</translation>
		</message>
		<message>
			<source>actionGetParentId</source>
			<translation>Pobierz nowy identyfikator rodzica</translation>
		</message>
		<message>
			<source>tooltip_actionGetParentId</source>
			<translation>actionGetParentId</translation>
		</message>
		<message>
			<source>actionHelp</source>
			<translation>Pomoc</translation>
		</message>
		<message>
			<source>tooltip_actionHelp</source>
			<translation>actionHelp</translation>
		</message>
		<message>
			<source>actionInterpolate</source>
			<translation>Interpoluj</translation>
		</message>
		<message>
			<source>tooltip_actionInterpolate</source>
			<translation>actionInterpolate</translation>
		</message>
		<message>
			<source>actionLink</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_actionLink</source>
			<translation>actionLink</translation>
		</message>
		<message>
			<source>actionMapZone</source>
			<translation>MapZone</translation>
		</message>
		<message>
			<source>tooltip_actionMapZone</source>
			<translation>actionMapZone</translation>
		</message>
		<message>
			<source>actionOrifice</source>
			<translation>Kryza</translation>
		</message>
		<message>
			<source>tooltip_actionOrifice</source>
			<translation>actionOrifice</translation>
		</message>
		<message>
			<source>actionOutlet</source>
			<translation>Outlet</translation>
		</message>
		<message>
			<source>tooltip_actionOutlet</source>
			<translation>actionOutlet</translation>
		</message>
		<message>
			<source>actionRotation</source>
			<translation>Rotacja</translation>
		</message>
		<message>
			<source>tooltip_actionRotation</source>
			<translation>actionRotation</translation>
		</message>
		<message>
			<source>actionSection</source>
			<translation>Pokaż sekcję</translation>
		</message>
		<message>
			<source>tooltip_actionSection</source>
			<translation>actionSection</translation>
		</message>
		<message>
			<source>actionSetGeom</source>
			<translation>Set Geom</translation>
		</message>
		<message>
			<source>tooltip_actionSetGeom</source>
			<translation>actionSetGeom</translation>
		</message>
		<message>
			<source>actionSetToArc</source>
			<translation>Ustawiony na łuk</translation>
		</message>
		<message>
			<source>tooltip_actionSetToArc</source>
			<translation>actionSetToArc</translation>
		</message>
		<message>
			<source>actionWeir</source>
			<translation>Weir</translation>
		</message>
		<message>
			<source>tooltip_actionWeir</source>
			<translation>actionWeir</translation>
		</message>
		<message>
			<source>actionWorkcat</source>
			<translation>Workcat</translation>
		</message>
		<message>
			<source>tooltip_actionWorkcat</source>
			<translation>actionWorkcat</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_apply</source>
			<translation>Zastosuj</translation>
		</message>
		<message>
			<source>tooltip_btn_apply</source>
			<translation>Zastosuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_doc_delete</source>
			<translation>btn_doc_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_doc_delete</source>
			<translation>Usuń dokument</translation>
		</message>
		<message>
			<source>btn_doc_insert</source>
			<translation>btn_doc_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_doc_insert</source>
			<translation>Wstaw dokument</translation>
		</message>
		<message>
			<source>btn_doc_new</source>
			<translation>btn_doc_new</translation>
		</message>
		<message>
			<source>tooltip_btn_doc_new</source>
			<translation>Tworzenie nowego dokumentu</translation>
		</message>
		<message>
			<source>btn_insert</source>
			<translation>btn_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_insert</source>
			<translation>Wstawka</translation>
		</message>
		<message>
			<source>btn_link</source>
			<translation>btn_link</translation>
		</message>
		<message>
			<source>tooltip_btn_link</source>
			<translation>btn_link</translation>
		</message>
		<message>
			<source>btn_new_element</source>
			<translation>btn_new_element</translation>
		</message>
		<message>
			<source>tooltip_btn_new_element</source>
			<translation>btn_new_element</translation>
		</message>
		<message>
			<source>btn_new_visit</source>
			<translation>btn_new_visit</translation>
		</message>
		<message>
			<source>tooltip_btn_new_visit</source>
			<translation>btn_new_visit</translation>
		</message>
		<message>
			<source>btn_open_doc</source>
			<translation>btn_open_doc</translation>
		</message>
		<message>
			<source>tooltip_btn_open_doc</source>
			<translation>Otwórz dokument</translation>
		</message>
		<message>
			<source>btn_open_element</source>
			<translation>btn_open_element</translation>
		</message>
		<message>
			<source>tooltip_btn_open_element</source>
			<translation>btn_open_element</translation>
		</message>
		<message>
			<source>btn_open_gallery</source>
			<translation>btn_open_gallery</translation>
		</message>
		<message>
			<source>tooltip_btn_open_gallery</source>
			<translation>btn_open_gallery</translation>
		</message>
		<message>
			<source>btn_open_visit</source>
			<translation>btn_open_visit</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit</source>
			<translation>btn_open_visit</translation>
		</message>
		<message>
			<source>btn_open_visit_doc</source>
			<translation>btn_open_visit_doc</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit_doc</source>
			<translation>btn_open_visit_doc</translation>
		</message>
		<message>
			<source>btn_open_visit_event</source>
			<translation>btn_open_visit_event</translation>
		</message>
		<message>
			<source>tooltip_btn_open_visit_event</source>
			<translation>btn_open_visit_event</translation>
		</message>
		<message>
			<source>dlg_info_feature</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_feature</source>
			<translation>dlg_info_feature</translation>
		</message>
		<message>
			<source>grb_frelem_dscenario</source>
			<translation>Scenariusz</translation>
		</message>
		<message>
			<source>tooltip_grb_frelem_dscenario</source>
			<translation>grb_frelem_dscenario</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>INP</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>RPT</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_cat_per_filter</source>
			<translation>Filtr okresowy Cat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_per_filter</source>
			<translation>lbl_cat_per_filter</translation>
		</message>
		<message>
			<source>lbl_doc_id</source>
			<translation>Nazwa dokumentu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_doc_id</source>
			<translation>lbl_doc_id</translation>
		</message>
		<message>
			<source>lbl_downstream_features</source>
			<translation>Funkcje niższego szczebla:</translation>
		</message>
		<message>
			<source>tooltip_lbl_downstream_features</source>
			<translation>lbl_downstream_features</translation>
		</message>
		<message>
			<source>lbl_from_doc</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_lbl_from_doc</source>
			<translation>lbl_from_doc</translation>
		</message>
		<message>
			<source>lbl_from_om</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_lbl_from_om</source>
			<translation>lbl_from_om</translation>
		</message>
		<message>
			<source>lbl_parameter_om</source>
			<translation>Parametr:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_om</source>
			<translation>lbl_parameter_om</translation>
		</message>
		<message>
			<source>lbl_param_type_om</source>
			<translation>Typ parametru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_param_type_om</source>
			<translation>lbl_param_type_om</translation>
		</message>
		<message>
			<source>lbl_to_doc</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_to_doc</source>
			<translation>lbl_to_doc</translation>
		</message>
		<message>
			<source>lbl_to_om</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_to_om</source>
			<translation>lbl_to_om</translation>
		</message>
		<message>
			<source>lbl_type_doc</source>
			<translation>Typ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type_doc</source>
			<translation>lbl_type_doc</translation>
		</message>
		<message>
			<source>lbl_upstream_features</source>
			<translation>Funkcje upstream:</translation>
		</message>
		<message>
			<source>tooltip_lbl_upstream_features</source>
			<translation>lbl_upstream_features</translation>
		</message>
		<message>
			<source>page</source>
			<translation>Dane</translation>
		</message>
		<message>
			<source>tooltip_page</source>
			<translation>page</translation>
		</message>
		<message>
			<source>page_2</source>
			<translation>Scenariusz</translation>
		</message>
		<message>
			<source>tooltip_page_2</source>
			<translation>page_2</translation>
		</message>
		<message>
			<source>page_add</source>
			<translation>Dodatkowe dane</translation>
		</message>
		<message>
			<source>tooltip_page_add</source>
			<translation>page_add</translation>
		</message>
		<message>
			<source>page_main</source>
			<translation>Główne dane</translation>
		</message>
		<message>
			<source>tooltip_page_main</source>
			<translation>page_main</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_connections</source>
			<translation>Stożki</translation>
		</message>
		<message>
			<source>tooltip_tab_connections</source>
			<translation>tab_connections</translation>
		</message>
		<message>
			<source>tab_data</source>
			<translation>Dane</translation>
		</message>
		<message>
			<source>tooltip_tab_data</source>
			<translation>tab_data</translation>
		</message>
		<message>
			<source>tab_documents</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_tab_documents</source>
			<translation>tab_documents</translation>
		</message>
		<message>
			<source>tab_elements</source>
			<translation>Elementy</translation>
		</message>
		<message>
			<source>tooltip_tab_elements</source>
			<translation>tab_elements</translation>
		</message>
		<message>
			<source>tab_epa</source>
			<translation>EPA</translation>
		</message>
		<message>
			<source>tooltip_tab_epa</source>
			<translation>tab_epa</translation>
		</message>
		<message>
			<source>tab_event</source>
			<translation>Wydarzenie</translation>
		</message>
		<message>
			<source>tooltip_tab_event</source>
			<translation>tab_event</translation>
		</message>
		<message>
			<source>tab_features</source>
			<translation>Cechy</translation>
		</message>
		<message>
			<source>tooltip_tab_features</source>
			<translation>tab_features</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_hydrometer</source>
			<translation>Hydrometr</translation>
		</message>
		<message>
			<source>tooltip_tab_hydrometer</source>
			<translation>tab_hydrometer</translation>
		</message>
		<message>
			<source>tab_hydrometer_val</source>
			<translation>Wartości hydrometru</translation>
		</message>
		<message>
			<source>tooltip_tab_hydrometer_val</source>
			<translation>tab_hydrometer_val</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_om</source>
			<translation>O&amp;amp;&amp;amp;M</translation>
		</message>
		<message>
			<source>tooltip_tab_om</source>
			<translation>tab_om</translation>
		</message>
		<message>
			<source>tab_orifice</source>
			<translation>Kryza</translation>
		</message>
		<message>
			<source>tooltip_tab_orifice</source>
			<translation>tab_orifice</translation>
		</message>
		<message>
			<source>tab_outlet</source>
			<translation>Outlet</translation>
		</message>
		<message>
			<source>tooltip_tab_outlet</source>
			<translation>tab_outlet</translation>
		</message>
		<message>
			<source>tab_plan</source>
			<translation>Plan</translation>
		</message>
		<message>
			<source>tooltip_tab_plan</source>
			<translation>tab_plan</translation>
		</message>
		<message>
			<source>tab_pump</source>
			<translation>Pompa</translation>
		</message>
		<message>
			<source>tooltip_tab_pump</source>
			<translation>tab_pump</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>tab_rpt</source>
			<translation>Rpt</translation>
		</message>
		<message>
			<source>tooltip_tab_rpt</source>
			<translation>tab_rpt</translation>
		</message>
		<message>
			<source>tab_shortpipe</source>
			<translation>Shortpipe</translation>
		</message>
		<message>
			<source>tooltip_tab_shortpipe</source>
			<translation>tab_shortpipe</translation>
		</message>
		<message>
			<source>tab_valve</source>
			<translation>Zawór</translation>
		</message>
		<message>
			<source>tooltip_tab_valve</source>
			<translation>tab_valve</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Odwiedź</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
		<message>
			<source>tab_weir</source>
			<translation>Weir</translation>
		</message>
		<message>
			<source>tooltip_tab_weir</source>
			<translation>tab_weir</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>info_generic</name>
		<message>
			<source>title</source>
			<translation>Podstawowe informacje</translation>
		</message>
		<message>
			<source>actionEdit</source>
			<translation>Edytuj</translation>
		</message>
		<message>
			<source>tooltip_actionEdit</source>
			<translation>actionEdit</translation>
		</message>
		<message>
			<source>actionSetToArc</source>
			<translation>Set To Arc</translation>
		</message>
		<message>
			<source>tooltip_actionSetToArc</source>
			<translation>actionSetToArc</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_info_generic</source>
			<translation>Podstawowe informacje</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_generic</source>
			<translation>dlg_info_generic</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>info_workcat</name>
		<message>
			<source>title</source>
			<translation>Nowy workcat</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>builtdate</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_builtdate</source>
			<translation>builtdate</translation>
		</message>
		<message>
			<source>dlg_info_workcat</source>
			<translation>Nowy workcat</translation>
		</message>
		<message>
			<source>tooltip_dlg_info_workcat</source>
			<translation>dlg_info_workcat</translation>
		</message>
		<message>
			<source>lbl_builtdate</source>
			<translation>Data budowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_builtdate</source>
			<translation>lbl_builtdate</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Link:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>lbl_work_id</source>
			<translation>Identyfikator pracy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_id</source>
			<translation>lbl_work_id</translation>
		</message>
		<message>
			<source>lbl_workid_key_1</source>
			<translation>Klucz roboczy 1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workid_key_1</source>
			<translation>lbl_workid_key_1</translation>
		</message>
		<message>
			<source>lbl_workid_key_2</source>
			<translation>Klucz roboczy 2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workid_key_2</source>
			<translation>lbl_workid_key_2</translation>
		</message>
	</context>
	<context>
		<name>inp_config_import</name>
		<message>
			<source>title</source>
			<translation>Konfiguracja importu INP</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_load</source>
			<translation>Załaduj...</translation>
		</message>
		<message>
			<source>tooltip_btn_load</source>
			<translation>btn_load</translation>
		</message>
		<message>
			<source>btn_reload</source>
			<translation>Opcje przeładowania</translation>
		</message>
		<message>
			<source>tooltip_btn_reload</source>
			<translation>btn_reload</translation>
		</message>
		<message>
			<source>btn_save</source>
			<translation>Zapisz...</translation>
		</message>
		<message>
			<source>tooltip_btn_save</source>
			<translation>btn_save</translation>
		</message>
		<message>
			<source>chk_force_commit</source>
			<translation>Wymuś zatwierdzenie</translation>
		</message>
		<message>
			<source>tooltip_chk_force_commit</source>
			<translation>chk_force_commit</translation>
		</message>
		<message>
			<source>dlg_inp_config_import</source>
			<translation>Konfiguracja importu INP</translation>
		</message>
		<message>
			<source>tooltip_dlg_inp_config_import</source>
			<translation>dlg_inp_config_import</translation>
		</message>
		<message>
			<source>grb_basic</source>
			<translation>Podstawowy</translation>
		</message>
		<message>
			<source>tooltip_grb_basic</source>
			<translation>grb_basic</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>grb_mapzones</source>
			<translation>Mapy</translation>
		</message>
		<message>
			<source>tooltip_grb_mapzones</source>
			<translation>grb_mapzones</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Sektor:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Działanie:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Gmina:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Sektor:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>lbl_arcs</source>
			<translation>Wybierz odpowiedni arccat_id dla każdej kombinacji łuków z poniższych opcji. Jeśli wybierzesz &amp;quot;Utwórz nowy&amp;quot;, wprowadź nową nazwę w kolumnie &amp;quot;Nowa nazwa katalogu&amp;quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_arcs</source>
			<translation>lbl_arcs</translation>
		</message>
		<message>
			<source>lbl_dscenario</source>
			<translation>Żąda nazwy scenariusza:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dscenario</source>
			<translation>lbl_dscenario</translation>
		</message>
		<message>
			<source>lbl_feature</source>
			<translation>Wybierz odpowiedni feature_id dla każdego typu EPA z poniższych opcji. W razie potrzeby można dodać nowy typ elementu w katalogu Giswater i kliknąć przycisk &amp;quot;Przeładuj opcje&amp;quot; poniżej.</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature</source>
			<translation>lbl_feature</translation>
		</message>
		<message>
			<source>lbl_flwreg</source>
			<translation>Wybierz odpowiedni identyfikator katalogowy dla każdego regulatora przepływu z poniższych opcji. Jeśli wybierzesz &amp;quot;Utwórz nowy&amp;quot;, wprowadź nową nazwę w kolumnie &amp;quot;Nowa nazwa katalogu&amp;quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_flwreg</source>
			<translation>lbl_flwreg</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Wybierz odpowiedni materiał dla każdej chropowatości z poniższych opcji. W razie potrzeby można dodać nowy materiał w katalogu Giswater i kliknąć przycisk &amp;quot;Przeładuj opcje&amp;quot; poniżej.</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>lbl_material</translation>
		</message>
		<message>
			<source>lbl_nodes</source>
			<translation>Wybierz odpowiedni nodecat_id dla każdego typu EPA z poniższych opcji. Jeśli wybierzesz &amp;quot;Utwórz nowy&amp;quot;, wprowadź nową nazwę w kolumnie &amp;quot;Nowa nazwa katalogu&amp;quot;.</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodes</source>
			<translation>lbl_nodes</translation>
		</message>
		<message>
			<source>lbl_raingage</source>
			<translation>Domyślny raingage:</translation>
		</message>
		<message>
			<source>tooltip_lbl_raingage</source>
			<translation>lbl_raingage</translation>
		</message>
		<message>
			<source>lbl_workcat</source>
			<translation>Workcat_id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat</source>
			<translation>lbl_workcat</translation>
		</message>
		<message>
			<source>tab_arccat</source>
			<translation>Łuki</translation>
		</message>
		<message>
			<source>tooltip_tab_arccat</source>
			<translation>tab_arccat</translation>
		</message>
		<message>
			<source>tab_basic</source>
			<translation>Podstawowy</translation>
		</message>
		<message>
			<source>tooltip_tab_basic</source>
			<translation>tab_basic</translation>
		</message>
		<message>
			<source>tab_feature</source>
			<translation>Cechy</translation>
		</message>
		<message>
			<source>tooltip_tab_feature</source>
			<translation>tab_feature</translation>
		</message>
		<message>
			<source>tab_flwreg</source>
			<translation>Regulatory przepływu</translation>
		</message>
		<message>
			<source>tooltip_tab_flwreg</source>
			<translation>tab_flwreg</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_material</source>
			<translation>Materiał</translation>
		</message>
		<message>
			<source>tooltip_tab_material</source>
			<translation>tab_material</translation>
		</message>
		<message>
			<source>tab_nodecat</source>
			<translation>Węzły</translation>
		</message>
		<message>
			<source>tooltip_tab_nodecat</source>
			<translation>tab_nodecat</translation>
		</message>
		<message>
			<source>tbl_arcs</source>
			<translation>Nowa nazwa katalogu</translation>
		</message>
		<message>
			<source>tooltip_tbl_arcs</source>
			<translation>tbl_arcs</translation>
		</message>
		<message>
			<source>tbl_feature</source>
			<translation>Cecha</translation>
		</message>
		<message>
			<source>tooltip_tbl_feature</source>
			<translation>tbl_feature</translation>
		</message>
		<message>
			<source>tbl_flwreg</source>
			<translation>Nowa nazwa katalogu</translation>
		</message>
		<message>
			<source>tooltip_tbl_flwreg</source>
			<translation>tbl_flwreg</translation>
		</message>
		<message>
			<source>tbl_material</source>
			<translation>Materiał</translation>
		</message>
		<message>
			<source>tooltip_tbl_material</source>
			<translation>tbl_material</translation>
		</message>
		<message>
			<source>tbl_nodes</source>
			<translation>Nowa nazwa katalogu</translation>
		</message>
		<message>
			<source>tooltip_tbl_nodes</source>
			<translation>tbl_nodes</translation>
		</message>
	</context>
	<context>
		<name>inp_parsing</name>
		<message>
			<source>title</source>
			<translation>Parsowanie pliku INP</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>dlg_inp_parsing</source>
			<translation>Parsowanie pliku INP</translation>
		</message>
		<message>
			<source>tooltip_dlg_inp_parsing</source>
			<translation>dlg_inp_parsing</translation>
		</message>
		<message>
			<source>tab_databaselog</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_databaselog</source>
			<translation>tab_databaselog</translation>
		</message>
	</context>
	<context>
		<name>interpolate</name>
		<message>
			<source>title</source>
			<translation>Interpoluj</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_interpolate</source>
			<translation>Interpoluj</translation>
		</message>
		<message>
			<source>tooltip_dlg_interpolate</source>
			<translation>dlg_interpolate</translation>
		</message>
		<message>
			<source>rb_extrapolate</source>
			<translation>Ekstrapolacja</translation>
		</message>
		<message>
			<source>tooltip_rb_extrapolate</source>
			<translation>rb_extrapolate</translation>
		</message>
		<message>
			<source>rb_interpolate</source>
			<translation>Interpoluj</translation>
		</message>
		<message>
			<source>tooltip_rb_interpolate</source>
			<translation>rb_interpolate</translation>
		</message>
	</context>
	<context>
		<name>load_menu</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_load_menu</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_load_menu</source>
			<translation>dlg_load_menu</translation>
		</message>
	</context>
	<context>
		<name>lot_management</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie lotami</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń działkę</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń partię</translation>
		</message>
		<message>
			<source>btn_export</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>btn_lot_selector</source>
			<translation>Selektor partii</translation>
		</message>
		<message>
			<source>tooltip_btn_lot_selector</source>
			<translation>Selektor partii</translation>
		</message>
		<message>
			<source>btn_manage_load</source>
			<translation>Rejestracja odpadów</translation>
		</message>
		<message>
			<source>tooltip_btn_manage_load</source>
			<translation>Rejestracja odpadów</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Działka otwarta</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>Partia otwarta</translation>
		</message>
		<message>
			<source>btn_work_register</source>
			<translation>Dzienniki pracy</translation>
		</message>
		<message>
			<source>tooltip_btn_work_register</source>
			<translation>Dzienniki pracy</translation>
		</message>
		<message>
			<source>chk_assignacio</source>
			<translation>Pendent przypisuje prace do OT</translation>
		</message>
		<message>
			<source>tooltip_chk_assignacio</source>
			<translation>Pendent przypisuje prace do OT</translation>
		</message>
		<message>
			<source>chk_show_nulls</source>
			<translation>Pokaż wartości null</translation>
		</message>
		<message>
			<source>tooltip_chk_show_nulls</source>
			<translation>Pokaż puste wartości</translation>
		</message>
		<message>
			<source>dlg_lot_management</source>
			<translation>Zarządzanie lotami</translation>
		</message>
		<message>
			<source>tooltip_dlg_lot_management</source>
			<translation>dlg_lot_management</translation>
		</message>
		<message>
			<source>lbl_address</source>
			<translation>Adres:</translation>
		</message>
		<message>
			<source>tooltip_lbl_address</source>
			<translation>Adres:</translation>
		</message>
		<message>
			<source>lbl_column_filter</source>
			<translation>Filtruj kolumnę dat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter</source>
			<translation>Filtr kolumny danych:</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Imię i nazwisko:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_performance_type</source>
			<translation>Typ wydajności:</translation>
		</message>
		<message>
			<source>tooltip_lbl_performance_type</source>
			<translation>Typ wydajności:</translation>
		</message>
		<message>
			<source>lbl_serie</source>
			<translation>Seria:</translation>
		</message>
		<message>
			<source>tooltip_lbl_serie</source>
			<translation>Seria:</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Stan:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Stan:</translation>
		</message>
		<message>
			<source>lot_management</source>
			<translation>Zarządzanie lotami</translation>
		</message>
		<message>
			<source>tooltip_lot_management</source>
			<translation>lot_management</translation>
		</message>
	</context>
	<context>
		<name>lot_selector</name>
		<message>
			<source>btn_ok</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>lbl_performance_type</source>
			<translation>Typ wydajności:</translation>
		</message>
		<message>
			<source>tooltip_lbl_performance_type</source>
			<translation>Typ wydajności:</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Stan:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>Stan:</translation>
		</message>
	</context>
	<context>
		<name>main_dbproject</name>
		<message>
			<source>title</source>
			<translation>Utwórz projekt</translation>
		</message>
		<message>
			<source>dlg_main_dbproject</source>
			<translation>Główny projekt db:</translation>
		</message>
		<message>
			<source>tooltip_dlg_main_dbproject</source>
			<translation>dlg_main_dbproject</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
	</context>
	<context>
		<name>mapzone_config</name>
		<message>
			<source>title</source>
			<translation>Konfiguracja Mapzone</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_forceClosed</source>
			<translation>ADD</translation>
		</message>
		<message>
			<source>tooltip_btn_add_forceClosed</source>
			<translation>btn_add_forceClosed</translation>
		</message>
		<message>
			<source>btn_add_ignore</source>
			<translation>ADD</translation>
		</message>
		<message>
			<source>tooltip_btn_add_ignore</source>
			<translation>btn_add_ignore</translation>
		</message>
		<message>
			<source>btn_add_nodeParent</source>
			<translation>ADD</translation>
		</message>
		<message>
			<source>tooltip_btn_add_nodeParent</source>
			<translation>btn_add_nodeParent</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_clear_preview</source>
			<translation>Przejrzysty podgląd</translation>
		</message>
		<message>
			<source>tooltip_btn_clear_preview</source>
			<translation>btn_clear_preview</translation>
		</message>
		<message>
			<source>btn_remove_forceClosed</source>
			<translation>USUŃ</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_forceClosed</source>
			<translation>btn_remove_forceClosed</translation>
		</message>
		<message>
			<source>btn_remove_ignore</source>
			<translation>USUŃ</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_ignore</source>
			<translation>btn_remove_ignore</translation>
		</message>
		<message>
			<source>btn_remove_nodeParent</source>
			<translation>USUŃ</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_nodeParent</source>
			<translation>btn_remove_nodeParent</translation>
		</message>
		<message>
			<source>dlg_mapzone_config</source>
			<translation>Konfiguracja Mapzone</translation>
		</message>
		<message>
			<source>tooltip_dlg_mapzone_config</source>
			<translation>dlg_mapzone_config</translation>
		</message>
		<message>
			<source>lbl_forceClosed</source>
			<translation>forceClosed:</translation>
		</message>
		<message>
			<source>tooltip_lbl_forceClosed</source>
			<translation>lbl_forceClosed</translation>
		</message>
		<message>
			<source>lbl_ignore</source>
			<translation>ignorować</translation>
		</message>
		<message>
			<source>tooltip_lbl_ignore</source>
			<translation>lbl_ignore</translation>
		</message>
		<message>
			<source>lbl_nodeParent</source>
			<translation>nodeParent:</translation>
		</message>
		<message>
			<source>tooltip_lbl_nodeParent</source>
			<translation>lbl_nodeParent</translation>
		</message>
		<message>
			<source>lbl_preview</source>
			<translation>Podgląd:</translation>
		</message>
		<message>
			<source>tooltip_lbl_preview</source>
			<translation>lbl_preview</translation>
		</message>
		<message>
			<source>lbl_toArc</source>
			<translation>toArc:</translation>
		</message>
		<message>
			<source>tooltip_lbl_toArc</source>
			<translation>lbl_toArc</translation>
		</message>
	</context>
	<context>
		<name>mapzone_manager</name>
		<message>
			<source>title</source>
			<translation>Menedżer Mapzones</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>btn_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_btn_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_execute</source>
			<translation>btn_execute</translation>
		</message>
		<message>
			<source>tooltip_btn_execute</source>
			<translation>Wykonanie procesu analizy strefy mapowania</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Pokaż nieaktywne</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Pokaż nieaktywne</translation>
		</message>
		<message>
			<source>chk_show_all</source>
			<translation>Pokaż wszystkie strefy map</translation>
		</message>
		<message>
			<source>tooltip_chk_show_all</source>
			<translation>Pokaż wszystkie strefy map</translation>
		</message>
		<message>
			<source>dlg_mapzone_manager</source>
			<translation>Menedżer Mapzones</translation>
		</message>
		<message>
			<source>tooltip_dlg_mapzone_manager</source>
			<translation>dlg_mapzone_manager</translation>
		</message>
		<message>
			<source>lbl_mapzone_name</source>
			<translation>Filtruj według: Nazwa strefy</translation>
		</message>
		<message>
			<source>tooltip_lbl_mapzone_name</source>
			<translation>Filtruj według: Nazwa strefy</translation>
		</message>
	</context>
	<context>
		<name>massive_composer</name>
		<message>
			<source>title</source>
			<translation>Automatyczne drukowanie stron kompozytora</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>dlg_massive_composer</source>
			<translation>Automatyczne drukowanie stron kompozytora</translation>
		</message>
		<message>
			<source>tooltip_dlg_massive_composer</source>
			<translation>dlg_massive_composer</translation>
		</message>
		<message>
			<source>grb_comp</source>
			<translation>Lista kompozytorów</translation>
		</message>
		<message>
			<source>tooltip_grb_comp</source>
			<translation>grb_comp</translation>
		</message>
		<message>
			<source>lbl_composers</source>
			<translation>Wybierz kompozytora:</translation>
		</message>
		<message>
			<source>tooltip_lbl_composers</source>
			<translation>lbl_composers</translation>
		</message>
		<message>
			<source>lbl_folder</source>
			<translation>Wybierz folder:</translation>
		</message>
		<message>
			<source>tooltip_lbl_folder</source>
			<translation>lbl_folder</translation>
		</message>
		<message>
			<source>lbl_prefix</source>
			<translation>Plik prefiksu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prefix</source>
			<translation>lbl_prefix</translation>
		</message>
		<message>
			<source>lbl_single</source>
			<translation>Pojedynczy plik:</translation>
		</message>
		<message>
			<source>tooltip_lbl_single</source>
			<translation>lbl_single</translation>
		</message>
		<message>
			<source>lbl_sleep</source>
			<translation>Czas snu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_sleep</source>
			<translation>lbl_sleep</translation>
		</message>
	</context>
	<context>
		<name>mincut</name>
		<message>
			<source>title</source>
			<translation>Mincut</translation>
		</message>
		<message>
			<source>actionAddConnec</source>
			<translation>Connec Mincut</translation>
		</message>
		<message>
			<source>tooltip_actionAddConnec</source>
			<translation>actionAddConnec</translation>
		</message>
		<message>
			<source>actionAddHydrometer</source>
			<translation>Hydrometr Mincut</translation>
		</message>
		<message>
			<source>tooltip_actionAddHydrometer</source>
			<translation>actionAddHydrometer</translation>
		</message>
		<message>
			<source>actionChangeValveStatus</source>
			<translation>Zmiana stanu zaworu</translation>
		</message>
		<message>
			<source>tooltip_actionChangeValveStatus</source>
			<translation>actionChangeValveStatus</translation>
		</message>
		<message>
			<source>actionComposer</source>
			<translation>Kompozytor</translation>
		</message>
		<message>
			<source>tooltip_actionComposer</source>
			<translation>actionComposer</translation>
		</message>
		<message>
			<source>actionCustomMincut</source>
			<translation>Custom Mincut</translation>
		</message>
		<message>
			<source>tooltip_actionCustomMincut</source>
			<translation>actionCustomMincut</translation>
		</message>
		<message>
			<source>actionExportHydroCsv</source>
			<translation>Eksport Hydro Csv</translation>
		</message>
		<message>
			<source>tooltip_actionExportHydroCsv</source>
			<translation>actionExportHydroCsv</translation>
		</message>
		<message>
			<source>actionMincut</source>
			<translation>Automatyczny Mincut</translation>
		</message>
		<message>
			<source>tooltip_actionMincut</source>
			<translation>actionMincut</translation>
		</message>
		<message>
			<source>actionRefreshMincut</source>
			<translation>Odśwież Mincut</translation>
		</message>
		<message>
			<source>tooltip_actionRefreshMincut</source>
			<translation>actionRefreshMincut</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>btn_cancel_task</source>
			<translation>Anuluj zadanie</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_task</source>
			<translation>btn_cancel_task</translation>
		</message>
		<message>
			<source>btn_end</source>
			<translation>Koniec</translation>
		</message>
		<message>
			<source>tooltip_btn_end</source>
			<translation>btn_end</translation>
		</message>
		<message>
			<source>btn_start</source>
			<translation>Start</translation>
		</message>
		<message>
			<source>tooltip_btn_start</source>
			<translation>btn_start</translation>
		</message>
		<message>
			<source>cbx_date_end</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end</source>
			<translation>cbx_date_end</translation>
		</message>
		<message>
			<source>cbx_date_end_predict</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end_predict</source>
			<translation>cbx_date_end_predict</translation>
		</message>
		<message>
			<source>cbx_date_start</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start</source>
			<translation>cbx_date_start</translation>
		</message>
		<message>
			<source>cbx_date_start_predict</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start_predict</source>
			<translation>cbx_date_start_predict</translation>
		</message>
		<message>
			<source>cbx_recieved_day</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_cbx_recieved_day</source>
			<translation>cbx_recieved_day</translation>
		</message>
		<message>
			<source>chk_use_planified</source>
			<translation>Korzystanie z sieci planowanej</translation>
		</message>
		<message>
			<source>tooltip_chk_use_planified</source>
			<translation>chk_use_planified</translation>
		</message>
		<message>
			<source>dlg_mincut</source>
			<translation>Mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut</source>
			<translation>dlg_mincut</translation>
		</message>
		<message>
			<source>grb_exec_realdates</source>
			<translation>Prawdziwe daty</translation>
		</message>
		<message>
			<source>tooltip_grb_exec_realdates</source>
			<translation>grb_exec_realdates</translation>
		</message>
		<message>
			<source>grb_location</source>
			<translation>Lokalizacja</translation>
		</message>
		<message>
			<source>tooltip_grb_location</source>
			<translation>grb_location</translation>
		</message>
		<message>
			<source>grb_plan_details</source>
			<translation>Szczegóły</translation>
		</message>
		<message>
			<source>tooltip_grb_plan_details</source>
			<translation>grb_plan_details</translation>
		</message>
		<message>
			<source>grb_plan_forecasted_dates</source>
			<translation>Przewidywane daty</translation>
		</message>
		<message>
			<source>tooltip_grb_plan_forecasted_dates</source>
			<translation>grb_plan_forecasted_dates</translation>
		</message>
		<message>
			<source>lbl_assigned_to</source>
			<translation>Przypisany do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_assigned_to</source>
			<translation>lbl_assigned_to</translation>
		</message>
		<message>
			<source>lbl_cause</source>
			<translation>Przyczyna:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cause</source>
			<translation>lbl_cause</translation>
		</message>
		<message>
			<source>lbl_chlorine</source>
			<translation>Chlor:</translation>
		</message>
		<message>
			<source>tooltip_lbl_chlorine</source>
			<translation>lbl_chlorine</translation>
		</message>
		<message>
			<source>lbl_depth</source>
			<translation>Głębokość:</translation>
		</message>
		<message>
			<source>tooltip_lbl_depth</source>
			<translation>lbl_depth</translation>
		</message>
		<message>
			<source>lbl_descript_pd</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_pd</source>
			<translation>lbl_descript_pd</translation>
		</message>
		<message>
			<source>lbl_descript_rd</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_rd</source>
			<translation>lbl_descript_rd</translation>
		</message>
		<message>
			<source>lbl_dist_from_plot</source>
			<translation>Odległość od działki:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dist_from_plot</source>
			<translation>lbl_dist_from_plot</translation>
		</message>
		<message>
			<source>lbl_end</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end</source>
			<translation>lbl_end</translation>
		</message>
		<message>
			<source>lbl_equipment_code</source>
			<translation>Chlorine measurement equipment:</translation>
		</message>
		<message>
			<source>tooltip_lbl_equipment_code</source>
			<translation>lbl_equipment_code</translation>
		</message>
		<message>
			<source>lbl_exec_appropriate</source>
			<translation>Odpowiednie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_appropriate</source>
			<translation>Jeśli to prawda, rzeczywista lokalizacja jest zgodna z zaplanowanymi informacjami mincut</translation>
		</message>
		<message>
			<source>lbl_exec_enddate</source>
			<translation>Data zakończenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_enddate</source>
			<translation>lbl_exec_enddate</translation>
		</message>
		<message>
			<source>lbl_exec_startdate</source>
			<translation>Data rozpoczęcia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_startdate</source>
			<translation>Odwiedź ID</translation>
		</message>
		<message>
			<source>lbl_exec_user</source>
			<translation>Użytkownik wykonawczy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exec_user</source>
			<translation>lbl_exec_user</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_msg</source>
			<translation>Nie znaleziono wyników</translation>
		</message>
		<message>
			<source>tooltip_lbl_msg</source>
			<translation>lbl_msg</translation>
		</message>
		<message>
			<source>lbl_reagent_lot</source>
			<translation>Chlorine reagent lot:</translation>
		</message>
		<message>
			<source>tooltip_lbl_reagent_lot</source>
			<translation>lbl_reagent_lot</translation>
		</message>
		<message>
			<source>lbl_received_date</source>
			<translation>Data otrzymania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_received_date</source>
			<translation>lbl_received_date</translation>
		</message>
		<message>
			<source>lbl_start</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start</source>
			<translation>lbl_start</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Stan:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
		<message>
			<source>lbl_turbidity</source>
			<translation>Zmętnienie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_turbidity</source>
			<translation>lbl_turbidity</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Typ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
		<message>
			<source>lbl_work_order</source>
			<translation>Zlecenie pracy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_order</source>
			<translation>lbl_work_order</translation>
		</message>
		<message>
			<source>tab</source>
			<translation>Wykonanie</translation>
		</message>
		<message>
			<source>tooltip_tab</source>
			<translation>tab</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Plan</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_hydro</source>
			<translation>Hydro</translation>
		</message>
		<message>
			<source>tooltip_tab_hydro</source>
			<translation>tab_hydro</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Dziennik</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
	</context>
	<context>
		<name>mincut_composer</name>
		<message>
			<source>title</source>
			<translation>Kompozytor Mincut</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Otwarty</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_mincut_composer</source>
			<translation>Kompozytor Mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_composer</source>
			<translation>dlg_mincut_composer</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Kompozytor Mincut</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_rotation</source>
			<translation>Rotacja:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rotation</source>
			<translation>lbl_rotation</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Szablon:</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Tytuł:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
	</context>
	<context>
		<name>mincut_connec</name>
		<message>
			<source>title</source>
			<translation>Połączenie Mincut</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_insert</source>
			<translation>btn_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_insert</source>
			<translation>Wstawka</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>btn_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Snapping</translation>
		</message>
		<message>
			<source>dlg_mincut_connec</source>
			<translation>Połączenie Mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_connec</source>
			<translation>dlg_mincut_connec</translation>
		</message>
		<message>
			<source>lbl_search</source>
			<translation>Wyszukiwanie według kodu klienta:</translation>
		</message>
		<message>
			<source>tooltip_lbl_search</source>
			<translation>lbl_search</translation>
		</message>
	</context>
	<context>
		<name>mincut_end</name>
		<message>
			<source>title</source>
			<translation>Mincut end</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_set_real_location</source>
			<translation>Ustaw rzeczywistą lokalizację</translation>
		</message>
		<message>
			<source>tooltip_btn_set_real_location</source>
			<translation>btn_set_real_location</translation>
		</message>
		<message>
			<source>cbx_date_end_fin</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_end_fin</source>
			<translation>cbx_date_end_fin</translation>
		</message>
		<message>
			<source>cbx_date_start_fin</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_cbx_date_start_fin</source>
			<translation>cbx_date_start_fin</translation>
		</message>
		<message>
			<source>cbx_hours_start_fin</source>
			<translation>H:mm:ss</translation>
		</message>
		<message>
			<source>tooltip_cbx_hours_start_fin</source>
			<translation>cbx_hours_start_fin</translation>
		</message>
		<message>
			<source>dlg_mincut_end</source>
			<translation>Mincut end</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_end</source>
			<translation>dlg_mincut_end</translation>
		</message>
		<message>
			<source>grb_close_mincut</source>
			<translation>Zamknij mincut</translation>
		</message>
		<message>
			<source>tooltip_grb_close_mincut</source>
			<translation>grb_close_mincut</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Daty</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>lbl_end_date</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_date</source>
			<translation>lbl_end_date</translation>
		</message>
		<message>
			<source>lbl_end_hour</source>
			<translation>Godzina zakończenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_hour</source>
			<translation>lbl_end_hour</translation>
		</message>
		<message>
			<source>lbl_executed</source>
			<translation>Wykonane przez:</translation>
		</message>
		<message>
			<source>tooltip_lbl_executed</source>
			<translation>lbl_executed</translation>
		</message>
		<message>
			<source>lbl_mincut</source>
			<translation>Mincut:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mincut</source>
			<translation>lbl_mincut</translation>
		</message>
		<message>
			<source>lbl_msg</source>
			<translation>Nie znaleziono wyników</translation>
		</message>
		<message>
			<source>tooltip_lbl_msg</source>
			<translation>lbl_msg</translation>
		</message>
		<message>
			<source>lbl_municipality</source>
			<translation>Gmina:</translation>
		</message>
		<message>
			<source>tooltip_lbl_municipality</source>
			<translation>lbl_municipality</translation>
		</message>
		<message>
			<source>lbl_number</source>
			<translation>Numer:</translation>
		</message>
		<message>
			<source>tooltip_lbl_number</source>
			<translation>lbl_number</translation>
		</message>
		<message>
			<source>lbl_start_date</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_date</source>
			<translation>lbl_start_date</translation>
		</message>
		<message>
			<source>lbl_start_hour</source>
			<translation>Godzina rozpoczęcia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_hour</source>
			<translation>lbl_start_hour</translation>
		</message>
		<message>
			<source>lbl_street</source>
			<translation>Ulica:</translation>
		</message>
		<message>
			<source>tooltip_lbl_street</source>
			<translation>lbl_street</translation>
		</message>
		<message>
			<source>lbl_work_order</source>
			<translation>Zlecenie pracy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_work_order</source>
			<translation>lbl_work_order</translation>
		</message>
	</context>
	<context>
		<name>mincut_hydrometer</name>
		<message>
			<source>title</source>
			<translation>Hydrometr Mincut</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_insert</source>
			<translation>btn_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_insert</source>
			<translation>Wstawka</translation>
		</message>
		<message>
			<source>dlg_mincut_hydrometer</source>
			<translation>Hydrometr Mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_hydrometer</source>
			<translation>dlg_mincut_hydrometer</translation>
		</message>
		<message>
			<source>lbl_ccc</source>
			<translation>Kod klienta Connec:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ccc</source>
			<translation>lbl_ccc</translation>
		</message>
		<message>
			<source>lbl_hcc</source>
			<translation>Kod klienta hydrometru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_hcc</source>
			<translation>lbl_hcc</translation>
		</message>
	</context>
	<context>
		<name>mincut_manager</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie Mincut</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_cancel_mincut</source>
			<translation>Anuluj mincut</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel_mincut</source>
			<translation>btn_cancel_mincut</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_next_days</source>
			<translation>Następne dni</translation>
		</message>
		<message>
			<source>tooltip_btn_next_days</source>
			<translation>btn_next_days</translation>
		</message>
		<message>
			<source>btn_notify</source>
			<translation>Wyślij sms</translation>
		</message>
		<message>
			<source>tooltip_btn_notify</source>
			<translation>btn_notify</translation>
		</message>
		<message>
			<source>btn_selector_mincut</source>
			<translation>btn_selector_mincut</translation>
		</message>
		<message>
			<source>tooltip_btn_selector_mincut</source>
			<translation>btn_selector_mincut</translation>
		</message>
		<message>
			<source>dlg_mincut_manager</source>
			<translation>Zarządzanie Mincut</translation>
		</message>
		<message>
			<source>tooltip_dlg_mincut_manager</source>
			<translation>dlg_mincut_manager</translation>
		</message>
		<message>
			<source>lbl_date_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_from</source>
			<translation>lbl_date_from</translation>
		</message>
		<message>
			<source>lbl_date_to</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_to</source>
			<translation>lbl_date_to</translation>
		</message>
		<message>
			<source>lbl_exploitation</source>
			<translation>Działanie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exploitation</source>
			<translation>lbl_exploitation</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtruj według:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_mincut_type</source>
			<translation>Typ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mincut_type</source>
			<translation>lbl_mincut_type</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Stan:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
		<message>
			<source>lbl_streetaxis</source>
			<translation>Streetaxis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_streetaxis</source>
			<translation>lbl_streetaxis</translation>
		</message>
	</context>
	<context>
		<name>netscenario</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_btn_config</source>
			<translation>btn_config</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>btn_toggle_closed</source>
			<translation>Przełączanie zamknięte</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_closed</source>
			<translation>btn_toggle_closed</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>dlg_netscenario</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_netscenario</source>
			<translation>dlg_netscenario</translation>
		</message>
		<message>
			<source>lbl_mapzone_id</source>
			<translation>Mapzone id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_mapzone_id</source>
			<translation>lbl_mapzone_id</translation>
		</message>
	</context>
	<context>
		<name>netscenario_manager</name>
		<message>
			<source>title</source>
			<translation>Menedżer scenariusza sieciowego</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>     Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplikat</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>Duplikat</translation>
		</message>
		<message>
			<source>btn_execute</source>
			<translation>btn_execute</translation>
		</message>
		<message>
			<source>tooltip_btn_execute</source>
			<translation>Przeprowadzenie analizy mapzones</translation>
		</message>
		<message>
			<source>btn_toc</source>
			<translation>btn_toc</translation>
		</message>
		<message>
			<source>tooltip_btn_toc</source>
			<translation>Załaduj warstwę Giswater</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>btn_update_netscenario</source>
			<translation>Bieżący scenariusz sieciowy</translation>
		</message>
		<message>
			<source>tooltip_btn_update_netscenario</source>
			<translation>Bieżący scenariusz sieciowy</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Pokaż nieaktywne</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Pokaż nieaktywne</translation>
		</message>
		<message>
			<source>dlg_netscenario_manager</source>
			<translation>Menedżer scenariusza sieciowego</translation>
		</message>
		<message>
			<source>tooltip_dlg_netscenario_manager</source>
			<translation>dlg_netscenario_manager</translation>
		</message>
		<message>
			<source>lbl_netscenario_name</source>
			<translation>Filtruj według: Nazwa scenariusza sieciowego</translation>
		</message>
		<message>
			<source>tooltip_lbl_netscenario_name</source>
			<translation>Filtruj według: Nazwa scenariusza sieciowego</translation>
		</message>
	</context>
	<context>
		<name>nodetype_change</name>
		<message>
			<source>title</source>
			<translation>Zmiana typu węzła</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nodetype_change</source>
			<translation>Zmiana typu węzła</translation>
		</message>
		<message>
			<source>tooltip_dlg_nodetype_change</source>
			<translation>dlg_nodetype_change</translation>
		</message>
		<message>
			<source>lbl_catalog_id</source>
			<translation>Identyfikator katalogowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_catalog_id</source>
			<translation>lbl_catalog_id</translation>
		</message>
		<message>
			<source>lbl_custom_node_type</source>
			<translation>Nowy typ węzła:</translation>
		</message>
		<message>
			<source>tooltip_lbl_custom_node_type</source>
			<translation>lbl_custom_node_type</translation>
		</message>
		<message>
			<source>lbl_node_type</source>
			<translation>Bieżący typ węzła:</translation>
		</message>
		<message>
			<source>tooltip_lbl_node_type</source>
			<translation>lbl_node_type</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_controls</name>
		<message>
			<source>title</source>
			<translation>Prosty edytor elementów sterujących</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Aktywny</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_controls</source>
			<translation>Prosty edytor elementów sterujących</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_controls</source>
			<translation>dlg_nonvisual_controls</translation>
		</message>
		<message>
			<source>lbl_sector_id</source>
			<translation>Identyfikator sektora</translation>
		</message>
		<message>
			<source>tooltip_lbl_sector_id</source>
			<translation>lbl_sector_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_curve</name>
		<message>
			<source>title</source>
			<translation>Edytor krzywych</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_curve</source>
			<translation>Edytor krzywych</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_curve</source>
			<translation>dlg_nonvisual_curve</translation>
		</message>
		<message>
			<source>lbl_curve_id</source>
			<translation>Identyfikator krzywej</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_id</source>
			<translation>lbl_curve_id</translation>
		</message>
		<message>
			<source>lbl_curve_type</source>
			<translation>Typ krzywej</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_type</source>
			<translation>lbl_curve_type</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>Identyfikator operacji</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>tbl_curve_value</source>
			<translation>Y</translation>
		</message>
		<message>
			<source>tooltip_tbl_curve_value</source>
			<translation>tbl_curve_value</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_lids</name>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_help</source>
			<translation>Pomoc</translation>
		</message>
		<message>
			<source>tooltip_btn_help</source>
			<translation>btn_help</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>Dialog</source>
			<translation>LIDS</translation>
		</message>
		<message>
			<source>tooltip_Dialog</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>drain</source>
			<translation>Odpływ</translation>
		</message>
		<message>
			<source>tooltip_drain</source>
			<translation>drain</translation>
		</message>
		<message>
			<source>drainmat</source>
			<translation>Drenaż maty</translation>
		</message>
		<message>
			<source>tooltip_drainmat</source>
			<translation>drainmat</translation>
		</message>
		<message>
			<source>label_source_img</source>
			<translation>Źródło: SWMM 5.1</translation>
		</message>
		<message>
			<source>tooltip_label_source_img</source>
			<translation>label_source_img</translation>
		</message>
		<message>
			<source>lbl_berm_height</source>
			<translation>Wysokość nasypu (w calach lub mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_berm_height</source>
			<translation>lbl_berm_height</translation>
		</message>
		<message>
			<source>lbl_clogging_factor_pavement</source>
			<translation>Czynnik zatykający</translation>
		</message>
		<message>
			<source>tooltip_lbl_clogging_factor_pavement</source>
			<translation>lbl_clogging_factor_pavement</translation>
		</message>
		<message>
			<source>lbl_clogging_factor_storage</source>
			<translation>Czynnik zatykający</translation>
		</message>
		<message>
			<source>tooltip_lbl_clogging_factor_storage</source>
			<translation>lbl_clogging_factor_storage</translation>
		</message>
		<message>
			<source>lbl_closed_level</source>
			<translation>Poziom zamknięcia (w calach lub mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_closed_level</source>
			<translation>lbl_closed_level</translation>
		</message>
		<message>
			<source>lbl_conducticity_slope</source>
			<translation>Przewodność Nachylenie</translation>
		</message>
		<message>
			<source>tooltip_lbl_conducticity_slope</source>
			<translation>lbl_conducticity_slope</translation>
		</message>
		<message>
			<source>lbl_conductivity</source>
			<translation>Przewodność (cal/godz. lub mm/godz.)</translation>
		</message>
		<message>
			<source>tooltip_lbl_conductivity</source>
			<translation>lbl_conductivity</translation>
		</message>
		<message>
			<source>lbl_control_curve</source>
			<translation>Krzywa kontrolna</translation>
		</message>
		<message>
			<source>tooltip_lbl_control_curve</source>
			<translation>lbl_control_curve</translation>
		</message>
		<message>
			<source>lbl_control_name</source>
			<translation>Nazwa kontroli:</translation>
		</message>
		<message>
			<source>tooltip_lbl_control_name</source>
			<translation>lbl_control_name</translation>
		</message>
		<message>
			<source>lbl_drain_delay</source>
			<translation>Opóźnienie spustu (godz.)</translation>
		</message>
		<message>
			<source>tooltip_lbl_drain_delay</source>
			<translation>lbl_drain_delay</translation>
		</message>
		<message>
			<source>lbl_field_capacity</source>
			<translation>Pojemność pola (ułamek objętości)</translation>
		</message>
		<message>
			<source>tooltip_lbl_field_capacity</source>
			<translation>lbl_field_capacity</translation>
		</message>
		<message>
			<source>lbl_flow_capacity</source>
			<translation>Przepustowość (cal/godz. lub mm/godz.)</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_capacity</source>
			<translation>lbl_flow_capacity</translation>
		</message>
		<message>
			<source>lbl__flow_coefficient</source>
			<translation>Współczynnik przepływu*</translation>
		</message>
		<message>
			<source>tooltip_lbl__flow_coefficient</source>
			<translation>lbl__flow_coefficient</translation>
		</message>
		<message>
			<source>lbl_flow_description</source>
			<translation>*Przepływ w calach na godzinę lub mm na godzinę; użyj 0, jeśli nie ma odpływu.</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_description</source>
			<translation>lbl_flow_description</translation>
		</message>
		<message>
			<source>lbl_flow_exponent</source>
			<translation>Wykładnik przepływu</translation>
		</message>
		<message>
			<source>tooltip_lbl_flow_exponent</source>
			<translation>lbl_flow_exponent</translation>
		</message>
		<message>
			<source>lbl_imprevious_surface</source>
			<translation>Ułamek powierzchni nieprzepuszczalnej</translation>
		</message>
		<message>
			<source>tooltip_lbl_imprevious_surface</source>
			<translation>lbl_imprevious_surface</translation>
		</message>
		<message>
			<source>lbl_lid_type</source>
			<translation>Typ LID:</translation>
		</message>
		<message>
			<source>tooltip_lbl_lid_type</source>
			<translation>lbl_lid_type</translation>
		</message>
		<message>
			<source>lbl_offset</source>
			<translation>Przesunięcie (in lub mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_offset</source>
			<translation>lbl_offset</translation>
		</message>
		<message>
			<source>lbl_open_level</source>
			<translation>Poziom otwarcia (w calach lub mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_open_level</source>
			<translation>lbl_open_level</translation>
		</message>
		<message>
			<source>lbl__permeability</source>
			<translation>Przepuszczalność (cal/godz. lub mm/godz.)</translation>
		</message>
		<message>
			<source>tooltip_lbl__permeability</source>
			<translation>lbl__permeability</translation>
		</message>
		<message>
			<source>lbl_porosity</source>
			<translation>Porowatość (ułamek objętościowy)</translation>
		</message>
		<message>
			<source>tooltip_lbl_porosity</source>
			<translation>lbl_porosity</translation>
		</message>
		<message>
			<source>lbl_regeneration_fraction</source>
			<translation>Frakcja regeneracji</translation>
		</message>
		<message>
			<source>tooltip_lbl_regeneration_fraction</source>
			<translation>lbl_regeneration_fraction</translation>
		</message>
		<message>
			<source>lbl_regeneration_interval</source>
			<translation>Interwał regeneracji (dni)</translation>
		</message>
		<message>
			<source>tooltip_lbl_regeneration_interval</source>
			<translation>lbl_regeneration_interval</translation>
		</message>
		<message>
			<source>lbl_roughness</source>
			<translation>Chropowatość (Mannings n)</translation>
		</message>
		<message>
			<source>tooltip_lbl_roughness</source>
			<translation>lbl_roughness</translation>
		</message>
		<message>
			<source>lbl_seepage_rate</source>
			<translation>Szybkość przesączania (cal/godz. lub mm/godz.)</translation>
		</message>
		<message>
			<source>tooltip_lbl_seepage_rate</source>
			<translation>lbl_seepage_rate</translation>
		</message>
		<message>
			<source>lbl_suction_head</source>
			<translation>Wysokość ssania (cale lub mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_suction_head</source>
			<translation>lbl_suction_head</translation>
		</message>
		<message>
			<source>lbl_surface_roughness</source>
			<translation>Chropowatość powierzchni (Mannings n)</translation>
		</message>
		<message>
			<source>tooltip_lbl_surface_roughness</source>
			<translation>lbl_surface_roughness</translation>
		</message>
		<message>
			<source>lbl_surface_slope</source>
			<translation>Nachylenie powierzchni (w procentach)</translation>
		</message>
		<message>
			<source>tooltip_lbl_surface_slope</source>
			<translation>lbl_surface_slope</translation>
		</message>
		<message>
			<source>lbl_swale_side_slope</source>
			<translation>Nachylenie boczne kanału (spadek/wzniesienie)</translation>
		</message>
		<message>
			<source>tooltip_lbl_swale_side_slope</source>
			<translation>lbl_swale_side_slope</translation>
		</message>
		<message>
			<source>lbl_thickness</source>
			<translation>Grubość (w calach lub mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness</source>
			<translation>lbl_thickness</translation>
		</message>
		<message>
			<source>lbl_thickness_drainage</source>
			<translation>Grubość (w calach lub mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness_drainage</source>
			<translation>lbl_thickness_drainage</translation>
		</message>
		<message>
			<source>lbl_thickness_storage</source>
			<translation>Grubość (w calach lub mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thickness_storage</source>
			<translation>lbl_thickness_storage</translation>
		</message>
		<message>
			<source>lbl_thinkness_pavement</source>
			<translation>Grubość (w calach lub mm)</translation>
		</message>
		<message>
			<source>tooltip_lbl_thinkness_pavement</source>
			<translation>lbl_thinkness_pavement</translation>
		</message>
		<message>
			<source>lbl_vegetation_volume</source>
			<translation>Ułamek objętości roślinności</translation>
		</message>
		<message>
			<source>tooltip_lbl_vegetation_volume</source>
			<translation>lbl_vegetation_volume</translation>
		</message>
		<message>
			<source>lbl_void_fraction</source>
			<translation>Ułamek pustki</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_fraction</source>
			<translation>lbl_void_fraction</translation>
		</message>
		<message>
			<source>lbl_void_ratio_pavement</source>
			<translation>Współczynnik pustki (pustka/ciała stałe)</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_ratio_pavement</source>
			<translation>lbl_void_ratio_pavement</translation>
		</message>
		<message>
			<source>lbl_void_ratio_storage</source>
			<translation>Współczynnik pustych przestrzeni (puste przestrzenie/ciała stałe)</translation>
		</message>
		<message>
			<source>tooltip_lbl_void_ratio_storage</source>
			<translation>lbl_void_ratio_storage</translation>
		</message>
		<message>
			<source>lbl_wilting_point</source>
			<translation>Temperatura więdnięcia (ułamek objętościowy)</translation>
		</message>
		<message>
			<source>tooltip_lbl_wilting_point</source>
			<translation>lbl_wilting_point</translation>
		</message>
		<message>
			<source>pavement</source>
			<translation>Chodnik</translation>
		</message>
		<message>
			<source>tooltip_pavement</source>
			<translation>pavement</translation>
		</message>
		<message>
			<source>rooftop</source>
			<translation>Odpływ dachowy</translation>
		</message>
		<message>
			<source>tooltip_rooftop</source>
			<translation>rooftop</translation>
		</message>
		<message>
			<source>soil</source>
			<translation>Gleba</translation>
		</message>
		<message>
			<source>tooltip_soil</source>
			<translation>soil</translation>
		</message>
		<message>
			<source>storage</source>
			<translation>Przechowywanie</translation>
		</message>
		<message>
			<source>tooltip_storage</source>
			<translation>storage</translation>
		</message>
		<message>
			<source>surface</source>
			<translation>Powierzchnia</translation>
		</message>
		<message>
			<source>tooltip_surface</source>
			<translation>surface</translation>
		</message>
		<message>
			<source>txt_1_berm_height</source>
			<translation>0.0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_berm_height</source>
			<translation>txt_1_berm_height</translation>
		</message>
		<message>
			<source>txt_1_flow_coefficient</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_flow_coefficient</source>
			<translation>txt_1_flow_coefficient</translation>
		</message>
		<message>
			<source>txt_1_thickness</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness</source>
			<translation>txt_1_thickness</translation>
		</message>
		<message>
			<source>txt_1_thickness_drainage</source>
			<translation>3</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_drainage</source>
			<translation>txt_1_thickness_drainage</translation>
		</message>
		<message>
			<source>txt_1_thickness_pavement</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_pavement</source>
			<translation>txt_1_thickness_pavement</translation>
		</message>
		<message>
			<source>txt_1_thickness_storage</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_1_thickness_storage</source>
			<translation>txt_1_thickness_storage</translation>
		</message>
		<message>
			<source>txt_2_flow_exponent</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_flow_exponent</source>
			<translation>txt_2_flow_exponent</translation>
		</message>
		<message>
			<source>txt_2_porosity</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_porosity</source>
			<translation>txt_2_porosity</translation>
		</message>
		<message>
			<source>txt_2_vegetation_volume</source>
			<translation>0.0</translation>
		</message>
		<message>
			<source>tooltip_txt_2_vegetation_volume</source>
			<translation>txt_2_vegetation_volume</translation>
		</message>
		<message>
			<source>txt_2_void_fraction</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_fraction</source>
			<translation>txt_2_void_fraction</translation>
		</message>
		<message>
			<source>txt_2_void_ratio_pavement</source>
			<translation>0.15</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_ratio_pavement</source>
			<translation>txt_2_void_ratio_pavement</translation>
		</message>
		<message>
			<source>txt_2_void_ratio_storage</source>
			<translation>0.75</translation>
		</message>
		<message>
			<source>tooltip_txt_2_void_ratio_storage</source>
			<translation>txt_2_void_ratio_storage</translation>
		</message>
		<message>
			<source>txt_3_field_capacity</source>
			<translation>0.2</translation>
		</message>
		<message>
			<source>tooltip_txt_3_field_capacity</source>
			<translation>txt_3_field_capacity</translation>
		</message>
		<message>
			<source>txt_3_imprevious_surface</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_3_imprevious_surface</source>
			<translation>txt_3_imprevious_surface</translation>
		</message>
		<message>
			<source>txt_3_offset</source>
			<translation>6</translation>
		</message>
		<message>
			<source>tooltip_txt_3_offset</source>
			<translation>txt_3_offset</translation>
		</message>
		<message>
			<source>txt_3_roughness</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_3_roughness</source>
			<translation>txt_3_roughness</translation>
		</message>
		<message>
			<source>txt_3_seepage_rate</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_3_seepage_rate</source>
			<translation>txt_3_seepage_rate</translation>
		</message>
		<message>
			<source>txt_3_surface_roughness</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_3_surface_roughness</source>
			<translation>txt_3_surface_roughness</translation>
		</message>
		<message>
			<source>txt_4_clogging_factor_storage</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_4_clogging_factor_storage</source>
			<translation>txt_4_clogging_factor_storage</translation>
		</message>
		<message>
			<source>txt_4_drain_delay</source>
			<translation>6</translation>
		</message>
		<message>
			<source>tooltip_txt_4_drain_delay</source>
			<translation>txt_4_drain_delay</translation>
		</message>
		<message>
			<source>txt_4_permeability</source>
			<translation>100</translation>
		</message>
		<message>
			<source>tooltip_txt_4_permeability</source>
			<translation>txt_4_permeability</translation>
		</message>
		<message>
			<source>txt_4_surface_slope</source>
			<translation>1.0</translation>
		</message>
		<message>
			<source>tooltip_txt_4_surface_slope</source>
			<translation>txt_4_surface_slope</translation>
		</message>
		<message>
			<source>txt_4_wilting_point</source>
			<translation>0.1</translation>
		</message>
		<message>
			<source>tooltip_txt_4_wilting_point</source>
			<translation>txt_4_wilting_point</translation>
		</message>
		<message>
			<source>txt_5_clogging_factor_pavement</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_5_clogging_factor_pavement</source>
			<translation>txt_5_clogging_factor_pavement</translation>
		</message>
		<message>
			<source>txt_5_conductivity</source>
			<translation>0.5</translation>
		</message>
		<message>
			<source>tooltip_txt_5_conductivity</source>
			<translation>txt_5_conductivity</translation>
		</message>
		<message>
			<source>txt_5_open_level</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_5_open_level</source>
			<translation>txt_5_open_level</translation>
		</message>
		<message>
			<source>txt_5_swale_side_slope</source>
			<translation>5</translation>
		</message>
		<message>
			<source>tooltip_txt_5_swale_side_slope</source>
			<translation>txt_5_swale_side_slope</translation>
		</message>
		<message>
			<source>txt_6_closed_level</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_closed_level</source>
			<translation>txt_6_closed_level</translation>
		</message>
		<message>
			<source>txt_6_conducticity_slope</source>
			<translation>10.0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_conducticity_slope</source>
			<translation>txt_6_conducticity_slope</translation>
		</message>
		<message>
			<source>txt_6_regeneration_interval</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_6_regeneration_interval</source>
			<translation>txt_6_regeneration_interval</translation>
		</message>
		<message>
			<source>txt_7_regeneration_fraction</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_7_regeneration_fraction</source>
			<translation>txt_7_regeneration_fraction</translation>
		</message>
		<message>
			<source>txt_7_suction_head</source>
			<translation>3.5</translation>
		</message>
		<message>
			<source>tooltip_txt_7_suction_head</source>
			<translation>txt_7_suction_head</translation>
		</message>
		<message>
			<source>txt_flow_capacity</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_txt_flow_capacity</source>
			<translation>txt_flow_capacity</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_manager</name>
		<message>
			<source>title</source>
			<translation>Menedżer obiektów niewizualnych</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplikat</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>Duplikat</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Kształt do PNG</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>btn_print</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>cat_mat_roughness</source>
			<translation>Chropowatość</translation>
		</message>
		<message>
			<source>tooltip_cat_mat_roughness</source>
			<translation>cat_mat_roughness</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Pokaż nieaktywne</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Pokaż nieaktywne</translation>
		</message>
		<message>
			<source>dlg_nonvisual_manager</source>
			<translation>Menedżer obiektów niewizualnych</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_manager</source>
			<translation>dlg_nonvisual_manager</translation>
		</message>
		<message>
			<source>inp_lid</source>
			<translation>Pokrywy</translation>
		</message>
		<message>
			<source>tooltip_inp_lid</source>
			<translation>inp_lid</translation>
		</message>
		<message>
			<source>lbl_curve_type</source>
			<translation>Typ krzywej:</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_type</source>
			<translation>Typ krzywej</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtruj według:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Typ wzoru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>Typ wzoru</translation>
		</message>
		<message>
			<source>lbl_timser_type</source>
			<translation>Typ serii czasowej:</translation>
		</message>
		<message>
			<source>tooltip_lbl_timser_type</source>
			<translation>Typ serii czasowej</translation>
		</message>
		<message>
			<source>ve_inp_controls</source>
			<translation>kontrole</translation>
		</message>
		<message>
			<source>tooltip_ve_inp_controls</source>
			<translation>ve_inp_controls</translation>
		</message>
		<message>
			<source>ve_inp_curve</source>
			<translation>krzywe</translation>
		</message>
		<message>
			<source>tooltip_ve_inp_curve</source>
			<translation>ve_inp_curve</translation>
		</message>
		<message>
			<source>ve_inp_pattern</source>
			<translation>wzory</translation>
		</message>
		<message>
			<source>tooltip_ve_inp_pattern</source>
			<translation>ve_inp_pattern</translation>
		</message>
		<message>
			<source>ve_inp_rules</source>
			<translation>zasady</translation>
		</message>
		<message>
			<source>tooltip_ve_inp_rules</source>
			<translation>ve_inp_rules</translation>
		</message>
		<message>
			<source>ve_inp_timeseries</source>
			<translation>timeseries</translation>
		</message>
		<message>
			<source>tooltip_ve_inp_timeseries</source>
			<translation>ve_inp_timeseries</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_pattern_ud</name>
		<message>
			<source>title</source>
			<translation>Edytor wzorów</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_pattern_ud</source>
			<translation>Edytor wzorów</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_pattern_ud</source>
			<translation>dlg_nonvisual_pattern_ud</translation>
		</message>
		<message>
			<source>lbl_expl_id</source>
			<translation>Identyfikator operacji</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_id</source>
			<translation>lbl_expl_id</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Obserwacja</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_pattern_id</source>
			<translation>Identyfikator wzoru</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_id</source>
			<translation>lbl_pattern_id</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Typ wzoru</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>lbl_pattern_type</translation>
		</message>
		<message>
			<source>tbl_daily</source>
			<translation>SUN</translation>
		</message>
		<message>
			<source>tooltip_tbl_daily</source>
			<translation>tbl_daily</translation>
		</message>
		<message>
			<source>tbl_hourly</source>
			<translation>11:00</translation>
		</message>
		<message>
			<source>tooltip_tbl_hourly</source>
			<translation>tbl_hourly</translation>
		</message>
		<message>
			<source>tbl_monthly</source>
			<translation>DEC</translation>
		</message>
		<message>
			<source>tooltip_tbl_monthly</source>
			<translation>tbl_monthly</translation>
		</message>
		<message>
			<source>tbl_weekend</source>
			<translation>11:00</translation>
		</message>
		<message>
			<source>tooltip_tbl_weekend</source>
			<translation>tbl_weekend</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_pattern_ws</name>
		<message>
			<source>title</source>
			<translation>Edytor wzorów</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_pattern_ws</source>
			<translation>Edytor wzorów</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_pattern_ws</source>
			<translation>dlg_nonvisual_pattern_ws</translation>
		</message>
		<message>
			<source>lbl_observ</source>
			<translation>Obserwacja</translation>
		</message>
		<message>
			<source>tooltip_lbl_observ</source>
			<translation>lbl_observ</translation>
		</message>
		<message>
			<source>lbl_pattern_id</source>
			<translation>Identyfikator wzoru</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_id</source>
			<translation>lbl_pattern_id</translation>
		</message>
		<message>
			<source>lbl_pattern_type</source>
			<translation>Identyfikator operacji</translation>
		</message>
		<message>
			<source>tooltip_lbl_pattern_type</source>
			<translation>lbl_pattern_type</translation>
		</message>
		<message>
			<source>tbl_pattern_value</source>
			<translation>18</translation>
		</message>
		<message>
			<source>tooltip_tbl_pattern_value</source>
			<translation>tbl_pattern_value</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_print</name>
		<message>
			<source>title</source>
			<translation>Drukowanie obiektów niewizualnych</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>chk_cross_arccat</source>
			<translation>Krzyż z arccat</translation>
		</message>
		<message>
			<source>tooltip_chk_cross_arccat</source>
			<translation>chk_cross_arccat</translation>
		</message>
		<message>
			<source>dlg_nonvisual_print</source>
			<translation>Drukowanie obiektów niewizualnych</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_print</source>
			<translation>dlg_nonvisual_print</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_roughness</name>
		<message>
			<source>title</source>
			<translation>Edytor kontrolek opartych na regułach</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Aktywny</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_roughness</source>
			<translation>Edytor kontrolek opartych na regułach</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_roughness</source>
			<translation>dlg_nonvisual_roughness</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Identyfikator okresu</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Początkowy wiek</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Koniec wieku</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Chropowatość</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Opis</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>lbl_matcat_id</source>
			<translation>Matcat ID</translation>
		</message>
		<message>
			<source>tooltip_lbl_matcat_id</source>
			<translation>lbl_matcat_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_rules</name>
		<message>
			<source>title</source>
			<translation>Edytor kontrolek opartych na regułach</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Aktywny</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>chk_active</translation>
		</message>
		<message>
			<source>dlg_nonvisual_rules</source>
			<translation>Edytor kontrolek opartych na regułach</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_rules</source>
			<translation>dlg_nonvisual_rules</translation>
		</message>
		<message>
			<source>lbl_sector_id</source>
			<translation>Identyfikator sektora</translation>
		</message>
		<message>
			<source>tooltip_lbl_sector_id</source>
			<translation>lbl_sector_id</translation>
		</message>
	</context>
	<context>
		<name>nonvisual_timeseries</name>
		<message>
			<source>title</source>
			<translation>Edytor serii czasowych</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_nonvisual_timeseries</source>
			<translation>Edytor serii czasowych</translation>
		</message>
		<message>
			<source>tooltip_dlg_nonvisual_timeseries</source>
			<translation>dlg_nonvisual_timeseries</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Times Type</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Opis</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Identyfikator operacji</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Aktywny</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>lbl_active</translation>
		</message>
		<message>
			<source>lbl_addparam</source>
			<translation>Addparam (json)</translation>
		</message>
		<message>
			<source>tooltip_lbl_addparam</source>
			<translation>lbl_addparam</translation>
		</message>
		<message>
			<source>lbl_curve_id</source>
			<translation>Identyfikator serii czasowej</translation>
		</message>
		<message>
			<source>tooltip_lbl_curve_id</source>
			<translation>lbl_curve_id</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Typ serii czasowej</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_fname</source>
			<translation>Nazwa pliku</translation>
		</message>
		<message>
			<source>tooltip_lbl_fname</source>
			<translation>lbl_fname</translation>
		</message>
		<message>
			<source>tbl_timeseries_value</source>
			<translation>Wartość</translation>
		</message>
		<message>
			<source>tooltip_tbl_timeseries_value</source>
			<translation>tbl_timeseries_value</translation>
		</message>
	</context>
	<context>
		<name>organization_create</name>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>organization_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_organization_create</source>
			<translation>organization_create</translation>
		</message>
	</context>
	<context>
		<name>plan_psector</name>
		<message>
			<source>active</source>
			<translation>Aktywny</translation>
		</message>
		<message>
			<source>tooltip_active</source>
			<translation>active</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_arc_fusion</source>
			<translation>btn_arc_fusion</translation>
		</message>
		<message>
			<source>tooltip_btn_arc_fusion</source>
			<translation>Łączenie łuków z łukami planowanymi</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_insert</source>
			<translation>btn_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_insert</source>
			<translation>Wstawka</translation>
		</message>
		<message>
			<source>btn_rapports</source>
			<translation>Generowanie raportów</translation>
		</message>
		<message>
			<source>tooltip_btn_rapports</source>
			<translation>btn_rapports</translation>
		</message>
		<message>
			<source>btn_remove</source>
			<translation>Usunąć</translation>
		</message>
		<message>
			<source>tooltip_btn_remove</source>
			<translation>btn_remove</translation>
		</message>
		<message>
			<source>btn_reports</source>
			<translation>Generowanie raportu</translation>
		</message>
		<message>
			<source>tooltip_btn_reports</source>
			<translation>btn_reports</translation>
		</message>
		<message>
			<source>btn_select</source>
			<translation>Wybierz</translation>
		</message>
		<message>
			<source>tooltip_btn_select</source>
			<translation>btn_select</translation>
		</message>
		<message>
			<source>btn_select_arc</source>
			<translation>btn_select_arc</translation>
		</message>
		<message>
			<source>tooltip_btn_select_arc</source>
			<translation>Wymiana w serwisie na łuk strugany</translation>
		</message>
		<message>
			<source>btn_set_geom</source>
			<translation>Ustaw geometrię</translation>
		</message>
		<message>
			<source>tooltip_btn_set_geom</source>
			<translation>btn_set_geom</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>btn_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Wybierz funkcje</translation>
		</message>
		<message>
			<source>chk_enable_all</source>
			<translation>Włącz wszystko (wizualizacja przestarzałego stanu funkcji związanych z sektorem)</translation>
		</message>
		<message>
			<source>tooltip_chk_enable_all</source>
			<translation>chk_enable_all</translation>
		</message>
		<message>
			<source>gexpenses_label</source>
			<translation>Koszty ogólne</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label</source>
			<translation>gexpenses_label</translation>
		</message>
		<message>
			<source>gexpenses_label_10</source>
			<translation>Łączna liczba łuków:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_10</source>
			<translation>gexpenses_label_10</translation>
		</message>
		<message>
			<source>gexpenses_label_3</source>
			<translation>Łączna liczba węzłów:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_3</source>
			<translation>gexpenses_label_3</translation>
		</message>
		<message>
			<source>gexpenses_label_4</source>
			<translation>Pozostałe ceny ogółem:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_4</source>
			<translation>gexpenses_label_4</translation>
		</message>
		<message>
			<source>gexpenses_label_5</source>
			<translation>Łącznie:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_5</source>
			<translation>gexpenses_label_5</translation>
		</message>
		<message>
			<source>gexpenses_label_6</source>
			<translation>Łącznie:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_6</source>
			<translation>gexpenses_label_6</translation>
		</message>
		<message>
			<source>gexpenses_label_7</source>
			<translation>Łącznie:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_7</source>
			<translation>gexpenses_label_7</translation>
		</message>
		<message>
			<source>gexpenses_label_8</source>
			<translation>Łącznie:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_8</source>
			<translation>gexpenses_label_8</translation>
		</message>
		<message>
			<source>grb_map_details</source>
			<translation>Szczegóły mapy</translation>
		</message>
		<message>
			<source>tooltip_grb_map_details</source>
			<translation>grb_map_details</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Szczegóły mapy</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Identyfikator rodzica:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_11</source>
			<translation>Tekst 1:</translation>
		</message>
		<message>
			<source>tooltip_label_11</source>
			<translation>label_11</translation>
		</message>
		<message>
			<source>label_12</source>
			<translation>Tekst 2:</translation>
		</message>
		<message>
			<source>tooltip_label_12</source>
			<translation>label_12</translation>
		</message>
		<message>
			<source>label_13</source>
			<translation>Obserwacja</translation>
		</message>
		<message>
			<source>tooltip_label_13</source>
			<translation>label_13</translation>
		</message>
		<message>
			<source>label_14</source>
			<translation>Rotacja:</translation>
		</message>
		<message>
			<source>tooltip_label_14</source>
			<translation>label_14</translation>
		</message>
		<message>
			<source>label_15</source>
			<translation>Schody:</translation>
		</message>
		<message>
			<source>tooltip_label_15</source>
			<translation>label_15</translation>
		</message>
		<message>
			<source>label_16</source>
			<translation>Atlas id:</translation>
		</message>
		<message>
			<source>tooltip_label_16</source>
			<translation>label_16</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Imię i nazwisko:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Priorytet:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>label_4</source>
			<translation>Ext code:</translation>
		</message>
		<message>
			<source>tooltip_label_4</source>
			<translation>label_4</translation>
		</message>
		<message>
			<source>label_5</source>
			<translation>Działanie:</translation>
		</message>
		<message>
			<source>tooltip_label_5</source>
			<translation>label_5</translation>
		</message>
		<message>
			<source>label_6</source>
			<translation>Identyfikator Workcat:</translation>
		</message>
		<message>
			<source>tooltip_label_6</source>
			<translation>label_6</translation>
		</message>
		<message>
			<source>label_7</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_label_7</source>
			<translation>label_7</translation>
		</message>
		<message>
			<source>label_8</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_label_8</source>
			<translation>label_8</translation>
		</message>
		<message>
			<source>lbl_atlas_id</source>
			<translation>Atlas id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_atlas_id</source>
			<translation>lbl_atlas_id</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_exploitation</source>
			<translation>Działanie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_exploitation</source>
			<translation>lbl_exploitation</translation>
		</message>
		<message>
			<source>lbl_ext_code</source>
			<translation>Kod wewnętrzny</translation>
		</message>
		<message>
			<source>tooltip_lbl_ext_code</source>
			<translation>lbl_ext_code</translation>
		</message>
		<message>
			<source>lbl_general_expenses</source>
			<translation>Koszty ogólne</translation>
		</message>
		<message>
			<source>tooltip_lbl_general_expenses</source>
			<translation>lbl_general_expenses</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Imię i nazwisko:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>lbl_name</translation>
		</message>
		<message>
			<source>lbl_num_value</source>
			<translation>Wartość liczbowa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_num_value</source>
			<translation>lbl_num_value</translation>
		</message>
		<message>
			<source>lbl_observation</source>
			<translation>Obserwacja:</translation>
		</message>
		<message>
			<source>tooltip_lbl_observation</source>
			<translation>lbl_observation</translation>
		</message>
		<message>
			<source>lbl_other_expenses</source>
			<translation>Inne wydatki</translation>
		</message>
		<message>
			<source>tooltip_lbl_other_expenses</source>
			<translation>lbl_other_expenses</translation>
		</message>
		<message>
			<source>lbl_parent_id</source>
			<translation>Identyfikator rodzica:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parent_id</source>
			<translation>lbl_parent_id</translation>
		</message>
		<message>
			<source>lbl_priority</source>
			<translation>Priorytet:</translation>
		</message>
		<message>
			<source>tooltip_lbl_priority</source>
			<translation>lbl_priority</translation>
		</message>
		<message>
			<source>lbl_psector_id</source>
			<translation>Identyfikator sektora:</translation>
		</message>
		<message>
			<source>tooltip_lbl_psector_id</source>
			<translation>lbl_psector_id</translation>
		</message>
		<message>
			<source>lbl_rotation</source>
			<translation>Rotacja:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rotation</source>
			<translation>lbl_rotation</translation>
		</message>
		<message>
			<source>lbl_scale</source>
			<translation>Schody:</translation>
		</message>
		<message>
			<source>tooltip_lbl_scale</source>
			<translation>lbl_scale</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_text1</source>
			<translation>Tekst 1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text1</source>
			<translation>lbl_text1</translation>
		</message>
		<message>
			<source>lbl_text2</source>
			<translation>Tekst 2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text2</source>
			<translation>lbl_text2</translation>
		</message>
		<message>
			<source>lbl_text3</source>
			<translation>Tekst 3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text3</source>
			<translation>lbl_text3</translation>
		</message>
		<message>
			<source>lbl_text4</source>
			<translation>Tekst 4:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text4</source>
			<translation>lbl_text4</translation>
		</message>
		<message>
			<source>lbl_text5</source>
			<translation>Tekst 5:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text5</source>
			<translation>lbl_text5</translation>
		</message>
		<message>
			<source>lbl_text6</source>
			<translation>Tekst 6:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text6</source>
			<translation>lbl_text6</translation>
		</message>
		<message>
			<source>lbl_total_arcs</source>
			<translation>Łączna liczba łuków:</translation>
		</message>
		<message>
			<source>tooltip_lbl_total_arcs</source>
			<translation>lbl_total_arcs</translation>
		</message>
		<message>
			<source>lbl_total_nodes</source>
			<translation>Łączna liczba węzłów:</translation>
		</message>
		<message>
			<source>tooltip_lbl_total_nodes</source>
			<translation>lbl_total_nodes</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Typ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
		<message>
			<source>lbl_vat</source>
			<translation>VAT:</translation>
		</message>
		<message>
			<source>tooltip_lbl_vat</source>
			<translation>lbl_vat</translation>
		</message>
		<message>
			<source>lbl_workcat_id</source>
			<translation>Identyfikator Workcat:</translation>
		</message>
		<message>
			<source>tooltip_lbl_workcat_id</source>
			<translation>lbl_workcat_id</translation>
		</message>
		<message>
			<source>other_label</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label</source>
			<translation>other_label</translation>
		</message>
		<message>
			<source>other_label_2</source>
			<translation>Inne wydatki</translation>
		</message>
		<message>
			<source>tooltip_other_label_2</source>
			<translation>other_label_2</translation>
		</message>
		<message>
			<source>other_label_3</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_3</source>
			<translation>other_label_3</translation>
		</message>
		<message>
			<source>other_label_4</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_4</source>
			<translation>other_label_4</translation>
		</message>
		<message>
			<source>tab_additional_info</source>
			<translation>Dodatkowe informacje</translation>
		</message>
		<message>
			<source>tooltip_tab_additional_info</source>
			<translation>Dodatkowe informacje</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tab_budget</source>
			<translation>Budżet</translation>
		</message>
		<message>
			<source>tooltip_tab_budget</source>
			<translation>Budżet</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Ogólne</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>Ogólne</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tab_other_prices</source>
			<translation>Inne ceny</translation>
		</message>
		<message>
			<source>tooltip_tab_other_prices</source>
			<translation>Inne ceny</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>vat_label</source>
			<translation>VAT:</translation>
		</message>
		<message>
			<source>tooltip_vat_label</source>
			<translation>vat_label</translation>
		</message>
	</context>
	<context>
		<name>price_manager</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie wynikami cenowymi</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_update_result</source>
			<translation>Bieżący wynik</translation>
		</message>
		<message>
			<source>tooltip_btn_update_result</source>
			<translation>btn_update_result</translation>
		</message>
		<message>
			<source>dlg_price_manager</source>
			<translation>Zarządzanie wynikami cenowymi</translation>
		</message>
		<message>
			<source>tooltip_dlg_price_manager</source>
			<translation>dlg_price_manager</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Filtruj według:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
	</context>
	<context>
		<name>print</name>
		<message>
			<source>title</source>
			<translation>Fastprint</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_preview</source>
			<translation>Podgląd</translation>
		</message>
		<message>
			<source>tooltip_btn_preview</source>
			<translation>btn_preview</translation>
		</message>
		<message>
			<source>btn_print</source>
			<translation>Drukuj</translation>
		</message>
		<message>
			<source>tooltip_btn_print</source>
			<translation>btn_print</translation>
		</message>
		<message>
			<source>dlg_print</source>
			<translation>Fastprint</translation>
		</message>
		<message>
			<source>tooltip_dlg_print</source>
			<translation>dlg_print</translation>
		</message>
		<message>
			<source>grb_map_options</source>
			<translation>Opcje mapy:</translation>
		</message>
		<message>
			<source>tooltip_grb_map_options</source>
			<translation>grb_map_options</translation>
		</message>
		<message>
			<source>grb_option_values</source>
			<translation>Wartości opcjonalne:</translation>
		</message>
		<message>
			<source>tooltip_grb_option_values</source>
			<translation>grb_option_values</translation>
		</message>
	</context>
	<context>
		<name>priority</name>
		<message>
			<source>title</source>
			<translation>Obliczanie priorytetu</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Obliczać</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_again</source>
			<translation>Następny</translation>
		</message>
		<message>
			<source>tooltip_btn_again</source>
			<translation>btn_again</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_save2file</source>
			<translation>Zapisywanie wyników w pliku Excel...</translation>
		</message>
		<message>
			<source>tooltip_btn_save2file</source>
			<translation>btn_save2file</translation>
		</message>
		<message>
			<source>btn_snapping</source>
			<translation>Wybrane funkcje na płótnie</translation>
		</message>
		<message>
			<source>tooltip_btn_snapping</source>
			<translation>Wybrane funkcje na płótnie</translation>
		</message>
		<message>
			<source>dlg_priority</source>
			<translation>Obliczanie priorytetu</translation>
		</message>
		<message>
			<source>tooltip_dlg_priority</source>
			<translation>dlg_priority</translation>
		</message>
		<message>
			<source>grb_engine_1</source>
			<translation>grb_engine_1</translation>
		</message>
		<message>
			<source>tooltip_grb_engine_1</source>
			<translation>grb_engine_1</translation>
		</message>
		<message>
			<source>grb_engine_2</source>
			<translation>grb_engine_2</translation>
		</message>
		<message>
			<source>tooltip_grb_engine_2</source>
			<translation>grb_engine_2</translation>
		</message>
		<message>
			<source>grb_global</source>
			<translation>Parametry obliczeniowe</translation>
		</message>
		<message>
			<source>tooltip_grb_global</source>
			<translation>grb_global</translation>
		</message>
		<message>
			<source>grb_selection</source>
			<translation>Wybór funkcji</translation>
		</message>
		<message>
			<source>tooltip_grb_selection</source>
			<translation>grb_selection</translation>
		</message>
		<message>
			<source>lbl_budget</source>
			<translation>Budżet roczny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_budget</source>
			<translation>lbl_budget</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_dnom</source>
			<translation>Średnica:</translation>
		</message>
		<message>
			<source>tooltip_lbl_dnom</source>
			<translation>lbl_dnom</translation>
		</message>
		<message>
			<source>lbl_expl_selection</source>
			<translation>Działanie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl_selection</source>
			<translation>lbl_expl_selection</translation>
		</message>
		<message>
			<source>lbl_material</source>
			<translation>Materiał:</translation>
		</message>
		<message>
			<source>tooltip_lbl_material</source>
			<translation>lbl_material</translation>
		</message>
		<message>
			<source>lbl_presszone</source>
			<translation>Strefa prasowa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_presszone</source>
			<translation>lbl_presszone</translation>
		</message>
		<message>
			<source>lbl_result_id</source>
			<translation>Nazwa wyniku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_id</source>
			<translation>lbl_result_id</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_year</source>
			<translation>Horyzont roku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_year</source>
			<translation>lbl_year</translation>
		</message>
		<message>
			<source>tab_calc</source>
			<translation>Kalkulacja</translation>
		</message>
		<message>
			<source>tooltip_tab_calc</source>
			<translation>tab_calc</translation>
		</message>
		<message>
			<source>tab_catalog</source>
			<translation>Katalog</translation>
		</message>
		<message>
			<source>tooltip_tab_catalog</source>
			<translation>tab_catalog</translation>
		</message>
		<message>
			<source>tab_engine</source>
			<translation>Silnik</translation>
		</message>
		<message>
			<source>tooltip_tab_engine</source>
			<translation>tab_engine</translation>
		</message>
		<message>
			<source>tab_infolog</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_infolog</source>
			<translation>tab_infolog</translation>
		</message>
		<message>
			<source>tab_material</source>
			<translation>Materiał</translation>
		</message>
		<message>
			<source>tooltip_tab_material</source>
			<translation>tab_material</translation>
		</message>
	</context>
	<context>
		<name>priority_manager</name>
		<message>
			<source>title</source>
			<translation>Menedżer wyników</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_corporate</source>
			<translation>Zestaw korporacyjny</translation>
		</message>
		<message>
			<source>tooltip_btn_corporate</source>
			<translation>btn_corporate</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplikat</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_edit</source>
			<translation>Edytuj</translation>
		</message>
		<message>
			<source>tooltip_btn_edit</source>
			<translation>btn_edit</translation>
		</message>
		<message>
			<source>btn_status</source>
			<translation>Zmień status</translation>
		</message>
		<message>
			<source>tooltip_btn_status</source>
			<translation>btn_status</translation>
		</message>
		<message>
			<source>dlg_priority_manager</source>
			<translation>Menedżer wyników</translation>
		</message>
		<message>
			<source>tooltip_dlg_priority_manager</source>
			<translation>dlg_priority_manager</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Działanie:</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtruj według: Nazwa wyniku</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_type</source>
			<translation>Typ:</translation>
		</message>
		<message>
			<source>tooltip_lbl_type</source>
			<translation>lbl_type</translation>
		</message>
	</context>
	<context>
		<name>profile</name>
		<message>
			<source>title</source>
			<translation>Draw Profile</translation>
		</message>
		<message>
			<source>actionAddPoint</source>
			<translation>Dodatkowy punkt</translation>
		</message>
		<message>
			<source>tooltip_actionAddPoint</source>
			<translation>actionAddPoint</translation>
		</message>
		<message>
			<source>actionProfile</source>
			<translation>Zestaw węzłów</translation>
		</message>
		<message>
			<source>tooltip_actionProfile</source>
			<translation>actionProfile</translation>
		</message>
		<message>
			<source>btn_add_additional_point</source>
			<translation>Dodatkowy punkt</translation>
		</message>
		<message>
			<source>tooltip_btn_add_additional_point</source>
			<translation>btn_add_additional_point</translation>
		</message>
		<message>
			<source>btn_add_end_point</source>
			<translation>Dodaj punkt końcowy</translation>
		</message>
		<message>
			<source>tooltip_btn_add_end_point</source>
			<translation>btn_add_end_point</translation>
		</message>
		<message>
			<source>btn_add_start_point</source>
			<translation>Dodaj punkt początkowy</translation>
		</message>
		<message>
			<source>tooltip_btn_add_start_point</source>
			<translation>btn_add_start_point</translation>
		</message>
		<message>
			<source>btn_clear_profile</source>
			<translation>Przejrzysty profil</translation>
		</message>
		<message>
			<source>tooltip_btn_clear_profile</source>
			<translation>btn_clear_profile</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_delete_additional_point</source>
			<translation>btn_delete_additional_point</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_additional_point</source>
			<translation>btn_delete_additional_point</translation>
		</message>
		<message>
			<source>btn_draw_profile</source>
			<translation>Draw profile</translation>
		</message>
		<message>
			<source>tooltip_btn_draw_profile</source>
			<translation>btn_draw_profile</translation>
		</message>
		<message>
			<source>btn_export_pdf</source>
			<translation>Otwarty kompozytor</translation>
		</message>
		<message>
			<source>tooltip_btn_export_pdf</source>
			<translation>btn_export_pdf</translation>
		</message>
		<message>
			<source>btn_load_profile</source>
			<translation>Profile obciążenia</translation>
		</message>
		<message>
			<source>tooltip_btn_load_profile</source>
			<translation>btn_load_profile</translation>
		</message>
		<message>
			<source>btn_save_profile</source>
			<translation>Zapisz profil</translation>
		</message>
		<message>
			<source>tooltip_btn_save_profile</source>
			<translation>btn_save_profile</translation>
		</message>
		<message>
			<source>btn_update_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_update_path</source>
			<translation>btn_update_path</translation>
		</message>
		<message>
			<source>date</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_date</source>
			<translation>date</translation>
		</message>
		<message>
			<source>dlg_profile</source>
			<translation>Draw Profile</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile</source>
			<translation>dlg_profile</translation>
		</message>
		<message>
			<source>grb_composer</source>
			<translation>Parametry</translation>
		</message>
		<message>
			<source>tooltip_grb_composer</source>
			<translation>grb_composer</translation>
		</message>
		<message>
			<source>grb_profile</source>
			<translation>Profil</translation>
		</message>
		<message>
			<source>tooltip_grb_profile</source>
			<translation>grb_profile</translation>
		</message>
		<message>
			<source>lbl_additional_point</source>
			<translation>Dodatkowy punkt:</translation>
		</message>
		<message>
			<source>tooltip_lbl_additional_point</source>
			<translation>lbl_additional_point</translation>
		</message>
		<message>
			<source>lbl_date</source>
			<translation>Data:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date</source>
			<translation>lbl_date</translation>
		</message>
		<message>
			<source>lbl_end_point</source>
			<translation>Punkt końcowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_point</source>
			<translation>lbl_end_point</translation>
		</message>
		<message>
			<source>lbl_min_distance</source>
			<translation>Vnode Min Dist:</translation>
		</message>
		<message>
			<source>tooltip_lbl_min_distance</source>
			<translation>lbl_min_distance</translation>
		</message>
		<message>
			<source>lbl_path</source>
			<translation>Ścieżka:</translation>
		</message>
		<message>
			<source>tooltip_lbl_path</source>
			<translation>lbl_path</translation>
		</message>
		<message>
			<source>lbl_profile_id</source>
			<translation>Identyfikator profilu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_profile_id</source>
			<translation>lbl_profile_id</translation>
		</message>
		<message>
			<source>lbl_rotation</source>
			<translation>Rotacja:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rotation</source>
			<translation>lbl_rotation</translation>
		</message>
		<message>
			<source>lbl_sh</source>
			<translation>Skala pozioma:</translation>
		</message>
		<message>
			<source>tooltip_lbl_sh</source>
			<translation>lbl_sh</translation>
		</message>
		<message>
			<source>lbl_start_point</source>
			<translation>Punkt początkowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_point</source>
			<translation>lbl_start_point</translation>
		</message>
		<message>
			<source>lbl_sv</source>
			<translation>Skala pionowa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_sv</source>
			<translation>lbl_sv</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Szablon:</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Tytuł:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
		<message>
			<source>toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>tooltip_toolBar</source>
			<translation>toolBar</translation>
		</message>
		<message>
			<source>txt_profile_id</source>
			<translation>Opcjonalny identyfikator profilu</translation>
		</message>
		<message>
			<source>tooltip_txt_profile_id</source>
			<translation>txt_profile_id</translation>
		</message>
	</context>
	<context>
		<name>profile_list</name>
		<message>
			<source>title</source>
			<translation>Profile obciążenia</translation>
		</message>
		<message>
			<source>btn_delete_profile</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_profile</source>
			<translation>btn_delete_profile</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Otwarty</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_profile_list</source>
			<translation>Profile obciążenia</translation>
		</message>
		<message>
			<source>tooltip_dlg_profile_list</source>
			<translation>dlg_profile_list</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Lista profili</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
	</context>
	<context>
		<name>project_check</name>
		<message>
			<source>title</source>
			<translation>Sprawdź projekt</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>dlg_project_check</source>
			<translation>Sprawdź projekt</translation>
		</message>
		<message>
			<source>tooltip_dlg_project_check</source>
			<translation>dlg_project_check</translation>
		</message>
		<message>
			<source>tab_databaselog</source>
			<translation>Dziennik bazy danych</translation>
		</message>
		<message>
			<source>tooltip_tab_databaselog</source>
			<translation>tab_databaselog</translation>
		</message>
		<message>
			<source>tab_qgis_projlog</source>
			<translation>Dziennik projektu Qgis</translation>
		</message>
		<message>
			<source>tooltip_tab_qgis_projlog</source>
			<translation>tab_qgis_projlog</translation>
		</message>
	</context>
	<context>
		<name>psector</name>
		<message>
			<source>title</source>
			<translation>Sektor planu</translation>
		</message>
		<message>
			<source>btn_remove</source>
			<translation>Usunąć</translation>
		</message>
		<message>
			<source>tooltip_btn_remove</source>
			<translation>btn_remove</translation>
		</message>
		<message>
			<source>btn_reports</source>
			<translation>Generowanie raportu</translation>
		</message>
		<message>
			<source>tooltip_btn_reports</source>
			<translation>btn_reports</translation>
		</message>
		<message>
			<source>btn_select</source>
			<translation>Dodaj</translation>
		</message>
		<message>
			<source>tooltip_btn_select</source>
			<translation>btn_select</translation>
		</message>
		<message>
			<source>btn_set_geom</source>
			<translation>Ustaw geometrię</translation>
		</message>
		<message>
			<source>tooltip_btn_set_geom</source>
			<translation>btn_set_geom</translation>
		</message>
		<message>
			<source>dlg_psector</source>
			<translation>Sektor planu</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector</source>
			<translation>dlg_psector</translation>
		</message>
		<message>
			<source>gexpenses_label</source>
			<translation>Koszty ogólne</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label</source>
			<translation>gexpenses_label</translation>
		</message>
		<message>
			<source>gexpenses_label_10</source>
			<translation>Łączna liczba łuków:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_10</source>
			<translation>gexpenses_label_10</translation>
		</message>
		<message>
			<source>gexpenses_label_3</source>
			<translation>Łączna liczba węzłów:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_3</source>
			<translation>gexpenses_label_3</translation>
		</message>
		<message>
			<source>gexpenses_label_4</source>
			<translation>Pozostałe ceny ogółem:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_4</source>
			<translation>gexpenses_label_4</translation>
		</message>
		<message>
			<source>gexpenses_label_5</source>
			<translation>Łącznie:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_5</source>
			<translation>gexpenses_label_5</translation>
		</message>
		<message>
			<source>gexpenses_label_6</source>
			<translation>Łącznie:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_6</source>
			<translation>gexpenses_label_6</translation>
		</message>
		<message>
			<source>gexpenses_label_7</source>
			<translation>Łącznie:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_7</source>
			<translation>gexpenses_label_7</translation>
		</message>
		<message>
			<source>gexpenses_label_8</source>
			<translation>Łącznie:</translation>
		</message>
		<message>
			<source>tooltip_gexpenses_label_8</source>
			<translation>gexpenses_label_8</translation>
		</message>
		<message>
			<source>lbl_num_value</source>
			<translation>Wartość liczbowa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_num_value</source>
			<translation>lbl_num_value</translation>
		</message>
		<message>
			<source>lbl_text3</source>
			<translation>Tekst 3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text3</source>
			<translation>lbl_text3</translation>
		</message>
		<message>
			<source>lbl_text4</source>
			<translation>Tekst 4:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text4</source>
			<translation>lbl_text4</translation>
		</message>
		<message>
			<source>lbl_text5</source>
			<translation>Tekst 5:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text5</source>
			<translation>lbl_text5</translation>
		</message>
		<message>
			<source>lbl_text6</source>
			<translation>Tekst 6:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text6</source>
			<translation>lbl_text6</translation>
		</message>
		<message>
			<source>lbl_total</source>
			<translation>Łącznie :</translation>
		</message>
		<message>
			<source>tooltip_lbl_total</source>
			<translation>lbl_total</translation>
		</message>
		<message>
			<source>lbl_total_count</source>
			<translation>0</translation>
		</message>
		<message>
			<source>tooltip_lbl_total_count</source>
			<translation>lbl_total_count</translation>
		</message>
		<message>
			<source>other_label</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label</source>
			<translation>other_label</translation>
		</message>
		<message>
			<source>other_label_2</source>
			<translation>Inne wydatki</translation>
		</message>
		<message>
			<source>tooltip_other_label_2</source>
			<translation>other_label_2</translation>
		</message>
		<message>
			<source>other_label_3</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_3</source>
			<translation>other_label_3</translation>
		</message>
		<message>
			<source>other_label_4</source>
			<translation>%</translation>
		</message>
		<message>
			<source>tooltip_other_label_4</source>
			<translation>other_label_4</translation>
		</message>
		<message>
			<source>tab_additional_info</source>
			<translation>Dodatkowe informacje</translation>
		</message>
		<message>
			<source>tooltip_tab_additional_info</source>
			<translation>tab_additional_info</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_budget</source>
			<translation>Budżet</translation>
		</message>
		<message>
			<source>tooltip_tab_budget</source>
			<translation>tab_budget</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>tab_document</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Ogólne</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_other_prices</source>
			<translation>Inne ceny</translation>
		</message>
		<message>
			<source>tooltip_tab_other_prices</source>
			<translation>tab_other_prices</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>tab_relations</translation>
		</message>
		<message>
			<source>vat_label</source>
			<translation>VAT:</translation>
		</message>
		<message>
			<source>tooltip_vat_label</source>
			<translation>vat_label</translation>
		</message>
	</context>
	<context>
		<name>psector_duplicate</name>
		<message>
			<source>title</source>
			<translation>Zduplikowany sektor</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_psector_duplicate</source>
			<translation>Zduplikowany sektor</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_duplicate</source>
			<translation>dlg_psector_duplicate</translation>
		</message>
		<message>
			<source>lbl_duplicate_psector</source>
			<translation>Zduplikowany sektor:</translation>
		</message>
		<message>
			<source>tooltip_lbl_duplicate_psector</source>
			<translation>lbl_duplicate_psector</translation>
		</message>
		<message>
			<source>lbl_new_psector</source>
			<translation>Nowa nazwa sektora:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_psector</source>
			<translation>lbl_new_psector</translation>
		</message>
		<message>
			<source>tab_duplicate_psector</source>
			<translation>Zduplikowany sektor</translation>
		</message>
		<message>
			<source>tooltip_tab_duplicate_psector</source>
			<translation>tab_duplicate_psector</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
	</context>
	<context>
		<name>psector_manager</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie sektorem</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_duplicate</source>
			<translation>Duplikat</translation>
		</message>
		<message>
			<source>tooltip_btn_duplicate</source>
			<translation>btn_duplicate</translation>
		</message>
		<message>
			<source>btn_merge</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_btn_merge</source>
			<translation>Aby połączyć różne sektory w jeden, należy wcześniej zaznaczyć je za pomocą Ctrl, a następnie kliknąć ten przycisk</translation>
		</message>
		<message>
			<source>btn_restore</source>
			<translation>Przywracanie</translation>
		</message>
		<message>
			<source>tooltip_btn_restore</source>
			<translation>btn_restore</translation>
		</message>
		<message>
			<source>btn_show</source>
			<translation>Pokaż</translation>
		</message>
		<message>
			<source>tooltip_btn_show</source>
			<translation>btn_show</translation>
		</message>
		<message>
			<source>btn_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_active</source>
			<translation>btn_toggle_active</translation>
		</message>
		<message>
			<source>btn_update_psector</source>
			<translation>Przełączanie prądu</translation>
		</message>
		<message>
			<source>tooltip_btn_update_psector</source>
			<translation>btn_update_psector</translation>
		</message>
		<message>
			<source>chk_active</source>
			<translation>Pokaż nieaktywne</translation>
		</message>
		<message>
			<source>tooltip_chk_active</source>
			<translation>Pokaż nieaktywne</translation>
		</message>
		<message>
			<source>chk_archived</source>
			<translation>Pokaż zarchiwizowane</translation>
		</message>
		<message>
			<source>tooltip_chk_archived</source>
			<translation>chk_archived</translation>
		</message>
		<message>
			<source>chk_filter_canvas</source>
			<translation>Filtr z kanwy</translation>
		</message>
		<message>
			<source>tooltip_chk_filter_canvas</source>
			<translation>Pokazuje tylko sektory widoczne na kanwie</translation>
		</message>
		<message>
			<source>dlg_psector_manager</source>
			<translation>Zarządzanie sektorem</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_manager</source>
			<translation>dlg_psector_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_psector_name</source>
			<translation>Filtruj według: Nazwa sektora</translation>
		</message>
		<message>
			<source>tooltip_lbl_psector_name</source>
			<translation>lbl_psector_name</translation>
		</message>
	</context>
	<context>
		<name>psector_rapport</name>
		<message>
			<source>title</source>
			<translation>Raport sektorowy</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>chk_composer</source>
			<translation>Plik pdf programu Composer</translation>
		</message>
		<message>
			<source>tooltip_chk_composer</source>
			<translation>chk_composer</translation>
		</message>
		<message>
			<source>dlg_psector_rapport</source>
			<translation>Raport sektorowy</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_rapport</source>
			<translation>dlg_psector_rapport</translation>
		</message>
		<message>
			<source>grb_rapport</source>
			<translation>Raport</translation>
		</message>
		<message>
			<source>tooltip_grb_rapport</source>
			<translation>grb_rapport</translation>
		</message>
		<message>
			<source>lbl_composer_disabled</source>
			<translation>Kompozytor wyłączony</translation>
		</message>
		<message>
			<source>tooltip_lbl_composer_disabled</source>
			<translation>lbl_composer_disabled</translation>
		</message>
		<message>
			<source>lbl_detail_csv</source>
			<translation>Szczegółowy plik csv:</translation>
		</message>
		<message>
			<source>tooltip_lbl_detail_csv</source>
			<translation>lbl_detail_csv</translation>
		</message>
		<message>
			<source>lbl_prices_list</source>
			<translation>Lista cen w pliku csv:</translation>
		</message>
		<message>
			<source>tooltip_lbl_prices_list</source>
			<translation>lbl_prices_list</translation>
		</message>
		<message>
			<source>lbl_template</source>
			<translation>Szablon</translation>
		</message>
		<message>
			<source>tooltip_lbl_template</source>
			<translation>lbl_template</translation>
		</message>
	</context>
	<context>
		<name>psector_repair</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_repair</source>
			<translation>Naprawa</translation>
		</message>
		<message>
			<source>tooltip_btn_repair</source>
			<translation>btn_repair</translation>
		</message>
		<message>
			<source>dlg_psector_repair</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_psector_repair</source>
			<translation>dlg_psector_repair</translation>
		</message>
	</context>
	<context>
		<name>quantized_demands</name>
		<message>
			<source>title</source>
			<translation>Skwantyzowane wymagania</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_quantized_demands</source>
			<translation>Skwantyzowane wymagania</translation>
		</message>
		<message>
			<source>tooltip_dlg_quantized_demands</source>
			<translation>dlg_quantized_demands</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Plik wejściowy INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Folder wyjściowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
	</context>
	<context>
		<name>recursive_epa</name>
		<message>
			<source>title</source>
			<translation>Połączenia wielokrotne Epa</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_recursive_epa</source>
			<translation>Połączenia wielokrotne Epa</translation>
		</message>
		<message>
			<source>tooltip_dlg_recursive_epa</source>
			<translation>dlg_recursive_epa</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Folder wyjściowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
	</context>
	<context>
		<name>replace_arc</name>
		<message>
			<source>title</source>
			<translation>Sektor planu</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_replace_arc</source>
			<translation>Sektor planu</translation>
		</message>
		<message>
			<source>tooltip_dlg_replace_arc</source>
			<translation>dlg_replace_arc</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Aktualny katalog łuków:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_arccat</source>
			<translation>Nowy katalog łuków:</translation>
		</message>
		<message>
			<source>tooltip_lbl_arccat</source>
			<translation>lbl_arccat</translation>
		</message>
		<message>
			<source>tab_general</source>
			<translation>Ogólne</translation>
		</message>
		<message>
			<source>tooltip_tab_general</source>
			<translation>tab_general</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>replace_in_file</name>
		<message>
			<source>title</source>
			<translation>Zastępowanie tekstu w pliku</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_replace_in_file</source>
			<translation>Zastępowanie tekstu w pliku</translation>
		</message>
		<message>
			<source>tooltip_dlg_replace_in_file</source>
			<translation>dlg_replace_in_file</translation>
		</message>
		<message>
			<source>lbl_subtitle</source>
			<translation>Istnieją obiekty z więcej niż 16 znakami w nazwie</translation>
		</message>
		<message>
			<source>tooltip_lbl_subtitle</source>
			<translation>lbl_subtitle</translation>
		</message>
		<message>
			<source>lbl_title</source>
			<translation>Zastąp te nazwy nowymi:</translation>
		</message>
		<message>
			<source>tooltip_lbl_title</source>
			<translation>lbl_title</translation>
		</message>
	</context>
	<context>
		<name>reports</name>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_export</source>
			<translation>Eksport</translation>
		</message>
		<message>
			<source>tooltip_btn_export</source>
			<translation>btn_export</translation>
		</message>
		<message>
			<source>grb_filters</source>
			<translation>Filtry</translation>
		</message>
		<message>
			<source>tooltip_grb_filters</source>
			<translation>grb_filters</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Zapytanie:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>lbl_export_path</source>
			<translation>Ścieżka:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_path</source>
			<translation>lbl_export_path</translation>
		</message>
	</context>
	<context>
		<name>resources_management</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie zasobami</translation>
		</message>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>btn_assign_team</source>
			<translation>Przypisywanie zespołu</translation>
		</message>
		<message>
			<source>tooltip_btn_assign_team</source>
			<translation>btn_assign_team</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_organi_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_organi_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>btn_organi_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_organi_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_organi_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_organi_update</source>
			<translation>Modyfikacja</translation>
		</message>
		<message>
			<source>btn_remove_team</source>
			<translation>Usuń zespół</translation>
		</message>
		<message>
			<source>tooltip_btn_remove_team</source>
			<translation>btn_remove_team</translation>
		</message>
		<message>
			<source>btn_team_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_team_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>btn_team_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_team_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>btn_team_selector</source>
			<translation>Selektor</translation>
		</message>
		<message>
			<source>tooltip_btn_team_selector</source>
			<translation>Selektor</translation>
		</message>
		<message>
			<source>btn_team_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>tooltip_btn_team_toggle_active</source>
			<translation>btn_team_toggle_active</translation>
		</message>
		<message>
			<source>btn_team_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_team_update</source>
			<translation>Modyfikacja</translation>
		</message>
		<message>
			<source>btn_user_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_user_create</source>
			<translation>btn_user_create</translation>
		</message>
		<message>
			<source>btn_user_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_user_delete</source>
			<translation>btn_user_delete</translation>
		</message>
		<message>
			<source>btn_user_toggle_active</source>
			<translation>Przełącz aktywny</translation>
		</message>
		<message>
			<source>tooltip_btn_user_toggle_active</source>
			<translation>btn_user_toggle_active</translation>
		</message>
		<message>
			<source>btn_user_update</source>
			<translation>Modyfikacja</translation>
		</message>
		<message>
			<source>tooltip_btn_user_update</source>
			<translation>btn_user_update</translation>
		</message>
		<message>
			<source>cmb_team</source>
			<translation>Wybierz zespół</translation>
		</message>
		<message>
			<source>tooltip_cmb_team</source>
			<translation>cmb_team</translation>
		</message>
		<message>
			<source>dlg_resources_management</source>
			<translation>Zarządzanie zasobami</translation>
		</message>
		<message>
			<source>tooltip_dlg_resources_management</source>
			<translation>dlg_resources_management</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Zarządzanie:</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Zarządzanie:</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Zarządzanie:</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Zarządzanie:</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Filtruj według nazwy:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Filtruj według nazwy zespołu:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>label_3</source>
			<translation>Filtruj według zespołu:</translation>
		</message>
		<message>
			<source>tooltip_label_3</source>
			<translation>label_3</translation>
		</message>
		<message>
			<source>organizations</source>
			<translation>Organizacje</translation>
		</message>
		<message>
			<source>tooltip_organizations</source>
			<translation>Organizacje</translation>
		</message>
		<message>
			<source>resource_management</source>
			<translation>Zarządzanie zasobami</translation>
		</message>
		<message>
			<source>tooltip_resource_management</source>
			<translation>resource_management</translation>
		</message>
		<message>
			<source>tab_organizations</source>
			<translation>Organizacje</translation>
		</message>
		<message>
			<source>tooltip_tab_organizations</source>
			<translation>tab_organizations</translation>
		</message>
		<message>
			<source>tab_teams</source>
			<translation>Zespoły</translation>
		</message>
		<message>
			<source>tooltip_tab_teams</source>
			<translation>tab_teams</translation>
		</message>
		<message>
			<source>tab_users</source>
			<translation>Użytkownicy</translation>
		</message>
		<message>
			<source>tooltip_tab_users</source>
			<translation>tab_users</translation>
		</message>
		<message>
			<source>team</source>
			<translation>Zespoły</translation>
		</message>
		<message>
			<source>tooltip_team</source>
			<translation>Zespoły</translation>
		</message>
	</context>
	<context>
		<name>result_selector</name>
		<message>
			<source>title</source>
			<translation>Selektor wyników</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_result_selector</source>
			<translation>Selektor wyników</translation>
		</message>
		<message>
			<source>tooltip_dlg_result_selector</source>
			<translation>dlg_result_selector</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_descript_compare</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript_compare</source>
			<translation>lbl_descript_compare</translation>
		</message>
		<message>
			<source>lbl_result_compare</source>
			<translation>Wynik do porównania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_compare</source>
			<translation>lbl_result_compare</translation>
		</message>
		<message>
			<source>lbl_result_main</source>
			<translation>Wynik do pokazania:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_main</source>
			<translation>lbl_result_main</translation>
		</message>
		<message>
			<source>tab_result</source>
			<translation>Wynik</translation>
		</message>
		<message>
			<source>tooltip_tab_result</source>
			<translation>tab_result</translation>
		</message>
	</context>
	<context>
		<name>search</name>
		<message>
			<source>title</source>
			<translation>Wyszukiwanie</translation>
		</message>
		<message>
			<source>Check all</source>
			<translation>Sprawdź wszystko</translation>
		</message>
		<message>
			<source>tooltip_Check all</source>
			<translation>Check all</translation>
		</message>
		<message>
			<source>dlg_search</source>
			<translation>Wyszukiwanie</translation>
		</message>
		<message>
			<source>tooltip_dlg_search</source>
			<translation>dlg_search</translation>
		</message>
		<message>
			<source>lbl_msg</source>
			<translation>Nie znaleziono wyników</translation>
		</message>
		<message>
			<source>tooltip_lbl_msg</source>
			<translation>lbl_msg</translation>
		</message>
	</context>
	<context>
		<name>search_workcat</name>
		<message>
			<source>title</source>
			<translation>Wyszukiwanie Workcat</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_export_to_csv</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_to_csv</source>
			<translation>btn_export_to_csv</translation>
		</message>
		<message>
			<source>btn_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_path</source>
			<translation>btn_path</translation>
		</message>
		<message>
			<source>btn_state0</source>
			<translation>Aktywuj</translation>
		</message>
		<message>
			<source>tooltip_btn_state0</source>
			<translation>btn_state0</translation>
		</message>
		<message>
			<source>btn_state1</source>
			<translation>Aktywuj</translation>
		</message>
		<message>
			<source>tooltip_btn_state1</source>
			<translation>btn_state1</translation>
		</message>
		<message>
			<source>dlg_search_workcat</source>
			<translation>Wyszukiwanie Workcat</translation>
		</message>
		<message>
			<source>tooltip_dlg_search_workcat</source>
			<translation>dlg_search_workcat</translation>
		</message>
		<message>
			<source>lbl_destination_path</source>
			<translation>Ścieżka docelowa:</translation>
		</message>
		<message>
			<source>tooltip_lbl_destination_path</source>
			<translation>lbl_destination_path</translation>
		</message>
		<message>
			<source>lbl_end</source>
			<translation>Filtruj według: kod</translation>
		</message>
		<message>
			<source>tooltip_lbl_end</source>
			<translation>lbl_end</translation>
		</message>
		<message>
			<source>lbl_feat_end</source>
			<translation>Funkcje usunięte z wybraną kategorią roboczą</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_end</source>
			<translation>lbl_feat_end</translation>
		</message>
		<message>
			<source>lbl_feat_ini</source>
			<translation>Funkcje zainstalowane w wybranym komputerze typu workcat</translation>
		</message>
		<message>
			<source>tooltip_lbl_feat_ini</source>
			<translation>lbl_feat_ini</translation>
		</message>
		<message>
			<source>lbl_init</source>
			<translation>Filtruj według: kod</translation>
		</message>
		<message>
			<source>tooltip_lbl_init</source>
			<translation>lbl_init</translation>
		</message>
		<message>
			<source>lbl_total1</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;&amp;lt;span style=&amp;quot; font-weight:600;&amp;quot;&amp;gt;Liczby całkowite:&amp;lt;/span&amp;gt;&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_lbl_total1</source>
			<translation>lbl_total1</translation>
		</message>
		<message>
			<source>lbl_total2</source>
			<translation>&amp;lt;html&amp;gt;&amp;lt;head/&amp;gt;&amp;lt;body&amp;gt;&amp;lt;p&amp;gt;&amp;lt;span style=&amp;quot; font-weight:600;&amp;quot;&amp;gt;Liczby całkowite:&amp;lt;/span&amp;gt;&amp;lt;/p&amp;gt;&amp;lt;/body&amp;gt;&amp;lt;/html&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_lbl_total2</source>
			<translation>lbl_total2</translation>
		</message>
		<message>
			<source>tab_doc</source>
			<translation>Dokumenty</translation>
		</message>
		<message>
			<source>tooltip_tab_doc</source>
			<translation>tab_doc</translation>
		</message>
		<message>
			<source>tab_ended</source>
			<translation>Usunięto</translation>
		</message>
		<message>
			<source>tooltip_tab_ended</source>
			<translation>tab_ended</translation>
		</message>
		<message>
			<source>tab_init</source>
			<translation>Zainstalowany</translation>
		</message>
		<message>
			<source>tooltip_tab_init</source>
			<translation>tab_init</translation>
		</message>
	</context>
	<context>
		<name>selector</name>
		<message>
			<source>title</source>
			<translation>Selektor</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>chk_all_</source>
			<translation>Sprawdź wszystko</translation>
		</message>
		<message>
			<source>tooltip_chk_all_</source>
			<translation>Shift+kliknięcie, aby odznaczyć wszystkie</translation>
		</message>
		<message>
			<source>dlg_selector</source>
			<translation>Selektor</translation>
		</message>
		<message>
			<source>tooltip_dlg_selector</source>
			<translation>dlg_selector</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtr:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
	</context>
	<context>
		<name>selector_date</name>
		<message>
			<source>title</source>
			<translation>Selektor daty</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>date_from</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_date_from</source>
			<translation>date_from</translation>
		</message>
		<message>
			<source>date_to</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_date_to</source>
			<translation>date_to</translation>
		</message>
		<message>
			<source>dlg_selector_date</source>
			<translation>Selektor daty</translation>
		</message>
		<message>
			<source>tooltip_dlg_selector_date</source>
			<translation>dlg_selector_date</translation>
		</message>
		<message>
			<source>lbl_date_from</source>
			<translation>Data od:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_from</source>
			<translation>lbl_date_from</translation>
		</message>
		<message>
			<source>lbl_date_to</source>
			<translation>Data do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_date_to</source>
			<translation>lbl_date_to</translation>
		</message>
	</context>
	<context>
		<name>show_info</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_show_info</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_show_info</source>
			<translation>dlg_show_info</translation>
		</message>
	</context>
	<context>
		<name>snapshot_view</name>
		<message>
			<source>title</source>
			<translation>Audyt</translation>
		</message>
		<message>
			<source>Audit</source>
			<translation>Audyt</translation>
		</message>
		<message>
			<source>tooltip_Audit</source>
			<translation>Audit</translation>
		</message>
		<message>
			<source>Calculate from exploitation</source>
			<translation>Obliczanie na podstawie eksploatacji</translation>
		</message>
		<message>
			<source>tooltip_Calculate from exploitation</source>
			<translation>Obliczanie na podstawie eksploatacji</translation>
		</message>
		<message>
			<source>Calculate from municipality</source>
			<translation>Obliczyć na podstawie gminy</translation>
		</message>
		<message>
			<source>tooltip_Calculate from municipality</source>
			<translation>Obliczyć na podstawie gminy</translation>
		</message>
		<message>
			<source>dlg_snapshot_view</source>
			<translation>Audyt</translation>
		</message>
		<message>
			<source>tooltip_dlg_snapshot_view</source>
			<translation>Audyt</translation>
		</message>
		<message>
			<source>Draw on map canvas</source>
			<translation>Rysowanie na płótnie mapy</translation>
		</message>
		<message>
			<source>tooltip_Draw on map canvas</source>
			<translation>Rysowanie na płótnie mapy</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Funkcje do odzyskania</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>Funkcje do odzyskania</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Selekcja czasowa i przestrzenna</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>Selekcja czasowa i przestrzenna</translation>
		</message>
		<message>
			<source>Use current map canvas extent</source>
			<translation>Użyj bieżącego zakresu kanwy mapy</translation>
		</message>
		<message>
			<source>tooltip_Use current map canvas extent</source>
			<translation>Użyj bieżącego zakresu kanwy mapy</translation>
		</message>
	</context>
	<context>
		<name>static_calibration</name>
		<message>
			<source>title</source>
			<translation>Kalibracja statyczna</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_static_calibration</source>
			<translation>Kalibracja statyczna</translation>
		</message>
		<message>
			<source>tooltip_dlg_static_calibration</source>
			<translation>dlg_static_calibration</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_inp_input_file</source>
			<translation>Plik wejściowy INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_inp_input_file</source>
			<translation>lbl_inp_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Nazwa plików wyjściowych:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
	</context>
	<context>
		<name>status_selector</name>
		<message>
			<source>title</source>
			<translation>Selektor statusu</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_status_selector</source>
			<translation>Selektor statusu</translation>
		</message>
		<message>
			<source>tooltip_dlg_status_selector</source>
			<translation>dlg_status_selector</translation>
		</message>
		<message>
			<source>lbl_new_status</source>
			<translation>Nowy status:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_status</source>
			<translation>lbl_new_status</translation>
		</message>
		<message>
			<source>lbl_result</source>
			<translation>result_id: result_name</translation>
		</message>
		<message>
			<source>tooltip_lbl_result</source>
			<translation>lbl_result</translation>
		</message>
		<message>
			<source>lbl_result_main</source>
			<translation>Zmieniasz status następującego wyniku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_result_main</source>
			<translation>lbl_result_main</translation>
		</message>
	</context>
	<context>
		<name>style</name>
		<message>
			<source>title</source>
			<translation>Dodaj kategorię</translation>
		</message>
		<message>
			<source>btn_add</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_add</source>
			<translation>btn_add</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_style</source>
			<translation>Dodaj kategorię</translation>
		</message>
		<message>
			<source>tooltip_dlg_style</source>
			<translation>dlg_style</translation>
		</message>
		<message>
			<source>lbl_cat_id</source>
			<translation>Identyfikator kategorii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_id</source>
			<translation>lbl_cat_id</translation>
		</message>
		<message>
			<source>lbl_cat_name</source>
			<translation>Nazwa kategorii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_cat_name</source>
			<translation>lbl_cat_name</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_role</source>
			<translation>Rola:</translation>
		</message>
		<message>
			<source>tooltip_lbl_role</source>
			<translation>lbl_role</translation>
		</message>
		<message>
			<source>tab_del_feature</source>
			<translation>Dane</translation>
		</message>
		<message>
			<source>tooltip_tab_del_feature</source>
			<translation>tab_del_feature</translation>
		</message>
	</context>
	<context>
		<name>style_manager</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie stylem</translation>
		</message>
		<message>
			<source>btn_addGroup</source>
			<translation>btn_addGroup</translation>
		</message>
		<message>
			<source>tooltip_btn_addGroup</source>
			<translation>Dodaj nową kategorię</translation>
		</message>
		<message>
			<source>btn_add_style</source>
			<translation>Dodaj styl</translation>
		</message>
		<message>
			<source>tooltip_btn_add_style</source>
			<translation>Dodaj styl</translation>
		</message>
		<message>
			<source>btn_addStyle</source>
			<translation>Dodaj styl</translation>
		</message>
		<message>
			<source>tooltip_btn_addStyle</source>
			<translation>Dodaje warstwę do wybranej kategorii</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_deleteGroup</source>
			<translation>btn_deleteGroup</translation>
		</message>
		<message>
			<source>tooltip_btn_deleteGroup</source>
			<translation>Usuń wybraną kategorię</translation>
		</message>
		<message>
			<source>btn_delete_style</source>
			<translation>Usuń styl</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_style</source>
			<translation>btn_delete_style</translation>
		</message>
		<message>
			<source>btn_deleteStyle</source>
			<translation>Usuń styl</translation>
		</message>
		<message>
			<source>tooltip_btn_deleteStyle</source>
			<translation>Usuwa styl z kategorii</translation>
		</message>
		<message>
			<source>btn_refresh_all</source>
			<translation>Odśwież wszystko</translation>
		</message>
		<message>
			<source>tooltip_btn_refresh_all</source>
			<translation>Odśwież wszystko</translation>
		</message>
		<message>
			<source>btn_refreshAll</source>
			<translation>Odśwież wszystko</translation>
		</message>
		<message>
			<source>tooltip_btn_refreshAll</source>
			<translation>Przeładowuje style załadowane do projektu</translation>
		</message>
		<message>
			<source>btn_update_group</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update_group</source>
			<translation>Zaktualizuj wybraną kategorię</translation>
		</message>
		<message>
			<source>btn_update_style</source>
			<translation>Styl aktualizacji</translation>
		</message>
		<message>
			<source>tooltip_btn_update_style</source>
			<translation>Styl aktualizacji</translation>
		</message>
		<message>
			<source>btn_updateStyle</source>
			<translation>Styl aktualizacji</translation>
		</message>
		<message>
			<source>tooltip_btn_updateStyle</source>
			<translation>Aktualizuje wybrany styl warstwy ze stylem w odpowiedniej warstwie projektu.</translation>
		</message>
		<message>
			<source>Delete style</source>
			<translation>Usuń styl</translation>
		</message>
		<message>
			<source>tooltip_Delete style</source>
			<translation>Usuń styl</translation>
		</message>
		<message>
			<source>dlg_style_manager</source>
			<translation>Zarządzanie stylem</translation>
		</message>
		<message>
			<source>tooltip_dlg_style_manager</source>
			<translation>dlg_style_manager</translation>
		</message>
		<message>
			<source>lbl_filter_category</source>
			<translation>Filtruj według: Kategoria</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_category</source>
			<translation>lbl_filter_category</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtruj według: layername</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
		<message>
			<source>stylegroup</source>
			<translation>stylegroup</translation>
		</message>
		<message>
			<source>tooltip_stylegroup</source>
			<translation>Wszystkie kategorie stylu</translation>
		</message>
		<message>
			<source>style_name</source>
			<translation>style_name</translation>
		</message>
		<message>
			<source>tooltip_style_name</source>
			<translation>Wprowadź nazwę warstwy do filtrowania</translation>
		</message>
	</context>
	<context>
		<name>style_update_category</name>
		<message>
			<source>title</source>
			<translation>Zmiana nazwy kategorii</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_style_update_category</source>
			<translation>Zmiana nazwy kategorii</translation>
		</message>
		<message>
			<source>tooltip_dlg_style_update_category</source>
			<translation>dlg_style_update_category</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Wybierz nazwę nowej kategorii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>lbl_rename_copy</translation>
		</message>
	</context>
	<context>
		<name>team_create</name>
		<message>
			<source>title</source>
			<translation>Utwórz zespół</translation>
		</message>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>dlg_team_create</source>
			<translation>Utwórz zespół</translation>
		</message>
		<message>
			<source>tooltip_dlg_team_create</source>
			<translation>dlg_team_create</translation>
		</message>
		<message>
			<source>grb_team</source>
			<translation>Zespół:</translation>
		</message>
		<message>
			<source>tooltip_grb_team</source>
			<translation>grb_team</translation>
		</message>
		<message>
			<source>lbl_active</source>
			<translation>Aktywny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_active</source>
			<translation>Aktywny:</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>lbl_name</source>
			<translation>Nazwa zespołu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_name</source>
			<translation>Nazwa zespołu:</translation>
		</message>
		<message>
			<source>team_create</source>
			<translation>Utwórz zespół</translation>
		</message>
		<message>
			<source>tooltip_team_create</source>
			<translation>team_create</translation>
		</message>
		<message>
			<source>TeamTab</source>
			<translation>Zespół</translation>
		</message>
		<message>
			<source>tooltip_TeamTab</source>
			<translation>TeamTab</translation>
		</message>
	</context>
	<context>
		<name>team_management</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie zespołem</translation>
		</message>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_user_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_user_select</source>
			<translation>btn_user_select</translation>
		</message>
		<message>
			<source>btn_user_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_user_unselect</source>
			<translation>btn_user_unselect</translation>
		</message>
		<message>
			<source>btn_vehicle_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_vehicle_select</source>
			<translation>btn_vehicle_select</translation>
		</message>
		<message>
			<source>btn_vehicle_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_vehicle_unselect</source>
			<translation>btn_vehicle_unselect</translation>
		</message>
		<message>
			<source>btn_visitclass_select</source>
			<translation>&amp;gt;&amp;gt;</translation>
		</message>
		<message>
			<source>tooltip_btn_visitclass_select</source>
			<translation>btn_visitclass_select</translation>
		</message>
		<message>
			<source>btn_visitclass_unselect</source>
			<translation>&amp;lt;&amp;lt;</translation>
		</message>
		<message>
			<source>tooltip_btn_visitclass_unselect</source>
			<translation>btn_visitclass_unselect</translation>
		</message>
		<message>
			<source>dlg_team_management</source>
			<translation>Zarządzanie zespołem</translation>
		</message>
		<message>
			<source>tooltip_dlg_team_management</source>
			<translation>dlg_team_management</translation>
		</message>
		<message>
			<source>tab_user</source>
			<translation>Użytkownicy</translation>
		</message>
		<message>
			<source>tooltip_tab_user</source>
			<translation>Użytkownicy</translation>
		</message>
		<message>
			<source>tab_vehicles</source>
			<translation>Pojazdy</translation>
		</message>
		<message>
			<source>tooltip_tab_vehicles</source>
			<translation>Pojazdy</translation>
		</message>
		<message>
			<source>tab_visit_class</source>
			<translation>Odwiedź klasę</translation>
		</message>
		<message>
			<source>tooltip_tab_visit_class</source>
			<translation>Odwiedź klasę</translation>
		</message>
		<message>
			<source>team_management</source>
			<translation>Zarządzanie zespołem</translation>
		</message>
		<message>
			<source>tooltip_team_management</source>
			<translation>team_management</translation>
		</message>
	</context>
	<context>
		<name>toolbox</name>
		<message>
			<source>title</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_run</source>
			<translation>Bieg</translation>
		</message>
		<message>
			<source>tooltip_btn_run</source>
			<translation>btn_run</translation>
		</message>
		<message>
			<source>dlg_toolbox</source>
			<translation>Dialog</translation>
		</message>
		<message>
			<source>tooltip_dlg_toolbox</source>
			<translation>dlg_toolbox</translation>
		</message>
		<message>
			<source>grb_input_layer</source>
			<translation>Warstwa wejściowa:</translation>
		</message>
		<message>
			<source>tooltip_grb_input_layer</source>
			<translation>grb_input_layer</translation>
		</message>
		<message>
			<source>grb_parameters</source>
			<translation>Parametry opcji:</translation>
		</message>
		<message>
			<source>tooltip_grb_parameters</source>
			<translation>grb_parameters</translation>
		</message>
		<message>
			<source>grb_selection_type</source>
			<translation>Typ wyboru:</translation>
		</message>
		<message>
			<source>tooltip_grb_selection_type</source>
			<translation>grb_selection_type</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>rbt_layer</source>
			<translation>Wszystkie funkcje</translation>
		</message>
		<message>
			<source>tooltip_rbt_layer</source>
			<translation>rbt_layer</translation>
		</message>
		<message>
			<source>rbt_previous</source>
			<translation>Tylko wybrane funkcje</translation>
		</message>
		<message>
			<source>tooltip_rbt_previous</source>
			<translation>rbt_previous</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
		<message>
			<source>trv_processes</source>
			<translation>Procesy</translation>
		</message>
		<message>
			<source>tooltip_trv_processes</source>
			<translation>trv_processes</translation>
		</message>
		<message>
			<source>trv_reports</source>
			<translation>Raporty</translation>
		</message>
		<message>
			<source>tooltip_trv_reports</source>
			<translation>trv_reports</translation>
		</message>
	</context>
	<context>
		<name>toolbox_reports</name>
		<message>
			<source>title</source>
			<translation>Raporty</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_export</source>
			<translation>Eksport</translation>
		</message>
		<message>
			<source>tooltip_btn_export</source>
			<translation>btn_export</translation>
		</message>
		<message>
			<source>btn_export_path</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_btn_export_path</source>
			<translation>btn_export_path</translation>
		</message>
		<message>
			<source>dlg_toolbox_reports</source>
			<translation>Raporty</translation>
		</message>
		<message>
			<source>tooltip_dlg_toolbox_reports</source>
			<translation>dlg_toolbox_reports</translation>
		</message>
		<message>
			<source>grb_filters</source>
			<translation>Filtry</translation>
		</message>
		<message>
			<source>tooltip_grb_filters</source>
			<translation>grb_filters</translation>
		</message>
		<message>
			<source>grb_info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>tooltip_grb_info</source>
			<translation>grb_info</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Zapytanie:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>label_2</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_label_2</source>
			<translation>label_2</translation>
		</message>
		<message>
			<source>lbl_export_path</source>
			<translation>Ścieżka:</translation>
		</message>
		<message>
			<source>tooltip_lbl_export_path</source>
			<translation>lbl_export_path</translation>
		</message>
	</context>
	<context>
		<name>toolbox_tool</name>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_run</source>
			<translation>Bieg</translation>
		</message>
		<message>
			<source>tooltip_btn_run</source>
			<translation>btn_run</translation>
		</message>
		<message>
			<source>grb_input_layer</source>
			<translation>Warstwa wejściowa:</translation>
		</message>
		<message>
			<source>tooltip_grb_input_layer</source>
			<translation>grb_input_layer</translation>
		</message>
		<message>
			<source>grb_parameters</source>
			<translation>Parametry opcji:</translation>
		</message>
		<message>
			<source>tooltip_grb_parameters</source>
			<translation>grb_parameters</translation>
		</message>
		<message>
			<source>grb_selection_type</source>
			<translation>Typ wyboru:</translation>
		</message>
		<message>
			<source>tooltip_grb_selection_type</source>
			<translation>grb_selection_type</translation>
		</message>
		<message>
			<source>groupBox</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_groupBox</source>
			<translation>groupBox</translation>
		</message>
		<message>
			<source>progressBar</source>
			<translation>%p%</translation>
		</message>
		<message>
			<source>tooltip_progressBar</source>
			<translation>progressBar</translation>
		</message>
		<message>
			<source>rbt_layer</source>
			<translation>Wszystkie funkcje</translation>
		</message>
		<message>
			<source>tooltip_rbt_layer</source>
			<translation>rbt_layer</translation>
		</message>
		<message>
			<source>rbt_previous</source>
			<translation>Tylko wybrane funkcje</translation>
		</message>
		<message>
			<source>tooltip_rbt_previous</source>
			<translation>rbt_previous</translation>
		</message>
		<message>
			<source>tab_config</source>
			<translation>Konfiguracja</translation>
		</message>
		<message>
			<source>tooltip_tab_config</source>
			<translation>tab_config</translation>
		</message>
		<message>
			<source>tab_loginfo</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_loginfo</source>
			<translation>tab_loginfo</translation>
		</message>
	</context>
	<context>
		<name>update_style_group</name>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>lbl_rename_copy</source>
			<translation>Wybierz nazwę nowej kategorii:</translation>
		</message>
		<message>
			<source>tooltip_lbl_rename_copy</source>
			<translation>Wybierz nazwę nowej kategorii:</translation>
		</message>
	</context>
	<context>
		<name>user_create</name>
		<message>
			<source>title</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>actionT</source>
			<translation>t</translation>
		</message>
		<message>
			<source>tooltip_actionT</source>
			<translation>actionT</translation>
		</message>
		<message>
			<source>dlg_user_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_dlg_user_create</source>
			<translation>dlg_user_create</translation>
		</message>
		<message>
			<source>user_create</source>
			<translation>Utwórz użytkownika</translation>
		</message>
		<message>
			<source>tooltip_user_create</source>
			<translation>user_create</translation>
		</message>
	</context>
	<context>
		<name>valve_operation_check</name>
		<message>
			<source>title</source>
			<translation>Kontrola działania zaworu</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_ok</source>
			<translation>OK</translation>
		</message>
		<message>
			<source>tooltip_btn_ok</source>
			<translation>btn_ok</translation>
		</message>
		<message>
			<source>dlg_valve_operation_check</source>
			<translation>Kontrola działania zaworu</translation>
		</message>
		<message>
			<source>tooltip_dlg_valve_operation_check</source>
			<translation>dlg_valve_operation_check</translation>
		</message>
		<message>
			<source>lbl_config_file</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_lbl_config_file</source>
			<translation>lbl_config_file</translation>
		</message>
		<message>
			<source>lbl_filename</source>
			<translation>Nazwa pliku:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filename</source>
			<translation>lbl_filename</translation>
		</message>
		<message>
			<source>lbl_input_file</source>
			<translation>Plik wejściowy INP:</translation>
		</message>
		<message>
			<source>tooltip_lbl_input_file</source>
			<translation>lbl_input_file</translation>
		</message>
		<message>
			<source>lbl_output_folder</source>
			<translation>Folder wyjściowy:</translation>
		</message>
		<message>
			<source>tooltip_lbl_output_folder</source>
			<translation>lbl_output_folder</translation>
		</message>
		<message>
			<source>lbl_scenarios</source>
			<translation>Użyj scenariuszy z:</translation>
		</message>
		<message>
			<source>tooltip_lbl_scenarios</source>
			<translation>lbl_scenarios</translation>
		</message>
		<message>
			<source>rdb_scenarios_config</source>
			<translation>Plik konfiguracyjny:</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_config</source>
			<translation>rdb_scenarios_config</translation>
		</message>
		<message>
			<source>rdb_scenarios_database</source>
			<translation>Baza danych</translation>
		</message>
		<message>
			<source>tooltip_rdb_scenarios_database</source>
			<translation>rdb_scenarios_database</translation>
		</message>
	</context>
	<context>
		<name>visit</name>
		<message>
			<source>title</source>
			<translation>Odwiedź</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_add_geom</source>
			<translation>Dodaj geom</translation>
		</message>
		<message>
			<source>tooltip_btn_add_geom</source>
			<translation>btn_add_geom</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_doc_delete</source>
			<translation>btn_doc_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_doc_delete</source>
			<translation>Usuń dokument</translation>
		</message>
		<message>
			<source>btn_doc_insert</source>
			<translation>btn_doc_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_doc_insert</source>
			<translation>Wstaw dokument</translation>
		</message>
		<message>
			<source>btn_doc_new</source>
			<translation>btn_doc_new</translation>
		</message>
		<message>
			<source>tooltip_btn_doc_new</source>
			<translation>Tworzenie nowego dokumentu</translation>
		</message>
		<message>
			<source>btn_event_delete</source>
			<translation>USUŃ ZDARZENIE</translation>
		</message>
		<message>
			<source>tooltip_btn_event_delete</source>
			<translation>btn_event_delete</translation>
		</message>
		<message>
			<source>btn_event_insert</source>
			<translation>WSTAW WYDARZENIE</translation>
		</message>
		<message>
			<source>tooltip_btn_event_insert</source>
			<translation>btn_event_insert</translation>
		</message>
		<message>
			<source>btn_event_update</source>
			<translation>AKTUALIZACJA WYDARZENIA</translation>
		</message>
		<message>
			<source>tooltip_btn_event_update</source>
			<translation>btn_event_update</translation>
		</message>
		<message>
			<source>btn_feature_delete</source>
			<translation>btn_feature_delete</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_delete</source>
			<translation>btn_feature_delete</translation>
		</message>
		<message>
			<source>btn_feature_insert</source>
			<translation>btn_feature_insert</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_insert</source>
			<translation>btn_feature_insert</translation>
		</message>
		<message>
			<source>btn_feature_snapping</source>
			<translation>btn_feature_snapping</translation>
		</message>
		<message>
			<source>tooltip_btn_feature_snapping</source>
			<translation>btn_feature_snapping</translation>
		</message>
		<message>
			<source>btn_open_doc</source>
			<translation>btn_open_doc</translation>
		</message>
		<message>
			<source>tooltip_btn_open_doc</source>
			<translation>Otwórz dokument</translation>
		</message>
		<message>
			<source>dlg_visit</source>
			<translation>Odwiedź</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit</source>
			<translation>dlg_visit</translation>
		</message>
		<message>
			<source>enddate</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_enddate</source>
			<translation>enddate</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Typ funkcji:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_code</source>
			<translation>Kod:</translation>
		</message>
		<message>
			<source>tooltip_lbl_code</source>
			<translation>lbl_code</translation>
		</message>
		<message>
			<source>lbl_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_descript</source>
			<translation>lbl_descript</translation>
		</message>
		<message>
			<source>lbl_end_date</source>
			<translation>Data zakończenia:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_end_date</source>
			<translation>lbl_end_date</translation>
		</message>
		<message>
			<source>lbl_expl</source>
			<translation>Operacje:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_expl</source>
			<translation>lbl_expl</translation>
		</message>
		<message>
			<source>lbl_feature_type</source>
			<translation>Typ funkcji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_feature_type</source>
			<translation>lbl_feature_type</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_info</source>
			<translation>Na pasku narzędzi włączone są tylko ZDARZENIA STANDARDOWE.</translation>
		</message>
		<message>
			<source>tooltip_lbl_info</source>
			<translation>lbl_info</translation>
		</message>
		<message>
			<source>lbl_start_date</source>
			<translation>Data rozpoczęcia:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_start_date</source>
			<translation>lbl_start_date</translation>
		</message>
		<message>
			<source>lbl_status</source>
			<translation>Status:</translation>
		</message>
		<message>
			<source>tooltip_lbl_status</source>
			<translation>lbl_status</translation>
		</message>
		<message>
			<source>lbl_user_name</source>
			<translation>Nazwa użytkownika:</translation>
		</message>
		<message>
			<source>tooltip_lbl_user_name</source>
			<translation>lbl_user_name</translation>
		</message>
		<message>
			<source>lbl_visitcat_id</source>
			<translation>Identyfikator Visitcat:*</translation>
		</message>
		<message>
			<source>tooltip_lbl_visitcat_id</source>
			<translation>lbl_visitcat_id</translation>
		</message>
		<message>
			<source>startdate</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_startdate</source>
			<translation>startdate</translation>
		</message>
		<message>
			<source>tab_arc</source>
			<translation>Łuk</translation>
		</message>
		<message>
			<source>tooltip_tab_arc</source>
			<translation>tab_arc</translation>
		</message>
		<message>
			<source>tab_connec</source>
			<translation>Połączenie</translation>
		</message>
		<message>
			<source>tooltip_tab_connec</source>
			<translation>tab_connec</translation>
		</message>
		<message>
			<source>tab_document</source>
			<translation>Dokument</translation>
		</message>
		<message>
			<source>tooltip_tab_document</source>
			<translation>tab_document</translation>
		</message>
		<message>
			<source>tab_event</source>
			<translation>Wydarzenie</translation>
		</message>
		<message>
			<source>tooltip_tab_event</source>
			<translation>tab_event</translation>
		</message>
		<message>
			<source>tab_gully</source>
			<translation>Wąwóz</translation>
		</message>
		<message>
			<source>tooltip_tab_gully</source>
			<translation>tab_gully</translation>
		</message>
		<message>
			<source>tab_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>tooltip_tab_link</source>
			<translation>tab_link</translation>
		</message>
		<message>
			<source>tab_node</source>
			<translation>Węzeł</translation>
		</message>
		<message>
			<source>tooltip_tab_node</source>
			<translation>tab_node</translation>
		</message>
		<message>
			<source>tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>tooltip_tab_relations</source>
			<translation>Relacje</translation>
		</message>
		<message>
			<source>tab_visit</source>
			<translation>Odwiedź</translation>
		</message>
		<message>
			<source>tooltip_tab_visit</source>
			<translation>tab_visit</translation>
		</message>
	</context>
	<context>
		<name>visit_document</name>
		<message>
			<source>title</source>
			<translation>Wczytywanie dokumentów</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Otwarty</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>dlg_visit_document</source>
			<translation>Wczytywanie dokumentów</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_document</source>
			<translation>dlg_visit_document</translation>
		</message>
		<message>
			<source>groupBox_2</source>
			<translation>Lista dokumentów</translation>
		</message>
		<message>
			<source>tooltip_groupBox_2</source>
			<translation>groupBox_2</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Odwiedź id</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>Odwiedź ID</translation>
		</message>
	</context>
	<context>
		<name>visit_event</name>
		<message>
			<source>title</source>
			<translation>Zdarzenie standardowe</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_file</source>
			<translation>Dodaj plik</translation>
		</message>
		<message>
			<source>tooltip_btn_add_file</source>
			<translation>btn_add_file</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_file</source>
			<translation>Usuń plik</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_file</source>
			<translation>btn_delete_file</translation>
		</message>
		<message>
			<source>dlg_visit_event</source>
			<translation>Zdarzenie standardowe</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event</source>
			<translation>dlg_visit_event</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Event_code:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Pliki:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Identyfikator parametru:      </translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Identyfikator stanowiska:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Wartość pozycji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Tekst:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_value</source>
			<translation>Wartość:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value</source>
			<translation>lbl_value</translation>
		</message>
	</context>
	<context>
		<name>visit_event_full</name>
		<message>
			<source>title</source>
			<translation>Wydarzenie</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>dlg_visit_event_full</source>
			<translation>Wydarzenie</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event_full</source>
			<translation>dlg_visit_event_full</translation>
		</message>
		<message>
			<source>lbl_compass</source>
			<translation>Kompas:</translation>
		</message>
		<message>
			<source>tooltip_lbl_compass</source>
			<translation>lbl_compass</translation>
		</message>
		<message>
			<source>lbl_event_code</source>
			<translation>Kod zdarzenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_code</source>
			<translation>lbl_event_code</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Pliki:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_geom1</source>
			<translation>Geom1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom1</source>
			<translation>lbl_geom1</translation>
		</message>
		<message>
			<source>lbl_geom2</source>
			<translation>Geom2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom2</source>
			<translation>lbl_geom2</translation>
		</message>
		<message>
			<source>lbl_geom3</source>
			<translation>Geom3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom3</source>
			<translation>lbl_geom3</translation>
		</message>
		<message>
			<source>lbl_id</source>
			<translation>Id:</translation>
		</message>
		<message>
			<source>tooltip_lbl_id</source>
			<translation>lbl_id</translation>
		</message>
		<message>
			<source>lbl_index_val</source>
			<translation>Pułapka indeksu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_index_val</source>
			<translation>lbl_index_val</translation>
		</message>
		<message>
			<source>lbl_is_last</source>
			<translation>Jest ostatni:</translation>
		</message>
		<message>
			<source>tooltip_lbl_is_last</source>
			<translation>lbl_is_last</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Identyfikator parametru:</translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Identyfikator stanowiska:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Wartość pozycji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Tekst:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_tstamp</source>
			<translation>Tstamp:</translation>
		</message>
		<message>
			<source>tooltip_lbl_tstamp</source>
			<translation>lbl_tstamp</translation>
		</message>
		<message>
			<source>lbl_value</source>
			<translation>Wartość:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value</source>
			<translation>lbl_value</translation>
		</message>
		<message>
			<source>lbl_value1</source>
			<translation>Wartość1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value1</source>
			<translation>lbl_value1</translation>
		</message>
		<message>
			<source>lbl_value2</source>
			<translation>Wartość2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value2</source>
			<translation>lbl_value2</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Identyfikator wizyty:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>Odwiedź ID</translation>
		</message>
		<message>
			<source>lbl_xcoord</source>
			<translation>Xcoord:</translation>
		</message>
		<message>
			<source>tooltip_lbl_xcoord</source>
			<translation>lbl_xcoord</translation>
		</message>
		<message>
			<source>lbl_ycoord</source>
			<translation>Ycoord:</translation>
		</message>
		<message>
			<source>tooltip_lbl_ycoord</source>
			<translation>lbl_ycoord</translation>
		</message>
		<message>
			<source>tab_files</source>
			<translation>Pliki</translation>
		</message>
		<message>
			<source>tooltip_tab_files</source>
			<translation>tab_files</translation>
		</message>
		<message>
			<source>tab_info</source>
			<translation>Info</translation>
		</message>
		<message>
			<source>tooltip_tab_info</source>
			<translation>tab_info</translation>
		</message>
	</context>
	<context>
		<name>visit_event_rehab</name>
		<message>
			<source>title</source>
			<translation>Zdarzenie łuku rehabilitacyjnego</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_add_file</source>
			<translation>Dodaj plik</translation>
		</message>
		<message>
			<source>tooltip_btn_add_file</source>
			<translation>btn_add_file</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_delete_file</source>
			<translation>Usuń plik</translation>
		</message>
		<message>
			<source>tooltip_btn_delete_file</source>
			<translation>btn_delete_file</translation>
		</message>
		<message>
			<source>dlg_visit_event_rehab</source>
			<translation>Zdarzenie łuku rehabilitacyjnego</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_event_rehab</source>
			<translation>dlg_visit_event_rehab</translation>
		</message>
		<message>
			<source>lbl_files</source>
			<translation>Pliki:</translation>
		</message>
		<message>
			<source>tooltip_lbl_files</source>
			<translation>lbl_files</translation>
		</message>
		<message>
			<source>lbl_geom1</source>
			<translation>Geom1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom1</source>
			<translation>lbl_geom1</translation>
		</message>
		<message>
			<source>lbl_geom2</source>
			<translation>Geom2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom2</source>
			<translation>lbl_geom2</translation>
		</message>
		<message>
			<source>lbl_geom3</source>
			<translation>Geom3:</translation>
		</message>
		<message>
			<source>tooltip_lbl_geom3</source>
			<translation>lbl_geom3</translation>
		</message>
		<message>
			<source>lbl_parameter_id</source>
			<translation>Identyfikator parametru:      </translation>
		</message>
		<message>
			<source>tooltip_lbl_parameter_id</source>
			<translation>lbl_parameter_id</translation>
		</message>
		<message>
			<source>lbl_position_id</source>
			<translation>Identyfikator stanowiska:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_id</source>
			<translation>lbl_position_id</translation>
		</message>
		<message>
			<source>lbl_position_value</source>
			<translation>Wartość pozycji:</translation>
		</message>
		<message>
			<source>tooltip_lbl_position_value</source>
			<translation>lbl_position_value</translation>
		</message>
		<message>
			<source>lbl_text</source>
			<translation>Tekst:</translation>
		</message>
		<message>
			<source>tooltip_lbl_text</source>
			<translation>lbl_text</translation>
		</message>
		<message>
			<source>lbl_value1</source>
			<translation>Wartość1:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value1</source>
			<translation>lbl_value1</translation>
		</message>
		<message>
			<source>lbl_value2</source>
			<translation>Wartość2:</translation>
		</message>
		<message>
			<source>tooltip_lbl_value2</source>
			<translation>lbl_value2</translation>
		</message>
	</context>
	<context>
		<name>visit_gallery</name>
		<message>
			<source>title</source>
			<translation>Galeria</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>btn_close</translation>
		</message>
		<message>
			<source>btn_next</source>
			<translation>btn_next</translation>
		</message>
		<message>
			<source>tooltip_btn_next</source>
			<translation>btn_next</translation>
		</message>
		<message>
			<source>btn_previous</source>
			<translation>btn_previous</translation>
		</message>
		<message>
			<source>tooltip_btn_previous</source>
			<translation>btn_previous</translation>
		</message>
		<message>
			<source>dlg_visit_gallery</source>
			<translation>Galeria</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_gallery</source>
			<translation>dlg_visit_gallery</translation>
		</message>
		<message>
			<source>lbl_event_id</source>
			<translation>Identyfikator zdarzenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_id</source>
			<translation>lbl_event_id</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Identyfikator wizyty:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>Odwiedź ID</translation>
		</message>
	</context>
	<context>
		<name>visit_gallery_zoom</name>
		<message>
			<source>title</source>
			<translation>Gallery zoom</translation>
		</message>
		<message>
			<source>btn_slideNext</source>
			<translation>btn_slideNext</translation>
		</message>
		<message>
			<source>tooltip_btn_slideNext</source>
			<translation>btn_slideNext</translation>
		</message>
		<message>
			<source>btn_slidePrevious</source>
			<translation>btn_slidePrevious</translation>
		</message>
		<message>
			<source>tooltip_btn_slidePrevious</source>
			<translation>btn_slidePrevious</translation>
		</message>
		<message>
			<source>dlg_visit_gallery_zoom</source>
			<translation>Gallery zoom</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_gallery_zoom</source>
			<translation>dlg_visit_gallery_zoom</translation>
		</message>
		<message>
			<source>lbl_event_id</source>
			<translation>Identyfikator zdarzenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_event_id</source>
			<translation>lbl_event_id</translation>
		</message>
		<message>
			<source>lbl_img_zoom</source>
			<translation>Powiększenie obrazu</translation>
		</message>
		<message>
			<source>tooltip_lbl_img_zoom</source>
			<translation>lbl_img_zoom</translation>
		</message>
		<message>
			<source>lbl_visit_id</source>
			<translation>Identyfikator wizyty:</translation>
		</message>
		<message>
			<source>tooltip_lbl_visit_id</source>
			<translation>Odwiedź ID</translation>
		</message>
	</context>
	<context>
		<name>visit_manager</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie wizytą</translation>
		</message>
		<message>
			<source>btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_close</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń wizytę</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>btn_open</source>
			<translation>Wizyta otwarta</translation>
		</message>
		<message>
			<source>tooltip_btn_open</source>
			<translation>btn_open</translation>
		</message>
		<message>
			<source>date_event_from</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_date_event_from</source>
			<translation>date_event_from</translation>
		</message>
		<message>
			<source>date_event_to</source>
			<translation>dd/MM/rrrr</translation>
		</message>
		<message>
			<source>tooltip_date_event_to</source>
			<translation>date_event_to</translation>
		</message>
		<message>
			<source>dlg_visit_manager</source>
			<translation>Zarządzanie wizytą</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_manager</source>
			<translation>dlg_visit_manager</translation>
		</message>
		<message>
			<source>lbl_data_event_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_from</source>
			<translation>lbl_data_event_from</translation>
		</message>
		<message>
			<source>lbl_data_event_to</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_data_event_to</source>
			<translation>lbl_data_event_to</translation>
		</message>
		<message>
			<source>lbl_filter</source>
			<translation>Filtruj według kodu:</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter</source>
			<translation>lbl_filter</translation>
		</message>
	</context>
	<context>
		<name>visit_picture</name>
		<message>
			<source>title</source>
			<translation>Dodaj zdjęcie</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>dlg_visit_picture</source>
			<translation>Dodaj zdjęcie</translation>
		</message>
		<message>
			<source>tooltip_dlg_visit_picture</source>
			<translation>dlg_visit_picture</translation>
		</message>
		<message>
			<source>lbl_link</source>
			<translation>Link:</translation>
		</message>
		<message>
			<source>tooltip_lbl_link</source>
			<translation>Link do</translation>
		</message>
		<message>
			<source>path_doc</source>
			<translation>...</translation>
		</message>
		<message>
			<source>tooltip_path_doc</source>
			<translation>path_doc</translation>
		</message>
	</context>
	<context>
		<name>workcat_manager</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie Workcat</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>dlg_workcat_manager</source>
			<translation>Zarządzanie Workcat</translation>
		</message>
		<message>
			<source>tooltip_dlg_workcat_manager</source>
			<translation>dlg_workcat_manager</translation>
		</message>
		<message>
			<source>lbl_filter_name</source>
			<translation>Filtruj według: Nazwa komputera roboczego</translation>
		</message>
		<message>
			<source>tooltip_lbl_filter_name</source>
			<translation>lbl_filter_name</translation>
		</message>
	</context>
	<context>
		<name>work_management</name>
		<message>
			<source>btn_accept</source>
			<translation>Zapisz</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>Zapisz</translation>
		</message>
		<message>
			<source>btn_export_user</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>tooltip_btn_export_user</source>
			<translation>Eksport do csv</translation>
		</message>
		<message>
			<source>lbl_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>tooltip_lbl_from</source>
			<translation>Od:</translation>
		</message>
		<message>
			<source>lbl_team</source>
			<translation>Zespół:</translation>
		</message>
		<message>
			<source>tooltip_lbl_team</source>
			<translation>Zespół:</translation>
		</message>
		<message>
			<source>lbl_to</source>
			<translation>Do:</translation>
		</message>
		<message>
			<source>tooltip_lbl_to</source>
			<translation>Do:</translation>
		</message>
	</context>
	<context>
		<name>workorder_management</name>
		<message>
			<source>title</source>
			<translation>Zarządzanie zleceniami pracy</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Utwórz zlecenie pracy</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>btn_create</translation>
		</message>
		<message>
			<source>btn_create_wclass</source>
			<translation>Utwórz klasę</translation>
		</message>
		<message>
			<source>tooltip_btn_create_wclass</source>
			<translation>btn_create_wclass</translation>
		</message>
		<message>
			<source>btn_create_wtype</source>
			<translation>Utwórz typ</translation>
		</message>
		<message>
			<source>tooltip_btn_create_wtype</source>
			<translation>btn_create_wtype</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń zlecenie</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>btn_delete</translation>
		</message>
		<message>
			<source>campaign_management</source>
			<translation>Menedżer kampanii</translation>
		</message>
		<message>
			<source>tooltip_campaign_management</source>
			<translation>campaign_management</translation>
		</message>
		<message>
			<source>dlg_workorder_management</source>
			<translation>Zarządzanie zleceniami pracy</translation>
		</message>
		<message>
			<source>tooltip_dlg_workorder_management</source>
			<translation>dlg_workorder_management</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Filtruj według nazwy:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_column_filter_dates</source>
			<translation>Typ zlecenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_column_filter_dates</source>
			<translation>lbl_column_filter_dates</translation>
		</message>
		<message>
			<source>lbl_state</source>
			<translation>Klasa zlecenia:</translation>
		</message>
		<message>
			<source>tooltip_lbl_state</source>
			<translation>lbl_state</translation>
		</message>
		<message>
			<source>workorder_management</source>
			<translation>Zarządzanie zleceniami pracy</translation>
		</message>
		<message>
			<source>tooltip_workorder_management</source>
			<translation>workorder_management</translation>
		</message>
	</context>
	<context>
		<name>workspace_create</name>
		<message>
			<source>title</source>
			<translation>Utwórz nowy obszar roboczy</translation>
		</message>
		<message>
			<source>btn_accept</source>
			<translation>Akceptuj</translation>
		</message>
		<message>
			<source>tooltip_btn_accept</source>
			<translation>btn_accept</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Anuluj</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_toggle_privacy</source>
			<translation>Przełączanie prywatności</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_privacy</source>
			<translation>btn_toggle_privacy</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>btn_update</translation>
		</message>
		<message>
			<source>dlg_workspace_create</source>
			<translation>Utwórz nowy obszar roboczy</translation>
		</message>
		<message>
			<source>tooltip_dlg_workspace_create</source>
			<translation>dlg_workspace_create</translation>
		</message>
		<message>
			<source>lbl_new_workspace</source>
			<translation>Nazwa obszaru roboczego:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace</source>
			<translation>Nazwa obszaru roboczego</translation>
		</message>
		<message>
			<source>lbl_new_workspace_chk</source>
			<translation>Prywatna przestrzeń robocza:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace_chk</source>
			<translation>lbl_new_workspace_chk</translation>
		</message>
		<message>
			<source>lbl_new_workspace_descript</source>
			<translation>Opis:</translation>
		</message>
		<message>
			<source>tooltip_lbl_new_workspace_descript</source>
			<translation>Opis obszaru roboczego</translation>
		</message>
		<message>
			<source>tab_info_log</source>
			<translation>Dziennik informacyjny</translation>
		</message>
		<message>
			<source>tooltip_tab_info_log</source>
			<translation>tab_info_log</translation>
		</message>
		<message>
			<source>tab_new_workspace</source>
			<translation>Utwórz nowy obszar roboczy</translation>
		</message>
		<message>
			<source>tooltip_tab_new_workspace</source>
			<translation>tab_new_workspace</translation>
		</message>
		<message>
			<source>txt_workspace_descript</source>
			<translation>Opis obszaru roboczego</translation>
		</message>
		<message>
			<source>tooltip_txt_workspace_descript</source>
			<translation>Użyj tego, aby opisać, do czego służy obszar roboczy</translation>
		</message>
		<message>
			<source>txt_workspace_name</source>
			<translation>Nazwa obszaru roboczego</translation>
		</message>
		<message>
			<source>tooltip_txt_workspace_name</source>
			<translation>Nazwa obszaru roboczego *wymagane</translation>
		</message>
	</context>
	<context>
		<name>workspace_manager</name>
		<message>
			<source>title</source>
			<translation>Menedżer przestrzeni roboczej</translation>
		</message>
		<message>
			<source>btn_cancel</source>
			<translation>Zamknij</translation>
		</message>
		<message>
			<source>tooltip_btn_cancel</source>
			<translation>btn_cancel</translation>
		</message>
		<message>
			<source>btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>tooltip_btn_create</source>
			<translation>Utwórz</translation>
		</message>
		<message>
			<source>btn_current</source>
			<translation>Ustaw bieżący</translation>
		</message>
		<message>
			<source>tooltip_btn_current</source>
			<translation>Ustaw bieżący obszar roboczy</translation>
		</message>
		<message>
			<source>btn_delete</source>
			<translation>Usuń</translation>
		</message>
		<message>
			<source>tooltip_btn_delete</source>
			<translation>Usuń wybrany obszar roboczy</translation>
		</message>
		<message>
			<source>btn_reset</source>
			<translation>Resetowanie obszaru roboczego</translation>
		</message>
		<message>
			<source>tooltip_btn_reset</source>
			<translation>Resetowanie wartości bieżącego obszaru roboczego</translation>
		</message>
		<message>
			<source>btn_toggle_privacy</source>
			<translation>Przełączanie prywatności</translation>
		</message>
		<message>
			<source>tooltip_btn_toggle_privacy</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>btn_update</source>
			<translation>Aktualizacja</translation>
		</message>
		<message>
			<source>tooltip_btn_update</source>
			<translation>Przełączanie prywatności</translation>
		</message>
		<message>
			<source>dlg_workspace_manager</source>
			<translation>Menedżer przestrzeni roboczej</translation>
		</message>
		<message>
			<source>tooltip_dlg_workspace_manager</source>
			<translation>dlg_workspace_manager</translation>
		</message>
		<message>
			<source>label</source>
			<translation>Info:</translation>
		</message>
		<message>
			<source>tooltip_label</source>
			<translation>label</translation>
		</message>
		<message>
			<source>lbl_vdefault_workspace</source>
			<translation>lbl_vdefault_workspace</translation>
		</message>
		<message>
			<source>tooltip_lbl_vdefault_workspace</source>
			<translation>Bieżący obszar roboczy</translation>
		</message>
		<message>
			<source>lbl_workspace_name</source>
			<translation>Filtruj według: Nazwa obszaru roboczego</translation>
		</message>
		<message>
			<source>tooltip_lbl_workspace_name</source>
			<translation>lbl_workspace_name</translation>
		</message>
		<message>
			<source>txt_name</source>
			<translation>Nazwa</translation>
		</message>
		<message>
			<source>tooltip_txt_name</source>
			<translation>Nazwa obszaru roboczego</translation>
		</message>
	</context>
</TS>
