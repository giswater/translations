/*
This file is part of Giswater
The program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
*/


SET search_path = SCHEMA_NAME, public, pg_catalog;
UPDATE config_csv AS t SET alias = v.alias, descript = v.descript FROM (
	VALUES
	(234, 'Importar preços do banco de dados', E'O arquivo csv deve conter as seguintes colunas na mesma posição: id, unit, descript, text, price. \n- A coluna price deve ser numérica com duas casas decimais. \n- Você pode escolher um nome de catálogo para esses preços definindo um rótulo de importação.'),
    (235, 'Importar elementos', E'O arquivo csv deve conter as seguintes colunas na mesma posição:\nId (arc_id, node_id, connec_id), code, elementcat_id, observ, comment, num_elements, state type (id), workcat_id, verified (selecionar em edit_typevalue>value_verified).\n- Os campos observations e comments são opcionais\n- ATENÇÃO! O rótulo de importação deve ser preenchido com o tipo de elemento (node, arc, connec)'),
    (238, 'Importar visita OM', E'Para usar esta função de importação csv de parâmetros de visita OM, é necessário configurar antes de executá-la o parâmetro do sistema ''utils_csv2pg_om_visit_parameters''. \nTambém recomendamos ler antes as anotações dentro da função para trabalhar o melhor possível com ela'),
    (384, 'Importar curvas inp', E'Função para automatizar a importação de arquivos de curvas inp. \nO arquivo csv deve conter as seguintes colunas na mesma posição: \ncurve_id, x_value, y_value, curve_type (para projeto WS OU UD o curve_type tem valores diferentes. Verifique o manual do usuário)'),
    (386, 'Importar padrões inp', E'Função para automatizar a importação de arquivos de padrões inp. \nO arquivo csv deve conter as seguintes colunas na mesma posição: \npattern_id, pattern_type, factor1,.......,factorn. \nPara WS use até factor18, repetindo linhas se desejar. \nPara UD use até factor24. Não é permitido mais de uma linha por pattern'),
    (444, 'Importar cat_feature_arc', E'O arquivo csv deve conter as seguintes colunas na mesma ordem exata: \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (445, 'Importar cat_feature_node', E'O arquivo csv deve conter as seguintes colunas na mesma ordem exata: \nid, system_id, epa_default, isarcdivide, isprofilesurface, choose_hemisphere, code_autofill, double_geom, num_arcs, graph_delimiter, shortcut_key, link_path, descript, active'),
    (446, 'Importar cat_feature_connec', E'O arquivo csv deve conter as seguintes colunas na mesma ordem exata: \nid, system_id, epa_default, code_autofill, shortcut_key, link_path, descript, active'),
    (448, 'Importar cat_node', E'O arquivo csv deve conter as seguintes colunas na mesma ordem exata: \nid, nodetype_id, matcat_id, pnom, dnom, dint, dext, shape, descript, link, brand, model, svg, estimated_depth, cost_unit, cost, active, label, ischange, acoeff'),
    (449, 'Importar cat_connec', E'O arquivo csv deve conter as seguintes colunas na mesma ordem exata: \nid, connectype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, active, label'),
    (450, 'Importar cat_arc', E'O arquivo csv deve conter as seguintes colunas na mesma ordem exata: \nid, arctype_id, matcat_id, pnom, dnom, dint, dext, descript, link, brand, model, svg, z1, z2, width, area, estimated_depth, bulk, cost_unit, cost, m2bottom_cost, m3protec_cost, active, label, shape, acoeff, connect_cost'),
    (469, 'Importar valores SCADA', 'Importar valores SCADA para a tabela ext_rtc_scada_x_data conforme o arquivo de exemplo scada_values.csv'),
    (470, 'Importar hydrometer_x_data', E'O arquivo csv deve ter os seguintes campos:\nhydrometer_id, cat_period_id, sum, value_date (opcional), value_type (opcional), value_status (opcional), value_state (opcional)'),
    (471, 'Importar valores de período CRM', E'O arquivo csv deve ter os seguintes campos:\nid, start_date, end_date, period_seconds (opcional), code'),
    (500, 'Importar status de válvula', E'O arquivo csv deve ter os seguintes campos:\ndscenario_name, node_id, status'),
    (501, 'Importar demandas dscenario', 'O arquivo csv deve conter os seguintes campos: dscenario_name, feature_id, feature_type, value, pattern_id, demand_type, source.'),
    (504, 'Importar valores diários de medidor de fluxo', 'Importar valores diários de medidor de fluxo para a tabela ext_rtc_scada_x_data conforme o arquivo de exemplo scada_flowmeter_daily_values.csv'),
    (506, 'Importar valores agregados de medidor de fluxo', 'Importar valores agregados de medidor de fluxo para a tabela ext_rtc_scada_x_data conforme o arquivo de exemplo scada_flowmeter_agg_values.csv'),
    (514, 'Importar válvulas fechadas em netscenario', E'O arquivo csv deve ter os seguintes campos:\nnetscenario_id, node_id, closed')
) AS v(fid, alias, descript)
WHERE t.fid = v.fid;